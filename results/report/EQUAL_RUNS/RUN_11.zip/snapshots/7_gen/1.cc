tcb->m_cWnd = (int) (81.297*(11.307)*(26.877)*(-13.371)*(50.749));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-1.408*(-12.873)*(-25.817));
CongestionAvoidance (tcb, segmentsAcked);
