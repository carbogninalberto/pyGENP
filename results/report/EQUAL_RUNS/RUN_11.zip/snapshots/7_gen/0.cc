tcb->m_cWnd = (int) (-38.123*(72.51)*(-58.525)*(19.251)*(84.299));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (80.122*(56.841)*(81.762));
CongestionAvoidance (tcb, segmentsAcked);
