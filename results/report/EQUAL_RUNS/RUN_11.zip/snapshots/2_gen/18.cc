float dEKmkCfyxTiEhfaR = (float) 55.968;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (41.494-(-40.614)-(-63.939)-(-43.238)-(62.163)-(-88.377));
