int ghThPVOgHGOyhCnc = (int) 51.169;
if (segmentsAcked < segmentsAcked) {
	tcb->m_cWnd = (int) (53.72*(26.361)*(84.096)*(segmentsAcked)*(14.148)*(66.871)*(66.653));

} else {
	tcb->m_cWnd = (int) (3.504+(12.053)+(43.987)+(98.068)+(9.785)+(47.347)+(91.201));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
