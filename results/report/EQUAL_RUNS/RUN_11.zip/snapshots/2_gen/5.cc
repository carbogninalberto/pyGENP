float KCYiDVAqOwZnJADl = (float) (44.681-(-45.595)-(42.317)-(-87.877)-(74.935)-(-61.24)-(-60.9)-(57.081)-(40.779));
tcb->m_cWnd = (int) (-30.487-(-81.242)-(7.895)-(-73.149));
segmentsAcked = (int) (-96.49+(-9.037));
CongestionAvoidance (tcb, segmentsAcked);
