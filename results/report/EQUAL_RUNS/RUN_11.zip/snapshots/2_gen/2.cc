segmentsAcked = (int) (-65.939-(9.22)-(-29.821)-(-72.506)-(83.435));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (13.249-(76.625)-(23.445)-(81.453)-(32.492)-(1.937));

} else {
	tcb->m_segmentSize = (int) (11.752-(40.499));
	tcb->m_segmentSize = (int) (76.945-(21.758)-(65.108)-(73.688)-(24.634)-(59.657)-(tcb->m_segmentSize));

}
CongestionAvoidance (tcb, segmentsAcked);
