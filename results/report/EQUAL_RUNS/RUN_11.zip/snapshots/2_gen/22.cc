float czZmWVShDWCbNxDZ = (float) (-24.49-(-60.545)-(4.886)-(-96.732)-(-1.459));
segmentsAcked = (int) (-39.785-(1.69)-(5.205));
tcb->m_cWnd = (int) (83.032*(80.131)*(-24.055));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (73.462*(31.511)*(-24.34));
segmentsAcked = (int) (29.129*(50.706)*(-44.782)*(-64.066));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-2.995*(-4.524)*(94.72)*(49.919));
