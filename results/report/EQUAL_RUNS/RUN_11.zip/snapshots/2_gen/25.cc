tcb->m_cWnd = (int) (9.056*(-1.48)*(61.399)*(-42.535));
ReduceCwnd (tcb);
