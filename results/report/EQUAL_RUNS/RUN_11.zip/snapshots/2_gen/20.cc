float czZmWVShDWCbNxDZ = (float) (-32.887-(17.136)-(15.248)-(11.987)-(97.128));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-17.761*(-65.649)*(-33.982));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-3.697*(-92.538)*(27.244)*(84.804));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-66.04*(28.004)*(95.381)*(-58.936));
