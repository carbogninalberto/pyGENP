float ZfBKrlcfUvUGVVlr = (float) (45.045-(-80.932)-(68.289)-(-56.744)-(72.1)-(-18.392)-(-55.226));
float WLTicWtZBqQfdljl = (float) (35.351/43.344);
tcb->m_segmentSize = (int) (((23.306)+((92.337-(9.047)-(71.782)-(-48.48)-(tcb->m_cWnd)-(-97.704)-(-31.639)-(87.275)))+(-63.366)+(29.908)+(-20.175))/((-92.981)));
if (WLTicWtZBqQfdljl == ZfBKrlcfUvUGVVlr) {
	segmentsAcked = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((-78.665)+((-80.473-(84.215)-(13.333)-(ZfBKrlcfUvUGVVlr)-(tcb->m_cWnd)-(3.197)-(12.718)-(ZfBKrlcfUvUGVVlr)))+(42.197)+(49.634)+(-54.67))/((-22.064)));
int qwUbOJTpfRmKSCoj = (int) (0.684-(23.197)-(-96.504)-(-47.266)-(92.855)-(-4.284)-(83.627));
if (WLTicWtZBqQfdljl == ZfBKrlcfUvUGVVlr) {
	segmentsAcked = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (0.1/0.1);

}
