if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (28.543-(49.193)-(tcb->m_cWnd)-(-25.466)-(tcb->m_cWnd)-(tcb->m_cWnd)-(tcb->m_cWnd)-(34.689)-(75.412));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(31.169)-(50.838)-(88.855)-(33.148)-(99.596)-(92.402));

}
int ywwmytxSFnjhZDlf = (int) (-34.104-(-1.108)-(-52.734)-(-11.044)-(-40.466)-(74.739)-(-6.189));
tcb->m_segmentSize = (int) (((23.164)+(98.093)+(-79.024)+(-5.444))/((-68.654)));
tcb->m_cWnd = (int) (-3.498+(-26.244)+(-36.49)+(-24.796)+(96.708));
tcb->m_cWnd = (int) (64.149*(67.221)*(-62.849)*(-57.165)*(28.896)*(-83.295));
