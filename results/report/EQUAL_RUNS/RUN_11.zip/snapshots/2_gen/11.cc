ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(68.318)-(18.423)-(57.119));
	segmentsAcked = (int) (51.329*(-0.038)*(17.783)*(22.927)*(43.444)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (53.577-(-48.876)-(53.644)-(tcb->m_segmentSize)-(27.357)-(95.806)-(88.755));

}
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	segmentsAcked = (int) (39.945-(44.844)-(tcb->m_segmentSize)-(56.83)-(93.64)-(1.191)-(50.782));
	segmentsAcked = (int) (26.775-(27.003));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (27.996/31.938);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-78.769+(90.125)+(81.992)+(57.301)+(-68.24)+(27.151));
tcb->m_segmentSize = (int) (17.16-(35.219)-(-27.511)-(36.955)-(9.543)-(-48.917)-(55.192)-(-29.967));
