int FHlOPGVOmfTMRPsf = (int) (69.823/0.1);
if (tcb->m_segmentSize < FHlOPGVOmfTMRPsf) {
	tcb->m_ssThresh = (int) (88.615+(81.118)+(FHlOPGVOmfTMRPsf));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (16.424+(35.988)+(6.055)+(tcb->m_ssThresh)+(71.869));
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(36.392));

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked == tcb->m_cWnd) {
	FHlOPGVOmfTMRPsf = (int) (tcb->m_segmentSize-(2.257)-(3.145)-(51.199)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(segmentsAcked)-(tcb->m_ssThresh)-(70.355));
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(7.289)+(tcb->m_segmentSize)+(13.057));
	FHlOPGVOmfTMRPsf = (int) (94.083*(77.462)*(FHlOPGVOmfTMRPsf)*(tcb->m_cWnd)*(47.669)*(11.208)*(tcb->m_ssThresh)*(77.664)*(30.27));

} else {
	FHlOPGVOmfTMRPsf = (int) (99.724*(7.843)*(54.204)*(39.447));
	tcb->m_segmentSize = (int) ((75.663-(tcb->m_segmentSize)-(11.736)-(56.827)-(80.233))/82.72);

}
segmentsAcked = (int) (83.501-(56.235)-(14.334));
