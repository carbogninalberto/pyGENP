tcb->m_cWnd = (int) (-10.366*(-97.266)*(99.271)*(-80.98)*(-90.819));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-26.54*(86.009)*(-18.665));
CongestionAvoidance (tcb, segmentsAcked);
