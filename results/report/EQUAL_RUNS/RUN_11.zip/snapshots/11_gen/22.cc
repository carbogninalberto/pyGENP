float qtsjeazFPipDncOg = (float) (tcb->m_cWnd*(96.126)*(22.519)*(tcb->m_ssThresh));
segmentsAcked = (int) (42.368+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(74.366)+(4.258)+(37.8)+(tcb->m_cWnd)+(95.985));
if (qtsjeazFPipDncOg < segmentsAcked) {
	qtsjeazFPipDncOg = (float) (96.157-(55.658)-(26.47)-(7.243)-(22.99)-(32.487)-(3.952));
	tcb->m_cWnd = (int) (10.377*(77.409));
	tcb->m_ssThresh = (int) (13.164*(81.941)*(64.021)*(91.782)*(56.835)*(10.846)*(86.679)*(71.136));

} else {
	qtsjeazFPipDncOg = (float) (39.98/0.1);
	qtsjeazFPipDncOg = (float) (38.352/37.708);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
