float KQXQvklosVkuATOJ = (float) (-8.42+(12.027)+(-23.152)+(99.707)+(45.486)+(37.104)+(35.191)+(-11.35)+(52.942));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int hlslFkCEmFJyWGYQ = (int) (-12.572-(98.027)-(68.612)-(50.604)-(56.719)-(-70.292));
ReduceCwnd (tcb);
int kjHMEYKAxNFikODN = (int) 93.798;
kjHMEYKAxNFikODN = (int) (-92.354*(66.722));
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (((0.1)+((1.749*(48.576)*(0.988)*(tcb->m_cWnd)*(93.036)*(86.794)))+(46.971)+(77.187)+(63.127)+(58.057))/((63.245)+(0.1)+(61.662)));

} else {
	tcb->m_segmentSize = (int) (96.595-(68.846)-(32.549)-(tcb->m_segmentSize)-(26.407)-(4.482)-(42.425));

}
if (KQXQvklosVkuATOJ <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (72.621*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(14.978));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (5.005-(KQXQvklosVkuATOJ)-(5.574)-(32.414)-(85.432));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
