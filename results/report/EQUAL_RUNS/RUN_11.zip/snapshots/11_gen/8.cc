tcb->m_cWnd = (int) ((((66.338+(-20.151)+(27.675)+(81.982)+(60.033)+(tcb->m_segmentSize)))+(4.33)+(-34.642)+(56.878)+(1.659)+(19.071)+(-76.824))/((40.739)+(4.31)));
float kQpnbzleGrmbndhI = (float) 55.606;
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (98.588/69.456);
ReduceCwnd (tcb);
if (kQpnbzleGrmbndhI >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(25.341)-(17.678)-(58.039)-(84.165)-(65.771)-(85.066)-(77.832));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (69.546+(11.467)+(kQpnbzleGrmbndhI)+(97.898)+(56.872)+(99.416));

}
if (kQpnbzleGrmbndhI > tcb->m_segmentSize) {
	kQpnbzleGrmbndhI = (float) (57.578*(tcb->m_segmentSize)*(38.415)*(80.162)*(85.336));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	kQpnbzleGrmbndhI = (float) (50.809+(tcb->m_cWnd)+(segmentsAcked)+(76.276)+(31.239)+(51.379));
	kQpnbzleGrmbndhI = (float) (63.119*(98.228)*(77.582)*(15.345));

}
segmentsAcked = (int) (-86.443/14.586);
ReduceCwnd (tcb);
if (kQpnbzleGrmbndhI >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (69.546+(11.467)+(kQpnbzleGrmbndhI)+(97.898)+(56.872)+(99.416));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(25.341)-(17.678)-(58.039)-(84.165)-(65.771)-(85.066)-(77.832));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (kQpnbzleGrmbndhI > tcb->m_segmentSize) {
	kQpnbzleGrmbndhI = (float) (57.578*(tcb->m_segmentSize)*(38.415)*(80.162)*(85.336));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	kQpnbzleGrmbndhI = (float) (50.809+(tcb->m_cWnd)+(segmentsAcked)+(76.276)+(31.239)+(51.379));
	kQpnbzleGrmbndhI = (float) (63.119*(98.228)*(77.582)*(15.345));

}
