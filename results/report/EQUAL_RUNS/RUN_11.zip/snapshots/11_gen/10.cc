if (tcb->m_cWnd > tcb->m_segmentSize) {
	segmentsAcked = (int) (26.0-(2.229)-(80.367)-(74.08)-(28.679)-(58.53));
	segmentsAcked = (int) (14.039+(segmentsAcked)+(84.939)+(39.321)+(99.091)+(52.861));

} else {
	segmentsAcked = (int) (50.893/84.193);
	segmentsAcked = (int) (28.333*(93.51)*(80.501)*(65.934)*(segmentsAcked)*(81.696));

}
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-13.925*(87.757)*(-47.462)*(81.483));
