CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (88.306-(60.823));
tcb->m_segmentSize = (int) (21.342+(98.538)+(39.761)+(28.828)+(tcb->m_segmentSize)+(segmentsAcked)+(98.487)+(53.038)+(96.525));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (19.463+(tcb->m_ssThresh)+(76.096)+(43.394)+(tcb->m_ssThresh)+(18.853)+(13.026));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (92.299+(44.852)+(21.352)+(0.136)+(3.198));

} else {
	segmentsAcked = (int) (43.964+(tcb->m_segmentSize)+(tcb->m_cWnd)+(31.732)+(32.154)+(11.74)+(83.71));
	tcb->m_cWnd = (int) (25.846+(45.163)+(tcb->m_ssThresh)+(2.117)+(0.25)+(8.571)+(33.078)+(68.386)+(27.518));

}
segmentsAcked = (int) (82.093/76.871);
