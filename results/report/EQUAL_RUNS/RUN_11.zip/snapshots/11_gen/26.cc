CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (54.465*(47.454)*(99.621)*(segmentsAcked)*(tcb->m_ssThresh)*(48.389)*(68.826));
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(39.356)*(60.345)*(52.905));
	tcb->m_cWnd = (int) (segmentsAcked*(2.201)*(76.275)*(0.325)*(5.736)*(tcb->m_ssThresh)*(70.631));

} else {
	tcb->m_ssThresh = (int) (57.357*(46.395)*(77.68)*(67.373)*(26.091)*(26.077)*(19.465));
	ReduceCwnd (tcb);

}
CongestionAvoidance (tcb, segmentsAcked);
float sXpONyrjroGvcmGT = (float) (40.208-(52.653)-(49.349)-(59.086)-(14.356)-(11.001)-(segmentsAcked));
