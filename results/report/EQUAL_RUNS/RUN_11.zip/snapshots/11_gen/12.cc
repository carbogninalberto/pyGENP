tcb->m_cWnd = (int) (14.195*(-2.075)*(-76.035)*(-42.802)*(-18.52));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (88.664*(-39.884)*(86.223));
CongestionAvoidance (tcb, segmentsAcked);
