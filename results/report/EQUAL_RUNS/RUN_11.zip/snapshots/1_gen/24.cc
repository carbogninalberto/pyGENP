if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((68.126)+(0.1)+(14.648)+(84.622)+(75.03)+(17.521))/((48.699)+(5.166)));
	segmentsAcked = (int) (0.137+(18.993)+(tcb->m_cWnd)+(55.18)+(11.036)+(97.44));

} else {
	tcb->m_segmentSize = (int) (20.13-(32.101));
	segmentsAcked = (int) (80.396*(tcb->m_segmentSize));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (((7.983)+(0.1)+(0.1)+(0.1)+(79.752)+(46.569)+(0.1))/((0.1)));
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_cWnd = (int) (54.571/0.1);
	tcb->m_segmentSize = (int) (18.409+(45.281)+(72.46)+(22.469)+(13.224)+(35.411)+(49.51)+(0.888)+(tcb->m_ssThresh));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (69.406-(4.327)-(28.879)-(20.533)-(85.793));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(38.124)+(0.1))/((8.404)));

}
