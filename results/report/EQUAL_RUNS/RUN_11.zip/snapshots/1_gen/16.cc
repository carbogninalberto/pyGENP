if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((3.909)+(61.747)+(64.893)+(82.61))/((0.1)+(0.1)+(47.015)+(0.1)+(46.51)));

} else {
	tcb->m_ssThresh = (int) (21.712*(tcb->m_ssThresh)*(20.4)*(69.247)*(35.84)*(20.284));
	tcb->m_ssThresh = (int) (45.081-(tcb->m_ssThresh)-(7.97)-(9.077)-(68.342)-(segmentsAcked)-(58.287));
	tcb->m_ssThresh = (int) (segmentsAcked*(65.874)*(0.787)*(tcb->m_ssThresh)*(43.76)*(39.531)*(tcb->m_ssThresh)*(92.663));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_cWnd = (int) (26.436*(7.637)*(36.68)*(49.78)*(29.891));
	tcb->m_cWnd = (int) (73.894*(89.206)*(41.72)*(2.847)*(25.498));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(4.316)*(segmentsAcked)*(34.134));
	tcb->m_ssThresh = (int) (1.658+(53.924)+(25.044)+(72.098)+(8.647)+(99.81)+(97.793)+(28.59)+(66.821));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (38.359*(47.693)*(segmentsAcked));
tcb->m_cWnd = (int) (tcb->m_segmentSize-(79.961)-(42.462)-(tcb->m_segmentSize));
