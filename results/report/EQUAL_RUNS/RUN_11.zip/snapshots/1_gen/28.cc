tcb->m_cWnd = (int) (35.237+(17.165)+(21.245)+(90.474)+(41.458)+(40.569)+(13.967)+(86.244)+(74.295));
segmentsAcked = (int) (15.267/0.1);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
