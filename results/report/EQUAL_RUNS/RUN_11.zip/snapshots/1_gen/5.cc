if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (28.259+(segmentsAcked)+(76.092)+(74.673));

} else {
	segmentsAcked = (int) (26.234+(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(11.798)*(77.598)*(44.588)*(tcb->m_segmentSize)*(73.822)*(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (56.32*(57.735)*(76.86)*(64.792)*(tcb->m_segmentSize)*(73.245));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd*(62.941)*(22.903)*(97.304));
	tcb->m_cWnd = (int) (87.496+(tcb->m_segmentSize)+(31.542)+(5.267)+(67.522));
	tcb->m_cWnd = (int) (68.586-(62.471));

} else {
	segmentsAcked = (int) (segmentsAcked+(46.386)+(36.787)+(34.619)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(26.257)+(27.092));

}
tcb->m_cWnd = (int) (58.116-(19.403)-(tcb->m_cWnd)-(66.505));
