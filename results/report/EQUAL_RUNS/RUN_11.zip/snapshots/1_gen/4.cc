ReduceCwnd (tcb);
float WLTicWtZBqQfdljl = (float) (0.1/0.1);
float ZfBKrlcfUvUGVVlr = (float) (41.458-(78.066)-(48.067)-(71.945)-(39.114)-(57.363)-(93.045));
tcb->m_segmentSize = (int) (((40.089)+((38.878-(51.83)-(97.723)-(ZfBKrlcfUvUGVVlr)-(tcb->m_cWnd)-(37.814)-(80.378)-(ZfBKrlcfUvUGVVlr)))+(0.1)+(49.614)+(0.1))/((51.653)));
if (WLTicWtZBqQfdljl == ZfBKrlcfUvUGVVlr) {
	segmentsAcked = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (0.1/0.1);

}
