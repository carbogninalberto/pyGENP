CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (((70.893)+((0.513+(97.014)))+(41.774)+(0.1)+((42.06*(79.591)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(43.868)))+(74.586)+(67.192))/((13.484)));
tcb->m_segmentSize = (int) (71.249*(37.065)*(78.544)*(tcb->m_segmentSize)*(segmentsAcked)*(61.0)*(89.675)*(28.947));
tcb->m_cWnd = (int) (6.289+(77.198)+(48.825));
ReduceCwnd (tcb);
