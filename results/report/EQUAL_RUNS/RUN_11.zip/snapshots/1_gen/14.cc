segmentsAcked = (int) (tcb->m_cWnd+(95.959));
ReduceCwnd (tcb);
float iTnYYHEaOJBDsqHq = (float) (3.128*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(72.589)*(tcb->m_ssThresh));
iTnYYHEaOJBDsqHq = (float) (38.449+(3.013)+(tcb->m_segmentSize)+(iTnYYHEaOJBDsqHq)+(47.892)+(50.135)+(45.651)+(tcb->m_ssThresh));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (17.872*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (((32.186)+((tcb->m_cWnd+(6.413)+(17.852)+(84.214)+(77.347)+(99.446)+(13.903)+(82.268)+(tcb->m_segmentSize)))+((tcb->m_cWnd*(68.38)*(67.299)*(73.665)))+(0.1)+(0.1)+(0.1))/((32.172)+(32.531)+(64.677)));

} else {
	tcb->m_ssThresh = (int) (iTnYYHEaOJBDsqHq+(49.332)+(79.182));
	segmentsAcked = (int) (95.457+(7.597)+(36.158)+(51.828));
	segmentsAcked = (int) (87.79-(85.776));

}
tcb->m_ssThresh = (int) (((0.1)+(76.139)+(63.936)+(11.621)+(0.1)+(0.1))/((0.1)));
