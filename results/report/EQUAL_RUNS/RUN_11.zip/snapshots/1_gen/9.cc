float PFcoQMGDGjWGzhQd = (float) (31.191+(48.848)+(75.971));
tcb->m_segmentSize = (int) (tcb->m_ssThresh-(14.82)-(71.455)-(75.473)-(30.55)-(20.375)-(tcb->m_segmentSize)-(76.177));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	segmentsAcked = (int) (((90.997)+(0.1)+((63.324-(segmentsAcked)-(95.862)-(tcb->m_cWnd)-(23.597)-(55.014)-(7.239)-(73.912)))+((74.963-(40.309)-(70.257)-(60.174)-(tcb->m_cWnd)-(93.974)-(57.385)-(21.994)))+(0.1)+(7.899))/((13.263)+(0.1)));
	tcb->m_ssThresh = (int) (86.621+(88.506)+(35.825));

} else {
	segmentsAcked = (int) (tcb->m_cWnd*(PFcoQMGDGjWGzhQd));

}
float cwuCWscSTZYBsvUH = (float) (PFcoQMGDGjWGzhQd*(66.425)*(95.251)*(31.399)*(91.105)*(34.071)*(58.345));
float asbfYlcUTrVZeEZN = (float) (0.1/7.939);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (((45.938)+(95.802)+(27.971)+(0.1))/((43.458)+(66.928)+(0.1)+(0.1)));
cwuCWscSTZYBsvUH = (float) (52.088+(tcb->m_segmentSize)+(2.855)+(33.319)+(11.696)+(asbfYlcUTrVZeEZN)+(4.188));
if (tcb->m_ssThresh == segmentsAcked) {
	asbfYlcUTrVZeEZN = (float) (95.195-(13.503)-(tcb->m_cWnd)-(tcb->m_segmentSize));
	PFcoQMGDGjWGzhQd = (float) ((((97.352*(7.224)*(7.032)*(segmentsAcked)*(cwuCWscSTZYBsvUH)*(99.642)))+(60.752)+(88.786)+(55.413))/((0.1)+(77.225)+(28.707)+(34.844)));

} else {
	asbfYlcUTrVZeEZN = (float) (26.449-(82.317)-(tcb->m_segmentSize)-(48.007)-(asbfYlcUTrVZeEZN)-(95.091)-(48.328)-(70.878)-(82.814));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (37.558+(49.669)+(25.022)+(77.092));

}
