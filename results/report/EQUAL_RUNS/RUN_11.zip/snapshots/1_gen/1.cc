tcb->m_cWnd = (int) (33.84-(2.123)-(tcb->m_segmentSize)-(46.076)-(48.041)-(85.63)-(20.53));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (98.458+(29.254)+(tcb->m_ssThresh)+(38.651)+(98.66)+(98.122)+(1.963)+(tcb->m_segmentSize));
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (37.874+(2.835)+(segmentsAcked)+(31.305)+(69.976)+(93.743));
	tcb->m_ssThresh = (int) (73.219*(74.44)*(8.83)*(63.616)*(20.206)*(89.788));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (4.389+(74.473)+(64.025)+(97.889)+(1.859)+(86.517)+(tcb->m_ssThresh)+(79.819)+(segmentsAcked));
	tcb->m_cWnd = (int) (47.118*(27.55)*(79.902)*(23.437)*(13.374)*(67.568));

}
segmentsAcked = (int) (70.804+(32.543));
