ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (40.656-(33.961)-(96.389)-(64.271)-(7.494)-(76.625));
CongestionAvoidance (tcb, segmentsAcked);
float jgUJNBQiXYvCHQuF = (float) (64.348+(56.907)+(61.3)+(31.909)+(42.454)+(87.612)+(tcb->m_segmentSize)+(44.652)+(69.938));
jgUJNBQiXYvCHQuF = (float) (77.128-(10.3));
tcb->m_ssThresh = (int) (tcb->m_cWnd+(83.334)+(segmentsAcked)+(46.758)+(jgUJNBQiXYvCHQuF)+(80.169)+(52.082));
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (14.081*(jgUJNBQiXYvCHQuF)*(43.888)*(segmentsAcked)*(54.269)*(90.752)*(96.366)*(tcb->m_ssThresh));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (72.108-(25.041)-(51.353));
	jgUJNBQiXYvCHQuF = (float) (58.014+(17.414)+(51.139)+(97.25)+(jgUJNBQiXYvCHQuF)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(51.886)+(82.166));

}
