tcb->m_cWnd = (int) (-43.298-(-26.213)-(57.95)-(11.296));
segmentsAcked = (int) (74.841+(66.026));
CongestionAvoidance (tcb, segmentsAcked);
