tcb->m_cWnd = (int) (94.235*(38.887)*(-24.367)*(-5.94)*(65.54));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (84.264*(52.151)*(99.254));
CongestionAvoidance (tcb, segmentsAcked);
