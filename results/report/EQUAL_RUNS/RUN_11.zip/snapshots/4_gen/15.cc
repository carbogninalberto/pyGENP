tcb->m_cWnd = (int) (69.381*(-72.742)*(-87.134)*(-9.891)*(-63.374)*(-3.082)*(-59.56));
tcb->m_cWnd = (int) (75.11-(91.321)-(-33.969)-(47.89));
segmentsAcked = (int) (8.957+(-80.036));
segmentsAcked = (int) (-85.25+(74.334));
CongestionAvoidance (tcb, segmentsAcked);
