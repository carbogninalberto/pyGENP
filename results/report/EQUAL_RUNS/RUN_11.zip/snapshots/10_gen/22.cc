if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (84.986-(60.302)-(96.362)-(63.827)-(54.731)-(2.338));
	segmentsAcked = (int) (99.936+(51.142)+(93.063)+(52.164)+(31.13)+(61.196)+(9.794));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(62.632)-(47.914));

} else {
	tcb->m_cWnd = (int) (22.211/37.669);
	CongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (76.431*(32.863)*(33.061)*(86.568)*(tcb->m_segmentSize)*(83.79)*(22.358));
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_cWnd = (int) (41.066*(18.952)*(68.095)*(89.743));

} else {
	tcb->m_cWnd = (int) (36.894-(27.654)-(74.125));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
int KSkutTzFydZNzOBu = (int) (tcb->m_segmentSize*(24.55)*(segmentsAcked)*(38.244));
tcb->m_segmentSize = (int) (23.106+(77.704)+(23.98)+(23.032));
