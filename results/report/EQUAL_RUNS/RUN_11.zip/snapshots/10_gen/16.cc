tcb->m_cWnd = (int) (-6.176*(-63.706)*(69.113)*(-2.275)*(-21.356));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (27.315*(-69.235)*(-11.581));
CongestionAvoidance (tcb, segmentsAcked);
