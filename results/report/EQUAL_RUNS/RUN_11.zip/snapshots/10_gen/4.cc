tcb->m_cWnd = (int) (98.601*(46.23)*(2.453)*(-15.331)*(-81.055));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (39.821*(-74.478)*(-86.768));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (78.233*(-15.124)*(32.769));
CongestionAvoidance (tcb, segmentsAcked);
