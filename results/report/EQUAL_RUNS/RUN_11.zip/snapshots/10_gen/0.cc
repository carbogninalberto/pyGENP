tcb->m_cWnd = (int) (-15.449*(-7.722)*(-47.568)*(81.456)*(73.493));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-36.739*(16.393)*(-10.704));
CongestionAvoidance (tcb, segmentsAcked);
