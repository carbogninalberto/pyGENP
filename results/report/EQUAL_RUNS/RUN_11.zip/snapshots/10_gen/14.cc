tcb->m_cWnd = (int) (90.18*(73.536)*(90.612)*(1.043)*(-10.579));
tcb->m_cWnd = (int) (-22.453*(11.111)*(-1.761)*(-8.446)*(-92.003));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (63.312*(51.267)*(-75.044));
tcb->m_cWnd = (int) (-23.313*(78.189)*(31.489));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
