tcb->m_cWnd = (int) (-87.026*(-49.876)*(-73.902)*(58.949)*(-33.7));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (51.258*(-24.091)*(-50.487));
CongestionAvoidance (tcb, segmentsAcked);
