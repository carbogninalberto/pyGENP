if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) (5.691-(40.337)-(49.748)-(34.834)-(52.845)-(91.135)-(0.685));

} else {
	segmentsAcked = (int) (0.1/50.545);
	tcb->m_segmentSize = (int) (41.449+(70.109)+(45.538)+(94.255)+(tcb->m_cWnd)+(48.091)+(41.962));
	tcb->m_segmentSize = (int) (24.552+(10.649)+(39.869)+(77.039)+(segmentsAcked)+(40.671));

}
tcb->m_cWnd = (int) (17.114*(-38.068)*(-17.196)*(-50.979)*(-20.143)*(-30.169));
