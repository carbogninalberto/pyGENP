if (segmentsAcked >= tcb->m_cWnd) {
	segmentsAcked = (int) (50.636*(36.968)*(29.546)*(35.439));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (0.1/26.053);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize != tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd+(39.628)+(tcb->m_ssThresh)+(15.738)+(6.207));
	tcb->m_cWnd = (int) (63.033/29.344);

} else {
	segmentsAcked = (int) (3.803-(73.19)-(32.71));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_ssThresh) {
	segmentsAcked = (int) (20.122+(40.313)+(57.651)+(52.465)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(21.171)+(18.6)+(12.175));
	segmentsAcked = (int) (tcb->m_cWnd-(87.203));

} else {
	segmentsAcked = (int) (94.281*(tcb->m_ssThresh)*(8.031)*(36.488)*(13.14)*(77.558));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
