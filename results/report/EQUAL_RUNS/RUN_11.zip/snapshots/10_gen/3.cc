tcb->m_cWnd = (int) (-61.715*(0.512)*(-77.144)*(-76.275)*(24.956));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-82.179*(15.232)*(95.437));
CongestionAvoidance (tcb, segmentsAcked);
