if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (83.8-(71.486)-(28.676)-(42.68)-(92.559)-(64.363)-(36.581)-(57.43));
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(27.632)*(4.77));

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(6.386)+(0.1)+((62.092*(tcb->m_segmentSize)*(tcb->m_cWnd)*(20.355)*(tcb->m_cWnd)*(22.6)))+(0.1)+(7.166))/((0.1)));
	segmentsAcked = (int) ((60.213+(segmentsAcked)+(85.578)+(19.965)+(74.639)+(60.311)+(46.187)+(tcb->m_cWnd)+(58.254))/40.669);
	tcb->m_cWnd = (int) (7.495-(97.174)-(tcb->m_segmentSize)-(57.867)-(12.766));

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (81.508-(58.868)-(7.342)-(92.435)-(tcb->m_ssThresh)-(2.904)-(11.238));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (98.662+(62.952)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(55.493)+(4.31)+(tcb->m_ssThresh));
