float RohMayainYoXaalk = (float) (tcb->m_cWnd+(37.761)+(77.418)+(19.798));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (14.778*(26.63)*(64.173)*(71.147));
	tcb->m_segmentSize = (int) (segmentsAcked+(74.383)+(tcb->m_ssThresh)+(56.714)+(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (80.912*(79.434)*(tcb->m_cWnd)*(73.345)*(tcb->m_ssThresh)*(20.611));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
