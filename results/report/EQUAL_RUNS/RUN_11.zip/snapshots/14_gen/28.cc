tcb->m_segmentSize = (int) (84.035-(56.743)-(29.962)-(67.156));
if (tcb->m_ssThresh == tcb->m_cWnd) {
	segmentsAcked = (int) (55.489-(15.105));
	tcb->m_cWnd = (int) (98.726*(0.591));
	segmentsAcked = (int) (0.1/(38.677+(86.148)+(tcb->m_cWnd)+(90.064)+(64.662)+(95.896)+(61.957)+(88.801)+(tcb->m_segmentSize)));

} else {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (18.683/0.1);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_ssThresh-(52.658)-(82.573)-(10.301)-(88.713));
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (82.018/36.266);
	tcb->m_cWnd = (int) (70.884/0.1);
	tcb->m_cWnd = (int) (84.988*(tcb->m_cWnd)*(28.127)*(tcb->m_ssThresh)*(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (50.242*(24.624)*(tcb->m_cWnd)*(5.405)*(11.727)*(81.166)*(34.81)*(34.607));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
