tcb->m_cWnd = (int) (29.693+(7.416));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (0.1/0.1);
tcb->m_cWnd = (int) (((8.358)+(90.633)+(0.1)+(83.402)+(0.1)+(6.858))/((15.641)+(0.1)));
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.625*(34.707)*(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (((37.346)+(35.871)+(13.373)+(55.654))/((0.1)+(68.676)+(18.969)));

}
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (15.405*(25.225)*(25.407)*(57.985)*(80.109)*(86.41)*(48.116));

} else {
	tcb->m_segmentSize = (int) (15.228+(56.345));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (69.53-(67.08)-(tcb->m_ssThresh)-(57.827)-(92.944)-(50.147)-(39.038)-(tcb->m_segmentSize));

}
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((0.1)+((80.245*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(segmentsAcked)))+(0.1)+(0.1))/((0.1)+(0.1)+(26.464)+(65.682)+(14.528)));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(0.375)-(6.039)-(25.718));

} else {
	tcb->m_cWnd = (int) (18.076*(10.068)*(7.185)*(82.026)*(15.099));

}
tcb->m_ssThresh = (int) (0.1/0.1);
