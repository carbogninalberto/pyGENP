tcb->m_cWnd = (int) (42.19/(tcb->m_segmentSize+(5.826)+(31.227)+(tcb->m_ssThresh)));
tcb->m_cWnd = (int) (segmentsAcked-(tcb->m_ssThresh)-(17.577)-(96.902)-(88.139));
tcb->m_segmentSize = (int) ((tcb->m_segmentSize+(59.87))/0.1);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
