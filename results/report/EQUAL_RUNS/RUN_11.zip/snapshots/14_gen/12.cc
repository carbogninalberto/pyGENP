tcb->m_cWnd = (int) (-1.685*(77.013)*(-91.985)*(84.6)*(68.349));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-96.949*(68.064)*(-53.905));
CongestionAvoidance (tcb, segmentsAcked);
