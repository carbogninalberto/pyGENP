TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (92.493+(93.249)+(98.888)+(69.86));

} else {
	tcb->m_segmentSize = (int) (74.681-(34.768)-(12.07)-(segmentsAcked)-(56.818));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_cWnd = (int) (57.609+(9.683)+(37.536)+(tcb->m_cWnd)+(tcb->m_cWnd)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (82.029-(87.734)-(6.388)-(95.376)-(tcb->m_cWnd)-(32.449)-(67.296)-(42.39)-(24.683));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
