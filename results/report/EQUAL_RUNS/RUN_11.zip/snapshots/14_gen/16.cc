ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (88.525*(39.562)*(9.309)*(11.157)*(54.853)*(61.791)*(55.581)*(14.4));
tcb->m_cWnd = (int) (tcb->m_ssThresh*(95.137)*(47.635)*(35.912));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (90.973*(81.794)*(62.134));

} else {
	segmentsAcked = (int) (segmentsAcked-(tcb->m_segmentSize)-(39.468));
	tcb->m_cWnd = (int) (27.834+(14.463)+(96.941)+(68.161)+(99.523)+(85.171)+(94.143));
	CongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
