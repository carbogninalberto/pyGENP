tcb->m_cWnd = (int) (25.661+(9.097));
tcb->m_segmentSize = (int) (89.895-(7.417));
tcb->m_segmentSize = (int) (96.582-(4.863));
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(44.205));
ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (63.783*(33.319));

} else {
	tcb->m_cWnd = (int) (89.984+(30.286)+(89.384)+(57.399)+(85.11));

}
tcb->m_segmentSize = (int) (13.111+(22.509)+(segmentsAcked)+(5.116)+(9.823)+(4.559)+(tcb->m_cWnd)+(74.508)+(60.534));
