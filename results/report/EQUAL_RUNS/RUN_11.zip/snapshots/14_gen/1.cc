tcb->m_cWnd = (int) (13.501*(-79.536)*(94.513)*(-39.511)*(17.521));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-57.172*(17.855)*(60.515));
CongestionAvoidance (tcb, segmentsAcked);
