tcb->m_cWnd = (int) (68.481*(-19.271)*(-30.561)*(-25.906)*(-28.595));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-26.794*(-37.021)*(68.683));
tcb->m_cWnd = (int) (15.944*(90.76)*(-37.484)*(-53.118)*(-5.797));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (9.503*(52.365)*(37.237));
CongestionAvoidance (tcb, segmentsAcked);
