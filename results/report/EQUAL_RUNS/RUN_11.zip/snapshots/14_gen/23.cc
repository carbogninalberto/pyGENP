tcb->m_ssThresh = (int) (63.014+(42.52)+(67.907)+(tcb->m_ssThresh)+(20.715));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(53.878)+(22.465)+(6.695)+(53.534)+(92.97)+(55.645)+(46.393)+(43.928));
	tcb->m_ssThresh = (int) (87.803*(25.066)*(36.453)*(1.515)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(segmentsAcked)*(65.729));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) ((segmentsAcked+(1.932)+(6.52)+(43.063)+(67.43)+(16.233)+(10.348))/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (16.658*(34.813));
	segmentsAcked = (int) ((tcb->m_cWnd*(54.869)*(94.94)*(tcb->m_ssThresh)*(65.599)*(32.188))/0.1);
	tcb->m_ssThresh = (int) ((((36.48*(46.32)*(26.521)*(88.116)*(84.827)*(15.761)*(25.837)))+(0.1)+(0.1)+(64.405))/((90.625)));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (35.273+(5.437)+(65.391)+(66.193)+(84.69));
	tcb->m_segmentSize = (int) (51.214+(25.421)+(83.145)+(9.525));
	tcb->m_cWnd = (int) (85.737-(11.689)-(46.908)-(50.977)-(44.597)-(84.411)-(91.353));

} else {
	tcb->m_ssThresh = (int) (38.01*(segmentsAcked)*(11.543)*(56.064)*(55.798)*(33.064));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(53.793)-(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (10.969/0.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (90.077-(52.844)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(69.019)-(52.808)-(32.427)-(94.728));
ReduceCwnd (tcb);
