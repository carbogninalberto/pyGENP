tcb->m_cWnd = (int) (55.796*(-55.321)*(-36.798)*(7.568)*(-76.553));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (37.93*(92.336)*(-83.736));
CongestionAvoidance (tcb, segmentsAcked);
