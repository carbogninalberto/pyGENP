float XGvtVKdevTNVVpyo = (float) (32.027*(78.867)*(tcb->m_segmentSize));
tcb->m_cWnd = (int) (78.599*(70.826)*(65.272)*(XGvtVKdevTNVVpyo)*(tcb->m_ssThresh)*(3.705));
if (tcb->m_ssThresh == XGvtVKdevTNVVpyo) {
	segmentsAcked = (int) (31.165*(31.806)*(98.593)*(41.034)*(segmentsAcked)*(tcb->m_ssThresh)*(65.173)*(33.11));
	tcb->m_ssThresh = (int) (((0.1)+(16.311)+(99.54)+(13.234)+(0.1)+(63.934))/((0.1)+(0.1)+(47.485)));
	XGvtVKdevTNVVpyo = (float) (tcb->m_ssThresh-(25.764)-(14.296)-(17.051)-(segmentsAcked)-(44.01)-(91.767)-(85.211));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh-(19.497));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (41.436+(37.378)+(44.954)+(72.507)+(XGvtVKdevTNVVpyo)+(40.69)+(75.176)+(tcb->m_segmentSize));

}
if (tcb->m_segmentSize != segmentsAcked) {
	segmentsAcked = (int) (((63.398)+(0.1)+(0.1)+(51.419))/((0.1)));
	XGvtVKdevTNVVpyo = (float) (94.351+(5.577)+(12.346)+(22.468));

} else {
	segmentsAcked = (int) (XGvtVKdevTNVVpyo*(tcb->m_segmentSize)*(88.737)*(56.741));
	XGvtVKdevTNVVpyo = (float) (98.661-(XGvtVKdevTNVVpyo)-(XGvtVKdevTNVVpyo)-(11.543)-(18.906)-(66.65)-(63.387)-(39.73));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
XGvtVKdevTNVVpyo = (float) (39.208/0.1);
XGvtVKdevTNVVpyo = (float) (52.491*(tcb->m_segmentSize)*(77.768)*(64.982)*(85.51)*(18.824)*(93.827));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	XGvtVKdevTNVVpyo = (float) (9.781*(tcb->m_cWnd)*(94.797)*(XGvtVKdevTNVVpyo));
	tcb->m_cWnd = (int) (41.277*(tcb->m_ssThresh)*(18.981)*(14.072));

} else {
	XGvtVKdevTNVVpyo = (float) (38.719*(44.386)*(77.508)*(73.314)*(68.351));

}
