float WLTicWtZBqQfdljl = (float) (59.703/84.859);
