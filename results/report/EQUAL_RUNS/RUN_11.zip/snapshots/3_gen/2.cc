ReduceCwnd (tcb);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-54.63*(-92.958)*(-79.468)*(9.42)*(-83.477)*(11.963)*(56.959)*(-43.132));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
