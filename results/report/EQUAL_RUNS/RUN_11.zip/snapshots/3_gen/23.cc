float jErdpzUCYbXdkQgB = (float) (-64.415*(-48.458)*(-22.081)*(86.206)*(37.609)*(-18.079)*(65.814));
int lUFTkzJKbDwGIWFY = (int) (-4.321-(83.248)-(19.62)-(-57.25)-(-73.586)-(-41.181)-(-89.49)-(-49.688));
CongestionAvoidance (tcb, segmentsAcked);
int uPiawkyPaIybQkiQ = (int) ((61.726*(-13.142)*(-92.736)*(52.614)*(90.049)*(98.292)*(-76.641)*(-47.122))/31.183);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-62.296-(97.061)-(-73.744)-(-30.054)-(11.046));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
