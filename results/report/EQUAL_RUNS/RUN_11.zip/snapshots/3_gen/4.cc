segmentsAcked = (int) ((tcb->m_segmentSize-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(-25.396))/13.459);
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (28.543-(49.193)-(tcb->m_cWnd)-(57.335)-(tcb->m_cWnd)-(tcb->m_cWnd)-(tcb->m_cWnd)-(34.689)-(75.412));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(31.169)-(50.838)-(88.855)-(33.148)-(99.596)-(92.402));

}
tcb->m_cWnd = (int) (45.22*(93.802)*(79.081)*(31.797)*(56.899)*(67.834));
tcb->m_segmentSize = (int) (((-82.809)+(62.714)+(35.62)+(-15.687))/((-13.895)));
tcb->m_cWnd = (int) (-25.525+(72.484)+(-91.67)+(6.519)+(-92.584));
