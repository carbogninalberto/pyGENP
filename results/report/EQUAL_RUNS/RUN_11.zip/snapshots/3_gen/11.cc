float WLTicWtZBqQfdljl = (float) (-6.225/40.537);
ReduceCwnd (tcb);
segmentsAcked = (int) (-8.53/18.13);
float ZfBKrlcfUvUGVVlr = (float) 62.791;
tcb->m_segmentSize = (int) (((48.535)+((49.316-(23.205)-(-43.78)-(-11.825)-(tcb->m_cWnd)-(-86.523)-(39.036)-(-90.078)))+(75.845)+(34.139)+(51.894))/((-58.753)));
if (WLTicWtZBqQfdljl == ZfBKrlcfUvUGVVlr) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
