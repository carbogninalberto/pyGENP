segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-69.38-(-75.434)-(39.088)-(-8.321));
segmentsAcked = (int) (-76.922+(-91.223));
CongestionAvoidance (tcb, segmentsAcked);
