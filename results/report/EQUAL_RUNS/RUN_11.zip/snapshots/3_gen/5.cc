tcb->m_cWnd = (int) (-3.01*(-76.05)*(51.894)*(-14.199)*(-40.12));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (26.697*(-57.48)*(-60.491));
CongestionAvoidance (tcb, segmentsAcked);
