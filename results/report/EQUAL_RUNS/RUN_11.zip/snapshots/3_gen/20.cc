float WLTicWtZBqQfdljl = (float) (-69.917/-37.262);
WLTicWtZBqQfdljl = (float) (-74.801/-52.137);
segmentsAcked = (int) (3.304/28.564);
float ZfBKrlcfUvUGVVlr = (float) 51.696;
segmentsAcked = (int) (31.865/0.73);
tcb->m_segmentSize = (int) (((-28.515)+((-54.762-(85.366)-(-67.146)-(38.324)-(tcb->m_cWnd)-(69.838)-(7.309)-(-99.727)))+(-17.151)+(-61.146)+(-48.598))/((-60.603)));
tcb->m_segmentSize = (int) (((62.254)+((-61.062-(-29.731)-(-78.431)-(-4.332)-(tcb->m_cWnd)-(-52.967)-(-71.014)-(0.839)))+(-18.323)+(44.879)+(-95.405))/((84.425)));
if (WLTicWtZBqQfdljl == ZfBKrlcfUvUGVVlr) {
	segmentsAcked = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (0.1/0.1);

}
if (WLTicWtZBqQfdljl == ZfBKrlcfUvUGVVlr) {
	segmentsAcked = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (0.1/0.1);

}
