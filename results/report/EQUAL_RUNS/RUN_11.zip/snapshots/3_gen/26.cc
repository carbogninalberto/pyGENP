tcb->m_segmentSize = (int) ((-61.619-(-67.385)-(tcb->m_cWnd)-(93.433)-(41.247)-(-69.791)-(-81.713)-(24.264)-(77.779))/-7.01);
tcb->m_cWnd = (int) (-44.824-(-2.825)-(67.429)-(-58.342));
segmentsAcked = (int) (56.889+(89.275));
segmentsAcked = (int) (13.147+(-52.661));
CongestionAvoidance (tcb, segmentsAcked);
