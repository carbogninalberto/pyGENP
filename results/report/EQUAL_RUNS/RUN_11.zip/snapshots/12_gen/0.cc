tcb->m_cWnd = (int) (-49.658*(-30.246)*(-58.874)*(1.859)*(12.399));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-47.326*(-11.72)*(-14.201));
CongestionAvoidance (tcb, segmentsAcked);
