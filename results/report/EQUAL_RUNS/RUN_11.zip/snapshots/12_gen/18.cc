float YMKlqLAbKuHSyPEq = (float) (-53.387+(31.927)+(-16.074));
int nkmgWzPXqbujmsKa = (int) (-81.573*(-68.166)*(-74.944)*(-6.77)*(-37.857)*(-98.458));
YMKlqLAbKuHSyPEq = (float) (8.782-(59.808)-(22.883)-(80.525)-(71.182)-(-50.191));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
