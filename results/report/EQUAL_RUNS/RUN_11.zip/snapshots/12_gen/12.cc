float kQpnbzleGrmbndhI = (float) 55.606;
int ossxIZwxcKGFqrZa = (int) (-96.731+(26.689)+(-61.806)+(-69.689)+(44.159));
