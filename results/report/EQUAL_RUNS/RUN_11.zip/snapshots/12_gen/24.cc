tcb->m_cWnd = (int) (93.838*(86.6)*(60.272)*(-55.686)*(-3.215));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (89.109*(-73.699)*(-71.96)*(-76.513)*(70.554));
tcb->m_cWnd = (int) (85.195*(-62.685)*(94.272));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-53.761*(94.35)*(88.212));
CongestionAvoidance (tcb, segmentsAcked);
