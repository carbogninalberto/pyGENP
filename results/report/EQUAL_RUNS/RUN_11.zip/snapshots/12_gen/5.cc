float aSnQxRGBKSojWNYX = (float) (97.019*(-67.648)*(94.347)*(36.671)*(-10.891)*(79.78));
segmentsAcked = (int) (72.524-(88.821)-(-43.348)-(4.291)-(83.093)-(56.175)-(-77.945)-(-60.323)-(31.771));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
