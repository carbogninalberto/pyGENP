tcb->m_segmentSize = (int) (-17.153-(53.158)-(-74.323)-(-5.367)-(1.843)-(-17.8));
int EeWzIfDpcnMiznjh = (int) 69.405;
EeWzIfDpcnMiznjh = (int) (87.48-(69.283)-(73.475)-(45.39)-(-11.905)-(-55.874)-(-20.4)-(-17.928)-(11.072));
segmentsAcked = (int) (48.078-(-4.51)-(-70.891)-(27.975)-(41.204)-(-94.642)-(84.702));
CongestionAvoidance (tcb, segmentsAcked);
