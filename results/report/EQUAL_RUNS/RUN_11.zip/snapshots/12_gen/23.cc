tcb->m_cWnd = (int) (-84.09*(-66.689)*(58.544)*(-80.303)*(32.225));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (68.313*(-38.878)*(30.606));
tcb->m_cWnd = (int) (-49.32*(-15.541)*(63.468)*(-2.85)*(-59.033));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (1.626*(32.46)*(80.771));
CongestionAvoidance (tcb, segmentsAcked);
