tcb->m_cWnd = (int) (1.776*(-5.739)*(-27.459)*(-51.855)*(40.203));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-31.457*(71.843)*(-69.922));
CongestionAvoidance (tcb, segmentsAcked);
