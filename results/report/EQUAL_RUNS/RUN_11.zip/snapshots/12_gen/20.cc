tcb->m_cWnd = (int) (28.923*(-29.837)*(-95.941)*(-61.362)*(-10.21));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (12.442*(17.726)*(-41.447));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-7.078*(-93.567)*(88.3)*(-36.166)*(-7.285));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (71.848*(-39.856)*(7.95));
CongestionAvoidance (tcb, segmentsAcked);
