tcb->m_cWnd = (int) (50.937*(-18.74)*(-89.777)*(-27.177)*(46.816));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-40.633*(-27.988)*(-19.22));
CongestionAvoidance (tcb, segmentsAcked);
