segmentsAcked = (int) (3.763/-17.006);
float fsdWSTDVHclaQpMy = (float) (-56.439+(62.595));
segmentsAcked = (int) (-93.063/2.379);
float IoDdLDRoKPkrnYwu = (float) (-73.417/-97.311);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
