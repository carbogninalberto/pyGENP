tcb->m_ssThresh = (int) (13.846+(67.742)+(8.973)+(63.237)+(35.085)+(81.708));
segmentsAcked = (int) (72.742/8.779);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (tcb->m_cWnd-(31.673)-(51.739)-(75.728)-(95.331)-(9.058)-(17.794)-(76.014)-(77.594));
tcb->m_ssThresh = (int) (tcb->m_segmentSize*(36.42)*(26.81)*(50.683));
ReduceCwnd (tcb);
