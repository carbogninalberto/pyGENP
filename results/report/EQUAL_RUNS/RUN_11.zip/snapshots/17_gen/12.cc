float yCSWXMeqhVQlleTd = (float) (70.2*(96.6)*(-47.409)*(-66.878)*(34.042)*(-21.612));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (2.642+(68.382)+(95.366)+(40.475)+(93.345)+(56.762)+(-7.389));
if (tcb->m_segmentSize < segmentsAcked) {
	yCSWXMeqhVQlleTd = (float) (22.269+(66.983)+(48.59)+(tcb->m_segmentSize)+(20.861)+(88.066));

} else {
	yCSWXMeqhVQlleTd = (float) (77.453-(segmentsAcked)-(2.105)-(91.665)-(54.068)-(86.107)-(49.653)-(0.689));

}
