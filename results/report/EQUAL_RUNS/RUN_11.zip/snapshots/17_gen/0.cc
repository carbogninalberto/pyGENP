tcb->m_cWnd = (int) (54.036*(91.701)*(-41.986)*(42.52)*(61.59));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-99.402*(29.241)*(57.675));
CongestionAvoidance (tcb, segmentsAcked);
