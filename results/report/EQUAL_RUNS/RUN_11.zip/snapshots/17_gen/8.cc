ReduceCwnd (tcb);
tcb->m_cWnd = (int) ((68.182-(segmentsAcked)-(-37.309)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(68.664)-(tcb->m_ssThresh)-(4.272)-(54.449))/5.624);
segmentsAcked = (int) (3.426*(91.678)*(23.688)*(-96.871)*(55.777)*(93.835)*(48.064));
