tcb->m_cWnd = (int) (36.804*(-63.884)*(55.735)*(-1.411)*(57.095));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-88.57*(81.626)*(-94.244));
CongestionAvoidance (tcb, segmentsAcked);
