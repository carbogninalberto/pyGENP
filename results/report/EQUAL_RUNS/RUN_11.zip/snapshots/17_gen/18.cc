tcb->m_cWnd = (int) (-62.052*(-18.871)*(33.594)*(-11.848)*(-77.166));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (12.799*(-28.894)*(95.284));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
