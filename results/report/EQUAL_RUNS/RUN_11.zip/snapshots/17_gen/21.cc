segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((89.61-(segmentsAcked)-(-90.868)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(-66.45)-(tcb->m_ssThresh)-(-63.757)-(33.551))/83.116);
segmentsAcked = (int) (-42.257*(44.879)*(32.901)*(48.107)*(-11.531)*(53.547)*(20.162));
