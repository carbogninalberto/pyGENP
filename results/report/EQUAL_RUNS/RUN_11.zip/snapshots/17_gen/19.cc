tcb->m_cWnd = (int) (-53.288*(-28.068)*(46.929)*(-47.416)*(58.59));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (18.328*(35.055)*(1.122));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (5.975*(-89.699)*(96.994));
CongestionAvoidance (tcb, segmentsAcked);
