int EqXoUwSFnTyNmJUN = (int) (60.746*(79.539)*(-57.861)*(-56.763)*(21.77)*(51.061)*(-81.877));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (40.434+(44.268)+(46.322)+(4.028)+(49.905)+(63.797));

} else {
	tcb->m_cWnd = (int) (62.634*(50.972)*(84.305)*(50.316));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (11.558*(16.164)*(57.611)*(76.899)*(90.396)*(41.897)*(-44.326)*(87.379));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (40.434+(-22.781)+(46.322)+(4.028)+(49.905)+(63.797));

} else {
	tcb->m_cWnd = (int) (62.634*(50.972)*(84.305)*(50.316));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (11.558*(16.164)*(57.611)*(76.899)*(90.396)*(41.897)*(8.511)*(87.379));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
