float KprZIgEQZqVUpaSA = (float) (50.793-(-90.081));
tcb->m_cWnd = (int) (84.102-(-94.422)-(32.064)-(-62.422)-(79.304)-(-61.296)-(-48.837)-(-51.023));
if (segmentsAcked > tcb->m_segmentSize) {
	segmentsAcked = (int) (57.235+(92.337)+(39.777));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (47.996-(74.33)-(94.606));
	CongestionAvoidance (tcb, segmentsAcked);

}
KprZIgEQZqVUpaSA = (float) (-19.2-(-77.549)-(-82.834)-(-76.147)-(81.104)-(59.074));
tcb->m_cWnd = (int) ((-59.964+(8.002)+(segmentsAcked)+(-99.707))/-20.282);
ReduceCwnd (tcb);
