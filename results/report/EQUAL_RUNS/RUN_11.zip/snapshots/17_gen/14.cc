tcb->m_cWnd = (int) (71.531*(5.789)*(59.354)*(-28.132)*(-84.757));
tcb->m_cWnd = (int) (-56.462*(48.255)*(8.305)*(97.162)*(-86.833));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (79.495*(-68.187)*(-17.668));
tcb->m_cWnd = (int) (-60.087*(47.928)*(-12.395));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
