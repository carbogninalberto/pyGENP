int SLPSDfbweGUYsMpy = (int) 40.915;
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
