int PToLemeODXzEfoIR = (int) (66.056+(44.513)+(22.594)+(89.4)+(51.49)+(90.749)+(33.569)+(70.746)+(tcb->m_cWnd));
if (PToLemeODXzEfoIR <= tcb->m_ssThresh) {
	segmentsAcked = (int) (43.898-(-0.034)-(64.616)-(77.756));
	tcb->m_segmentSize = (int) (66.649+(23.58)+(27.167)+(64.07)+(38.586));

} else {
	segmentsAcked = (int) (48.353+(28.259)+(84.541)+(20.409)+(33.372)+(87.376)+(12.18));

}
if (PToLemeODXzEfoIR <= segmentsAcked) {
	tcb->m_cWnd = (int) (14.152*(tcb->m_cWnd)*(80.517)*(55.421)*(4.804)*(10.755)*(97.53));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(tcb->m_cWnd)-(94.557)-(20.969)-(1.884)-(65.636));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (40.646*(64.532)*(31.407)*(31.956)*(56.237)*(8.534)*(segmentsAcked)*(93.69));

}
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_cWnd = (int) (0.1/21.698);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (78.206*(tcb->m_ssThresh)*(47.274)*(68.138)*(tcb->m_segmentSize)*(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
if (PToLemeODXzEfoIR != segmentsAcked) {
	tcb->m_ssThresh = (int) (52.97*(8.157)*(tcb->m_segmentSize)*(12.841)*(48.401)*(89.85)*(41.288));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (47.295-(8.859)-(93.662)-(0.303)-(69.274));

} else {
	tcb->m_ssThresh = (int) (52.459*(tcb->m_ssThresh)*(47.937)*(76.938)*(35.221)*(90.331));
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) ((((96.951-(tcb->m_ssThresh)))+((55.114*(PToLemeODXzEfoIR)*(93.13)*(PToLemeODXzEfoIR)))+(22.623)+(23.393))/((46.499)));
	tcb->m_cWnd = (int) (5.707+(tcb->m_ssThresh)+(27.307)+(1.845)+(85.08)+(21.931)+(PToLemeODXzEfoIR));

} else {
	tcb->m_cWnd = (int) (11.457+(segmentsAcked)+(41.542)+(45.471));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (15.072*(3.302)*(40.29)*(6.561));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
