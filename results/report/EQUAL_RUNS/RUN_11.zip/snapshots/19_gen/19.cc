if (tcb->m_cWnd > tcb->m_cWnd) {
	segmentsAcked = (int) (98.894-(80.68)-(18.485)-(27.049));
	tcb->m_ssThresh = (int) (29.986*(segmentsAcked)*(65.706)*(69.025));

} else {
	segmentsAcked = (int) (((49.597)+(0.1)+((tcb->m_segmentSize+(59.169)+(35.005)))+(0.1)+(34.209))/((62.09)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (0.1/17.052);
tcb->m_cWnd = (int) (66.679-(66.429)-(90.437)-(segmentsAcked));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(88.961));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (72.299-(38.209)-(56.208)-(63.437)-(13.081));
	segmentsAcked = (int) (85.249-(92.276)-(tcb->m_segmentSize)-(82.452)-(25.248));
	tcb->m_segmentSize = (int) (63.717/0.1);

}
segmentsAcked = (int) (60.226+(75.721)+(91.646)+(78.56)+(55.5)+(1.916)+(94.601));
tcb->m_ssThresh = (int) (42.231+(74.818)+(13.193)+(66.086)+(73.645)+(33.529)+(75.58));
