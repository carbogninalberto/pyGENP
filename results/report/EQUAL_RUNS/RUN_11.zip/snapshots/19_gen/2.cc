int znWwdCHBxnTkLwHO = (int) 88.742;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((-7.612+(88.895)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(75.044)+(tcb->m_segmentSize)+(-24.778)+(24.557)+(-66.877))/62.548);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (78.029-(30.548)-(41.74)-(85.602));
	segmentsAcked = (int) (1.473-(31.946)-(77.488)-(71.778)-(56.565)-(62.712)-(32.74)-(13.804)-(-14.301));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	segmentsAcked = (int) (95.46-(85.725)-(45.942));

}
tcb->m_cWnd = (int) ((-36.292+(-77.615)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(-25.35)+(tcb->m_segmentSize)+(13.417)+(-73.811)+(-57.577))/-89.129);
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_cWnd = (int) (5.327-(42.747)-(78.06)-(13.692)-(5.638)-(tcb->m_segmentSize)-(20.732));
	znWwdCHBxnTkLwHO = (int) (18.773-(32.148)-(72.743)-(81.699)-(83.532)-(81.203)-(92.903)-(80.048));

} else {
	tcb->m_cWnd = (int) (46.975-(39.262)-(44.71)-(5.102)-(31.77));
	tcb->m_segmentSize = (int) (segmentsAcked-(70.448)-(66.553)-(58.291)-(79.893)-(8.157));
	znWwdCHBxnTkLwHO = (int) (74.291*(84.32));

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (78.029-(30.548)-(41.74)-(85.602));
	segmentsAcked = (int) (1.473-(31.946)-(77.488)-(71.778)-(-24.532)-(62.712)-(32.74)-(13.804)-(75.261));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	segmentsAcked = (int) (95.46-(85.725)-(-6.957));

}
