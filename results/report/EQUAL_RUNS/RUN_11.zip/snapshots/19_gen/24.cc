tcb->m_ssThresh = (int) (78.285*(25.38)*(segmentsAcked));
ReduceCwnd (tcb);
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_ssThresh = (int) (9.057-(segmentsAcked)-(64.495)-(6.991)-(segmentsAcked)-(42.159)-(52.22)-(18.591)-(61.922));
	segmentsAcked = (int) (48.396+(61.748)+(84.347)+(93.731)+(70.688)+(tcb->m_segmentSize)+(26.027));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(16.404)+(68.677)+(40.728)+(12.234)+(17.147)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(58.341));
	tcb->m_segmentSize = (int) (78.98*(tcb->m_cWnd)*(58.135)*(56.725));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (95.205-(85.446));
segmentsAcked = (int) (39.498+(82.299)+(5.512)+(8.718)+(74.703)+(40.076)+(19.378)+(segmentsAcked)+(69.22));
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(91.533)+(32.6)+(1.025)+(4.016)+(26.287)+(0.113)+(37.038));
