float gkBFjarFImStGGxc = (float) (83.678-(69.324)-(-99.654)-(-61.361)-(-6.538));
