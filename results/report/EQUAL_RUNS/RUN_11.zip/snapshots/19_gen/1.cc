int znWwdCHBxnTkLwHO = (int) 87.577;
tcb->m_cWnd = (int) ((88.659+(-97.265)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(4.6)+(tcb->m_segmentSize)+(11.921)+(-18.442)+(82.744))/41.849);
int gupjHUKbNbwbTTNz = (int) (88.96+(-99.493)+(-56.692)+(45.309)+(-39.563)+(13.424)+(40.338)+(-71.736)+(-45.923));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);
	segmentsAcked = (int) (95.46-(85.725)-(11.822));

} else {
	tcb->m_cWnd = (int) (78.029-(30.548)-(41.74)-(85.602));
	segmentsAcked = (int) (1.473-(31.946)-(77.488)-(71.778)-(59.744)-(62.712)-(32.74)-(13.804)-(54.371));

}
float XoovmCBOJbmjGAJS = (float) (30.697+(-99.482)+(96.902)+(36.107)+(-43.291)+(44.747));
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_cWnd = (int) (5.327-(42.747)-(78.06)-(13.692)-(5.638)-(tcb->m_segmentSize)-(20.732));
	znWwdCHBxnTkLwHO = (int) (18.773-(32.148)-(72.743)-(81.699)-(83.532)-(81.203)-(92.903)-(80.048));

} else {
	tcb->m_cWnd = (int) (46.975-(39.262)-(44.71)-(5.102)-(31.77));
	tcb->m_segmentSize = (int) (segmentsAcked-(70.448)-(66.553)-(58.291)-(79.893)-(8.157));
	znWwdCHBxnTkLwHO = (int) (74.291*(84.32));

}
