float vRuVZwJNbbiHeTMS = (float) (((0.1)+((30.943-(80.215)))+(59.924)+(31.898)+(0.1)+((86.077+(tcb->m_segmentSize)+(11.089)+(59.591)+(64.944)))+(0.1)+(0.1))/((0.1)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_cWnd = (int) (45.199+(3.794)+(92.498)+(30.153)+(4.442)+(72.589));
	segmentsAcked = (int) ((40.379*(85.502))/93.774);

} else {
	tcb->m_cWnd = (int) (74.89-(24.914)-(40.162)-(39.788));
	tcb->m_ssThresh = (int) (((0.1)+(22.641)+(60.158)+(0.1))/((0.1)+(97.402)+(0.1)+(0.1)));

}
if (vRuVZwJNbbiHeTMS > tcb->m_ssThresh) {
	vRuVZwJNbbiHeTMS = (float) (53.086*(71.907)*(tcb->m_cWnd)*(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (39.171-(97.219)-(55.816)-(4.144));

} else {
	vRuVZwJNbbiHeTMS = (float) ((tcb->m_cWnd-(51.348)-(75.854)-(83.122)-(87.79)-(44.484)-(47.85))/(tcb->m_cWnd+(24.692)+(85.851)+(19.352)+(vRuVZwJNbbiHeTMS)+(97.413)+(vRuVZwJNbbiHeTMS)));

}
tcb->m_ssThresh = (int) (59.794-(9.399)-(9.125)-(40.007)-(38.629));
tcb->m_cWnd = (int) (67.159+(49.647)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(87.751)+(tcb->m_ssThresh));
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (27.938+(17.501)+(53.815)+(tcb->m_ssThresh)+(14.833)+(92.278));

} else {
	tcb->m_cWnd = (int) (64.91/0.1);
	tcb->m_segmentSize = (int) (vRuVZwJNbbiHeTMS+(27.557));

}
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	vRuVZwJNbbiHeTMS = (float) (tcb->m_segmentSize-(90.002));
	segmentsAcked = (int) (50.9-(tcb->m_cWnd)-(18.207)-(55.739)-(56.51)-(66.403));

} else {
	vRuVZwJNbbiHeTMS = (float) (tcb->m_segmentSize+(76.171)+(2.072)+(32.565));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (segmentsAcked-(8.832)-(tcb->m_ssThresh));
