int sKBzMiSAPJynounP = (int) (-36.954+(-17.225)+(72.997)+(10.304)+(-81.82)+(-42.156)+(-74.193));
tcb->m_cWnd = (int) ((-36.865-(segmentsAcked)-(92.105)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(-54.271)-(tcb->m_ssThresh)-(-33.023)-(-8.336))/60.644);
