if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (79.102+(12.048)+(75.141)+(52.199)+(33.211)+(61.88)+(77.361)+(2.858)+(79.236));
	tcb->m_cWnd = (int) (43.788+(segmentsAcked)+(5.379)+(37.97)+(37.562)+(37.29));

} else {
	tcb->m_cWnd = (int) (((0.1)+(21.163)+(0.1)+(26.614)+((46.832*(tcb->m_segmentSize)*(44.444)*(tcb->m_ssThresh)*(44.298)*(26.996)))+(0.1))/((0.1)+(99.804)));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (94.412/0.1);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (85.231-(91.517));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (74.804+(39.168)+(58.122)+(79.908)+(segmentsAcked));
	segmentsAcked = (int) (segmentsAcked-(90.542)-(1.093)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (17.622+(67.044)+(3.977)+(tcb->m_cWnd)+(43.067)+(37.534));

}
segmentsAcked = (int) (95.029+(50.566)+(8.39)+(7.219)+(tcb->m_cWnd)+(84.493));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (11.993-(75.769)-(16.724)-(tcb->m_segmentSize));
