if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_segmentSize = (int) (49.757*(92.615)*(55.183)*(16.336)*(13.562)*(88.821));
	tcb->m_segmentSize = (int) (71.561+(segmentsAcked)+(26.622)+(78.31)+(segmentsAcked)+(46.657)+(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(8.294)+(94.677)+(tcb->m_cWnd)+(7.272)+(21.513)+(47.18)+(24.355));

}
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_cWnd*(79.71)*(tcb->m_segmentSize)*(61.311)*(51.219)*(46.945)*(80.782)*(2.851)*(68.011));
	segmentsAcked = (int) (tcb->m_segmentSize-(81.164)-(24.874)-(6.404)-(75.548)-(47.909)-(3.719)-(52.551)-(45.177));

} else {
	segmentsAcked = (int) (63.86-(19.58)-(46.694)-(89.582)-(72.682)-(16.34));

}
segmentsAcked = (int) (0.1/0.1);
tcb->m_cWnd = (int) (87.029*(57.207)*(tcb->m_segmentSize)*(84.932)*(36.343)*(55.083)*(37.92));
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(45.929)-(90.959)-(21.853)-(61.923));
	tcb->m_cWnd = (int) (89.395+(tcb->m_cWnd)+(40.32)+(49.385)+(84.058)+(75.272)+(28.637)+(65.15));

} else {
	tcb->m_segmentSize = (int) (14.385*(80.553)*(tcb->m_cWnd)*(54.653));
	ReduceCwnd (tcb);

}
