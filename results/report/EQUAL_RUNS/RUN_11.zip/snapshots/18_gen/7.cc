tcb->m_cWnd = (int) ((-34.694-(segmentsAcked)-(40.257)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(28.82)-(tcb->m_ssThresh)-(59.053)-(-71.454))/54.889);
int sKBzMiSAPJynounP = (int) (3.243+(-96.741)+(21.218)+(69.581)+(-76.01)+(67.373)+(61.883));
segmentsAcked = (int) (-8.401*(4.982)*(-66.987)*(-11.945)*(-7.669)*(-53.167)*(66.788));
