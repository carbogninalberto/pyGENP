tcb->m_cWnd = (int) (99.225*(51.549)*(60.168)*(-98.442)*(-68.021));
tcb->m_cWnd = (int) (-29.134*(-51.117)*(-6.534)*(66.589)*(-72.291));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (53.641*(-51.232)*(-20.17));
tcb->m_cWnd = (int) (97.918*(-41.11)*(92.183));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
