tcb->m_cWnd = (int) (85.965*(-31.714)*(-32.911)*(-32.463)*(69.65));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-18.752*(-72.027)*(62.856));
CongestionAvoidance (tcb, segmentsAcked);
