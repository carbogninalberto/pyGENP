segmentsAcked = (int) (79.542/-44.737);
