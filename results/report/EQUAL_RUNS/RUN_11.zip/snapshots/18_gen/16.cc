tcb->m_segmentSize = (int) (17.576-(97.99)-(tcb->m_cWnd)-(85.29)-(63.841));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_cWnd+(19.28)+(99.558)+(tcb->m_cWnd)+(82.903)+(66.945)+(tcb->m_ssThresh)+(38.845));
tcb->m_segmentSize = (int) (20.176+(73.359)+(86.973)+(93.607)+(segmentsAcked)+(17.958)+(99.709));
tcb->m_ssThresh = (int) ((91.713*(tcb->m_segmentSize)*(92.659)*(74.65)*(24.179))/71.702);
