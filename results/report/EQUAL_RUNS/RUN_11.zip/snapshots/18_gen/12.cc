tcb->m_segmentSize = (int) (-66.616+(30.692)+(80.703)+(-97.611)+(-53.664)+(-30.063)+(-3.232));
tcb->m_cWnd = (int) ((-55.066-(segmentsAcked)-(-2.263)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(-16.52)-(tcb->m_ssThresh)-(50.548)-(66.743))/77.749);
segmentsAcked = (int) (-68.508*(70.701)*(27.019)*(-25.679)*(-13.63)*(-3.434)*(94.444));
tcb->m_cWnd = (int) ((67.357-(segmentsAcked)-(-22.11)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(-96.887)-(tcb->m_ssThresh)-(-60.507)-(-66.73))/36.208);
segmentsAcked = (int) (83.906*(-13.883)*(66.4)*(85.392)*(-37.723)*(-65.179)*(-38.559));
