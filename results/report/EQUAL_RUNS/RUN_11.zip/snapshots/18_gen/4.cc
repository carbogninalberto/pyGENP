if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((71.665)+(0.1)+(0.1)+(0.1))/((0.1)+(33.719)+(0.1)+(76.116)));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(80.101)-(85.587)-(55.001)-(92.971));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) ((50.926-(segmentsAcked)-(35.175)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(-90.4)-(tcb->m_ssThresh)-(-1.581)-(86.356))/-27.617);
