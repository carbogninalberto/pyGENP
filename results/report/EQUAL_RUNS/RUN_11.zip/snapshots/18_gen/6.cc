int AWmlRBjQJaGIZrsh = (int) (35.097/79.505);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (6.496+(1.459)+(81.228)+(-28.01)+(-19.868)+(99.567)+(-62.29));
segmentsAcked = (int) (35.305-(-4.016));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
