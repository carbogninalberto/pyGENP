segmentsAcked = (int) (33.301-(9.148)-(66.986)-(-49.688)-(-64.447)-(-18.534)-(72.045));
tcb->m_cWnd = (int) ((18.574-(segmentsAcked)-(-55.76)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(86.987)-(tcb->m_ssThresh)-(-22.295)-(4.355))/-9.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-29.47*(87.057)*(44.423)*(97.529)*(-13.362)*(87.355)*(-69.679));
tcb->m_cWnd = (int) ((-55.74-(segmentsAcked)-(44.826)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(-30.581)-(tcb->m_ssThresh)-(91.846)-(24.403))/-90.316);
segmentsAcked = (int) (88.003*(4.429)*(33.773)*(42.023)*(-4.951)*(-75.479)*(23.16));
