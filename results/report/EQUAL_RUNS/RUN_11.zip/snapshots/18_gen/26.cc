int FwhijzGuSlCNMfWn = (int) (52.046+(43.003)+(55.664)+(96.69)+(60.114)+(25.111)+(75.745)+(73.407));
segmentsAcked = (int) (69.797-(75.303)-(29.29)-(tcb->m_cWnd)-(4.158)-(71.266)-(81.282));
if (FwhijzGuSlCNMfWn >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/28.571);

} else {
	tcb->m_cWnd = (int) (99.265+(50.012)+(89.851)+(40.089));
	tcb->m_ssThresh = (int) (24.109-(81.213));

}
ReduceCwnd (tcb);
if (FwhijzGuSlCNMfWn >= segmentsAcked) {
	FwhijzGuSlCNMfWn = (int) (((0.1)+(0.1)+(92.693)+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));

} else {
	FwhijzGuSlCNMfWn = (int) (14.743+(16.196)+(1.488));
	tcb->m_cWnd = (int) (((0.1)+((38.304*(62.942)))+(89.57)+(0.1))/((0.1)+(43.998)+(6.479)+(0.1)+(0.1)));

}
