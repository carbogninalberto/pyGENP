tcb->m_cWnd = (int) (((44.999)+(15.375)+((65.625+(tcb->m_cWnd)+(33.432)+(80.705)+(64.191)+(94.9)+(9.23)+(22.907)+(97.838)))+(12.195))/((68.285)+(43.221)+(0.1)));
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(89.705));
int GRypbBkxGhxnjcqY = (int) (29.202+(11.83)+(10.085)+(78.343)+(10.273)+(41.353)+(66.58)+(60.218)+(83.165));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(tcb->m_cWnd)-(92.856));
GRypbBkxGhxnjcqY = (int) (tcb->m_cWnd-(45.098)-(11.728)-(segmentsAcked));
segmentsAcked = SlowStart (tcb, segmentsAcked);
