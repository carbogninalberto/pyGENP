if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (51.35*(52.275)*(tcb->m_segmentSize)*(47.273)*(29.588)*(30.886)*(tcb->m_ssThresh));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (47.012-(32.616)-(78.121)-(10.495)-(56.359));

}
tcb->m_cWnd = (int) ((segmentsAcked-(28.489)-(45.894))/0.1);
segmentsAcked = (int) (94.384-(39.227)-(80.24)-(60.982)-(tcb->m_ssThresh)-(91.764)-(segmentsAcked)-(tcb->m_cWnd)-(96.249));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.913*(tcb->m_ssThresh)*(78.142)*(10.471)*(11.721));

} else {
	tcb->m_cWnd = (int) (77.01*(tcb->m_segmentSize)*(33.226)*(tcb->m_ssThresh)*(68.475));
	tcb->m_ssThresh = (int) (0.1/45.84);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (((8.529)+(75.667)+((35.942*(88.294)*(76.698)*(91.623)*(69.775)*(21.754)))+(24.146)+(56.545)+((66.325-(94.282)-(tcb->m_cWnd)))+(0.1))/((91.89)+(0.1)));
