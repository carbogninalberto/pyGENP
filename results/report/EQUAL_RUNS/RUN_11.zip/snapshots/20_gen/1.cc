float XoovmCBOJbmjGAJS = (float) (-26.894+(-66.437)+(17.326)+(-55.087)+(-33.077)+(-80.747));
int gupjHUKbNbwbTTNz = (int) (69.792+(-74.258)+(2.308)+(-88.8)+(59.496)+(-21.284)+(97.226)+(73.173)+(28.167));
int znWwdCHBxnTkLwHO = (int) 49.91;
tcb->m_cWnd = (int) ((-59.948+(-73.397)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(-60.87)+(tcb->m_segmentSize)+(72.238)+(22.977)+(-87.188))/20.299);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (78.029-(30.548)-(41.74)-(85.602));
	segmentsAcked = (int) (1.473-(31.946)-(77.488)-(71.778)-(59.744)-(62.712)-(32.74)-(13.804)-(54.371));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	segmentsAcked = (int) (95.46-(85.725)-(11.822));

}
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_cWnd = (int) (5.327-(42.747)-(78.06)-(13.692)-(5.638)-(tcb->m_segmentSize)-(20.732));
	znWwdCHBxnTkLwHO = (int) (18.773-(32.148)-(72.743)-(81.699)-(83.532)-(81.203)-(92.903)-(80.048));

} else {
	tcb->m_cWnd = (int) (46.975-(39.262)-(44.71)-(5.102)-(31.77));
	tcb->m_segmentSize = (int) (segmentsAcked-(70.448)-(66.553)-(58.291)-(79.893)-(8.157));
	znWwdCHBxnTkLwHO = (int) (74.291*(84.32));

}
