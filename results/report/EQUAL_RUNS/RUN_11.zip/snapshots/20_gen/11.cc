tcb->m_segmentSize = (int) ((((-23.928+(-67.463)+(85.186)+(-52.293)+(-52.083)+(-78.24)+(3.937)))+(-82.315)+(-5.991)+(-89.263))/((44.038)+(55.02)+(74.415)+(-57.1)+(57.596)));
int PToLemeODXzEfoIR = (int) 13.441;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
