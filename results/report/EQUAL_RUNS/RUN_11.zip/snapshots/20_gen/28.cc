segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (10.372-(45.14)-(76.748)-(17.467)-(tcb->m_cWnd)-(69.18)-(96.265)-(12.734)-(tcb->m_cWnd));
float QHfhIHBLgglTiWhu = (float) (26.092*(62.059)*(14.365)*(38.336)*(22.436)*(59.512)*(44.475)*(tcb->m_cWnd));
if (tcb->m_ssThresh != QHfhIHBLgglTiWhu) {
	tcb->m_ssThresh = (int) (78.921-(0.655)-(39.365)-(14.433));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(87.755)-(31.187)-(33.95)-(48.779)-(98.209)-(25.718)-(74.373)-(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (45.708-(39.362)-(11.739)-(QHfhIHBLgglTiWhu));
	tcb->m_cWnd = (int) (68.803*(1.865)*(71.654)*(3.113)*(9.578)*(0.576)*(22.993)*(tcb->m_ssThresh)*(tcb->m_segmentSize));

}
QHfhIHBLgglTiWhu = (float) (21.961+(83.92)+(20.914)+(56.111)+(67.012));
ReduceCwnd (tcb);
