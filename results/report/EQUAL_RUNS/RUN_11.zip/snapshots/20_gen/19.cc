tcb->m_segmentSize = (int) (0.1/7.2);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (14.074/0.1);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(79.643)*(segmentsAcked)*(38.091)*(12.073)*(66.208)*(78.59)*(47.866)*(77.443));
	tcb->m_ssThresh = (int) (27.263+(69.733)+(74.037)+(tcb->m_segmentSize)+(segmentsAcked)+(6.505)+(11.528)+(tcb->m_segmentSize)+(85.782));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (35.097+(53.966)+(52.578)+(32.522));

}
ReduceCwnd (tcb);
