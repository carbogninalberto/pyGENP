tcb->m_cWnd = (int) (-52.929*(93.583)*(-54.97)*(-14.277)*(63.798));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-72.978*(25.144)*(32.457));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
