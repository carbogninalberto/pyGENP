tcb->m_cWnd = (int) (76.02*(20.017)*(25.629)*(78.512)*(99.984));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-87.805*(42.095)*(-29.853));
CongestionAvoidance (tcb, segmentsAcked);
