int EqdFrkNBiNmNltIX = (int) (7.709/0.1);
int wwOlAmJJjlklGCpz = (int) (0.1/47.146);
segmentsAcked = (int) (((0.1)+(0.1)+(15.247)+((93.291+(69.661)+(23.519)+(25.997)+(73.603)+(38.848)+(9.854)+(segmentsAcked)))+(77.808))/((0.1)+(59.321)));
ReduceCwnd (tcb);
if (tcb->m_cWnd <= segmentsAcked) {
	EqdFrkNBiNmNltIX = (int) (0.1/0.1);

} else {
	EqdFrkNBiNmNltIX = (int) (((55.914)+(85.412)+(0.1)+((53.25-(wwOlAmJJjlklGCpz)-(64.601)-(32.603)-(wwOlAmJJjlklGCpz)-(tcb->m_ssThresh)-(EqdFrkNBiNmNltIX)-(48.118)-(81.868)))+(0.1)+(39.705))/((0.1)+(39.25)));
	wwOlAmJJjlklGCpz = (int) (39.163+(tcb->m_ssThresh)+(59.95)+(17.927)+(70.485)+(95.021)+(49.476));

}
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	wwOlAmJJjlklGCpz = (int) (segmentsAcked*(79.727)*(wwOlAmJJjlklGCpz)*(15.524));

} else {
	wwOlAmJJjlklGCpz = (int) (15.954-(tcb->m_cWnd));
	ReduceCwnd (tcb);

}
if (segmentsAcked >= EqdFrkNBiNmNltIX) {
	segmentsAcked = (int) (0.1/55.032);
	segmentsAcked = (int) (tcb->m_cWnd+(22.308)+(67.547)+(tcb->m_ssThresh)+(99.954)+(75.838)+(93.745)+(EqdFrkNBiNmNltIX)+(66.957));

} else {
	segmentsAcked = (int) (97.767*(17.584)*(tcb->m_cWnd)*(92.751));
	tcb->m_segmentSize = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (wwOlAmJJjlklGCpz >= segmentsAcked) {
	EqdFrkNBiNmNltIX = (int) (83.326+(67.719));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	EqdFrkNBiNmNltIX = (int) (30.11-(tcb->m_ssThresh)-(30.125)-(17.139)-(36.757)-(13.406)-(wwOlAmJJjlklGCpz));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (37.414*(35.631));

}
if (EqdFrkNBiNmNltIX < segmentsAcked) {
	tcb->m_cWnd = (int) (0.1/80.521);
	segmentsAcked = (int) (tcb->m_ssThresh-(86.696)-(64.635)-(17.404)-(6.123)-(18.263)-(28.022)-(29.571));
	tcb->m_cWnd = (int) (0.1/54.516);

} else {
	tcb->m_cWnd = (int) (((62.25)+(98.809)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(53.65)+(0.1)));

}
