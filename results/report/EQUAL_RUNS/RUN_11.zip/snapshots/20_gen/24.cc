int mfRdptpkCAlGLdGb = (int) (10.198*(60.68)*(62.907));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (47.276-(69.073)-(42.985)-(3.576));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (15.92-(14.395));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
mfRdptpkCAlGLdGb = (int) (56.012+(segmentsAcked)+(7.789));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (mfRdptpkCAlGLdGb > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (66.857-(30.226)-(26.702)-(segmentsAcked)-(79.468));

} else {
	tcb->m_segmentSize = (int) (10.564*(42.242)*(75.318));
	segmentsAcked = (int) (11.59+(78.718)+(19.002)+(40.734)+(98.548)+(34.575)+(80.766)+(57.418));

}
