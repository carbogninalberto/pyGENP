float yttsbYMpayfTzjQu = (float) (-41.079/(-40.139*(-49.684)*(56.705)*(-52.307)*(-92.699)*(-93.715)*(-8.112)*(10.995)*(72.402)));
int AUQpFDqlFnvjRRXp = (int) (96.441-(72.169)-(30.587));
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (5.48+(30.16)+(14.911)+(44.266)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) ((4.527+(91.31)+(26.58)+(yttsbYMpayfTzjQu)+(43.334)+(70.43)+(5.136)+(75.332)+(tcb->m_cWnd))/0.1);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (87.386*(37.176)*(92.784)*(96.447)*(-73.919)*(13.753)*(-83.365)*(94.426));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
