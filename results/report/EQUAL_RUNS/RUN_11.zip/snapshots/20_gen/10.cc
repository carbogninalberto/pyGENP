float awARmXzVxeBtpQcS = (float) 52.604;
float JkSYIvZMGLvyqTQP = (float) 54.561;
