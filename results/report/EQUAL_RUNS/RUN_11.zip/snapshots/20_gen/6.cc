TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int PToLemeODXzEfoIR = (int) 91.706;
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
