CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (61.088*(84.803)*(42.124)*(tcb->m_cWnd)*(tcb->m_cWnd)*(98.667)*(33.06)*(16.884));
tcb->m_ssThresh = (int) (71.111*(60.804)*(4.596)*(41.551)*(96.05));
ReduceCwnd (tcb);
float QezpXjyypIaQbcMW = (float) (37.255-(84.012));
