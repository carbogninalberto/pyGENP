float yttsbYMpayfTzjQu = (float) (44.161/(20.917*(49.424)*(-31.779)*(-10.62)*(-63.051)*(-97.61)*(-45.934)*(-15.302)*(-2.834)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
int AUQpFDqlFnvjRRXp = (int) 98.248;
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (5.48+(30.16)+(14.911)+(44.266)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) ((4.527+(91.31)+(26.58)+(yttsbYMpayfTzjQu)+(43.334)+(70.43)+(5.136)+(75.332)+(tcb->m_cWnd))/0.1);

}
AUQpFDqlFnvjRRXp = (int) (-81.829*(-48.698)*(-78.304)*(-66.024));
segmentsAcked = (int) (23.959*(-99.236)*(-30.794)*(-92.366)*(-87.789)*(-5.297)*(66.344)*(30.457));
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (5.48+(30.16)+(14.911)+(44.266)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) ((4.527+(91.31)+(26.58)+(yttsbYMpayfTzjQu)+(43.334)+(70.43)+(5.136)+(75.332)+(tcb->m_cWnd))/0.1);

}
segmentsAcked = (int) (-87.299*(15.476)*(-75.047)*(90.786)*(43.184)*(16.773)*(-22.98)*(28.294));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
