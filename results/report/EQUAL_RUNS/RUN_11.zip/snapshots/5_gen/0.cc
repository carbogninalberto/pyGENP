tcb->m_cWnd = (int) (-6.353*(-55.757)*(-61.1)*(37.967)*(-97.936));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-86.594*(-26.355)*(-53.619));
CongestionAvoidance (tcb, segmentsAcked);
