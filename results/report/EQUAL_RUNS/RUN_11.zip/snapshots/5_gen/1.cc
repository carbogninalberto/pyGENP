CongestionAvoidance (tcb, segmentsAcked);
float LWavpPXccFoBIZiy = (float) (((77.95)+((-33.431-(21.028)-(-87.099)-(47.318)-(-2.8)-(32.579)))+(-3.687)+(93.006)+(36.938)+(68.796)+(-98.995))/((53.107)+(-1.323)));
CongestionAvoidance (tcb, segmentsAcked);
