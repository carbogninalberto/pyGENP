tcb->m_cWnd = (int) (33.005*(-2.79)*(45.744)*(54.887)*(38.211));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-70.92*(18.979)*(7.266));
CongestionAvoidance (tcb, segmentsAcked);
