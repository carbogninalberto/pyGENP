tcb->m_cWnd = (int) (-19.767*(-32.096)*(87.695)*(-6.499)*(62.462));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-34.901*(22.473)*(92.528));
CongestionAvoidance (tcb, segmentsAcked);
