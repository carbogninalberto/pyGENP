if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (78.213*(99.87)*(tcb->m_cWnd)*(57.42)*(tcb->m_ssThresh));
	segmentsAcked = (int) (tcb->m_segmentSize+(56.067)+(42.38)+(50.597)+(50.882)+(segmentsAcked)+(79.031)+(88.152));
	tcb->m_segmentSize = (int) (75.853-(segmentsAcked)-(15.33)-(segmentsAcked)-(68.794)-(54.73)-(18.56)-(71.474));

} else {
	tcb->m_ssThresh = (int) (84.659-(66.051)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (60.346+(16.636));
	segmentsAcked = (int) (tcb->m_cWnd*(4.925)*(9.652)*(36.954)*(52.155)*(segmentsAcked)*(85.732)*(65.537)*(81.645));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(11.244)+(68.648)+(97.717)+(tcb->m_cWnd)+(46.892)+(tcb->m_segmentSize));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (25.56-(27.38)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (((56.259)+(7.713)+(0.1)+(0.1)+(0.1))/((0.1)+(95.48)+(38.434)));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (segmentsAcked-(tcb->m_ssThresh));
tcb->m_cWnd = (int) (16.564*(97.175)*(31.853)*(65.071)*(segmentsAcked)*(41.145)*(86.095));
tcb->m_cWnd = (int) (39.379-(71.583)-(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (28.048+(65.015));
