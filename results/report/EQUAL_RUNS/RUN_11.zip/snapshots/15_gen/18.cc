if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (21.187+(27.786)+(4.542)+(87.512)+(17.027)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(79.288)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(95.592)-(94.437));

}
tcb->m_ssThresh = (int) (2.274*(40.485)*(25.662)*(5.307)*(87.767)*(98.009)*(76.24));
tcb->m_segmentSize = (int) (37.578/0.1);
segmentsAcked = (int) (tcb->m_ssThresh*(45.292));
segmentsAcked = (int) (33.87+(76.361)+(8.279));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((64.222)+(0.1)+(34.169)+((98.292+(19.273)))+(0.1)+(70.176))/((0.1)));
	tcb->m_ssThresh = (int) (18.826+(53.237)+(20.345)+(93.174)+(95.081)+(21.758));

} else {
	tcb->m_cWnd = (int) (71.996-(segmentsAcked)-(40.247)-(81.775)-(0.769)-(30.861));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(18.08)-(60.295)-(81.335)-(segmentsAcked));
	segmentsAcked = (int) (51.868*(86.956)*(70.136));

}
