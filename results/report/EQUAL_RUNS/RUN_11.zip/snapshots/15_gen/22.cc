if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (91.808/0.1);
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (76.486-(35.526)-(39.71)-(87.828));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(80.934)*(4.224)*(56.046));
	tcb->m_ssThresh = (int) (90.974*(60.961)*(17.116)*(43.803)*(17.579)*(4.165)*(4.532)*(69.218));
	tcb->m_ssThresh = (int) (15.255+(59.834)+(segmentsAcked)+(48.711)+(76.068));

}
if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((38.961)+(0.1)+(0.1)+(34.076))/((0.1)+(44.294)+(85.073)+(77.889)));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked+(59.758)+(73.536)+(4.839)+(85.832)+(12.708));

}
segmentsAcked = (int) (8.828+(68.78)+(57.32)+(tcb->m_ssThresh)+(77.279)+(71.089));
segmentsAcked = (int) (87.83+(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (tcb->m_ssThresh*(51.643)*(tcb->m_cWnd)*(92.716)*(52.892));
