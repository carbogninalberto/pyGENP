tcb->m_cWnd = (int) (((-6.149)+(-99.183)+(44.631)+(-32.267))/((-84.438)+(-92.966)));
tcb->m_cWnd = (int) (-4.581*(13.998)*(-1.156)*(45.049));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (90.973*(81.794)*(62.134));

} else {
	segmentsAcked = (int) (segmentsAcked-(tcb->m_segmentSize)-(39.468));
	tcb->m_cWnd = (int) (27.834+(14.463)+(96.941)+(68.161)+(99.523)+(85.171)+(94.143));
	CongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
