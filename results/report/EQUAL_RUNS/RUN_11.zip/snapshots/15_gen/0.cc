tcb->m_cWnd = (int) (-19.963*(-28.522)*(-79.465)*(-17.504)*(66.594));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-56.848*(-47.921)*(-77.936));
CongestionAvoidance (tcb, segmentsAcked);
