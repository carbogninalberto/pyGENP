if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (((74.148)+(0.1)+(57.364)+(63.479))/((74.096)));

}
segmentsAcked = (int) (14.932-(93.071)-(93.605));
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) ((58.446-(tcb->m_ssThresh))/0.1);

} else {
	tcb->m_segmentSize = (int) (32.078-(87.476)-(72.43));
	tcb->m_cWnd = (int) (segmentsAcked-(95.09)-(93.682));
	tcb->m_segmentSize = (int) (76.217+(67.755));

}
if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (36.641+(32.093));

} else {
	segmentsAcked = (int) (95.972*(55.852)*(6.97)*(43.046));

}
tcb->m_segmentSize = (int) (39.914-(tcb->m_ssThresh)-(segmentsAcked)-(64.524)-(35.296)-(16.337)-(88.646));
tcb->m_segmentSize = (int) (37.453-(81.645)-(32.159)-(65.197)-(86.306)-(62.765)-(43.179));
tcb->m_segmentSize = (int) (((76.639)+(0.1)+(0.1)+(0.1)+(67.926))/((0.1)+(0.1)));
ReduceCwnd (tcb);
