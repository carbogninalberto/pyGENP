if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) ((((75.828+(67.57)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(89.836)+(37.233)+(10.485)))+(81.973)+(0.1)+((tcb->m_ssThresh-(75.171)-(6.254)-(87.386)-(60.857)-(37.47)-(42.413)-(94.938)))+(48.291))/((0.1)+(85.222)));
	tcb->m_ssThresh = (int) (20.458+(28.948)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(54.301)+(tcb->m_ssThresh)+(11.658)+(40.241));

} else {
	tcb->m_cWnd = (int) (51.458+(36.652)+(76.761)+(64.272)+(62.006)+(94.394)+(14.213));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (0.1/0.1);

}
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (94.521-(41.757));

} else {
	tcb->m_ssThresh = (int) (((19.077)+((58.84-(tcb->m_segmentSize)-(24.532)-(53.667)-(45.349)-(81.341)-(95.43)-(14.041)))+(0.1)+(0.1)+(15.813))/((0.1)));
	tcb->m_cWnd = (int) (91.165*(62.05)*(segmentsAcked)*(78.474)*(25.714)*(35.826));
	tcb->m_ssThresh = (int) (segmentsAcked*(91.749)*(5.298)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(60.111)*(45.025));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (12.269-(72.009)-(96.973));
float mIbHIMXeifbUcoUF = (float) (((35.147)+((tcb->m_cWnd+(tcb->m_cWnd)+(tcb->m_segmentSize)+(segmentsAcked)+(segmentsAcked)+(83.596)+(21.869)))+(83.445)+(0.1)+(0.1)+(0.1)+(8.342)+(0.1))/((0.1)));
if (mIbHIMXeifbUcoUF >= tcb->m_cWnd) {
	segmentsAcked = (int) (73.785-(36.497));

} else {
	segmentsAcked = (int) (((24.724)+(0.1)+(0.1)+(0.1)+(59.734)+(0.1)+(0.1)+(90.905))/((65.877)));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (54.903-(48.029)-(56.336)-(7.635)-(7.403));
mIbHIMXeifbUcoUF = (float) (((0.1)+(97.015)+(0.1)+(89.659)+(0.1))/((93.92)));
