segmentsAcked = (int) (18.044-(83.212)-(96.748));
if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (36.641+(32.093));

} else {
	segmentsAcked = (int) (95.972*(55.852)*(6.97)*(43.046));

}
tcb->m_segmentSize = (int) (49.922-(71.019)-(87.602)-(-27.775)-(-88.785)-(98.287)-(62.697));
tcb->m_segmentSize = (int) (-30.317-(-42.777)-(-0.944)-(-11.041)-(69.207)-(40.362)-(15.554));
tcb->m_segmentSize = (int) (((94.17)+(84.141)+(-37.995)+(51.036)+(59.859))/((-20.113)+(60.397)));
ReduceCwnd (tcb);
