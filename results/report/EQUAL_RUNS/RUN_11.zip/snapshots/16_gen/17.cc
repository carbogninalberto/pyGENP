if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((73.161)+((95.051*(41.548)*(65.323)*(segmentsAcked)*(26.024)*(4.472)*(tcb->m_cWnd)*(98.108)*(58.907)))+(7.415)+(70.067))/((0.1)+(70.541)+(0.1)));
	tcb->m_ssThresh = (int) (segmentsAcked+(tcb->m_segmentSize)+(2.615)+(tcb->m_segmentSize)+(76.676)+(0.488)+(65.842)+(59.747)+(83.766));

} else {
	tcb->m_ssThresh = (int) (85.248+(32.183)+(6.327)+(9.229)+(tcb->m_segmentSize)+(90.969)+(74.863));

}
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(24.935)-(72.159)-(tcb->m_ssThresh)-(2.475)-(29.027)-(36.13)-(84.62)-(30.518));

} else {
	tcb->m_ssThresh = (int) (18.472+(tcb->m_ssThresh)+(66.096)+(11.356)+(66.132));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (40.434+(tcb->m_ssThresh)+(46.322)+(4.028)+(49.905)+(63.797));

} else {
	tcb->m_cWnd = (int) (62.634*(50.972)*(84.305)*(50.316));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (11.558*(16.164)*(57.611)*(76.899)*(90.396)*(41.897)*(tcb->m_ssThresh)*(87.379));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
