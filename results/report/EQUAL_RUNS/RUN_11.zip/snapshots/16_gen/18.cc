tcb->m_cWnd = (int) (65.388+(70.93)+(29.497)+(95.762));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (18.431+(58.685)+(47.682)+(68.01));

} else {
	tcb->m_segmentSize = (int) (89.706-(43.094)-(22.032));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
int aUlftkUKhDFuDFjf = (int) (45.135+(37.889)+(1.256)+(47.276)+(17.669)+(10.814));
