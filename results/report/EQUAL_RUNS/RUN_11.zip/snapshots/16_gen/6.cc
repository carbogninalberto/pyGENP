float tYLSxlXyJQOJObvk = (float) (83.88/-27.191);
int SLPSDfbweGUYsMpy = (int) 40.915;
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
