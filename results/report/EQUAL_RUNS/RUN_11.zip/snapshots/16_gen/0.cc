tcb->m_cWnd = (int) (35.362*(-52.554)*(51.769)*(78.351)*(55.228));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-75.102*(-15.043)*(57.284));
CongestionAvoidance (tcb, segmentsAcked);
