segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (42.069*(55.164)*(57.81)*(41.49)*(13.568)*(65.467)*(85.435)*(20.938)*(77.917));
tcb->m_cWnd = (int) ((15.097-(segmentsAcked)-(94.395)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(83.594)-(tcb->m_ssThresh)-(72.824)-(35.299))/59.222);
segmentsAcked = (int) (23.384*(53.81)*(8.01)*(64.42)*(3.971)*(95.284)*(10.87));
tcb->m_ssThresh = (int) ((52.49*(38.7)*(11.084)*(65.296)*(19.636))/0.1);
