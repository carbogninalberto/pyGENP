float XGvtVKdevTNVVpyo = (float) 23.577;
tcb->m_cWnd = (int) (-7.483*(-56.053)*(-58.819)*(68.456)*(87.033)*(-47.515));
