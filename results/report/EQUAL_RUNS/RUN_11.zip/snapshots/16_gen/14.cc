float IoDdLDRoKPkrnYwu = (float) (-22.809/30.102);
float fsdWSTDVHclaQpMy = (float) (97.654+(33.307));
segmentsAcked = (int) (-57.72/-87.18);
segmentsAcked = (int) (3.412/-95.472);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
