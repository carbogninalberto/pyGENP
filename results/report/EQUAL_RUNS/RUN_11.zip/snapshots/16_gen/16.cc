ReduceCwnd (tcb);
tcb->m_cWnd = (int) (96.401+(40.998)+(52.434)+(68.635));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (89.555+(41.865)+(62.016)+(tcb->m_ssThresh)+(66.34)+(99.678)+(92.907));

} else {
	tcb->m_ssThresh = (int) (9.784/0.1);
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(43.133)*(tcb->m_ssThresh));

}
tcb->m_ssThresh = (int) (83.45+(18.158)+(3.104));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.962+(20.778));

} else {
	tcb->m_cWnd = (int) (94.223*(64.994)*(66.52)*(75.714));
	tcb->m_cWnd = (int) ((((57.654*(tcb->m_ssThresh)*(20.425)*(18.298)*(tcb->m_segmentSize)*(72.802)))+((95.485*(77.792)*(21.569)))+(0.1)+(49.241)+((37.058-(56.205)-(34.557)-(49.418)-(segmentsAcked)-(tcb->m_cWnd)-(38.944)-(68.206)))+(0.1))/((0.1)));
	tcb->m_segmentSize = (int) (60.604-(45.736)-(90.009));

}
segmentsAcked = (int) (70.885+(tcb->m_ssThresh)+(93.44)+(47.087)+(40.087));
