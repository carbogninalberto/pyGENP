TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (78.99-(1.994)-(37.272)-(tcb->m_segmentSize)-(34.168)-(62.748));
tcb->m_segmentSize = (int) (15.625-(5.193));
segmentsAcked = (int) (98.273-(2.508)-(2.924)-(segmentsAcked)-(74.495)-(tcb->m_ssThresh)-(43.942)-(90.396));
segmentsAcked = (int) (0.1/49.646);
tcb->m_segmentSize = (int) (32.335-(15.926)-(75.868)-(7.849));
