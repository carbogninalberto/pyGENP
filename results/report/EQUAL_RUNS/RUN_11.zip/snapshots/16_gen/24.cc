tcb->m_cWnd = (int) (56.369+(46.241)+(68.179)+(59.929)+(20.145)+(25.029)+(34.611));
ReduceCwnd (tcb);
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (61.68/20.502);

} else {
	tcb->m_segmentSize = (int) (80.283+(85.776)+(37.624)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(52.914));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (0.1/38.307);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (74.963+(46.947));

} else {
	tcb->m_cWnd = (int) (1.575-(3.796)-(54.672)-(16.266)-(78.284));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
