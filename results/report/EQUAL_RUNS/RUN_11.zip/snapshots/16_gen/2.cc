tcb->m_cWnd = (int) (80.321*(53.443)*(-36.85)*(76.511)*(28.875));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (55.728*(11.377)*(20.264));
CongestionAvoidance (tcb, segmentsAcked);
