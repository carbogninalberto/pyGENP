ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((0.1)+(0.1)+((74.644+(43.583)+(segmentsAcked)+(7.324)+(tcb->m_cWnd)+(70.424)+(segmentsAcked)+(95.341)+(63.815)))+(0.1)+((tcb->m_segmentSize-(57.217)))+(0.1))/((29.439)+(0.1)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (98.78+(29.05)+(78.393)+(tcb->m_ssThresh)+(94.828)+(tcb->m_cWnd)+(84.641));
	segmentsAcked = (int) (tcb->m_cWnd*(89.72)*(tcb->m_segmentSize)*(72.224)*(30.833)*(20.265));
	tcb->m_cWnd = (int) (71.33*(tcb->m_segmentSize)*(43.875)*(tcb->m_cWnd)*(92.984)*(86.747)*(tcb->m_cWnd)*(64.107)*(42.913));

} else {
	tcb->m_cWnd = (int) (49.199+(0.371)+(79.56));
	tcb->m_ssThresh = (int) (98.767-(46.33)-(36.314)-(tcb->m_segmentSize)-(7.929)-(48.873)-(62.339)-(tcb->m_segmentSize)-(91.795));

}
tcb->m_segmentSize = (int) (55.553-(88.009)-(55.853)-(segmentsAcked)-(3.186)-(45.061)-(8.566));
