if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (97.836*(69.728)*(96.155)*(40.446)*(tcb->m_cWnd)*(63.351)*(42.203));

} else {
	tcb->m_cWnd = (int) (64.239-(segmentsAcked)-(35.238)-(66.334)-(31.015)-(11.849)-(23.255)-(tcb->m_cWnd)-(64.833));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(75.12));
	ReduceCwnd (tcb);

}
float IoDdLDRoKPkrnYwu = (float) 68.644;
