tcb->m_cWnd = (int) (-49.062*(-94.344)*(16.146)*(-34.371)*(99.045));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (76.04*(19.64)*(13.749));
tcb->m_cWnd = (int) (-66.372*(-11.08)*(-72.521)*(-36.938)*(56.441));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-12.162*(-47.81)*(-8.162));
CongestionAvoidance (tcb, segmentsAcked);
