tcb->m_cWnd = (int) (11.426*(-17.557)*(-47.563)*(-98.228)*(1.055));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (26.061*(-1.968)*(-13.426));
CongestionAvoidance (tcb, segmentsAcked);
