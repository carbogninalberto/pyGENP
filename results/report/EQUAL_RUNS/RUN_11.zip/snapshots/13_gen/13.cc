tcb->m_cWnd = (int) (-73.944*(21.223)*(-61.692)*(-59.626)*(30.111));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (18.281*(-58.867)*(-69.806)*(-32.595)*(-71.259));
tcb->m_cWnd = (int) (-33.744*(-39.328)*(35.692));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-1.008*(-50.54)*(-24.754));
CongestionAvoidance (tcb, segmentsAcked);
