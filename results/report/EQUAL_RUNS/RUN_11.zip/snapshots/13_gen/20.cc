float KQXQvklosVkuATOJ = (float) 60.023;
int hlslFkCEmFJyWGYQ = (int) (-85.206-(-27.012)-(-13.328)-(-22.019)-(-69.041)-(-30.422));
if (tcb->m_cWnd >= KQXQvklosVkuATOJ) {
	KQXQvklosVkuATOJ = (float) (79.284/0.1);
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(KQXQvklosVkuATOJ)+(segmentsAcked)+(82.149)+(KQXQvklosVkuATOJ)+(tcb->m_segmentSize)+(44.078)+(tcb->m_segmentSize));

} else {
	KQXQvklosVkuATOJ = (float) (78.587*(74.455)*(79.612)*(98.354)*(50.762));

}
int kjHMEYKAxNFikODN = (int) 21.796;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
kjHMEYKAxNFikODN = (int) (96.455*(87.048));
ReduceCwnd (tcb);
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (96.595-(68.846)-(32.549)-(tcb->m_segmentSize)-(26.407)-(4.482)-(42.425));

} else {
	tcb->m_segmentSize = (int) (((0.1)+((1.749*(48.576)*(0.988)*(tcb->m_cWnd)*(93.036)*(86.794)))+(46.971)+(77.187)+(63.127)+(58.057))/((63.245)+(0.1)+(61.662)));

}
kjHMEYKAxNFikODN = (int) (-71.578*(-65.002));
if (KQXQvklosVkuATOJ <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (72.621*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(14.978));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (5.005-(KQXQvklosVkuATOJ)-(5.574)-(32.414)-(85.432));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (96.595-(68.846)-(32.549)-(tcb->m_segmentSize)-(26.407)-(4.482)-(42.425));

} else {
	tcb->m_segmentSize = (int) (((0.1)+((1.749*(48.576)*(0.988)*(tcb->m_cWnd)*(93.036)*(86.794)))+(46.971)+(77.187)+(63.127)+(58.057))/((63.245)+(0.1)+(61.662)));

}
if (KQXQvklosVkuATOJ <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (72.621*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(14.978));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (5.005-(KQXQvklosVkuATOJ)-(5.574)-(32.414)-(85.432));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
