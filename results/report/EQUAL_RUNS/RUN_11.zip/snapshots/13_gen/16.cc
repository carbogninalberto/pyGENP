segmentsAcked = (int) (22.675-(-88.669)-(-0.369)-(42.604)-(-12.162)-(37.892)-(83.604)-(10.408)-(-67.721));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
