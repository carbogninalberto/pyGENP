tcb->m_cWnd = (int) (30.046*(39.005)*(36.672)*(43.592)*(29.616));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (74.179*(-60.626)*(89.929)*(-74.289)*(97.957));
tcb->m_cWnd = (int) (-36.969*(48.684)*(84.469));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (95.841*(-86.013)*(-29.862));
CongestionAvoidance (tcb, segmentsAcked);
