tcb->m_cWnd = (int) (36.129*(-41.898)*(31.098)*(-89.976)*(86.669));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-44.854*(25.543)*(2.151));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-38.379*(-35.868)*(76.333)*(-16.06)*(71.017));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (88.237*(65.993)*(74.237));
CongestionAvoidance (tcb, segmentsAcked);
