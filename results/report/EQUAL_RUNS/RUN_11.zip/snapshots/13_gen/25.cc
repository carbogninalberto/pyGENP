tcb->m_cWnd = (int) (21.14*(56.705)*(-72.381)*(-79.202)*(81.6));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-41.957*(-13.568)*(-15.144));
tcb->m_cWnd = (int) (90.22*(-33.427)*(59.243));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
