tcb->m_cWnd = (int) (-85.193*(-58.802)*(90.331)*(-75.476)*(-8.764));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-31.2*(28.79)*(-48.362));
CongestionAvoidance (tcb, segmentsAcked);
