tcb->m_cWnd = (int) (14.118*(67.003)*(-44.181)*(67.396)*(-94.689));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-50.13*(93.37)*(-84.03));
CongestionAvoidance (tcb, segmentsAcked);
