segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (91.597+(72.551)+(98.825)+(segmentsAcked));
tcb->m_ssThresh = (int) (55.578+(5.267)+(36.791)+(9.696)+(57.674)+(25.18)+(72.946)+(49.233));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked == segmentsAcked) {
	segmentsAcked = (int) ((14.216*(tcb->m_segmentSize)*(9.897)*(tcb->m_ssThresh))/27.363);
	tcb->m_segmentSize = (int) ((tcb->m_segmentSize+(33.757)+(54.1)+(55.334)+(33.463)+(90.381))/85.092);
	tcb->m_segmentSize = (int) (28.768/93.495);

} else {
	segmentsAcked = (int) (((97.441)+(0.1)+(41.61)+(0.1)+(88.156))/((66.081)+(58.659)+(58.029)));
	segmentsAcked = (int) (((0.1)+(0.1)+((52.231*(71.918)*(72.846)*(14.866)*(27.292)*(67.626)*(segmentsAcked)*(26.551)*(41.076)))+(0.1)+(61.786)+(0.1))/((0.1)+(29.826)+(7.099)));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
