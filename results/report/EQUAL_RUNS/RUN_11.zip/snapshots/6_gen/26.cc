if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(8.396)*(93.06)*(76.206)*(0.744));
	tcb->m_cWnd = (int) (12.165+(82.259)+(21.925)+(84.293)+(tcb->m_ssThresh)+(6.904)+(tcb->m_segmentSize)+(70.21));
	segmentsAcked = (int) (28.497*(81.969)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(59.726)*(49.969));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (98.149+(73.258)+(15.026)+(49.48)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(10.915)+(24.18)+(55.421));
