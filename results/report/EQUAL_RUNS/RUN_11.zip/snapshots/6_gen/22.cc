float SjkmimIfvpmAuicy = (float) (tcb->m_cWnd+(92.793));
float nUIvfTxwqTFSJUEw = (float) (57.323/0.1);
if (tcb->m_segmentSize < nUIvfTxwqTFSJUEw) {
	segmentsAcked = (int) (7.84-(20.294));
	segmentsAcked = (int) (73.971*(60.607)*(45.584));

} else {
	segmentsAcked = (int) (SjkmimIfvpmAuicy+(40.48)+(90.436)+(10.701)+(nUIvfTxwqTFSJUEw)+(54.514)+(nUIvfTxwqTFSJUEw)+(59.819)+(15.404));
	ReduceCwnd (tcb);
	SjkmimIfvpmAuicy = (float) (46.997*(52.911)*(nUIvfTxwqTFSJUEw));

}
SjkmimIfvpmAuicy = (float) (0.1/58.246);
CongestionAvoidance (tcb, segmentsAcked);
float HZSciNUmPSwVmiDt = (float) (0.1/(26.295*(83.311)));
if (SjkmimIfvpmAuicy <= SjkmimIfvpmAuicy) {
	segmentsAcked = (int) (24.494+(46.77)+(54.79)+(4.098)+(15.555)+(95.969)+(segmentsAcked)+(15.288)+(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (41.903-(56.026)-(11.509)-(65.622));
	HZSciNUmPSwVmiDt = (float) (79.704*(58.37)*(76.836)*(SjkmimIfvpmAuicy));
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(47.415)-(6.702)-(SjkmimIfvpmAuicy)-(tcb->m_ssThresh)-(81.221));

}
if (HZSciNUmPSwVmiDt != SjkmimIfvpmAuicy) {
	nUIvfTxwqTFSJUEw = (float) (91.586+(14.52)+(HZSciNUmPSwVmiDt)+(tcb->m_segmentSize)+(21.38));

} else {
	nUIvfTxwqTFSJUEw = (float) (82.507*(39.203)*(23.077)*(54.602)*(53.551));
	tcb->m_cWnd = (int) (6.444/0.1);

}
