tcb->m_segmentSize = (int) (16.493-(0.424)-(80.817)-(tcb->m_segmentSize)-(97.833));
if (segmentsAcked == tcb->m_ssThresh) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (44.647+(6.862)+(60.425)+(38.345)+(75.74)+(tcb->m_cWnd));
tcb->m_ssThresh = (int) (64.897*(78.796)*(3.921)*(39.883));
float WMybTSStdmOkiNQZ = (float) (tcb->m_ssThresh*(78.652)*(4.132)*(tcb->m_cWnd)*(76.629)*(32.557)*(65.882));
