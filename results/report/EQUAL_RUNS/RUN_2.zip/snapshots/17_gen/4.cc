tcb->m_segmentSize = (int) (9.411-(-23.332)-(-49.0)-(-78.989)-(-54.641));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-36.656*(-63.932)*(72.812)*(-71.176));
ReduceCwnd (tcb);
