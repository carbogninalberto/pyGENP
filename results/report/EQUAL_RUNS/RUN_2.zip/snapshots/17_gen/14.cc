tcb->m_ssThresh = (int) (6.546+(tcb->m_cWnd)+(tcb->m_segmentSize));
segmentsAcked = (int) (70.663*(tcb->m_ssThresh)*(36.46)*(84.738)*(18.18)*(tcb->m_ssThresh)*(10.876));
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) ((((82.035-(19.099)-(24.769)-(61.903)-(80.23)-(tcb->m_segmentSize)-(1.248)))+(0.1)+(0.1)+(0.1)+((1.763*(32.011)*(56.804)*(segmentsAcked)*(54.984)*(32.853)*(52.622)*(78.656)))+(0.1))/((27.026)+(52.491)));

} else {
	tcb->m_segmentSize = (int) (49.44*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (0.1/0.1);

}
int UDMQnuJVIZFrIiyf = (int) (22.618+(tcb->m_ssThresh)+(segmentsAcked)+(segmentsAcked)+(segmentsAcked)+(65.365)+(94.878));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd != UDMQnuJVIZFrIiyf) {
	UDMQnuJVIZFrIiyf = (int) (19.659/92.604);

} else {
	UDMQnuJVIZFrIiyf = (int) (34.765-(segmentsAcked)-(tcb->m_segmentSize)-(11.484));

}
