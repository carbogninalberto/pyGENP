int ioxOwVdklroaAAlV = (int) (-29.221-(21.88)-(58.726)-(-43.174)-(-33.191)-(-72.146)-(-29.745));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (66.198-(40.129)-(40.282)-(41.765)-(-84.408)-(-20.018));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
