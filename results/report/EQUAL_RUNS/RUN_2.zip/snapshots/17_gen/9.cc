float ilbRMTmYOflkQjKf = (float) (-76.203/11.859);
ReduceCwnd (tcb);
int bCoGPJxbmsiHfBGr = (int) 7.496;
bCoGPJxbmsiHfBGr = (int) (36.024/-14.63);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (((52.144)+(6.411)+(37.01)+(87.085)+(60.921)+((98.064+(67.232)+(76.662)+(47.33)+(91.68)+(54.264)+(52.719)))+(0.1))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((52.144)+(6.411)+(37.01)+(87.085)+(60.921)+((98.064+(67.232)+(76.662)+(47.33)+(91.68)+(54.264)+(52.719)))+(0.1))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
ilbRMTmYOflkQjKf = (float) ((((-20.627*(96.042)*(tcb->m_segmentSize)))+(45.127)+((tcb->m_segmentSize-(tcb->m_cWnd)-(bCoGPJxbmsiHfBGr)-(-21.687)-(61.505)-(24.325)-(-46.03)-(-34.993)-(55.023)))+(96.277)+(20.705))/((-16.661)+(-15.586)));
ilbRMTmYOflkQjKf = (float) ((((55.768*(-25.786)*(tcb->m_segmentSize)))+(74.302)+((tcb->m_segmentSize-(tcb->m_cWnd)-(bCoGPJxbmsiHfBGr)-(55.764)-(-53.759)-(95.163)-(-1.62)-(45.351)-(76.088)))+(57.113)+(59.354))/((29.223)+(-6.925)));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((52.144)+(6.411)+(37.01)+(87.085)+(60.921)+((98.064+(67.232)+(76.662)+(47.33)+(91.68)+(54.264)+(52.719)))+(0.1))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
ilbRMTmYOflkQjKf = (float) ((((-66.27*(28.465)*(tcb->m_segmentSize)))+(-9.033)+((tcb->m_segmentSize-(tcb->m_cWnd)-(bCoGPJxbmsiHfBGr)-(-12.225)-(35.2)-(-14.997)-(-53.571)-(-68.479)-(-98.065)))+(-29.567)+(61.272))/((-30.869)+(-64.156)));
ilbRMTmYOflkQjKf = (float) ((((-13.347*(-22.136)*(tcb->m_segmentSize)))+(-27.207)+((tcb->m_segmentSize-(tcb->m_cWnd)-(bCoGPJxbmsiHfBGr)-(-32.612)-(13.878)-(86.853)-(-84.465)-(-82.974)-(90.895)))+(-37.927)+(-75.523))/((40.867)+(-22.562)));
