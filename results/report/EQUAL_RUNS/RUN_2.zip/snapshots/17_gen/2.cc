int jDcVGVGPVBXVcFDe = (int) (-14.037-(74.509)-(-85.545)-(79.682)-(-33.604)-(-67.943)-(68.469)-(16.665)-(22.321));
float CjhoSDsMoeczYlIv = (float) (95.987-(45.746)-(41.855)-(-20.407)-(-68.032)-(-28.401)-(-11.985)-(-18.272));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-50.443-(-43.395)-(61.463));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
