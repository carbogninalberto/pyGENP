segmentsAcked = (int) (((0.1)+(0.1)+(13.808)+(0.1)+(22.595)+(0.1)+(20.245)+(0.1))/((0.1)));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(73.628)*(tcb->m_segmentSize)*(32.981));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) ((((tcb->m_segmentSize-(tcb->m_segmentSize)))+(0.1)+(0.1)+(0.1)+(0.1)+(0.1)+(86.347)+(0.1))/((14.538)));

}
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) ((83.829-(6.143))/0.1);

} else {
	tcb->m_cWnd = (int) (59.362*(19.353)*(44.162));

}
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (97.396-(tcb->m_ssThresh)-(25.958)-(segmentsAcked)-(43.834)-(44.037));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (tcb->m_ssThresh-(1.295)-(86.188)-(35.394));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
