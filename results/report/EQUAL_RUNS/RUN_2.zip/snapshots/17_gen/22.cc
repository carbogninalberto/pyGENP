tcb->m_segmentSize = (int) (((0.1)+((98.076*(93.909)*(96.224)*(35.363)*(segmentsAcked)*(10.913)*(tcb->m_cWnd)))+(0.1)+(8.861))/((0.1)+(0.1)+(0.1)+(0.1)+(0.1)));
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_segmentSize = (int) (85.452+(52.296)+(7.96)+(segmentsAcked)+(87.523)+(42.993)+(segmentsAcked)+(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (61.707*(86.108)*(79.366)*(20.76)*(tcb->m_cWnd)*(6.197));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.633*(70.501)*(32.916)*(tcb->m_segmentSize)*(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (24.498+(12.918)+(tcb->m_cWnd)+(18.506)+(17.528)+(36.16)+(61.64));

} else {
	tcb->m_cWnd = (int) (0.1/31.603);
	tcb->m_segmentSize = (int) (22.316*(41.034)*(tcb->m_cWnd)*(88.768)*(73.301)*(46.291)*(10.89));

}
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_cWnd = (int) (61.223*(53.142)*(98.375)*(34.904)*(80.541)*(40.192)*(87.641)*(40.004)*(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (0.1/0.1);

}
