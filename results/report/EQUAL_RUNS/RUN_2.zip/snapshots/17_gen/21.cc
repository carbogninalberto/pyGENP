segmentsAcked = (int) (38.437*(41.736)*(60.212)*(46.648)*(27.892));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked > segmentsAcked) {
	segmentsAcked = (int) ((97.821*(41.389)*(68.391)*(70.17)*(tcb->m_ssThresh)*(2.981))/5.884);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (25.534/(36.942+(55.097)+(tcb->m_segmentSize)+(90.95)));
	tcb->m_cWnd = (int) (6.227-(tcb->m_cWnd)-(65.982)-(tcb->m_ssThresh));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh >= segmentsAcked) {
	segmentsAcked = (int) (93.794*(segmentsAcked)*(67.899)*(64.168)*(tcb->m_ssThresh)*(26.632)*(90.274)*(tcb->m_cWnd)*(22.392));
	tcb->m_segmentSize = (int) ((30.451-(tcb->m_cWnd)-(40.261)-(segmentsAcked))/91.548);
	tcb->m_ssThresh = (int) (94.153-(75.476)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(87.293)-(tcb->m_ssThresh)-(6.938));

} else {
	segmentsAcked = (int) (tcb->m_cWnd+(37.321)+(98.718)+(77.845)+(11.373)+(52.831));
	tcb->m_segmentSize = (int) (90.775+(2.977)+(74.587)+(tcb->m_cWnd)+(65.308)+(7.142)+(segmentsAcked)+(41.264));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
