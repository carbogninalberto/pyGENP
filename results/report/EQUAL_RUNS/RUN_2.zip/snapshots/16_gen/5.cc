float gQEbNndcMwUuXnQB = (float) (43.612/99.917);
