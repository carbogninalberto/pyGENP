CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(74.319));
	tcb->m_cWnd = (int) ((77.607*(31.262)*(segmentsAcked)*(90.302))/0.1);

} else {
	tcb->m_cWnd = (int) (75.867*(35.982)*(75.805)*(12.698));

}
segmentsAcked = (int) (31.182+(70.043)+(56.991));
ReduceCwnd (tcb);
