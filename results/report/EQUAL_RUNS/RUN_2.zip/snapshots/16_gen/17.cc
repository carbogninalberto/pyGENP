tcb->m_ssThresh = (int) (35.98+(11.918)+(82.988)+(tcb->m_segmentSize)+(tcb->m_ssThresh));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(26.295)*(71.407)*(29.902)*(51.036)*(77.532)*(64.519)*(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(tcb->m_cWnd)-(53.156)-(8.57)-(28.642));
	tcb->m_ssThresh = (int) (37.288-(57.336)-(19.128)-(33.057));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
