int gvOFcIkVshjJjqvb = (int) 22.916;
tcb->m_cWnd = (int) (-9.099*(15.405)*(34.438));
