float JSrPnksDntmwdHhz = (float) (-21.747-(87.17));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (53.583/57.072);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-60.22*(62.92)*(76.377)*(-35.562)*(20.756)*(-18.111)*(-23.086));
