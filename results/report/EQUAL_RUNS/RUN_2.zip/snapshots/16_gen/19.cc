ReduceCwnd (tcb);
int dAwdrpOpbednXWGR = (int) (0.1/0.1);
segmentsAcked = (int) (segmentsAcked-(94.608));
tcb->m_ssThresh = (int) (79.902+(86.149)+(22.464)+(88.773)+(10.439));
int FPMRzYCeDjBDYpCH = (int) ((71.294-(23.489)-(4.742)-(segmentsAcked)-(22.349)-(50.08)-(48.269)-(dAwdrpOpbednXWGR)-(20.056))/33.381);
