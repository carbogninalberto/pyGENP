int XGknyvbEfVwETwVs = (int) (-10.573/95.796);
