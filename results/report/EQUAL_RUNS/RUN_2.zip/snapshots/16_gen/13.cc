if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_ssThresh = (int) (11.965*(1.339)*(segmentsAcked)*(16.521)*(20.74)*(42.125));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (81.082-(76.93)-(40.439));
	tcb->m_ssThresh = (int) (76.053*(14.555)*(18.826)*(32.952));
	tcb->m_ssThresh = (int) (2.639*(5.911)*(12.826)*(84.639)*(30.855)*(tcb->m_cWnd));

}
tcb->m_ssThresh = (int) (71.102*(31.688)*(47.141)*(tcb->m_segmentSize)*(39.389)*(15.888)*(55.792));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_cWnd*(60.496)*(63.958)*(48.581)*(58.872)*(segmentsAcked)*(75.524));
tcb->m_segmentSize = (int) (46.143+(89.61)+(97.207)+(76.266)+(6.193)+(91.718));
