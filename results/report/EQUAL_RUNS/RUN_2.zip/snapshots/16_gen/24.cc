CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
float VWrjrxpEzeBQnXKd = (float) (14.191+(84.887)+(32.343)+(tcb->m_segmentSize)+(tcb->m_ssThresh));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (27.428+(tcb->m_ssThresh)+(71.177)+(63.105)+(1.767)+(71.899)+(12.487)+(18.173)+(tcb->m_ssThresh));
