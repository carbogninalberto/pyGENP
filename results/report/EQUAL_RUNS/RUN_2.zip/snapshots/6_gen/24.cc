segmentsAcked = (int) (-10.731*(-25.982));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
