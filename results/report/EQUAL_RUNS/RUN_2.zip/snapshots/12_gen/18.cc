segmentsAcked = (int) (-58.721*(71.284));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-88.416*(1.839));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
