tcb->m_segmentSize = (int) (0.789+(76.276)+(73.371)+(86.482)+(26.786)+(45.469)+(43.885));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (85.356/0.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_ssThresh+(20.129)+(65.225)+(tcb->m_cWnd)+(21.81)+(88.655)+(12.309)+(82.943)+(57.189));
tcb->m_ssThresh = (int) (25.739/0.1);
ReduceCwnd (tcb);
