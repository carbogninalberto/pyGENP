int nZqjnkSbRlNCiLtu = (int) 4.05;
float QCJcgycVXirmJiak = (float) 12.654;
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (61.525+(53.845));

} else {
	tcb->m_cWnd = (int) (70.767/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
