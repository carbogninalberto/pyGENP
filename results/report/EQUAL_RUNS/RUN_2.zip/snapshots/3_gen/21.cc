int AxigTpuAzJOLRbcH = (int) (81.613*(26.179)*(-35.794)*(2.388)*(93.914)*(-46.518)*(-43.097)*(-60.315));
segmentsAcked = (int) (-75.933+(37.005)+(-82.093));
segmentsAcked = (int) (-71.657+(-24.596)+(29.251));
segmentsAcked = (int) (60.542+(-33.046)+(8.775));
segmentsAcked = (int) (-79.118+(40.747));
segmentsAcked = (int) (71.728+(-3.982));
