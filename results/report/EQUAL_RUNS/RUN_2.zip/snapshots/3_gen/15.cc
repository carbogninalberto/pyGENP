segmentsAcked = SlowStart (tcb, segmentsAcked);
float EzDFcaHZlfbnnDSt = (float) 28.909;
EzDFcaHZlfbnnDSt = (float) (-61.112*(-63.219)*(-77.908));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (60.537+(37.888)+(48.94)+(9.098)+(segmentsAcked)+(tcb->m_cWnd)+(84.171)+(43.269)+(97.12));
	ReduceCwnd (tcb);
	EzDFcaHZlfbnnDSt = (float) (tcb->m_cWnd-(55.104)-(59.116)-(12.499));

} else {
	tcb->m_segmentSize = (int) (91.155+(10.758)+(16.618)+(96.078)+(38.137)+(55.961)+(55.039));

}
