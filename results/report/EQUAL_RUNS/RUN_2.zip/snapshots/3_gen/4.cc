if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (segmentsAcked-(45.511)-(14.417)-(11.986)-(19.352)-(51.992));

} else {
	tcb->m_segmentSize = (int) (20.654/70.002);

}
tcb->m_segmentSize = (int) (89.314/93.952);
tcb->m_segmentSize = (int) ((((62.448*(-86.633)*(9.315)*(-29.23)*(-24.255)*(segmentsAcked)*(97.779)))+(-89.817)+(-65.055)+(75.311)+(-20.564)+(26.654))/((74.702)));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (87.211*(-39.457)*(-84.407)*(51.724)*(65.56));
