tcb->m_cWnd = (int) (-28.786/90.84);
tcb->m_segmentSize = (int) (-2.581*(54.887)*(68.61));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
