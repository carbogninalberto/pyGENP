ReduceCwnd (tcb);
float SSxZJfXDSpLgrvfL = (float) (32.012-(33.337)-(85.069)-(98.159));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (45.302*(83.155)*(SSxZJfXDSpLgrvfL)*(40.597)*(70.119)*(tcb->m_cWnd));
