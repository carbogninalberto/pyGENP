float EzDFcaHZlfbnnDSt = (float) (((0.1)+(52.913)+(20.264)+(0.1)+(93.326)+(55.134))/((0.1)+(68.152)+(0.1)));
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_cWnd = (int) (54.119-(tcb->m_ssThresh)-(segmentsAcked)-(89.396));

} else {
	tcb->m_cWnd = (int) (((0.1)+((segmentsAcked+(23.782)+(11.307)+(5.775)))+(0.1)+(0.1)+(0.1)+(0.1)+(34.087))/((70.144)+(0.1)));

}
EzDFcaHZlfbnnDSt = (float) (98.391*(tcb->m_segmentSize)*(tcb->m_ssThresh));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (60.537+(37.888)+(48.94)+(9.098)+(segmentsAcked)+(tcb->m_cWnd)+(84.171)+(43.269)+(97.12));
	ReduceCwnd (tcb);
	EzDFcaHZlfbnnDSt = (float) (tcb->m_cWnd-(55.104)-(59.116)-(12.499));

} else {
	tcb->m_segmentSize = (int) (91.155+(10.758)+(16.618)+(96.078)+(38.137)+(55.961)+(55.039));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
