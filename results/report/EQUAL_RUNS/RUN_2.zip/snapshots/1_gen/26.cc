if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (13.962+(8.763)+(14.817)+(tcb->m_cWnd)+(19.554)+(37.466)+(30.128)+(67.77));
	segmentsAcked = (int) ((tcb->m_cWnd+(44.938))/(42.072+(tcb->m_segmentSize)+(94.211)+(tcb->m_segmentSize)+(93.41)+(56.781)));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (((81.548)+(62.302)+((31.333*(97.452)))+(60.247))/((52.836)+(68.168)+(0.1)+(0.1)));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (((90.173)+((81.651+(95.738)+(segmentsAcked)+(69.755)+(21.576)+(49.128)+(14.316)))+(23.896)+(0.1)+(0.1))/((15.743)+(55.958)+(73.936)));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (84.995*(92.259)*(58.805)*(86.879)*(tcb->m_cWnd)*(53.632)*(26.587)*(82.275));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (39.105-(segmentsAcked)-(tcb->m_segmentSize)-(96.417)-(22.041)-(71.632)-(segmentsAcked));
