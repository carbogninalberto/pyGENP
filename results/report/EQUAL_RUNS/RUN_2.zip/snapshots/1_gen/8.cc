tcb->m_cWnd = (int) (14.918-(72.891)-(96.249)-(57.153)-(48.561)-(2.378)-(84.395));
segmentsAcked = (int) (56.183+(57.502)+(57.103));
segmentsAcked = (int) (58.455+(65.997));
if (segmentsAcked > segmentsAcked) {
	tcb->m_cWnd = (int) (94.425-(68.92)-(26.933)-(71.768)-(9.645));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (90.486*(segmentsAcked)*(76.364)*(43.741)*(segmentsAcked)*(78.118)*(41.144)*(25.084));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(1.011)*(segmentsAcked)*(tcb->m_ssThresh)*(segmentsAcked)*(11.316)*(52.56)*(29.251));

}
float XEpVKwBwyMgAryMh = (float) (segmentsAcked*(27.519)*(86.263)*(85.382));
