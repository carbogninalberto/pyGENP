CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (0.1/35.177);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (26.912+(5.926)+(18.932));

} else {
	tcb->m_cWnd = (int) (16.22+(78.225)+(85.999)+(69.177)+(37.05)+(28.82)+(69.068));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (69.966+(5.37)+(tcb->m_cWnd)+(86.705)+(16.835));

} else {
	tcb->m_cWnd = (int) (98.895-(34.561)-(95.094)-(20.022)-(70.832));
	segmentsAcked = (int) (((29.189)+(0.1)+(39.527)+(0.1)+(42.065)+(0.1)+(95.055))/((55.94)));

}
