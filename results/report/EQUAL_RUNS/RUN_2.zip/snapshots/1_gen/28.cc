if (segmentsAcked < segmentsAcked) {
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (29.57*(97.561)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(1.343)*(tcb->m_ssThresh));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = (int) (56.585-(14.635)-(97.719)-(53.046)-(39.987)-(23.352)-(99.434)-(segmentsAcked)-(segmentsAcked));
tcb->m_segmentSize = (int) (2.246/0.1);
tcb->m_segmentSize = (int) ((((tcb->m_segmentSize*(1.524)*(tcb->m_segmentSize)*(93.74)*(76.334)*(segmentsAcked)*(96.827)))+(0.1)+(99.325)+(54.915)+(26.987)+(3.304))/((0.1)));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (92.211*(8.827)*(28.808)*(68.912)*(78.76));
