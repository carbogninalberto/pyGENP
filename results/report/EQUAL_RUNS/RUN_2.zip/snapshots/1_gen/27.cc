segmentsAcked = (int) (75.07-(tcb->m_ssThresh)-(26.999)-(14.956));
tcb->m_segmentSize = (int) (45.048*(tcb->m_cWnd)*(17.287));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (90.961-(87.101));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(28.18)-(28.431)-(52.871)-(9.792)-(27.856)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (18.006-(49.011)-(87.136)-(60.346)-(53.357)-(46.574));

}
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (87.491/8.7);
	segmentsAcked = (int) (33.764*(12.868)*(15.101));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (23.114*(73.329)*(64.572)*(12.785)*(68.884)*(64.308)*(49.623)*(95.068)*(60.96));
	tcb->m_ssThresh = (int) (35.821+(segmentsAcked)+(24.857)+(62.276)+(tcb->m_segmentSize)+(34.129)+(62.562)+(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
