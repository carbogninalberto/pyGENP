segmentsAcked = (int) (46.016*(54.039));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (66.948*(88.641)*(69.703)*(tcb->m_segmentSize)*(67.768));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (65.631*(22.513)*(tcb->m_cWnd)*(90.186)*(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (62.257/63.841);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
