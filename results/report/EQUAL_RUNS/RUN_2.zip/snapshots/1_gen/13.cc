ReduceCwnd (tcb);
if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (((13.199)+(12.234)+(0.1)+(0.1)+(67.345)+(82.252))/((0.1)+(94.45)));
	tcb->m_ssThresh = (int) (segmentsAcked*(12.364)*(13.8)*(79.357)*(tcb->m_ssThresh)*(93.099));
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(31.828)+(84.204)+(4.294)+(75.814)+(63.232)+(6.364)+(48.291));

} else {
	segmentsAcked = (int) (26.168-(55.476)-(16.199)-(tcb->m_segmentSize)-(42.09)-(96.264)-(27.6)-(tcb->m_ssThresh)-(87.356));
	tcb->m_cWnd = (int) (71.48+(90.914)+(74.136)+(47.868)+(46.569)+(5.229)+(3.577)+(38.531));
	tcb->m_cWnd = (int) (18.642-(22.132)-(tcb->m_segmentSize));

}
tcb->m_ssThresh = (int) (0.1/0.1);
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/38.878);
	tcb->m_cWnd = (int) (((96.578)+(0.1)+(45.108)+(0.1)+(75.574)+(0.1))/((85.854)));

} else {
	tcb->m_segmentSize = (int) (90.924+(segmentsAcked)+(92.243)+(83.128)+(65.338));

}
if (segmentsAcked != segmentsAcked) {
	segmentsAcked = (int) (tcb->m_cWnd+(63.702)+(71.839));

} else {
	segmentsAcked = (int) (78.697*(67.586)*(83.538)*(57.5)*(90.685)*(7.956)*(7.064)*(60.797)*(64.631));

}
