tcb->m_segmentSize = (int) (-74.75-(-85.367)-(-88.285)-(88.713)-(-5.85)-(26.235));
tcb->m_segmentSize = (int) (-6.155-(4.054));
tcb->m_cWnd = (int) (12.775+(61.282));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(segmentsAcked)-(tcb->m_cWnd)-(tcb->m_cWnd)-(tcb->m_cWnd)-(segmentsAcked)-(44.024)-(76.548));
	tcb->m_segmentSize = (int) (68.516*(63.039)*(84.521)*(78.706)*(95.942)*(76.248)*(60.226)*(58.506));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(63.328)*(37.293));
	segmentsAcked = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
