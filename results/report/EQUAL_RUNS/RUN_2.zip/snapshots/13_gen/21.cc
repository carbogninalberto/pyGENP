tcb->m_cWnd = (int) (((6.144)+(0.1)+(17.445)+(0.1))/((0.1)+(0.1)));
float iFmcZahpnxfBpvyS = (float) (84.916-(51.326)-(44.82)-(82.526));
tcb->m_segmentSize = (int) ((((tcb->m_ssThresh-(73.786)-(12.842)-(70.837)-(segmentsAcked)-(tcb->m_segmentSize)-(43.901)-(27.617)-(21.053)))+((8.719-(94.51)-(74.544)-(51.843)-(tcb->m_segmentSize)))+(32.031)+((34.61*(39.167)*(54.482)*(72.767)*(5.001)*(12.437)*(94.958)))+(0.1))/((0.1)+(0.1)));
if (iFmcZahpnxfBpvyS != iFmcZahpnxfBpvyS) {
	tcb->m_ssThresh = (int) (94.838/0.1);
	tcb->m_ssThresh = (int) (((54.698)+(12.267)+(77.035)+(41.992))/((0.1)+(53.559)+(0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (83.992-(13.738)-(94.01));
	segmentsAcked = (int) (tcb->m_cWnd*(tcb->m_segmentSize)*(22.081)*(iFmcZahpnxfBpvyS));

}
float sdJjJzlMISLMTJcc = (float) (97.481*(30.269));
sdJjJzlMISLMTJcc = (float) (44.598-(16.565)-(21.574)-(iFmcZahpnxfBpvyS)-(77.472));
CongestionAvoidance (tcb, segmentsAcked);
iFmcZahpnxfBpvyS = (float) (0.1/0.1);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
