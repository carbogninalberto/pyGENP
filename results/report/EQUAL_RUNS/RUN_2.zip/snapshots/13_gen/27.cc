tcb->m_cWnd = (int) (30.966-(tcb->m_segmentSize));
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (3.928*(38.105)*(22.581));

}
tcb->m_cWnd = (int) (((0.1)+((tcb->m_ssThresh*(82.81)*(97.096)*(6.001)*(79.38)*(7.833)*(1.244)))+(0.1)+(29.749)+(63.445)+(0.1)+(0.1))/((53.26)+(0.1)));
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_ssThresh = (int) ((96.343*(6.757))/41.287);
	ReduceCwnd (tcb);
	segmentsAcked = (int) (((0.1)+(0.1)+(22.317)+(0.1))/((26.348)+(46.832)+(33.642)));

} else {
	tcb->m_ssThresh = (int) (13.799-(9.949));

}
CongestionAvoidance (tcb, segmentsAcked);
