tcb->m_ssThresh = (int) ((segmentsAcked*(81.336)*(3.558))/7.763);
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (24.789*(69.817)*(79.726)*(66.848)*(64.235)*(62.167)*(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (36.371-(9.13)-(segmentsAcked)-(42.342)-(63.421));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (26.093-(9.426)-(45.933)-(95.501)-(tcb->m_cWnd)-(12.138));

}
tcb->m_segmentSize = (int) (24.015-(72.008)-(tcb->m_segmentSize)-(13.851)-(22.647)-(45.477)-(tcb->m_cWnd)-(91.482));
segmentsAcked = (int) (((45.619)+(0.1)+((segmentsAcked+(39.788)+(59.941)+(53.177)+(tcb->m_cWnd)))+(44.876)+((99.513*(44.932)*(64.877)*(8.179)*(72.973)))+(0.1))/((0.1)+(0.1)+(50.275)));
CongestionAvoidance (tcb, segmentsAcked);
