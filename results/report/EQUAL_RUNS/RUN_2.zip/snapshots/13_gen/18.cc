if (tcb->m_cWnd <= tcb->m_ssThresh) {
	segmentsAcked = (int) (72.92+(53.119)+(77.675)+(22.88)+(60.416)+(68.54)+(28.277)+(93.204));
	tcb->m_segmentSize = (int) (22.949*(40.202)*(72.442)*(tcb->m_segmentSize)*(29.961)*(64.237)*(69.741));
	tcb->m_ssThresh = (int) (33.095*(6.561)*(20.57));

} else {
	segmentsAcked = (int) (91.105+(tcb->m_segmentSize)+(tcb->m_cWnd)+(46.805));
	segmentsAcked = (int) (((4.356)+(0.1)+(78.651)+(0.1)+(69.121)+(0.1))/((70.522)));
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (tcb->m_cWnd*(segmentsAcked)*(49.833)*(18.713)*(60.67));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (85.903/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) ((50.496*(69.052)*(18.371)*(94.884)*(81.941)*(tcb->m_ssThresh)*(20.296))/0.1);
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(87.955)*(57.72));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
