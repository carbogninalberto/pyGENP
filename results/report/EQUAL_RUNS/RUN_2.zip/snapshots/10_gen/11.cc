segmentsAcked = (int) (71.627*(-45.411));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
