if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (21.051-(44.512)-(71.907)-(43.949)-(71.293)-(48.539)-(25.13)-(13.78));
	tcb->m_segmentSize = (int) (91.287*(72.139)*(51.419)*(87.04));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	segmentsAcked = (int) ((8.695+(63.432)+(41.519)+(12.573))/0.1);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (31.854-(95.557)-(-84.376)-(76.998)-(36.422)-(-83.035));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
