int tMGLnCalosdJyGix = (int) (47.607-(53.251)-(72.337)-(-28.436)-(-35.511)-(-73.31)-(-86.675));
tcb->m_cWnd = (int) (-9.312*(65.768)*(9.611)*(-82.775)*(11.982)*(31.336));
tcb->m_segmentSize = (int) (-57.636/41.481);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-14.296*(87.038));
