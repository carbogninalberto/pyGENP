CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (81.804-(-89.061)-(43.394)-(99.29)-(-26.639)-(39.106));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
