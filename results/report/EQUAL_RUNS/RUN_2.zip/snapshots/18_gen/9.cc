CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-41.795-(82.467)-(-3.422)-(-53.093)-(-85.662)-(-52.832));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
