float QXjQAVWlKHGlISIx = (float) (13.214+(-56.947)+(23.833)+(-42.24));
int fXnerCxSICZQgYSm = (int) (-33.713-(31.722)-(71.908));
QXjQAVWlKHGlISIx = (float) (85.396+(84.439)+(-71.389)+(-1.275)+(68.67)+(27.028)+(-58.764)+(-80.36));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (52.651*(-95.226)*(-87.138)*(-1.631));
if (fXnerCxSICZQgYSm == segmentsAcked) {
	segmentsAcked = (int) (45.786*(9.511)*(51.847)*(18.084)*(QXjQAVWlKHGlISIx)*(QXjQAVWlKHGlISIx)*(-62.788)*(87.473));
	tcb->m_cWnd = (int) (((0.1)+(52.9)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(84.794)+(0.1)));
	tcb->m_segmentSize = (int) (31.225-(54.026));

} else {
	segmentsAcked = (int) (30.618+(19.769)+(27.11)+(26.22)+(92.885)+(61.98)+(-81.699));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
