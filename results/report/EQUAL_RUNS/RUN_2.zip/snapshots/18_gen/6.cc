int msVQvzxhtkSWrTzZ = (int) (-39.885+(-75.378)+(-5.083)+(-87.855)+(-77.204)+(-38.365));
int wPHOHyCKxMeYjuzQ = (int) (69.028*(37.14));
ReduceCwnd (tcb);
int gkuuUxFaCOGnICbb = (int) (8.385*(-22.213)*(-53.056)*(24.161)*(-39.409)*(2.097)*(96.341));
if (wPHOHyCKxMeYjuzQ <= wPHOHyCKxMeYjuzQ) {
	tcb->m_cWnd = (int) (97.071*(wPHOHyCKxMeYjuzQ));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (45.454*(60.609)*(38.7)*(20.604));

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	segmentsAcked = (int) (20.622-(63.245)-(3.659)-(28.689)-(86.294));

} else {
	segmentsAcked = (int) (segmentsAcked+(5.857)+(78.643)+(-18.237)+(17.086)+(-7.363));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (wPHOHyCKxMeYjuzQ != wPHOHyCKxMeYjuzQ) {
	wPHOHyCKxMeYjuzQ = (int) (segmentsAcked-(71.259)-(81.673)-(7.414)-(17.13));
	tcb->m_cWnd = (int) (((0.1)+(37.287)+((64.057+(41.657)+(wPHOHyCKxMeYjuzQ)+(48.797)+(wPHOHyCKxMeYjuzQ)+(55.558)+(73.947)))+(44.642)+(78.713)+(0.1))/((0.1)));
	wPHOHyCKxMeYjuzQ = (int) (segmentsAcked-(tcb->m_cWnd)-(16.959)-(73.025)-(71.494)-(49.347)-(41.217)-(52.101));

} else {
	wPHOHyCKxMeYjuzQ = (int) (73.588-(97.151));

}
