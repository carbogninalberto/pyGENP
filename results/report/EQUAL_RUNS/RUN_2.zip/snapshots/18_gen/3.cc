float QXjQAVWlKHGlISIx = (float) (-79.629+(-99.501)+(93.615)+(-2.516));
int fXnerCxSICZQgYSm = (int) (-43.493-(97.238)-(-50.123));
if (fXnerCxSICZQgYSm != tcb->m_cWnd) {
	QXjQAVWlKHGlISIx = (float) (((0.1)+((89.81*(71.993)*(54.563)*(tcb->m_segmentSize)*(segmentsAcked)*(22.296)))+(0.1)+(92.364))/((0.1)+(74.993)));
	QXjQAVWlKHGlISIx = (float) (56.562+(3.08));
	ReduceCwnd (tcb);

} else {
	QXjQAVWlKHGlISIx = (float) (68.417+(2.576));
	QXjQAVWlKHGlISIx = (float) (5.413*(fXnerCxSICZQgYSm)*(8.989)*(26.056)*(QXjQAVWlKHGlISIx)*(99.25)*(70.458));

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (53.479*(-28.659)*(-41.739)*(-14.02));
if (fXnerCxSICZQgYSm == segmentsAcked) {
	segmentsAcked = (int) (45.786*(9.511)*(51.847)*(72.776)*(QXjQAVWlKHGlISIx)*(QXjQAVWlKHGlISIx)*(99.674)*(87.473));
	tcb->m_cWnd = (int) (((0.1)+(52.9)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(84.794)+(0.1)));
	tcb->m_segmentSize = (int) (31.225-(54.026));

} else {
	segmentsAcked = (int) (30.618+(19.769)+(27.11)+(26.22)+(92.885)+(61.98)+(16.995));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
