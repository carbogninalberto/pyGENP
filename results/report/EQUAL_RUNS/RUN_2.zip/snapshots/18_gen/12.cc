tcb->m_cWnd = (int) (0.1/0.1);
tcb->m_cWnd = (int) (42.567-(89.217)-(56.168)-(26.512)-(76.666)-(5.31)-(74.485)-(62.217)-(51.928));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd-(53.223)-(73.506)-(5.776)-(45.48)-(89.892));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (43.77-(tcb->m_cWnd)-(64.292)-(tcb->m_cWnd)-(segmentsAcked)-(60.837)-(segmentsAcked));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
