int aiCTKArSqjytOxfA = (int) (-83.539-(-91.64)-(-98.769));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
aiCTKArSqjytOxfA = (int) (83.381*(59.438)*(-27.053)*(-20.634)*(-93.986)*(75.177)*(-23.663)*(-1.108)*(-82.684));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (67.321*(58.157)*(15.893));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(6.129)+(-57.577)+(95.885));
	segmentsAcked = (int) (49.797*(55.649)*(59.156)*(26.962));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
