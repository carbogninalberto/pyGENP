tcb->m_segmentSize = (int) (47.754+(75.877));
ReduceCwnd (tcb);
int iVlnvzZNZnIBUxOW = (int) (0.1/(69.979+(19.24)+(87.519)+(66.925)+(tcb->m_ssThresh)+(87.845)+(81.985)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (iVlnvzZNZnIBUxOW < iVlnvzZNZnIBUxOW) {
	tcb->m_cWnd = (int) (((62.529)+(5.472)+(0.1)+(57.779))/((0.1)+(0.1)+(0.1)));
	iVlnvzZNZnIBUxOW = (int) (0.1/0.1);
	iVlnvzZNZnIBUxOW = (int) (37.556+(92.18)+(65.936)+(44.612));

} else {
	tcb->m_cWnd = (int) (11.512+(iVlnvzZNZnIBUxOW)+(73.945)+(16.886)+(6.657)+(54.172));
	tcb->m_cWnd = (int) (65.625-(iVlnvzZNZnIBUxOW)-(56.616));

}
tcb->m_ssThresh = (int) (segmentsAcked+(tcb->m_segmentSize)+(26.789)+(91.286)+(44.175));
