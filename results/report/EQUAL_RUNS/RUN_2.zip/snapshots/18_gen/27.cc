ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (19.067*(89.835)*(14.114)*(tcb->m_segmentSize)*(16.026)*(0.898));
	tcb->m_segmentSize = (int) (26.598*(12.811)*(21.667)*(56.825));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(40.922)*(tcb->m_segmentSize)*(24.718)*(61.892));

}
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_ssThresh+(32.155)+(28.729));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh+(40.781)+(18.95)+(15.819));
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (0.1/0.1);
tcb->m_segmentSize = (int) (((80.325)+(0.1)+(97.939)+(0.1)+(8.86))/((0.1)+(0.1)+(0.1)));
