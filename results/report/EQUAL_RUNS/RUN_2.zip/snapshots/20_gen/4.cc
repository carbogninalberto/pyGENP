int iiLwEcGiVxLeUCUJ = (int) (-96.188*(-48.78)*(-30.151)*(47.335)*(47.638)*(-9.022)*(-69.2)*(5.519));
ReduceCwnd (tcb);
if (segmentsAcked > tcb->m_segmentSize) {
	segmentsAcked = (int) ((42.728+(segmentsAcked))/42.805);

} else {
	segmentsAcked = (int) (15.373/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
float TsNSZLOYmEIsAhXD = (float) (6.456+(-97.168));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != iiLwEcGiVxLeUCUJ) {
	tcb->m_segmentSize = (int) (65.778*(94.906)*(segmentsAcked)*(67.843)*(24.856)*(-81.231)*(97.661)*(iiLwEcGiVxLeUCUJ)*(56.609));
	tcb->m_cWnd = (int) (34.714-(83.914)-(46.139)-(72.829)-(15.866)-(iiLwEcGiVxLeUCUJ));

} else {
	tcb->m_segmentSize = (int) (53.486-(98.976)-(segmentsAcked)-(iiLwEcGiVxLeUCUJ));

}
if (iiLwEcGiVxLeUCUJ >= segmentsAcked) {
	tcb->m_cWnd = (int) (59.786/50.036);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(91.049)*(66.57)*(2.88));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (segmentsAcked > tcb->m_segmentSize) {
	segmentsAcked = (int) ((42.728+(segmentsAcked))/42.805);

} else {
	segmentsAcked = (int) (15.373/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
