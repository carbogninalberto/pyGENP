int hRMkMLQEysBsJJcj = (int) (-1.361+(-58.938));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (hRMkMLQEysBsJJcj <= hRMkMLQEysBsJJcj) {
	hRMkMLQEysBsJJcj = (int) (((17.23)+(0.1)+(40.047)+(61.804)+(0.1))/((36.349)+(0.1)+(0.1)+(3.306)));
	hRMkMLQEysBsJJcj = (int) (0.1/89.402);

} else {
	hRMkMLQEysBsJJcj = (int) (58.272+(35.717)+(28.947)+(50.87)+(segmentsAcked));
	tcb->m_segmentSize = (int) (92.121-(98.453));
	tcb->m_cWnd = (int) (80.912+(19.352)+(47.754)+(hRMkMLQEysBsJJcj)+(tcb->m_cWnd)+(83.484));

}
tcb->m_cWnd = (int) (-54.591-(59.372)-(-94.07)-(29.024)-(1.917)-(-84.303));
