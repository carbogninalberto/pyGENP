tcb->m_ssThresh = (int) (92.668+(80.815)+(77.911));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (64.861/0.1);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((0.1)+(22.859)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)));
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (segmentsAcked+(49.164)+(89.469)+(tcb->m_cWnd)+(83.145)+(63.949)+(95.749)+(24.786));

} else {
	tcb->m_ssThresh = (int) (21.659*(tcb->m_ssThresh));

}
