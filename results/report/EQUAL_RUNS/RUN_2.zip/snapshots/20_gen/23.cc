segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (32.54*(segmentsAcked)*(7.45)*(17.06)*(6.403)*(tcb->m_segmentSize)*(5.478)*(21.302)*(25.053));
	tcb->m_ssThresh = (int) (45.663+(32.822)+(58.192)+(tcb->m_segmentSize)+(21.13)+(9.893)+(60.289));

} else {
	tcb->m_cWnd = (int) (2.763*(tcb->m_cWnd)*(43.359)*(61.966)*(27.848));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (37.871-(60.393)-(34.738)-(43.847)-(81.989)-(51.509)-(6.91));

}
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (50.573*(6.67)*(60.553)*(52.559)*(26.329)*(34.82)*(29.523)*(25.816));

} else {
	tcb->m_segmentSize = (int) (80.405*(13.311));
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (segmentsAcked+(67.166)+(97.853)+(64.509)+(50.158)+(91.254)+(66.852)+(31.876));

}
tcb->m_segmentSize = (int) (tcb->m_ssThresh+(97.44)+(47.995)+(38.361)+(70.535));
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (6.677-(84.427)-(tcb->m_ssThresh)-(43.266)-(38.805)-(52.264));

} else {
	tcb->m_ssThresh = (int) (58.964-(tcb->m_segmentSize)-(segmentsAcked)-(47.219)-(88.291)-(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (30.379/0.1);

}
segmentsAcked = (int) (76.3+(38.841));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (24.206+(39.69)+(segmentsAcked)+(segmentsAcked));
