int rgXeFperRiEFHDYh = (int) (4.823-(-72.275)-(-75.3)-(-43.133)-(21.401)-(22.928)-(-42.537)-(-4.031)-(-91.856));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-25.587/81.053);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-44.624*(84.122)*(24.943)*(-84.879)*(-96.333)*(26.682)*(50.094));
