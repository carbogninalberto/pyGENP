tcb->m_segmentSize = (int) (0.1/0.1);
tcb->m_segmentSize = (int) (0.1/0.1);
tcb->m_segmentSize = (int) (84.051*(50.457));
tcb->m_cWnd = (int) (63.34-(86.097)-(89.052)-(tcb->m_ssThresh));
tcb->m_segmentSize = (int) ((((tcb->m_segmentSize*(tcb->m_ssThresh)))+(25.813)+(0.1)+(92.969))/((0.1)+(3.566)+(0.1)+(52.71)+(0.1)));
