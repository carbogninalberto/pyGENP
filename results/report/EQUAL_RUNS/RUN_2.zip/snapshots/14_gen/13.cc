int mfJdMNrQDymBcBoe = (int) (-51.812*(-68.021));
float NUdgFXKuwpjhjiDC = (float) (12.929*(-87.122)*(63.918)*(30.95)*(-97.135)*(44.412)*(-83.962)*(-80.275)*(75.897));
segmentsAcked = SlowStart (tcb, segmentsAcked);
int tRpfxWQXoIRrXaIG = (int) (((-2.47)+(-2.686)+(83.738)+(-49.934))/((-64.107)+(20.511)+(-31.794)+(-24.991)));
tcb->m_cWnd = (int) (97.84*(77.771)*(-41.644));
int UrmwejNCFxceLQtQ = (int) 94.79;
ReduceCwnd (tcb);
if (tcb->m_cWnd >= mfJdMNrQDymBcBoe) {
	tcb->m_cWnd = (int) ((((45.847*(2.802)*(39.22)*(mfJdMNrQDymBcBoe)))+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(27.489)+(0.1)));
	NUdgFXKuwpjhjiDC = (float) (NUdgFXKuwpjhjiDC+(5.31));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-82.792*(-66.057)*(67.959));
ReduceCwnd (tcb);
if (tcb->m_cWnd >= mfJdMNrQDymBcBoe) {
	tcb->m_cWnd = (int) ((((45.847*(2.802)*(39.22)*(mfJdMNrQDymBcBoe)))+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(27.489)+(0.1)));
	NUdgFXKuwpjhjiDC = (float) (NUdgFXKuwpjhjiDC+(5.31));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
