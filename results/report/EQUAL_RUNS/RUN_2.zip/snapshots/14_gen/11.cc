float MkIDJpbPYuKjPWzj = (float) (13.033/-74.687);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-66.76*(63.31)*(-7.834)*(-16.333)*(-82.222)*(6.988)*(93.554));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (58.628+(48.559)+(53.646)+(8.891)+(3.827)+(65.103)+(75.483)+(87.01));
	ReduceCwnd (tcb);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) ((74.845-(42.52)-(90.483))/(30.317*(49.267)));

}
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (95.755*(51.668)*(83.53));

} else {
	tcb->m_segmentSize = (int) (29.352+(90.999)+(80.488)+(48.766)+(26.513)+(80.185));

}
