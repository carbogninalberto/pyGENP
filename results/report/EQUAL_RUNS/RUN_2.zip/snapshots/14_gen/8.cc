TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (22.147-(12.583)-(-11.04)-(-78.546)-(-85.044)-(-21.701));
