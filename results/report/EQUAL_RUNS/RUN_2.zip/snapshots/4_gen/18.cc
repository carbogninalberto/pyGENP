float qSYiIpGFZglflsvN = (float) 46.331;
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
qSYiIpGFZglflsvN = (float) (-15.835/90.541);
