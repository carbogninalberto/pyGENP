CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (2.179-(61.076)-(-76.614)-(-52.753));
tcb->m_segmentSize = (int) (23.495*(-34.037)*(-37.031));
tcb->m_segmentSize = (int) (61.649*(31.469)*(20.626));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
