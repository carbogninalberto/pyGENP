TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (86.483+(-41.773)+(58.612));
segmentsAcked = (int) (82.904+(92.848)+(-63.538));
segmentsAcked = (int) (-93.817+(30.514)+(90.28));
segmentsAcked = (int) (43.674+(55.219));
