segmentsAcked = (int) (-45.981-(88.75)-(-95.972));
