tcb->m_segmentSize = (int) (62.312-(94.756)-(-70.495)-(-42.141)-(-62.342)-(30.289)-(0.329)-(-4.168)-(-87.584));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (59.353-(83.239)-(25.532)-(80.301)-(30.763)-(64.885)-(tcb->m_segmentSize)-(78.348)-(65.579));

} else {
	tcb->m_cWnd = (int) (18.12*(1.089)*(87.069)*(75.41)*(52.202)*(74.397)*(42.43)*(72.38));
	CongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (59.353-(83.239)-(25.532)-(80.301)-(30.763)-(64.885)-(tcb->m_segmentSize)-(78.348)-(65.579));

} else {
	tcb->m_cWnd = (int) (18.12*(1.089)*(87.069)*(75.41)*(52.202)*(74.397)*(42.43)*(72.38));
	CongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
