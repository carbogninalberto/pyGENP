tcb->m_segmentSize = (int) (2.921+(58.94)+(-48.098)+(-82.055)+(22.503)+(-78.237)+(11.615));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (((-71.387)+((19.329+(15.182)+(segmentsAcked)+(-53.205)+(-63.121)+(-25.078)+(-80.038)))+(59.298)+(45.71)+(50.66))/((-32.696)+(-17.518)+(66.083)));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-34.802*(-8.398)*(0.272)*(-11.509)*(88.5)*(-45.006)*(30.936)*(-64.544));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-14.215-(4.05)-(-36.926)-(-55.49)-(-63.232)-(94.295)-(-86.688));
