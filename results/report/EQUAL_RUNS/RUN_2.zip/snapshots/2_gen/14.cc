float qWywrFwHsNgJVlgZ = (float) (13.527+(-66.612)+(-65.709)+(90.855)+(55.834)+(72.591)+(90.508));
int nZqjnkSbRlNCiLtu = (int) 4.05;
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (70.767/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (61.525+(53.845));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (70.767/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (61.525+(53.845));

}
float QCJcgycVXirmJiak = (float) 93.683;
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
