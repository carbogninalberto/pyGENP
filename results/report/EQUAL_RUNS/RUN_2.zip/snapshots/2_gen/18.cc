ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.12*(1.089)*(87.069)*(75.41)*(52.202)*(74.397)*(42.43)*(72.38));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (59.353-(83.239)-(25.532)-(80.301)-(30.763)-(64.885)-(tcb->m_segmentSize)-(78.348)-(65.579));

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (59.353-(83.239)-(25.532)-(80.301)-(30.763)-(64.885)-(tcb->m_segmentSize)-(78.348)-(65.579));

} else {
	tcb->m_cWnd = (int) (18.12*(1.089)*(87.069)*(75.41)*(52.202)*(74.397)*(42.43)*(72.38));
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
