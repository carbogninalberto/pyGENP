tcb->m_segmentSize = (int) (89.505*(-70.832)*(-60.444)*(94.183));
tcb->m_segmentSize = (int) (-48.615*(22.076)*(-94.316));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-39.942-(-75.454)-(30.122)-(-11.06));
tcb->m_segmentSize = (int) (-53.545*(53.132)*(29.677));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
