if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (35.493-(33.085)-(14.968)-(25.712)-(50.769));

} else {
	tcb->m_cWnd = (int) ((90.399+(97.704)+(79.018))/65.933);
	segmentsAcked = (int) (15.823*(83.552)*(47.261)*(14.098)*(83.706)*(93.52));
	tcb->m_segmentSize = (int) (67.361+(60.752)+(42.293)+(segmentsAcked)+(89.313)+(tcb->m_segmentSize)+(98.292)+(50.848));

}
