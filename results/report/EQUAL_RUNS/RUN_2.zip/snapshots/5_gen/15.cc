if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked+(72.689)+(76.41)+(85.691)+(tcb->m_segmentSize)+(71.749)+(70.048)+(39.273)+(28.558));
	ReduceCwnd (tcb);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (0.1/47.504);
	tcb->m_segmentSize = (int) (55.146-(14.962)-(segmentsAcked)-(21.742)-(80.433)-(93.186)-(34.433)-(11.975));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-89.842-(-22.483)-(33.886)-(15.427));
tcb->m_segmentSize = (int) (90.129*(-61.517)*(-94.064));
tcb->m_segmentSize = (int) (58.639*(31.681)*(53.304));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
