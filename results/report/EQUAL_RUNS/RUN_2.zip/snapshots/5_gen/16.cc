segmentsAcked = (int) (-90.593*(-40.891));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
