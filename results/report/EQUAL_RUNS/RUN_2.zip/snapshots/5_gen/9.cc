segmentsAcked = (int) (-92.265*(3.895)*(47.972)*(-13.974)*(-29.16)*(-5.408)*(-11.023));
segmentsAcked = (int) (-97.961+(-34.083)+(-73.92));
segmentsAcked = (int) (95.703+(18.019)+(-22.371));
segmentsAcked = (int) (-71.747+(-29.635)+(2.036));
segmentsAcked = (int) (10.086+(-60.984));
