segmentsAcked = (int) (-77.167*(39.309));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (57.153*(-81.422));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
