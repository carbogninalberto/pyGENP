segmentsAcked = (int) (-17.939*(-78.336));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
