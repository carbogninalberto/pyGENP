segmentsAcked = (int) (79.792*(-65.164));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
