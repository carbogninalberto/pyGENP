float CYioSTiRqjoHQfdT = (float) (22.714+(-5.802)+(-79.045)+(89.944)+(30.381));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (81.538*(20.609)*(-47.869)*(1.364));
segmentsAcked = (int) (-79.561*(-79.347)*(-81.909)*(-13.536)*(-44.319)*(-67.409));
segmentsAcked = (int) (70.973-(-2.475)-(85.46)-(-86.794)-(-60.496)-(-21.832)-(-65.681)-(14.464)-(84.442));
if (segmentsAcked >= CYioSTiRqjoHQfdT) {
	CYioSTiRqjoHQfdT = (float) (((87.882)+(0.1)+(57.637)+(0.1)+(5.392))/((94.617)+(42.858)+(0.1)+(84.234)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	CYioSTiRqjoHQfdT = (float) (69.336-(38.179)-(26.834)-(segmentsAcked)-(31.49)-(11.934)-(69.857));

}
segmentsAcked = (int) (-56.287-(-19.117)-(33.962)-(-87.978)-(76.96)-(-44.242)-(92.804)-(71.019)-(-87.744));
if (segmentsAcked >= CYioSTiRqjoHQfdT) {
	CYioSTiRqjoHQfdT = (float) (69.336-(38.179)-(26.834)-(segmentsAcked)-(31.49)-(11.934)-(69.857));

} else {
	CYioSTiRqjoHQfdT = (float) (((87.882)+(0.1)+(57.637)+(0.1)+(5.392))/((94.617)+(42.858)+(0.1)+(84.234)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
