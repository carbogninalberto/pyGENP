tcb->m_ssThresh = (int) (((13.338)+(0.1)+((1.815-(99.49)-(90.236)-(97.197)-(54.913)-(10.058)))+(83.756)+((15.052+(35.586)+(20.951)+(88.733)))+(86.316))/((60.761)+(0.1)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (31.178*(4.974)*(5.397)*(segmentsAcked)*(41.226)*(84.118)*(segmentsAcked)*(tcb->m_ssThresh)*(61.419));
tcb->m_cWnd = (int) (81.784+(95.996)+(99.786)+(33.182)+(tcb->m_ssThresh)+(26.424));
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (10.822+(70.61)+(66.054)+(2.632)+(tcb->m_cWnd)+(45.842)+(69.865));
	segmentsAcked = (int) ((81.009*(66.29)*(48.537)*(segmentsAcked)*(tcb->m_cWnd)*(60.742)*(60.036)*(18.944))/57.824);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(8.631)-(segmentsAcked)-(44.075)-(tcb->m_cWnd)-(28.7)-(79.921));

}
