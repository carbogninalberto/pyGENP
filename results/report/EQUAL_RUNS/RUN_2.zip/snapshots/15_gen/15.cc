tcb->m_cWnd = (int) (73.005*(21.949));
int gLSWMqnCWfxXDixi = (int) (72.859-(82.349)-(4.314)-(2.917)-(74.286)-(53.177)-(35.489)-(86.024)-(74.703));
int VUndcxlUemLygDRH = (int) (30.299/16.071);
gLSWMqnCWfxXDixi = (int) (0.1/0.1);
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(50.684)-(44.678)-(tcb->m_cWnd)-(63.308)-(67.967)-(62.646)-(86.474)-(66.574));

} else {
	tcb->m_segmentSize = (int) (33.304+(27.417)+(24.475)+(98.003)+(88.256));

}
ReduceCwnd (tcb);
if (gLSWMqnCWfxXDixi < gLSWMqnCWfxXDixi) {
	tcb->m_segmentSize = (int) (80.232/0.1);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (VUndcxlUemLygDRH-(49.772)-(86.764)-(72.76)-(27.472)-(89.766));

}
if (VUndcxlUemLygDRH < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (83.863*(3.587));
	segmentsAcked = (int) (59.278+(9.928)+(7.367)+(70.292)+(tcb->m_segmentSize)+(VUndcxlUemLygDRH));
	VUndcxlUemLygDRH = (int) (3.058-(18.827)-(43.721)-(62.632));

} else {
	tcb->m_segmentSize = (int) (gLSWMqnCWfxXDixi*(97.552)*(19.726)*(11.839)*(29.372)*(74.938)*(segmentsAcked)*(18.887)*(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (49.623+(VUndcxlUemLygDRH)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(99.637)+(96.86)+(20.479));
