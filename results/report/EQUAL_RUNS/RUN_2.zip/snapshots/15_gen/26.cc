int vMixWyAxpeipwrtI = (int) (55.559-(tcb->m_cWnd)-(82.661)-(tcb->m_cWnd)-(48.306)-(75.312));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= vMixWyAxpeipwrtI) {
	tcb->m_ssThresh = (int) (((49.816)+(0.1)+((91.28-(tcb->m_segmentSize)-(89.338)-(62.028)-(95.046)))+(39.649))/((29.38)+(0.1)+(0.1)+(0.1)+(0.1)));
	tcb->m_segmentSize = (int) (48.557-(1.644)-(89.487)-(55.038)-(tcb->m_cWnd)-(tcb->m_cWnd)-(tcb->m_segmentSize)-(41.744)-(38.91));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (65.347*(3.274)*(53.992)*(28.044)*(6.449)*(11.198)*(12.356)*(6.477));

}
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (33.916+(tcb->m_ssThresh)+(33.154)+(33.956)+(vMixWyAxpeipwrtI));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (10.464+(39.997)+(9.897)+(vMixWyAxpeipwrtI)+(vMixWyAxpeipwrtI));

} else {
	tcb->m_ssThresh = (int) (58.117*(tcb->m_ssThresh)*(10.875));

}
tcb->m_cWnd = (int) (38.6-(10.14)-(93.721));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	vMixWyAxpeipwrtI = (int) (96.672*(22.91)*(tcb->m_segmentSize));
	vMixWyAxpeipwrtI = (int) (25.663-(42.102)-(30.457));

} else {
	vMixWyAxpeipwrtI = (int) (60.246*(36.038));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) ((27.088*(11.489)*(82.585)*(5.477)*(57.913)*(tcb->m_segmentSize)*(47.551))/17.637);

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_ssThresh = (int) ((1.413*(51.153)*(98.776)*(vMixWyAxpeipwrtI)*(85.989)*(32.733))/0.1);
	tcb->m_ssThresh = (int) (70.624*(vMixWyAxpeipwrtI)*(51.061)*(18.2)*(92.247)*(13.191)*(39.963)*(36.838)*(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (91.634-(61.487)-(tcb->m_segmentSize)-(83.794)-(2.23)-(28.84));

} else {
	tcb->m_ssThresh = (int) (62.635+(48.567)+(70.836)+(2.733)+(0.848)+(11.686)+(tcb->m_ssThresh));
	tcb->m_cWnd = (int) ((23.898*(52.184))/86.447);

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(85.65)+(19.074)+(44.453)+(52.921)+(vMixWyAxpeipwrtI)+(9.464)+(16.825)+(45.677));
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (31.506*(77.215)*(13.899)*(97.361)*(segmentsAcked)*(segmentsAcked)*(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (83.355-(41.076));

}
