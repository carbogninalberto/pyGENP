tcb->m_cWnd = (int) (65.654*(18.921)*(32.652)*(77.594)*(91.492));
tcb->m_ssThresh = (int) (64.09-(99.402)-(tcb->m_cWnd)-(tcb->m_cWnd)-(53.714)-(71.656));
segmentsAcked = (int) (93.423-(35.209)-(19.897)-(46.185)-(tcb->m_segmentSize)-(37.188)-(62.517));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (42.182+(tcb->m_ssThresh)+(33.995)+(63.299)+(47.397)+(26.824)+(53.513)+(72.397)+(11.286));
	tcb->m_ssThresh = (int) (segmentsAcked-(48.134));
	tcb->m_ssThresh = (int) (91.697+(13.722)+(tcb->m_cWnd)+(21.86)+(90.428)+(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (43.849*(46.615)*(31.267)*(75.521)*(91.384)*(9.625)*(tcb->m_cWnd)*(54.604));
	tcb->m_cWnd = (int) (28.268+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (((16.754)+(82.134)+(0.1)+(0.1)+(0.1)+(91.258))/((0.1)+(90.592)));

}
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((33.802)+(43.341)+(0.1)+((16.416+(71.702)))+(57.403)+(93.851))/((96.806)+(17.239)));
	tcb->m_cWnd = (int) (52.826+(74.637)+(59.066)+(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked-(6.04)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(tcb->m_segmentSize)*(3.881)*(41.071)*(segmentsAcked)*(13.246)*(29.348)*(19.661));
	tcb->m_segmentSize = (int) (0.1/78.971);

}
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_cWnd = (int) (89.369-(37.969)-(84.95)-(87.323)-(83.488)-(66.072)-(48.658));
	segmentsAcked = (int) (70.242-(30.621)-(43.055)-(75.458)-(26.088)-(94.607)-(91.757)-(64.248)-(77.344));
	tcb->m_cWnd = (int) (tcb->m_cWnd*(segmentsAcked)*(14.411)*(tcb->m_ssThresh)*(43.365)*(53.93)*(40.444)*(95.068)*(62.244));

} else {
	tcb->m_cWnd = (int) (3.43*(22.32)*(tcb->m_segmentSize)*(1.167)*(segmentsAcked));
	tcb->m_segmentSize = (int) (49.802+(75.249)+(69.568)+(segmentsAcked)+(35.811)+(84.471)+(31.483));

}
segmentsAcked = (int) (0.1/(8.167-(tcb->m_ssThresh)));
