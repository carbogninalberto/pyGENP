tcb->m_ssThresh = (int) (77.166+(85.224)+(80.571)+(27.329)+(45.646)+(51.438)+(53.946)+(6.234)+(43.647));
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (48.962-(45.056));
	tcb->m_segmentSize = (int) (43.63-(24.661)-(3.433)-(19.945)-(47.45)-(69.013)-(4.04)-(89.691));

} else {
	segmentsAcked = (int) (71.632+(16.976)+(87.425)+(66.513)+(84.372)+(10.479)+(6.671));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (4.035+(85.423));
if (segmentsAcked <= segmentsAcked) {
	tcb->m_cWnd = (int) (92.761-(62.408)-(19.829)-(tcb->m_cWnd)-(9.274));
	tcb->m_ssThresh = (int) (32.05+(24.679)+(92.965)+(86.882)+(tcb->m_cWnd)+(64.947)+(99.66));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(53.118)-(tcb->m_cWnd)-(84.606));

}
tcb->m_ssThresh = (int) ((9.689-(74.273)-(77.26)-(26.673)-(7.653)-(34.931)-(94.558))/0.1);
