float CYioSTiRqjoHQfdT = (float) (37.153+(17.25)+(18.046)+(-90.111)+(10.695));
tcb->m_cWnd = (int) (-45.776*(4.595)*(1.871)*(-18.427)*(-30.196)*(40.105)*(-21.121));
segmentsAcked = SlowStart (tcb, segmentsAcked);
