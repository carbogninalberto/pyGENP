tcb->m_cWnd = (int) (tcb->m_segmentSize*(27.137)*(69.886)*(92.754));
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	segmentsAcked = (int) (((0.1)+(0.1)+(88.862)+(23.368))/((50.298)));
	tcb->m_cWnd = (int) (97.713+(0.549)+(tcb->m_ssThresh)+(86.533)+(62.262));

} else {
	segmentsAcked = (int) (16.087+(66.03)+(95.078)+(tcb->m_segmentSize)+(47.0)+(15.552)+(52.254)+(21.067));
	segmentsAcked = (int) (((0.1)+((23.099-(99.015)-(tcb->m_ssThresh)-(79.701)-(62.253)-(tcb->m_segmentSize)-(66.839)))+(0.1)+(0.1)+(0.1)+((tcb->m_segmentSize+(28.069)+(67.028)+(78.686)+(82.834)+(tcb->m_ssThresh)+(40.978)+(26.374)))+(40.839))/((84.132)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (0.1/0.1);
tcb->m_cWnd = (int) (92.071*(24.297)*(57.24)*(90.748)*(55.821)*(56.255)*(32.985)*(81.032));
int HKCJMExzodOGGfQB = (int) (99.964-(10.892)-(93.014)-(12.133)-(7.209)-(tcb->m_cWnd));
