tcb->m_segmentSize = (int) (tcb->m_segmentSize-(31.563)-(41.909));
int XmCwCRnilsKGTmzu = (int) (3.099-(tcb->m_segmentSize)-(97.002));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (segmentsAcked-(63.96)-(82.355)-(98.261)-(tcb->m_segmentSize)-(85.739)-(67.336)-(5.261));

} else {
	tcb->m_ssThresh = (int) (41.111-(36.934)-(11.595)-(68.844)-(40.053)-(17.309));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
XmCwCRnilsKGTmzu = (int) (85.053*(94.764)*(8.648)*(tcb->m_cWnd));
float xCiRZkPWhSLoKUeB = (float) (((5.143)+((26.326-(8.078)-(77.926)-(0.302)-(89.19)))+((segmentsAcked*(84.084)*(75.622)*(15.442)*(9.997)*(70.684)*(segmentsAcked)*(66.74)))+(0.1))/((12.252)+(0.1)+(0.1)+(0.1)+(0.1)));
if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (((19.249)+(42.292)+(0.1)+(15.307))/((0.1)+(95.632)+(80.909)));

} else {
	segmentsAcked = (int) (97.48-(40.603)-(tcb->m_ssThresh)-(52.407));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (95.017*(35.309));
	XmCwCRnilsKGTmzu = (int) (37.613-(98.254)-(73.95)-(57.298));

} else {
	tcb->m_segmentSize = (int) (72.331-(96.101)-(tcb->m_segmentSize)-(47.992));
	tcb->m_cWnd = (int) (70.765*(23.882)*(87.906));

}
if (XmCwCRnilsKGTmzu != segmentsAcked) {
	xCiRZkPWhSLoKUeB = (float) (47.292-(14.1)-(42.82)-(57.174)-(96.096));
	tcb->m_cWnd = (int) (segmentsAcked+(88.916)+(69.882)+(80.42)+(3.91)+(XmCwCRnilsKGTmzu));
	XmCwCRnilsKGTmzu = (int) (68.942/15.888);

} else {
	xCiRZkPWhSLoKUeB = (float) (53.589*(4.953)*(tcb->m_ssThresh)*(21.986)*(segmentsAcked)*(93.171)*(28.503)*(4.008)*(65.843));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (71.569-(27.008)-(76.584)-(97.668)-(49.392)-(4.839)-(78.001)-(9.54));

}
tcb->m_cWnd = (int) (75.9+(81.939)+(84.574)+(52.259)+(xCiRZkPWhSLoKUeB)+(74.995)+(98.152)+(61.169)+(88.577));
