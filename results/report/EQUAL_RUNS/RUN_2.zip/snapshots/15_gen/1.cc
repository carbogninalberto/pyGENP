segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (84.14-(-84.157)-(-12.752)-(29.153)-(27.234)-(53.27));
