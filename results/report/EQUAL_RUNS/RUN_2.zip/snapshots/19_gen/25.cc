tcb->m_cWnd = (int) (20.459*(78.382)*(6.433)*(31.756)*(tcb->m_cWnd)*(98.867)*(30.609));
tcb->m_segmentSize = (int) (79.686*(57.735)*(75.514)*(48.221)*(34.356)*(19.944)*(60.096));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (segmentsAcked-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(32.716)-(tcb->m_cWnd)-(42.34));
ReduceCwnd (tcb);
