if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_cWnd = (int) (36.317/23.565);

} else {
	tcb->m_cWnd = (int) (75.149*(88.553)*(23.574)*(79.894)*(6.332)*(81.082)*(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) ((13.993-(41.856))/3.011);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((0.1)+(58.62)+(0.1)+(0.1)+(0.1)+(67.028))/((0.1)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (((39.565)+(12.122)+(34.757)+(85.872))/((0.1)));
