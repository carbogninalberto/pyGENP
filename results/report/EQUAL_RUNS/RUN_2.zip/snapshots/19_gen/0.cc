CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-54.089-(-2.102)-(8.808)-(-9.842)-(-51.874)-(-89.761));
