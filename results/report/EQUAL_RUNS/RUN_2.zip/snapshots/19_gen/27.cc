float stvbMsOaSFtzByBv = (float) (56.921+(8.986));
float FwQPXEzMThArPChs = (float) (61.066-(66.288)-(43.181)-(38.286)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(61.036)-(54.571)-(tcb->m_segmentSize));
float DWmvkoxBymSBhUGw = (float) (74.722*(FwQPXEzMThArPChs)*(23.795)*(93.932)*(tcb->m_cWnd)*(segmentsAcked));
DWmvkoxBymSBhUGw = (float) ((((24.097*(9.595)*(7.49)*(11.682)))+(0.1)+(0.1)+(35.786)+(0.1)+(0.1))/((0.1)+(0.1)));
stvbMsOaSFtzByBv = (float) (((0.1)+(14.747)+(2.904)+(34.681)+(0.1)+(0.1))/((9.874)));
if (tcb->m_cWnd < tcb->m_ssThresh) {
	DWmvkoxBymSBhUGw = (float) (tcb->m_cWnd*(54.744));

} else {
	DWmvkoxBymSBhUGw = (float) (57.621-(stvbMsOaSFtzByBv)-(35.351));
	DWmvkoxBymSBhUGw = (float) (71.897-(83.116)-(97.264)-(2.388)-(13.19)-(64.772)-(42.635)-(31.901)-(77.768));
	DWmvkoxBymSBhUGw = (float) (56.318-(segmentsAcked)-(6.472)-(24.724)-(50.787)-(47.854)-(7.687)-(27.822)-(3.532));

}
