float ZiyAQBMjvIYGPAxi = (float) (25.116/-16.069);
if (tcb->m_segmentSize <= ZiyAQBMjvIYGPAxi) {
	tcb->m_segmentSize = (int) (75.022-(66.581)-(41.506)-(5.458)-(32.023)-(83.565)-(43.459)-(76.262)-(ZiyAQBMjvIYGPAxi));

} else {
	tcb->m_segmentSize = (int) (14.115+(6.566)+(17.871)+(-44.656));
	tcb->m_segmentSize = (int) (((0.1)+(83.588)+(83.716)+(0.1)+(0.1)+(0.1)+(3.371)+(29.901))/((91.089)));

}
tcb->m_cWnd = (int) (82.854+(-76.545)+(11.191)+(-61.365)+(70.274)+(70.345)+(-19.716)+(91.207)+(53.629));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) ((((tcb->m_cWnd-(75.123)-(-35.844)-(-8.721)-(tcb->m_ssThresh)-(29.338)-(-30.913)))+(7.201)+((tcb->m_cWnd*(-8.196)*(31.508)*(-62.983)*(-29.772)*(-79.49)*(tcb->m_cWnd)*(11.854)))+(33.069))/((9.751)));
