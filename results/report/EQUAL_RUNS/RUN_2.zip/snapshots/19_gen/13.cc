if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	segmentsAcked = (int) (((61.092)+(0.1)+((tcb->m_segmentSize+(25.673)+(69.25)+(0.344)+(59.068)+(10.035)+(68.428)+(85.084)+(81.371)))+(90.216)+(0.1)+(0.1)+(49.099))/((0.1)+(0.1)));
	tcb->m_segmentSize = (int) (64.914*(93.318));

} else {
	segmentsAcked = (int) (99.815-(35.336)-(86.424));

}
tcb->m_ssThresh = (int) (55.406+(81.924)+(17.076)+(50.705)+(segmentsAcked));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh >= segmentsAcked) {
	segmentsAcked = (int) (97.935+(96.946));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (0.597+(77.415)+(39.424)+(48.822)+(96.177)+(tcb->m_segmentSize)+(17.723)+(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (((82.173)+(0.1)+(9.814)+(52.432))/((59.443)+(0.1)+(0.1)+(0.1)));

}
int hRMkMLQEysBsJJcj = (int) (33.582+(4.085));
if (hRMkMLQEysBsJJcj <= hRMkMLQEysBsJJcj) {
	hRMkMLQEysBsJJcj = (int) (((17.23)+(0.1)+(40.047)+(61.804)+(0.1))/((36.349)+(0.1)+(0.1)+(3.306)));
	hRMkMLQEysBsJJcj = (int) (0.1/89.402);

} else {
	hRMkMLQEysBsJJcj = (int) (58.272+(35.717)+(28.947)+(50.87)+(segmentsAcked));
	tcb->m_segmentSize = (int) (92.121-(98.453));
	tcb->m_cWnd = (int) (80.912+(19.352)+(47.754)+(hRMkMLQEysBsJJcj)+(tcb->m_cWnd)+(83.484));

}
tcb->m_cWnd = (int) (78.689-(39.385)-(42.134)-(61.815)-(44.637)-(33.232));
