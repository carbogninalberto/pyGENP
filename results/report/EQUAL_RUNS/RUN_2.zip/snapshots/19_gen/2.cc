int fXnerCxSICZQgYSm = (int) (-56.776-(-76.266)-(-75.344));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float QXjQAVWlKHGlISIx = (float) 56.151;
QXjQAVWlKHGlISIx = (float) (-58.082+(18.936)+(-78.367)+(60.21)+(64.914)+(88.796)+(-83.659)+(-95.276));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-23.12*(-16.485)*(-97.071)*(-56.365));
if (fXnerCxSICZQgYSm == segmentsAcked) {
	segmentsAcked = (int) (45.786*(9.511)*(51.847)*(18.084)*(QXjQAVWlKHGlISIx)*(QXjQAVWlKHGlISIx)*(-62.788)*(87.473));
	tcb->m_cWnd = (int) (((0.1)+(52.9)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(84.794)+(0.1)));
	tcb->m_segmentSize = (int) (31.225-(54.026));

} else {
	segmentsAcked = (int) (30.618+(19.769)+(27.11)+(26.22)+(92.885)+(61.98)+(-81.699));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
