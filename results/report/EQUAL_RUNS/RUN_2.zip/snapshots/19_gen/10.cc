int fXnerCxSICZQgYSm = (int) (95.647-(76.426)-(93.773));
float QXjQAVWlKHGlISIx = (float) (-68.615+(9.925)+(-84.132)+(55.871));
segmentsAcked = (int) (-82.504*(-21.475)*(-89.394)*(45.967)*(9.42)*(-40.753)*(53.208)*(42.778));
QXjQAVWlKHGlISIx = (float) (51.749+(-25.244)+(-43.177)+(54.875)+(40.009)+(-78.867)+(25.724)+(17.861));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (86.113*(96.421)*(59.34)*(-98.285));
if (fXnerCxSICZQgYSm == segmentsAcked) {
	segmentsAcked = (int) (30.618+(19.769)+(27.11)+(26.22)+(92.885)+(61.98)+(-81.699));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (45.786*(9.511)*(51.847)*(18.084)*(QXjQAVWlKHGlISIx)*(QXjQAVWlKHGlISIx)*(-62.788)*(87.473));
	tcb->m_cWnd = (int) (((0.1)+(52.9)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(84.794)+(0.1)));
	tcb->m_segmentSize = (int) (31.225-(54.026));

}
QXjQAVWlKHGlISIx = (float) (82.888+(40.248)+(-34.381)+(3.897)+(35.444)+(-30.491)+(78.999)+(-5.216));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-32.803*(76.339)*(-61.197)*(-61.766));
if (fXnerCxSICZQgYSm == segmentsAcked) {
	segmentsAcked = (int) (45.786*(9.511)*(51.847)*(18.084)*(QXjQAVWlKHGlISIx)*(QXjQAVWlKHGlISIx)*(-62.788)*(87.473));
	tcb->m_cWnd = (int) (((0.1)+(52.9)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(84.794)+(0.1)));
	tcb->m_segmentSize = (int) (31.225-(54.026));

} else {
	segmentsAcked = (int) (30.618+(19.769)+(27.11)+(26.22)+(92.885)+(61.98)+(-81.699));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
