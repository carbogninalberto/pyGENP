int mQBFCeLZRngjClyV = (int) (-36.087-(34.873)-(-25.723)-(-71.989)-(61.028)-(60.707)-(58.19)-(-56.229)-(99.16));
tcb->m_cWnd = (int) (-75.769+(19.55)+(80.401));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	mQBFCeLZRngjClyV = (int) (26.864*(84.439)*(22.416)*(63.561));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	mQBFCeLZRngjClyV = (int) ((56.628-(14.911)-(tcb->m_cWnd)-(24.083)-(82.274))/0.1);

} else {
	mQBFCeLZRngjClyV = (int) (96.877*(28.493)*(49.676)*(mQBFCeLZRngjClyV));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (mQBFCeLZRngjClyV != tcb->m_cWnd) {
	mQBFCeLZRngjClyV = (int) (mQBFCeLZRngjClyV+(37.947)+(3.265)+(49.302)+(63.401)+(6.549));

} else {
	mQBFCeLZRngjClyV = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (segmentsAcked*(tcb->m_cWnd)*(16.026)*(18.134));

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (49.239+(segmentsAcked)+(62.818)+(38.995));
	tcb->m_cWnd = (int) (74.988-(24.858));

} else {
	tcb->m_segmentSize = (int) (47.608+(11.642));
	tcb->m_segmentSize = (int) (((22.43)+(38.017)+(0.1)+((37.032+(segmentsAcked)+(67.519)+(30.693)+(22.103)+(tcb->m_segmentSize)))+(0.1))/((0.1)+(2.498)+(0.1)+(29.829)));
	segmentsAcked = (int) (5.1-(24.59)-(segmentsAcked)-(87.439)-(mQBFCeLZRngjClyV));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	mQBFCeLZRngjClyV = (int) (26.864*(84.439)*(22.416)*(63.561));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	mQBFCeLZRngjClyV = (int) ((56.628-(14.911)-(tcb->m_cWnd)-(24.083)-(82.274))/0.1);

} else {
	mQBFCeLZRngjClyV = (int) (96.877*(28.493)*(49.676)*(mQBFCeLZRngjClyV));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (mQBFCeLZRngjClyV != tcb->m_cWnd) {
	mQBFCeLZRngjClyV = (int) (mQBFCeLZRngjClyV+(37.947)+(3.265)+(49.302)+(63.401)+(6.549));

} else {
	mQBFCeLZRngjClyV = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (segmentsAcked*(tcb->m_cWnd)*(16.026)*(18.134));

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (49.239+(segmentsAcked)+(62.818)+(38.995));
	tcb->m_cWnd = (int) (-72.638-(24.858));

} else {
	tcb->m_segmentSize = (int) (47.608+(11.642));
	tcb->m_segmentSize = (int) (((22.43)+(38.017)+(0.1)+((37.032+(segmentsAcked)+(67.519)+(30.693)+(22.103)+(tcb->m_segmentSize)))+(0.1))/((0.1)+(2.498)+(0.1)+(29.829)));
	segmentsAcked = (int) (5.1-(24.59)-(segmentsAcked)-(87.439)-(mQBFCeLZRngjClyV));

}
