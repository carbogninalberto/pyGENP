if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (12.51+(segmentsAcked));
	tcb->m_cWnd = (int) (tcb->m_cWnd*(25.749)*(6.311)*(23.963)*(0.377)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (24.449-(37.951)-(98.034)-(28.464)-(54.383)-(55.356)-(15.916));
	tcb->m_cWnd = (int) (12.459+(79.967)+(14.319)+(27.6)+(42.583)+(tcb->m_cWnd)+(83.871)+(tcb->m_ssThresh));

}
tcb->m_ssThresh = (int) (35.45-(72.012)-(38.053)-(75.012)-(29.554)-(segmentsAcked));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
