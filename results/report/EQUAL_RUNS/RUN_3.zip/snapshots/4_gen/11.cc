ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (-28.415-(62.193)-(76.305));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (88.636-(96.311)-(-45.911)-(83.579)-(-53.743)-(-20.199));
segmentsAcked = (int) (87.513-(-97.273)-(-37.959)-(73.989)-(-96.805)-(8.807));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
