ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (68.242-(-60.829)-(-69.761));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (83.996-(27.887)-(48.385)-(-76.558)-(-50.127)-(29.606));
ReduceCwnd (tcb);
