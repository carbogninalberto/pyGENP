int UlGUusBGbfDBmhrc = (int) (-86.444-(55.309)-(91.251)-(-44.683)-(85.322)-(-77.924));
int cunMUEGuuWqswOmN = (int) (55.682-(23.397)-(42.727)-(19.083)-(66.802)-(21.527)-(-85.876));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
