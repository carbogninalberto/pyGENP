int EDgbliiKCVwgMqFu = (int) (86.038*(19.029)*(76.327)*(-11.612)*(93.008)*(-62.945)*(53.171));
tcb->m_segmentSize = (int) (((-35.004)+(-50.698)+(94.278)+(-99.285)+(84.949)+((-17.129*(65.621)*(-58.835)*(-37.79)))+(51.918))/((57.147)+(71.98)));
if (segmentsAcked >= tcb->m_segmentSize) {
	segmentsAcked = (int) (86.989/46.403);
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (22.12*(42.283)*(72.417)*(51.269));

}
if (segmentsAcked >= tcb->m_segmentSize) {
	segmentsAcked = (int) (86.989/46.403);
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (22.12*(42.283)*(72.417)*(51.269));

}
