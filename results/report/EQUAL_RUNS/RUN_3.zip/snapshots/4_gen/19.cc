ReduceCwnd (tcb);
ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (68.198-(-52.552)-(-62.962));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (38.287-(79.484)-(-13.253)-(17.185)-(-77.446)-(-41.637));
ReduceCwnd (tcb);
