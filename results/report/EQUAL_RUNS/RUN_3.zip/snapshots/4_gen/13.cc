int EvKLvllicwWYINXW = (int) (-77.449-(-65.444)-(6.188));
ReduceCwnd (tcb);
segmentsAcked = (int) (-33.666-(24.36)-(19.973)-(98.839)-(-75.635)-(82.226));
ReduceCwnd (tcb);
segmentsAcked = (int) (-38.766-(-78.592)-(-72.273)-(61.049)-(-38.342)-(37.062));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (-3.342-(81.442)-(97.41)-(-32.012)-(49.311)-(-42.921));
ReduceCwnd (tcb);
