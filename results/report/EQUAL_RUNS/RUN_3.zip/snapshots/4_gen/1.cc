int EvKLvllicwWYINXW = (int) (-0.352-(78.574)-(-35.948));
ReduceCwnd (tcb);
segmentsAcked = (int) (64.216-(69.637)-(52.071)-(38.983)-(-7.679)-(50.305));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-74.962-(72.364)-(-70.794)-(-75.234)-(-98.067)-(50.441));
ReduceCwnd (tcb);
