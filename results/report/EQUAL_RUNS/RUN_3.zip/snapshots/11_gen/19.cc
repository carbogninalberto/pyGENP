if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_segmentSize = (int) ((15.333+(41.206)+(24.499)+(77.193)+(59.782)+(20.105))/13.709);
	segmentsAcked = (int) (18.227+(50.644)+(3.681)+(segmentsAcked));
	tcb->m_ssThresh = (int) (64.768+(54.565)+(40.164));

} else {
	tcb->m_segmentSize = (int) (70.773*(40.842)*(67.368)*(tcb->m_ssThresh)*(31.403)*(76.243)*(78.689)*(28.057));
	segmentsAcked = (int) (1.471*(tcb->m_ssThresh)*(97.211)*(4.873)*(13.445));
	segmentsAcked = (int) (42.725+(67.447)+(60.839)+(20.827)+(86.497));

}
tcb->m_segmentSize = (int) (26.604-(21.362)-(56.677)-(92.655)-(92.291)-(9.482)-(77.702)-(tcb->m_cWnd)-(70.992));
tcb->m_ssThresh = (int) (((54.571)+(0.1)+(0.1)+(0.1)+(0.1)+((78.321+(20.693)+(81.836)+(25.877)+(29.971)+(tcb->m_cWnd)+(75.767)+(tcb->m_cWnd)))+(0.1))/((61.489)+(0.1)));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(11.257)*(49.272));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (10.372-(22.969)-(11.886)-(45.025)-(5.098)-(54.05));

}
CongestionAvoidance (tcb, segmentsAcked);
