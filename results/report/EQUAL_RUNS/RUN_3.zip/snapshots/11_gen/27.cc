if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (20.422-(74.402)-(45.925)-(10.738)-(56.918)-(89.892)-(78.485));

} else {
	tcb->m_ssThresh = (int) (36.54+(92.04)+(8.055)+(50.832)+(33.228));

}
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_ssThresh = (int) (38.616/58.625);

} else {
	tcb->m_ssThresh = (int) (78.623+(tcb->m_segmentSize)+(86.963)+(62.487)+(85.107)+(0.238));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked <= tcb->m_cWnd) {
	segmentsAcked = (int) (12.933+(segmentsAcked)+(94.748)+(63.396));
	tcb->m_ssThresh = (int) (2.585-(78.186)-(tcb->m_segmentSize)-(73.758)-(tcb->m_ssThresh)-(81.872)-(96.635));
	tcb->m_ssThresh = (int) (96.449+(0.977)+(75.843)+(56.716)+(80.445)+(50.348));

} else {
	segmentsAcked = (int) (87.117-(segmentsAcked)-(64.123)-(79.911));
	tcb->m_ssThresh = (int) (56.386-(17.217)-(tcb->m_segmentSize)-(51.302)-(45.016)-(segmentsAcked)-(62.609)-(54.844));

}
float ZbkJTboZFazTadYW = (float) (16.616-(tcb->m_segmentSize)-(18.969)-(46.826)-(60.429)-(65.675)-(tcb->m_segmentSize));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (22.191+(58.847)+(60.097)+(86.659)+(tcb->m_cWnd)+(35.531)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (68.982+(18.508)+(73.036)+(tcb->m_segmentSize)+(17.97)+(segmentsAcked)+(77.187));

}
tcb->m_ssThresh = (int) (8.865+(21.292));
int KsbAEgWaAoPiOpYS = (int) (54.303-(18.239)-(39.356)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(33.348));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) (35.612+(99.28)+(99.049)+(96.63)+(24.654)+(40.323)+(ZbkJTboZFazTadYW)+(18.287)+(85.361));
	ZbkJTboZFazTadYW = (float) (tcb->m_cWnd-(ZbkJTboZFazTadYW)-(95.524)-(44.901)-(tcb->m_ssThresh)-(11.845)-(6.592)-(31.916)-(4.32));
	ZbkJTboZFazTadYW = (float) (63.094-(50.386)-(77.249)-(31.799)-(4.77)-(40.339)-(53.562)-(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) (87.755-(83.904)-(77.627)-(24.252)-(51.633));
	tcb->m_cWnd = (int) (42.527*(KsbAEgWaAoPiOpYS)*(14.141)*(tcb->m_ssThresh)*(4.059)*(3.26)*(11.935));

}
