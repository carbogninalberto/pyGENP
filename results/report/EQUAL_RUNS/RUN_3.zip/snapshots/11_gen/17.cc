tcb->m_ssThresh = (int) (0.1/52.186);
tcb->m_cWnd = (int) (3.916*(64.274)*(tcb->m_ssThresh)*(27.495)*(segmentsAcked)*(83.495)*(5.106)*(35.879));
ReduceCwnd (tcb);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((33.898)+(0.1)+(61.739)+(0.1)+(89.534)+(42.03)+((36.343*(36.145)*(59.885)))+(3.44))/((0.1)));

} else {
	tcb->m_cWnd = (int) (0.693+(38.813)+(tcb->m_cWnd));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(35.082)*(tcb->m_cWnd)*(25.693)*(tcb->m_ssThresh));
