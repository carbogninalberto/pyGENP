TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (27.057-(71.436)-(41.518)-(58.351)-(30.182)-(94.231)-(39.0)-(28.838)-(78.936));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (segmentsAcked*(49.651));

} else {
	segmentsAcked = (int) (((91.068)+(52.278)+(0.1)+(0.1))/((0.1)+(48.033)+(88.429)+(0.1)));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((15.276-(41.677)-(70.651)-(segmentsAcked)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(61.337)-(71.952))/34.047);
	segmentsAcked = (int) ((((93.73*(87.64)))+(0.1)+(0.1)+(67.21))/((0.1)));
	tcb->m_segmentSize = (int) (14.086-(36.546)-(63.531)-(8.949)-(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (((71.918)+(80.628)+(0.1)+(42.216)+(0.1))/((87.935)+(96.79)+(0.1)));
	segmentsAcked = (int) (46.472-(20.898)-(85.439)-(tcb->m_ssThresh)-(3.134)-(35.275)-(88.003)-(5.525)-(77.977));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(23.888)*(tcb->m_segmentSize)*(1.884)*(25.253)*(83.792)*(8.354)*(40.893)*(61.827));

}
