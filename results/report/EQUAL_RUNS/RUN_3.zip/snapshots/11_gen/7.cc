float xtNzRYDTPPiIEKSM = (float) (11.535*(-48.251)*(-91.675)*(-23.739)*(-21.074)*(93.886)*(36.911)*(-47.93)*(-78.689));
float aGTgvMpdAsosKPEv = (float) 79.149;
CongestionAvoidance (tcb, segmentsAcked);
aGTgvMpdAsosKPEv = (float) (23.922*(92.14)*(88.017)*(50.302)*(-59.132)*(-25.005)*(59.658)*(-32.033));
tcb->m_segmentSize = (int) (-37.636*(-1.172)*(97.368)*(30.514)*(-76.45)*(-47.481)*(96.781)*(42.725));
ReduceCwnd (tcb);
