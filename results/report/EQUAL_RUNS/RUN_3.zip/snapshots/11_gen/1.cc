int EvKLvllicwWYINXW = (int) (18.389-(99.88)-(92.108));
ReduceCwnd (tcb);
segmentsAcked = (int) (-54.067-(-17.827)-(-62.415)-(49.363)-(-61.96)-(87.412));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (30.28-(86.395)-(-40.622)-(-90.005)-(-41.658)-(33.718));
ReduceCwnd (tcb);
