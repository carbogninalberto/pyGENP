ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (-14.778-(34.678)-(-73.0));
segmentsAcked = (int) (-50.542-(-3.82)-(-91.49)-(-74.569)-(19.786)-(55.576));
ReduceCwnd (tcb);
segmentsAcked = (int) (49.582-(-84.59)-(-20.849)-(75.626)-(-44.881)-(-53.318));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (7.106-(61.88)-(-6.757)-(-8.818)-(21.392)-(-39.369));
ReduceCwnd (tcb);
