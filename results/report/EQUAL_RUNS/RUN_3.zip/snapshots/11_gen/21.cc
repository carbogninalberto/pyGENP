ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (74.58*(74.445)*(tcb->m_ssThresh)*(88.796)*(38.88)*(39.403));
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((0.875-(36.043)-(13.308)-(tcb->m_ssThresh)-(81.983)-(88.279))/2.696);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (50.299/35.461);
