ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (90.4-(76.374)-(-84.265));
segmentsAcked = (int) (67.161-(67.758)-(93.99)-(92.628)-(16.592)-(35.428));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (69.477-(-76.716)-(69.632)-(-12.046)-(84.362)-(48.74));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
