int EvKLvllicwWYINXW = (int) (10.789-(3.656)-(17.064));
ReduceCwnd (tcb);
segmentsAcked = (int) (-94.645-(-17.02)-(16.329)-(0.942)-(3.678)-(76.511));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (12.451-(84.586)-(2.784)-(-70.931)-(92.957)-(-24.095));
ReduceCwnd (tcb);
