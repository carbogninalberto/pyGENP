tcb->m_segmentSize = (int) (26.082+(96.837)+(-21.596));
