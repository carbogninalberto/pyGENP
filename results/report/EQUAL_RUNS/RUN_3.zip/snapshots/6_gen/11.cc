float foLtPkUIwqQQweVU = (float) (-49.865/35.944);
ReduceCwnd (tcb);
int nWwVoQAOkOVNrqUw = (int) (-32.24+(39.389)+(-72.125)+(-17.892)+(24.812));
float pyfbitMlUGWBCWlp = (float) (-72.651-(21.599)-(62.133)-(-44.209));
