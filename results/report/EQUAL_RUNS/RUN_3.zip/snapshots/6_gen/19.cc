float dauFSBWhLKjInIHi = (float) (34.236-(10.107)-(29.639));
int pPnJDysSVzjFqLEU = (int) (89.793*(99.138)*(46.55)*(-88.275)*(-86.189)*(-72.265)*(-10.217));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
