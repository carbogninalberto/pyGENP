int EvKLvllicwWYINXW = (int) (-97.764-(-50.162)-(-80.507));
ReduceCwnd (tcb);
segmentsAcked = (int) (73.89-(-73.271)-(45.097)-(60.25)-(56.643)-(35.421));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (49.785-(-17.006)-(47.255)-(39.023)-(60.618)-(-42.602));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
