int cTGOEDWNMomOVxfV = (int) (-82.357/58.862);
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (68.049*(8.249)*(10.406)*(85.813)*(49.287)*(0.942)*(58.208));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (0.1/9.445);
	tcb->m_cWnd = (int) (55.789-(2.983)-(55.408)-(97.276)-(25.51)-(19.35)-(85.026)-(34.806));

}
tcb->m_segmentSize = (int) (99.374/-8.445);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-65.392/-96.209);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
