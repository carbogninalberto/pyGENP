ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (69.099-(-5.823)-(-53.317));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (50.103-(-8.902)-(-63.399)-(-56.194)-(-26.704)-(-99.891));
ReduceCwnd (tcb);
