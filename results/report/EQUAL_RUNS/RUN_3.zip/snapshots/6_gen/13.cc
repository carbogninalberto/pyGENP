CongestionAvoidance (tcb, segmentsAcked);
int vIJoPriVwmfZZxlD = (int) (17.739+(35.178)+(-5.918)+(-76.611)+(-33.858)+(95.943));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
