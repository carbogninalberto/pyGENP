int EvKLvllicwWYINXW = (int) (-12.795-(38.826)-(58.08));
ReduceCwnd (tcb);
segmentsAcked = (int) (36.706-(6.441)-(-15.908)-(26.77)-(-57.685)-(26.763));
ReduceCwnd (tcb);
segmentsAcked = (int) (96.611-(23.164)-(-57.982)-(9.053)-(-28.363)-(24.289));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (-4.539-(35.217)-(49.034)-(95.478)-(36.297)-(-23.251));
ReduceCwnd (tcb);
