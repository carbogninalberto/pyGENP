TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (79.688+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(15.213)+(25.976)+(78.458)+(92.42));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(40.209)-(26.317)-(88.075));
	tcb->m_cWnd = (int) (((17.992)+(8.172)+(29.335)+((20.068-(tcb->m_cWnd)-(53.353)-(19.91)-(27.474)-(95.307)-(47.516)-(78.458)-(24.627)))+(35.929))/((51.175)+(59.281)));

} else {
	tcb->m_ssThresh = (int) (96.372-(14.604)-(76.311)-(tcb->m_segmentSize)-(64.112)-(tcb->m_segmentSize)-(27.975)-(41.377)-(65.548));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (segmentsAcked-(tcb->m_cWnd)-(37.185)-(78.116)-(97.596)-(91.628)-(48.68)-(tcb->m_ssThresh));

}
tcb->m_segmentSize = (int) (6.956+(78.479));
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(55.694)-(50.937)-(13.666)-(69.78)-(93.552)-(86.999)-(57.529)-(73.391));
	tcb->m_cWnd = (int) ((33.326-(tcb->m_segmentSize)-(88.113)-(2.02)-(segmentsAcked)-(tcb->m_ssThresh)-(48.623)-(23.549)-(96.393))/76.399);
	segmentsAcked = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (13.631-(segmentsAcked)-(8.447)-(67.427));

}
