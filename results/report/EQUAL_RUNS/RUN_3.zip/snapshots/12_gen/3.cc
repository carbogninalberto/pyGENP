ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (62.184-(-23.49)-(51.402));
segmentsAcked = (int) (-86.784-(98.824)-(36.261)-(40.508)-(-51.753)-(-35.779));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-80.242-(63.715)-(24.115)-(76.085)-(-83.945)-(-60.171));
ReduceCwnd (tcb);
