int GpnINqmhImDQYAHV = (int) 42.139;
segmentsAcked = SlowStart (tcb, segmentsAcked);
float uixGBNJYpRjbLLzZ = (float) 41.646;
tcb->m_segmentSize = (int) (-19.923/33.893);
tcb->m_segmentSize = (int) (-35.72*(-72.81));
tcb->m_segmentSize = (int) ((66.505*(64.564)*(-85.252)*(-19.428))/-27.459);
