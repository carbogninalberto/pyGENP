float aGTgvMpdAsosKPEv = (float) 6.851;
