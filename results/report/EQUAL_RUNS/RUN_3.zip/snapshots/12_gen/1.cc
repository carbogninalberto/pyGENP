int EvKLvllicwWYINXW = (int) (52.459-(55.045)-(-60.779));
ReduceCwnd (tcb);
segmentsAcked = (int) (89.334-(-52.32)-(-26.553)-(16.383)-(12.604)-(88.906));
ReduceCwnd (tcb);
segmentsAcked = (int) (36.795-(-13.161)-(73.424)-(8.177)-(-58.629)-(-48.76));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (-47.434-(-38.323)-(28.81)-(3.427)-(92.627)-(-70.038));
ReduceCwnd (tcb);
