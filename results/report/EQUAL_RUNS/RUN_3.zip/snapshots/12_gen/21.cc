tcb->m_segmentSize = (int) (49.4+(39.543)+(tcb->m_ssThresh)+(7.462)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(91.515)+(72.644)+(22.6));
tcb->m_ssThresh = (int) (45.53-(55.95)-(tcb->m_ssThresh));
tcb->m_segmentSize = (int) (78.995+(tcb->m_cWnd)+(tcb->m_cWnd)+(98.723)+(30.653)+(94.594)+(tcb->m_ssThresh)+(50.283)+(tcb->m_cWnd));
segmentsAcked = (int) (0.1/0.1);
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (44.345*(tcb->m_segmentSize)*(57.254)*(40.598)*(tcb->m_ssThresh)*(62.092));

} else {
	tcb->m_ssThresh = (int) (83.567+(51.465)+(tcb->m_segmentSize)+(10.027)+(94.27)+(46.821)+(17.732)+(6.09));
	segmentsAcked = (int) (72.842*(79.597)*(11.554));

}
