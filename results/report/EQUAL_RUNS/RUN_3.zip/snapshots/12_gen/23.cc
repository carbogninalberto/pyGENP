segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd-(97.86)-(92.601)-(34.291));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (21.139+(62.65)+(31.577)+(60.688)+(64.398)+(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (57.073+(73.211)+(20.718)+(19.656));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (55.186-(tcb->m_cWnd)-(37.668));
segmentsAcked = (int) (tcb->m_ssThresh*(50.949)*(34.112)*(segmentsAcked)*(28.557)*(89.805)*(90.716)*(tcb->m_ssThresh));
segmentsAcked = SlowStart (tcb, segmentsAcked);
