CongestionAvoidance (tcb, segmentsAcked);
float pcQMPfbjegiWNUmT = (float) (12.908*(-98.608)*(59.219)*(40.08));
segmentsAcked = SlowStart (tcb, segmentsAcked);
