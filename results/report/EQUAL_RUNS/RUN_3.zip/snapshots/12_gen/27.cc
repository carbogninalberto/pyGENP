ReduceCwnd (tcb);
tcb->m_cWnd = (int) (0.1/0.1);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (40.741*(26.72)*(38.769)*(segmentsAcked)*(11.864)*(56.45)*(49.79)*(85.318)*(62.005));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(tcb->m_segmentSize)+(44.614)+(29.442)+(83.233)+(13.863)+(tcb->m_cWnd)+(93.23)+(91.486));

}
tcb->m_segmentSize = (int) (0.1/88.004);
int xvUiYwbVxClXigPy = (int) ((((93.585+(9.869)+(segmentsAcked)+(44.066)+(1.353)+(1.298)))+(87.755)+(0.1)+(0.1)+(46.002))/((16.648)+(84.919)+(0.1)+(97.104)));
tcb->m_ssThresh = (int) (((37.585)+(0.1)+(0.1)+(0.1))/((53.531)+(0.1)));
