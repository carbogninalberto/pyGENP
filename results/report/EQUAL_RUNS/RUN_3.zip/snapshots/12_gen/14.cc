int TBakewcrgAxmyjlE = (int) (68.739-(55.051));
tcb->m_cWnd = (int) (29.416*(2.863)*(67.963)*(10.752)*(45.009)*(2.745));
int XWYtjNKTWFdNEcSO = (int) (12.285-(14.639)-(76.064)-(87.924)-(47.103));
tcb->m_segmentSize = (int) (((0.1)+(0.1)+((82.807*(88.069)*(95.319)*(27.956)))+(9.773))/((8.85)));
if (XWYtjNKTWFdNEcSO >= XWYtjNKTWFdNEcSO) {
	XWYtjNKTWFdNEcSO = (int) (2.649+(82.88)+(80.254)+(0.539)+(tcb->m_cWnd)+(68.013)+(30.27));
	TBakewcrgAxmyjlE = (int) (70.498-(tcb->m_segmentSize));
	TBakewcrgAxmyjlE = (int) (((36.178)+(0.1)+(54.893)+(0.1)+(0.1)+(58.446))/((0.1)+(27.408)+(26.023)));

} else {
	XWYtjNKTWFdNEcSO = (int) (tcb->m_cWnd*(46.362));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (segmentsAcked >= segmentsAcked) {
	tcb->m_ssThresh = (int) (0.1/75.512);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (40.233+(TBakewcrgAxmyjlE)+(38.25)+(65.162)+(19.764)+(51.548));
	TBakewcrgAxmyjlE = (int) (0.1/61.399);

}
