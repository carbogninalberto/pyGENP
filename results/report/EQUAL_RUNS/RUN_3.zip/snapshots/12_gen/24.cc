segmentsAcked = (int) (0.1/73.058);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (tcb->m_ssThresh-(29.887)-(17.015)-(68.286));
tcb->m_cWnd = (int) (84.884+(segmentsAcked)+(65.104)+(68.11)+(22.851)+(79.447));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
