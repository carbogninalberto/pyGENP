int cunMUEGuuWqswOmN = (int) (74.15-(28.011)-(75.49)-(13.473)-(-68.887)-(6.218)-(-68.581));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
