float pgMVGONVGIHtJXIa = (float) (32.772*(-52.998)*(41.046));
ReduceCwnd (tcb);
int nYBQQlHOcKOLzjsA = (int) ((-80.163+(90.679)+(-59.829)+(-65.079)+(-0.399)+(28.484)+(-73.076))/71.722);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
