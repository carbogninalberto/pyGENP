ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (-91.574-(24.263)-(38.38));
segmentsAcked = (int) (-37.936-(51.42)-(-15.362)-(5.012)-(-80.167)-(45.347));
ReduceCwnd (tcb);
segmentsAcked = (int) (44.455-(73.008)-(-51.636)-(-62.773)-(-76.166)-(94.247));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (-95.647-(61.981)-(34.115)-(70.505)-(-35.78)-(42.704));
ReduceCwnd (tcb);
