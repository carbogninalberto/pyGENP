tcb->m_cWnd = (int) (tcb->m_segmentSize+(30.918)+(71.897)+(25.54));
segmentsAcked = (int) (56.105+(43.135)+(37.246)+(5.444));
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_ssThresh = (int) (30.551*(27.659)*(90.215)*(16.577)*(45.816)*(51.841)*(75.122)*(63.596));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (23.6*(28.85)*(70.143)*(44.922));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
float meyQXbYMlkhXOTtK = (float) (23.665-(36.005));
ReduceCwnd (tcb);
