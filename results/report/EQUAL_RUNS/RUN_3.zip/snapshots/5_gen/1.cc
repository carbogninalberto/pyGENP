ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (-13.763-(85.359)-(86.388));
segmentsAcked = (int) (96.367-(-57.476)-(-40.903)-(-10.105)-(80.92)-(71.107));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (4.71-(22.0)-(3.463)-(31.31)-(74.876)-(44.254));
ReduceCwnd (tcb);
