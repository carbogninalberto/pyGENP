int pPnJDysSVzjFqLEU = (int) (78.055*(84.823)*(-77.72)*(1.276)*(43.006)*(27.77)*(67.428));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (50.218+(65.986)+(17.584)+(9.309)+(19.818)+(55.523)+(10.04));
	segmentsAcked = (int) (0.1/87.863);

} else {
	tcb->m_cWnd = (int) (27.427-(73.686));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
