int AVhnNCefnJVJLuIL = (int) (22.786+(-83.385)+(-73.21)+(23.735)+(-41.443));
segmentsAcked = SlowStart (tcb, segmentsAcked);
AVhnNCefnJVJLuIL = (int) (4.95-(-40.642)-(-50.617)-(89.926)-(-63.371)-(-20.65));
if (segmentsAcked >= AVhnNCefnJVJLuIL) {
	segmentsAcked = (int) (98.874-(65.538)-(28.535)-(tcb->m_cWnd)-(94.366)-(88.866)-(16.062));
	AVhnNCefnJVJLuIL = (int) (54.563+(67.506)+(79.089)+(24.251));

} else {
	segmentsAcked = (int) (70.79+(54.927)+(68.471)+(91.501));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
