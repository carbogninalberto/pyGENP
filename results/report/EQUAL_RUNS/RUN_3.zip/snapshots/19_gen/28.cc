int AVhnNCefnJVJLuIL = (int) (1.9+(7.462)+(-79.575)+(-84.16)+(-33.071));
