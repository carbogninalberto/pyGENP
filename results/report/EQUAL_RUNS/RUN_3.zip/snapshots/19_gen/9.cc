ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (67.777-(-89.86)-(84.721));
segmentsAcked = (int) (99.478-(-80.18)-(76.742)-(-16.8)-(-27.275)-(16.659));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (94.263-(-6.406)-(-43.517)-(58.469)-(-73.225)-(2.679));
ReduceCwnd (tcb);
