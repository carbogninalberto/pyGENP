if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (97.316+(tcb->m_cWnd)+(80.041)+(76.071)+(7.807)+(78.771)+(58.56)+(41.166));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(35.87)*(14.522)*(59.372)*(56.999)*(20.306)*(26.402)*(89.674));

} else {
	tcb->m_cWnd = (int) (45.388*(82.536)*(11.501)*(69.42)*(21.516)*(segmentsAcked)*(3.068));

}
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (67.374-(91.231)-(40.373)-(77.387)-(-41.425));

} else {
	segmentsAcked = (int) (54.65/0.1);
	tcb->m_cWnd = (int) (3.213-(22.447)-(tcb->m_segmentSize));

}
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
