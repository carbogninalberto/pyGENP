float DFKXFvMseLsInzUg = (float) 87.765;
