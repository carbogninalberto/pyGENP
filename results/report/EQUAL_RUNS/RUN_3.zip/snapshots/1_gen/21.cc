ReduceCwnd (tcb);
int BLfVGhufxVPssprt = (int) (12.77/0.1);
int bzUuiFqXVnEmPKJk = (int) (70.535*(38.731)*(59.192)*(91.104)*(12.1)*(52.104)*(38.157)*(6.415)*(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
bzUuiFqXVnEmPKJk = (int) (49.465+(35.678)+(30.644)+(2.877)+(tcb->m_ssThresh)+(20.567)+(2.15)+(16.639));
tcb->m_ssThresh = (int) (tcb->m_ssThresh-(BLfVGhufxVPssprt)-(94.529)-(4.047)-(58.347));
segmentsAcked = SlowStart (tcb, segmentsAcked);
