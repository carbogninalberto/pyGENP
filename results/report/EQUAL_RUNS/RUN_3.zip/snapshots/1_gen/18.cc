tcb->m_segmentSize = (int) (1.446-(58.911)-(65.314)-(66.789)-(77.68)-(tcb->m_segmentSize));
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (33.036-(40.525)-(77.723)-(tcb->m_ssThresh)-(25.454)-(39.288)-(tcb->m_ssThresh)-(20.264));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (68.271*(42.987)*(19.544)*(92.987)*(34.634)*(segmentsAcked));

}
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (46.783/78.218);
	tcb->m_cWnd = (int) (29.742-(9.486)-(52.966)-(29.551));
	tcb->m_ssThresh = (int) (19.728*(33.262)*(98.289)*(86.795)*(58.365)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (56.675-(segmentsAcked)-(0.212)-(96.342)-(43.743)-(5.19)-(63.796));
	tcb->m_cWnd = (int) (7.291+(63.013)+(tcb->m_segmentSize));

}
tcb->m_ssThresh = (int) (40.542+(76.027)+(32.008)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(55.84)+(79.412)+(49.202));
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (12.821/0.1);

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(90.377));
	segmentsAcked = (int) (tcb->m_cWnd+(78.178)+(85.072)+(91.782)+(34.752)+(12.277)+(tcb->m_ssThresh));

}
