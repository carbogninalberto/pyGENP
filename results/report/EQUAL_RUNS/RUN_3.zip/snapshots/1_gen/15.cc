if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_ssThresh = (int) (38.641/0.1);

} else {
	tcb->m_ssThresh = (int) (0.448-(45.515)-(40.294)-(70.232)-(53.324)-(8.698));
	tcb->m_ssThresh = (int) (42.002+(84.287)+(6.107));

}
tcb->m_segmentSize = (int) (tcb->m_ssThresh+(tcb->m_segmentSize)+(81.035)+(18.826)+(32.897)+(4.346)+(85.261)+(15.536));
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((0.1)+(67.681)+(0.1)+(98.103)+(0.1))/((77.426)+(0.1)+(78.874)));
	tcb->m_segmentSize = (int) (37.143*(26.022)*(80.216)*(tcb->m_cWnd)*(20.718)*(74.406));

} else {
	tcb->m_ssThresh = (int) (13.629*(60.428)*(tcb->m_segmentSize)*(75.692)*(56.056)*(97.493));
	segmentsAcked = (int) (tcb->m_cWnd-(42.638));

}
tcb->m_segmentSize = (int) (97.765+(85.035)+(51.684)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(34.331)+(91.776)+(30.618)+(71.455));
tcb->m_ssThresh = (int) (59.867-(20.186)-(tcb->m_cWnd)-(21.29)-(18.553)-(segmentsAcked)-(57.789)-(15.197));
tcb->m_segmentSize = (int) (tcb->m_ssThresh+(47.283)+(tcb->m_segmentSize)+(18.138));
float IHlPbNYMdkbqnjcY = (float) (89.184+(segmentsAcked)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(97.779)+(74.19)+(tcb->m_segmentSize)+(31.72)+(91.417));
if (IHlPbNYMdkbqnjcY < tcb->m_segmentSize) {
	IHlPbNYMdkbqnjcY = (float) (26.752*(48.196)*(63.414));
	tcb->m_cWnd = (int) (57.896*(23.649)*(89.751)*(14.139)*(24.058)*(82.957)*(84.303)*(82.268));

} else {
	IHlPbNYMdkbqnjcY = (float) (8.155-(19.997)-(81.856)-(99.848)-(tcb->m_cWnd)-(27.5)-(63.401));

}
