if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (52.525/33.878);

} else {
	tcb->m_cWnd = (int) (60.105*(segmentsAcked)*(segmentsAcked)*(17.357)*(25.025)*(48.13)*(tcb->m_ssThresh)*(73.851));

}
tcb->m_cWnd = (int) (97.83-(12.817));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (54.47-(42.618));

} else {
	tcb->m_segmentSize = (int) (89.286+(7.832));

}
CongestionAvoidance (tcb, segmentsAcked);
