float vHwXZAOhbZpwgCnD = (float) (58.01*(82.39)*(tcb->m_ssThresh)*(85.301)*(8.521)*(53.035)*(29.432)*(71.208));
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (25.81*(80.428)*(segmentsAcked)*(61.786));
	vHwXZAOhbZpwgCnD = (float) (9.187+(tcb->m_cWnd)+(14.027));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (4.157*(7.493));

}
float PAhYUvEvdMpckRNB = (float) (75.908*(57.049)*(20.788)*(tcb->m_ssThresh)*(vHwXZAOhbZpwgCnD)*(tcb->m_cWnd));
tcb->m_cWnd = (int) (62.476/0.1);
float ihMEIKNvZFpafEQR = (float) (80.769+(90.727)+(vHwXZAOhbZpwgCnD)+(76.012)+(2.119)+(45.703));
if (tcb->m_segmentSize <= ihMEIKNvZFpafEQR) {
	tcb->m_segmentSize = (int) (81.539-(5.707)-(tcb->m_ssThresh)-(2.472)-(28.994)-(tcb->m_cWnd)-(47.975)-(47.422)-(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (36.672+(94.329)+(92.912)+(59.398)+(PAhYUvEvdMpckRNB)+(95.848)+(23.754));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) ((57.779*(46.647)*(82.95)*(35.131)*(92.826)*(58.897))/0.1);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (25.582/0.1);
	tcb->m_segmentSize = (int) (PAhYUvEvdMpckRNB+(9.51)+(1.147)+(36.503)+(47.142)+(2.853)+(37.002)+(70.223)+(29.597));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (31.582*(70.529)*(segmentsAcked)*(78.613)*(83.647)*(ihMEIKNvZFpafEQR)*(vHwXZAOhbZpwgCnD));
	tcb->m_cWnd = (int) (62.075*(17.375)*(62.573));

}
