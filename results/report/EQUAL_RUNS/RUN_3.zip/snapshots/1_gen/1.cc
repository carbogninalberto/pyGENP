if (segmentsAcked == segmentsAcked) {
	tcb->m_cWnd = (int) (17.454+(39.024)+(17.855)+(55.664)+(73.966)+(57.887)+(33.683)+(tcb->m_ssThresh)+(64.444));
	tcb->m_ssThresh = (int) (47.025+(31.342)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(92.986));
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (66.775*(26.913)*(22.536)*(55.921));
	tcb->m_ssThresh = (int) (28.126*(7.958)*(10.798)*(38.875)*(69.957)*(segmentsAcked)*(59.146));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (19.549*(66.109)*(16.931)*(27.257)*(96.564));
float qirPGtMBmSzVPLpr = (float) (tcb->m_cWnd-(97.38)-(59.632)-(segmentsAcked)-(41.58)-(62.557)-(71.181)-(44.923));
int YatGUdMTxNTNBxMp = (int) (1.627+(31.182)+(78.406)+(0.948));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
