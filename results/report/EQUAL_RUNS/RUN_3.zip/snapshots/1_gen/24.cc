int EvKLvllicwWYINXW = (int) (tcb->m_segmentSize-(40.433)-(29.338));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (38.54-(94.928)-(32.563));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (72.101*(34.989)*(62.373)*(segmentsAcked));

}
segmentsAcked = (int) (56.728-(42.765)-(tcb->m_cWnd)-(86.908)-(tcb->m_ssThresh)-(56.756));
ReduceCwnd (tcb);
