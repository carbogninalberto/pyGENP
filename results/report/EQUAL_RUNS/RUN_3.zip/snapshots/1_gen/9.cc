tcb->m_cWnd = (int) (33.998-(segmentsAcked)-(50.626)-(58.412));
float qZFQXTwhVaHxxTau = (float) (62.706/89.314);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (90.433+(qZFQXTwhVaHxxTau)+(27.176)+(46.553)+(tcb->m_cWnd)+(66.816)+(24.164)+(73.383));
tcb->m_ssThresh = (int) (34.153-(tcb->m_segmentSize)-(85.52)-(45.201));
