tcb->m_cWnd = (int) (61.134+(96.46)+(52.553)+(81.584)+(69.086)+(99.269)+(38.187)+(94.291)+(7.72));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_segmentSize-(57.485)-(9.341));

} else {
	segmentsAcked = (int) (46.424*(81.909)*(tcb->m_ssThresh)*(tcb->m_ssThresh));

}
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (49.907+(1.122)+(47.503));
	tcb->m_segmentSize = (int) (((80.532)+(0.1)+(0.1)+(21.903))/((0.1)+(99.638)+(98.475)+(38.381)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (0.1/32.23);
	tcb->m_cWnd = (int) (7.868+(2.084)+(51.205)+(tcb->m_ssThresh)+(1.435));

}
