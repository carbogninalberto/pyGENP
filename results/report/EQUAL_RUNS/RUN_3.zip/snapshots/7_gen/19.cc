tcb->m_segmentSize = (int) (4.079-(46.255)-(46.804));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (((96.762)+(25.334)+(12.502)+(65.606)+(32.31))/((66.397)+(7.183)+(85.937)));
tcb->m_cWnd = (int) (7.987-(-33.198)-(-50.944)-(-41.758)-(70.233)-(-86.218)-(-70.665)-(-78.061)-(10.253));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (((-83.099)+(5.954)+(90.92)+(-35.814)+(26.797))/((32.712)+(-62.309)+(-6.521)));
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (16.536/0.1);
	tcb->m_cWnd = (int) (1.533-(92.037)-(6.701)-(tcb->m_cWnd)-(51.408)-(20.359));

} else {
	tcb->m_cWnd = (int) (36.926*(88.106)*(tcb->m_segmentSize)*(61.417)*(7.704)*(tcb->m_cWnd)*(8.65)*(82.621)*(44.764));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (((-40.328)+(61.953)+(38.659)+(-84.445)+(-6.414))/((26.854)+(-83.487)+(0.054)));
tcb->m_cWnd = (int) (22.204-(55.946)-(-97.932)-(39.394)-(-45.909)-(54.757)-(10.838)-(-77.234)-(-89.138));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (((-64.695)+(-94.988)+(34.695)+(-48.458)+(86.824))/((10.406)+(31.971)+(40.82)));
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (36.926*(88.106)*(tcb->m_segmentSize)*(61.417)*(7.704)*(tcb->m_cWnd)*(8.65)*(82.621)*(44.764));

} else {
	tcb->m_cWnd = (int) (16.536/0.1);
	tcb->m_cWnd = (int) (1.533-(92.037)-(6.701)-(tcb->m_cWnd)-(51.408)-(20.359));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
