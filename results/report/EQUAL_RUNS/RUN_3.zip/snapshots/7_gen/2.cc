ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (68.102-(0.875)-(46.311));
segmentsAcked = (int) (-89.73-(94.236)-(-32.9)-(-59.136)-(-68.713)-(-45.51));
ReduceCwnd (tcb);
segmentsAcked = (int) (18.091-(35.92)-(3.251)-(37.158)-(80.646)-(41.404));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (-50.942-(-93.007)-(-52.341)-(40.678)-(-51.357)-(-41.135));
ReduceCwnd (tcb);
