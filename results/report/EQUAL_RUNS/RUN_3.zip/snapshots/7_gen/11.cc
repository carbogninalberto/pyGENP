int avKkxcjWHLdYgkuH = (int) (-33.742-(0.47)-(-79.733)-(-65.903)-(46.384)-(-2.399)-(-5.51)-(-42.174)-(-70.43));
if (segmentsAcked >= tcb->m_segmentSize) {
	segmentsAcked = (int) (38.573/14.685);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (97.37+(tcb->m_cWnd)+(91.154)+(35.368)+(66.115)+(17.438)+(87.685)+(36.31));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = (int) (-2.91/99.369);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-17.61*(94.086)*(-46.427));
tcb->m_cWnd = (int) (-90.279*(-19.26)*(-52.347));
ReduceCwnd (tcb);
