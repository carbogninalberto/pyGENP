int wMKBWGdkTfcfJnqN = (int) ((((-56.206*(63.041)))+((-36.667*(-2.363)*(30.724)*(-8.372)*(53.697)*(41.342)*(-53.578)*(-0.239)))+((9.728-(29.816)-(-59.001)-(42.328)))+(84.5)+(39.001)+(74.852)+((92.573*(-5.929)*(-70.089)*(42.548)))+(28.781))/((-16.53)));
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (49.794-(45.301)-(12.231)-(13.761)-(44.58)-(segmentsAcked));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (62.937-(69.517)-(44.538)-(-17.927));

}
CongestionAvoidance (tcb, segmentsAcked);
