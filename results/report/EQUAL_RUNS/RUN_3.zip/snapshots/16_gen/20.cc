segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(39.924)+((tcb->m_segmentSize*(segmentsAcked)*(89.225)*(85.297)*(30.509)*(93.599)*(65.845)*(60.598)))+(34.242))/((20.671)+(0.1)+(56.566)));
int ktshNnicFJyRidDa = (int) (44.919*(75.722)*(tcb->m_segmentSize)*(98.345)*(tcb->m_cWnd)*(7.86)*(67.901)*(42.767));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) (((0.1)+(0.1)+(61.387)+((segmentsAcked-(88.65)-(46.901)-(44.35)-(70.732)-(87.834)-(80.607)))+(0.1))/((39.051)));
	ktshNnicFJyRidDa = (int) (97.973+(94.687)+(1.416)+(71.237)+(17.353)+(64.823)+(31.636)+(0.438)+(43.882));
	ktshNnicFJyRidDa = (int) (((43.812)+(0.1)+(0.1)+(54.627))/((93.853)+(64.245)+(0.1)+(0.1)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(57.766));
	CongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
