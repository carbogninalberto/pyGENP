int EvKLvllicwWYINXW = (int) (59.872-(19.057)-(-28.056));
ReduceCwnd (tcb);
segmentsAcked = (int) (-33.077-(-92.963)-(-44.805)-(-51.445)-(75.027)-(-34.929));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-77.878-(89.867)-(80.159)-(-69.633)-(-76.251)-(31.116));
ReduceCwnd (tcb);
