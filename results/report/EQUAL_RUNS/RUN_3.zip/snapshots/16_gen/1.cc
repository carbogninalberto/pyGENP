tcb->m_cWnd = (int) (70.728+(-60.476)+(60.044)+(-85.463)+(-51.927)+(31.135)+(16.347)+(-81.243)+(89.154));
tcb->m_cWnd = (int) (-57.793*(-41.983)*(-38.319)*(-46.202)*(-84.061));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (27.373+(73.322)+(54.005)+(62.959)+(36.705));
	segmentsAcked = (int) ((37.734*(11.308)*(1.708)*(59.603)*(64.462)*(43.829)*(segmentsAcked)*(25.762)*(tcb->m_ssThresh))/(16.413*(tcb->m_ssThresh)*(61.484)*(80.819)*(tcb->m_cWnd)*(21.726)));

} else {
	tcb->m_cWnd = (int) (86.382+(32.625)+(65.499));
	tcb->m_cWnd = (int) ((tcb->m_segmentSize+(69.695)+(65.712)+(tcb->m_segmentSize)+(9.119)+(tcb->m_segmentSize)+(51.273)+(92.978)+(9.769))/0.1);

}
