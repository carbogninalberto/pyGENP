TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (72.897+(62.475)+(9.141)+(98.858));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize-(12.15)-(tcb->m_cWnd)-(60.768)-(82.331));

}
ReduceCwnd (tcb);
int kVUDwMmcXZVkpHDt = (int) (0.1/(2.576+(16.373)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float slSkNLuTsNPcOnaF = (float) (64.057+(segmentsAcked)+(10.296)+(19.615)+(tcb->m_cWnd)+(segmentsAcked)+(76.286)+(83.203)+(80.292));
