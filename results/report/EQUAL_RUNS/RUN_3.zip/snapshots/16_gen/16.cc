if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (21.276-(3.555)-(94.916)-(tcb->m_segmentSize)-(98.725));
	tcb->m_segmentSize = (int) (48.017*(95.624));

} else {
	tcb->m_segmentSize = (int) (22.346+(60.19)+(76.172)+(98.583));
	ReduceCwnd (tcb);

}
int LOIbjlQZoNrDypeo = (int) (11.321+(67.61));
tcb->m_cWnd = (int) (36.242-(87.557)-(25.265)-(-17.856)-(21.938)-(73.18));
tcb->m_cWnd = (int) (44.268*(-71.885)*(85.74)*(-23.304)*(-2.716)*(17.591)*(77.128));
