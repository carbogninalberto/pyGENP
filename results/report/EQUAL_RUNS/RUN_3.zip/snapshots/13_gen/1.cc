ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (-69.054-(-90.022)-(31.925));
segmentsAcked = (int) (24.657-(-15.457)-(-49.262)-(-3.247)-(44.015)-(-67.416));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (70.383-(30.713)-(-28.116)-(-49.174)-(-75.653)-(-44.206));
ReduceCwnd (tcb);
