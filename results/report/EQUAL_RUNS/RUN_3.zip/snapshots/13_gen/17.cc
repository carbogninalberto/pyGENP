ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (-77.647-(71.993)-(47.324));
segmentsAcked = (int) (82.322-(91.004)-(63.195)-(19.247)-(34.986)-(-52.851));
ReduceCwnd (tcb);
segmentsAcked = (int) (77.099-(72.296)-(-88.446)-(56.476)-(31.426)-(18.346));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (-36.272-(-60.077)-(40.45)-(90.598)-(-7.231)-(39.096));
ReduceCwnd (tcb);
