int XWYtjNKTWFdNEcSO = (int) (57.252-(73.756)-(63.742)-(-16.095)-(-75.789));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (36.363*(27.067)*(32.749)*(71.367)*(49.18)*(87.85));
int TBakewcrgAxmyjlE = (int) 53.675;
tcb->m_segmentSize = (int) (((-45.726)+(-6.828)+((30.556*(38.783)*(-2.859)*(-41.693)))+(59.18))/((91.274)));
if (XWYtjNKTWFdNEcSO >= XWYtjNKTWFdNEcSO) {
	XWYtjNKTWFdNEcSO = (int) (2.649+(82.88)+(80.254)+(0.539)+(tcb->m_cWnd)+(68.013)+(30.27));
	TBakewcrgAxmyjlE = (int) (70.498-(tcb->m_segmentSize));
	TBakewcrgAxmyjlE = (int) (((36.178)+(0.1)+(54.893)+(0.1)+(0.1)+(58.446))/((0.1)+(27.408)+(26.023)));

} else {
	XWYtjNKTWFdNEcSO = (int) (tcb->m_cWnd*(46.362));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
