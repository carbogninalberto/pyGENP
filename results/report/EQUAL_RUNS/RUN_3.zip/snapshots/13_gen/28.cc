float pcQMPfbjegiWNUmT = (float) (5.084*(40.086)*(83.671)*(-11.944));
segmentsAcked = (int) (47.157/(tcb->m_segmentSize-(22.254)-(14.742)-(66.899)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
