float UYxMvBjfAHJfybtX = (float) 24.222;
tcb->m_cWnd = (int) (12.669-(54.328)-(38.386)-(-77.4)-(37.228));
float DfvKHTkeaLCGGZzu = (float) 97.24;
