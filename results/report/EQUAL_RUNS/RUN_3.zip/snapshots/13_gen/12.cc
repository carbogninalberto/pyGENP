if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) ((tcb->m_ssThresh+(41.383)+(tcb->m_ssThresh)+(segmentsAcked)+(segmentsAcked)+(59.176)+(77.837)+(29.321))/0.1);

} else {
	segmentsAcked = (int) (((24.113)+((64.349-(45.938)-(5.067)-(99.468)))+(69.071)+(79.23)+(51.607))/((0.1)+(0.1)));

}
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (segmentsAcked*(78.692));
	segmentsAcked = (int) (15.231+(9.65)+(18.41)+(-16.304)+(76.83)+(40.708)+(96.64)+(17.818)+(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (41.619-(62.959)-(4.887)-(86.057)-(71.519)-(24.497)-(78.576)-(15.601)-(24.404));

}
