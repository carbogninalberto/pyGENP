segmentsAcked = (int) (-32.797*(38.563)*(-67.045)*(27.963)*(86.008)*(-4.602));
segmentsAcked = (int) (52.123-(10.895)-(29.355)-(-42.114));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (57.073+(73.211)+(20.718)+(19.656));

} else {
	tcb->m_cWnd = (int) (21.139+(62.65)+(31.577)+(60.688)+(64.398)+(tcb->m_cWnd));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (66.869-(-14.627)-(-15.921));
segmentsAcked = (int) (-38.827*(-54.008)*(88.346)*(-32.64)*(-99.373)*(0.137)*(-69.351)*(65.831));
segmentsAcked = SlowStart (tcb, segmentsAcked);
