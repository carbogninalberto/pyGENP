int EvKLvllicwWYINXW = (int) (50.413-(36.688)-(-55.789));
ReduceCwnd (tcb);
segmentsAcked = (int) (90.547-(95.405)-(-23.42)-(-35.376)-(30.169)-(83.779));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-7.357-(-11.672)-(1.096)-(94.732)-(88.642)-(-95.207));
ReduceCwnd (tcb);
