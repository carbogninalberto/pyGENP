float DfvKHTkeaLCGGZzu = (float) (((37.879)+(81.805)+(40.938)+(-92.704))/((54.481)+(70.49)));
float UYxMvBjfAHJfybtX = (float) 66.802;
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
