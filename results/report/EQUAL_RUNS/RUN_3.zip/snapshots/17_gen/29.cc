segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (42.101-(57.747)-(23.932)-(94.633)-(tcb->m_segmentSize)-(79.165)-(13.191));

} else {
	tcb->m_segmentSize = (int) (0.1/4.061);

}
float IFJGNQxKzWFGxXFu = (float) (tcb->m_ssThresh+(50.704)+(tcb->m_cWnd)+(32.99)+(89.896));
if (IFJGNQxKzWFGxXFu > segmentsAcked) {
	tcb->m_cWnd = (int) (9.719*(64.879));

} else {
	tcb->m_cWnd = (int) (((9.887)+(0.1)+(0.1)+((tcb->m_ssThresh*(62.693)*(49.274)*(38.992)*(93.091)*(17.401)*(tcb->m_segmentSize)*(52.22)))+(0.1))/((0.1)+(56.153)));

}
tcb->m_segmentSize = (int) (40.236-(45.334)-(tcb->m_cWnd)-(62.326));
int GwwaORfrHmJBsSSP = (int) (49.612-(2.056)-(85.026)-(51.263));
if (GwwaORfrHmJBsSSP >= IFJGNQxKzWFGxXFu) {
	tcb->m_ssThresh = (int) (segmentsAcked-(tcb->m_ssThresh)-(34.138)-(93.445)-(IFJGNQxKzWFGxXFu)-(GwwaORfrHmJBsSSP)-(50.562)-(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) ((((77.037+(63.575)+(tcb->m_cWnd)+(84.955)+(GwwaORfrHmJBsSSP)+(26.692)+(tcb->m_segmentSize)+(86.275)+(10.195)))+(24.831)+(41.898)+(0.1)+(22.698)+(38.549)+(29.05))/((0.1)));

}
