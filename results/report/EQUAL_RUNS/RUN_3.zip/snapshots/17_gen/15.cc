ReduceCwnd (tcb);
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	segmentsAcked = (int) (26.063*(12.079));

} else {
	segmentsAcked = (int) (65.083/0.1);
	tcb->m_ssThresh = (int) (98.824*(50.344)*(59.913)*(tcb->m_segmentSize)*(54.099)*(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (17.939*(80.386)*(tcb->m_cWnd)*(segmentsAcked)*(53.109)*(46.993));

}
float DNrafSkMHOHaUyBR = (float) (29.361-(85.039)-(99.742)-(74.58)-(tcb->m_cWnd)-(26.429)-(tcb->m_cWnd)-(11.801));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) (77.403*(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (5.214*(6.951)*(71.588)*(27.495)*(93.471));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (18.994*(tcb->m_segmentSize)*(17.285)*(84.557));

}
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (79.322+(97.885)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(6.412)+(12.925));

} else {
	tcb->m_segmentSize = (int) (16.159-(tcb->m_cWnd)-(66.482)-(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
