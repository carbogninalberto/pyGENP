segmentsAcked = (int) (60.742*(45.973)*(81.052));
segmentsAcked = SlowStart (tcb, segmentsAcked);
