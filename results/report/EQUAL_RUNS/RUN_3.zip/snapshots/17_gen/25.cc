if (tcb->m_cWnd > tcb->m_cWnd) {
	segmentsAcked = (int) (19.913*(56.263)*(54.768)*(20.697)*(tcb->m_segmentSize)*(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (48.95+(92.93)+(12.091)+(9.786)+(10.103)+(68.728)+(88.846));

}
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked == segmentsAcked) {
	segmentsAcked = (int) (59.876-(13.602)-(84.785)-(82.584)-(98.143)-(51.224)-(51.306)-(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (88.621-(tcb->m_segmentSize)-(66.431)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(segmentsAcked)-(45.743)-(42.222));

} else {
	segmentsAcked = (int) (segmentsAcked+(4.64)+(23.685)+(37.18)+(30.519)+(82.606)+(75.738)+(12.45)+(8.72));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (segmentsAcked-(0.127)-(1.61)-(tcb->m_segmentSize)-(9.296)-(98.761)-(tcb->m_segmentSize));
