ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (42.934-(2.766)-(-79.751));
segmentsAcked = (int) (-76.244-(88.306)-(94.074)-(18.886)-(-29.132)-(-34.842));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (37.638-(-66.732)-(-51.213)-(-1.47)-(-47.965)-(-61.59));
ReduceCwnd (tcb);
