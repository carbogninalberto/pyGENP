tcb->m_ssThresh = (int) (74.632*(53.974)*(tcb->m_cWnd)*(17.807)*(80.321)*(28.696)*(10.705)*(43.869));
segmentsAcked = (int) (61.761-(30.755)-(59.194)-(segmentsAcked)-(57.049)-(89.621));
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (52.793-(28.292)-(57.961)-(tcb->m_cWnd)-(65.92)-(22.403)-(93.048)-(32.338)-(0.162));

} else {
	tcb->m_cWnd = (int) (((48.033)+((32.493*(tcb->m_segmentSize)*(8.443)*(86.843)))+(0.1)+(0.1)+((55.76-(28.78)-(61.475)-(68.256)-(85.066)))+(0.1))/((0.1)));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (52.628*(9.944)*(segmentsAcked)*(56.307)*(55.479)*(38.79)*(7.492)*(segmentsAcked));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (85.624+(32.89)+(5.268)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(71.069)+(17.525));
	tcb->m_ssThresh = (int) (99.142+(53.573)+(24.214)+(83.379)+(tcb->m_cWnd)+(90.945)+(55.299)+(56.421)+(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (62.265*(72.868));
