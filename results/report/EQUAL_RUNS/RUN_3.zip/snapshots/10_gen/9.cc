int EvKLvllicwWYINXW = (int) (3.089-(-89.964)-(-2.621));
ReduceCwnd (tcb);
segmentsAcked = (int) (-83.233-(98.524)-(-47.602)-(-62.024)-(-20.286)-(-49.546));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (37.655-(99.777)-(10.177)-(-61.973)-(-88.987)-(52.237));
ReduceCwnd (tcb);
