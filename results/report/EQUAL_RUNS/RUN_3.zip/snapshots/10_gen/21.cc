float aGTgvMpdAsosKPEv = (float) (70.158+(82.328)+(28.684));
CongestionAvoidance (tcb, segmentsAcked);
float xtNzRYDTPPiIEKSM = (float) (94.92*(77.428)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(14.681)*(44.521)*(23.185)*(segmentsAcked)*(43.689));
aGTgvMpdAsosKPEv = (float) (53.889*(24.086)*(84.095)*(2.585)*(12.128)*(94.58)*(77.314)*(tcb->m_cWnd));
tcb->m_segmentSize = (int) (46.833*(52.504)*(97.037)*(81.3)*(43.71)*(53.866)*(35.303)*(97.788));
ReduceCwnd (tcb);
