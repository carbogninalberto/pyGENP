CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked >= tcb->m_segmentSize) {
	segmentsAcked = (int) (97.37+(tcb->m_cWnd)+(91.154)+(35.368)+(66.115)+(17.438)+(87.685)+(36.31));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (38.573/14.685);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (-5.111/-4.815);
