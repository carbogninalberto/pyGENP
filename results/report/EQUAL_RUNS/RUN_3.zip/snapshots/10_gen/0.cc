ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (-93.188-(-84.172)-(75.891));
segmentsAcked = (int) (49.898-(-34.558)-(46.524)-(-27.355)-(-30.149)-(-41.639));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-2.278-(18.297)-(67.388)-(89.322)-(46.495)-(-54.697));
ReduceCwnd (tcb);
