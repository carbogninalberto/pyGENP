segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (30.85+(97.666)+(tcb->m_ssThresh)+(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (segmentsAcked+(60.966)+(segmentsAcked)+(62.837)+(3.13)+(38.083));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(83.523)-(72.23)-(37.712)-(40.905)-(48.682));
	tcb->m_cWnd = (int) (1.538*(10.896)*(16.392)*(11.76)*(35.367)*(61.7)*(77.493)*(88.112));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (55.663+(82.778)+(0.894)+(15.697)+(39.779)+(33.062));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
