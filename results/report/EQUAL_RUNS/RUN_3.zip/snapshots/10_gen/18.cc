if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (95.19*(76.925)*(9.225)*(45.55)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(67.716));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (48.542-(92.039));

}
tcb->m_segmentSize = (int) (81.194+(50.823)+(83.993)+(91.344)+(59.018)+(21.731)+(tcb->m_segmentSize)+(85.599)+(18.686));
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(84.888)*(79.715)*(23.534)*(45.424)*(8.683)*(25.993)*(73.924));
tcb->m_cWnd = (int) (69.282-(5.23)-(89.572)-(tcb->m_ssThresh)-(89.578)-(segmentsAcked));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
