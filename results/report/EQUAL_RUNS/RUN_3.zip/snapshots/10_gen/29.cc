int EvKLvllicwWYINXW = (int) (-93.727-(52.488)-(93.585));
ReduceCwnd (tcb);
segmentsAcked = (int) (-41.265-(-19.861)-(79.858)-(-11.005)-(-57.984)-(-86.9));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (3.161-(-98.367)-(81.286)-(35.439)-(-91.556)-(-3.466));
ReduceCwnd (tcb);
