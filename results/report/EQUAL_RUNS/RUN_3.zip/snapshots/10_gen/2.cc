int EvKLvllicwWYINXW = (int) (31.465-(-80.629)-(-35.235));
ReduceCwnd (tcb);
segmentsAcked = (int) (64.796-(35.068)-(96.61)-(-92.845)-(66.358)-(-75.189));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-63.569-(62.628)-(-36.325)-(63.452)-(44.095)-(19.775));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
