if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(69.582)*(29.823)*(75.27)*(33.865)*(96.282)*(33.324));
	tcb->m_cWnd = (int) (45.964-(82.13)-(6.374)-(81.351)-(27.471)-(83.005)-(tcb->m_ssThresh)-(16.655));

} else {
	tcb->m_cWnd = (int) ((((tcb->m_segmentSize*(50.266)*(10.388)*(72.923)*(87.893)))+(0.1)+(0.1)+(52.834))/((71.281)+(0.1)+(0.1)+(0.1)));

}
tcb->m_cWnd = (int) (98.352-(52.286)-(52.727)-(89.121)-(82.046)-(61.575)-(78.441)-(2.068));
tcb->m_ssThresh = (int) (56.917*(segmentsAcked));
tcb->m_cWnd = (int) (tcb->m_cWnd+(22.837)+(24.591)+(tcb->m_segmentSize)+(83.319)+(90.684));
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(7.151)-(tcb->m_ssThresh));
	segmentsAcked = (int) (((16.999)+(0.1)+(0.1)+(6.586))/((64.765)+(95.861)));

} else {
	tcb->m_cWnd = (int) (68.184+(33.989)+(39.305)+(94.505)+(64.394)+(91.005)+(70.573)+(70.265)+(19.669));

}
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
