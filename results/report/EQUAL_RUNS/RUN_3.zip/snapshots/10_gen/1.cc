int EvKLvllicwWYINXW = (int) (-19.336-(90.071)-(92.474));
ReduceCwnd (tcb);
segmentsAcked = (int) (14.777-(-77.78)-(66.411)-(29.996)-(-58.054)-(52.967));
ReduceCwnd (tcb);
segmentsAcked = (int) (83.464-(-59.513)-(-74.191)-(-70.193)-(-58.162)-(-0.831));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (32.227-(73.575)-(-7.945)-(8.475)-(-96.18)-(-80.602));
ReduceCwnd (tcb);
