float DFKXFvMseLsInzUg = (float) 32.61;
segmentsAcked = (int) (17.168+(5.522)+(98.975)+(62.813)+(23.753)+(-56.567));
CongestionAvoidance (tcb, segmentsAcked);
