float kpRqKZsetOqUFQAl = (float) (((93.49)+((-21.864*(8.551)*(52.454)*(93.792)*(45.557)*(6.887)))+(37.752)+(-11.18)+(-16.318))/((64.792)+(86.82)+(-7.331)));
float gSeKXEvRiCBVKnFA = (float) 82.069;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
