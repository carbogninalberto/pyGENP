segmentsAcked = (int) (-76.829-(73.939)-(95.519)-(67.034)-(-54.796)-(-70.883));
tcb->m_segmentSize = (int) (24.291*(-57.628));
tcb->m_segmentSize = (int) (28.059*(92.87));
