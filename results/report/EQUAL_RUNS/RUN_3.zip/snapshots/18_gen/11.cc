float IvUYZoFsMzaFqRZM = (float) (((0.419)+(8.572)+(58.573)+((-1.235-(56.602)-(-12.352)-(-98.845)-(22.273)-(77.361)))+(-72.177)+(-56.78)+(-50.363))/((94.77)));
int sBkpHeQTXzwdRZPt = (int) 88.926;
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) (-57.804-(tcb->m_cWnd)-(4.442)-(65.221)-(93.315)-(69.353)-(65.641)-(53.877));

} else {
	segmentsAcked = (int) (91.259/2.864);

}
tcb->m_segmentSize = (int) (-97.125-(-89.962)-(64.283)-(48.547)-(-88.69)-(76.775)-(-48.041)-(84.004));
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (73.823*(26.297)*(28.321)*(45.112));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (IvUYZoFsMzaFqRZM*(17.25));
	segmentsAcked = (int) (92.908*(sBkpHeQTXzwdRZPt)*(69.362)*(90.647)*(60.341)*(sBkpHeQTXzwdRZPt));

}
