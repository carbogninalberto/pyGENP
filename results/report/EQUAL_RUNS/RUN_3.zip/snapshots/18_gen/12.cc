tcb->m_segmentSize = (int) (-92.333/23.893);
segmentsAcked = (int) (99.934-(79.127)-(62.566)-(-35.874)-(2.087)-(12.786));
tcb->m_segmentSize = (int) (-73.38*(4.818));
