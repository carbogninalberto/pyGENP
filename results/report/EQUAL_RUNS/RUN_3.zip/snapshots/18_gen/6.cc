int EvKLvllicwWYINXW = (int) (74.069-(-76.935)-(84.702));
ReduceCwnd (tcb);
segmentsAcked = (int) (54.981-(2.669)-(-78.118)-(-63.312)-(62.492)-(-90.479));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (43.633-(71.625)-(49.417)-(62.023)-(-79.913)-(-83.559));
ReduceCwnd (tcb);
