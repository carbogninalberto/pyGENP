int AVhnNCefnJVJLuIL = (int) (27.086+(-16.965)+(-50.678)+(97.306)+(58.907));
tcb->m_cWnd = (int) (-17.434+(95.899)+(44.198)+(13.606)+(-74.214)+(-69.053));
if (segmentsAcked >= AVhnNCefnJVJLuIL) {
	segmentsAcked = (int) (98.874-(65.538)-(28.535)-(tcb->m_cWnd)-(94.366)-(88.866)-(16.062));
	AVhnNCefnJVJLuIL = (int) (54.563+(67.506)+(79.089)+(24.251));

} else {
	segmentsAcked = (int) (70.79+(54.927)+(68.471)+(91.501));

}
CongestionAvoidance (tcb, segmentsAcked);
