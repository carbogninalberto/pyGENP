float kpRqKZsetOqUFQAl = (float) (((-87.821)+((46.561*(65.096)*(-62.28)*(-55.711)*(-58.55)*(25.454)))+(81.206)+(-99.116)+(-91.203))/((80.359)+(-61.55)+(-29.165)));
float gSeKXEvRiCBVKnFA = (float) 18.524;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
