float VsOzgcyQGVaVCqrG = (float) (-80.728+(-85.93)+(-90.925)+(-4.631)+(-22.866)+(15.244)+(-51.931)+(-75.752)+(-59.602));
float iRHYNrhIMWzjSijK = (float) (21.514-(50.666)-(-11.652)-(58.049)-(-61.857)-(49.306)-(12.066));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
