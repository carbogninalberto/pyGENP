float DNrafSkMHOHaUyBR = (float) (21.899-(-20.195)-(83.117)-(-54.16)-(-12.308)-(-47.294)-(-69.583)-(-7.49));
if (tcb->m_cWnd <= DNrafSkMHOHaUyBR) {
	tcb->m_cWnd = (int) ((95.828-(56.798)-(87.828)-(37.295)-(tcb->m_cWnd)-(31.708)-(tcb->m_segmentSize))/19.846);

} else {
	tcb->m_cWnd = (int) (25.879+(47.79)+(84.933));
	DNrafSkMHOHaUyBR = (float) (42.107+(47.153)+(43.168)+(95.502));

}
