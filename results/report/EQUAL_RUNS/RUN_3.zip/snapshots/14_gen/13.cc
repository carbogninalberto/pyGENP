float DfvKHTkeaLCGGZzu = (float) 97.24;
tcb->m_cWnd = (int) (87.901-(13.166)-(-98.078)-(-71.918)-(98.976));
