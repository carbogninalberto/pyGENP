int EvKLvllicwWYINXW = (int) (4.271-(-90.007)-(-14.799));
ReduceCwnd (tcb);
segmentsAcked = (int) (-4.072-(97.414)-(74.953)-(58.141)-(-85.094)-(-7.522));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-39.882-(32.541)-(89.692)-(-5.129)-(-81.772)-(-6.625));
ReduceCwnd (tcb);
