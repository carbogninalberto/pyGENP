int TBakewcrgAxmyjlE = (int) 53.675;
int XWYtjNKTWFdNEcSO = (int) 66.081;
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-92.249*(-22.046)*(-68.057)*(-30.922)*(-28.573)*(-96.876));
tcb->m_segmentSize = (int) (((-35.151)+(51.276)+((2.458*(4.635)*(-49.669)*(37.469)))+(25.18))/((-85.662)));
if (XWYtjNKTWFdNEcSO >= XWYtjNKTWFdNEcSO) {
	XWYtjNKTWFdNEcSO = (int) (2.649+(82.88)+(80.254)+(0.539)+(tcb->m_cWnd)+(68.013)+(30.27));
	TBakewcrgAxmyjlE = (int) (70.498-(tcb->m_segmentSize));
	TBakewcrgAxmyjlE = (int) (((36.178)+(0.1)+(54.893)+(0.1)+(0.1)+(58.446))/((0.1)+(27.408)+(26.023)));

} else {
	XWYtjNKTWFdNEcSO = (int) (tcb->m_cWnd*(46.362));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
