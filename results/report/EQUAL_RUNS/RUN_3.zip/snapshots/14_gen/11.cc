TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-70.885+(-50.66));
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(55.694)-(50.937)-(13.666)-(69.78)-(93.552)-(86.999)-(57.529)-(73.391));
	tcb->m_cWnd = (int) ((33.326-(tcb->m_segmentSize)-(88.113)-(2.02)-(segmentsAcked)-(tcb->m_ssThresh)-(48.623)-(23.549)-(96.393))/76.399);
	segmentsAcked = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (13.631-(segmentsAcked)-(8.447)-(67.427));

}
