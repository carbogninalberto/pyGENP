int EvKLvllicwWYINXW = (int) (16.811-(31.606)-(59.885));
ReduceCwnd (tcb);
segmentsAcked = (int) (-71.311-(33.287)-(-76.204)-(51.846)-(82.514)-(-86.343));
ReduceCwnd (tcb);
segmentsAcked = (int) (-66.517-(7.931)-(-11.582)-(94.521)-(32.007)-(93.01));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (-96.96-(-57.129)-(-10.924)-(-13.265)-(42.89)-(70.878));
ReduceCwnd (tcb);
