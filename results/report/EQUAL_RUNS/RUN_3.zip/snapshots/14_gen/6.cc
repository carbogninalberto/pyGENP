ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (-54.706-(1.774)-(-98.719));
segmentsAcked = (int) (-95.3-(-42.433)-(-51.095)-(-9.803)-(-54.806)-(28.08));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-65.164-(31.718)-(38.651)-(-48.39)-(-56.057)-(98.23));
ReduceCwnd (tcb);
