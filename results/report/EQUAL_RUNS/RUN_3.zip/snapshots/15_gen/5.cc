ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (46.977-(-62.744)-(-56.467));
segmentsAcked = (int) (-85.66-(-2.497)-(98.746)-(95.483)-(77.968)-(88.426));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-68.821-(74.256)-(61.105)-(-47.391)-(-39.947)-(22.997));
ReduceCwnd (tcb);
