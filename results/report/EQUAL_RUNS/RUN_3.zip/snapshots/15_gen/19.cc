int XWYtjNKTWFdNEcSO = (int) 44.299;
segmentsAcked = SlowStart (tcb, segmentsAcked);
int TBakewcrgAxmyjlE = (int) 94.842;
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-22.041*(-52.964)*(95.668)*(-53.469)*(39.741)*(18.452));
tcb->m_cWnd = (int) (20.287*(-0.241)*(24.648)*(-21.481)*(97.511)*(-22.429));
tcb->m_segmentSize = (int) (((-59.889)+(-32.938)+((23.503*(72.147)*(42.485)*(3.653)))+(30.476))/((90.552)));
tcb->m_segmentSize = (int) (((-65.797)+(75.16)+((7.875*(29.693)*(-75.659)*(29.774)))+(-13.167))/((-15.157)));
if (XWYtjNKTWFdNEcSO >= XWYtjNKTWFdNEcSO) {
	XWYtjNKTWFdNEcSO = (int) (2.649+(82.88)+(80.254)+(0.539)+(tcb->m_cWnd)+(68.013)+(30.27));
	TBakewcrgAxmyjlE = (int) (70.498-(tcb->m_segmentSize));
	TBakewcrgAxmyjlE = (int) (((36.178)+(0.1)+(54.893)+(0.1)+(0.1)+(58.446))/((0.1)+(27.408)+(26.023)));

} else {
	XWYtjNKTWFdNEcSO = (int) (tcb->m_cWnd*(46.362));
	ReduceCwnd (tcb);

}
if (XWYtjNKTWFdNEcSO >= XWYtjNKTWFdNEcSO) {
	XWYtjNKTWFdNEcSO = (int) (2.649+(82.88)+(80.254)+(0.539)+(tcb->m_cWnd)+(68.013)+(30.27));
	TBakewcrgAxmyjlE = (int) (70.498-(tcb->m_segmentSize));
	TBakewcrgAxmyjlE = (int) (((36.178)+(0.1)+(54.893)+(0.1)+(0.1)+(58.446))/((0.1)+(27.408)+(26.023)));

} else {
	XWYtjNKTWFdNEcSO = (int) (tcb->m_cWnd*(46.362));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
