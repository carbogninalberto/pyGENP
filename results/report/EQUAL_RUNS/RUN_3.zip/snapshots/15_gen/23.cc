TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (89.686+(11.997)+(96.344)+(42.227)+(78.497)+(89.872)+(75.494)+(tcb->m_cWnd)+(10.766));
tcb->m_cWnd = (int) (49.39*(25.216)*(43.608)*(99.439)*(82.422));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (86.382+(32.625)+(65.499));
	tcb->m_cWnd = (int) ((tcb->m_segmentSize+(69.695)+(65.712)+(tcb->m_segmentSize)+(9.119)+(tcb->m_segmentSize)+(51.273)+(92.978)+(9.769))/0.1);

} else {
	tcb->m_cWnd = (int) (27.373+(73.322)+(54.005)+(62.959)+(36.705));
	segmentsAcked = (int) ((37.734*(11.308)*(1.708)*(59.603)*(64.462)*(43.829)*(segmentsAcked)*(25.762)*(tcb->m_ssThresh))/(16.413*(tcb->m_ssThresh)*(61.484)*(80.819)*(tcb->m_cWnd)*(21.726)));

}
tcb->m_ssThresh = (int) (0.1/56.073);
