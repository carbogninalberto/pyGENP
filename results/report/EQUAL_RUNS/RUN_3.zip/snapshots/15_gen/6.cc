int XWYtjNKTWFdNEcSO = (int) 44.299;
segmentsAcked = SlowStart (tcb, segmentsAcked);
float GZvKWtAJdJsYYcaP = (float) (((75.317)+(23.482)+(-2.41)+(-36.721)+(58.973))/((1.457)));
