CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (segmentsAcked+(64.451)+(tcb->m_segmentSize)+(0.16));
tcb->m_segmentSize = (int) (99.504+(33.463)+(4.01));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (44.548-(23.953)-(segmentsAcked));
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_ssThresh = (int) (29.41*(8.803)*(tcb->m_ssThresh));
	tcb->m_cWnd = (int) ((((tcb->m_ssThresh-(0.728)-(89.255)-(segmentsAcked)))+(94.568)+(88.44)+(0.1)+(62.406)+(82.096)+(0.1))/((0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (13.529*(70.042)*(70.975)*(66.041)*(tcb->m_cWnd)*(81.256)*(96.232)*(88.202)*(22.759));
	tcb->m_segmentSize = (int) (((0.1)+(29.293)+(63.641)+(0.1)+(49.99))/((0.1)+(0.1)));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (14.425/3.518);
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (77.8-(77.24));
	tcb->m_cWnd = (int) ((((74.942*(58.374)*(37.692)))+(46.026)+(62.944)+(0.1)+(0.1))/((0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) ((tcb->m_cWnd*(37.097)*(15.224)*(69.741)*(segmentsAcked))/0.1);
	tcb->m_cWnd = (int) ((92.278*(tcb->m_segmentSize)*(46.895)*(segmentsAcked)*(18.421)*(19.07))/0.1);

}
