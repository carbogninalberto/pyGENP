if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (65.827+(19.275)+(64.776)+(71.872)+(31.282)+(segmentsAcked)+(8.82)+(39.391)+(12.814));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (segmentsAcked+(69.847)+(94.77)+(35.877)+(32.15)+(23.228)+(69.708));
	tcb->m_segmentSize = (int) (0.1/15.775);

}
tcb->m_cWnd = (int) (-64.178-(-3.218)-(59.008)-(-15.609)-(-50.511)-(42.875)-(-72.065)-(-93.161));
tcb->m_cWnd = (int) (68.306-(93.067)-(57.548)-(46.716)-(-39.05));
tcb->m_cWnd = (int) (97.367-(57.399)-(7.543)-(-92.155)-(37.669));
