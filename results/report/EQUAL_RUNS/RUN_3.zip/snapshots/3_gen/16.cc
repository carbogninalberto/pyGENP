ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (35.961-(-18.562)-(-87.891));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (96.752-(-80.106)-(60.424)-(26.361)-(69.641)-(92.676));
segmentsAcked = (int) (87.545-(88.307)-(50.063)-(-55.473)-(6.239)-(18.298));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
