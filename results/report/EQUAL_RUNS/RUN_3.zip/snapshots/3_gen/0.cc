ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (-28.678-(-34.617)-(1.753));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-75.217-(42.202)-(-11.981)-(25.396)-(-52.278)-(24.193));
ReduceCwnd (tcb);
