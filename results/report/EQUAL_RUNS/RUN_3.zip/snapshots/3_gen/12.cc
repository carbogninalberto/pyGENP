if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (4.738*(7.859)*(93.63));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (37.997-(52.042)-(96.124)-(30.672));

}
