float qirPGtMBmSzVPLpr = (float) (45.2-(21.02)-(-90.018)-(86.7)-(-50.868)-(91.444)-(3.768)-(96.28));
segmentsAcked = SlowStart (tcb, segmentsAcked);
int YatGUdMTxNTNBxMp = (int) 78.664;
YatGUdMTxNTNBxMp = (int) (18.899-(-2.143)-(66.109)-(-32.42)-(-18.799)-(-12.547));
tcb->m_cWnd = (int) (-31.091*(-77.257)*(50.147)*(8.259)*(40.434));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
