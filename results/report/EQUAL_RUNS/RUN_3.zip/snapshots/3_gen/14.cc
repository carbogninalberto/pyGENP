int BLfVGhufxVPssprt = (int) (-64.657/97.456);
int bzUuiFqXVnEmPKJk = (int) (-50.114*(17.337)*(-83.178)*(72.011)*(54.283)*(7.736)*(-56.393)*(-97.288)*(-30.31));
bzUuiFqXVnEmPKJk = (int) (-27.094*(-77.017)*(-50.969)*(85.715));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
