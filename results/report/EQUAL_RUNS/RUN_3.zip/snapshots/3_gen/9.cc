segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (82.909+(57.785)+(-84.64)+(-8.627)+(-52.543));
tcb->m_cWnd = (int) (-60.914*(-44.249));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
