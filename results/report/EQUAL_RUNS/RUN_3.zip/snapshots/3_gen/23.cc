ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (67.927-(-95.401)-(-73.039));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-36.54-(78.338)-(-58.914)-(77.075)-(-76.62)-(-36.995));
segmentsAcked = (int) (44.035-(18.652)-(-34.7)-(68.898)-(19.679)-(43.551));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
