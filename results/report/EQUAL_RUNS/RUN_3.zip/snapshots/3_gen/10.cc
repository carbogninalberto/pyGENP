segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(60.677)-(76.542)-(32.887));

}
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(60.677)-(76.542)-(32.887));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);

}
segmentsAcked = (int) (42.235/54.528);
segmentsAcked = (int) (78.088/65.135);
segmentsAcked = (int) (10.901-(1.83)-(37.232)-(-48.87)-(27.116));
segmentsAcked = (int) (-58.029-(17.4)-(-7.123)-(-46.193)-(-48.594));
tcb->m_cWnd = (int) (5.561*(-48.914)*(-33.441)*(-12.398)*(-26.016)*(-57.481)*(-78.158)*(-17.392)*(-4.534));
