ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (31.661-(-6.738)-(55.185));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-17.147-(81.068)-(-51.881)-(4.038)-(9.258)-(7.48));
ReduceCwnd (tcb);
segmentsAcked = (int) (-49.951-(-42.817)-(-82.974)-(59.479)-(0.144)-(-91.786));
ReduceCwnd (tcb);
