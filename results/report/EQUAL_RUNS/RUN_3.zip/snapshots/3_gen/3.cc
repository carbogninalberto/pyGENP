if (segmentsAcked != segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(74.347)-(72.863));

} else {
	tcb->m_cWnd = (int) (52.437/0.1);
	tcb->m_segmentSize = (int) (0.1/71.39);

}
if (segmentsAcked >= tcb->m_segmentSize) {
	segmentsAcked = (int) (86.989/46.403);
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (22.12*(42.283)*(72.417)*(51.269));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked >= tcb->m_segmentSize) {
	segmentsAcked = (int) (86.989/46.403);
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (22.12*(42.283)*(72.417)*(51.269));

}
