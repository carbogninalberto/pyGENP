ReduceCwnd (tcb);
segmentsAcked = (int) (56.278-(-8.915)-(-40.711)-(68.318)-(-69.508)-(45.428));
int EvKLvllicwWYINXW = (int) (42.836-(25.852)-(92.353));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (55.844-(-86.893)-(30.258)-(76.023)-(-90.924)-(-76.759));
ReduceCwnd (tcb);
