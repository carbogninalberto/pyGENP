float qZFQXTwhVaHxxTau = (float) (47.144/89.774);
ReduceCwnd (tcb);
