ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (48.097-(94.921)-(-92.968));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-71.872-(71.109)-(-92.684)-(-30.93)-(60.407)-(57.063));
ReduceCwnd (tcb);
