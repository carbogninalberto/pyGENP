float nLSPgxZCFWCrMTpY = (float) (((-74.172)+(24.357)+((-53.223-(34.608)-(25.431)-(-66.971)-(35.014)))+(-4.856))/((86.686)+(-5.151)+(-67.598)+(75.937)+(29.617)));
float AKjzcXciYgpeLHao = (float) 7.986;
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
