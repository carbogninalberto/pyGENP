ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (73.389-(42.301)-(-80.697));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-94.143-(-72.811)-(58.902)-(8.701)-(36.472)-(-62.046));
segmentsAcked = (int) (44.916-(54.08)-(-72.243)-(-13.911)-(-77.876)-(59.665));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
