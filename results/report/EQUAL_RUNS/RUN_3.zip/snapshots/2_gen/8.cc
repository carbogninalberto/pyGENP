int UlGUusBGbfDBmhrc = (int) (4.954-(-90.056)-(-15.02)-(-69.393)-(-92.145)-(-17.728));
int xodwJemFsqepCLTo = (int) (-95.346*(99.17));
int cunMUEGuuWqswOmN = (int) 67.507;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
