ReduceCwnd (tcb);
int EvKLvllicwWYINXW = (int) (-18.686-(33.964)-(-5.556));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (44.001-(36.377)-(-44.692)-(-96.638)-(61.41)-(-76.788));
segmentsAcked = (int) (-44.066-(-98.836)-(-75.555)-(-65.078)-(6.61)-(-15.184));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
