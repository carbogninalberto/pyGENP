if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (2.336+(4.266)+(tcb->m_cWnd)+(73.22)+(69.316)+(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (16.559+(48.86)+(43.296)+(12.598)+(6.002)+(tcb->m_cWnd)+(88.409)+(tcb->m_segmentSize)+(17.587));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked >= tcb->m_segmentSize) {
	segmentsAcked = (int) (86.989/46.403);
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (22.12*(42.283)*(72.417)*(51.269));

}
