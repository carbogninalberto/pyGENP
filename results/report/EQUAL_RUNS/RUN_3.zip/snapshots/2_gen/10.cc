float IHlPbNYMdkbqnjcY = (float) 47.5;
