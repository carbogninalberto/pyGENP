int UlGUusBGbfDBmhrc = (int) (95.524-(95.153)-(-44.351)-(77.564)-(-25.9)-(-98.202));
int cunMUEGuuWqswOmN = (int) (68.476-(15.37)-(22.074)-(-60.909)-(-2.324)-(-42.628)-(38.654));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
