int YatGUdMTxNTNBxMp = (int) (-32.755+(16.42)+(35.761)+(3.849));
float qirPGtMBmSzVPLpr = (float) (-83.177-(9.612)-(30.355)-(52.203)-(-90.407)-(24.341)-(-20.533)-(-29.03));
YatGUdMTxNTNBxMp = (int) (31.942-(-87.591)-(-54.601)-(-63.755)-(61.675)-(51.681));
tcb->m_cWnd = (int) (94.857*(-34.776)*(-32.434)*(-88.864)*(-61.979));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
