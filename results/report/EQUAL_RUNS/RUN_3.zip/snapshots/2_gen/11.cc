CongestionAvoidance (tcb, segmentsAcked);
int bzUuiFqXVnEmPKJk = (int) (-9.624*(-99.177)*(-11.018)*(-44.543)*(37.63)*(3.783)*(-0.842)*(-87.591)*(-82.326));
CongestionAvoidance (tcb, segmentsAcked);
int BLfVGhufxVPssprt = (int) (77.177/10.032);
ReduceCwnd (tcb);
float cHaKxwbYeXqnvIWE = (float) (-47.27/7.539);
bzUuiFqXVnEmPKJk = (int) (86.635+(32.649)+(74.059)+(44.103)+(44.175)+(86.113)+(31.209)+(12.379));
segmentsAcked = SlowStart (tcb, segmentsAcked);
