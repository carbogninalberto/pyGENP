float ojiCBGfkAFjXxlgI = (float) (-27.472+(-39.949)+(-38.714)+(46.494)+(10.672)+(-6.587)+(-45.43)+(24.926)+(-10.75));
float qEZDXDvxigtPoLzs = (float) (2.496*(-20.703)*(-93.184)*(10.62)*(-3.459)*(-4.28));
tcb->m_cWnd = (int) (14.372+(-24.362)+(-56.752)+(-33.413)+(-32.602));
tcb->m_cWnd = (int) (64.204*(-72.135));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
