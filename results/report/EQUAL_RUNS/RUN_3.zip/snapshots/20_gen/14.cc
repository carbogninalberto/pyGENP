int ktshNnicFJyRidDa = (int) 21.882;
