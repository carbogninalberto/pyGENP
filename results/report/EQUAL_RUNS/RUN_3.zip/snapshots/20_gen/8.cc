CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (54.65/0.1);
	tcb->m_cWnd = (int) (3.213-(22.447)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (67.374-(91.231)-(40.373)-(77.387)-(-41.425));

}
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
