tcb->m_cWnd = (int) (67.912*(-58.769)*(86.834)*(98.17));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (98.851-(94.847)-(52.466));

} else {
	tcb->m_cWnd = (int) (40.893-(12.996));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (40.893-(12.996));

} else {
	tcb->m_cWnd = (int) (98.851-(94.847)-(52.466));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
