int fUWCIaFttElKiqOH = (int) (1.292*(1.63)*(95.64)*(62.618)*(tcb->m_segmentSize)*(87.846));
float fxyYMdtOvpLXSEvd = (float) (10.588+(91.689)+(segmentsAcked)+(84.375));
tcb->m_cWnd = (int) (25.804+(29.018)+(34.703)+(74.093)+(68.206)+(25.508)+(24.328)+(62.578)+(19.176));
if (fUWCIaFttElKiqOH != tcb->m_ssThresh) {
	segmentsAcked = (int) (84.493+(84.371)+(43.416)+(60.187)+(fUWCIaFttElKiqOH)+(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (63.132*(tcb->m_segmentSize)*(39.015)*(87.432)*(3.01));

}
if (fUWCIaFttElKiqOH >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((59.483)+(0.1)+(0.1)+(1.312)+((51.264+(22.292)+(tcb->m_cWnd)+(84.22)+(68.435)+(53.4)+(62.943)+(79.845)))+(73.184)+(0.1))/((0.1)));
	tcb->m_cWnd = (int) (69.319/15.863);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (fxyYMdtOvpLXSEvd+(41.415)+(37.733)+(92.243)+(tcb->m_ssThresh)+(83.092)+(37.411));
	tcb->m_ssThresh = (int) (55.003*(fUWCIaFttElKiqOH)*(83.135)*(5.922)*(48.873)*(7.507)*(72.847));

}
ReduceCwnd (tcb);
