float nPxufPOygFrQJlYN = (float) (-36.915-(-6.304)-(40.226)-(-91.397)-(6.67)-(-3.361)-(86.42)-(-2.554)-(-19.94));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (53.118-(-61.925)-(59.35)-(-61.43)-(-50.318)-(61.14)-(78.052));
