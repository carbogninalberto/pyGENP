if (tcb->m_ssThresh > segmentsAcked) {
	segmentsAcked = (int) (45.67-(68.884)-(59.643)-(4.275)-(16.127)-(tcb->m_ssThresh)-(54.292));
	tcb->m_segmentSize = (int) (15.542-(tcb->m_segmentSize)-(45.561));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(tcb->m_cWnd)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(78.237)+(79.434)+(segmentsAcked));
	tcb->m_ssThresh = (int) (53.19-(15.323)-(82.55)-(87.08));

}
tcb->m_ssThresh = (int) (70.841*(45.513)*(86.263)*(60.136));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (73.415+(33.078)+(60.511)+(79.585)+(42.115)+(10.592)+(62.082)+(72.249));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (14.764+(68.662));
	tcb->m_ssThresh = (int) (6.708/0.1);
	tcb->m_segmentSize = (int) (91.53-(65.057)-(2.952)-(segmentsAcked)-(28.822)-(56.677)-(65.14)-(49.681)-(tcb->m_cWnd));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (53.59-(24.319)-(segmentsAcked)-(54.737)-(67.373)-(tcb->m_segmentSize));
