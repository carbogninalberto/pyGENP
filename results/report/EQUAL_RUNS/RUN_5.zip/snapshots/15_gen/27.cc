tcb->m_ssThresh = (int) (13.056*(tcb->m_cWnd));
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (89.821*(9.234)*(96.837)*(87.346)*(17.299)*(tcb->m_segmentSize)*(1.619)*(78.41)*(79.217));
	segmentsAcked = (int) (26.029+(19.294)+(55.85)+(86.876)+(97.605)+(segmentsAcked)+(21.875)+(18.325)+(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (27.033*(12.348)*(5.828)*(50.138)*(48.085)*(23.101)*(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (61.688*(tcb->m_ssThresh));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (((0.1)+(0.1)+(52.331)+(77.05)+(55.444)+(0.1))/((0.1)));
tcb->m_segmentSize = (int) (87.85/0.1);
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_cWnd = (int) (6.49/2.98);
	segmentsAcked = (int) (62.131+(31.756)+(63.761));

} else {
	tcb->m_cWnd = (int) (((62.919)+(14.27)+(71.638)+(0.1))/((0.1)+(41.502)));

}
int cAgbEXEaUOnFzubb = (int) (30.347+(2.655)+(64.611));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (((0.1)+((24.07+(12.494)+(14.525)+(48.546)+(57.807)+(cAgbEXEaUOnFzubb)+(31.658)+(28.259)))+(0.1)+(90.275))/((0.1)+(29.273)+(0.1)));

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(0.1)+(37.135)+(0.1))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (58.626*(14.192)*(36.806)*(tcb->m_ssThresh)*(29.634)*(1.995));

}
