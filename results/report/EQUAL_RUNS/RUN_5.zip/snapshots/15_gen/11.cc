CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.757+(48.654)+(87.002)+(38.945)+(56.687)+(62.125));
	tcb->m_cWnd = (int) (58.468*(23.437));

} else {
	tcb->m_segmentSize = (int) (17.788*(76.751)*(11.799)*(82.701)*(tcb->m_cWnd)*(tcb->m_cWnd)*(16.753)*(69.438));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (97.146/0.1);

} else {
	tcb->m_segmentSize = (int) (52.873+(tcb->m_segmentSize)+(49.045)+(95.408)+(75.936)+(tcb->m_segmentSize)+(51.455));

}
ReduceCwnd (tcb);
if (segmentsAcked != segmentsAcked) {
	tcb->m_ssThresh = (int) (47.556*(81.806)*(73.302)*(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(0.772)+(61.794)+(tcb->m_cWnd)+(34.13)+(61.946)+(8.125)+(segmentsAcked));
	tcb->m_segmentSize = (int) (((35.203)+((tcb->m_cWnd+(97.197)+(tcb->m_segmentSize)+(50.1)+(16.128)+(52.954)))+(0.1)+(2.958))/((72.666)+(16.269)));
	tcb->m_ssThresh = (int) (97.285+(58.301)+(tcb->m_ssThresh)+(24.222)+(17.053));

}
if (tcb->m_ssThresh == tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_segmentSize+(77.844)+(5.511)+(62.049)+(43.515));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (59.074*(65.506)*(51.359)*(57.424)*(96.939)*(62.182));

} else {
	segmentsAcked = (int) (66.177+(10.266)+(35.424)+(29.73)+(74.306)+(20.766));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
