float PjNKJBhRUbeaHWuV = (float) 44.882;
