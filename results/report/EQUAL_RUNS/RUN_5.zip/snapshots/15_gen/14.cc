float nuEYJYFsNsoQrNms = (float) (tcb->m_segmentSize-(20.187)-(41.43)-(76.5)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(tcb->m_cWnd));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (nuEYJYFsNsoQrNms < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((15.7*(22.273)*(12.588)*(16.595)*(46.72)*(28.748)*(92.228)*(nuEYJYFsNsoQrNms)*(33.905))/94.72);

} else {
	tcb->m_segmentSize = (int) (24.774-(36.097)-(0.468)-(tcb->m_segmentSize)-(nuEYJYFsNsoQrNms));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (54.592+(57.926)+(91.607)+(12.505)+(43.373)+(15.881)+(71.44));
CongestionAvoidance (tcb, segmentsAcked);
