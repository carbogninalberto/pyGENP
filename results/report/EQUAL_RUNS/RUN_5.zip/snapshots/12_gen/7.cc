TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-72.369-(-27.31)-(7.287)-(-58.026)-(9.775)-(87.348)-(47.278)-(-3.96)-(-82.162));
segmentsAcked = (int) (-63.358+(0.972)+(-11.418)+(-34.544));
