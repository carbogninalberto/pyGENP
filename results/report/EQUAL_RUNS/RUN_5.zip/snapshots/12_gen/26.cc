if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (75.377+(66.34)+(44.699)+(55.168));

} else {
	tcb->m_cWnd = (int) (95.165+(10.622)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(27.109)+(21.65)+(93.146));
	tcb->m_ssThresh = (int) (25.419+(96.851)+(9.86)+(6.98)+(tcb->m_ssThresh)+(19.405)+(74.819)+(31.304));

}
tcb->m_ssThresh = (int) (tcb->m_cWnd-(66.028)-(33.391)-(64.989)-(38.951)-(41.913)-(84.676)-(76.288)-(86.243));
segmentsAcked = (int) (0.1/97.056);
segmentsAcked = (int) (96.494+(tcb->m_cWnd)+(76.487)+(31.413)+(49.485)+(74.198));
tcb->m_segmentSize = (int) (41.414-(84.206)-(56.517)-(78.147)-(68.396)-(segmentsAcked)-(6.305)-(78.006));
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) (((0.1)+(20.102)+(0.1)+(0.1)+(81.571)+(0.1))/((0.1)+(0.1)+(0.1)));
	segmentsAcked = (int) (8.269-(90.398)-(38.984)-(60.788)-(88.468)-(26.828)-(0.365));

} else {
	tcb->m_cWnd = (int) (14.459-(96.54)-(29.322)-(tcb->m_ssThresh)-(86.825));
	tcb->m_ssThresh = (int) (segmentsAcked*(4.044)*(27.462));
	ReduceCwnd (tcb);

}
