float YbTgyhWeobrZnoqq = (float) 57.936;
tcb->m_cWnd = (int) (-31.232-(96.532)-(-50.442)-(-37.35)-(-64.716));
float NYBTGhwKYhavWZKf = (float) 80.906;
if (segmentsAcked < NYBTGhwKYhavWZKf) {
	NYBTGhwKYhavWZKf = (float) (11.614+(17.417)+(94.088)+(85.824)+(tcb->m_cWnd)+(YbTgyhWeobrZnoqq));

} else {
	NYBTGhwKYhavWZKf = (float) (17.04-(95.052)-(2.575)-(57.393)-(segmentsAcked)-(68.11)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (94.715*(72.85)*(46.966));

}
segmentsAcked = (int) (-37.519-(66.524)-(-97.006)-(-42.715)-(42.927)-(97.962));
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (YbTgyhWeobrZnoqq-(68.319)-(94.391)-(tcb->m_segmentSize)-(25.522)-(98.318));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (21.262*(23.535)*(3.367)*(18.577)*(36.802)*(32.877));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
