if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((87.013)+(0.1)+(0.1)+((60.683+(82.411)))+(0.1))/((1.321)));
	tcb->m_ssThresh = (int) (69.359/(49.845+(16.098)+(72.24)+(29.771)+(24.474)+(20.878)+(84.441)+(52.502)));

} else {
	tcb->m_ssThresh = (int) (((23.409)+(0.1)+(27.681)+(38.732)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)));
	tcb->m_ssThresh = (int) (44.625+(91.508)+(39.578)+(31.904)+(6.436)+(63.549)+(26.732));
	tcb->m_cWnd = (int) (77.631+(93.283)+(61.156)+(81.677)+(71.33));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (0.1/30.694);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (58.072*(71.084)*(tcb->m_ssThresh)*(86.077)*(64.135)*(54.052)*(32.776));
	tcb->m_ssThresh = (int) (11.08-(83.411));
	tcb->m_segmentSize = (int) (55.355+(tcb->m_cWnd)+(98.824));

} else {
	tcb->m_segmentSize = (int) (1.812-(0.7)-(34.02)-(12.495));
	tcb->m_segmentSize = (int) (10.825+(80.005)+(segmentsAcked)+(4.152));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.149-(50.483)-(88.665)-(44.986)-(59.549)-(25.513)-(55.0)-(11.634));

} else {
	tcb->m_cWnd = (int) (((0.1)+(96.91)+(0.1)+(97.99))/((0.1)+(54.936)+(12.051)+(87.943)));
	tcb->m_segmentSize = (int) (((35.244)+(44.966)+((82.681*(93.96)*(56.877)))+(0.1)+(4.658))/((0.1)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
