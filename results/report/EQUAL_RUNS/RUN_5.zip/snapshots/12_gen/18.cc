if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) (83.74/3.374);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (1.267-(33.348));

}
float rfhYmOyJxTlkuMYo = (float) (9.58*(80.133)*(55.995)*(17.837)*(segmentsAcked)*(7.927)*(85.813));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (91.142*(69.273)*(68.506)*(37.676)*(98.119)*(69.288));
tcb->m_ssThresh = (int) (48.064/31.011);
