float ABlvGzJQvEBXXdiq = (float) (90.348-(-7.781));
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (28.379*(89.101)*(41.54)*(53.375)*(2.396)*(84.266));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (86.526+(-55.412)+(-3.528));

} else {
	tcb->m_cWnd = (int) (13.064-(88.156)-(36.417)-(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked < segmentsAcked) {
	tcb->m_cWnd = (int) (53.847+(17.668)+(34.557)+(46.039)+(3.57)+(80.699)+(47.477)+(13.504)+(49.914));
	segmentsAcked = (int) (70.109-(segmentsAcked)-(92.111)-(90.261)-(2.161)-(84.115)-(25.363)-(76.718)-(77.79));

} else {
	tcb->m_cWnd = (int) (0.1/1.539);
	tcb->m_segmentSize = (int) (72.154-(7.749));
	tcb->m_cWnd = (int) ((42.835+(segmentsAcked)+(59.103))/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
ABlvGzJQvEBXXdiq = (float) (-96.157+(83.444)+(31.242));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ABlvGzJQvEBXXdiq = (float) (84.099/69.077);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked < segmentsAcked) {
	tcb->m_cWnd = (int) (53.847+(17.668)+(57.4)+(46.039)+(3.57)+(80.699)+(47.477)+(13.504)+(49.914));
	segmentsAcked = (int) (70.109-(segmentsAcked)-(92.111)-(90.261)-(2.161)-(84.115)-(25.363)-(76.718)-(77.79));

} else {
	tcb->m_cWnd = (int) (0.1/1.539);
	tcb->m_segmentSize = (int) (72.154-(7.749));
	tcb->m_cWnd = (int) ((42.835+(segmentsAcked)+(59.103))/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
ABlvGzJQvEBXXdiq = (float) (73.027+(-51.001)+(-3.626));
ABlvGzJQvEBXXdiq = (float) (63.189/-9.403);
