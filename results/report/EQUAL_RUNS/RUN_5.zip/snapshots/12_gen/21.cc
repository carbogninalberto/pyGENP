tcb->m_cWnd = (int) (70.096-(71.472)-(10.168)-(tcb->m_cWnd)-(segmentsAcked)-(0.186));
tcb->m_cWnd = (int) (32.303+(31.926)+(57.411)+(20.889)+(tcb->m_cWnd)+(74.425)+(19.126)+(83.585));
tcb->m_ssThresh = (int) (78.64-(94.889)-(tcb->m_segmentSize));
int cLbyXEiwXPttRWGP = (int) (7.824*(24.832)*(29.417)*(34.468)*(90.478)*(8.55)*(tcb->m_segmentSize));
cLbyXEiwXPttRWGP = (int) (80.021+(36.432)+(21.756)+(61.682)+(31.197)+(26.209)+(76.767)+(94.725));
if (tcb->m_segmentSize < cLbyXEiwXPttRWGP) {
	segmentsAcked = (int) (57.098-(2.793)-(cLbyXEiwXPttRWGP)-(65.028)-(97.22));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((0.1)+(30.508)+(0.1)+(82.525))/((92.158)));
	ReduceCwnd (tcb);
	cLbyXEiwXPttRWGP = (int) (tcb->m_ssThresh+(15.786));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (0.1/0.1);
