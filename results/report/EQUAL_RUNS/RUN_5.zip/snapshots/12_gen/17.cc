tcb->m_ssThresh = (int) (((80.028)+((17.634*(75.404)*(tcb->m_cWnd)*(20.108)*(85.312)*(82.579)*(85.786)))+(0.1)+(95.268)+((18.423*(53.764)*(60.937)*(14.508)))+(84.007))/((0.1)));
tcb->m_segmentSize = (int) (86.644-(61.228)-(71.335)-(segmentsAcked)-(tcb->m_ssThresh)-(94.66));
tcb->m_cWnd = (int) ((29.364-(70.853)-(83.403)-(54.227)-(6.011)-(19.175)-(85.248))/89.576);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh < segmentsAcked) {
	segmentsAcked = (int) (95.121*(18.299)*(segmentsAcked)*(tcb->m_segmentSize)*(16.441));
	tcb->m_segmentSize = (int) (0.1/74.015);

} else {
	segmentsAcked = (int) (2.745*(tcb->m_segmentSize)*(tcb->m_ssThresh));

}
