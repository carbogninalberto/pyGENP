float PmNtSXtgQzStyKcy = (float) (-75.203/13.116);
float RaxmocRdQOgaFrjZ = (float) (41.803*(-80.898)*(-85.019)*(90.285)*(50.349)*(58.364)*(-47.75)*(-49.739)*(45.422));
tcb->m_segmentSize = (int) (58.753+(40.319)+(86.048)+(37.981)+(-61.752)+(99.254)+(5.02));
float SGePNcCCoynjRbUw = (float) 6.091;
if (SGePNcCCoynjRbUw != tcb->m_cWnd) {
	SGePNcCCoynjRbUw = (float) (6.217/8.493);

} else {
	SGePNcCCoynjRbUw = (float) (11.074-(-60.02)-(tcb->m_segmentSize)-(30.157));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
RaxmocRdQOgaFrjZ = (float) (((-8.573)+((77.087+(segmentsAcked)+(-60.913)))+(-50.715)+(-9.153)+(86.321))/((-85.623)+(-35.308)));
if (SGePNcCCoynjRbUw == SGePNcCCoynjRbUw) {
	SGePNcCCoynjRbUw = (float) (SGePNcCCoynjRbUw*(22.968)*(36.298)*(41.303)*(tcb->m_cWnd)*(segmentsAcked)*(2.007)*(0.71)*(RaxmocRdQOgaFrjZ));
	RaxmocRdQOgaFrjZ = (float) (17.949+(74.511));

} else {
	SGePNcCCoynjRbUw = (float) (99.627+(70.024)+(29.073)+(47.805)+(61.921)+(RaxmocRdQOgaFrjZ)+(16.681)+(44.082));

}
PmNtSXtgQzStyKcy = (float) (-35.853+(-35.56)+(-93.02)+(22.332)+(34.298)+(-57.567)+(-95.389)+(35.165)+(-3.539));
