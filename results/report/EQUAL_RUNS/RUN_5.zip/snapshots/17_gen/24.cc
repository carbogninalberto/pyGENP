if (tcb->m_cWnd == tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (55.722/92.452);

}
tcb->m_cWnd = (int) (20.91-(99.877));
segmentsAcked = (int) (54.423*(tcb->m_ssThresh)*(51.972)*(39.334)*(58.645)*(34.265));
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	segmentsAcked = (int) (31.087*(67.981)*(tcb->m_cWnd)*(32.599)*(segmentsAcked)*(4.348));

} else {
	segmentsAcked = (int) (69.866-(77.229)-(20.356)-(tcb->m_segmentSize));

}
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (94.216/0.1);

}
