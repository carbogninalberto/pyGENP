if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (36.906+(16.056));
	tcb->m_ssThresh = (int) (11.457-(tcb->m_ssThresh)-(93.26)-(27.685)-(93.48)-(segmentsAcked)-(74.019));
	tcb->m_cWnd = (int) ((87.289-(tcb->m_cWnd))/24.435);

} else {
	tcb->m_ssThresh = (int) (71.083+(14.289)+(10.668));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	segmentsAcked = (int) (42.848-(39.993)-(tcb->m_ssThresh)-(59.947)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(31.613)-(tcb->m_ssThresh)-(44.398));
	tcb->m_segmentSize = (int) (40.987-(8.098)-(23.066)-(94.637)-(16.15)-(34.174)-(tcb->m_cWnd)-(44.248));

} else {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (24.085+(2.568)+(12.095)+(76.757)+(91.933)+(87.526)+(33.629)+(2.75)+(53.694));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (5.307+(35.605)+(segmentsAcked)+(segmentsAcked)+(52.39)+(95.479)+(37.909));

} else {
	tcb->m_segmentSize = (int) (38.148+(39.643)+(18.038));
	segmentsAcked = (int) (tcb->m_segmentSize+(tcb->m_ssThresh)+(52.173)+(8.484)+(tcb->m_ssThresh)+(13.15));
	segmentsAcked = (int) ((((99.565-(18.202)-(93.476)-(tcb->m_cWnd)-(tcb->m_cWnd)-(53.62)-(40.875)))+((tcb->m_cWnd+(25.374)+(47.603)+(tcb->m_segmentSize)+(39.772)))+(38.898)+(0.1)+(15.663)+(10.534)+(0.1))/((41.113)));

}
segmentsAcked = (int) (1.74*(62.228)*(43.771)*(tcb->m_segmentSize)*(75.402));
