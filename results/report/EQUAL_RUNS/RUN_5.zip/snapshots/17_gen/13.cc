int ABvsFjdYWXdsoMLv = (int) (67.273*(54.298));
float dfkkmQOddzurLKZE = (float) (56.081-(1.305)-(44.477)-(tcb->m_ssThresh)-(87.221)-(53.127)-(tcb->m_segmentSize));
tcb->m_cWnd = (int) (4.379-(99.157)-(54.947)-(93.831)-(53.155)-(tcb->m_segmentSize));
dfkkmQOddzurLKZE = (float) (0.1/0.1);
float bPzWLWZeCmYSEETM = (float) (67.647*(42.529)*(59.252)*(76.842)*(83.835)*(29.203)*(79.809)*(68.383));
if (tcb->m_segmentSize >= ABvsFjdYWXdsoMLv) {
	bPzWLWZeCmYSEETM = (float) ((((93.007+(52.419)+(12.372)+(44.868)+(91.327)+(77.504)+(86.032)))+(0.1)+(60.936)+((ABvsFjdYWXdsoMLv-(dfkkmQOddzurLKZE)-(51.365)-(48.883)-(22.08)-(0.067)-(33.143)-(segmentsAcked)-(94.622)))+(0.1)+(17.557))/((13.332)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	bPzWLWZeCmYSEETM = (float) (dfkkmQOddzurLKZE-(9.242)-(35.716)-(52.624));
	dfkkmQOddzurLKZE = (float) (tcb->m_ssThresh*(45.618)*(21.689)*(tcb->m_ssThresh));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
