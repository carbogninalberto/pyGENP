ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (40.299+(94.887)+(27.951)+(73.637)+(76.436)+(tcb->m_cWnd)+(19.051)+(79.257));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (10.667-(tcb->m_cWnd)-(tcb->m_cWnd)-(85.259)-(89.245));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(49.812)*(35.719)*(19.586)*(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (18.532-(tcb->m_ssThresh)-(13.308)-(8.991)-(24.494)-(48.492)-(27.736)-(50.279)-(93.367));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float HLSNGnKmAZPoMQsu = (float) (tcb->m_segmentSize*(4.44)*(48.474)*(84.158)*(26.869)*(13.534));
