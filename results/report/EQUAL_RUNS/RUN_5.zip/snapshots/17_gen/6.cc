tcb->m_cWnd = (int) (-22.602*(39.568));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-51.689/19.884);
