TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int jhUwOeuSMjLBqWLY = (int) (tcb->m_ssThresh+(42.721)+(11.018)+(65.674)+(12.342)+(84.621)+(tcb->m_segmentSize)+(tcb->m_ssThresh));
if (segmentsAcked <= tcb->m_ssThresh) {
	jhUwOeuSMjLBqWLY = (int) (37.6-(71.976)-(tcb->m_cWnd)-(12.016)-(74.736)-(74.388)-(22.811)-(tcb->m_ssThresh)-(77.2));
	tcb->m_ssThresh = (int) ((91.674*(13.626)*(1.064)*(51.897)*(95.411)*(16.275))/68.463);
	tcb->m_cWnd = (int) ((7.616-(49.63)-(35.128)-(1.248)-(69.862)-(segmentsAcked)-(32.93)-(74.094))/(segmentsAcked*(tcb->m_ssThresh)*(62.676)));

} else {
	jhUwOeuSMjLBqWLY = (int) (82.322*(93.382)*(32.578)*(19.033)*(77.454));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (61.58+(84.422)+(23.845)+(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (63.173+(44.542)+(56.23)+(70.471));

}
int kzTATUONEhacHVkX = (int) (55.251*(2.715)*(14.603)*(71.759)*(segmentsAcked));
if (tcb->m_segmentSize <= segmentsAcked) {
	segmentsAcked = (int) (((74.808)+(76.836)+((63.82*(25.74)*(64.718)*(83.431)*(83.488)))+(0.1)+(66.232)+(32.199))/((71.962)+(72.845)+(34.749)));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+((jhUwOeuSMjLBqWLY*(46.566)*(31.665)*(26.406)*(79.128)*(tcb->m_segmentSize)))+(6.537))/((0.1)+(86.703)+(99.918)+(94.091)));
	ReduceCwnd (tcb);

}
