int eQJXDODaQsTsXOgS = (int) 2.584;
eQJXDODaQsTsXOgS = (int) (20.219-(25.935)-(23.461)-(-61.634));
