if (tcb->m_ssThresh == tcb->m_cWnd) {
	segmentsAcked = (int) (87.267+(89.001)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (35.154*(44.595)*(90.95)*(30.559)*(5.109)*(6.676));
	tcb->m_cWnd = (int) (40.689-(18.797)-(92.379)-(54.043)-(43.698)-(85.314));
	tcb->m_cWnd = (int) (61.796*(11.991));

}
if (segmentsAcked < segmentsAcked) {
	segmentsAcked = (int) (35.567*(68.522)*(57.782)*(tcb->m_ssThresh)*(40.548)*(12.41)*(10.361)*(tcb->m_ssThresh)*(76.16));
	segmentsAcked = (int) (31.572/0.1);

} else {
	segmentsAcked = (int) (14.458-(42.981)-(27.476)-(28.777));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
