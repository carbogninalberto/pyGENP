float xWCzJGKTDwJKOELC = (float) (-13.566*(8.135));
int VxMPJKCmWNgwIoel = (int) 54.047;
VxMPJKCmWNgwIoel = (int) (-49.478-(58.083)-(-54.918)-(-62.371)-(-26.943)-(32.387)-(-88.133)-(-55.013)-(35.441));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (18.576*(35.111)*(tcb->m_cWnd)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(37.029)*(33.662)*(90.916)*(45.513)*(50.369));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(37.029)*(33.662)*(90.916)*(45.513)*(50.369));

} else {
	tcb->m_segmentSize = (int) (18.576*(35.111)*(tcb->m_cWnd)*(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
