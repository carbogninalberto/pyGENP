ReduceCwnd (tcb);
float mkIpdsbVCdpxTcbt = (float) 90.366;
if (mkIpdsbVCdpxTcbt != mkIpdsbVCdpxTcbt) {
	tcb->m_segmentSize = (int) (27.386*(tcb->m_cWnd)*(82.187));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (1.249+(80.818)+(74.368)+(74.213));

}
tcb->m_cWnd = (int) ((((tcb->m_ssThresh*(-15.999)*(-21.533)*(4.506)*(-52.73)*(tcb->m_ssThresh)))+((tcb->m_segmentSize*(6.968)*(98.817)))+((-63.71+(84.275)+(55.345)+(-78.723)+(-5.243)+(86.762)+(-25.648)))+(-47.075)+(-97.811)+(-81.988)+(-88.147))/((82.945)));
tcb->m_segmentSize = (int) (-2.752-(92.74)-(87.817)-(-99.509)-(44.607)-(62.599)-(-38.372)-(49.546)-(29.366));
segmentsAcked = (int) (25.416-(-41.288)-(96.009)-(53.795)-(33.451)-(96.759));
segmentsAcked = (int) (57.863-(-89.0)-(47.575)-(13.692)-(-64.52)-(58.665));
if (tcb->m_segmentSize < segmentsAcked) {
	segmentsAcked = (int) ((((99.57+(92.763)+(15.686)+(53.984)+(17.231)))+(0.1)+(0.1)+((7.522*(45.828)*(27.749)*(69.051)*(74.875)*(mkIpdsbVCdpxTcbt)*(38.57)))+(5.263))/((44.314)+(94.478)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(17.617)*(84.423));

}
if (tcb->m_segmentSize < segmentsAcked) {
	segmentsAcked = (int) ((((99.57+(92.763)+(15.686)+(53.984)+(17.231)))+(0.1)+(0.1)+((7.522*(45.828)*(27.749)*(69.051)*(74.875)*(mkIpdsbVCdpxTcbt)*(38.57)))+(5.263))/((44.314)+(94.478)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(17.617)*(84.423));

}
if (mkIpdsbVCdpxTcbt <= tcb->m_segmentSize) {
	segmentsAcked = (int) (mkIpdsbVCdpxTcbt-(24.147)-(47.64)-(51.426)-(80.628)-(38.0)-(40.268));
	segmentsAcked = (int) (10.765*(77.169)*(99.77)*(74.81)*(42.357)*(55.638)*(97.284));
	tcb->m_segmentSize = (int) (81.981-(50.393)-(60.365)-(46.632)-(5.926)-(28.656)-(26.618)-(57.408)-(45.766));

} else {
	segmentsAcked = (int) (34.857*(67.253)*(27.74));

}
if (mkIpdsbVCdpxTcbt <= tcb->m_segmentSize) {
	segmentsAcked = (int) (mkIpdsbVCdpxTcbt-(79.649)-(47.64)-(51.426)-(80.628)-(38.0)-(40.268));
	segmentsAcked = (int) (10.765*(77.169)*(99.77)*(74.81)*(42.357)*(55.638)*(97.284));
	tcb->m_segmentSize = (int) (81.981-(50.393)-(60.365)-(46.632)-(5.926)-(28.656)-(26.618)-(57.408)-(45.766));

} else {
	segmentsAcked = (int) (34.857*(67.253)*(27.74));

}
