float UUfGITEwWhoHYJhC = (float) (-57.777-(18.873)-(-68.225)-(45.077)-(-24.064)-(-25.803)-(18.871)-(-25.555));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (28.54*(7.879)*(56.929)*(72.902));

} else {
	tcb->m_cWnd = (int) (99.319*(91.473)*(49.822)*(38.328)*(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-82.145*(-30.203)*(67.021)*(-46.649)*(-88.966)*(-63.869));
