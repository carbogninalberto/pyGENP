float rjativgHnGYUwGnC = (float) 53.918;
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (29.965+(15.289)+(98.014)+(-92.268)+(-97.348)+(75.291)+(-77.1));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= rjativgHnGYUwGnC) {
	tcb->m_segmentSize = (int) ((((44.148+(70.932)+(59.019)+(79.72)+(56.582)+(37.166)))+((94.0*(82.667)*(60.252)*(85.158)*(91.953)*(13.406)*(32.416)*(segmentsAcked)*(38.325)))+(66.512)+(0.1)+(79.69)+(0.1))/((0.1)+(59.493)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (61.207-(84.895)-(48.874)-(90.005)-(73.171)-(96.889)-(98.552));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	rjativgHnGYUwGnC = (float) (67.784*(89.675)*(1.485));

}
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
