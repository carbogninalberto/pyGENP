float goksirDpbGPrtQaW = (float) (2.142-(11.871)-(-11.568)-(88.386)-(-77.22));
tcb->m_segmentSize = (int) (10.143-(97.411)-(72.312));
tcb->m_cWnd = (int) (10.014*(96.752)*(40.698)*(-22.047));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
