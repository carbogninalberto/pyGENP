int VxMPJKCmWNgwIoel = (int) (-80.764-(-50.792)-(-82.407)-(-59.194));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
