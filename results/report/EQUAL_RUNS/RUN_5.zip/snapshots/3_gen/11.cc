segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-97.693+(-76.132)+(95.786)+(13.224)+(-26.385)+(-7.574));
