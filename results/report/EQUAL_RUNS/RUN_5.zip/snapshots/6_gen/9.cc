int gioCJXpkkxuDWaCb = (int) ((29.106*(-6.187)*(-72.703))/84.033);
int AyRiwHPkighdOQIM = (int) (-54.362*(72.799)*(-26.678)*(-33.628)*(78.711)*(23.849)*(77.293)*(97.167));
segmentsAcked = (int) (14.948-(43.659)-(-64.227)-(8.097)-(-57.81));
int ZnDXWjlcHsWUmTxh = (int) (1.912+(-52.005)+(-47.578)+(-37.775)+(-77.204)+(-38.375)+(83.402));
segmentsAcked = (int) (-17.263-(65.208)-(89.997)-(-87.543)-(-74.086));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
