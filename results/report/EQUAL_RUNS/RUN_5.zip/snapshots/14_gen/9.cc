segmentsAcked = (int) (70.596+(84.045)+(98.834));
tcb->m_cWnd = (int) (98.009-(-16.323));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
