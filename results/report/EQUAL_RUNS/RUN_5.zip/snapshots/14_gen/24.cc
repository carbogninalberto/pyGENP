segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (segmentsAcked+(31.583)+(74.718)+(16.074)+(33.215)+(43.628));
tcb->m_segmentSize = (int) (75.593+(97.583)+(90.679));
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (37.505-(11.633)-(tcb->m_ssThresh)-(29.342)-(99.31)-(79.693)-(82.086)-(tcb->m_cWnd)-(24.257));
	tcb->m_cWnd = (int) (45.222*(62.1)*(tcb->m_cWnd)*(71.453)*(86.23));

} else {
	segmentsAcked = (int) (0.1/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) ((85.93-(82.671)-(95.884)-(47.318)-(tcb->m_cWnd)-(64.219))/0.1);
