int pGWWCMOzeftpHhjb = (int) (-34.09+(-87.299)+(81.532));
float IflMKXxQMpxFdpFL = (float) (-5.907*(-90.882)*(-95.776)*(-17.349)*(-93.645)*(67.224)*(98.78)*(-97.691)*(-10.199));
segmentsAcked = (int) (8.006/-12.08);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
