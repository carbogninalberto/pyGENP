if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (70.772-(tcb->m_ssThresh)-(2.593)-(10.84)-(85.255)-(35.675)-(30.103));
	tcb->m_ssThresh = (int) (88.055-(81.923)-(95.718)-(62.177));

} else {
	tcb->m_cWnd = (int) (3.865-(61.419)-(42.184)-(26.674)-(92.144)-(84.89)-(56.77)-(49.313));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked == tcb->m_segmentSize) {
	segmentsAcked = (int) (63.917*(29.557)*(5.523)*(tcb->m_ssThresh)*(67.444)*(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (7.196*(24.26)*(tcb->m_ssThresh)*(23.428)*(tcb->m_cWnd)*(65.568)*(40.773)*(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (92.671-(52.995));

}
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (55.887-(28.68)-(67.477));
	tcb->m_cWnd = (int) (26.732+(tcb->m_segmentSize)+(33.288));

} else {
	tcb->m_cWnd = (int) (18.288+(41.281)+(96.89)+(segmentsAcked)+(segmentsAcked)+(49.938)+(tcb->m_cWnd));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (2.993+(16.488)+(tcb->m_ssThresh)+(86.236)+(segmentsAcked)+(segmentsAcked)+(tcb->m_ssThresh)+(89.158)+(85.431));
tcb->m_segmentSize = (int) (12.285-(82.219)-(44.891)-(44.853));
segmentsAcked = (int) (16.957*(53.124)*(81.78)*(17.196)*(36.334)*(45.043)*(21.358)*(56.219));
segmentsAcked = SlowStart (tcb, segmentsAcked);
