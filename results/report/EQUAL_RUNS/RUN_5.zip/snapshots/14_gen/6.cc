if (segmentsAcked != tcb->m_segmentSize) {
	segmentsAcked = (int) (52.826/0.1);
	segmentsAcked = (int) (72.971+(50.592)+(65.22)+(segmentsAcked)+(segmentsAcked));

} else {
	segmentsAcked = (int) (3.674*(segmentsAcked)*(-50.571)*(95.696)*(80.245));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
