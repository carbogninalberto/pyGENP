segmentsAcked = (int) (0.1/0.1);
tcb->m_cWnd = (int) (75.971*(tcb->m_ssThresh)*(68.541)*(tcb->m_cWnd)*(25.914)*(50.043)*(tcb->m_segmentSize)*(3.673)*(42.81));
tcb->m_segmentSize = (int) (62.035+(tcb->m_cWnd)+(22.068)+(tcb->m_cWnd)+(93.924));
ReduceCwnd (tcb);
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) ((segmentsAcked-(61.341)-(69.371)-(50.025)-(67.2)-(49.817)-(57.827))/20.875);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) ((96.077+(22.793)+(15.306)+(tcb->m_ssThresh)+(27.776)+(39.844)+(56.851)+(44.586))/0.1);

}
