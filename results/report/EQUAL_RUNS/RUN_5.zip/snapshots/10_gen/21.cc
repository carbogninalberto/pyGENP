segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (83.64/0.1);
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (85.696/0.1);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (0.1/40.682);
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	segmentsAcked = (int) ((18.4-(78.225)-(40.242)-(40.674))/21.394);

} else {
	segmentsAcked = (int) (54.242+(6.37)+(tcb->m_ssThresh)+(76.32)+(64.804)+(39.027)+(99.778)+(tcb->m_ssThresh));
	ReduceCwnd (tcb);

}
