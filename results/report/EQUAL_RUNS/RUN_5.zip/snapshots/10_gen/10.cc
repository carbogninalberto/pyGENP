float MvfPJkQvCUwyRBrn = (float) (-27.451+(-6.262)+(78.684));
float ObzOihqjXdjMrjSB = (float) (39.335-(-6.322)-(-69.371)-(92.056)-(-77.841)-(20.457)-(-5.788)-(-10.421));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float KbUbWJonbMjYxJrh = (float) (39.149/(44.029+(-34.307)+(90.141)+(-21.421)+(8.884)));
tcb->m_cWnd = (int) (3.833+(91.124)+(47.258)+(-67.801)+(-84.588)+(-86.9)+(80.568)+(24.849));
tcb->m_segmentSize = (int) (-96.071+(68.276)+(-96.712)+(-44.167)+(-80.221)+(-30.398)+(-10.297)+(27.831));
