if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (84.471-(5.92)-(segmentsAcked)-(15.561)-(22.325)-(65.5)-(99.236)-(tcb->m_cWnd)-(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (46.697+(58.354)+(76.612)+(4.766)+(7.547)+(tcb->m_cWnd)+(41.12)+(63.814));

} else {
	tcb->m_segmentSize = (int) (88.401+(tcb->m_ssThresh)+(87.843)+(12.077)+(67.979));

}
tcb->m_cWnd = (int) (1.61+(7.351)+(17.304)+(21.199)+(63.858)+(11.022)+(1.951));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (75.5+(75.857)+(35.954)+(10.374)+(92.906)+(56.579)+(44.255)+(14.595));
CongestionAvoidance (tcb, segmentsAcked);
