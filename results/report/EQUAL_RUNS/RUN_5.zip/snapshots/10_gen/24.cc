segmentsAcked = (int) (20.676*(9.816));
float aZkBwJhBKrIljvAe = (float) (77.701+(3.214)+(93.193)+(92.645));
if (tcb->m_segmentSize >= aZkBwJhBKrIljvAe) {
	tcb->m_segmentSize = (int) (2.167+(5.054)+(tcb->m_cWnd)+(24.552)+(9.928)+(36.891)+(49.289)+(87.432));
	tcb->m_cWnd = (int) (28.431/34.288);
	aZkBwJhBKrIljvAe = (float) (17.773*(37.691));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((69.177)+(32.486)));

}
float mNuIaowZVRDSdYiO = (float) (22.857*(7.144));
int BMaSWtKAfwCeLncH = (int) (0.1/34.034);
if (segmentsAcked == mNuIaowZVRDSdYiO) {
	tcb->m_ssThresh = (int) (69.96+(82.012));
	BMaSWtKAfwCeLncH = (int) (4.866-(80.623)-(95.55)-(33.08)-(28.23)-(99.295)-(17.025)-(15.055));
	segmentsAcked = (int) (BMaSWtKAfwCeLncH+(62.12)+(81.111)+(37.961)+(97.513));

} else {
	tcb->m_ssThresh = (int) (33.285-(tcb->m_cWnd)-(84.764)-(60.943));

}
if (BMaSWtKAfwCeLncH != tcb->m_segmentSize) {
	mNuIaowZVRDSdYiO = (float) (36.922+(46.891)+(23.972));

} else {
	mNuIaowZVRDSdYiO = (float) ((40.59+(87.601)+(1.173)+(62.524)+(44.882))/0.1);
	BMaSWtKAfwCeLncH = (int) (segmentsAcked-(75.021)-(39.465)-(29.869)-(26.87)-(96.575)-(46.385)-(tcb->m_cWnd));

}
