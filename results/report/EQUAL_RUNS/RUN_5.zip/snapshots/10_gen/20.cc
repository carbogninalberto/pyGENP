ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(4.612)+(93.821)+(segmentsAcked));
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (85.411-(segmentsAcked)-(3.327)-(24.946)-(76.548)-(90.258)-(79.349)-(3.543)-(94.438));
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(71.758));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (24.861-(72.192)-(41.819)-(tcb->m_cWnd)-(46.412)-(75.27)-(74.936));
	tcb->m_segmentSize = (int) (28.108/(15.085*(tcb->m_segmentSize)*(90.555)*(21.502)*(34.202)*(segmentsAcked)));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (92.235+(tcb->m_cWnd)+(tcb->m_ssThresh)+(segmentsAcked)+(81.421)+(1.425));
