segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (79.902*(50.296));
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(21.878)+(13.973)+(39.362)+(23.287));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(13.709)-(tcb->m_ssThresh)-(79.722)-(segmentsAcked)-(84.759)-(78.555)-(58.768));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (28.487*(8.966)*(tcb->m_ssThresh)*(51.532)*(35.186)*(30.326));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (13.159*(99.576)*(51.438)*(15.46)*(0.414)*(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
