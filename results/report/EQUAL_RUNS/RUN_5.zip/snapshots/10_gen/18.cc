tcb->m_cWnd = (int) (43.187+(22.229)+(33.934));
tcb->m_segmentSize = (int) (84.987+(33.282)+(51.7)+(70.635)+(9.53)+(74.057)+(86.435)+(89.614));
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (11.729*(36.422)*(45.405)*(1.071)*(24.643)*(69.051)*(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (90.969*(tcb->m_cWnd));

}
tcb->m_ssThresh = (int) (72.573-(61.854)-(10.701)-(40.405)-(87.192)-(72.574));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (32.42+(22.401)+(81.764)+(53.412)+(92.377)+(95.743)+(98.021));

} else {
	tcb->m_cWnd = (int) (12.671-(83.029)-(segmentsAcked)-(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
