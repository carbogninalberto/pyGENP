ReduceCwnd (tcb);
tcb->m_ssThresh = (int) ((40.223+(81.148)+(tcb->m_segmentSize)+(12.182)+(89.881))/0.1);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (45.403*(27.729)*(11.659)*(5.621));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) ((52.245-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(33.005)-(28.623)-(3.017)-(5.634)-(64.207))/99.005);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(76.247));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (20.543+(segmentsAcked)+(segmentsAcked));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (46.42+(49.804));
