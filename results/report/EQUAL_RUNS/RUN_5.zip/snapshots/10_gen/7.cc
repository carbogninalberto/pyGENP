float YbTgyhWeobrZnoqq = (float) (-90.534/-55.198);
float NYBTGhwKYhavWZKf = (float) 62.395;
if (segmentsAcked < NYBTGhwKYhavWZKf) {
	NYBTGhwKYhavWZKf = (float) (17.04-(95.052)-(2.575)-(57.393)-(segmentsAcked)-(68.11)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (94.715*(72.85)*(46.966));

} else {
	NYBTGhwKYhavWZKf = (float) (11.614+(17.417)+(94.088)+(85.824)+(tcb->m_cWnd)+(YbTgyhWeobrZnoqq));

}
segmentsAcked = (int) (73.39-(-37.99)-(44.491)-(49.3)-(-8.182)-(82.136));
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (YbTgyhWeobrZnoqq-(68.319)-(94.391)-(tcb->m_segmentSize)-(25.522)-(98.318));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (21.262*(23.535)*(3.367)*(18.577)*(36.802)*(32.877));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
