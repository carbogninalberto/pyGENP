float SGePNcCCoynjRbUw = (float) 6.091;
tcb->m_segmentSize = (int) (59.831+(-16.658)+(-10.297)+(-25.157)+(31.884)+(-84.415)+(3.382));
float RaxmocRdQOgaFrjZ = (float) (40.202*(-11.778)*(-88.382)*(-46.65)*(-64.294)*(-46.667)*(23.539)*(-6.691)*(-27.028));
if (SGePNcCCoynjRbUw != tcb->m_cWnd) {
	SGePNcCCoynjRbUw = (float) (11.074-(-60.02)-(tcb->m_segmentSize)-(30.157));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	SGePNcCCoynjRbUw = (float) (6.217/8.493);

}
int xUkpFghWigGumPKA = (int) (73.772+(-28.233)+(-21.622)+(8.949)+(15.197)+(-99.21)+(16.563)+(23.565)+(11.509));
CongestionAvoidance (tcb, segmentsAcked);
RaxmocRdQOgaFrjZ = (float) (((89.864)+((74.424+(segmentsAcked)+(70.436)))+(33.305)+(59.73)+(-7.46))/((-47.003)+(49.648)));
if (SGePNcCCoynjRbUw == SGePNcCCoynjRbUw) {
	SGePNcCCoynjRbUw = (float) (SGePNcCCoynjRbUw*(22.968)*(36.298)*(41.303)*(tcb->m_cWnd)*(segmentsAcked)*(2.007)*(0.71)*(RaxmocRdQOgaFrjZ));
	RaxmocRdQOgaFrjZ = (float) (17.949+(74.511));

} else {
	SGePNcCCoynjRbUw = (float) (99.627+(70.024)+(29.073)+(47.805)+(61.921)+(RaxmocRdQOgaFrjZ)+(16.681)+(44.082));

}
float PmNtSXtgQzStyKcy = (float) 45.418;
PmNtSXtgQzStyKcy = (float) (48.781+(-89.543)+(-71.678)+(93.872)+(20.511)+(29.216)+(1.724)+(-92.848)+(69.346));
