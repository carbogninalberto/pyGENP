int ZWGZyLqARYsPDWxC = (int) (-0.679-(-11.445)-(21.439)-(-81.836)-(-77.687)-(54.543)-(-52.2));
CongestionAvoidance (tcb, segmentsAcked);
int tcIBLjpIuqPVewev = (int) 98.548;
segmentsAcked = SlowStart (tcb, segmentsAcked);
