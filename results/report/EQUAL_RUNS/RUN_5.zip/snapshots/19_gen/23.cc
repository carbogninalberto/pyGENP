float HLSNGnKmAZPoMQsu = (float) 68.493;
