int tcIBLjpIuqPVewev = (int) 5.28;
if (tcIBLjpIuqPVewev <= tcb->m_segmentSize) {
	segmentsAcked = (int) (56.607*(78.037)*(0.586)*(15.274)*(83.26)*(54.196)*(45.025)*(tcIBLjpIuqPVewev)*(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (tcb->m_cWnd*(48.262)*(53.155));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
