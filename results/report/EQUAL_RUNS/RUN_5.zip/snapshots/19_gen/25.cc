float SGePNcCCoynjRbUw = (float) 6.091;
float RaxmocRdQOgaFrjZ = (float) (10.212*(-69.835)*(-36.935)*(-65.288)*(20.993)*(72.919)*(-91.986)*(5.076)*(-28.654));
if (tcb->m_segmentSize >= RaxmocRdQOgaFrjZ) {
	segmentsAcked = (int) (92.65-(36.305)-(47.5)-(89.325)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (72.534-(24.861)-(68.199)-(22.891)-(74.188)-(38.987)-(71.921));

} else {
	segmentsAcked = (int) (20.118*(0.96)*(8.332)*(3.159)*(67.531)*(23.033));
	tcb->m_cWnd = (int) (7.949+(segmentsAcked)+(65.268)+(33.02)+(59.025)+(24.783)+(73.959)+(9.9));

}
tcb->m_segmentSize = (int) (-74.102+(-86.571)+(20.619)+(63.226)+(-0.895)+(25.873)+(-52.109));
