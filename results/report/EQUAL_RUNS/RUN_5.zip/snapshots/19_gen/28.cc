tcb->m_segmentSize = (int) (9.086*(67.914));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (73.785+(91.479)+(36.097)+(80.884)+(tcb->m_segmentSize)+(28.841));

} else {
	tcb->m_segmentSize = (int) (52.956-(12.299)-(53.964));

}
segmentsAcked = (int) (-92.918*(-37.99)*(65.535));
