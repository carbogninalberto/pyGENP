if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (85.366-(tcb->m_cWnd)-(66.825)-(22.567)-(13.107)-(tcb->m_segmentSize)-(17.952)-(tcb->m_cWnd)-(46.869));

} else {
	tcb->m_segmentSize = (int) (58.436-(tcb->m_segmentSize)-(60.161)-(tcb->m_segmentSize)-(74.322)-(97.79)-(38.936));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (76.569/0.1);

}
tcb->m_segmentSize = (int) (-73.637*(-7.13));
