int unuMExZUtJqAsvqr = (int) (49.345*(-85.722)*(-9.881)*(-95.586)*(21.543)*(-96.596)*(20.172)*(-75.887)*(91.881));
int hsYPtPzhdqbRbKea = (int) (86.365-(7.738)-(98.031)-(-25.375)-(-7.191));
segmentsAcked = (int) (67.893*(81.972)*(-99.492)*(-98.679)*(69.667)*(-40.253)*(42.01));
tcb->m_cWnd = (int) (-24.551/72.891);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-82.378/-9.63);
ReduceCwnd (tcb);
