float HLSNGnKmAZPoMQsu = (float) (9.878*(95.979)*(48.393)*(-90.51)*(27.078)*(-83.144));
HLSNGnKmAZPoMQsu = (float) (-22.684/-99.313);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (1.243-(0.572)-(62.011)-(53.402)-(-91.558)-(88.384)-(41.53)-(72.456)-(-78.744));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-39.635-(-12.291)-(16.087)-(-61.782)-(88.403)-(88.736)-(-31.553)-(-48.635)-(-77.633));
segmentsAcked = SlowStart (tcb, segmentsAcked);
