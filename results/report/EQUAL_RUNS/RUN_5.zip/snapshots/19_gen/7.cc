int EyRfosbSdfGLJDGh = (int) (21.124-(87.118)-(-99.925)-(-17.788));
ReduceCwnd (tcb);
