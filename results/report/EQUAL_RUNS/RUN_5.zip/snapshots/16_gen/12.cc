if (tcb->m_ssThresh == segmentsAcked) {
	segmentsAcked = (int) (32.996-(tcb->m_ssThresh)-(40.818));

} else {
	segmentsAcked = (int) (35.01/0.1);
	tcb->m_ssThresh = (int) (segmentsAcked-(11.297)-(tcb->m_segmentSize)-(23.205)-(49.145)-(73.589)-(30.547));

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (49.208+(25.253)+(71.666)+(24.268)+(tcb->m_cWnd)+(76.117)+(29.883)+(49.449)+(74.653));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (tcb->m_cWnd*(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (90.097*(tcb->m_segmentSize)*(0.017)*(41.232)*(19.372));
	tcb->m_ssThresh = (int) (37.119+(48.048)+(segmentsAcked)+(97.874)+(75.758)+(76.672)+(82.307));

}
segmentsAcked = (int) (tcb->m_ssThresh+(53.163)+(tcb->m_segmentSize)+(27.525)+(segmentsAcked));
int lnXyOxcseBHRdDGK = (int) (14.945+(46.48)+(94.813)+(28.425)+(59.774)+(51.951)+(81.947)+(9.341));
