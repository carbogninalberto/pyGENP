int tAshkNjFoJUaJsNj = (int) (-16.321+(-22.254)+(40.712)+(-71.714));
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (1.08+(44.635));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(segmentsAcked)+(23.112)+(34.864)+(19.211)+(7.511)+(82.866));
	segmentsAcked = (int) (0.1/88.421);

} else {
	tcb->m_segmentSize = (int) (19.94/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (21.217+(4.015)+(78.554)+(0.027)+(8.125)+(segmentsAcked));

}
CongestionAvoidance (tcb, segmentsAcked);
