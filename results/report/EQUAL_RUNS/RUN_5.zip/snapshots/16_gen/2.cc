float oNaLmqhhrUUNflHL = (float) (-96.833/73.939);
oNaLmqhhrUUNflHL = (float) (82.336-(-70.272)-(15.726)-(-26.748));
