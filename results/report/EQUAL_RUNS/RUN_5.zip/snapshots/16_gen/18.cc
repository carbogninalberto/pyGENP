segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (3.095-(6.142)-(tcb->m_segmentSize));
tcb->m_cWnd = (int) (21.015-(52.53)-(17.024)-(21.489)-(4.576)-(66.086)-(tcb->m_ssThresh)-(tcb->m_segmentSize));
