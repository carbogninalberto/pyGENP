segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	segmentsAcked = (int) (30.376-(41.859)-(tcb->m_ssThresh)-(14.401)-(19.33)-(tcb->m_segmentSize)-(segmentsAcked)-(43.042)-(53.263));
	tcb->m_segmentSize = (int) (5.133-(99.981)-(tcb->m_cWnd)-(47.095)-(68.759)-(tcb->m_cWnd)-(44.695)-(tcb->m_cWnd)-(73.132));

} else {
	segmentsAcked = (int) (17.209-(74.782)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(99.524)-(40.928)-(96.689)-(23.639));
	tcb->m_cWnd = (int) (3.555+(33.134)+(81.81));

}
float HxBVVDIBzCyWwAeU = (float) (8.526/41.173);
