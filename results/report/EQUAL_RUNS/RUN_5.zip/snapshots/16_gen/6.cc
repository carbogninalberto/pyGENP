float SGePNcCCoynjRbUw = (float) (-70.251+(-63.728)+(83.662));
float RaxmocRdQOgaFrjZ = (float) (29.491*(-66.716)*(24.83)*(63.078)*(77.592)*(-76.881)*(-70.396)*(-80.884)*(65.15));
float PmNtSXtgQzStyKcy = (float) (11.732/39.432);
if (SGePNcCCoynjRbUw != tcb->m_cWnd) {
	SGePNcCCoynjRbUw = (float) (6.217/8.493);

} else {
	SGePNcCCoynjRbUw = (float) (11.074-(-60.02)-(tcb->m_segmentSize)-(30.157));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
RaxmocRdQOgaFrjZ = (float) (((-63.089)+((71.813+(segmentsAcked)+(43.229)))+(-29.119)+(-99.798)+(-89.326))/((31.04)+(11.613)));
if (SGePNcCCoynjRbUw == SGePNcCCoynjRbUw) {
	SGePNcCCoynjRbUw = (float) (SGePNcCCoynjRbUw*(22.968)*(36.298)*(41.303)*(tcb->m_cWnd)*(segmentsAcked)*(2.007)*(0.71)*(RaxmocRdQOgaFrjZ));
	RaxmocRdQOgaFrjZ = (float) (17.949+(74.511));

} else {
	SGePNcCCoynjRbUw = (float) (99.627+(70.024)+(29.073)+(47.805)+(61.921)+(RaxmocRdQOgaFrjZ)+(16.681)+(44.082));

}
PmNtSXtgQzStyKcy = (float) (22.751+(-77.514)+(-43.989)+(-53.234)+(-44.605)+(-42.09)+(85.741)+(3.39)+(-86.324));
