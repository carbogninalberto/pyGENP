if (tcb->m_segmentSize != segmentsAcked) {
	segmentsAcked = (int) (94.263-(51.641)-(55.353)-(tcb->m_ssThresh)-(20.99)-(3.648)-(97.533));
	segmentsAcked = (int) (segmentsAcked*(76.901)*(81.042)*(tcb->m_segmentSize)*(82.002)*(4.55)*(43.363));
	tcb->m_cWnd = (int) (27.183+(83.897)+(68.573)+(63.925)+(tcb->m_segmentSize)+(29.154));

} else {
	segmentsAcked = (int) (4.213-(31.77)-(51.898)-(33.152)-(15.332)-(tcb->m_ssThresh)-(tcb->m_segmentSize));

}
tcb->m_cWnd = (int) (91.201*(84.823));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (segmentsAcked*(62.39)*(54.842)*(tcb->m_segmentSize)*(7.146)*(tcb->m_segmentSize));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (0.1/0.1);
