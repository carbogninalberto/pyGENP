if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (85.658+(46.317)+(95.537)+(37.717));

} else {
	tcb->m_ssThresh = (int) (0.1/78.353);
	tcb->m_cWnd = (int) (26.523+(23.97)+(49.326)+(74.832)+(87.069)+(15.036)+(43.102));

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked >= segmentsAcked) {
	segmentsAcked = (int) (66.752*(73.588)*(44.907)*(81.063)*(65.86)*(9.455)*(95.867)*(32.486));
	segmentsAcked = (int) (44.458+(93.218));
	tcb->m_ssThresh = (int) (82.544+(94.899)+(tcb->m_segmentSize)+(22.703));

} else {
	segmentsAcked = (int) (18.53+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(51.915));

}
tcb->m_cWnd = (int) (74.062-(23.686)-(tcb->m_ssThresh));
