tcb->m_cWnd = (int) (tcb->m_segmentSize*(49.523));
segmentsAcked = (int) (0.1/41.09);
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_cWnd = (int) (24.072-(39.361)-(33.673)-(tcb->m_ssThresh)-(83.823)-(tcb->m_cWnd)-(37.554));

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(19.434)+((17.039-(7.728)-(tcb->m_cWnd)))+(0.1))/((86.227)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (52.069*(tcb->m_cWnd)*(tcb->m_cWnd)*(29.609)*(tcb->m_segmentSize)*(40.261));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
