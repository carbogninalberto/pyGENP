TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int sUkECzqqqUWEnBhQ = (int) (69.693/0.1);
int IfboNHEtDIrfPykq = (int) (53.63+(tcb->m_ssThresh)+(6.866)+(19.261)+(sUkECzqqqUWEnBhQ));
if (segmentsAcked < segmentsAcked) {
	segmentsAcked = (int) (99.937+(47.342)+(58.831));

} else {
	segmentsAcked = (int) (tcb->m_cWnd*(41.907));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_ssThresh >= IfboNHEtDIrfPykq) {
	tcb->m_ssThresh = (int) (72.629-(14.906));

} else {
	tcb->m_ssThresh = (int) (48.928*(2.052)*(70.856)*(91.631)*(IfboNHEtDIrfPykq));
	sUkECzqqqUWEnBhQ = (int) (91.644*(37.595)*(7.175)*(tcb->m_cWnd));
	segmentsAcked = (int) (0.597-(sUkECzqqqUWEnBhQ)-(42.756)-(17.754)-(67.31)-(65.707)-(92.349)-(40.053));

}
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (24.866-(tcb->m_cWnd)-(49.835)-(81.576)-(10.071)-(40.914)-(tcb->m_ssThresh)-(33.159));
	tcb->m_cWnd = (int) (93.263/0.1);

} else {
	segmentsAcked = (int) (((22.556)+(62.868)+(0.1)+((3.584*(73.55)))+(63.528))/((0.1)+(72.151)+(0.1)+(0.1)));

}
if (sUkECzqqqUWEnBhQ > sUkECzqqqUWEnBhQ) {
	tcb->m_ssThresh = (int) (0.1/51.331);

} else {
	tcb->m_ssThresh = (int) (57.294-(10.647)-(tcb->m_ssThresh)-(46.139)-(4.528)-(sUkECzqqqUWEnBhQ));
	tcb->m_cWnd = (int) (29.255+(tcb->m_ssThresh));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) (sUkECzqqqUWEnBhQ+(IfboNHEtDIrfPykq)+(sUkECzqqqUWEnBhQ)+(tcb->m_cWnd)+(76.741)+(tcb->m_cWnd)+(39.161));

} else {
	segmentsAcked = (int) (82.98-(2.085)-(55.657)-(41.291)-(85.668));
	segmentsAcked = (int) (15.051+(IfboNHEtDIrfPykq)+(40.091)+(58.828)+(tcb->m_segmentSize));
	IfboNHEtDIrfPykq = (int) (tcb->m_segmentSize*(82.53)*(84.127)*(segmentsAcked)*(70.149));

}
