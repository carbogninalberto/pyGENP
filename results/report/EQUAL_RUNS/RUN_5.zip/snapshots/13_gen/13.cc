ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	segmentsAcked = (int) (7.042*(74.807));
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (0.1/(5.236-(18.653)-(61.666)-(62.485)-(89.045)-(82.079)));
	segmentsAcked = (int) (16.839*(70.872)*(segmentsAcked)*(62.146)*(26.903)*(86.799)*(1.876)*(42.833)*(2.596));
	segmentsAcked = (int) (94.546-(41.516));

}
if (segmentsAcked != segmentsAcked) {
	tcb->m_segmentSize = (int) (((0.1)+((36.281*(29.686)))+(50.228)+(49.994)+(0.1))/((0.1)));
	tcb->m_ssThresh = (int) (22.082*(70.18)*(82.153));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(82.809)+((55.812*(74.994)))+((38.344-(segmentsAcked)-(4.173)-(89.25)))+(64.966))/((91.013)+(0.1)));

}
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (3.999+(48.609));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(27.233)*(87.705)*(18.849)*(69.159)*(46.623)*(23.472)*(4.879)*(53.871));
	tcb->m_cWnd = (int) (39.998+(58.746)+(tcb->m_ssThresh)+(77.723)+(tcb->m_ssThresh)+(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (99.389*(90.624)*(12.865)*(83.759));
	tcb->m_segmentSize = (int) (62.753-(18.427)-(10.584)-(15.698)-(67.2)-(tcb->m_segmentSize)-(63.228));

}
float gshhESzrilcvlGcr = (float) (0.1/0.1);
if (tcb->m_ssThresh >= gshhESzrilcvlGcr) {
	tcb->m_ssThresh = (int) (0.1/94.991);
	gshhESzrilcvlGcr = (float) (25.396*(59.831)*(91.352)*(40.024)*(segmentsAcked)*(20.599)*(5.837)*(98.147));

} else {
	tcb->m_ssThresh = (int) (12.036-(50.256)-(7.798)-(segmentsAcked)-(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
if (gshhESzrilcvlGcr > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (11.077+(73.648)+(42.573));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (74.121*(83.239)*(99.551)*(80.583)*(9.765)*(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (36.59+(41.089)+(50.832)+(tcb->m_ssThresh)+(75.916));

}
