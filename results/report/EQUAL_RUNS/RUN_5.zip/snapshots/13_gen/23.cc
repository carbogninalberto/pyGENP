tcb->m_segmentSize = (int) (46.606+(tcb->m_ssThresh)+(76.387)+(19.432)+(91.279)+(61.185)+(52.45));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (13.39+(56.607)+(tcb->m_ssThresh)+(66.505));
	segmentsAcked = (int) (tcb->m_segmentSize-(26.164));
	tcb->m_ssThresh = (int) (76.661-(87.538)-(tcb->m_cWnd)-(65.195)-(16.316)-(34.986)-(0.222));

} else {
	tcb->m_ssThresh = (int) (17.167-(tcb->m_ssThresh)-(11.124)-(tcb->m_cWnd));
	tcb->m_ssThresh = (int) ((((70.967-(tcb->m_segmentSize)-(31.321)-(tcb->m_ssThresh)-(50.992)-(59.962)))+(52.075)+(0.1)+(0.1))/((0.1)+(0.1)));

}
if (tcb->m_cWnd == tcb->m_segmentSize) {
	segmentsAcked = (int) (3.841*(70.34)*(57.819)*(19.793)*(91.898)*(16.434)*(tcb->m_cWnd)*(36.098));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (64.492*(74.512)*(45.447)*(tcb->m_segmentSize)*(47.168)*(35.976)*(tcb->m_ssThresh)*(55.601));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) ((((80.573-(15.498)))+(10.046)+(29.173)+(64.798))/((93.535)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (13.987-(45.422)-(46.455)-(14.125)-(33.438)-(segmentsAcked)-(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (74.971-(78.371)-(96.638)-(56.348)-(59.173)-(12.615));

}
ReduceCwnd (tcb);
