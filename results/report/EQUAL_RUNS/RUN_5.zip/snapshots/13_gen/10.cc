tcb->m_ssThresh = (int) (63.437/0.1);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (39.148-(tcb->m_segmentSize)-(75.106));
	tcb->m_ssThresh = (int) (93.994+(40.68)+(37.84)+(98.169));
	segmentsAcked = (int) (15.193+(34.199)+(68.722)+(7.687)+(71.408)+(tcb->m_cWnd)+(64.32)+(44.194)+(21.832));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(16.071));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (tcb->m_segmentSize*(41.27));

}
segmentsAcked = (int) (24.399-(3.06));
tcb->m_ssThresh = (int) (41.391-(49.411)-(75.37)-(87.934)-(26.282)-(72.906)-(49.732)-(12.222));
tcb->m_cWnd = (int) (3.451/0.1);
tcb->m_segmentSize = (int) (1.088*(94.503)*(41.571)*(76.629)*(80.5)*(1.269)*(65.857)*(67.832)*(9.326));
float KyvHRXKQIMiTivYF = (float) (46.978*(87.743)*(70.683)*(13.331)*(76.953)*(36.279)*(tcb->m_ssThresh));
