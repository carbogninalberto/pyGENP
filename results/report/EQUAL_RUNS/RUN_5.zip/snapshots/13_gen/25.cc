tcb->m_ssThresh = (int) (tcb->m_ssThresh-(1.331)-(31.888)-(85.913));
if (segmentsAcked != tcb->m_segmentSize) {
	segmentsAcked = (int) (52.826/0.1);
	segmentsAcked = (int) (72.971+(50.592)+(65.22)+(segmentsAcked)+(segmentsAcked));

} else {
	segmentsAcked = (int) (3.674*(segmentsAcked)*(tcb->m_ssThresh)*(95.696)*(80.245));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) ((tcb->m_segmentSize*(80.693)*(tcb->m_segmentSize)*(93.128)*(29.153)*(7.657)*(93.826))/48.01);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
