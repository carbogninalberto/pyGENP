float LWcEfXQtaquzZfuG = (float) (39.022+(13.148)+(-52.917));
