float ooojpWneyfFcCrRg = (float) 29.83;
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_segmentSize = (int) (((66.141)+((23.051+(segmentsAcked)))+(0.1)+(95.569))/((0.1)+(0.1)));
	segmentsAcked = (int) (20.02/34.979);
	ooojpWneyfFcCrRg = (float) ((((41.773*(ooojpWneyfFcCrRg)*(4.262)*(49.693)*(segmentsAcked)*(90.707)*(67.663)*(tcb->m_ssThresh)*(88.862)))+(0.1)+(0.1)+(37.284))/((59.433)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (53.823*(-33.233)*(19.155));
	tcb->m_cWnd = (int) (41.68*(66.31)*(22.173)*(61.95)*(14.728)*(21.266)*(22.733)*(99.95));
	ooojpWneyfFcCrRg = (float) (0.1/0.1);

}
