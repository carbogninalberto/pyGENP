segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((87.876*(tcb->m_cWnd)*(88.797)*(tcb->m_cWnd)*(23.837))/88.24);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (52.653*(51.729));
	tcb->m_ssThresh = (int) (22.552*(82.71)*(31.392));
	segmentsAcked = (int) (54.12*(tcb->m_ssThresh)*(75.775));

} else {
	tcb->m_cWnd = (int) (25.067*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(30.396)*(37.391)*(31.076)*(31.246)*(8.962));

}
float KfvgrHFnAmlHRtrs = (float) (11.438*(4.394)*(76.5));
int deQtjmieSQAoGYdj = (int) ((77.709-(83.271)-(tcb->m_cWnd)-(62.428))/10.722);
