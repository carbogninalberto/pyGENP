if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (34.312+(segmentsAcked)+(62.65)+(96.481));
	tcb->m_cWnd = (int) (82.151-(95.513)-(16.954)-(94.345)-(8.585)-(94.703)-(67.101)-(6.513));

} else {
	segmentsAcked = (int) ((((59.766-(83.497)-(11.515)-(3.059)))+((71.928+(73.316)+(82.348)+(tcb->m_segmentSize)+(98.456)+(50.827)+(16.892)+(32.183)+(14.616)))+(70.206)+(8.139))/((0.1)+(0.1)));
	tcb->m_ssThresh = (int) (13.672*(23.287)*(43.144)*(60.286)*(63.009)*(45.334)*(31.049));
	tcb->m_segmentSize = (int) (86.023-(segmentsAcked)-(71.298));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	segmentsAcked = (int) (65.576-(16.602));
	tcb->m_cWnd = (int) ((((87.059*(18.149)*(34.886)*(94.315)*(41.604)))+(52.329)+(0.1)+((81.963*(tcb->m_ssThresh)*(segmentsAcked)*(64.722)*(97.244)*(89.331)*(97.627)*(70.239)*(42.985)))+(0.1))/((0.1)+(0.1)));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) ((43.979*(92.038)*(78.153)*(46.977))/76.243);
	tcb->m_cWnd = (int) (((0.1)+((69.044+(65.054)+(76.215)+(53.555)+(tcb->m_cWnd)+(3.986)+(97.382)+(14.711)))+((tcb->m_segmentSize-(46.602)-(tcb->m_cWnd)-(29.898)))+(8.619)+(35.284))/((97.759)+(9.471)));

}
tcb->m_ssThresh = (int) (78.635*(92.315)*(16.251));
tcb->m_cWnd = (int) (3.194-(30.53)-(9.23)-(82.593)-(tcb->m_cWnd));
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (80.773+(3.572)+(31.184)+(26.409)+(28.011));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (17.404*(3.601)*(97.491)*(18.105)*(segmentsAcked)*(tcb->m_ssThresh)*(7.183));
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
