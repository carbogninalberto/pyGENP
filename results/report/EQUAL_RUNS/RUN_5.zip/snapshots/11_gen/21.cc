int jYyWuygolLqfYIoY = (int) (23.243-(63.584)-(97.623)-(46.995)-(4.534)-(9.09)-(tcb->m_segmentSize)-(89.891));
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((48.956)+(0.1)+(0.1)+(43.764)+(16.733)+(0.1))/((0.1)+(0.1)+(0.1)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (37.186*(64.084)*(83.971)*(77.697)*(37.323)*(85.953));
	jYyWuygolLqfYIoY = (int) (59.928-(44.902)-(39.705)-(21.299));

}
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (35.356/0.1);

} else {
	tcb->m_segmentSize = (int) (61.438*(23.479)*(82.574)*(50.406)*(58.64)*(20.575)*(tcb->m_ssThresh)*(26.11)*(72.926));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (68.591+(33.415)+(segmentsAcked));

}
tcb->m_ssThresh = (int) (98.934*(6.341)*(76.915)*(93.173)*(9.034)*(93.042)*(28.25)*(70.527));
segmentsAcked = SlowStart (tcb, segmentsAcked);
int UbrXVGteeLeiDXrB = (int) (((35.194)+(0.1)+(0.1)+(0.1))/((16.41)));
if (UbrXVGteeLeiDXrB <= tcb->m_segmentSize) {
	UbrXVGteeLeiDXrB = (int) (16.184*(tcb->m_cWnd)*(74.088)*(15.585)*(14.969)*(51.017)*(77.158)*(94.75));

} else {
	UbrXVGteeLeiDXrB = (int) (31.128-(60.748)-(54.991)-(UbrXVGteeLeiDXrB)-(51.651)-(71.083)-(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);

}
jYyWuygolLqfYIoY = (int) (2.638-(61.924)-(14.156)-(39.897)-(88.661));
if (jYyWuygolLqfYIoY < UbrXVGteeLeiDXrB) {
	jYyWuygolLqfYIoY = (int) (21.543*(37.348)*(74.948)*(tcb->m_segmentSize));

} else {
	jYyWuygolLqfYIoY = (int) (41.893*(32.786)*(10.242)*(70.154));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
