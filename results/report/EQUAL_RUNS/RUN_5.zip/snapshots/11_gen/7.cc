segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (85.063+(-93.246)+(16.971)+(93.13)+(-66.242)+(-63.495));
