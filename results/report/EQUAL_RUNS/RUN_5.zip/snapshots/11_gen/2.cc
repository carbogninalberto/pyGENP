int ZnDXWjlcHsWUmTxh = (int) (-36.57+(-8.027)+(-83.638)+(-17.466)+(27.135)+(60.79)+(-12.907));
int AyRiwHPkighdOQIM = (int) (33.397*(-43.418)*(91.52)*(-37.094)*(-91.852)*(-18.879)*(6.698)*(-98.906));
int gioCJXpkkxuDWaCb = (int) ((57.774*(58.294)*(-9.289))/-80.754);
segmentsAcked = (int) (-62.484-(-65.15)-(-69.33)-(28.552)-(-5.447));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (94.109-(-11.493)-(15.163)-(-94.039)-(-15.207));
segmentsAcked = SlowStart (tcb, segmentsAcked);
