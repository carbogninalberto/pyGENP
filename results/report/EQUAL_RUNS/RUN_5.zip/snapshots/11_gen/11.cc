float KnrrvghokgAhuiVm = (float) 35.11;
float QKJGhvQdMEPFUXfK = (float) 74.564;
int AlSrAAeWwlxRqCkw = (int) 60.561;
