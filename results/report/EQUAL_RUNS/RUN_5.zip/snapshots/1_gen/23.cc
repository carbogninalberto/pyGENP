tcb->m_segmentSize = (int) (15.088+(21.699)+(tcb->m_segmentSize)+(53.644));
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (92.289*(41.568)*(62.408)*(13.511)*(18.312)*(60.709)*(segmentsAcked)*(89.537)*(35.028));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (8.127-(3.148));
	tcb->m_cWnd = (int) (2.522-(64.337)-(1.466)-(12.462)-(70.235));

}
tcb->m_cWnd = (int) ((((tcb->m_ssThresh*(17.388)*(tcb->m_cWnd)*(tcb->m_cWnd)*(71.624)*(tcb->m_ssThresh)))+((tcb->m_segmentSize*(19.623)*(76.688)))+((6.826+(19.322)+(83.834)+(56.364)+(10.229)+(68.928)+(94.607)))+(0.1)+(54.327)+(0.1)+(24.861))/((0.1)));
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (71.813*(tcb->m_segmentSize)*(92.396));
	tcb->m_cWnd = (int) (65.54-(65.746)-(66.649)-(56.183)-(54.756)-(tcb->m_ssThresh)-(28.044)-(93.855));
	tcb->m_ssThresh = (int) (segmentsAcked-(55.81)-(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (24.544/61.593);
	tcb->m_cWnd = (int) (12.667-(97.761)-(59.512)-(47.799)-(56.447)-(46.915));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(39.737)-(3.793)-(61.558)-(27.162)-(94.855)-(5.466)-(85.172)-(55.259));
float mkIpdsbVCdpxTcbt = (float) (9.758+(tcb->m_cWnd)+(tcb->m_cWnd)+(segmentsAcked)+(93.575));
segmentsAcked = (int) (tcb->m_ssThresh-(tcb->m_ssThresh)-(35.887)-(91.97)-(20.269)-(59.983));
if (tcb->m_segmentSize < segmentsAcked) {
	segmentsAcked = (int) ((((99.57+(92.763)+(15.686)+(53.984)+(17.231)))+(0.1)+(0.1)+((7.522*(45.828)*(27.749)*(69.051)*(74.875)*(mkIpdsbVCdpxTcbt)*(38.57)))+(5.263))/((44.314)+(94.478)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(17.617)*(84.423));

}
if (mkIpdsbVCdpxTcbt <= tcb->m_segmentSize) {
	segmentsAcked = (int) (mkIpdsbVCdpxTcbt-(tcb->m_ssThresh)-(47.64)-(51.426)-(80.628)-(38.0)-(40.268));
	segmentsAcked = (int) (10.765*(77.169)*(99.77)*(74.81)*(42.357)*(55.638)*(97.284));
	tcb->m_segmentSize = (int) (81.981-(50.393)-(60.365)-(46.632)-(5.926)-(28.656)-(26.618)-(57.408)-(45.766));

} else {
	segmentsAcked = (int) (34.857*(67.253)*(27.74));

}
