if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((93.088)+(43.599)+((tcb->m_ssThresh-(9.06)-(15.041)))+(0.1))/((25.974)));
	tcb->m_cWnd = (int) (68.067+(46.447)+(tcb->m_ssThresh)+(segmentsAcked)+(tcb->m_cWnd)+(89.35)+(58.432));

} else {
	tcb->m_segmentSize = (int) ((((57.793+(78.141)+(58.63)+(82.15)+(46.438)+(segmentsAcked)+(33.537)+(28.376)))+(33.692)+(0.1)+(61.62)+(53.098))/((0.1)+(0.1)));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (97.042+(2.103)+(47.106));

} else {
	tcb->m_segmentSize = (int) (57.499+(81.4)+(84.536)+(74.187)+(33.512)+(10.265)+(tcb->m_ssThresh)+(22.916)+(32.544));
	tcb->m_segmentSize = (int) (((0.1)+(55.603)+(75.328)+(0.1)+(88.759)+((27.669-(tcb->m_segmentSize)))+(13.183))/((0.1)));

}
tcb->m_cWnd = (int) ((((tcb->m_segmentSize+(78.445)+(29.251)+(49.905)+(67.282)+(78.526)))+(0.1)+(0.1)+(0.1)+(84.461)+(57.491)+(89.273)+(0.1))/((98.414)));
ReduceCwnd (tcb);
int sYgMDelIVtLJKQbp = (int) (85.318*(20.375)*(tcb->m_ssThresh)*(64.99)*(3.074)*(tcb->m_ssThresh)*(67.912)*(9.274)*(tcb->m_ssThresh));
sYgMDelIVtLJKQbp = (int) (37.832/0.1);
