float inBPIfGzVcVpTfzR = (float) (((0.1)+(86.189)+(7.084)+((18.827+(42.493)+(70.793)+(tcb->m_cWnd)+(29.163)+(38.462)+(75.623)+(76.762)))+(53.91)+(51.337))/((46.868)+(0.1)+(63.368)));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_ssThresh*(69.349)*(93.172)*(21.465)*(tcb->m_ssThresh)*(93.096)*(0.855));
inBPIfGzVcVpTfzR = (float) (77.066-(19.83)-(37.412)-(95.363)-(74.87)-(44.735));
