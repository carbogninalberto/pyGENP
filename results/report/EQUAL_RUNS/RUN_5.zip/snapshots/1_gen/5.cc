tcb->m_ssThresh = (int) (62.105-(75.115)-(93.707)-(64.386)-(tcb->m_ssThresh)-(15.574));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (35.901+(22.984)+(13.876)+(95.992)+(71.47)+(80.651)+(tcb->m_cWnd)+(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(94.963)+(segmentsAcked)+(26.525)+(77.777)+(84.953)+(61.358)+(tcb->m_cWnd));
	segmentsAcked = (int) (81.771+(33.722)+(97.657)+(75.995)+(17.676));

}
