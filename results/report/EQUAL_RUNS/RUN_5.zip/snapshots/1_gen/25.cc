TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (segmentsAcked-(81.662)-(56.753)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (81.275-(77.506)-(11.104)-(10.127)-(tcb->m_ssThresh)-(34.457)-(64.036)-(59.276));
	tcb->m_cWnd = (int) (tcb->m_cWnd*(75.898)*(58.538));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (54.847-(7.56)-(93.921)-(tcb->m_segmentSize)-(41.25)-(29.315));
	segmentsAcked = (int) (((0.1)+(0.1)+(51.211)+(0.1)+(0.1)+(0.1)+(55.402))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (99.594*(51.832)*(52.365)*(98.448)*(82.17)*(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (((0.1)+((94.469+(97.779)+(4.766)+(5.515)+(93.094)+(30.282)+(80.629)+(65.952)+(91.761)))+(0.1)+(0.1))/((0.1)+(48.726)+(0.1)+(0.1)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (4.583+(35.859));

} else {
	tcb->m_cWnd = (int) (92.44-(42.694)-(54.153)-(segmentsAcked)-(19.63)-(74.719));
	tcb->m_segmentSize = (int) (22.946*(49.185)*(55.097));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
