tcb->m_cWnd = (int) (31.389*(tcb->m_cWnd));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(37.029)*(33.662)*(90.916)*(45.513)*(50.369));

} else {
	tcb->m_segmentSize = (int) (18.576*(35.111)*(tcb->m_cWnd)*(tcb->m_segmentSize));

}
float xWCzJGKTDwJKOELC = (float) (32.717*(4.813));
int VxMPJKCmWNgwIoel = (int) (16.5-(48.983)-(65.501)-(6.46));
ReduceCwnd (tcb);
