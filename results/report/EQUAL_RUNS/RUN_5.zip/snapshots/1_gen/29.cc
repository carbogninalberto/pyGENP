if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(24.221)));
	segmentsAcked = (int) (65.577-(34.361)-(33.728)-(42.701)-(18.299)-(93.572)-(88.774)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (((0.1)+((80.764-(80.885)-(69.463)-(42.347)-(72.254)-(1.626)))+(38.525)+(96.001)+(98.037))/((8.026)+(0.1)));
	tcb->m_segmentSize = (int) (74.323+(57.016)+(52.05));

}
tcb->m_ssThresh = (int) (37.991-(tcb->m_cWnd));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (((0.1)+(0.1)+(62.76)+(96.075)+(26.844)+(0.1))/((36.129)));
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_segmentSize = (int) (53.466+(94.631)+(65.122)+(3.435)+(93.011)+(22.554)+(14.145)+(76.856)+(5.892));

} else {
	tcb->m_segmentSize = (int) ((((48.227-(92.896)-(63.485)-(tcb->m_segmentSize)))+(0.1)+(79.113)+((37.399*(segmentsAcked)*(91.866)*(18.317)))+(0.1)+(5.523)+(0.1))/((53.084)+(23.113)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (42.569+(tcb->m_segmentSize)+(28.778)+(tcb->m_ssThresh)+(92.729));
	segmentsAcked = (int) (51.142*(52.05));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (33.466-(33.459));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh < tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_segmentSize*(17.814)*(tcb->m_cWnd)*(19.908)*(80.636)*(segmentsAcked)*(64.65)*(26.613));

} else {
	segmentsAcked = (int) (95.445*(80.939));
	tcb->m_cWnd = (int) (62.881-(66.728)-(66.337)-(16.35)-(tcb->m_cWnd)-(45.215));

}
