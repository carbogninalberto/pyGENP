segmentsAcked = (int) (((0.1)+((65.802+(54.114)+(96.688)))+(0.1)+(0.1)+((30.421*(39.12)*(segmentsAcked)*(78.219)*(16.395)))+(37.755))/((0.1)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (64.106-(33.715)-(tcb->m_cWnd)-(92.798)-(90.089)-(segmentsAcked)-(13.433)-(87.577)-(31.065));
if (segmentsAcked < segmentsAcked) {
	segmentsAcked = (int) (71.119-(tcb->m_ssThresh)-(87.634)-(78.766)-(segmentsAcked));

} else {
	segmentsAcked = (int) (47.645-(tcb->m_cWnd)-(90.052)-(segmentsAcked)-(87.875)-(20.321)-(90.666)-(81.707)-(55.972));
	tcb->m_segmentSize = (int) (54.144+(36.995)+(35.981));
	tcb->m_ssThresh = (int) (81.422*(68.645)*(14.055)*(25.347)*(3.935)*(36.431));

}
