if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (12.071+(11.266)+(17.319)+(tcb->m_cWnd)+(22.312));
	tcb->m_segmentSize = (int) (0.1/73.005);
	tcb->m_segmentSize = (int) (81.056-(46.881)-(67.343)-(74.047)-(15.029)-(41.719)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(89.993));

} else {
	tcb->m_cWnd = (int) (47.739+(56.752)+(65.044)+(34.249)+(segmentsAcked)+(tcb->m_cWnd)+(34.42)+(95.47)+(tcb->m_cWnd));
	ReduceCwnd (tcb);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_segmentSize*(71.561)*(tcb->m_ssThresh)*(22.255)*(80.438));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(86.745)*(72.266)*(13.718)*(3.018)*(50.488)*(68.709)*(75.265)*(tcb->m_ssThresh));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (23.545*(10.982)*(91.951)*(81.321)*(tcb->m_cWnd)*(30.827)*(55.888));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (0.1/17.005);

}
segmentsAcked = (int) (41.714+(40.706)+(73.921)+(39.75)+(79.012)+(27.458)+(94.185)+(tcb->m_cWnd)+(80.977));
