if (tcb->m_ssThresh == segmentsAcked) {
	segmentsAcked = (int) (76.624-(31.003)-(segmentsAcked));
	segmentsAcked = (int) (4.141-(23.388));
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (37.461-(11.066)-(64.102));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((0.1)+(65.667)+((13.928-(99.067)-(69.114)))+(0.1)+(26.467))/((0.1)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (segmentsAcked > tcb->m_ssThresh) {
	segmentsAcked = (int) ((tcb->m_segmentSize*(66.759)*(71.589)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(69.201))/28.328);
	segmentsAcked = (int) (1.304-(70.983)-(tcb->m_cWnd)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (75.3-(34.671)-(6.165)-(90.091));
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
