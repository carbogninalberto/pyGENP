float rjativgHnGYUwGnC = (float) (-1.531+(10.555)+(-60.748)+(29.18)+(17.612)+(-9.868));
tcb->m_cWnd = (int) (-88.332+(68.927)+(16.283)+(-23.824)+(79.939)+(-68.619));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= rjativgHnGYUwGnC) {
	tcb->m_segmentSize = (int) ((((44.148+(70.932)+(59.019)+(79.72)+(56.582)+(37.166)))+((94.0*(82.667)*(60.252)*(85.158)*(91.953)*(13.406)*(32.416)*(segmentsAcked)*(38.325)))+(66.512)+(0.1)+(79.69)+(0.1))/((0.1)+(59.493)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (61.207-(84.895)-(48.874)-(90.005)-(73.171)-(96.889)-(98.552));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	rjativgHnGYUwGnC = (float) (67.784*(89.675)*(1.485));

}
if (tcb->m_segmentSize <= rjativgHnGYUwGnC) {
	tcb->m_segmentSize = (int) ((((44.148+(70.932)+(59.019)+(79.72)+(56.582)+(37.166)))+((94.0*(82.667)*(60.252)*(85.158)*(91.953)*(13.406)*(32.416)*(segmentsAcked)*(38.325)))+(66.512)+(0.1)+(79.69)+(0.1))/((0.1)+(59.493)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (61.207-(84.895)-(48.874)-(90.005)-(73.171)-(96.889)-(98.552));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	rjativgHnGYUwGnC = (float) (67.784*(89.675)*(1.485));

}
