int RAyUiYlqGldYxSBy = (int) (-25.173-(7.563)-(91.973)-(41.22)-(-90.405)-(-36.651)-(3.707)-(-68.175)-(76.428));
int xvrJHTTtZuoQVpbg = (int) (-33.592+(93.362));
tcb->m_cWnd = (int) (41.42+(87.271)+(82.866)+(-51.296)+(-14.237)+(43.606)+(-67.191));
tcb->m_cWnd = (int) (31.689+(57.638)+(15.032)+(90.889)+(90.896)+(21.272)+(-80.036));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
RAyUiYlqGldYxSBy = (int) (-57.487-(96.556)-(66.217)-(-99.683)-(-44.92)-(-74.53));
RAyUiYlqGldYxSBy = (int) (14.033-(32.654)-(-75.433)-(69.356)-(-20.437)-(91.82));
