float mkIpdsbVCdpxTcbt = (float) (21.501+(-60.832)+(-14.029)+(98.911)+(39.229));
if (mkIpdsbVCdpxTcbt != mkIpdsbVCdpxTcbt) {
	tcb->m_segmentSize = (int) (27.386*(tcb->m_cWnd)*(82.187));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (1.249+(80.818)+(74.368)+(74.213));

}
tcb->m_cWnd = (int) ((((tcb->m_ssThresh*(-60.636)*(74.719)*(18.577)*(-62.717)*(tcb->m_ssThresh)))+((tcb->m_segmentSize*(78.485)*(-85.926)))+((-0.576+(-21.9)+(59.038)+(65.079)+(50.993)+(85.203)+(82.454)))+(-64.444)+(-32.124)+(-4.421)+(97.915))/((-39.009)));
tcb->m_segmentSize = (int) (13.099-(81.851)-(-13.432)-(-70.606)-(-22.371)-(-18.81)-(-45.119)-(-59.064)-(-65.197));
segmentsAcked = (int) (-31.924-(8.166)-(53.574)-(27.934)-(68.113)-(1.43));
segmentsAcked = (int) (78.612-(-49.644)-(42.644)-(91.649)-(65.828)-(-90.29));
if (tcb->m_segmentSize < segmentsAcked) {
	segmentsAcked = (int) ((((99.57+(92.763)+(15.686)+(53.984)+(17.231)))+(0.1)+(0.1)+((7.522*(45.828)*(27.749)*(69.051)*(74.875)*(mkIpdsbVCdpxTcbt)*(38.57)))+(5.263))/((44.314)+(94.478)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(17.617)*(84.423));

}
if (tcb->m_segmentSize < segmentsAcked) {
	segmentsAcked = (int) ((((99.57+(92.763)+(15.686)+(53.984)+(17.231)))+(0.1)+(0.1)+((7.522*(45.828)*(27.749)*(69.051)*(74.875)*(mkIpdsbVCdpxTcbt)*(38.57)))+(5.263))/((44.314)+(94.478)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(17.617)*(84.423));

}
if (mkIpdsbVCdpxTcbt <= tcb->m_segmentSize) {
	segmentsAcked = (int) (mkIpdsbVCdpxTcbt-(24.147)-(47.64)-(51.426)-(80.628)-(38.0)-(40.268));
	segmentsAcked = (int) (10.765*(77.169)*(99.77)*(74.81)*(42.357)*(55.638)*(97.284));
	tcb->m_segmentSize = (int) (81.981-(50.393)-(60.365)-(46.632)-(5.926)-(28.656)-(26.618)-(57.408)-(45.766));

} else {
	segmentsAcked = (int) (34.857*(67.253)*(27.74));

}
if (mkIpdsbVCdpxTcbt <= tcb->m_segmentSize) {
	segmentsAcked = (int) (mkIpdsbVCdpxTcbt-(79.649)-(47.64)-(51.426)-(80.628)-(38.0)-(40.268));
	segmentsAcked = (int) (10.765*(77.169)*(99.77)*(74.81)*(42.357)*(55.638)*(97.284));
	tcb->m_segmentSize = (int) (81.981-(50.393)-(60.365)-(46.632)-(5.926)-(28.656)-(26.618)-(57.408)-(45.766));

} else {
	segmentsAcked = (int) (34.857*(67.253)*(27.74));

}
