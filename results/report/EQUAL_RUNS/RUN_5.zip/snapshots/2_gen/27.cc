int VxMPJKCmWNgwIoel = (int) (-50.557-(55.976)-(28.504)-(-90.418));
float xWCzJGKTDwJKOELC = (float) (-54.211*(84.623));
VxMPJKCmWNgwIoel = (int) (-61.301-(17.985)-(-23.856)-(-32.557)-(-26.437)-(41.239)-(-58.43)-(18.849)-(18.259));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (18.576*(35.111)*(tcb->m_cWnd)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(37.029)*(33.662)*(90.916)*(45.513)*(50.369));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(37.029)*(33.662)*(90.916)*(45.513)*(50.369));

} else {
	tcb->m_segmentSize = (int) (18.576*(35.111)*(tcb->m_cWnd)*(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
