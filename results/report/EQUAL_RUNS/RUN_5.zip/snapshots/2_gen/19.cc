float xWCzJGKTDwJKOELC = (float) (-76.239*(47.115));
int VxMPJKCmWNgwIoel = (int) (77.16-(96.014)-(18.46)-(-97.089));
tcb->m_cWnd = (int) (87.166*(-54.838));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (18.576*(35.111)*(tcb->m_cWnd)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(37.029)*(33.662)*(90.916)*(45.513)*(50.369));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(37.029)*(33.662)*(90.916)*(45.513)*(50.369));

} else {
	tcb->m_segmentSize = (int) (18.576*(35.111)*(tcb->m_cWnd)*(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
