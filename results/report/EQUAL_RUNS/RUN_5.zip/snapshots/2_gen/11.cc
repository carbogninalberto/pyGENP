int RAyUiYlqGldYxSBy = (int) (12.727-(4.815)-(26.083)-(-93.927)-(-85.846)-(-56.563)-(96.693)-(30.58)-(85.274));
int xvrJHTTtZuoQVpbg = (int) (-96.229+(26.864));
tcb->m_cWnd = (int) (79.92+(-59.818)+(-26.12)+(18.309)+(56.896)+(61.087)+(-29.302));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
RAyUiYlqGldYxSBy = (int) (75.894-(-58.016)-(-59.47)-(75.777)-(82.407)-(-83.667));
RAyUiYlqGldYxSBy = (int) (78.732-(-27.436)-(8.13)-(88.155)-(-58.224)-(-88.636));
