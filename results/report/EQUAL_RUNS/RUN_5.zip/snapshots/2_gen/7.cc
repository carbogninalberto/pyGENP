int VxMPJKCmWNgwIoel = (int) (17.22-(-5.985)-(66.745)-(73.634));
float xWCzJGKTDwJKOELC = (float) (-40.525*(-24.017));
VxMPJKCmWNgwIoel = (int) (-44.908*(17.557)*(-29.469)*(-18.304)*(29.841)*(-61.296)*(39.932));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (18.576*(35.111)*(tcb->m_cWnd)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(37.029)*(33.662)*(90.916)*(45.513)*(50.369));

}
ReduceCwnd (tcb);
