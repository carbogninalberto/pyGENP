int RAyUiYlqGldYxSBy = (int) (20.379-(63.008)-(98.38)-(-19.744)-(87.575)-(88.549)-(34.817)-(-45.913)-(-41.512));
int xvrJHTTtZuoQVpbg = (int) (32.85+(42.789));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (48.97+(12.208)+(-12.169)+(-26.695)+(-2.987)+(19.241)+(-34.668));
CongestionAvoidance (tcb, segmentsAcked);
