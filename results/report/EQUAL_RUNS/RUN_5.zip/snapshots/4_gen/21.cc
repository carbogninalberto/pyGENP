tcb->m_segmentSize = (int) (41.022-(-0.223)-(49.081));
int gCpJatAOUvoddapb = (int) (((-30.483)+((20.365-(-82.13)-(84.585)-(65.308)-(-55.44)-(-65.025)))+(-21.45)+((-8.958-(96.897)-(82.844)-(-69.706)-(-51.733)-(-24.449)-(73.851)-(73.843)))+(-47.514)+(76.323)+(-11.192))/((-40.324)+(75.426)));
tcb->m_cWnd = (int) (-76.062*(11.446)*(90.186)*(-83.077));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
