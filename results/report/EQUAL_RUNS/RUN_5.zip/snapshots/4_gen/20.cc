float mkIpdsbVCdpxTcbt = (float) 90.366;
tcb->m_cWnd = (int) (-54.833-(81.962)-(98.666)-(79.57));
if (mkIpdsbVCdpxTcbt != mkIpdsbVCdpxTcbt) {
	tcb->m_segmentSize = (int) (1.249+(80.818)+(74.368)+(74.213));

} else {
	tcb->m_segmentSize = (int) (27.386*(tcb->m_cWnd)*(82.187));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) ((((tcb->m_ssThresh*(-49.235)*(72.239)*(-58.464)*(8.743)*(tcb->m_ssThresh)))+((tcb->m_segmentSize*(-92.684)*(-97.989)))+((19.14+(6.613)+(-56.072)+(7.367)+(91.684)+(-75.483)+(74.33)))+(78.145)+(-87.034)+(-8.197)+(-32.226))/((60.498)));
if (mkIpdsbVCdpxTcbt != mkIpdsbVCdpxTcbt) {
	tcb->m_segmentSize = (int) (27.386*(tcb->m_cWnd)*(82.187));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (1.249+(80.818)+(74.368)+(74.213));

}
tcb->m_segmentSize = (int) (-32.461-(-47.573)-(-30.827)-(96.059)-(-39.146)-(-49.114)-(11.134)-(57.279)-(-44.857));
tcb->m_cWnd = (int) ((((tcb->m_ssThresh*(41.965)*(13.777)*(-5.434)*(-28.267)*(tcb->m_ssThresh)))+((tcb->m_segmentSize*(89.527)*(-3.084)))+((-3.148+(-8.958)+(94.298)+(-73.568)+(-86.605)+(-62.811)+(-98.149)))+(44.243)+(-31.004)+(2.115)+(95.14))/((-39.483)));
segmentsAcked = (int) (78.41-(-37.624)-(-35.744)-(6.784)-(74.126)-(62.254));
tcb->m_segmentSize = (int) (-84.701-(36.89)-(-50.52)-(-51.549)-(41.75)-(-95.962)-(48.38)-(32.413)-(7.113));
segmentsAcked = (int) (30.879-(40.523)-(57.117)-(-18.994)-(-98.245)-(72.154));
segmentsAcked = (int) (9.065-(27.722)-(-35.88)-(96.02)-(96.775)-(48.964));
if (tcb->m_segmentSize < segmentsAcked) {
	segmentsAcked = (int) ((((99.57+(92.763)+(15.686)+(53.984)+(17.231)))+(0.1)+(0.1)+((7.522*(45.828)*(27.749)*(69.051)*(74.875)*(mkIpdsbVCdpxTcbt)*(38.57)))+(5.263))/((44.314)+(94.478)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(17.617)*(84.423));

}
segmentsAcked = (int) (-26.54-(57.76)-(50.66)-(29.969)-(97.272)-(-1.903));
if (tcb->m_segmentSize < segmentsAcked) {
	segmentsAcked = (int) ((((99.57+(92.763)+(15.686)+(53.984)+(17.231)))+(0.1)+(0.1)+((7.522*(45.828)*(27.749)*(69.051)*(74.875)*(mkIpdsbVCdpxTcbt)*(38.57)))+(5.263))/((44.314)+(94.478)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(17.617)*(84.423));

}
if (tcb->m_segmentSize < segmentsAcked) {
	segmentsAcked = (int) ((((99.57+(92.763)+(15.686)+(53.984)+(17.231)))+(0.1)+(0.1)+((7.522*(45.828)*(27.749)*(69.051)*(74.875)*(mkIpdsbVCdpxTcbt)*(38.57)))+(5.263))/((44.314)+(94.478)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(17.617)*(84.423));

}
if (mkIpdsbVCdpxTcbt <= tcb->m_segmentSize) {
	segmentsAcked = (int) (mkIpdsbVCdpxTcbt-(24.147)-(47.64)-(51.426)-(80.628)-(38.0)-(40.268));
	segmentsAcked = (int) (10.765*(77.169)*(99.77)*(74.81)*(42.357)*(55.638)*(97.284));
	tcb->m_segmentSize = (int) (81.981-(50.393)-(60.365)-(46.632)-(5.926)-(28.656)-(26.618)-(57.408)-(45.766));

} else {
	segmentsAcked = (int) (34.857*(67.253)*(27.74));

}
if (tcb->m_segmentSize < segmentsAcked) {
	segmentsAcked = (int) ((((99.57+(92.763)+(15.686)+(53.984)+(17.231)))+(0.1)+(0.1)+((7.522*(45.828)*(27.749)*(69.051)*(74.875)*(mkIpdsbVCdpxTcbt)*(38.57)))+(5.263))/((44.314)+(94.478)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(17.617)*(84.423));

}
if (mkIpdsbVCdpxTcbt <= tcb->m_segmentSize) {
	segmentsAcked = (int) (mkIpdsbVCdpxTcbt-(79.649)-(47.64)-(51.426)-(80.628)-(38.0)-(40.268));
	segmentsAcked = (int) (10.765*(77.169)*(99.77)*(74.81)*(42.357)*(55.638)*(97.284));
	tcb->m_segmentSize = (int) (81.981-(50.393)-(60.365)-(46.632)-(5.926)-(28.656)-(26.618)-(57.408)-(45.766));

} else {
	segmentsAcked = (int) (34.857*(67.253)*(27.74));

}
if (mkIpdsbVCdpxTcbt <= tcb->m_segmentSize) {
	segmentsAcked = (int) (mkIpdsbVCdpxTcbt-(24.147)-(47.64)-(51.426)-(80.628)-(38.0)-(40.268));
	segmentsAcked = (int) (10.765*(77.169)*(99.77)*(74.81)*(42.357)*(55.638)*(97.284));
	tcb->m_segmentSize = (int) (81.981-(50.393)-(60.365)-(46.632)-(5.926)-(28.656)-(26.618)-(57.408)-(45.766));

} else {
	segmentsAcked = (int) (34.857*(67.253)*(27.74));

}
if (mkIpdsbVCdpxTcbt <= tcb->m_segmentSize) {
	segmentsAcked = (int) (mkIpdsbVCdpxTcbt-(79.649)-(47.64)-(51.426)-(80.628)-(38.0)-(40.268));
	segmentsAcked = (int) (10.765*(77.169)*(99.77)*(74.81)*(42.357)*(55.638)*(97.284));
	tcb->m_segmentSize = (int) (81.981-(50.393)-(60.365)-(46.632)-(5.926)-(28.656)-(26.618)-(57.408)-(45.766));

} else {
	segmentsAcked = (int) (34.857*(67.253)*(27.74));

}
