int VxMPJKCmWNgwIoel = (int) 54.047;
tcb->m_cWnd = (int) (-89.882+(-9.948)+(-59.335)+(-6.244));
VxMPJKCmWNgwIoel = (int) (77.725-(-72.188)-(15.891)-(-87.628)-(18.329)-(91.96)-(-22.367)-(69.835)-(-95.493));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (18.576*(35.111)*(tcb->m_cWnd)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(37.029)*(33.662)*(90.916)*(45.513)*(50.369));

}
ReduceCwnd (tcb);
