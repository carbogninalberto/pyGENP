float mkIpdsbVCdpxTcbt = (float) 90.366;
tcb->m_segmentSize = (int) (84.834+(-19.111)+(67.44)+(43.415)+(-79.162)+(33.535));
if (mkIpdsbVCdpxTcbt != mkIpdsbVCdpxTcbt) {
	tcb->m_segmentSize = (int) (1.249+(80.818)+(74.368)+(74.213));

} else {
	tcb->m_segmentSize = (int) (27.386*(tcb->m_cWnd)*(82.187));
	CongestionAvoidance (tcb, segmentsAcked);

}
