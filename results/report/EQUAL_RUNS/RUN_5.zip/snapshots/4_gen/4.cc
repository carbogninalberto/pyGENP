int ZnDXWjlcHsWUmTxh = (int) (-37.595+(82.642)+(-20.26)+(12.317)+(-59.133)+(-58.213)+(27.146));
int AyRiwHPkighdOQIM = (int) (0.013*(-48.616)*(-13.479)*(33.574)*(-95.045)*(-4.36)*(81.796)*(-59.064));
int gioCJXpkkxuDWaCb = (int) ((-90.374*(71.706)*(64.813))/74.374);
segmentsAcked = (int) (-42.834-(18.883)-(-88.277)-(-74.315)-(79.44));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
