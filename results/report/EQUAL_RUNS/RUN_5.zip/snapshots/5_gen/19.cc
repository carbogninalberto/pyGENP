int VxMPJKCmWNgwIoel = (int) 4.992;
tcb->m_cWnd = (int) (92.4+(-26.957)+(-74.798)+(-42.912));
VxMPJKCmWNgwIoel = (int) (-80.502-(76.743)-(-44.229)-(-96.826)-(-17.932)-(6.379)-(-40.645)-(99.565)-(-77.509));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (18.576*(35.111)*(tcb->m_cWnd)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(37.029)*(33.662)*(90.916)*(45.513)*(50.369));

}
ReduceCwnd (tcb);
