segmentsAcked = (int) (-35.87-(0.38)-(-51.634)-(26.164)-(80.027));
int gioCJXpkkxuDWaCb = (int) ((-75.389*(-83.208)*(-8.897))/4.51);
segmentsAcked = SlowStart (tcb, segmentsAcked);
int AyRiwHPkighdOQIM = (int) (-27.799*(57.011)*(-14.858)*(-46.077)*(39.774)*(-79.298)*(-84.599)*(-76.947));
segmentsAcked = SlowStart (tcb, segmentsAcked);
int ZnDXWjlcHsWUmTxh = (int) (10.688+(76.551)+(85.002)+(22.877)+(36.001)+(-83.72)+(-92.876));
