segmentsAcked = (int) (-42.861-(13.511)-(-44.083)-(-44.067)-(21.722));
int gioCJXpkkxuDWaCb = (int) ((66.896*(-42.791)*(31.976))/-18.15);
segmentsAcked = SlowStart (tcb, segmentsAcked);
int AyRiwHPkighdOQIM = (int) (35.673*(-10.769)*(-63.306)*(-45.282)*(-82.302)*(-91.069)*(26.143)*(-42.367));
segmentsAcked = SlowStart (tcb, segmentsAcked);
int ZnDXWjlcHsWUmTxh = (int) (55.711+(-22.062)+(39.152)+(-69.811)+(-61.96)+(25.001)+(-58.338));
segmentsAcked = SlowStart (tcb, segmentsAcked);
