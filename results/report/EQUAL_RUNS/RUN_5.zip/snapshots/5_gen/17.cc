float mkIpdsbVCdpxTcbt = (float) 24.89;
