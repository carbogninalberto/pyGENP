segmentsAcked = SlowStart (tcb, segmentsAcked);
float oWemeUMapIxPaAkG = (float) (85.843+(-69.33)+(-75.292)+(39.894)+(-88.624)+(50.673)+(53.109)+(-21.056));
segmentsAcked = (int) (-88.935+(-95.468)+(58.044)+(-91.132)+(35.873));
oWemeUMapIxPaAkG = (float) (14.179-(-35.093)-(-97.488)-(94.838)-(-38.622)-(-28.867));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
