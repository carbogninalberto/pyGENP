CongestionAvoidance (tcb, segmentsAcked);
int MjtGhDTpBeFsbSME = (int) (12.674*(-94.747)*(49.971)*(-35.686));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (86.124/49.871);
