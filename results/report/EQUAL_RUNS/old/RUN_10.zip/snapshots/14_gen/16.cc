if (segmentsAcked != segmentsAcked) {
	segmentsAcked = (int) (37.695*(tcb->m_cWnd)*(tcb->m_cWnd)*(56.254));
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (63.657*(11.287)*(23.175)*(15.836)*(tcb->m_segmentSize)*(27.233)*(74.602));

}
