ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (25.387+(segmentsAcked)+(2.4)+(33.306)+(34.596)+(7.168)+(36.655)+(71.376)+(69.275));
	tcb->m_cWnd = (int) (89.664*(1.913)*(3.643)*(93.072));

} else {
	segmentsAcked = (int) (81.44+(87.316));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (75.549*(42.161)*(59.827)*(82.459)*(tcb->m_ssThresh)*(12.45)*(94.717)*(31.108));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh == segmentsAcked) {
	segmentsAcked = (int) (96.881/73.333);
	tcb->m_cWnd = (int) (0.1/84.753);

} else {
	segmentsAcked = (int) (((88.483)+((15.992-(1.111)-(88.466)-(tcb->m_cWnd)-(39.718)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(46.044)))+(0.1)+(8.655)+(0.1))/((0.1)+(0.1)+(85.25)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

}
