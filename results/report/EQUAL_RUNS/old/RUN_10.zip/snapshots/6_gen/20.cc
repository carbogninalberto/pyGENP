int HSEWdGJkahchKyig = (int) (-51.752*(-79.599)*(43.504)*(93.326)*(-51.024)*(77.194)*(-80.135)*(46.485));
CongestionAvoidance (tcb, segmentsAcked);
HSEWdGJkahchKyig = (int) (6.348*(-50.089)*(39.546));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
HSEWdGJkahchKyig = (int) (-91.738*(-51.131)*(80.461));
segmentsAcked = SlowStart (tcb, segmentsAcked);
