float pIcWSquLVqVEmUQX = (float) 37.849;
int ARzQrNDTBjTcGGMc = (int) (-4.167/39.695);
