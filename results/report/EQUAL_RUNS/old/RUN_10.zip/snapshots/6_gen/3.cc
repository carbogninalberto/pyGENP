int HSEWdGJkahchKyig = (int) (-37.231*(-57.269)*(41.577)*(-55.954)*(-26.979)*(53.07)*(-80.047)*(-92.21));
CongestionAvoidance (tcb, segmentsAcked);
HSEWdGJkahchKyig = (int) (19.473*(-11.044)*(36.723));
segmentsAcked = SlowStart (tcb, segmentsAcked);
