segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (-18.252*(98.125)*(-93.829)*(99.367)*(-35.834));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (71.115*(-57.215)*(82.257)*(-8.026)*(-70.251)*(50.202)*(-40.511)*(-22.869)*(-45.951));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
