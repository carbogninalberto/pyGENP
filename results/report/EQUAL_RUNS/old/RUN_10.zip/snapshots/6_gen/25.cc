segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
int HSEWdGJkahchKyig = (int) (-18.753*(-18.262)*(41.801)*(-69.297)*(-16.125)*(24.75)*(-57.831)*(-88.155));
HSEWdGJkahchKyig = (int) (-57.452*(-6.704)*(82.324));
segmentsAcked = SlowStart (tcb, segmentsAcked);
