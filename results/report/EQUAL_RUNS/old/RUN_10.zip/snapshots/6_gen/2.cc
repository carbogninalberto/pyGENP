int HSEWdGJkahchKyig = (int) (40.764*(-40.058)*(-81.308)*(-31.013)*(-45.474)*(21.344)*(-29.429)*(2.812));
CongestionAvoidance (tcb, segmentsAcked);
HSEWdGJkahchKyig = (int) (57.409*(42.671)*(-43.697));
segmentsAcked = SlowStart (tcb, segmentsAcked);
