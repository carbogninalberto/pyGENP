int iIUmbRTnIvlcGoul = (int) 66.239;
segmentsAcked = SlowStart (tcb, segmentsAcked);
int HSEWdGJkahchKyig = (int) 1.698;
