if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/23.797);
	segmentsAcked = (int) (segmentsAcked+(-65.203));

} else {
	tcb->m_segmentSize = (int) (49.302/0.1);
	segmentsAcked = (int) (7.755-(94.013)-(77.716)-(11.715)-(34.54));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (60.688/21.723);
segmentsAcked = (int) (-67.082-(32.165));
