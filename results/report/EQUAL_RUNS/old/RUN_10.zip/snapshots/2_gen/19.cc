tcb->m_segmentSize = (int) (50.337+(-94.246)+(-92.177)+(2.768));
tcb->m_cWnd = (int) (33.783*(-34.642));
tcb->m_segmentSize = (int) (59.727-(67.112)-(-85.323)-(-36.416)-(-77.874)-(-43.243));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (20.813-(-7.036)-(-42.982)-(-56.08)-(44.279)-(-89.535));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
