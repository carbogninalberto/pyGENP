ReduceCwnd (tcb);
float ZlJhBiSaetadrrxe = (float) 85.478;
segmentsAcked = (int) (92.455*(-43.246)*(81.209)*(-80.828)*(58.962));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (22.324*(17.477)*(1.19)*(12.999)*(42.139)*(-93.772)*(-76.054)*(-56.535)*(70.821));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
