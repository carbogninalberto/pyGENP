ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-69.462*(-59.52)*(4.265)*(-1.411)*(-62.424)*(-56.071)*(61.096)*(-42.27)*(-88.926));
CongestionAvoidance (tcb, segmentsAcked);
