segmentsAcked = (int) (-80.607*(65.193)*(7.988)*(19.485)*(38.511));
float ZlJhBiSaetadrrxe = (float) (-86.522+(17.627)+(4.779)+(-63.965)+(-81.268)+(77.592)+(-14.547)+(97.555)+(-57.557));
segmentsAcked = (int) (0.896*(-6.861)*(-80.424)*(-55.873)*(-6.245)*(67.67)*(-81.624)*(-81.509)*(23.397));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
