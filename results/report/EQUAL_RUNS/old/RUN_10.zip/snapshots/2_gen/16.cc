int bGzbPKmjThOICgUF = (int) (29.454+(28.972)+(-65.142)+(42.0)+(98.007));
segmentsAcked = SlowStart (tcb, segmentsAcked);
bGzbPKmjThOICgUF = (int) (49.219+(71.21)+(-48.562)+(87.119)+(97.302)+(-25.44)+(-14.207));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (bGzbPKmjThOICgUF != bGzbPKmjThOICgUF) {
	bGzbPKmjThOICgUF = (int) (segmentsAcked*(bGzbPKmjThOICgUF)*(72.625)*(69.368)*(75.588)*(29.847));
	ReduceCwnd (tcb);

} else {
	bGzbPKmjThOICgUF = (int) (bGzbPKmjThOICgUF-(30.707)-(1.281));
	tcb->m_cWnd = (int) (79.43*(10.388)*(56.698)*(segmentsAcked)*(70.673));
	segmentsAcked = (int) (94.267-(71.502));

}
bGzbPKmjThOICgUF = (int) (-70.13+(-43.061)+(21.068)+(21.821)+(-5.14)+(-11.613)+(66.869));
ReduceCwnd (tcb);
if (bGzbPKmjThOICgUF != bGzbPKmjThOICgUF) {
	bGzbPKmjThOICgUF = (int) (segmentsAcked*(bGzbPKmjThOICgUF)*(17.919)*(69.368)*(75.588)*(29.847));
	ReduceCwnd (tcb);

} else {
	bGzbPKmjThOICgUF = (int) (bGzbPKmjThOICgUF-(30.707)-(1.281));
	tcb->m_cWnd = (int) (79.43*(10.388)*(56.698)*(segmentsAcked)*(70.673));
	segmentsAcked = (int) (94.267-(71.502));

}
