ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (2.673*(-10.61)*(-37.288)*(-74.607)*(-56.23)*(55.964)*(-32.757)*(47.417)*(78.418));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
