int bGzbPKmjThOICgUF = (int) (69.882+(20.62)+(16.269)+(2.726)+(94.292));
if (bGzbPKmjThOICgUF > bGzbPKmjThOICgUF) {
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (((37.726)+(31.273)+(94.567)+(0.1)+(0.1))/((10.055)+(0.1)));
	tcb->m_cWnd = (int) (41.597+(77.175)+(92.678)+(58.833)+(89.156));
	tcb->m_segmentSize = (int) (0.1/0.1);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
