float ZoAzHyrTamqfnCGg = (float) (-20.568*(30.913)*(-95.48)*(-35.17));
tcb->m_segmentSize = (int) (((89.115)+(4.621)+(1.311)+((tcb->m_ssThresh-(21.921)-(tcb->m_cWnd)))+(-47.485)+(-55.847))/((-47.713)+(-84.446)+(-29.598)));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	segmentsAcked = (int) (42.165+(26.845)+(78.466)+(-39.556)+(16.905)+(99.173)+(95.686)+(48.278)+(39.973));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (ZoAzHyrTamqfnCGg+(tcb->m_segmentSize)+(21.766)+(77.422)+(29.474)+(15.042)+(39.291));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (91.557-(50.081)-(25.592)-(48.405));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	segmentsAcked = (int) (42.165+(26.845)+(78.466)+(-91.607)+(16.905)+(99.173)+(43.429)+(48.278)+(39.973));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (ZoAzHyrTamqfnCGg+(tcb->m_segmentSize)+(21.766)+(77.422)+(29.474)+(15.042)+(39.291));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (91.557-(50.081)-(25.592)-(48.405));

}
if (tcb->m_cWnd < ZoAzHyrTamqfnCGg) {
	ZoAzHyrTamqfnCGg = (float) (0.1/0.1);

} else {
	ZoAzHyrTamqfnCGg = (float) ((tcb->m_segmentSize-(51.825)-(tcb->m_ssThresh)-(70.383))/0.1);

}
if (tcb->m_cWnd < ZoAzHyrTamqfnCGg) {
	ZoAzHyrTamqfnCGg = (float) (0.1/0.1);

} else {
	ZoAzHyrTamqfnCGg = (float) ((tcb->m_segmentSize-(51.825)-(tcb->m_ssThresh)-(70.383))/0.1);

}
if (ZoAzHyrTamqfnCGg != tcb->m_cWnd) {
	ZoAzHyrTamqfnCGg = (float) (-49.679*(tcb->m_segmentSize)*(82.65)*(tcb->m_segmentSize)*(59.504)*(78.518)*(10.05)*(44.839)*(15.591));

} else {
	ZoAzHyrTamqfnCGg = (float) (((34.983)+(7.823)+(0.1)+(68.903)+(41.828))/((69.984)+(0.1)));
	tcb->m_segmentSize = (int) (60.472-(9.163)-(95.946)-(96.711)-(99.617)-(13.851));

}
if (ZoAzHyrTamqfnCGg != tcb->m_cWnd) {
	ZoAzHyrTamqfnCGg = (float) (-67.973*(tcb->m_segmentSize)*(82.65)*(tcb->m_segmentSize)*(59.504)*(78.518)*(10.05)*(44.839)*(15.591));

} else {
	ZoAzHyrTamqfnCGg = (float) (((34.983)+(7.823)+(0.1)+(68.903)+(41.828))/((69.984)+(0.1)));
	tcb->m_segmentSize = (int) (60.472-(9.163)-(95.946)-(96.711)-(99.617)-(13.851));

}
segmentsAcked = (int) (31.524*(43.646)*(27.705)*(-48.28)*(44.881)*(-13.288)*(-44.623));
segmentsAcked = (int) (73.37*(-8.58)*(-95.892)*(-27.52)*(13.351)*(-75.247)*(16.944));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (91.758*(53.657));
tcb->m_segmentSize = (int) (-39.208*(-47.783));
ReduceCwnd (tcb);
