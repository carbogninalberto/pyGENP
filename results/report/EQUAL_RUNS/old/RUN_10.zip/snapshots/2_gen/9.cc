ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (16.364*(-49.14)*(-52.612)*(-47.047)*(-87.579)*(73.156)*(-94.94)*(-40.344)*(94.292));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
