float xxfSvdIqIXvCCIJr = (float) (51.314-(-86.719)-(-7.726)-(-93.542)-(-76.882));
xxfSvdIqIXvCCIJr = (float) (-88.347/-58.253);
tcb->m_cWnd = (int) (78.826-(-45.388)-(82.223)-(50.325)-(16.817)-(42.277)-(63.077));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (75.989+(47.31)+(96.139)+(-42.187)+(21.09)+(25.65)+(74.904));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (30.152-(tcb->m_segmentSize)-(xxfSvdIqIXvCCIJr)-(24.404));
	tcb->m_cWnd = (int) (41.359+(xxfSvdIqIXvCCIJr)+(segmentsAcked)+(36.191)+(53.763));

}
