int bGzbPKmjThOICgUF = (int) (71.626+(60.76)+(-91.31)+(98.738)+(41.001));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (bGzbPKmjThOICgUF-(22.294)-(segmentsAcked)-(53.476)-(90.396)-(19.535)-(17.897)-(39.84)-(28.933));
	bGzbPKmjThOICgUF = (int) (94.957/1.847);

} else {
	tcb->m_cWnd = (int) (10.934+(16.287)+(tcb->m_segmentSize)+(15.065)+(77.341)+(47.068)+(44.549)+(bGzbPKmjThOICgUF)+(62.922));

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (bGzbPKmjThOICgUF != bGzbPKmjThOICgUF) {
	bGzbPKmjThOICgUF = (int) (segmentsAcked*(bGzbPKmjThOICgUF)*(40.513)*(69.368)*(75.588)*(29.847));
	ReduceCwnd (tcb);

} else {
	bGzbPKmjThOICgUF = (int) (bGzbPKmjThOICgUF-(30.707)-(1.281));
	tcb->m_cWnd = (int) (79.43*(10.388)*(56.698)*(segmentsAcked)*(70.673));
	segmentsAcked = (int) (94.267-(71.502));

}
bGzbPKmjThOICgUF = (int) (-2.106+(3.918)+(-74.571)+(9.75)+(-43.004)+(-74.806)+(-20.709));
ReduceCwnd (tcb);
if (bGzbPKmjThOICgUF != bGzbPKmjThOICgUF) {
	bGzbPKmjThOICgUF = (int) (segmentsAcked*(bGzbPKmjThOICgUF)*(8.241)*(69.368)*(75.588)*(29.847));
	ReduceCwnd (tcb);

} else {
	bGzbPKmjThOICgUF = (int) (bGzbPKmjThOICgUF-(30.707)-(1.281));
	tcb->m_cWnd = (int) (79.43*(10.388)*(56.698)*(segmentsAcked)*(70.673));
	segmentsAcked = (int) (94.267-(71.502));

}
