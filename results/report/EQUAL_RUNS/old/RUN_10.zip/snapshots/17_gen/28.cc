ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (81.44+(87.316));

} else {
	segmentsAcked = (int) (25.387+(segmentsAcked)+(2.4)+(33.306)+(34.596)+(7.168)+(36.655)+(71.376)+(69.275));
	tcb->m_cWnd = (int) (89.664*(1.913)*(3.643)*(93.072));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (12.443*(32.365)*(50.151)*(-59.563)*(98.603)*(-71.138)*(-19.355)*(-56.082));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (7.196*(3.08)*(-79.645)*(99.338)*(-24.171)*(84.422)*(-57.812)*(84.228));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
