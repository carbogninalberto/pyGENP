ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (25.387+(segmentsAcked)+(2.4)+(33.306)+(34.596)+(7.168)+(36.655)+(71.376)+(69.275));
	tcb->m_cWnd = (int) (89.664*(1.913)*(3.643)*(93.072));

} else {
	segmentsAcked = (int) (81.44+(87.316));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-83.658*(-99.247)*(3.625)*(-93.82)*(98.119)*(71.487)*(34.786)*(-95.542));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (25.387+(segmentsAcked)+(2.4)+(33.306)+(34.596)+(7.168)+(36.655)+(71.376)+(69.275));
	tcb->m_cWnd = (int) (89.664*(1.913)*(3.643)*(93.072));

} else {
	segmentsAcked = (int) (81.44+(87.316));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-66.238*(-99.892)*(8.055)*(-65.775)*(9.495)*(-57.101)*(-74.118)*(66.403));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
