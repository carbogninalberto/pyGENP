int HSEWdGJkahchKyig = (int) (3.73*(-64.768)*(25.761)*(-35.229)*(63.128)*(-3.513)*(80.182)*(-53.749));
CongestionAvoidance (tcb, segmentsAcked);
HSEWdGJkahchKyig = (int) (70.934*(55.474)*(-85.163));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
HSEWdGJkahchKyig = (int) (22.81*(-19.671)*(41.323));
segmentsAcked = SlowStart (tcb, segmentsAcked);
