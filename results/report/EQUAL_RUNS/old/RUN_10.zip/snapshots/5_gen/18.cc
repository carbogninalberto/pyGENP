ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (77.815*(46.404)*(-88.964)*(-55.819)*(-96.489)*(96.932)*(37.467)*(3.781)*(32.739));
CongestionAvoidance (tcb, segmentsAcked);
