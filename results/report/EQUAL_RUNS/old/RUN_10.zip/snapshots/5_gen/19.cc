ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-13.282*(49.076)*(22.511)*(96.149)*(38.161)*(-80.23)*(79.435)*(-92.311)*(12.396));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
