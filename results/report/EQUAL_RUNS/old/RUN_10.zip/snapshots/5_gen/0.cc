int HSEWdGJkahchKyig = (int) (32.03*(30.961)*(-51.508)*(50.778)*(16.559)*(58.024)*(10.879)*(-17.456));
CongestionAvoidance (tcb, segmentsAcked);
HSEWdGJkahchKyig = (int) (-23.954*(-29.668)*(-30.09));
segmentsAcked = SlowStart (tcb, segmentsAcked);
