CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (55.088*(55.327)*(-78.283)*(77.411)*(-9.464));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (64.536*(60.844)*(43.29)*(34.687)*(-30.283)*(-64.656)*(-59.49)*(-43.195)*(95.286));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (85.11*(-18.539)*(-69.253)*(-88.156)*(39.59)*(17.902)*(-30.426)*(21.697)*(18.904));
segmentsAcked = (int) (-56.852*(23.05)*(99.734)*(3.581)*(-76.279)*(-95.838)*(-80.939)*(-71.986)*(55.61));
