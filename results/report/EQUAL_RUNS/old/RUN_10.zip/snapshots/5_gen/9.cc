ReduceCwnd (tcb);
segmentsAcked = (int) (-44.887*(48.203)*(56.933)*(-46.369)*(77.341));
segmentsAcked = (int) (-8.841*(79.555)*(-96.891)*(46.14)*(-40.561));
segmentsAcked = (int) (-49.942*(-8.234)*(-87.788)*(57.735)*(-44.558)*(-97.069)*(55.987)*(10.868)*(-51.753));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-97.187*(84.144)*(86.844)*(12.171)*(58.85)*(97.752)*(13.569)*(20.783)*(-41.549));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
