int HnEQSMYKvVPqDZRc = (int) (-97.394+(-75.022)+(-59.814)+(51.875));
float pIcWSquLVqVEmUQX = (float) 69.693;
