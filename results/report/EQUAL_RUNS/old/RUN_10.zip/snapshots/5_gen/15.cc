int ykApSQGaWWvezkSo = (int) (-78.8/(-52.67+(-57.259)+(-33.5)+(-79.01)+(12.66)));
float vWdNGEvsZkCDuFwV = (float) (-63.366+(-89.776)+(-54.394));
