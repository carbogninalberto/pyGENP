ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-45.257*(-71.357)*(-57.409)*(-69.469)*(22.684)*(78.757)*(87.881)*(-0.095)*(81.777));
CongestionAvoidance (tcb, segmentsAcked);
