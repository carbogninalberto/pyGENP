int bGzbPKmjThOICgUF = (int) 68.407;
