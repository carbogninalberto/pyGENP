float pIcWSquLVqVEmUQX = (float) 12.792;
CongestionAvoidance (tcb, segmentsAcked);
float ZCCsBQBjLsoAJNBl = (float) (50.547+(23.289)+(88.21)+(-88.417)+(-24.346)+(-1.148));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
int HnEQSMYKvVPqDZRc = (int) 2.869;
if (segmentsAcked > pIcWSquLVqVEmUQX) {
	segmentsAcked = (int) (77.745-(80.381)-(75.473)-(48.294)-(segmentsAcked)-(73.117)-(18.32)-(64.987)-(61.384));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (tcb->m_cWnd*(63.489)*(15.471)*(77.739)*(15.135)*(HnEQSMYKvVPqDZRc)*(11.04)*(81.825)*(74.401));
	HnEQSMYKvVPqDZRc = (int) (20.406*(93.22)*(94.424));
	segmentsAcked = (int) (((0.1)+(33.106)+(0.1)+(0.1)+((tcb->m_segmentSize*(70.919)*(pIcWSquLVqVEmUQX)))+(0.1))/((0.1)+(0.1)+(0.1)));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked > pIcWSquLVqVEmUQX) {
	segmentsAcked = (int) (77.745-(80.381)-(75.473)-(48.294)-(segmentsAcked)-(73.117)-(18.32)-(64.987)-(61.384));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (tcb->m_cWnd*(63.489)*(15.471)*(77.739)*(15.135)*(HnEQSMYKvVPqDZRc)*(11.04)*(81.825)*(74.401));
	HnEQSMYKvVPqDZRc = (int) (20.406*(93.22)*(94.424));
	segmentsAcked = (int) (((0.1)+(33.106)+(0.1)+(0.1)+((tcb->m_segmentSize*(70.919)*(pIcWSquLVqVEmUQX)))+(0.1))/((0.1)+(0.1)+(0.1)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
