ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (55.853*(38.427)*(45.235)*(-98.231)*(-72.913)*(52.875)*(59.744)*(35.451)*(16.464));
CongestionAvoidance (tcb, segmentsAcked);
