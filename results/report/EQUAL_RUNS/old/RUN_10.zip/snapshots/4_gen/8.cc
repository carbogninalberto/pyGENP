int bGzbPKmjThOICgUF = (int) 68.407;
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (44.736-(bGzbPKmjThOICgUF)-(39.846)-(91.219));
	segmentsAcked = (int) (segmentsAcked*(23.81)*(43.91));

} else {
	tcb->m_cWnd = (int) (((0.1)+((37.897*(40.515)*(39.971)*(21.796)*(53.688)*(61.107)*(38.509)))+(0.1)+(41.487))/((0.1)));
	bGzbPKmjThOICgUF = (int) (((0.1)+((tcb->m_ssThresh+(66.735)+(59.894)+(85.821)+(70.37)+(14.139)))+((bGzbPKmjThOICgUF*(tcb->m_segmentSize)*(87.687)))+(35.529)+(0.1))/((48.848)+(0.1)+(41.202)+(16.649)));
	tcb->m_cWnd = (int) (18.727+(-65.365)+(23.111)+(22.649)+(45.982)+(30.392));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
bGzbPKmjThOICgUF = (int) (-75.237+(-65.83)+(38.001)+(-6.348)+(90.378)+(-67.28)+(-43.474));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (bGzbPKmjThOICgUF != bGzbPKmjThOICgUF) {
	bGzbPKmjThOICgUF = (int) (segmentsAcked*(bGzbPKmjThOICgUF)*(72.625)*(69.368)*(75.588)*(29.847));
	ReduceCwnd (tcb);

} else {
	bGzbPKmjThOICgUF = (int) (bGzbPKmjThOICgUF-(30.707)-(1.281));
	tcb->m_cWnd = (int) (79.43*(10.388)*(56.698)*(segmentsAcked)*(70.673));
	segmentsAcked = (int) (94.267-(71.502));

}
bGzbPKmjThOICgUF = (int) (13.35+(-82.173)+(55.368)+(1.063)+(-87.177)+(55.013)+(41.475));
