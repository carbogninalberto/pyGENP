ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (74.885*(-97.933)*(-26.753)*(65.642)*(77.473)*(-63.101)*(-1.895)*(-90.509)*(-12.883));
segmentsAcked = (int) (24.406*(45.638)*(-77.403)*(-21.919)*(-29.887)*(13.943)*(-76.578)*(-7.833)*(-2.13));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
