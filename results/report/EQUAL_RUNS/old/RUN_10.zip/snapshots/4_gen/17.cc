ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-39.525*(-46.59)*(59.184)*(-26.977)*(93.531)*(-69.885)*(-73.738)*(57.952)*(-79.975));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
