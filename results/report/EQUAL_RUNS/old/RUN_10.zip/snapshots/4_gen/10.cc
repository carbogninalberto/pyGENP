float ZoAzHyrTamqfnCGg = (float) 56.64;
int ykApSQGaWWvezkSo = (int) (37.788/(-76.773+(-44.583)+(34.725)+(97.194)+(-56.37)));
tcb->m_segmentSize = (int) (((-29.805)+(-63.582)+(53.929)+((tcb->m_ssThresh-(42.789)-(tcb->m_cWnd)))+(21.969)+(72.122))/((50.286)+(79.246)+(-73.66)));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	segmentsAcked = (int) (-64.654+(tcb->m_segmentSize)+(21.766)+(77.422)+(29.474)+(15.042)+(39.291));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (91.557-(50.081)-(25.592)-(48.405));

} else {
	segmentsAcked = (int) (42.165+(26.845)+(78.466)+(-39.556)+(16.905)+(99.173)+(95.686)+(48.278)+(39.973));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	segmentsAcked = (int) (42.165+(26.845)+(78.466)+(-91.607)+(16.905)+(99.173)+(43.429)+(48.278)+(39.973));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (ZoAzHyrTamqfnCGg+(tcb->m_segmentSize)+(21.766)+(77.422)+(29.474)+(15.042)+(39.291));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (91.557-(50.081)-(25.592)-(48.405));

}
if (tcb->m_cWnd < ZoAzHyrTamqfnCGg) {
	ZoAzHyrTamqfnCGg = (float) (0.1/0.1);

} else {
	ZoAzHyrTamqfnCGg = (float) ((tcb->m_segmentSize-(51.825)-(tcb->m_ssThresh)-(70.383))/0.1);

}
if (tcb->m_cWnd < ZoAzHyrTamqfnCGg) {
	ZoAzHyrTamqfnCGg = (float) (0.1/0.1);

} else {
	ZoAzHyrTamqfnCGg = (float) ((tcb->m_segmentSize-(51.825)-(tcb->m_ssThresh)-(70.383))/0.1);

}
if (ZoAzHyrTamqfnCGg != tcb->m_cWnd) {
	ZoAzHyrTamqfnCGg = (float) (-49.679*(tcb->m_segmentSize)*(82.65)*(tcb->m_segmentSize)*(59.504)*(78.518)*(10.05)*(44.839)*(15.591));

} else {
	ZoAzHyrTamqfnCGg = (float) (((34.983)+(7.823)+(0.1)+(68.903)+(41.828))/((69.984)+(0.1)));
	tcb->m_segmentSize = (int) (60.472-(9.163)-(95.946)-(96.711)-(99.617)-(13.851));

}
if (ZoAzHyrTamqfnCGg != tcb->m_cWnd) {
	ZoAzHyrTamqfnCGg = (float) (-67.973*(tcb->m_segmentSize)*(82.65)*(tcb->m_segmentSize)*(59.504)*(78.518)*(10.05)*(44.839)*(15.591));

} else {
	ZoAzHyrTamqfnCGg = (float) (((34.983)+(7.823)+(0.1)+(68.903)+(41.828))/((69.984)+(0.1)));
	tcb->m_segmentSize = (int) (60.472-(9.163)-(95.946)-(96.711)-(99.617)-(13.851));

}
