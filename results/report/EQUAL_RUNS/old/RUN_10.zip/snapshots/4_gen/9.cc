ReduceCwnd (tcb);
float ZlJhBiSaetadrrxe = (float) 23.875;
ZlJhBiSaetadrrxe = (float) (2.862+(56.294)+(-79.812)+(30.132));
segmentsAcked = (int) (-12.508*(48.216)*(55.52)*(-94.363)*(-54.411));
