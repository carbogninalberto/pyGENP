ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-88.513*(-33.344)*(13.464)*(12.826)*(78.622)*(-59.215)*(86.69)*(-54.517)*(-59.965));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (99.198*(63.208)*(26.605)*(76.976)*(-56.796)*(10.258)*(63.377)*(-67.632)*(16.497));
CongestionAvoidance (tcb, segmentsAcked);
