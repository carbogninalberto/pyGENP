ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (13.464*(68.141)*(11.46)*(38.623)*(-18.289)*(-40.674)*(71.225)*(-4.777)*(34.232));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
