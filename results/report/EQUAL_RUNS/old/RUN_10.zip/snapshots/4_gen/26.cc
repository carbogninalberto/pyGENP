float pIcWSquLVqVEmUQX = (float) 69.693;
if (pIcWSquLVqVEmUQX == tcb->m_segmentSize) {
	pIcWSquLVqVEmUQX = (float) (52.482+(58.287)+(83.824)+(tcb->m_cWnd)+(40.549)+(54.061));
	ReduceCwnd (tcb);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	pIcWSquLVqVEmUQX = (float) (tcb->m_cWnd*(53.271)*(8.088));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
