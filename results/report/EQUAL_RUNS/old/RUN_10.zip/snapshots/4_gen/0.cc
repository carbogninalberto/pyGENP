CongestionAvoidance (tcb, segmentsAcked);
int HSEWdGJkahchKyig = (int) (72.353*(74.029)*(0.203)*(-21.906)*(-58.473)*(42.534)*(11.598)*(-82.434));
HSEWdGJkahchKyig = (int) (-47.942*(77.874)*(-22.512));
segmentsAcked = SlowStart (tcb, segmentsAcked);
