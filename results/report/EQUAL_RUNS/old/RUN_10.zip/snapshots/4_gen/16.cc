ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (56.072*(-43.682)*(-57.407)*(85.193)*(48.129)*(-27.384)*(-14.116)*(16.184)*(-80.358));
CongestionAvoidance (tcb, segmentsAcked);
