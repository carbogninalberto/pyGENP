int HnEQSMYKvVPqDZRc = (int) (-46.749+(-81.855)+(4.841)+(-23.795));
float pIcWSquLVqVEmUQX = (float) 69.693;
