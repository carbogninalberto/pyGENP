ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (25.387+(segmentsAcked)+(2.4)+(33.306)+(34.596)+(7.168)+(36.655)+(71.376)+(69.275));
	tcb->m_cWnd = (int) (89.664*(1.913)*(3.643)*(93.072));

} else {
	segmentsAcked = (int) (81.44+(87.316));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-41.271*(-53.142)*(-85.394)*(-23.64)*(-26.467)*(75.334)*(-82.393)*(73.62));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (25.387+(segmentsAcked)+(2.4)+(33.306)+(34.596)+(7.168)+(36.655)+(71.376)+(69.275));
	tcb->m_cWnd = (int) (89.664*(1.913)*(3.643)*(93.072));

} else {
	segmentsAcked = (int) (81.44+(87.316));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (87.98*(-61.676)*(80.214)*(49.594)*(-36.558)*(-30.312)*(-60.41)*(-88.553));
segmentsAcked = (int) (39.279*(-22.164)*(-8.632)*(21.301)*(35.386)*(14.082)*(-85.881)*(-4.644));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
