if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (97.087+(41.894)+(15.909)+(92.19)+(30.484)+(22.835)+(54.933));
	tcb->m_segmentSize = (int) (0.1/97.138);

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(tcb->m_cWnd)*(tcb->m_ssThresh)*(tcb->m_segmentSize));
	segmentsAcked = (int) (tcb->m_segmentSize*(2.766)*(51.135)*(37.361)*(75.489)*(13.989)*(64.15)*(41.588)*(93.276));

}
tcb->m_segmentSize = (int) ((48.617*(tcb->m_cWnd)*(86.349)*(55.579)*(56.596)*(42.107)*(52.978)*(99.822)*(84.93))/55.656);
tcb->m_segmentSize = (int) (66.939+(tcb->m_ssThresh)+(71.594));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
