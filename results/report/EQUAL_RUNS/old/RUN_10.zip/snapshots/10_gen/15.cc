segmentsAcked = (int) (0.1/0.1);
if (tcb->m_cWnd <= segmentsAcked) {
	segmentsAcked = (int) (25.376+(tcb->m_ssThresh)+(76.378)+(13.796)+(tcb->m_cWnd)+(tcb->m_segmentSize));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (tcb->m_segmentSize-(25.007)-(63.818)-(34.809)-(57.941));
	tcb->m_cWnd = (int) (((0.1)+(93.092)+(0.1)+(0.1)+(0.1)+((47.077+(97.359)+(tcb->m_ssThresh)+(96.967)))+(9.092))/((0.1)+(44.951)));
	tcb->m_cWnd = (int) (0.1/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (35.198+(62.782)+(tcb->m_cWnd)+(62.335)+(tcb->m_ssThresh)+(26.003)+(68.088)+(segmentsAcked)+(83.204));
segmentsAcked = (int) (0.1/76.689);
