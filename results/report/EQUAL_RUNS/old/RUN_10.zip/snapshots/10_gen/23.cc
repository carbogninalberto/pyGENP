int zTxeKuxanvtOirBp = (int) (21.288-(99.609)-(segmentsAcked)-(79.308)-(tcb->m_ssThresh)-(16.487)-(6.426)-(19.128));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (78.476+(3.426)+(9.667)+(50.767));
tcb->m_segmentSize = (int) (7.287+(69.443)+(zTxeKuxanvtOirBp)+(zTxeKuxanvtOirBp));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	segmentsAcked = (int) (11.972-(79.271)-(84.978)-(94.593)-(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(12.49)-(25.327));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (0.1/0.1);
	segmentsAcked = (int) (19.689-(48.05));

}
