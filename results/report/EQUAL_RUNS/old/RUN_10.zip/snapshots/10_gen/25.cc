if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_ssThresh = (int) (91.931*(43.886)*(6.509)*(62.116));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(6.838)*(70.125)*(69.445)*(70.065)*(7.512)*(12.962));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (49.167*(84.48)*(19.139)*(segmentsAcked)*(42.125)*(76.23));
segmentsAcked = (int) (77.146+(69.793)+(69.066)+(segmentsAcked)+(segmentsAcked)+(84.412)+(tcb->m_cWnd)+(91.082));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_ssThresh-(17.068)-(40.61)-(59.992)-(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (((20.495)+(48.976)+(0.1)+(24.521)+(0.1))/((20.951)+(0.1)));

} else {
	segmentsAcked = (int) (83.97*(83.537)*(6.804)*(77.24)*(41.801));
	tcb->m_segmentSize = (int) (17.051+(78.658)+(6.907)+(58.554)+(tcb->m_cWnd)+(21.584)+(11.966)+(36.537));
	segmentsAcked = (int) (27.651-(28.36)-(72.365)-(7.128)-(tcb->m_cWnd)-(9.894));

}
