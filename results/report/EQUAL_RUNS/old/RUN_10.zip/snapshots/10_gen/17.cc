tcb->m_cWnd = (int) (segmentsAcked+(33.088)+(19.637)+(tcb->m_cWnd));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (36.65-(69.813)-(41.045));
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (38.001+(23.827)+(78.487)+(19.836)+(41.938)+(55.8)+(46.639)+(36.744)+(67.45));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (53.981-(37.416)-(62.346));

} else {
	tcb->m_ssThresh = (int) (8.948-(42.771)-(21.484)-(tcb->m_ssThresh)-(85.537));
	tcb->m_ssThresh = (int) (0.1/0.1);

}
if (segmentsAcked > tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd*(34.754));
	tcb->m_ssThresh = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (59.557/76.736);
	tcb->m_cWnd = (int) (99.51+(12.856));
	tcb->m_segmentSize = (int) (77.207+(99.991)+(49.53)+(segmentsAcked)+(72.094)+(38.553)+(64.473));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
