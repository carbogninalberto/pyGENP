int NFYnkVNSTUGhdOMT = (int) 12.087;
float EFffsRtWBLhXyqDH = (float) 62.842;
