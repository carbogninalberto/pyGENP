CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
float bxDnYpttILeTotGW = (float) (51.698-(85.509)-(27.19)-(97.355)-(41.848)-(7.47)-(43.1));
tcb->m_ssThresh = (int) (45.935+(segmentsAcked)+(37.715));
tcb->m_segmentSize = (int) (61.017-(66.972)-(1.336)-(tcb->m_cWnd)-(66.427));
tcb->m_segmentSize = (int) (tcb->m_ssThresh-(93.811)-(tcb->m_cWnd));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
