tcb->m_cWnd = (int) (0.1/(47.004-(33.621)-(51.665)-(3.452)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
int GhVwiozDdFOqSBdh = (int) (0.1/0.1);
CongestionAvoidance (tcb, segmentsAcked);
GhVwiozDdFOqSBdh = (int) (0.1/0.1);
