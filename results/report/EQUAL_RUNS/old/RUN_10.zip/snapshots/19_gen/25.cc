segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (70.568+(21.721)+(17.053)+(63.404)+(tcb->m_ssThresh)+(segmentsAcked)+(60.974)+(19.324)+(95.988));
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_segmentSize = (int) (36.8+(66.577));

} else {
	tcb->m_segmentSize = (int) (46.706+(tcb->m_ssThresh)+(34.483)+(4.615));

}
tcb->m_cWnd = (int) (60.53+(86.071)+(70.277)+(33.985)+(17.751)+(62.56)+(segmentsAcked)+(13.787)+(26.399));
ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (63.792+(64.506)+(79.471)+(tcb->m_segmentSize)+(2.668)+(94.459)+(58.822)+(37.361)+(28.617));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(49.589)*(83.488)*(97.47)*(18.208)*(36.29)*(97.62));

}
tcb->m_segmentSize = (int) (39.773-(93.472)-(64.228)-(86.233));
