ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (94.031-(48.295)-(63.139));
	tcb->m_segmentSize = (int) (67.585-(tcb->m_cWnd)-(17.823)-(94.68)-(74.568));

} else {
	segmentsAcked = (int) (98.059*(87.062)*(85.967)*(39.674)*(tcb->m_cWnd)*(35.338));

}
tcb->m_segmentSize = (int) (26.522-(36.492)-(89.942)-(9.735)-(49.748)-(91.809)-(79.899)-(90.194));
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_ssThresh = (int) (75.733*(tcb->m_cWnd)*(23.828));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (0.1/65.371);

}
tcb->m_cWnd = (int) (65.869*(93.238)*(54.051)*(39.92)*(26.848)*(tcb->m_cWnd)*(82.987));
tcb->m_ssThresh = (int) (0.1/11.515);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
