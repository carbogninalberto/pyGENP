float bxDnYpttILeTotGW = (float) (27.877-(79.14)-(-54.017)-(89.232)-(-55.181)-(61.263)-(-88.064));
tcb->m_segmentSize = (int) (40.275-(40.794)-(-7.769)-(-97.926)-(23.226)-(91.165)-(47.695));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-14.631-(22.479)-(7.108)-(-92.039)-(-66.241));
tcb->m_segmentSize = (int) (-74.673-(-73.105)-(10.304));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
