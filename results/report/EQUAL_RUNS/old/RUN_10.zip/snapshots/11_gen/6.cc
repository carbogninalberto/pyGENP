float bxDnYpttILeTotGW = (float) (87.225-(14.917)-(95.15)-(37.099)-(54.286)-(-72.016)-(-8.057));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	bxDnYpttILeTotGW = (float) (56.051-(45.038)-(89.658)-(65.273)-(93.394)-(34.27)-(69.504)-(84.318)-(2.688));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	bxDnYpttILeTotGW = (float) ((((tcb->m_cWnd-(23.882)-(bxDnYpttILeTotGW)-(tcb->m_ssThresh)-(tcb->m_segmentSize)))+(0.1)+(84.186)+(0.1))/((0.1)));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-63.935-(30.751)-(-63.748)-(-53.49)-(-76.036));
tcb->m_segmentSize = (int) (-35.165-(0.148)-(5.24));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
