if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (46.782*(94.996)*(tcb->m_cWnd)*(22.435)*(56.625)*(83.805)*(16.458));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(5.746)-(46.022)-(52.403)-(43.617)-(15.653));

}
float aCNzLaOKMjcmHewn = (float) (((39.564)+((97.721-(49.692)-(34.349)))+(0.1)+(0.1))/((60.087)+(0.1)));
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(4.281))/((29.294)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (aCNzLaOKMjcmHewn*(5.617)*(15.51));
	ReduceCwnd (tcb);

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (36.754+(44.685));
	aCNzLaOKMjcmHewn = (float) (34.326+(aCNzLaOKMjcmHewn)+(78.781)+(90.645));

}
int oEPgAEOpvQDMiYBu = (int) (((11.273)+((38.502+(43.743)+(tcb->m_cWnd)+(57.819)+(97.03)+(tcb->m_segmentSize)))+(0.1)+(0.1)+(35.74)+(0.1))/((0.1)+(92.979)+(0.1)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (oEPgAEOpvQDMiYBu == oEPgAEOpvQDMiYBu) {
	tcb->m_ssThresh = (int) (68.431-(88.476)-(78.926));

} else {
	tcb->m_ssThresh = (int) (55.32/14.487);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
oEPgAEOpvQDMiYBu = (int) (96.21-(28.485)-(74.188)-(segmentsAcked)-(segmentsAcked)-(aCNzLaOKMjcmHewn)-(54.749)-(oEPgAEOpvQDMiYBu));
segmentsAcked = SlowStart (tcb, segmentsAcked);
