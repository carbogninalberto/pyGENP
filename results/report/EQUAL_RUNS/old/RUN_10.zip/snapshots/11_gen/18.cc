TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (27.038+(2.995)+(74.149)+(80.316)+(56.215)+(19.101)+(40.96)+(34.11));
float PcRyLksnVpIcBGYh = (float) (13.382-(46.784));
tcb->m_ssThresh = (int) (segmentsAcked+(73.416)+(78.808)+(93.269));
float ZqJbSRglDqOBlKqT = (float) (60.74/0.1);
segmentsAcked = (int) (28.784-(tcb->m_ssThresh)-(12.314)-(96.256)-(89.936)-(93.072)-(22.778));
