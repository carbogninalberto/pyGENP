CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (48.314*(39.012)*(85.07)*(segmentsAcked)*(54.261)*(tcb->m_ssThresh)*(20.51)*(68.989)*(28.221));
	segmentsAcked = (int) ((81.553+(32.2)+(91.63)+(tcb->m_ssThresh)+(segmentsAcked)+(segmentsAcked)+(4.998)+(24.704)+(47.447))/39.716);

} else {
	segmentsAcked = (int) (32.146/(0.217*(segmentsAcked)*(45.97)*(45.862)*(28.653)));

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) ((53.281-(32.838)-(60.71)-(40.873)-(70.17)-(18.972)-(86.51)-(66.897))/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (83.906+(1.389)+(tcb->m_ssThresh)+(13.53)+(61.479));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (segmentsAcked-(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (((99.138)+((45.451-(75.657)))+(0.1)+(72.123)+(0.1))/((65.506)));

}
