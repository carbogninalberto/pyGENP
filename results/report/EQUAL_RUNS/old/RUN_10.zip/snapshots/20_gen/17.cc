if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	segmentsAcked = (int) (56.225-(85.201));

} else {
	segmentsAcked = (int) (75.707/10.22);
	tcb->m_ssThresh = (int) (55.763*(75.225)*(tcb->m_cWnd)*(tcb->m_cWnd)*(65.158)*(27.952)*(tcb->m_ssThresh));
	segmentsAcked = (int) (6.814*(53.73)*(78.031)*(23.027));

}
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_cWnd = (int) (19.83-(tcb->m_ssThresh)-(tcb->m_cWnd)-(57.648)-(72.854)-(36.031));
	tcb->m_cWnd = (int) (36.99-(33.469)-(6.562)-(4.823)-(30.582)-(28.792)-(80.418));

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(21.405))/((0.1)));
	segmentsAcked = (int) ((tcb->m_segmentSize-(6.628)-(71.163)-(57.321)-(tcb->m_cWnd)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(85.149))/0.1);
	tcb->m_cWnd = (int) ((((tcb->m_segmentSize+(63.914)+(5.98)))+((46.211-(47.42)-(63.714)-(44.542)))+(42.314)+(24.643)+(0.1)+(20.176))/((0.1)));

}
tcb->m_segmentSize = (int) (73.833+(segmentsAcked)+(5.502));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((0.1)+(26.147)+((2.717*(18.876)*(segmentsAcked)*(41.341)))+(0.1)+(45.109)+(29.173)+(0.1))/((40.394)));

} else {
	tcb->m_cWnd = (int) (81.569-(74.173)-(57.687)-(59.169)-(40.989)-(tcb->m_segmentSize)-(37.161));

}
