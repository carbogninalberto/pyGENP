int GhVwiozDdFOqSBdh = (int) (-73.482/-65.349);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
GhVwiozDdFOqSBdh = (int) (-63.98/19.496);
