float xHgShbVtOKjxaaiU = (float) (-29.945-(65.319));
segmentsAcked = (int) (53.595*(73.25)*(19.144)*(-43.69));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
