TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (60.851+(31.986));
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_cWnd = (int) ((28.409*(9.893)*(94.37)*(28.446)*(75.756))/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (78.817/87.763);
	segmentsAcked = (int) (22.26+(6.27)+(31.748));

}
