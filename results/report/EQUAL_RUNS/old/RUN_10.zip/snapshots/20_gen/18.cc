if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked*(84.003));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+(19.184)+(0.1)+(0.1))/((0.1)));
	tcb->m_segmentSize = (int) (10.872+(86.994)+(25.179)+(65.518)+(94.094)+(18.595)+(8.653)+(tcb->m_ssThresh)+(3.27));

}
int pCKkInQHpkYDNNpU = (int) (80.85-(89.982)-(81.994));
segmentsAcked = (int) (((26.919)+(15.499)+((46.577-(76.659)))+(0.1))/((0.1)+(0.1)+(27.203)+(0.1)+(0.1)));
pCKkInQHpkYDNNpU = (int) (70.412-(tcb->m_segmentSize)-(70.596)-(2.321)-(76.047)-(64.705));
tcb->m_cWnd = (int) ((19.703+(51.518)+(tcb->m_cWnd))/0.1);
