tcb->m_ssThresh = (int) ((((89.087-(tcb->m_segmentSize)))+(33.654)+(10.584)+(0.1)+(0.1))/((0.1)+(0.1)+(76.695)));
tcb->m_segmentSize = (int) (40.467-(63.95)-(85.71)-(38.741)-(91.984)-(90.771)-(87.284)-(3.844)-(2.852));
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	segmentsAcked = (int) (72.033/60.192);

} else {
	segmentsAcked = (int) ((((50.925-(19.717)-(72.624)-(74.038)))+((48.932-(97.003)))+(0.1)+(0.1))/((0.1)));
	segmentsAcked = (int) (93.159+(36.36));

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (73.863+(tcb->m_cWnd)+(69.748)+(13.392)+(93.797)+(90.623)+(63.442)+(42.231));
	segmentsAcked = (int) (21.559+(97.565)+(69.677)+(segmentsAcked)+(22.929)+(tcb->m_segmentSize)+(81.764)+(57.917));
	tcb->m_segmentSize = (int) (18.701-(6.33)-(95.346)-(30.876));

} else {
	tcb->m_segmentSize = (int) (((27.296)+(23.007)+(0.1)+(7.923))/((43.717)+(26.95)+(0.1)+(0.1)+(0.1)));
	tcb->m_cWnd = (int) (58.313+(90.159)+(74.655)+(72.255)+(72.0)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) ((36.021+(57.904)+(tcb->m_ssThresh))/0.1);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (38.76+(73.512));

} else {
	tcb->m_ssThresh = (int) (0.1/53.967);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (45.569-(88.353)-(tcb->m_ssThresh)-(61.922)-(72.609)-(25.312)-(segmentsAcked)-(61.955));
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_cWnd = (int) (33.184+(27.045)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(66.873));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (96.436+(segmentsAcked)+(84.306)+(31.463)+(4.93));
	ReduceCwnd (tcb);

}
