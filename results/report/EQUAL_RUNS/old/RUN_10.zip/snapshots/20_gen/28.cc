if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (54.557-(33.874)-(segmentsAcked)-(53.841)-(2.638)-(22.083)-(47.183)-(60.609)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (52.712+(91.041)+(24.095));
	tcb->m_ssThresh = (int) (((0.1)+(74.166)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_cWnd = (int) (51.039*(4.189)*(91.871)*(32.77));
	segmentsAcked = (int) (79.051*(79.294)*(42.908)*(tcb->m_ssThresh)*(23.948)*(tcb->m_ssThresh)*(36.651)*(44.399)*(53.968));
	tcb->m_segmentSize = (int) ((76.53*(64.457)*(80.891)*(49.623)*(0.027)*(98.881)*(41.668))/92.823);

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (45.361-(69.549)-(38.462)-(69.222)-(72.651)-(17.58)-(4.804));
tcb->m_ssThresh = (int) (2.131+(37.968));
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_ssThresh = (int) (65.474*(27.028)*(tcb->m_cWnd)*(42.28)*(47.759)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(79.215));
	segmentsAcked = (int) (68.391+(50.481)+(tcb->m_cWnd)+(54.044)+(segmentsAcked)+(90.028)+(tcb->m_ssThresh)+(2.413));

} else {
	tcb->m_ssThresh = (int) (57.72+(33.525)+(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);

}
