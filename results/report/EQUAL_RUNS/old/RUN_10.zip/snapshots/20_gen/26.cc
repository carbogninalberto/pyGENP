tcb->m_ssThresh = (int) (1.147-(37.309)-(76.713)-(30.544));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (77.782/47.168);
tcb->m_cWnd = (int) (((29.794)+((99.744*(4.431)*(20.874)*(73.281)*(tcb->m_segmentSize)*(93.448)*(64.303)*(8.694)*(4.585)))+(93.022)+((53.992+(92.325)+(89.459)+(segmentsAcked)+(32.984)+(72.385)+(40.179)+(25.926)+(76.558)))+(0.1))/((0.1)+(0.1)));
segmentsAcked = (int) (10.973-(28.166)-(37.91)-(26.198)-(30.187)-(66.558)-(37.929)-(74.115));
tcb->m_cWnd = (int) (30.091-(34.187)-(tcb->m_ssThresh)-(69.684)-(segmentsAcked));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
