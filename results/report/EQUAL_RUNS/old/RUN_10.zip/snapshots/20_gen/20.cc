ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (61.921*(tcb->m_ssThresh)*(68.465)*(69.032)*(segmentsAcked)*(7.728)*(78.098)*(13.346));
if (segmentsAcked >= segmentsAcked) {
	tcb->m_ssThresh = (int) (80.011/88.538);
	tcb->m_ssThresh = (int) ((98.198+(34.768)+(18.812)+(42.411)+(74.071)+(30.98)+(tcb->m_ssThresh)+(94.958))/43.327);
	tcb->m_cWnd = (int) (32.898-(68.14)-(tcb->m_ssThresh)-(26.981)-(71.571));

} else {
	tcb->m_ssThresh = (int) (44.71+(29.254)+(98.122)+(segmentsAcked)+(69.608)+(68.276));
	tcb->m_ssThresh = (int) (62.786*(56.127)*(88.5)*(96.306)*(segmentsAcked)*(68.261)*(48.287)*(74.276));
	tcb->m_cWnd = (int) (0.1/(76.253*(12.227)*(segmentsAcked)*(4.414)*(95.313)*(84.501)));

}
segmentsAcked = (int) (0.1/97.867);
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (47.505+(50.133)+(96.514));

} else {
	tcb->m_ssThresh = (int) (((0.1)+(12.797)+(93.439)+(0.1)+(0.1))/((0.1)+(3.701)+(20.659)));
	segmentsAcked = (int) (13.11+(45.325)+(33.919)+(13.576)+(25.946)+(segmentsAcked)+(48.919)+(83.14));

}
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (67.278*(87.063)*(80.116)*(9.308)*(tcb->m_ssThresh)*(77.421)*(28.792)*(74.148));
	tcb->m_segmentSize = (int) (76.159*(19.434)*(64.898)*(61.23)*(81.785));
	tcb->m_segmentSize = (int) (53.863-(21.479)-(14.648)-(57.59)-(33.35)-(37.929));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(95.529)+(15.95)+(29.618)+(tcb->m_segmentSize)+(27.916)+(77.291)+(19.175));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(48.045)-(48.239));
	segmentsAcked = (int) (60.695*(25.585)*(38.501)*(15.677));

}
ReduceCwnd (tcb);
