ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (81.44+(87.316));

} else {
	segmentsAcked = (int) (25.387+(segmentsAcked)+(2.4)+(33.306)+(34.596)+(7.168)+(36.655)+(71.376)+(69.275));
	tcb->m_cWnd = (int) (89.664*(1.913)*(3.643)*(93.072));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (25.387+(segmentsAcked)+(2.4)+(33.306)+(34.596)+(7.168)+(36.655)+(71.376)+(69.275));
	tcb->m_cWnd = (int) (89.664*(1.913)*(3.643)*(93.072));

} else {
	segmentsAcked = (int) (81.44+(87.316));

}
segmentsAcked = (int) (-4.712*(74.693)*(46.956)*(0.628)*(-5.208)*(-21.962)*(84.43)*(88.25));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-73.316*(59.881)*(-14.361)*(-72.223)*(-88.042)*(66.469)*(-52.009)*(82.077));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
