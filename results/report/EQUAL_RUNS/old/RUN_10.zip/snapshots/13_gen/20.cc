float pIcWSquLVqVEmUQX = (float) 54.659;
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
float ZCCsBQBjLsoAJNBl = (float) (-18.401+(54.259)+(-28.658)+(30.119)+(53.11)+(-45.481));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
