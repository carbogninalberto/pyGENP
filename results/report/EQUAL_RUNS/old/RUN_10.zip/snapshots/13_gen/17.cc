segmentsAcked = SlowStart (tcb, segmentsAcked);
int toMnIiwkJzpnSzCq = (int) (51.123/49.6);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
