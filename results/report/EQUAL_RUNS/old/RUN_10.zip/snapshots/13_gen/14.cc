float oWemeUMapIxPaAkG = (float) (-22.66+(-84.449)+(-53.651)+(91.355)+(2.43)+(13.531)+(-47.617)+(13.3));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-17.701+(30.24)+(-88.673)+(-49.651)+(87.625));
oWemeUMapIxPaAkG = (float) (93.906-(72.526)-(84.851)-(-15.682)-(29.885)-(15.491));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
