CongestionAvoidance (tcb, segmentsAcked);
float pIcWSquLVqVEmUQX = (float) 54.659;
CongestionAvoidance (tcb, segmentsAcked);
float ZCCsBQBjLsoAJNBl = (float) (12.135+(9.224)+(-43.395)+(49.976)+(43.592)+(-28.846));
CongestionAvoidance (tcb, segmentsAcked);
