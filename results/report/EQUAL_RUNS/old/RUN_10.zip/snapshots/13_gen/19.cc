tcb->m_cWnd = (int) (-45.072+(44.069)+(67.105)+(23.314)+(-40.255)+(69.967)+(-81.737)+(-47.572));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (87.117/-36.774);
segmentsAcked = (int) (-78.385/89.642);
