segmentsAcked = SlowStart (tcb, segmentsAcked);
float oWemeUMapIxPaAkG = (float) (96.706+(38.619)+(-88.7)+(-14.542)+(-83.169)+(9.206)+(-70.595)+(-40.135));
segmentsAcked = (int) (-82.037+(-46.688)+(-99.622)+(-93.46)+(45.948));
oWemeUMapIxPaAkG = (float) (-64.682-(26.571)-(-47.886)-(91.471)-(-79.037)-(-79.884));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
