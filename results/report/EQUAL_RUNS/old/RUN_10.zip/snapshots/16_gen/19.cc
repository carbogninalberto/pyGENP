float oWemeUMapIxPaAkG = (float) (20.778+(-18.037)+(-78.844)+(26.304)+(88.65)+(-31.905)+(37.402)+(-86.654));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-0.876+(86.22)+(80.494)+(90.798)+(-84.027));
oWemeUMapIxPaAkG = (float) (78.931-(-28.985)-(65.699)-(6.363)-(49.055)-(50.645));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
