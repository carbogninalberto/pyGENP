segmentsAcked = SlowStart (tcb, segmentsAcked);
float oWemeUMapIxPaAkG = (float) (72.006+(-85.534)+(46.624)+(-55.67)+(-64.747)+(-23.689)+(-40.93)+(-13.129));
segmentsAcked = (int) (-81.948+(95.923)+(-87.216)+(-7.063)+(29.938));
oWemeUMapIxPaAkG = (float) (-15.072-(69.173)-(-17.745)-(69.412)-(-37.779)-(-90.693));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
