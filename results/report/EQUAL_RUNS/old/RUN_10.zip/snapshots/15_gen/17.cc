float oWemeUMapIxPaAkG = (float) (-36.436+(79.391)+(-67.942)+(80.164)+(-18.591)+(59.901)+(-49.39)+(81.992));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (65.711+(-84.623)+(46.44)+(-18.834)+(91.823));
oWemeUMapIxPaAkG = (float) (-69.333-(94.269)-(-74.377)-(20.817)-(55.126)-(-95.016));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
