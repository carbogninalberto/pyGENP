int MjtGhDTpBeFsbSME = (int) (29.971*(64.421)*(-57.203)*(-89.867));
tcb->m_cWnd = (int) (-48.147*(74.636)*(5.301)*(-1.35)*(-7.832)*(35.301)*(-35.915)*(-90.245));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-23.252/79.144);
