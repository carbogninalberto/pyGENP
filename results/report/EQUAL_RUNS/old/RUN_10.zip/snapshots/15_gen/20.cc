int MjtGhDTpBeFsbSME = (int) (87.105*(-17.307)*(94.617)*(36.643));
tcb->m_segmentSize = (int) (35.406*(86.399)*(24.179)*(-79.285)*(-66.958)*(-62.875));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-27.187/4.087);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-18.394/30.924);
