ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (27.705*(26.616)*(-90.356)*(-35.976)*(13.268)*(-66.361)*(-63.614)*(74.731)*(-35.975));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
