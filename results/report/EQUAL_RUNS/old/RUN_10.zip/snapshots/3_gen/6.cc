segmentsAcked = SlowStart (tcb, segmentsAcked);
int bGzbPKmjThOICgUF = (int) 68.407;
segmentsAcked = SlowStart (tcb, segmentsAcked);
bGzbPKmjThOICgUF = (int) (-21.987+(12.892)+(16.199)+(-88.122)+(75.492)+(30.133)+(53.451));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (bGzbPKmjThOICgUF != bGzbPKmjThOICgUF) {
	bGzbPKmjThOICgUF = (int) (segmentsAcked*(bGzbPKmjThOICgUF)*(72.625)*(69.368)*(75.588)*(29.847));
	ReduceCwnd (tcb);

} else {
	bGzbPKmjThOICgUF = (int) (bGzbPKmjThOICgUF-(30.707)-(1.281));
	tcb->m_cWnd = (int) (79.43*(10.388)*(56.698)*(segmentsAcked)*(70.673));
	segmentsAcked = (int) (94.267-(71.502));

}
bGzbPKmjThOICgUF = (int) (76.492+(-61.218)+(-75.658)+(82.44)+(-14.07)+(15.706)+(-53.643));
ReduceCwnd (tcb);
if (bGzbPKmjThOICgUF != bGzbPKmjThOICgUF) {
	bGzbPKmjThOICgUF = (int) (segmentsAcked*(bGzbPKmjThOICgUF)*(17.919)*(69.368)*(75.588)*(29.847));
	ReduceCwnd (tcb);

} else {
	bGzbPKmjThOICgUF = (int) (bGzbPKmjThOICgUF-(30.707)-(1.281));
	tcb->m_cWnd = (int) (79.43*(10.388)*(56.698)*(segmentsAcked)*(70.673));
	segmentsAcked = (int) (94.267-(71.502));

}
