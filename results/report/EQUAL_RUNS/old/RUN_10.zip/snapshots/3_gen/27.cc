ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (5.704*(73.382)*(-33.722)*(81.813)*(-29.009)*(-9.843)*(-50.732)*(-96.546)*(-29.487));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-26.452*(95.017)*(84.993)*(16.243)*(-76.61)*(0.194)*(-29.499)*(36.094)*(51.442));
CongestionAvoidance (tcb, segmentsAcked);
