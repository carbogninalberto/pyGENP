segmentsAcked = (int) (((72.364)+((25.211-(99.558)-(-66.212)-(-98.974)-(-55.147)-(-69.129)))+(-16.594)+(-43.743)+(25.76)+(-14.978))/((-74.889)));
float ZoAzHyrTamqfnCGg = (float) 87.165;
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	segmentsAcked = (int) (ZoAzHyrTamqfnCGg+(tcb->m_segmentSize)+(21.766)+(77.422)+(29.474)+(15.042)+(39.291));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (91.557-(50.081)-(25.592)-(48.405));

} else {
	segmentsAcked = (int) (42.165+(26.845)+(78.466)+(-59.768)+(16.905)+(99.173)+(-95.101)+(48.278)+(39.973));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_cWnd < ZoAzHyrTamqfnCGg) {
	ZoAzHyrTamqfnCGg = (float) (0.1/0.1);

} else {
	ZoAzHyrTamqfnCGg = (float) ((tcb->m_segmentSize-(51.825)-(tcb->m_ssThresh)-(70.383))/0.1);

}
if (ZoAzHyrTamqfnCGg != tcb->m_cWnd) {
	ZoAzHyrTamqfnCGg = (float) (16.822*(tcb->m_segmentSize)*(82.65)*(tcb->m_segmentSize)*(59.504)*(78.518)*(10.05)*(44.839)*(15.591));

} else {
	ZoAzHyrTamqfnCGg = (float) (((34.983)+(7.823)+(0.1)+(68.903)+(41.828))/((69.984)+(0.1)));
	tcb->m_segmentSize = (int) (60.472-(9.163)-(95.946)-(96.711)-(99.617)-(13.851));

}
segmentsAcked = (int) (-88.235*(-56.77)*(-74.613)*(-55.077)*(-82.365)*(50.408)*(33.697));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < ZoAzHyrTamqfnCGg) {
	ZoAzHyrTamqfnCGg = (float) (0.1/0.1);

} else {
	ZoAzHyrTamqfnCGg = (float) ((tcb->m_segmentSize-(51.825)-(tcb->m_ssThresh)-(70.383))/0.1);

}
tcb->m_segmentSize = (int) (96.013*(25.597));
if (ZoAzHyrTamqfnCGg != tcb->m_cWnd) {
	ZoAzHyrTamqfnCGg = (float) (16.822*(tcb->m_segmentSize)*(82.65)*(tcb->m_segmentSize)*(59.504)*(78.518)*(10.05)*(44.839)*(15.591));

} else {
	ZoAzHyrTamqfnCGg = (float) (((34.983)+(7.823)+(0.1)+(68.903)+(41.828))/((69.984)+(0.1)));
	tcb->m_segmentSize = (int) (60.472-(9.163)-(95.946)-(96.711)-(99.617)-(13.851));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (-63.895*(54.588)*(22.005)*(90.541)*(-51.48)*(69.172)*(13.549));
CongestionAvoidance (tcb, segmentsAcked);
