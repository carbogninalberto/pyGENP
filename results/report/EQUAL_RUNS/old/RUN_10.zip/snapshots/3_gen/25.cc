ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-44.365*(-85.444)*(47.598)*(-0.163)*(-18.374)*(38.182)*(50.737)*(-42.819)*(82.25));
segmentsAcked = (int) (-45.972*(-86.599)*(29.401)*(-84.075)*(73.424)*(17.027)*(56.216)*(80.133)*(-95.902));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
