ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (34.094*(-95.396)*(-55.941)*(37.93)*(-2.653)*(-25.614)*(-82.968)*(-39.19)*(22.673));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
