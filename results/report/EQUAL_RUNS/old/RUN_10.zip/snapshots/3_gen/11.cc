ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (17.29*(-80.943)*(14.678)*(31.299)*(67.568)*(79.81)*(91.665)*(54.495)*(-5.5));
CongestionAvoidance (tcb, segmentsAcked);
