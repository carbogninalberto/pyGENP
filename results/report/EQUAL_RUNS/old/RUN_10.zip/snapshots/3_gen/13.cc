int HSEWdGJkahchKyig = (int) (20.373*(60.819)*(92.529)*(34.979)*(10.561)*(55.91)*(14.142)*(80.001));
int iIUmbRTnIvlcGoul = (int) (-3.912+(-52.29));
