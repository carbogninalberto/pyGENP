ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-67.588*(21.125)*(-26.046)*(-86.259)*(79.21)*(-11.258)*(60.138)*(63.955)*(46.458));
CongestionAvoidance (tcb, segmentsAcked);
