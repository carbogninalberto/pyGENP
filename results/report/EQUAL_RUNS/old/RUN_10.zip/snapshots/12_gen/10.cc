segmentsAcked = (int) (-8.256/-73.664);
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (48.314*(39.012)*(85.07)*(segmentsAcked)*(54.261)*(-70.035)*(20.51)*(68.989)*(28.221));
	segmentsAcked = (int) ((81.553+(32.2)+(91.63)+(tcb->m_ssThresh)+(segmentsAcked)+(segmentsAcked)+(4.998)+(24.704)+(47.447))/39.716);

} else {
	segmentsAcked = (int) (32.146/(0.217*(segmentsAcked)*(45.97)*(45.862)*(28.653)));

}
