if (tcb->m_cWnd <= segmentsAcked) {
	segmentsAcked = (int) (25.376+(-72.934)+(76.378)+(13.796)+(tcb->m_cWnd)+(tcb->m_segmentSize));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (tcb->m_segmentSize-(25.007)-(63.818)-(34.809)-(57.941));
	tcb->m_cWnd = (int) (((0.1)+(93.092)+(0.1)+(0.1)+(0.1)+((47.077+(97.359)+(tcb->m_ssThresh)+(96.967)))+(9.092))/((0.1)+(44.951)));
	tcb->m_cWnd = (int) (0.1/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-48.921/-94.408);
segmentsAcked = (int) (20.112/15.717);
