float bxDnYpttILeTotGW = (float) 38.341;
if (tcb->m_cWnd >= tcb->m_cWnd) {
	bxDnYpttILeTotGW = (float) (56.051-(45.038)-(89.658)-(65.273)-(93.394)-(34.27)-(69.504)-(84.318)-(2.688));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	bxDnYpttILeTotGW = (float) ((((tcb->m_cWnd-(23.882)-(bxDnYpttILeTotGW)-(tcb->m_ssThresh)-(tcb->m_segmentSize)))+(0.1)+(84.186)+(0.1))/((0.1)));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (60.199-(-73.584)-(83.154)-(-53.122)-(96.659));
tcb->m_segmentSize = (int) (54.631-(-51.796)-(-44.725));
