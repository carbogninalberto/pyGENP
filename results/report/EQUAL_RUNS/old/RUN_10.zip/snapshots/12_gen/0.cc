segmentsAcked = SlowStart (tcb, segmentsAcked);
float oWemeUMapIxPaAkG = (float) (39.898+(-47.071)+(-30.471)+(85.65)+(48.765)+(-53.012)+(-50.379)+(-93.902));
segmentsAcked = (int) (21.137+(-63.081)+(9.311)+(-35.136)+(-79.033));
oWemeUMapIxPaAkG = (float) (95.448-(18.211)-(-50.07)-(-40.667)-(68.048)-(5.529));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
