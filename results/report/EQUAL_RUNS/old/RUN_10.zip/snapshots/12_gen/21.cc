segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
