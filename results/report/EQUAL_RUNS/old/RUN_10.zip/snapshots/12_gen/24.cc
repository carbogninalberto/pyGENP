segmentsAcked = (int) (97.571+(85.746)+(62.338)+(-60.877)+(20.924)+(74.93)+(6.921));
float bxDnYpttILeTotGW = (float) 80.093;
if (tcb->m_cWnd >= tcb->m_cWnd) {
	bxDnYpttILeTotGW = (float) (56.051-(45.038)-(89.658)-(65.273)-(93.394)-(34.27)-(69.504)-(84.318)-(2.688));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	bxDnYpttILeTotGW = (float) ((((tcb->m_cWnd-(23.882)-(bxDnYpttILeTotGW)-(tcb->m_ssThresh)-(tcb->m_segmentSize)))+(0.1)+(84.186)+(0.1))/((0.1)));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (55.698-(39.788)-(-40.086)-(-74.816)-(52.285));
tcb->m_segmentSize = (int) (61.582-(-63.568)-(44.427));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
