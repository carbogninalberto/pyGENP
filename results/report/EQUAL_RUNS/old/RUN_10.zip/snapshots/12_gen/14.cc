int xoqHcluZYfkmErys = (int) (-57.441-(-73.106)-(41.876)-(30.291));
