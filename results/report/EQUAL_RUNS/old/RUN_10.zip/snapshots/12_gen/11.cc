if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (8.442-(35.736));

} else {
	tcb->m_cWnd = (int) (((0.1)+(77.26)+(0.1)+(0.1)+(0.1)+(13.919))/((34.7)+(0.1)));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-19.792/-3.675);
