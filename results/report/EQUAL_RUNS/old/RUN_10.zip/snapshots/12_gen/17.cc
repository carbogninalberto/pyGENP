tcb->m_segmentSize = (int) (27.568+(-98.739)+(-66.538)+(-79.332)+(18.278)+(48.099)+(40.075));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
