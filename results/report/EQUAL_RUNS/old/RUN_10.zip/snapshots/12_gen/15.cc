int LgzyIZHGwfBHEcUl = (int) (-23.835*(84.433)*(52.287)*(47.45)*(-15.443));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-97.729-(67.447)-(32.608)-(29.899)-(-69.937));
tcb->m_cWnd = (int) ((28.238+(72.7)+(69.633)+(-18.441)+(-5.652)+(34.318)+(50.944)+(-82.335)+(-53.908))/-64.81);
if (LgzyIZHGwfBHEcUl >= segmentsAcked) {
	tcb->m_segmentSize = (int) (53.644*(44.63)*(LgzyIZHGwfBHEcUl)*(47.897)*(82.927));

} else {
	tcb->m_segmentSize = (int) (LgzyIZHGwfBHEcUl*(69.339)*(39.502)*(57.59));
	tcb->m_cWnd = (int) (38.278*(4.036)*(46.796)*(88.175)*(63.389)*(67.576)*(73.774)*(tcb->m_segmentSize));

}
if (segmentsAcked > tcb->m_segmentSize) {
	segmentsAcked = (int) (20.614*(3.127)*(2.394)*(tcb->m_cWnd)*(88.673)*(59.19)*(34.056)*(5.359)*(-89.812));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (-76.792-(96.441)-(63.365)-(87.081)-(segmentsAcked)-(21.988)-(59.044)-(48.17)-(LgzyIZHGwfBHEcUl));

}
