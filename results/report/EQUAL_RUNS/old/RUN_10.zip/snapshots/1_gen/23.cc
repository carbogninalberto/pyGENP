CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (0.1/0.1);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (60.447/(96.335-(32.445)-(tcb->m_segmentSize)-(41.982)-(20.247)-(96.698)));
	tcb->m_segmentSize = (int) (3.346-(76.213)-(3.114)-(10.857)-(62.734)-(3.322)-(57.1));
	tcb->m_ssThresh = (int) (98.102+(60.791)+(77.41));

} else {
	tcb->m_cWnd = (int) (8.546/0.1);
	tcb->m_ssThresh = (int) (0.1/0.1);

}
int CxftAiPctOvmVbmB = (int) (11.803*(57.825)*(38.279)*(58.012)*(87.97)*(59.635)*(18.878)*(50.904)*(segmentsAcked));
