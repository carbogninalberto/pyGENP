int nqLfunYjEzCpWitE = (int) (tcb->m_cWnd+(50.472)+(57.607)+(83.8));
int JlrgzDsSzXTpGECo = (int) (25.89/54.712);
tcb->m_ssThresh = (int) (((56.241)+(3.172)+((13.469*(43.377)*(5.876)*(tcb->m_cWnd)*(50.526)*(31.6)*(78.132)))+(0.1)+(0.1)+(0.1))/((63.816)+(19.952)+(58.661)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (JlrgzDsSzXTpGECo == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (28.501+(40.702)+(30.096));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(77.196)+(62.883)+(84.751)+(62.809)+(63.322)+(66.43)+(6.637));
	tcb->m_ssThresh = (int) (69.696*(76.204)*(86.824)*(21.558)*(29.048)*(32.754)*(84.595)*(segmentsAcked)*(88.952));

}
if (tcb->m_segmentSize >= nqLfunYjEzCpWitE) {
	tcb->m_segmentSize = (int) (94.215-(24.856)-(nqLfunYjEzCpWitE)-(73.568)-(13.802)-(89.423)-(37.706)-(20.604));
	JlrgzDsSzXTpGECo = (int) (segmentsAcked+(66.266)+(tcb->m_cWnd)+(JlrgzDsSzXTpGECo)+(71.837)+(2.525)+(78.51)+(54.977)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) ((88.608-(82.356)-(nqLfunYjEzCpWitE)-(47.823)-(36.67)-(32.957)-(4.987))/(segmentsAcked+(27.217)+(81.923)+(25.418)+(88.6)+(14.387)+(41.461)+(tcb->m_cWnd)));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
