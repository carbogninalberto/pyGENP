TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (38.408*(98.981));
tcb->m_segmentSize = (int) (52.153-(24.68)-(73.489)-(84.497)-(80.386)-(18.853));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (33.132*(61.933)*(98.822)*(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (((77.02)+((7.087-(42.639)-(42.867)-(25.962)-(2.831)-(89.777)))+((tcb->m_cWnd-(segmentsAcked)-(27.53)-(tcb->m_cWnd)-(56.814)-(93.352)-(94.712)))+(1.018)+((57.011*(72.811)))+(0.1)+(70.882))/((33.011)));

} else {
	tcb->m_cWnd = (int) (24.087+(tcb->m_cWnd)+(29.304));
	tcb->m_segmentSize = (int) (50.951+(12.947)+(segmentsAcked));

}
ReduceCwnd (tcb);
