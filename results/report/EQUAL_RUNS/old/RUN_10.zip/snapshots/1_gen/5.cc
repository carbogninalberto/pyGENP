if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (56.274+(34.446)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(70.881)+(35.316));

} else {
	segmentsAcked = (int) (0.1/27.623);
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (2.395*(8.885)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(85.246)*(95.021)*(67.201)*(40.924));
tcb->m_ssThresh = (int) (0.1/41.7);
segmentsAcked = (int) (32.715*(3.569)*(22.546)*(52.537));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(segmentsAcked)-(91.376));
tcb->m_ssThresh = (int) (50.842+(17.251)+(39.928)+(12.003)+(70.603));
tcb->m_segmentSize = (int) (0.1/62.292);
