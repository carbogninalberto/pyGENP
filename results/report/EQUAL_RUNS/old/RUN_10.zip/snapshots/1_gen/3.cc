if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (15.807+(87.436)+(76.543)+(5.349)+(tcb->m_cWnd)+(50.147));
	segmentsAcked = (int) (tcb->m_ssThresh+(55.112)+(45.641)+(19.61));

} else {
	tcb->m_segmentSize = (int) (1.723*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (42.51+(1.997)+(70.445)+(22.966));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (14.936+(82.21)+(46.604)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(46.076)+(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(34.49)*(84.214)*(32.089)*(55.5)*(tcb->m_cWnd)*(15.036)*(tcb->m_segmentSize)*(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (17.052/67.697);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
float VSiccmMTSPfiRQSZ = (float) (80.192-(tcb->m_cWnd)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(82.729)-(1.839)-(29.834));
if (segmentsAcked < VSiccmMTSPfiRQSZ) {
	tcb->m_cWnd = (int) (66.322*(13.154)*(91.529)*(72.797)*(48.632)*(83.338)*(66.194)*(42.678)*(16.1));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (53.976-(23.296));

}
if (segmentsAcked != segmentsAcked) {
	VSiccmMTSPfiRQSZ = (float) (((0.1)+(1.697)+(0.1)+(82.736)+(72.825))/((29.798)+(0.1)));

} else {
	VSiccmMTSPfiRQSZ = (float) (37.978+(56.327)+(VSiccmMTSPfiRQSZ)+(87.762)+(6.978)+(tcb->m_ssThresh)+(8.855)+(11.36));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (71.047+(38.987)+(65.614)+(69.05)+(tcb->m_ssThresh));

}
tcb->m_segmentSize = (int) (37.159-(19.333)-(16.436)-(64.444)-(tcb->m_cWnd)-(13.405)-(86.757)-(95.829)-(66.59));
segmentsAcked = SlowStart (tcb, segmentsAcked);
