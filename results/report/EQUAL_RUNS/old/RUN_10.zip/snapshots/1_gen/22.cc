if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (70.011-(4.668)-(90.373)-(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (53.865-(11.936)-(45.809)-(tcb->m_ssThresh)-(21.404)-(12.98)-(69.534));

}
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_ssThresh = (int) (74.434-(92.513)-(tcb->m_ssThresh)-(59.31)-(7.15)-(16.371)-(21.78)-(60.135)-(37.928));
	tcb->m_segmentSize = (int) (((65.813)+(0.1)+(65.437)+((28.297-(94.129)-(29.994)-(60.139)-(54.69)-(89.697)-(tcb->m_segmentSize)))+(0.1))/((0.1)+(55.57)+(80.18)+(55.953)));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (86.032/56.928);

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (65.763/56.402);

} else {
	segmentsAcked = (int) (44.773-(20.423)-(97.198)-(tcb->m_ssThresh)-(segmentsAcked)-(21.087));
	tcb->m_ssThresh = (int) (68.153*(67.417)*(92.748)*(43.25)*(11.216));

}
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_ssThresh = (int) (39.42+(19.48)+(9.497)+(74.851)+(tcb->m_ssThresh)+(78.308)+(40.865)+(tcb->m_ssThresh));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (96.35*(6.34)*(92.262));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (10.528/0.1);
	tcb->m_cWnd = (int) (((0.1)+((73.599*(segmentsAcked)*(29.619)))+(0.1)+(0.1)+(96.725)+(19.535)+(99.971))/((0.1)+(34.253)));

} else {
	tcb->m_ssThresh = (int) (((0.1)+(37.634)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(83.223)+(0.1)));
	tcb->m_ssThresh = (int) (0.1/25.182);
	ReduceCwnd (tcb);

}
