ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (79.399-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(99.149)-(5.909)-(91.539)-(19.901)-(40.346));
	segmentsAcked = (int) (45.292/91.348);
	tcb->m_segmentSize = (int) (40.223+(76.814)+(segmentsAcked)+(58.406)+(49.497)+(61.746)+(segmentsAcked)+(88.15)+(26.417));

} else {
	segmentsAcked = (int) (35.436/68.408);
	tcb->m_ssThresh = (int) ((((2.366-(75.169)-(84.697)))+(0.1)+(88.799)+(28.601))/((7.685)+(28.785)));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (3.446*(57.083)*(55.949)*(tcb->m_segmentSize)*(90.787)*(54.49)*(18.099)*(tcb->m_segmentSize)*(tcb->m_ssThresh));
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_cWnd = (int) (94.716*(48.043)*(50.574)*(tcb->m_segmentSize)*(66.68));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (segmentsAcked-(segmentsAcked)-(82.707)-(54.19)-(9.226)-(40.774)-(7.063)-(14.87));

} else {
	tcb->m_cWnd = (int) (79.718-(tcb->m_cWnd)-(80.487)-(79.327)-(24.845)-(57.007)-(53.441)-(65.469));

}
CongestionAvoidance (tcb, segmentsAcked);
