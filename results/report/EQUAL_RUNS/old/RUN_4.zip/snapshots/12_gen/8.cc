segmentsAcked = (int) (91.893/97.099);
float JtUkcEprZHaIOxdO = (float) (77.543+(-66.93)+(73.723)+(-75.2));
CongestionAvoidance (tcb, segmentsAcked);
