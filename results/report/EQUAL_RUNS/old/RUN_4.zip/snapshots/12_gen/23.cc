float VJZiSDrMtqxlkapg = (float) 68.341;
VJZiSDrMtqxlkapg = (float) (-59.858+(-80.034)+(-36.951)+(95.229));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/78.251);
	tcb->m_segmentSize = (int) (31.926*(tcb->m_segmentSize)*(60.9));

} else {
	tcb->m_segmentSize = (int) (21.804+(97.997)+(VJZiSDrMtqxlkapg)+(tcb->m_segmentSize)+(14.43)+(40.273)+(60.28));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (81.685-(26.968)-(segmentsAcked)-(35.673)-(1.03)-(45.369));
	tcb->m_cWnd = (int) (68.685+(69.751)+(18.92)+(93.319)+(74.247)+(47.944)+(7.86));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (96.416-(97.674)-(35.575)-(92.643)-(tcb->m_segmentSize)-(90.239)-(62.289)-(19.25)-(26.912));

}
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/78.251);
	tcb->m_segmentSize = (int) (31.926*(tcb->m_segmentSize)*(60.9));

} else {
	tcb->m_segmentSize = (int) (21.804+(97.997)+(VJZiSDrMtqxlkapg)+(tcb->m_segmentSize)+(14.43)+(40.273)+(60.28));

}
tcb->m_segmentSize = (int) (-56.017-(68.205)-(-1.104)-(-18.959)-(-55.591));
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (81.685-(26.968)-(segmentsAcked)-(35.673)-(1.03)-(45.369));
	tcb->m_cWnd = (int) (68.685+(69.751)+(18.92)+(93.319)+(74.247)+(47.944)+(7.86));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (96.416-(97.674)-(35.575)-(92.643)-(tcb->m_segmentSize)-(90.239)-(62.289)-(19.25)-(26.912));

}
tcb->m_segmentSize = (int) (-9.209-(-96.388)-(49.467)-(-77.341)-(83.311));
