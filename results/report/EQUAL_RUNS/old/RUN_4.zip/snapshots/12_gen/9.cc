int YNKePzFZwtbIrZyc = (int) 7.347;
tcb->m_segmentSize = (int) ((75.271-(segmentsAcked)-(16.384)-(tcb->m_ssThresh)-(-64.397))/84.066);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
