int HPBfyXSolMGrMDkw = (int) (56.604*(-52.138));
