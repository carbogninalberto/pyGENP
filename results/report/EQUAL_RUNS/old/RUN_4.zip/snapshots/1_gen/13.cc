segmentsAcked = (int) (70.349+(51.428)+(3.772)+(27.838));
tcb->m_ssThresh = (int) (51.684-(16.195)-(23.895)-(38.071)-(95.66));
segmentsAcked = (int) (((46.604)+(0.1)+(84.909)+(74.979)+((22.991+(71.106)+(42.031)+(31.122)))+(8.044)+(58.581))/((29.446)+(15.655)));
tcb->m_ssThresh = (int) (54.449*(60.808)*(98.205)*(5.074)*(42.629));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
