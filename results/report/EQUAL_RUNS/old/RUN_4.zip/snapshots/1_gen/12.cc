ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((47.157)+(0.1)+((33.911-(33.166)-(83.6)))+(0.1)+(75.029)+(46.292))/((0.1)));

} else {
	tcb->m_cWnd = (int) (77.267*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(35.207)*(2.354)*(55.403));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int HvYUYEJzhkwXhVeB = (int) (65.122+(tcb->m_cWnd)+(57.411)+(84.093)+(tcb->m_segmentSize)+(66.844)+(tcb->m_cWnd)+(segmentsAcked)+(95.799));
if (HvYUYEJzhkwXhVeB != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (64.388/51.138);
	segmentsAcked = (int) ((4.639+(75.495))/0.1);

} else {
	tcb->m_cWnd = (int) (50.086-(27.956)-(0.922)-(12.964)-(46.655)-(0.813));

}
HvYUYEJzhkwXhVeB = (int) (42.467*(56.062)*(31.675));
