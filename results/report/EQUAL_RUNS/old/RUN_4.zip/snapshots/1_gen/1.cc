CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (75.109*(40.609)*(75.691)*(21.913)*(83.276)*(22.432));
	tcb->m_segmentSize = (int) (29.928*(76.971)*(50.416)*(55.033)*(56.933)*(93.966));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (21.582+(99.704)+(67.117)+(68.577)+(23.903)+(49.274));
	tcb->m_segmentSize = (int) (36.78+(tcb->m_ssThresh)+(49.548)+(57.519));
	tcb->m_ssThresh = (int) (90.314*(25.408)*(43.462)*(segmentsAcked)*(58.46)*(10.855)*(24.845)*(84.83));

}
tcb->m_cWnd = (int) (18.947+(75.168)+(15.178)+(6.322)+(54.692)+(65.842)+(52.222));
tcb->m_cWnd = (int) ((96.596*(64.959)*(60.191)*(55.087)*(77.937)*(19.483)*(segmentsAcked)*(tcb->m_segmentSize))/0.1);
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((50.445)+(0.1)+(0.1)+((64.684+(56.565)+(90.63)))+(0.1))/((89.648)+(81.283)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(20.026)+(80.678)+(segmentsAcked)+(43.642)+(71.58));
	tcb->m_cWnd = (int) (93.257*(tcb->m_ssThresh)*(70.951)*(88.366)*(tcb->m_segmentSize)*(23.525)*(44.635));
	segmentsAcked = (int) (1.054*(36.704)*(57.893)*(6.003)*(69.25)*(36.349)*(83.881));

}
