CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (0.1/99.261);
	segmentsAcked = (int) (41.912-(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (52.786+(2.057)+(49.562)+(49.918)+(16.548)+(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (23.969+(79.536)+(31.673)+(tcb->m_cWnd)+(53.444)+(38.592));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (10.694-(93.312)-(31.135)-(67.775));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) ((((80.597-(69.73)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(65.338)-(11.27)-(84.32)))+(94.579)+((segmentsAcked+(4.945)+(58.956)+(3.065)))+(0.1)+(0.1)+(0.1)+(30.157))/((0.1)+(94.316)));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	segmentsAcked = (int) (32.139*(3.193)*(81.094)*(58.217)*(74.334)*(29.838));
	tcb->m_cWnd = (int) (31.398+(7.953)+(77.125));

} else {
	segmentsAcked = (int) (((64.266)+(0.1)+(0.1)+(92.321)+(0.1)+(0.1)+(34.393))/((7.555)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (14.012-(tcb->m_segmentSize)-(65.479)-(28.371)-(tcb->m_cWnd)-(tcb->m_segmentSize));
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_ssThresh-(14.389));
	tcb->m_ssThresh = (int) ((11.914-(tcb->m_cWnd)-(80.523))/0.1);
	tcb->m_ssThresh = (int) ((((31.774+(20.931)+(68.596)+(69.008)+(tcb->m_segmentSize)))+(26.654)+(0.1)+(8.071)+(0.1))/((0.1)+(0.1)+(0.1)));

} else {
	segmentsAcked = (int) (9.235*(65.762)*(63.059)*(19.229));
	tcb->m_segmentSize = (int) (34.064+(63.544)+(57.377));

}
