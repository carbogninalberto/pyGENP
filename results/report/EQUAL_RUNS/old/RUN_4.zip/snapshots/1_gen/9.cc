ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (90.744+(46.758)+(77.058)+(54.993));
	tcb->m_cWnd = (int) (4.436-(69.394)-(87.241));

} else {
	tcb->m_ssThresh = (int) (81.266-(92.937)-(87.16)-(73.785)-(94.049)-(10.084)-(16.991));

}
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (45.448*(tcb->m_ssThresh)*(tcb->m_cWnd)*(98.5)*(tcb->m_segmentSize)*(32.487)*(42.154)*(70.332));
segmentsAcked = (int) (69.464-(15.362)-(48.495)-(tcb->m_cWnd));
