int GtghmtVbkgUQfieO = (int) (21.686+(57.989)+(-36.019)+(-91.64)+(-18.126)+(16.939));
tcb->m_segmentSize = (int) (-37.23*(65.97)*(2.381)*(71.433)*(36.548)*(76.286)*(81.782));
segmentsAcked = (int) (-51.168/-54.351);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (66.373*(-24.526)*(-62.772)*(-41.404)*(26.444));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
