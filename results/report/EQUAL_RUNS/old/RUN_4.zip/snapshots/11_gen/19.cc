ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-81.262+(-84.706)+(-51.73)+(-51.211)+(78.221));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-97.512+(-7.605)+(-99.045)+(-24.551)+(74.447)+(12.284));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
