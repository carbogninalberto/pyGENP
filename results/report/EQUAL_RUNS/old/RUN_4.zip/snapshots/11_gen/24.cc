float VJZiSDrMtqxlkapg = (float) (-70.054-(-31.645)-(46.364)-(24.885)-(31.724)-(24.343)-(-67.272)-(-27.312));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/78.251);
	tcb->m_segmentSize = (int) (31.926*(tcb->m_segmentSize)*(60.9));

} else {
	tcb->m_segmentSize = (int) (21.804+(97.997)+(VJZiSDrMtqxlkapg)+(tcb->m_segmentSize)+(-28.065)+(40.273)+(60.28));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (21.804+(97.997)+(VJZiSDrMtqxlkapg)+(tcb->m_segmentSize)+(-47.5)+(40.273)+(60.28));

} else {
	tcb->m_segmentSize = (int) (0.1/78.251);
	tcb->m_segmentSize = (int) (31.926*(tcb->m_segmentSize)*(60.9));

}
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (81.685-(26.968)-(segmentsAcked)-(35.673)-(1.03)-(45.369));
	tcb->m_cWnd = (int) (68.685+(69.751)+(-78.42)+(-45.395)+(74.247)+(47.944)+(7.86));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (96.416-(97.674)-(35.575)-(92.643)-(tcb->m_segmentSize)-(90.239)-(62.289)-(19.25)-(26.912));

}
