float lAYlKEAbjASWpvnh = (float) (((45.878)+(49.133)+((-83.844-(17.946)-(-74.217)-(-75.111)-(12.639)-(19.315)-(37.131)))+(-17.997)+((90.279-(18.888)-(-44.856)-(-75.193)-(92.138)-(-16.923)-(55.726)-(-12.625)-(-81.42)))+(-78.79))/((5.355)+(-55.648)+(-91.781)));
int YNKePzFZwtbIrZyc = (int) 7.347;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	lAYlKEAbjASWpvnh = (float) (0.789+(87.396)+(YNKePzFZwtbIrZyc)+(85.148)+(47.949)+(29.091)+(0.177)+(59.55)+(tcb->m_segmentSize));

} else {
	lAYlKEAbjASWpvnh = (float) (55.361*(22.045));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
