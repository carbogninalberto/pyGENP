segmentsAcked = SlowStart (tcb, segmentsAcked);
float POivovnAixoeJtAD = (float) (((0.1)+(20.358)+((29.777-(tcb->m_cWnd)-(24.576)-(segmentsAcked)-(31.303)-(80.161)-(tcb->m_ssThresh)-(39.496)))+(0.1))/((6.767)+(62.881)+(10.415)+(0.1)));
float KtBYDfmqaspMqcbC = (float) (74.08/0.1);
int NQNzUhSWTtBQuDXC = (int) (0.1/64.431);
if (POivovnAixoeJtAD >= segmentsAcked) {
	tcb->m_ssThresh = (int) (0.1/44.869);
	tcb->m_segmentSize = (int) (((79.374)+((25.884+(tcb->m_ssThresh)+(96.474)+(11.505)+(3.614)+(26.619)+(tcb->m_cWnd)+(35.22)+(20.143)))+(0.1)+(39.298)+((67.444+(51.569)))+(28.348)+(60.691))/((0.1)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
float qsKASSkBWDnBzWUy = (float) (69.085*(59.654)*(3.486));
if (KtBYDfmqaspMqcbC != POivovnAixoeJtAD) {
	qsKASSkBWDnBzWUy = (float) (KtBYDfmqaspMqcbC-(0.3)-(KtBYDfmqaspMqcbC)-(27.178)-(93.327));
	NQNzUhSWTtBQuDXC = (int) (KtBYDfmqaspMqcbC+(41.981)+(14.85)+(81.716)+(tcb->m_ssThresh));

} else {
	qsKASSkBWDnBzWUy = (float) (87.101+(88.779)+(KtBYDfmqaspMqcbC));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= POivovnAixoeJtAD) {
	KtBYDfmqaspMqcbC = (float) (21.312*(52.802)*(78.673)*(14.369)*(76.46));
	KtBYDfmqaspMqcbC = (float) (0.1/21.672);
	tcb->m_ssThresh = (int) (((72.03)+(21.49)+(0.1)+(0.1)+(64.199)+(0.1)+(22.316))/((0.1)));

} else {
	KtBYDfmqaspMqcbC = (float) (74.704-(NQNzUhSWTtBQuDXC)-(64.044)-(80.116)-(84.11)-(qsKASSkBWDnBzWUy)-(19.645)-(5.785)-(87.464));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
