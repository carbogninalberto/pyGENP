int UcuSsCrdtISTwcaJ = (int) (6.062*(25.44));
tcb->m_cWnd = (int) (0.1/88.713);
int WXMaeZmGsppvnTok = (int) (tcb->m_cWnd*(51.991)*(tcb->m_ssThresh));
float BQepkNVMklWWSoyc = (float) (31.832-(72.126)-(tcb->m_cWnd));
tcb->m_cWnd = (int) (UcuSsCrdtISTwcaJ-(79.322)-(84.318)-(WXMaeZmGsppvnTok));
segmentsAcked = SlowStart (tcb, segmentsAcked);
int QGFxxIHFrjMWNWWt = (int) (tcb->m_cWnd-(11.388));
UcuSsCrdtISTwcaJ = (int) (tcb->m_segmentSize-(44.506)-(WXMaeZmGsppvnTok)-(tcb->m_ssThresh));
