tcb->m_segmentSize = (int) (61.112*(tcb->m_segmentSize)*(67.563)*(tcb->m_segmentSize)*(32.226)*(67.382)*(tcb->m_segmentSize)*(25.929)*(4.059));
segmentsAcked = (int) (22.716-(61.285)-(70.714)-(21.89));
tcb->m_ssThresh = (int) (36.533-(10.74)-(75.778));
tcb->m_cWnd = (int) (91.65+(56.467)+(tcb->m_cWnd)+(36.918)+(44.2)+(8.602)+(77.173)+(58.11)+(tcb->m_segmentSize));
tcb->m_ssThresh = (int) (49.533+(9.611)+(59.344)+(89.61)+(18.318)+(47.871)+(71.887));
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (38.365-(tcb->m_cWnd)-(66.442)-(19.885)-(23.263));
	tcb->m_cWnd = (int) (1.169-(2.855)-(37.413)-(21.732)-(34.054)-(63.568)-(38.202)-(87.128));
	segmentsAcked = (int) (19.544*(20.909)*(57.002)*(42.882)*(tcb->m_cWnd)*(97.802)*(40.449));

} else {
	tcb->m_segmentSize = (int) (28.69*(62.561)*(84.354)*(75.728)*(36.474)*(85.855));
	tcb->m_ssThresh = (int) (57.016+(tcb->m_cWnd)+(89.514)+(61.014));
	tcb->m_segmentSize = (int) (67.447-(tcb->m_cWnd)-(56.119)-(18.05));

}
