if (tcb->m_ssThresh != tcb->m_cWnd) {
	segmentsAcked = (int) (48.772+(73.746)+(64.956)+(24.294)+(97.148)+(-0.029)+(33.698)+(90.127)+(78.784));
	tcb->m_cWnd = (int) (77.189/(84.847+(tcb->m_ssThresh)+(63.955)+(tcb->m_cWnd)+(tcb->m_cWnd)+(27.05)+(40.821)+(58.084)));

} else {
	segmentsAcked = (int) (64.686+(36.873)+(59.769)+(83.167)+(59.955)+(3.937)+(94.161)+(27.395)+(80.393));
	tcb->m_segmentSize = (int) (20.745*(19.363));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(18.568)-(51.216));

}
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(18.151)*(21.477)*(24.729)*(76.563)*(87.54)*(tcb->m_segmentSize)*(32.427)*(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) ((((81.755-(33.791)-(8.192)-(59.609)-(49.027)-(segmentsAcked)-(tcb->m_cWnd)))+(79.102)+(36.898)+(59.426))/((0.1)+(77.753)+(9.868)+(37.834)));
	tcb->m_cWnd = (int) (((47.436)+((tcb->m_cWnd+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(24.082)+(54.688)+(54.723)+(18.066)+(segmentsAcked)+(tcb->m_segmentSize)))+((tcb->m_segmentSize-(tcb->m_cWnd)-(29.822)))+(0.1)+(0.1)+(40.373))/((0.1)+(0.1)+(0.1)));

}
float tTYxwBqeBNmgyeZo = (float) (((0.1)+(0.1)+(96.622)+(0.1))/((0.1)+(54.261)+(0.1)+(60.557)));
segmentsAcked = (int) (55.783-(81.101)-(tcb->m_ssThresh)-(60.138)-(79.137)-(86.303)-(34.564));
tcb->m_segmentSize = (int) (0.1/0.1);
if (tcb->m_ssThresh < segmentsAcked) {
	tTYxwBqeBNmgyeZo = (float) (((50.178)+((segmentsAcked+(9.688)+(24.166)+(39.615)+(38.186)+(47.633)+(segmentsAcked)))+((58.541-(65.93)-(67.571)-(35.186)-(87.182)-(21.072)-(23.59)-(tcb->m_segmentSize)))+(92.824)+(16.342))/((21.579)+(0.1)));
	tcb->m_ssThresh = (int) (77.637-(58.582)-(tcb->m_ssThresh)-(63.031)-(60.995)-(segmentsAcked)-(tTYxwBqeBNmgyeZo)-(73.652)-(84.2));

} else {
	tTYxwBqeBNmgyeZo = (float) (80.366-(95.521)-(2.493)-(95.136)-(11.33)-(81.387));

}
