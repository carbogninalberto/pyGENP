int PnQtniVyrAIVJTED = (int) (((0.1)+(74.693)+(0.1)+((64.381+(58.262)+(66.92)+(45.302)))+(50.874)+(0.1))/((27.665)+(0.1)));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	PnQtniVyrAIVJTED = (int) (segmentsAcked-(83.334)-(PnQtniVyrAIVJTED)-(1.947)-(41.524)-(83.546));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	PnQtniVyrAIVJTED = (int) (32.254-(tcb->m_cWnd)-(26.92));

}
segmentsAcked = (int) (((0.1)+(0.1)+(10.987)+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));
PnQtniVyrAIVJTED = (int) (37.897-(54.512)-(37.779)-(21.672)-(PnQtniVyrAIVJTED)-(29.054)-(46.379)-(PnQtniVyrAIVJTED));
