TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (76.763-(63.005)-(-96.507)-(84.955)-(22.894));
tcb->m_segmentSize = (int) (55.712/52.151);
