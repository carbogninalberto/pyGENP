if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (19.929-(tcb->m_ssThresh)-(20.244)-(86.942)-(15.362)-(85.633)-(tcb->m_ssThresh)-(1.109)-(3.176));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(14.905)-(tcb->m_segmentSize)-(83.404));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (37.037*(13.017)*(39.825)*(segmentsAcked)*(22.704)*(74.708));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((71.991)+(28.098)+((55.248-(21.683)-(23.348)-(50.822)-(tcb->m_ssThresh)-(54.025)))+(12.892))/((0.1)+(0.1)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (0.1/0.1);
