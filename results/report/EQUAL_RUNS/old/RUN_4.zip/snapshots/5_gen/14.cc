int pTsjufRdeJBdfJNN = (int) (((-89.728)+(-42.979)+(11.883)+(-62.578))/((-82.407)));
float WYRpnjILAewGDJen = (float) (67.061*(17.831)*(99.007)*(95.543)*(98.49)*(-63.417));
float oDIIRLeElmNZPYxA = (float) (-54.079*(-6.747)*(50.032)*(-33.294)*(89.931)*(-18.017));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float tZRblbrpKcSHcity = (float) 23.311;
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-53.527*(33.108)*(68.135)*(88.766)*(30.314)*(-14.138));
tcb->m_cWnd = (int) (70.239+(-27.619)+(97.19));
if (tcb->m_segmentSize != tZRblbrpKcSHcity) {
	tcb->m_segmentSize = (int) (11.307-(86.539)-(67.927)-(83.776)-(12.671)-(79.901)-(tcb->m_cWnd)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(42.593)+(47.227)+(tZRblbrpKcSHcity)+(14.196)+(28.541));
	tZRblbrpKcSHcity = (float) (26.545+(34.521)+(80.091)+(57.671)+(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (-35.923*(-40.929)*(-51.859)*(-90.577)*(92.206)*(27.922)*(-7.181)*(-49.984));
tcb->m_cWnd = (int) (16.058*(75.546)*(22.257)*(-27.203)*(-73.822)*(-82.797)*(29.739)*(-88.369));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (69.247*(99.288)*(37.911)*(-39.782)*(70.484)*(-55.857));
if (tcb->m_segmentSize != tZRblbrpKcSHcity) {
	tcb->m_segmentSize = (int) (11.307-(86.539)-(67.927)-(83.776)-(12.671)-(79.901)-(tcb->m_cWnd)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(42.593)+(47.227)+(tZRblbrpKcSHcity)+(14.196)+(28.541));
	tZRblbrpKcSHcity = (float) (26.545+(34.521)+(80.091)+(57.671)+(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (25.028*(40.776)*(-43.034)*(44.659)*(78.076)*(-43.683)*(-48.122)*(-37.277));
