ReduceCwnd (tcb);
int pTsjufRdeJBdfJNN = (int) (((15.045)+(26.762)+(-33.714)+(96.5))/((-20.019)));
tcb->m_cWnd = (int) (-62.151+(20.631)+(64.524));
float WYRpnjILAewGDJen = (float) (-46.336*(-38.202)*(63.939)*(-73.753)*(-59.13)*(98.233));
tcb->m_cWnd = (int) (-23.013*(-22.578)*(68.337)*(-45.867)*(86.262)*(-94.11)*(-82.105)*(-39.343));
float oDIIRLeElmNZPYxA = (float) (-18.471*(-67.27)*(70.363)*(90.322)*(-19.439)*(-29.128));
ReduceCwnd (tcb);
float tZRblbrpKcSHcity = (float) 35.121;
tcb->m_segmentSize = (int) (-22.578*(-13.248)*(-16.47)*(-73.426)*(52.397)*(-7.493));
if (tcb->m_segmentSize != tZRblbrpKcSHcity) {
	tcb->m_segmentSize = (int) (11.307-(86.539)-(67.927)-(83.776)-(12.671)-(79.901)-(tcb->m_cWnd)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(42.593)+(47.227)+(tZRblbrpKcSHcity)+(14.196)+(28.541));
	tZRblbrpKcSHcity = (float) (26.545+(34.521)+(80.091)+(57.671)+(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (-21.195*(-74.527)*(-23.94)*(-78.923)*(-9.815)*(69.378)*(-25.94)*(-76.468));
