TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float zgCojkvoeRqJjcOV = (float) (63.923+(3.923)+(-16.999)+(87.721)+(-99.048)+(16.975)+(59.711)+(-44.228)+(-13.229));
tcb->m_cWnd = (int) (-7.547*(-74.849)*(48.014)*(31.233));
float MMTFoxHGjHEbhhBu = (float) (-59.253*(78.847)*(-64.738)*(-3.66)*(88.29)*(-72.105)*(-71.331)*(-37.231)*(35.553));
ReduceCwnd (tcb);
zgCojkvoeRqJjcOV = (float) ((23.157-(tcb->m_cWnd)-(66.681)-(tcb->m_cWnd)-(-38.83)-(12.032)-(tcb->m_segmentSize))/-53.127);
