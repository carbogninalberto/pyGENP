tcb->m_segmentSize = (int) (55.981/-85.681);
segmentsAcked = (int) (84.558-(81.091)-(28.697)-(35.681));
