if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (32.152-(11.947));

} else {
	tcb->m_cWnd = (int) (16.172+(55.112)+(31.51));
	segmentsAcked = (int) (((27.486)+(70.476)+(0.1)+(42.987)+(97.189)+(0.1)+(86.281))/((0.1)));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(20.937)+(30.83)+(12.338)+(tcb->m_segmentSize)+(segmentsAcked)+(tcb->m_segmentSize)+(20.456)+(51.958));

}
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (89.38+(53.97)+(24.578));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(tcb->m_ssThresh)-(70.825)-(17.127)-(21.282)-(32.991));

}
tcb->m_cWnd = (int) (96.776-(42.518));
if (segmentsAcked >= segmentsAcked) {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+((46.458*(36.173)*(segmentsAcked)*(segmentsAcked)*(92.104)*(tcb->m_ssThresh)))+(8.219)+(0.1))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (4.956+(46.118)+(92.958)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(80.475)+(1.42)+(tcb->m_segmentSize)+(67.403));
	tcb->m_cWnd = (int) (((0.1)+(31.718)+((tcb->m_segmentSize*(tcb->m_cWnd)*(10.161)*(58.027)*(tcb->m_segmentSize)*(75.281)*(20.708)*(63.167)))+(13.403))/((0.1)+(81.576)+(0.1)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
