float iSjzAWQrkWIDbzSh = (float) ((22.973*(-41.253)*(-74.802)*(53.911)*(97.7)*(-50.965))/94.775);
ReduceCwnd (tcb);
segmentsAcked = (int) (21.596*(97.223)*(-14.122));
CongestionAvoidance (tcb, segmentsAcked);
