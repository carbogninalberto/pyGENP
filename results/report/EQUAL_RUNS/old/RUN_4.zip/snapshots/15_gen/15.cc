int fQjqxicduoeAVmXX = (int) 61.689;
