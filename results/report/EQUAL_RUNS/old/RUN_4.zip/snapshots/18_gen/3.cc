float MMTFoxHGjHEbhhBu = (float) (35.611*(98.45)*(76.841)*(78.328)*(24.523)*(-27.241)*(45.234)*(-78.77)*(91.207));
float zgCojkvoeRqJjcOV = (float) (-3.898+(-17.567)+(-20.783)+(-10.732)+(83.075)+(26.942)+(80.725)+(-63.098)+(-58.659));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (26.868*(64.143)*(-11.531)*(26.946));
ReduceCwnd (tcb);
zgCojkvoeRqJjcOV = (float) ((1.774-(tcb->m_cWnd)-(16.854)-(tcb->m_cWnd)-(-8.317)-(80.095)-(tcb->m_segmentSize))/13.192);
