TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float zgCojkvoeRqJjcOV = (float) (43.531+(-86.029)+(-54.98)+(-61.221)+(6.472)+(36.275)+(41.685)+(83.791)+(-74.398));
tcb->m_cWnd = (int) (48.2*(32.642)*(74.2)*(12.61));
float MMTFoxHGjHEbhhBu = (float) (-10.614*(80.09)*(-54.648)*(-68.088)*(-9.862)*(72.88)*(-47.968)*(-76.671)*(6.683));
ReduceCwnd (tcb);
zgCojkvoeRqJjcOV = (float) ((1.234-(tcb->m_cWnd)-(83.562)-(tcb->m_cWnd)-(-53.99)-(37.7)-(tcb->m_segmentSize))/86.307);
zgCojkvoeRqJjcOV = (float) ((-70.152-(tcb->m_cWnd)-(-55.208)-(tcb->m_cWnd)-(-15.929)-(4.726)-(tcb->m_segmentSize))/-27.466);
