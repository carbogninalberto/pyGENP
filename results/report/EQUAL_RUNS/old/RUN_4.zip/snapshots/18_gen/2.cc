TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float zgCojkvoeRqJjcOV = (float) (20.62+(3.747)+(-77.518)+(-8.874)+(-89.871)+(34.972)+(-74.955)+(-98.157)+(-46.196));
tcb->m_cWnd = (int) (-40.352*(-23.296)*(77.974)*(88.134));
float MMTFoxHGjHEbhhBu = (float) (-68.519*(-76.598)*(-56.787)*(-20.793)*(14.539)*(47.577)*(98.574)*(-89.556)*(62.506));
tcb->m_cWnd = (int) (-5.86*(-70.087)*(-43.925)*(-49.966));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
zgCojkvoeRqJjcOV = (float) ((-6.76-(tcb->m_cWnd)-(-90.778)-(tcb->m_cWnd)-(91.205)-(-20.771)-(tcb->m_segmentSize))/19.128);
zgCojkvoeRqJjcOV = (float) ((68.113-(tcb->m_cWnd)-(69.564)-(tcb->m_cWnd)-(-84.276)-(98.666)-(tcb->m_segmentSize))/-54.026);
