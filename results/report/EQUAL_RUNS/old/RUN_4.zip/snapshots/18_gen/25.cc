ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
float IdEcduRgJeQEtYTK = (float) (65.907+(36.151)+(tcb->m_segmentSize)+(0.368)+(25.759));
float JmTGXJoOZiicICkg = (float) (((0.1)+(43.15)+(86.722)+(0.1)+(81.235))/((75.51)));
