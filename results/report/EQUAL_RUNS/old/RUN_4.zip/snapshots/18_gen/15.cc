int uSwPqosyyyKrdGvk = (int) (0.1/0.1);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	uSwPqosyyyKrdGvk = (int) (78.555-(72.719)-(77.486)-(19.334)-(79.939)-(10.552));
	tcb->m_segmentSize = (int) (2.144-(74.576)-(0.265));

} else {
	uSwPqosyyyKrdGvk = (int) (96.899+(65.452)+(39.811)+(2.86)+(8.516)+(36.116)+(23.486)+(19.407));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (7.515-(56.407)-(tcb->m_ssThresh));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (0.1/13.598);
if (tcb->m_segmentSize <= segmentsAcked) {
	segmentsAcked = (int) ((((11.171*(tcb->m_segmentSize)*(56.791)*(27.237)*(93.483)*(13.171)))+(31.197)+(4.501)+(0.1)+(0.1)+(0.1)+(54.063)+(0.1))/((0.1)));
	segmentsAcked = (int) ((tcb->m_segmentSize+(27.693))/60.998);

} else {
	segmentsAcked = (int) (((0.1)+((83.091-(25.683)-(tcb->m_ssThresh)))+((64.332+(14.163)+(86.969)+(42.238)))+(0.1)+(0.1))/((0.1)+(33.029)+(66.588)));

}
uSwPqosyyyKrdGvk = (int) (57.943-(48.454)-(4.364)-(uSwPqosyyyKrdGvk));
tcb->m_ssThresh = (int) (((34.691)+(7.766)+(0.1)+((47.056*(segmentsAcked)*(tcb->m_cWnd)*(11.776)*(93.792)*(74.678)*(48.623)))+(40.615)+(0.1))/((0.1)));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	uSwPqosyyyKrdGvk = (int) ((((88.152-(segmentsAcked)-(59.475)-(7.216)))+(0.1)+(0.1)+(99.927)+(63.301))/((0.1)));
	tcb->m_cWnd = (int) (12.759-(78.873)-(1.635)-(17.362)-(88.631)-(uSwPqosyyyKrdGvk)-(2.369)-(97.87)-(89.574));
	segmentsAcked = (int) (41.009*(92.434)*(89.169)*(61.395)*(25.865)*(uSwPqosyyyKrdGvk)*(tcb->m_ssThresh));

} else {
	uSwPqosyyyKrdGvk = (int) (33.163-(35.885)-(83.257)-(uSwPqosyyyKrdGvk)-(83.755)-(4.546)-(80.887)-(78.483));

}
