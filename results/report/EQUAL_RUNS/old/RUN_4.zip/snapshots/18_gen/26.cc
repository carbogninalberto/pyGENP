ReduceCwnd (tcb);
int BkToJPceZlNUCyFz = (int) (7.048+(87.33)+(77.74)+(segmentsAcked)+(14.214)+(67.404)+(21.315));
segmentsAcked = (int) (29.905*(11.846)*(segmentsAcked)*(35.352)*(18.711)*(tcb->m_segmentSize)*(16.043)*(26.063));
BkToJPceZlNUCyFz = (int) (80.36-(tcb->m_ssThresh));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (61.75+(tcb->m_ssThresh));
tcb->m_cWnd = (int) (10.497-(tcb->m_ssThresh)-(53.988)-(78.782));
