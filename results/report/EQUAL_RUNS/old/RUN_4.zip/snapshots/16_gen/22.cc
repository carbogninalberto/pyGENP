tcb->m_ssThresh = (int) (93.263*(tcb->m_cWnd)*(5.004)*(31.143)*(98.254)*(tcb->m_cWnd));
ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((0.1)+((segmentsAcked-(98.743)-(81.285)-(32.854)-(46.034)-(tcb->m_ssThresh)))+(27.75)+(0.1)+(0.1)+(0.1)+(0.1))/((38.014)));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (30.216*(tcb->m_ssThresh)*(81.735)*(92.472)*(11.705)*(1.373));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(77.74)-(87.138)-(29.311)-(36.722)-(5.298)-(47.11)-(70.94));
	CongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (25.249-(70.023)-(segmentsAcked)-(79.408)-(tcb->m_ssThresh)-(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (44.93-(76.175)-(57.275)-(tcb->m_ssThresh)-(6.919)-(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (27.365+(1.22)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(84.9)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(72.934));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (29.152-(31.559)-(83.662)-(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (88.221-(tcb->m_cWnd)-(5.848)-(80.791)-(tcb->m_ssThresh)-(48.595)-(50.023));
	tcb->m_cWnd = (int) (81.136-(26.729)-(38.719)-(70.23)-(5.722)-(tcb->m_cWnd)-(89.137));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
