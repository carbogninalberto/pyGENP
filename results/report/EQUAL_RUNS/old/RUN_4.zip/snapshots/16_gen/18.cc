tcb->m_ssThresh = (int) (21.345+(91.15));
tcb->m_cWnd = (int) (70.525+(52.793)+(23.958)+(segmentsAcked)+(99.064)+(40.976)+(tcb->m_segmentSize)+(19.358)+(13.709));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (8.387/0.1);
