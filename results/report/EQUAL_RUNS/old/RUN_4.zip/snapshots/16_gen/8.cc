ReduceCwnd (tcb);
float iSjzAWQrkWIDbzSh = (float) ((-19.116*(21.536)*(60.93)*(-11.766)*(-91.929)*(-76.472))/-17.941);
segmentsAcked = (int) (-57.662*(11.898)*(-48.853));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
