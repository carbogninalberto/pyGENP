TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-92.346*(-79.294)*(67.539)*(4.413));
float zgCojkvoeRqJjcOV = (float) (-31.345+(-44.435)+(92.204)+(-52.239)+(16.275)+(7.728)+(7.906)+(-54.899)+(-33.268));
ReduceCwnd (tcb);
float MMTFoxHGjHEbhhBu = (float) (25.418*(-6.771)*(-34.667)*(-61.629)*(-23.404)*(67.954)*(56.649)*(-6.452)*(19.696));
zgCojkvoeRqJjcOV = (float) ((26.593-(tcb->m_cWnd)-(9.194)-(tcb->m_cWnd)-(-55.894)-(25.461)-(tcb->m_segmentSize))/-74.031);
