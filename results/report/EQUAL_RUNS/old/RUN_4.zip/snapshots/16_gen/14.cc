tcb->m_segmentSize = (int) (73.216-(19.007));
ReduceCwnd (tcb);
if (segmentsAcked > segmentsAcked) {
	tcb->m_ssThresh = (int) (93.496*(tcb->m_cWnd)*(83.303)*(31.779)*(22.485)*(segmentsAcked));
	segmentsAcked = (int) (59.846*(53.243)*(tcb->m_segmentSize)*(91.036)*(57.72)*(80.751)*(80.597));

} else {
	tcb->m_ssThresh = (int) (((37.267)+(70.013)+(27.716)+((66.868-(16.003)-(5.23)-(tcb->m_ssThresh)))+(0.1))/((0.1)+(0.1)));
	tcb->m_ssThresh = (int) (47.745/93.24);

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (segmentsAcked+(tcb->m_cWnd)+(64.698)+(34.051)+(tcb->m_ssThresh)+(98.163)+(26.492)+(91.617));
	tcb->m_cWnd = (int) (76.001*(48.415)*(36.591));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (49.077+(15.473));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
