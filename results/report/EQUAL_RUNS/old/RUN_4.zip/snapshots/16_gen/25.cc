tcb->m_cWnd = (int) (tcb->m_cWnd-(24.997)-(48.068)-(82.346));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (0.1/36.183);
if (segmentsAcked < segmentsAcked) {
	tcb->m_segmentSize = (int) ((94.372-(tcb->m_ssThresh)-(76.828)-(37.033)-(98.377)-(2.897)-(1.734)-(91.404))/0.1);

} else {
	tcb->m_segmentSize = (int) (13.936+(tcb->m_segmentSize)+(3.146));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (61.479+(tcb->m_segmentSize)+(65.216)+(58.138)+(18.981));
