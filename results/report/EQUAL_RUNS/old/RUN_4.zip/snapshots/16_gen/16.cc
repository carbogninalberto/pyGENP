tcb->m_cWnd = (int) (63.145+(13.621)+(43.965)+(74.762)+(60.274)+(3.53)+(41.036)+(1.533)+(42.313));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (97.059/67.032);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (((11.597)+((33.932*(69.407)*(35.509)*(75.589)))+(0.1)+(99.788)+((78.202+(89.09)+(35.301)+(73.623)+(46.799)))+(0.1)+((17.204+(76.137)+(tcb->m_segmentSize)+(6.282)+(37.659)+(25.853)+(34.18)+(tcb->m_segmentSize)+(42.463)))+(70.653))/((66.329)));

} else {
	tcb->m_segmentSize = (int) (46.059+(80.597)+(41.875)+(89.437)+(9.965)+(tcb->m_cWnd)+(71.677)+(16.8));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (19.293-(41.645)-(58.818)-(47.491)-(46.521)-(71.739));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (tcb->m_segmentSize+(31.895)+(1.133)+(46.661));
ReduceCwnd (tcb);
