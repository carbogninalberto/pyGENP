TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float zgCojkvoeRqJjcOV = (float) (-32.217+(-56.935)+(-59.058)+(-23.979)+(-83.685)+(66.617)+(56.036)+(63.822)+(88.702));
tcb->m_cWnd = (int) (70.204*(-22.688)*(-32.899)*(-51.257));
float MMTFoxHGjHEbhhBu = (float) (94.911*(76.981)*(71.117)*(-14.736)*(81.196)*(-23.188)*(-60.036)*(-43.998)*(-80.128));
ReduceCwnd (tcb);
zgCojkvoeRqJjcOV = (float) ((33.048-(tcb->m_cWnd)-(95.815)-(tcb->m_cWnd)-(-64.245)-(-10.217)-(tcb->m_segmentSize))/80.692);
