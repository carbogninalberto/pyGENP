tcb->m_cWnd = (int) (92.36+(49.35)+(1.944)+(60.488)+(23.54)+(59.387)+(44.667)+(25.331));
int akkfBmYYtkphlrht = (int) (tcb->m_cWnd+(74.036)+(10.497)+(6.565)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(32.09)+(39.091));
int qhJEBlLsrvZQXZaG = (int) (((0.1)+((36.78+(86.254)+(87.933)+(46.67)+(62.103)+(16.955)+(tcb->m_segmentSize)))+((68.123+(tcb->m_segmentSize)+(53.727)))+((54.139-(6.859)))+(0.1))/((0.1)+(0.1)+(5.992)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (qhJEBlLsrvZQXZaG >= tcb->m_segmentSize) {
	segmentsAcked = (int) (80.82*(41.663)*(80.903)*(10.353)*(91.92)*(30.182)*(qhJEBlLsrvZQXZaG));

} else {
	segmentsAcked = (int) (56.158-(47.552)-(84.557)-(78.925)-(tcb->m_ssThresh));
	segmentsAcked = (int) (tcb->m_cWnd*(28.14)*(segmentsAcked)*(69.786)*(48.874));

}
