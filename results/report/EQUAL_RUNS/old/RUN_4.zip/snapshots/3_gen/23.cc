float ONTvAcFXWSHrMHMP = (float) (8.815-(-77.432)-(-67.949)-(95.617)-(-30.013));
float blrBZtFhcrHxiuGU = (float) (-79.517-(50.024));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
