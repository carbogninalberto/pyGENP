segmentsAcked = SlowStart (tcb, segmentsAcked);
float ONTvAcFXWSHrMHMP = (float) (-91.742-(56.183)-(-76.935)-(-79.128)-(26.219));
CongestionAvoidance (tcb, segmentsAcked);
float DvllrNAeVCaAIOVH = (float) (3.677+(71.121)+(5.154)+(-16.147)+(-53.751)+(65.08)+(-52.74));
CongestionAvoidance (tcb, segmentsAcked);
