CongestionAvoidance (tcb, segmentsAcked);
int IdOKtdeHVRrUognE = (int) (((5.635)+(31.871)+(-69.509)+(-2.179))/((13.088)+(-61.94)+(57.277)));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
