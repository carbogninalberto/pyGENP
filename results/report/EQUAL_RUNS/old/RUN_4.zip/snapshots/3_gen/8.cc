float hzBtDGfLzQuwZeDY = (float) 97.045;
int pTsjufRdeJBdfJNN = (int) (((83.155)+(-78.024)+(76.292)+(60.98))/((5.988)));
float WYRpnjILAewGDJen = (float) (44.935*(-12.518)*(4.214)*(82.142)*(22.113)*(79.435));
float oDIIRLeElmNZPYxA = (float) (-63.364*(43.668)*(36.901)*(-97.334)*(-11.684)*(-16.472));
tcb->m_cWnd = (int) (-96.512+(43.406)+(9.121));
float tZRblbrpKcSHcity = (float) 35.121;
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (9.332*(-98.609)*(-99.747)*(-43.113)*(82.624)*(-10.418));
if (tcb->m_segmentSize != tZRblbrpKcSHcity) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(42.593)+(47.227)+(tZRblbrpKcSHcity)+(14.196)+(28.541));
	tZRblbrpKcSHcity = (float) (26.545+(34.521)+(80.091)+(57.671)+(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (11.307-(86.539)-(67.927)-(83.776)-(12.671)-(79.901)-(tcb->m_cWnd)-(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (-35.811*(75.428)*(-71.937)*(1.205)*(75.768)*(73.274)*(78.77)*(88.286));
