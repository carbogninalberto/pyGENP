int BAIgYBODbUISDind = (int) 66.64;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-0.611-(-0.473)-(31.607)-(-46.252)-(-29.476)-(-79.003)-(58.002));
ReduceCwnd (tcb);
if (tcb->m_cWnd > BAIgYBODbUISDind) {
	segmentsAcked = (int) (51.614+(35.442)+(10.233)+(94.845)+(46.506)+(42.213)+(31.316));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (46.021-(79.294));

} else {
	segmentsAcked = (int) (42.048*(tcb->m_segmentSize)*(35.186)*(86.857)*(20.104));
	tcb->m_segmentSize = (int) (79.782*(82.048)*(41.204)*(45.059)*(segmentsAcked)*(67.663));

}
tcb->m_segmentSize = (int) (-66.763-(24.392)-(-99.467)-(-28.757)-(45.652)-(-74.946)-(72.183));
ReduceCwnd (tcb);
if (tcb->m_cWnd > BAIgYBODbUISDind) {
	segmentsAcked = (int) (51.614+(35.442)+(10.233)+(94.845)+(46.506)+(42.213)+(31.316));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (46.021-(79.294));

} else {
	segmentsAcked = (int) (42.048*(tcb->m_segmentSize)*(35.186)*(86.857)*(20.104));
	tcb->m_segmentSize = (int) (79.782*(82.048)*(41.204)*(45.059)*(segmentsAcked)*(67.663));

}
