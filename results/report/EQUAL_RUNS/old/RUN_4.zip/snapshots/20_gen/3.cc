float MMTFoxHGjHEbhhBu = (float) (12.313*(-30.673)*(-68.638)*(-16.271)*(-1.88)*(78.169)*(-51.788)*(1.436)*(-68.436));
float zgCojkvoeRqJjcOV = (float) (80.688+(39.616)+(-99.797)+(14.6)+(-15.492)+(-85.137)+(60.138)+(-65.482)+(-26.83));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-83.599*(48.544)*(36.285)*(-9.48));
ReduceCwnd (tcb);
zgCojkvoeRqJjcOV = (float) ((-2.67-(tcb->m_cWnd)-(-15.379)-(tcb->m_cWnd)-(14.128)-(-71.831)-(tcb->m_segmentSize))/-94.153);
