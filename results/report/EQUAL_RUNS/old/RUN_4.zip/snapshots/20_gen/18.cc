segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
int FvOpBACAIHfmkDnP = (int) (4.946*(44.965)*(39.146)*(64.902)*(4.677)*(tcb->m_ssThresh)*(63.796)*(68.72));
if (tcb->m_cWnd >= segmentsAcked) {
	FvOpBACAIHfmkDnP = (int) (segmentsAcked+(84.626)+(87.662)+(tcb->m_segmentSize)+(73.233)+(tcb->m_ssThresh)+(69.833)+(5.613)+(1.219));

} else {
	FvOpBACAIHfmkDnP = (int) (46.877*(33.634)*(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(61.951))/((26.074)+(94.986)+(85.767)));

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	segmentsAcked = (int) ((46.035+(50.142)+(56.038)+(81.293)+(6.384)+(75.747)+(tcb->m_segmentSize))/69.16);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (33.893+(FvOpBACAIHfmkDnP)+(4.38)+(29.48)+(95.389)+(15.788)+(77.893)+(94.908)+(tcb->m_cWnd));
	tcb->m_cWnd = (int) ((((33.804-(12.273)-(13.777)-(25.757)-(68.255)-(62.575)-(tcb->m_segmentSize)-(78.475)))+((6.555-(70.887)-(FvOpBACAIHfmkDnP)))+(43.64)+(0.1)+(0.1))/((0.1)+(0.1)));

}
