tcb->m_segmentSize = (int) (25.767/31.981);
ReduceCwnd (tcb);
segmentsAcked = (int) (-76.332-(-34.646)-(98.221)-(-21.277)-(60.11));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
