if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (16.569+(9.32)+(87.108)+(18.533)+(33.324)+(21.425));

} else {
	tcb->m_segmentSize = (int) (38.885-(88.165)-(segmentsAcked)-(7.829)-(24.901)-(50.389)-(segmentsAcked));
	tcb->m_ssThresh = (int) (40.107-(78.836)-(tcb->m_cWnd)-(20.76)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(2.002)-(segmentsAcked)-(74.046));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (92.991+(segmentsAcked)+(55.166)+(66.383)+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (92.782+(26.089)+(95.521)+(93.858)+(97.061)+(74.425)+(62.484)+(94.672));
tcb->m_segmentSize = (int) (26.361+(33.522)+(13.836)+(5.803)+(14.009)+(tcb->m_ssThresh)+(tcb->m_ssThresh));
tcb->m_ssThresh = (int) (33.6*(9.099)*(68.676)*(61.796)*(92.995)*(71.344)*(22.985)*(94.974)*(99.809));
