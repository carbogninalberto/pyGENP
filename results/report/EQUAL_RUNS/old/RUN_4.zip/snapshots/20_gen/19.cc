segmentsAcked = (int) (50.133-(46.042));
tcb->m_cWnd = (int) (82.318-(tcb->m_segmentSize)-(92.094)-(segmentsAcked));
tcb->m_ssThresh = (int) (54.662-(84.096)-(90.861)-(94.281)-(60.23));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_ssThresh = (int) (39.606+(36.633)+(tcb->m_cWnd)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (57.371*(tcb->m_segmentSize)*(tcb->m_cWnd)*(93.907)*(69.057)*(tcb->m_cWnd)*(87.984)*(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (71.413-(66.234)-(93.33));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (39.185/0.1);
float YdVIvPCDnTglCnkX = (float) (94.737*(tcb->m_segmentSize)*(26.12)*(tcb->m_cWnd));
segmentsAcked = (int) ((((7.006-(34.805)-(62.595)-(28.236)))+((tcb->m_cWnd+(97.815)+(92.884)+(YdVIvPCDnTglCnkX)+(tcb->m_cWnd)+(91.167)+(9.313)))+(67.77)+(0.1))/((0.1)+(12.517)+(4.133)+(0.1)+(0.1)));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
