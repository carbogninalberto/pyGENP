float MMTFoxHGjHEbhhBu = (float) (-66.737*(90.684)*(-30.09)*(-12.069)*(13.17)*(-3.795)*(-93.101)*(50.351)*(-24.258));
float zgCojkvoeRqJjcOV = (float) (10.019+(-36.341)+(-67.699)+(89.061)+(-43.951)+(-89.287)+(48.452)+(14.225)+(45.91));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (73.247*(-33.179)*(-70.746)*(11.161));
ReduceCwnd (tcb);
zgCojkvoeRqJjcOV = (float) ((76.815-(tcb->m_cWnd)-(29.335)-(tcb->m_cWnd)-(95.935)-(42.246)-(tcb->m_segmentSize))/13.788);
tcb->m_cWnd = (int) (-11.361*(97.838)*(-62.941)*(0.635));
ReduceCwnd (tcb);
zgCojkvoeRqJjcOV = (float) ((-35.467-(tcb->m_cWnd)-(-62.232)-(tcb->m_cWnd)-(-90.511)-(-59.566)-(tcb->m_segmentSize))/83.09);
