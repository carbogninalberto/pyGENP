TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (63.084+(8.544)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (0.1/82.34);
	tcb->m_cWnd = (int) (23.076*(32.48)*(tcb->m_cWnd)*(93.889));

}
