TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float zgCojkvoeRqJjcOV = (float) (11.608+(-5.323)+(24.52)+(-71.601)+(-69.495)+(-17.339)+(29.022)+(-88.287)+(9.523));
tcb->m_cWnd = (int) (-94.832*(50.772)*(95.181)*(-80.498));
float MMTFoxHGjHEbhhBu = (float) (-35.141*(98.176)*(51.811)*(12.518)*(4.082)*(-92.229)*(25.214)*(-61.399)*(-78.587));
ReduceCwnd (tcb);
zgCojkvoeRqJjcOV = (float) ((-40.446-(tcb->m_cWnd)-(-29.929)-(tcb->m_cWnd)-(28.422)-(-57.153)-(tcb->m_segmentSize))/-57.396);
zgCojkvoeRqJjcOV = (float) ((73.496-(tcb->m_cWnd)-(-49.703)-(tcb->m_cWnd)-(29.097)-(-87.7)-(tcb->m_segmentSize))/-38.955);
