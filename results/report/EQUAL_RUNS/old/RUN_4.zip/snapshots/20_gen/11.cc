int lSTvLxCVRYnriXmJ = (int) (22.424-(50.736)-(28.254));
float YRvyZpQMpIPQummy = (float) (-61.753/-13.997);
tcb->m_segmentSize = (int) (-74.752*(12.89)*(-52.323)*(56.355)*(98.953));
tcb->m_cWnd = (int) (-32.189-(34.362)-(-73.36)-(50.564)-(0.433));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
YRvyZpQMpIPQummy = (float) (64.119+(27.903)+(-10.24)+(38.97)+(-21.883));
CongestionAvoidance (tcb, segmentsAcked);
YRvyZpQMpIPQummy = (float) (53.988+(-10.577)+(-24.832)+(-57.514)+(54.723));
