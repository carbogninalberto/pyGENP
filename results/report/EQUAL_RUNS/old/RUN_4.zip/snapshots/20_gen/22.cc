tcb->m_segmentSize = (int) (20.535/17.985);
int IgOHdkkxyOnblSNp = (int) (33.116/0.1);
tcb->m_ssThresh = (int) (61.609-(12.113)-(segmentsAcked)-(29.476));
int dtszYuoPBUADKkzg = (int) (75.143-(53.764)-(32.144)-(92.594)-(IgOHdkkxyOnblSNp)-(29.345)-(93.884));
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((34.631)+(0.1)+(0.1)+(0.1)+(60.76)+(0.1)+(45.313))/((3.415)+(19.745)));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (83.244+(10.987)+(99.225)+(tcb->m_segmentSize)+(43.638)+(77.322));
	segmentsAcked = (int) (tcb->m_cWnd+(5.841)+(38.206));

}
if (IgOHdkkxyOnblSNp == IgOHdkkxyOnblSNp) {
	tcb->m_ssThresh = (int) (IgOHdkkxyOnblSNp-(dtszYuoPBUADKkzg)-(98.701)-(tcb->m_cWnd)-(99.932)-(97.67)-(56.922));

} else {
	tcb->m_ssThresh = (int) (20.425*(tcb->m_ssThresh)*(18.989)*(segmentsAcked));

}
