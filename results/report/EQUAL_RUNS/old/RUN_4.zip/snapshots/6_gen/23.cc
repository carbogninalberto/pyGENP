float MMTFoxHGjHEbhhBu = (float) (49.954*(-27.407)*(-79.947)*(-44.279)*(78.789)*(-8.804)*(51.118)*(-75.392)*(-56.615));
float zgCojkvoeRqJjcOV = (float) (56.319+(-28.119)+(-2.925)+(28.814)+(85.386)+(-97.032)+(86.713)+(-28.85)+(-17.405));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-17.499*(50.023)*(87.59)*(-93.078));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
zgCojkvoeRqJjcOV = (float) ((36.623-(tcb->m_cWnd)-(16.138)-(tcb->m_cWnd)-(-75.099)-(-47.73)-(tcb->m_segmentSize))/91.762);
zgCojkvoeRqJjcOV = (float) ((10.743-(tcb->m_cWnd)-(26.119)-(tcb->m_cWnd)-(-65.932)-(98.335)-(tcb->m_segmentSize))/-90.626);
