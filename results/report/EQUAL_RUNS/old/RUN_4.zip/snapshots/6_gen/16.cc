int nKcqHOCIskOHfYhs = (int) (14.181-(-82.204)-(17.919)-(-37.929)-(-16.447)-(73.609)-(-68.883)-(82.542));
float gjHyIdGuLrHurwyP = (float) (-1.272*(-23.808));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) (((0.1)+(0.1)+(68.752)+(83.236)+(49.211))/((0.1)+(33.207)+(0.1)+(18.08)));
	segmentsAcked = (int) (((0.1)+(0.1)+(65.805)+(0.1))/((18.304)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (74.398*(segmentsAcked)*(3.059)*(15.469)*(segmentsAcked)*(0.181)*(30.269));

}
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
