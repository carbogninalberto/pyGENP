int PnQtniVyrAIVJTED = (int) 67.974;
CongestionAvoidance (tcb, segmentsAcked);
