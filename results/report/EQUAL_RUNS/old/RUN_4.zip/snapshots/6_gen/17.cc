float DqCrQKyewfCCmTBX = (float) (-61.736*(-27.114)*(-24.814)*(-60.179)*(15.9)*(48.898)*(30.364)*(-77.151));
float JXVmhNhsmZsmFaBm = (float) (71.221*(69.467)*(-84.173)*(90.573)*(14.653)*(34.792)*(53.436)*(45.936));
DqCrQKyewfCCmTBX = (float) (44.787*(22.447)*(4.844)*(-28.153)*(-17.183)*(-97.969));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
