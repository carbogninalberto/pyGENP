segmentsAcked = (int) (68.492/12.274);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_ssThresh-(27.893)-(23.907));
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (63.75+(26.338)+(44.954)+(73.961)+(81.598)+(tcb->m_ssThresh)+(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (82.337*(84.342)*(1.787)*(tcb->m_cWnd)*(96.898)*(tcb->m_cWnd)*(71.278)*(17.949)*(10.338));

}
tcb->m_cWnd = (int) (tcb->m_cWnd+(tcb->m_cWnd)+(28.882)+(49.938)+(29.76)+(59.374)+(44.074));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
