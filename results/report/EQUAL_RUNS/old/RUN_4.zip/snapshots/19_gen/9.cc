int BkToJPceZlNUCyFz = (int) (73.434+(3.208)+(-88.27)+(-75.601)+(-16.511)+(71.008)+(-58.026));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-65.474*(-79.481)*(22.8)*(-67.929)*(-28.904)*(33.913)*(53.649)*(-62.659));
BkToJPceZlNUCyFz = (int) (-78.877-(-55.078));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-53.376+(-33.375));
tcb->m_cWnd = (int) (58.849-(87.94)-(-6.767)-(16.204));
