float QoKcAMWINCEnJjYX = (float) (5.353+(97.981)+(-70.921)+(26.052)+(-47.285));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (5.832-(-0.57)-(12.539)-(-22.095)-(-30.2));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
