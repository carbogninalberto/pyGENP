CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (98.288*(10.991)*(78.016)*(25.936));
segmentsAcked = (int) ((46.556*(tcb->m_cWnd)*(tcb->m_cWnd)*(85.407)*(14.17))/51.44);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int YYmNkkAZZlEbAySU = (int) (0.1/0.1);
