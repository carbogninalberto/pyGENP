tcb->m_cWnd = (int) (10.191-(22.763));
tcb->m_cWnd = (int) (63.03+(15.374)+(61.413)+(42.67)+(12.618));
float myGdgfYOkizBKESr = (float) (52.534-(tcb->m_segmentSize)-(71.077)-(96.474)-(34.835)-(61.432)-(86.369)-(19.256));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (90.911-(tcb->m_cWnd)-(tcb->m_ssThresh)-(1.394)-(tcb->m_ssThresh)-(59.846)-(90.89));
