tcb->m_ssThresh = (int) (0.1/16.371);
tcb->m_segmentSize = (int) (13.111-(63.881)-(segmentsAcked)-(62.732)-(97.009)-(93.706)-(93.884));
tcb->m_segmentSize = (int) (tcb->m_ssThresh-(1.643)-(tcb->m_segmentSize)-(97.255)-(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (((30.096)+(18.053)+(0.1)+(46.574))/((40.255)));
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (26.731*(tcb->m_segmentSize)*(tcb->m_cWnd)*(83.948)*(67.532)*(73.515)*(93.403)*(59.424)*(47.537));
	tcb->m_ssThresh = (int) (((81.868)+(0.1)+((36.955+(73.075)+(50.193)))+(0.1)+(0.1)+(88.233)+(0.1))/((66.598)+(0.1)));
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (71.823*(tcb->m_segmentSize)*(33.314)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(5.259)*(23.322));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (3.697-(9.406)-(42.034)-(35.071));
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(87.791)-(93.339)-(33.757)-(1.382));
	tcb->m_ssThresh = (int) (55.017-(84.924)-(22.238)-(54.049)-(59.495)-(51.049)-(41.842)-(40.29));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(93.843)*(81.446));

} else {
	tcb->m_cWnd = (int) ((((76.139-(33.661)-(43.636)-(98.429)-(segmentsAcked)-(56.654)-(tcb->m_segmentSize)))+(67.979)+(1.72)+(67.013)+(35.508))/((94.215)));
	tcb->m_ssThresh = (int) (78.451*(43.719)*(82.732)*(75.462)*(18.983)*(96.902));

}
tcb->m_ssThresh = (int) (46.344+(99.391)+(tcb->m_ssThresh)+(67.108)+(86.928)+(78.211));
