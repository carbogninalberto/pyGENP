float QoKcAMWINCEnJjYX = (float) (-61.791+(75.126)+(42.568)+(-35.159)+(-20.357));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (1.34-(-51.487)-(-54.624)-(67.264)-(-1.18));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
