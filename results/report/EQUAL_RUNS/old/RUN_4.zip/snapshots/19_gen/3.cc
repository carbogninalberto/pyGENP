float MMTFoxHGjHEbhhBu = (float) (-78.536*(17.521)*(91.78)*(47.792)*(67.132)*(-43.869)*(92.98)*(8.648)*(68.743));
float zgCojkvoeRqJjcOV = (float) (3.008+(-9.445)+(-68.196)+(14.19)+(97.723)+(69.0)+(70.289)+(-9.475)+(44.213));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-78.149*(-92.272)*(84.505)*(14.158));
ReduceCwnd (tcb);
zgCojkvoeRqJjcOV = (float) ((-81.11-(tcb->m_cWnd)-(-92.234)-(tcb->m_cWnd)-(72.437)-(82.358)-(tcb->m_segmentSize))/-6.797);
zgCojkvoeRqJjcOV = (float) ((32.976-(tcb->m_cWnd)-(-99.894)-(tcb->m_cWnd)-(9.154)-(29.727)-(tcb->m_segmentSize))/-17.893);
