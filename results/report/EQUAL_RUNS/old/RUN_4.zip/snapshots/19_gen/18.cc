int zPBTnATlMLCWpxpH = (int) (97.384+(61.963)+(2.211)+(8.727)+(85.697)+(96.237)+(5.041));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (0.1/11.896);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (51.125+(53.746)+(42.063)+(27.042)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(8.043)+(4.734));

} else {
	tcb->m_cWnd = (int) (52.324+(19.637)+(39.613)+(90.889)+(78.848)+(76.239)+(98.758)+(35.274));
	tcb->m_cWnd = (int) (68.75+(70.634)+(1.101)+(57.101)+(43.223)+(17.917));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (4.623/0.1);
ReduceCwnd (tcb);
int ybowmeSVvgdhhwAU = (int) (82.739/40.277);
if (tcb->m_ssThresh == ybowmeSVvgdhhwAU) {
	segmentsAcked = (int) (90.519-(31.32)-(zPBTnATlMLCWpxpH)-(83.056)-(78.92)-(76.065)-(zPBTnATlMLCWpxpH)-(32.196));
	zPBTnATlMLCWpxpH = (int) (tcb->m_segmentSize+(27.964));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (77.638-(23.075)-(tcb->m_cWnd)-(81.907)-(23.407));

}
ReduceCwnd (tcb);
