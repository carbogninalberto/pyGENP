float QoKcAMWINCEnJjYX = (float) (95.236+(71.09)+(-14.245)+(70.351)+(-72.017));
ReduceCwnd (tcb);
segmentsAcked = (int) (-58.246-(-52.383)-(-78.503)-(-94.023)-(-62.878));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
