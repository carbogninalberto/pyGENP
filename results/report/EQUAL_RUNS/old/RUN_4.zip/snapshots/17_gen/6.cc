float JLplrEgFqyumnAMn = (float) (-61.87-(-31.819));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (8.81*(41.845)*(73.229));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
