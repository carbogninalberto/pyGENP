float dFYAlBwmzRelqHjQ = (float) (segmentsAcked-(55.07)-(6.336)-(tcb->m_cWnd)-(28.795)-(55.238)-(8.963));
if (tcb->m_segmentSize == dFYAlBwmzRelqHjQ) {
	tcb->m_ssThresh = (int) (90.331-(56.319));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (71.34-(73.949)-(59.127));

}
if (tcb->m_ssThresh > dFYAlBwmzRelqHjQ) {
	tcb->m_cWnd = (int) (segmentsAcked-(59.492)-(49.683)-(17.471)-(36.627)-(77.306)-(44.156));
	ReduceCwnd (tcb);
	dFYAlBwmzRelqHjQ = (float) (91.238*(51.228)*(30.74)*(46.357)*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (23.997+(tcb->m_cWnd)+(11.248)+(dFYAlBwmzRelqHjQ)+(93.418)+(37.462)+(7.446));

}
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (50.8/30.432);

} else {
	tcb->m_segmentSize = (int) (segmentsAcked-(2.295)-(dFYAlBwmzRelqHjQ)-(tcb->m_segmentSize)-(3.646)-(41.561)-(0.209));
	tcb->m_cWnd = (int) (5.977-(62.939)-(78.417)-(0.337)-(89.617)-(segmentsAcked)-(15.334)-(78.206));
	tcb->m_cWnd = (int) (66.251-(20.824)-(31.977));

}
if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (20.794*(69.806)*(7.424)*(tcb->m_segmentSize)*(51.71));
	segmentsAcked = (int) (dFYAlBwmzRelqHjQ-(52.821)-(65.992)-(tcb->m_cWnd)-(33.687)-(tcb->m_cWnd)-(6.768)-(tcb->m_cWnd)-(14.897));
	tcb->m_segmentSize = (int) (((68.072)+(9.025)+(0.1)+(13.028)+(47.431))/((0.1)+(0.1)+(62.898)));

} else {
	tcb->m_cWnd = (int) (67.813*(38.625)*(tcb->m_ssThresh)*(50.481)*(46.395)*(1.087)*(64.627)*(47.893)*(62.264));

}
