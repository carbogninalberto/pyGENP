float MMTFoxHGjHEbhhBu = (float) (43.903*(-79.592)*(96.774)*(30.117)*(30.685)*(66.758)*(60.927)*(14.95)*(-15.645));
float zgCojkvoeRqJjcOV = (float) (84.441+(1.106)+(91.75)+(7.514)+(75.974)+(-69.381)+(64.347)+(-4.834)+(-83.321));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-12.413*(-54.666)*(64.235)*(-26.806));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
zgCojkvoeRqJjcOV = (float) ((47.572-(tcb->m_cWnd)-(-95.435)-(tcb->m_cWnd)-(24.053)-(-85.599)-(tcb->m_segmentSize))/-66.082);
zgCojkvoeRqJjcOV = (float) ((-7.14-(tcb->m_cWnd)-(20.657)-(tcb->m_cWnd)-(-35.096)-(35.16)-(tcb->m_segmentSize))/78.736);
