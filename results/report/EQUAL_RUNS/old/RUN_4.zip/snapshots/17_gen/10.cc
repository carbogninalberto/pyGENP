TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float zgCojkvoeRqJjcOV = (float) (-71.129+(-57.155)+(69.025)+(56.91)+(-64.263)+(33.254)+(-0.873)+(5.693)+(-90.59));
tcb->m_cWnd = (int) (40.938*(-92.038)*(37.775)*(-80.372));
float MMTFoxHGjHEbhhBu = (float) (2.852*(17.808)*(-2.618)*(-41.111)*(-69.398)*(-5.595)*(-25.499)*(-7.201)*(-88.427));
ReduceCwnd (tcb);
zgCojkvoeRqJjcOV = (float) ((-72.149-(tcb->m_cWnd)-(29.497)-(tcb->m_cWnd)-(-40.24)-(-69.669)-(tcb->m_segmentSize))/-36.406);
