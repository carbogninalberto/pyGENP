float lmDRNNORPJJGyVVm = (float) (9.623*(tcb->m_ssThresh)*(22.868)*(14.668));
lmDRNNORPJJGyVVm = (float) (((38.777)+(0.1)+(0.1)+((75.36*(45.156)*(lmDRNNORPJJGyVVm)*(37.561)))+(0.1)+(0.1)+(55.458))/((0.1)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (65.3*(18.026)*(74.483)*(73.174)*(63.413)*(43.906)*(78.089));
tcb->m_cWnd = (int) (63.316/58.215);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (lmDRNNORPJJGyVVm < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (92.002-(87.427));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(2.488)*(tcb->m_segmentSize)*(61.985)*(97.382)*(42.674)*(97.298)*(tcb->m_ssThresh)*(75.34));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
