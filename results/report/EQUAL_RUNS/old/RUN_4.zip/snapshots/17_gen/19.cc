if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((0.1)+(69.684)+((segmentsAcked+(51.358)+(segmentsAcked)))+(0.1)+(24.293))/((4.183)));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (59.381*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(tcb->m_segmentSize));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (84.167*(45.051)*(81.484)*(42.546)*(44.668)*(tcb->m_cWnd)*(tcb->m_ssThresh));

}
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (23.782-(56.516)-(77.497)-(68.224)-(32.487)-(42.779)-(24.401)-(98.043)-(83.138));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (97.782*(19.929)*(56.28));
	segmentsAcked = (int) (21.911+(17.415)+(26.829)+(26.547)+(tcb->m_segmentSize)+(0.783));
	segmentsAcked = (int) (40.061*(72.173)*(69.692)*(15.782)*(75.096)*(97.28)*(tcb->m_ssThresh));

}
tcb->m_segmentSize = (int) (32.34-(tcb->m_segmentSize)-(75.47)-(90.553)-(28.706)-(97.408)-(57.28)-(15.929)-(74.708));
ReduceCwnd (tcb);
segmentsAcked = (int) (95.121/0.1);
