segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	segmentsAcked = (int) (segmentsAcked-(80.791)-(86.667)-(segmentsAcked)-(76.952)-(96.704)-(32.575));

} else {
	segmentsAcked = (int) (96.118+(92.908)+(tcb->m_segmentSize)+(29.969)+(tcb->m_segmentSize)+(8.816)+(tcb->m_segmentSize)+(0.299));
	ReduceCwnd (tcb);

}
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+(59.358)+(0.1)+(45.01)+(0.1))/((0.1)+(15.201)));
	tcb->m_cWnd = (int) (53.039-(64.91)-(tcb->m_cWnd)-(52.771)-(31.329)-(tcb->m_ssThresh)-(21.871));

} else {
	tcb->m_segmentSize = (int) (28.332*(21.228)*(80.249));
	tcb->m_cWnd = (int) ((((16.942+(20.85)+(18.892)+(29.165)+(78.547)+(83.74)))+(0.1)+(0.1)+(0.1))/((95.589)+(35.743)+(0.1)));

}
segmentsAcked = (int) (25.146+(66.867)+(21.703)+(34.582));
segmentsAcked = (int) (16.074-(11.813)-(tcb->m_segmentSize)-(63.191)-(65.797)-(1.959)-(38.597)-(76.62));
