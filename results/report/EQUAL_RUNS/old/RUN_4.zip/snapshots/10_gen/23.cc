tcb->m_segmentSize = (int) (54.869*(segmentsAcked)*(tcb->m_cWnd)*(tcb->m_cWnd)*(10.581)*(14.812)*(16.857));
segmentsAcked = (int) (0.1/0.1);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (89.132*(tcb->m_cWnd)*(3.315)*(45.833)*(segmentsAcked));
CongestionAvoidance (tcb, segmentsAcked);
int GtghmtVbkgUQfieO = (int) (segmentsAcked+(75.995)+(53.048)+(3.221)+(22.276)+(35.356));
