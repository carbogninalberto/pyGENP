int YNKePzFZwtbIrZyc = (int) 93.269;
float lAYlKEAbjASWpvnh = (float) (((5.349)+(63.9)+((75.391-(-95.572)-(-82.977)-(20.258)-(-26.75)-(28.334)-(-31.181)))+(-52.248)+((90.514-(-46.785)-(18.552)-(-82.497)-(41.036)-(49.453)-(38.348)-(2.513)-(-33.032)))+(-22.243))/((95.674)+(28.948)+(66.107)));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) (87.974+(19.261)+(35.724)+(50.663)+(85.563));
	tcb->m_segmentSize = (int) (((0.1)+(44.948)+(0.1)+(0.1))/((0.1)+(56.921)));
	segmentsAcked = (int) (0.1/57.395);

} else {
	segmentsAcked = (int) (34.85*(40.522)*(43.124)*(14.694)*(75.946));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	lAYlKEAbjASWpvnh = (float) (0.789+(87.396)+(YNKePzFZwtbIrZyc)+(85.148)+(47.949)+(29.091)+(0.177)+(59.55)+(tcb->m_segmentSize));

} else {
	lAYlKEAbjASWpvnh = (float) (55.361*(22.045));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
