int YNKePzFZwtbIrZyc = (int) 93.269;
float lAYlKEAbjASWpvnh = (float) (((49.861)+(68.766)+((-10.989-(20.11)-(79.795)-(-80.375)-(25.164)-(-19.441)-(-97.544)))+(70.401)+((-54.386-(45.366)-(-29.048)-(58.88)-(19.809)-(84.025)-(21.02)-(20.68)-(-40.715)))+(63.123))/((33.883)+(-70.179)+(-54.518)));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	lAYlKEAbjASWpvnh = (float) (0.789+(87.396)+(YNKePzFZwtbIrZyc)+(85.148)+(47.949)+(29.091)+(0.177)+(59.55)+(tcb->m_segmentSize));

} else {
	lAYlKEAbjASWpvnh = (float) (55.361*(22.045));

}
if (tcb->m_segmentSize != tcb->m_cWnd) {
	lAYlKEAbjASWpvnh = (float) (55.361*(22.045));

} else {
	lAYlKEAbjASWpvnh = (float) (0.789+(87.396)+(YNKePzFZwtbIrZyc)+(85.148)+(47.949)+(29.091)+(0.177)+(59.55)+(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
