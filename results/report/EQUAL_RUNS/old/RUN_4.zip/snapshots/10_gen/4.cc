int YNKePzFZwtbIrZyc = (int) 93.269;
float lAYlKEAbjASWpvnh = (float) (((91.504)+(-46.572)+((60.907-(-81.614)-(13.041)-(6.554)-(90.81)-(-77.578)-(27.542)))+(-22.439)+((-22.761-(-64.949)-(37.318)-(41.124)-(-3.961)-(-80.037)-(48.178)-(4.804)-(53.645)))+(-21.799))/((96.55)+(-4.904)+(68.181)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	lAYlKEAbjASWpvnh = (float) (0.789+(87.396)+(YNKePzFZwtbIrZyc)+(85.148)+(47.949)+(29.091)+(0.177)+(59.55)+(tcb->m_segmentSize));

} else {
	lAYlKEAbjASWpvnh = (float) (55.361*(22.045));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
