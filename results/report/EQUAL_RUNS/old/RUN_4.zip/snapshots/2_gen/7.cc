float blrBZtFhcrHxiuGU = (float) (-9.657-(-22.108));
float ONTvAcFXWSHrMHMP = (float) (-53.163-(32.155)-(-90.559)-(-6.66)-(69.432));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
