tcb->m_cWnd = (int) (-4.108/83.996);
