CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/36.69);
	ReduceCwnd (tcb);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (41.982-(0.364)-(17.628)-(tcb->m_cWnd)-(62.031)-(32.156)-(segmentsAcked)-(13.072)-(58.018));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (-31.538*(52.835));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-72.272-(-72.813));
