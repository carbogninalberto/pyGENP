float HVMqzCVSQozcLnUE = (float) (27.56-(98.007)-(-12.709)-(68.106)-(-82.668));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (-53.901-(90.033)-(94.721)-(86.411));
