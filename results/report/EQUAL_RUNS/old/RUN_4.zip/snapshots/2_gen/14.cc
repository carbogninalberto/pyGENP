float oDIIRLeElmNZPYxA = (float) 46.005;
