if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (segmentsAcked+(17.841)+(11.467)+(7.309)+(37.748)+(36.132)+(24.787)+(52.634));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (((0.1)+(11.856)+((52.938*(56.32)*(71.052)))+((34.062*(6.825)*(77.195)*(tcb->m_cWnd)))+(93.053))/((0.1)+(0.1)+(79.619)));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(83.64)-(42.721)-(26.436)-(79.347)-(12.843)-(87.473)-(10.99));

}
