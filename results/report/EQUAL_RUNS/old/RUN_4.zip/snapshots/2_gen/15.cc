segmentsAcked = (int) (((46.946)+(-95.346)+(-90.368)+(-4.742)+((95.982+(-48.79)+(-46.066)+(12.053)))+(88.32)+(47.466))/((79.833)+(-34.083)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
