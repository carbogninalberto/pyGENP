float tZRblbrpKcSHcity = (float) (4.262-(36.962)-(-57.858));
float oDIIRLeElmNZPYxA = (float) (46.832*(92.766)*(98.296)*(-62.215)*(34.699)*(16.139));
float WYRpnjILAewGDJen = (float) (45.745*(-13.227)*(-79.779)*(16.327)*(42.159)*(-32.217));
ReduceCwnd (tcb);
int pTsjufRdeJBdfJNN = (int) (((-77.22)+(-55.363)+(88.711)+(-6.329))/((24.223)));
tcb->m_segmentSize = (int) (52.171*(-72.592)*(20.659)*(-6.966)*(-20.356)*(36.224));
float hzBtDGfLzQuwZeDY = (float) 97.045;
if (tcb->m_segmentSize != tZRblbrpKcSHcity) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(42.593)+(47.227)+(tZRblbrpKcSHcity)+(14.196)+(28.541));
	tZRblbrpKcSHcity = (float) (26.545+(34.521)+(80.091)+(57.671)+(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (11.307-(86.539)-(67.927)-(83.776)-(12.671)-(79.901)-(tcb->m_cWnd)-(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (-46.518*(83.328)*(99.384)*(-81.937)*(-80.053)*(5.945)*(7.202)*(37.057));
