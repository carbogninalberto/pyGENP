float tZRblbrpKcSHcity = (float) 35.121;
float oDIIRLeElmNZPYxA = (float) (40.982*(88.236)*(12.612)*(22.363)*(91.44)*(71.832));
float WYRpnjILAewGDJen = (float) (97.376*(87.87)*(-70.24)*(-28.242)*(21.577)*(-4.046));
int pTsjufRdeJBdfJNN = (int) (((65.586)+(20.825)+(-27.212)+(-46.789))/((69.015)));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (57.26+(-96.835)+(-9.929));
tcb->m_cWnd = (int) (17.578*(39.503)*(31.707)*(96.807)*(-60.839)*(81.656)*(68.776)*(-54.284));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (23.859*(-93.951)*(-29.848)*(34.631)*(52.935)*(-39.783));
if (tcb->m_segmentSize != tZRblbrpKcSHcity) {
	tcb->m_segmentSize = (int) (11.307-(86.539)-(67.927)-(83.776)-(12.671)-(79.901)-(tcb->m_cWnd)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(42.593)+(47.227)+(tZRblbrpKcSHcity)+(14.196)+(28.541));
	tZRblbrpKcSHcity = (float) (26.545+(34.521)+(80.091)+(57.671)+(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (-78.006*(-14.807)*(20.063)*(10.631)*(-35.689)*(15.211)*(70.107)*(3.969));
