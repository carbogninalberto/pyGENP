int pTsjufRdeJBdfJNN = (int) (((36.879)+(-94.332)+(-55.528)+(-73.36))/((-87.301)));
float tZRblbrpKcSHcity = (float) 9.375;
