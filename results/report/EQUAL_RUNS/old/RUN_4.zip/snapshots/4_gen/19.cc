if (tcb->m_cWnd != tcb->m_cWnd) {
	segmentsAcked = (int) (63.329/20.207);

} else {
	segmentsAcked = (int) (64.233-(54.729)-(83.432)-(59.932)-(53.977)-(87.204)-(68.411)-(76.751));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
