float ZmNElMOmEYJwqJeo = (float) 29.706;
float lzQaaNNGSMNTofgI = (float) 38.496;
