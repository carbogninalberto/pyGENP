float ERnDofRXJbBchLXP = (float) (85.688+(-65.265)+(-43.937)+(-88.182)+(5.641)+(-60.115)+(-98.613)+(-2.163)+(41.834));
float oXLyOWWaWwMYAECH = (float) (-79.506*(68.296)*(-24.028)*(-62.909));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
