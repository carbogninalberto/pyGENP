float ERnDofRXJbBchLXP = (float) (-25.469+(0.147)+(51.302)+(-65.969)+(88.739)+(-81.806)+(52.785)+(-28.696)+(-22.821));
float oXLyOWWaWwMYAECH = (float) (-24.009*(-77.953)*(93.981)*(-32.76));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
