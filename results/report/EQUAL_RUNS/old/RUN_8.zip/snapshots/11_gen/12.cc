int luiIwqZudFCWcdag = (int) 53.911;
