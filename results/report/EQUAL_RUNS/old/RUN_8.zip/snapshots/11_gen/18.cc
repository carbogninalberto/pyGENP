float ERnDofRXJbBchLXP = (float) (-75.039+(-23.745)+(-28.351)+(54.831)+(-71.33)+(-43.223)+(61.502)+(27.489)+(-9.382));
float oXLyOWWaWwMYAECH = (float) (64.12*(96.555)*(28.849)*(-12.451));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
