tcb->m_cWnd = (int) (44.746*(60.775)*(94.326)*(tcb->m_cWnd)*(4.186));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (39.078+(89.868));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (77.694/2.992);

}
tcb->m_ssThresh = (int) (39.46/0.1);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (9.192+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(94.634)+(11.943));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(42.54)*(61.703)*(58.948)*(84.381)*(tcb->m_cWnd));
	segmentsAcked = (int) (17.781-(54.091)-(48.206)-(68.259)-(93.726));

}
tcb->m_segmentSize = (int) (tcb->m_cWnd-(84.155)-(56.79)-(90.016)-(75.016)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(63.618)-(tcb->m_cWnd));
