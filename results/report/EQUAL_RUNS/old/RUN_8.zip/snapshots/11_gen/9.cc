int DajfqveGjjMKlQHc = (int) (-27.31-(-85.373)-(14.43)-(30.181)-(-43.032));
float IJeTSufbbYcyYSHq = (float) (-54.165-(-33.709)-(-21.733)-(68.995)-(-99.175));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/2.939);
	tcb->m_cWnd = (int) (93.821+(65.696)+(15.488));

} else {
	segmentsAcked = (int) (((0.1)+(99.511)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));

}
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (((0.1)+(99.511)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));

} else {
	segmentsAcked = (int) (0.1/2.939);
	tcb->m_cWnd = (int) (93.821+(65.696)+(15.488));

}
IJeTSufbbYcyYSHq = (float) (12.208*(-31.636)*(3.908)*(-9.974)*(37.627));
IJeTSufbbYcyYSHq = (float) (-56.853*(47.219)*(-88.113)*(58.512)*(-60.515));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
