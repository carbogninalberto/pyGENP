float ERnDofRXJbBchLXP = (float) (-58.744+(36.629)+(8.493)+(-77.2)+(89.423)+(85.05)+(63.282)+(57.167)+(-22.694));
float oXLyOWWaWwMYAECH = (float) (-30.469*(11.833)*(-12.816)*(91.169));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
