int QVWSlwYleHVrkbBQ = (int) (-13.187/-95.772);
float rBzfPcgTGBYHQhfU = (float) (29.069+(33.29)+(-22.527)+(-80.504)+(-15.242)+(-40.58)+(-36.171));
float tUdogVmTKJIdmnLF = (float) (-75.58+(17.706)+(-42.739)+(-17.55));
