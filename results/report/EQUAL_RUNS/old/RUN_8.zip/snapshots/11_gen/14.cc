float ERnDofRXJbBchLXP = (float) (-28.712+(55.883)+(-63.864)+(22.427)+(92.984)+(-69.615)+(-66.739)+(62.212)+(-45.135));
float oXLyOWWaWwMYAECH = (float) (-70.45*(-1.815)*(20.839)*(37.32));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
