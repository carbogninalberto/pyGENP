int xmswRhQWrgANCamG = (int) (34.948*(24.487)*(42.698)*(12.051));
tcb->m_cWnd = (int) (75.356-(53.98)-(xmswRhQWrgANCamG)-(xmswRhQWrgANCamG)-(21.074)-(61.202)-(24.188));
tcb->m_segmentSize = (int) (66.681+(66.689)+(69.126)+(32.982)+(88.86));
if (xmswRhQWrgANCamG > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((0.1)+(55.936)+(0.1)+(0.1))/((0.1)+(56.15)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (46.772+(81.098));

}
tcb->m_segmentSize = (int) (52.901*(4.436)*(85.537)*(10.138)*(69.665)*(18.667)*(11.09)*(13.908)*(60.5));
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (0.1/49.599);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (9.755-(29.247)-(segmentsAcked)-(82.62)-(segmentsAcked)-(45.532)-(94.617)-(71.273));
	tcb->m_segmentSize = (int) (90.887/0.1);

}
