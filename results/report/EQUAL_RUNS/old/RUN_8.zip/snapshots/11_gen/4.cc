float ERnDofRXJbBchLXP = (float) (8.376+(-87.586)+(-84.607)+(-85.953)+(70.19)+(36.139)+(66.289)+(75.244)+(-16.344));
float oXLyOWWaWwMYAECH = (float) (49.532*(-10.163)*(40.719)*(-34.939));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
