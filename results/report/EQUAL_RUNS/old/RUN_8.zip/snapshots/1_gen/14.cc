ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (24.463+(42.39)+(86.373));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (86.759+(4.743)+(4.461)+(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (((19.614)+(0.1)+((tcb->m_ssThresh+(1.044)+(59.238)+(78.254)+(67.858)+(36.004)+(85.231)+(94.863)+(26.868)))+((tcb->m_cWnd*(80.301)*(tcb->m_cWnd)))+(0.1))/((0.1)+(23.118)));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(81.198)+(0.1)+(83.902))/((5.053)+(0.1)));

}
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (2.719-(29.345)-(40.08)-(77.901)-(45.47)-(tcb->m_ssThresh)-(10.862)-(segmentsAcked));
	tcb->m_cWnd = (int) (20.439-(6.256)-(tcb->m_ssThresh)-(8.239)-(53.358)-(23.945)-(tcb->m_cWnd)-(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (37.605*(83.044)*(20.831)*(6.361)*(70.833)*(94.101)*(tcb->m_ssThresh)*(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (94.089+(66.096)+(29.389)+(36.173)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (88.355+(29.294)+(tcb->m_cWnd)+(93.673));
	tcb->m_segmentSize = (int) (66.228+(41.549)+(tcb->m_ssThresh)+(2.034)+(45.767));

} else {
	tcb->m_ssThresh = (int) (38.388-(54.969)-(19.642)-(38.103)-(66.902)-(39.858)-(70.357)-(79.745));
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (segmentsAcked-(39.365));
	segmentsAcked = (int) (52.247+(segmentsAcked)+(16.565)+(72.986)+(93.3)+(74.301)+(10.401)+(63.111)+(11.348));
	tcb->m_ssThresh = (int) (20.474+(tcb->m_ssThresh)+(tcb->m_cWnd)+(tcb->m_cWnd)+(32.552)+(80.276)+(46.856)+(81.601)+(65.817));

} else {
	tcb->m_cWnd = (int) (22.291*(77.364)*(9.824)*(6.795)*(88.375)*(segmentsAcked)*(97.931)*(98.446));
	tcb->m_ssThresh = (int) (71.56*(72.859)*(95.238)*(44.491)*(10.133));

}
