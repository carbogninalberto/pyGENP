tcb->m_segmentSize = (int) (0.1/0.1);
tcb->m_ssThresh = (int) (0.198*(53.71)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(23.876)*(tcb->m_segmentSize));
if (segmentsAcked != tcb->m_segmentSize) {
	segmentsAcked = (int) (21.651*(37.996)*(1.816)*(0.893)*(53.931)*(87.023)*(83.297));
	tcb->m_segmentSize = (int) (56.885-(57.624));

} else {
	segmentsAcked = (int) (tcb->m_cWnd+(83.783));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (18.055+(4.471)+(13.059)+(58.194)+(16.519)+(62.075)+(49.259));

} else {
	tcb->m_segmentSize = (int) (14.285*(99.413)*(14.397)*(83.057)*(93.646));

}
if (segmentsAcked == tcb->m_segmentSize) {
	segmentsAcked = (int) (93.576+(tcb->m_segmentSize)+(35.253)+(78.99));

} else {
	segmentsAcked = (int) (95.099*(32.903)*(44.263));

}
