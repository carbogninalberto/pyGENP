int TmNWwHHHaIsNasVW = (int) (5.998/0.1);
tcb->m_segmentSize = (int) (9.116*(tcb->m_cWnd)*(segmentsAcked)*(10.139)*(89.802));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (TmNWwHHHaIsNasVW >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (62.74-(17.576)-(22.609)-(TmNWwHHHaIsNasVW)-(31.637)-(81.828)-(54.664)-(92.32));
	TmNWwHHHaIsNasVW = (int) (segmentsAcked+(77.694)+(61.915)+(27.563)+(99.767)+(tcb->m_segmentSize)+(85.777)+(tcb->m_segmentSize));
	TmNWwHHHaIsNasVW = (int) (81.028+(51.047)+(18.533)+(35.619));

} else {
	tcb->m_cWnd = (int) (68.985+(73.158)+(71.558)+(27.8)+(87.911)+(44.086));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
