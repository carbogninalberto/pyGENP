tcb->m_segmentSize = (int) (36.554-(63.367)-(21.263)-(56.086)-(87.263)-(tcb->m_segmentSize));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (39.681*(tcb->m_segmentSize)*(tcb->m_cWnd)*(11.275)*(40.648)*(segmentsAcked)*(9.19));
int VbjWRahBeBQpfgSj = (int) (66.514*(tcb->m_cWnd)*(40.229)*(segmentsAcked)*(85.08)*(3.061)*(63.2)*(tcb->m_ssThresh));
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_ssThresh = (int) (62.297+(66.919)+(82.394)+(VbjWRahBeBQpfgSj)+(34.444)+(3.995)+(82.487));

} else {
	tcb->m_ssThresh = (int) (((86.774)+(0.1)+(0.1)+(47.519)+(39.47))/((17.436)+(27.505)));

}
tcb->m_segmentSize = (int) (52.705+(28.064)+(76.39)+(76.071)+(88.374)+(71.664)+(6.936)+(64.714)+(tcb->m_segmentSize));
