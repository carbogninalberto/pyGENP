if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.154+(9.484)+(52.693)+(segmentsAcked)+(97.859)+(54.126)+(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (74.644-(77.793)-(65.421)-(18.839)-(29.996)-(18.067)-(tcb->m_cWnd)-(4.572));

} else {
	tcb->m_cWnd = (int) (31.419*(61.825)*(47.93)*(66.45)*(34.312)*(79.872));
	segmentsAcked = (int) (segmentsAcked-(tcb->m_ssThresh)-(78.652)-(80.326)-(75.086)-(42.56)-(29.824));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (40.476/0.1);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) ((1.741+(97.369)+(87.019)+(57.8)+(12.368)+(33.163)+(48.096)+(75.213)+(46.315))/0.1);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (53.59*(0.354)*(tcb->m_cWnd)*(3.893));
