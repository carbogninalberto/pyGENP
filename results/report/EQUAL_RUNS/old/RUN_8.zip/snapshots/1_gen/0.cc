segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (68.78+(67.1)+(54.501)+(16.132)+(22.027)+(51.536)+(70.8)+(53.105)+(43.12));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (52.055*(tcb->m_ssThresh)*(32.959)*(23.205)*(15.729)*(segmentsAcked));
	segmentsAcked = (int) (tcb->m_segmentSize+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(85.785)+(75.224)+(3.955)+(64.486)+(4.066)+(76.009));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (0.1/17.204);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (99.31*(32.027)*(tcb->m_segmentSize)*(41.132)*(83.973)*(tcb->m_segmentSize)*(35.075)*(77.909));

}
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) ((((61.901+(55.813)+(0.388)+(4.543)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(98.123)))+(0.1)+(0.1)+(97.013)+(74.35)+(69.676))/((9.04)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (((69.268)+(12.067)+(0.1)+(0.1)+((76.577-(97.822)-(9.263)-(73.43)-(tcb->m_cWnd)-(82.855)))+(44.549)+(0.1))/((62.195)));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
