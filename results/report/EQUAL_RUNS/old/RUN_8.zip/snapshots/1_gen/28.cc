tcb->m_ssThresh = (int) (93.867-(35.881));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_ssThresh = (int) (10.282*(60.41)*(15.249)*(tcb->m_ssThresh)*(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (95.369*(40.182)*(segmentsAcked)*(33.342)*(75.419)*(19.959)*(54.561)*(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (0.1/7.146);
	segmentsAcked = (int) (41.587/14.773);

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (78.832-(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (87.018+(segmentsAcked)+(44.615)+(tcb->m_segmentSize)+(segmentsAcked)+(86.514)+(46.587));
	tcb->m_segmentSize = (int) (13.311*(60.579)*(19.936)*(53.544)*(segmentsAcked)*(tcb->m_cWnd)*(71.438)*(13.226));
	tcb->m_segmentSize = (int) (91.156+(49.02)+(68.883)+(tcb->m_cWnd)+(95.499)+(8.328)+(48.323)+(69.102)+(14.216));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
