if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (95.365/0.1);
	tcb->m_cWnd = (int) (64.068-(77.868)-(tcb->m_segmentSize)-(95.766)-(99.377)-(89.236));
	tcb->m_cWnd = (int) (0.1/0.1);

}
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(99.673)+(70.379)+(82.072)+(37.469));
	tcb->m_cWnd = (int) (0.1/2.029);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (73.414-(61.421)-(53.867)-(18.265)-(7.149));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (29.187*(91.325));
