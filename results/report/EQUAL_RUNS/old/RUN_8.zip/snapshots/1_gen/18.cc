if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (59.247/17.493);
	tcb->m_ssThresh = (int) (0.1/56.806);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(20.389)-(73.022)-(tcb->m_cWnd)-(33.052)-(82.581)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (36.058*(tcb->m_ssThresh)*(75.254));

}
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_cWnd = (int) (5.15-(54.191)-(tcb->m_segmentSize)-(61.369)-(8.555));
	tcb->m_ssThresh = (int) (54.757*(75.199)*(40.348));
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(58.682)*(25.622)*(tcb->m_ssThresh)*(50.487)*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (0.1/74.618);

}
tcb->m_cWnd = (int) (13.785+(14.669)+(97.058)+(32.795)+(7.722)+(52.065)+(64.585)+(64.813));
ReduceCwnd (tcb);
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (43.477-(57.798)-(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) ((17.578*(97.152))/(59.896+(95.956)+(49.383)));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(76.938)+(9.295)+(0.1)+(37.485))/((95.102)+(3.125)+(0.1)));

}
tcb->m_segmentSize = (int) (61.9*(tcb->m_cWnd));
segmentsAcked = (int) (((11.206)+(23.325)+(0.1)+(1.129)+(30.695))/((0.1)));
