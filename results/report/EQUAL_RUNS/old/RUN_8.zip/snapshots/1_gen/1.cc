ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (26.36-(17.074)-(51.945)-(98.398)-(15.998)-(22.85));
	tcb->m_segmentSize = (int) (82.657/0.1);
	tcb->m_cWnd = (int) (72.412*(38.337)*(segmentsAcked)*(10.417));

} else {
	tcb->m_ssThresh = (int) (9.843-(16.239)-(tcb->m_segmentSize)-(87.384)-(segmentsAcked)-(14.06));

}
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (67.543-(tcb->m_ssThresh)-(74.205));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (45.008*(77.417)*(segmentsAcked)*(7.102));

} else {
	tcb->m_cWnd = (int) (0.1/52.757);
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(51.762)+(20.415)+(55.998)+(76.605)+(42.132)+(20.164)+(segmentsAcked)+(11.236));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_cWnd = (int) (60.239-(tcb->m_ssThresh)-(40.419)-(33.806)-(76.297)-(44.551)-(76.627)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(42.648)*(60.827)*(tcb->m_segmentSize)*(82.913));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (75.858+(56.514)+(tcb->m_ssThresh)+(85.289)+(1.034));
	tcb->m_cWnd = (int) (62.347-(39.929)-(segmentsAcked)-(tcb->m_cWnd)-(42.236)-(tcb->m_segmentSize)-(52.58)-(segmentsAcked));
	ReduceCwnd (tcb);

}
