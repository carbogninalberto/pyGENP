float YhKgEFxxNxXHEVcl = (float) (67.186+(-78.583)+(-70.74));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-55.014/-74.105);
tcb->m_cWnd = (int) (-25.346/-83.654);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (20.54-(79.71)-(65.874)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(32.594)-(51.823)-(-58.465));
	segmentsAcked = (int) (((13.31)+(0.1)+(85.518)+(89.745))/((0.1)+(88.112)+(0.1)));
	segmentsAcked = (int) (26.012+(36.659)+(26.891)+(0.957));

} else {
	tcb->m_segmentSize = (int) (75.341+(73.601)+(tcb->m_segmentSize)+(72.849));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	YhKgEFxxNxXHEVcl = (float) (tcb->m_cWnd-(22.697)-(75.331)-(98.103)-(segmentsAcked)-(24.998)-(93.734));

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (20.54-(79.71)-(65.874)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(32.594)-(51.823)-(60.292));
	segmentsAcked = (int) (((13.31)+(0.1)+(85.518)+(89.745))/((0.1)+(88.112)+(0.1)));
	segmentsAcked = (int) (26.012+(36.659)+(26.891)+(0.957));

} else {
	tcb->m_segmentSize = (int) (75.341+(73.601)+(tcb->m_segmentSize)+(72.849));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	YhKgEFxxNxXHEVcl = (float) (tcb->m_cWnd-(22.697)-(75.331)-(98.103)-(segmentsAcked)-(24.998)-(78.844));

}
