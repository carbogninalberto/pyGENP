tcb->m_segmentSize = (int) (0.1/0.1);
tcb->m_ssThresh = (int) (tcb->m_cWnd*(41.923)*(39.549)*(3.017)*(77.506)*(54.457));
segmentsAcked = (int) (0.1/92.535);
segmentsAcked = (int) (tcb->m_cWnd-(41.797)-(tcb->m_segmentSize)-(66.835));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (85.484-(tcb->m_segmentSize)-(72.771)-(24.788));
tcb->m_segmentSize = (int) (((21.588)+(0.1)+((tcb->m_segmentSize*(14.849)*(95.783)*(tcb->m_cWnd)))+(88.726))/((0.1)));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	segmentsAcked = (int) (2.381+(34.647)+(24.629)+(segmentsAcked)+(12.506)+(tcb->m_segmentSize)+(76.863));

} else {
	segmentsAcked = (int) (32.358+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(83.844)+(tcb->m_ssThresh)+(60.589));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (41.527-(60.903)-(28.587)-(77.755)-(4.541)-(37.208));

}
