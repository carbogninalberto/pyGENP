if (segmentsAcked <= tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_segmentSize+(95.741)+(segmentsAcked)+(tcb->m_segmentSize)+(97.99)+(tcb->m_ssThresh)+(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(19.488)-(30.113)-(17.649)-(95.484)-(71.545)-(61.133));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (segmentsAcked-(segmentsAcked)-(62.226)-(10.098)-(64.049)-(tcb->m_segmentSize)-(74.292)-(67.042));
	tcb->m_cWnd = (int) (10.822+(42.5)+(3.832)+(74.147)+(20.463)+(segmentsAcked)+(76.304));
	tcb->m_cWnd = (int) (0.1/91.796);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (45.831/10.724);
