tcb->m_cWnd = (int) (49.172-(32.388)-(tcb->m_ssThresh)-(91.847)-(41.637)-(86.764)-(61.426));
tcb->m_cWnd = (int) (tcb->m_cWnd-(90.441)-(11.651));
tcb->m_segmentSize = (int) ((53.567-(55.51)-(63.333)-(42.664)-(tcb->m_cWnd)-(segmentsAcked))/51.158);
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (segmentsAcked-(54.45)-(tcb->m_ssThresh)-(47.623)-(64.291)-(tcb->m_segmentSize)-(81.266)-(8.464));
	tcb->m_segmentSize = (int) (2.924-(94.368)-(75.321)-(76.178));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (46.401+(72.756)+(85.888)+(25.029)+(60.104)+(segmentsAcked)+(42.426)+(36.538)+(96.762));
	segmentsAcked = (int) (46.435-(21.824)-(82.655)-(54.094)-(72.101)-(1.22)-(72.125)-(34.898));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (28.606/0.1);
tcb->m_ssThresh = (int) (98.34-(tcb->m_ssThresh)-(87.169)-(0.406)-(35.573)-(75.015)-(53.012));
