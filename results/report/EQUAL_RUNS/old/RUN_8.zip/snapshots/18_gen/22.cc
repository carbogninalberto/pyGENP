if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (59.885+(52.353)+(61.266)+(40.433));
	tcb->m_ssThresh = (int) (78.822+(30.289)+(45.074)+(59.917)+(72.475));

} else {
	tcb->m_segmentSize = (int) (7.953-(tcb->m_segmentSize)-(10.179)-(71.093)-(tcb->m_ssThresh)-(59.913)-(15.065)-(89.61));

}
tcb->m_ssThresh = (int) (80.216+(45.614)+(35.697)+(96.994));
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (89.582-(44.936)-(68.804)-(tcb->m_ssThresh)-(6.736));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (58.363-(61.74)-(36.795)-(tcb->m_segmentSize)-(22.683)-(55.025)-(87.435)-(53.974)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (27.716-(45.233)-(tcb->m_ssThresh)-(49.984));
	tcb->m_segmentSize = (int) (71.231-(82.343)-(16.989)-(6.667));
	ReduceCwnd (tcb);

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_ssThresh = (int) (58.492+(83.804)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(87.991)+(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (54.243-(4.152)-(7.411)-(77.545)-(59.57)-(21.839)-(43.907)-(55.297));
	tcb->m_cWnd = (int) (segmentsAcked-(39.621));

}
