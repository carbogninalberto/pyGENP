segmentsAcked = (int) (36.888/32.306);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (24.122*(tcb->m_ssThresh)*(49.96)*(36.312)*(66.087));

} else {
	tcb->m_cWnd = (int) (7.089-(21.411));

}
int HaiMAoTKzntnlwuV = (int) (segmentsAcked+(52.053)+(30.597)+(33.872)+(51.953)+(63.56));
tcb->m_segmentSize = (int) (75.571*(10.186)*(19.628));
