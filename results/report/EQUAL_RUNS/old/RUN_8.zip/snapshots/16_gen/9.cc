if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (84.74*(83.656)*(78.416)*(13.335));

} else {
	tcb->m_cWnd = (int) (5.352-(segmentsAcked)-(58.001)-(segmentsAcked));

}
tcb->m_segmentSize = (int) (-95.973/-28.4);
segmentsAcked = SlowStart (tcb, segmentsAcked);
