float FaxpsQMTPmvSaOcJ = (float) ((14.286+(53.745)+(-8.565)+(-46.432)+(69.216)+(-66.384)+(58.735))/48.334);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
FaxpsQMTPmvSaOcJ = (float) (((-3.191)+((4.04*(87.158)*(-13.828)*(-48.74)*(54.702)*(78.208)))+(-81.208)+(-70.892)+(54.695)+(-62.852)+(-44.525))/((10.405)));
