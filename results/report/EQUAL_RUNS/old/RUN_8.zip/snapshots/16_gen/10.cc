float eWaySTJBLsbHcHtO = (float) (-50.565*(25.336)*(-56.703)*(-59.5)*(-8.598)*(76.6)*(20.001));
int HyxJBINEZXQegGGW = (int) (-55.292-(-46.69)-(-13.584)-(-77.923)-(33.736)-(69.782));
int tfogEiIsAluSMVFU = (int) (34.954+(27.764)+(-53.093)+(23.201)+(3.816)+(10.788)+(-36.016));
HyxJBINEZXQegGGW = (int) (37.203-(88.125)-(-79.779)-(-5.098)-(71.498)-(-68.632)-(-7.222)-(85.965)-(19.217));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
