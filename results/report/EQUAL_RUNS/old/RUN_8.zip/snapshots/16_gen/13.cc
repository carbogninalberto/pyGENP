float eWaySTJBLsbHcHtO = (float) (83.683*(94.156)*(91.983)*(40.685)*(-75.625)*(-83.137)*(-60.2));
int HyxJBINEZXQegGGW = (int) (-46.576-(68.927)-(-68.04)-(73.808)-(-19.726)-(4.154));
int tfogEiIsAluSMVFU = (int) (50.557+(-20.018)+(53.474)+(-6.393)+(47.779)+(80.482)+(-46.17));
segmentsAcked = (int) (-73.013-(61.477)-(-30.068)-(33.455));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
