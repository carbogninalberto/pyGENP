tcb->m_segmentSize = (int) (0.975*(tcb->m_ssThresh)*(22.622));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (29.807/75.324);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (94.834*(9.163)*(74.546)*(tcb->m_segmentSize)*(69.866)*(86.487)*(41.64));

}
tcb->m_segmentSize = (int) (tcb->m_ssThresh+(13.014));
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (2.414-(37.167)-(81.535)-(29.417)-(76.308)-(15.492)-(41.58)-(77.892)-(92.063));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (33.466-(49.308));
	tcb->m_ssThresh = (int) (3.981-(50.546));

}
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(20.412)-(55.517)-(2.26));

} else {
	tcb->m_segmentSize = (int) (12.954+(14.085)+(49.648));
	tcb->m_segmentSize = (int) (98.988+(48.111)+(89.64)+(97.787)+(39.698));
	segmentsAcked = (int) (((56.454)+(89.179)+(23.002)+(0.1))/((40.395)));

}
tcb->m_cWnd = (int) (80.378/0.1);
