int CmiqekSZsRAeCSnB = (int) (34.491*(-66.333)*(-77.664)*(2.149)*(-86.538)*(-42.754)*(1.508)*(-34.578));
tcb->m_cWnd = (int) (25.561*(-44.195)*(86.593)*(-40.623)*(-70.208)*(-97.851)*(-91.922)*(-59.504)*(-71.355));
if (tcb->m_segmentSize != segmentsAcked) {
	segmentsAcked = (int) (93.625-(48.031));

} else {
	segmentsAcked = (int) (-87.378*(79.734)*(48.831)*(41.002)*(67.663));
	segmentsAcked = (int) (62.895+(75.303)+(5.967)+(68.08)+(segmentsAcked)+(79.072)+(41.841));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-1.628*(31.917)*(0.612)*(74.695)*(34.353)*(83.534));
tcb->m_cWnd = (int) (53.523*(83.283)*(14.686)*(0.899)*(-99.195)*(-48.708)*(74.458)*(50.463)*(1.577));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (40.217*(43.322)*(-0.307)*(26.363)*(2.366)*(-37.614));
