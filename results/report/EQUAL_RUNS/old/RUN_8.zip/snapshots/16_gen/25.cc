float NprmplRHzjrIPiar = (float) (1.125/0.1);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	segmentsAcked = (int) (NprmplRHzjrIPiar-(segmentsAcked)-(4.859));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (6.363*(0.668)*(18.518));
	tcb->m_segmentSize = (int) (44.297+(tcb->m_cWnd)+(99.195));

}
float svcJztIznvqSnUcq = (float) (76.877*(NprmplRHzjrIPiar)*(25.609)*(87.321)*(6.277)*(NprmplRHzjrIPiar)*(5.176));
if (tcb->m_ssThresh == NprmplRHzjrIPiar) {
	tcb->m_ssThresh = (int) (6.595*(-0.075)*(90.243)*(53.905)*(79.2));

} else {
	tcb->m_ssThresh = (int) (58.522+(68.507)+(70.219)+(82.272)+(4.492));

}
if (segmentsAcked >= segmentsAcked) {
	NprmplRHzjrIPiar = (float) (75.584-(21.406)-(tcb->m_ssThresh)-(svcJztIznvqSnUcq)-(11.094)-(31.648)-(34.687));

} else {
	NprmplRHzjrIPiar = (float) (81.357-(NprmplRHzjrIPiar)-(segmentsAcked)-(76.012)-(60.303));

}
segmentsAcked = (int) (82.914-(11.143)-(67.004));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (92.902+(5.689)+(21.972)+(10.276)+(segmentsAcked)+(28.376)+(37.851)+(34.343)+(39.93));
