tcb->m_cWnd = (int) (73.251*(47.947)*(26.144)*(32.196));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (63.735-(tcb->m_segmentSize)-(36.533)-(tcb->m_segmentSize)-(56.985)-(80.407)-(61.939)-(41.276)-(71.823));
tcb->m_ssThresh = (int) (37.374+(66.005));
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (35.59+(31.058));
	tcb->m_segmentSize = (int) (0.1/30.993);

} else {
	segmentsAcked = (int) (tcb->m_ssThresh*(tcb->m_ssThresh)*(38.968)*(55.618)*(39.115)*(0.265));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(51.063));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
