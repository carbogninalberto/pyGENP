CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (tcb->m_ssThresh-(36.714)-(35.211)-(15.511)-(43.025)-(19.879)-(74.131)-(segmentsAcked));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (37.324-(37.738)-(99.608)-(92.92));

} else {
	tcb->m_segmentSize = (int) (80.696/0.1);
	tcb->m_segmentSize = (int) (99.078+(tcb->m_segmentSize)+(47.26)+(30.324));

}
