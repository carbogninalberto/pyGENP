int PjxMjKwGDNMtJjYS = (int) (20.359+(-3.071)+(-54.773)+(-91.716)+(63.819)+(-27.162)+(43.676)+(-83.793));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (57.648+(10.34)+(-71.65)+(55.91)+(52.876)+(54.979)+(tcb->m_segmentSize)+(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (60.093-(98.087)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(6.098)-(66.05)-(77.88)-(segmentsAcked));

}
