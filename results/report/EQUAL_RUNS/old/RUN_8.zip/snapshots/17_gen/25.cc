tcb->m_cWnd = (int) (8.491-(26.662)-(42.414)-(13.354)-(66.522)-(11.222)-(64.978)-(42.668));
tcb->m_ssThresh = (int) (41.32+(tcb->m_ssThresh)+(57.872)+(53.39)+(85.118)+(90.978));
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_ssThresh = (int) (39.157-(4.628)-(tcb->m_ssThresh)-(54.191)-(tcb->m_segmentSize)-(56.485)-(25.859)-(65.049));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(85.633)-(19.861)-(76.979)-(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (19.682*(54.547)*(94.222)*(90.427)*(17.695)*(49.289));
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(tcb->m_cWnd)+(segmentsAcked));
tcb->m_segmentSize = (int) (65.558+(58.616)+(0.899)+(85.43)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(12.89)+(tcb->m_segmentSize));
