ReduceCwnd (tcb);
float FIFOwLPDGrMKZOWC = (float) (-55.245-(-64.953)-(17.818)-(-71.443)-(-46.024));
ReduceCwnd (tcb);
float FaxpsQMTPmvSaOcJ = (float) 99.112;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
FaxpsQMTPmvSaOcJ = (float) (((76.983)+((-31.749*(30.441)*(50.174)*(-38.729)*(49.978)*(36.677)))+(-75.2)+(26.303)+(59.458)+(-85.271)+(33.621))/((-43.815)));
