ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (52.05*(17.207)*(75.749));

} else {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(2.97)+(0.1)+((32.555*(90.383)*(3.486)*(80.3)*(26.003)))+(72.589)+(38.343))/((0.1)));

}
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (11.934*(3.57)*(segmentsAcked)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(95.705)*(60.978));

} else {
	tcb->m_cWnd = (int) (((0.1)+(52.415)+(59.339)+(0.1)+(59.978)+(22.539)+((21.29+(92.657)+(99.634)))+(0.1))/((53.961)));
	tcb->m_ssThresh = (int) (16.477-(53.131)-(23.084)-(segmentsAcked)-(tcb->m_cWnd)-(tcb->m_segmentSize));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (86.675-(15.172)-(22.966)-(34.351)-(32.921)-(35.455)-(tcb->m_cWnd)-(segmentsAcked));
