int tfogEiIsAluSMVFU = (int) (3.93+(13.495)+(50.302)+(98.214)+(41.082)+(-23.13)+(-82.308));
int HyxJBINEZXQegGGW = (int) (51.853-(86.512)-(-86.258)-(8.827)-(-30.868)-(-88.896));
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_cWnd = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (42.194-(4.13)-(2.074)-(66.536)-(HyxJBINEZXQegGGW)-(47.064)-(75.8)-(41.442)-(segmentsAcked));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
HyxJBINEZXQegGGW = (int) (-25.577-(15.266)-(83.012)-(-38.478)-(-67.468)-(-3.901)-(-26.855)-(-55.261)-(-11.381));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
