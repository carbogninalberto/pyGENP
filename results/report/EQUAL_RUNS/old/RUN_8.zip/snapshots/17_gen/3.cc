TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float lyeJFOhzcbXeFfIB = (float) 2.589;
segmentsAcked = (int) (((67.684)+(-63.851)+(-11.926)+(-55.014))/((-50.37)+(-40.354)+(7.994)));
ReduceCwnd (tcb);
if (tcb->m_cWnd >= lyeJFOhzcbXeFfIB) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(lyeJFOhzcbXeFfIB)*(75.694)*(77.965)*(tcb->m_cWnd));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (20.596-(0.229)-(0.867)-(38.659));

} else {
	tcb->m_segmentSize = (int) (48.054-(51.984));
	ReduceCwnd (tcb);

}
