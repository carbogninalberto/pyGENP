CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-35.163*(12.789)*(90.721)*(-64.196)*(-3.058)*(55.398)*(17.437)*(47.851)*(-95.102));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (72.878*(-75.896)*(96.548)*(65.657)*(-81.868)*(-64.715));
