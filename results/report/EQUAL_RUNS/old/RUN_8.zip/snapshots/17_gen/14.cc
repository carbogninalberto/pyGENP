if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (43.144*(26.04)*(60.548)*(32.016)*(16.974));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (77.658+(76.431)+(30.508)+(11.231)+(69.828)+(28.517)+(83.684)+(59.703));

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh >= segmentsAcked) {
	segmentsAcked = (int) (tcb->m_segmentSize+(53.966)+(69.178)+(tcb->m_ssThresh)+(8.446)+(85.928)+(70.488));
	segmentsAcked = (int) (20.02+(tcb->m_cWnd)+(tcb->m_segmentSize)+(segmentsAcked));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (tcb->m_cWnd*(31.642)*(72.653)*(77.215)*(55.939)*(tcb->m_cWnd)*(tcb->m_cWnd));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (36.133*(5.092));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (73.319-(6.201)-(8.047)-(26.546)-(71.777));
