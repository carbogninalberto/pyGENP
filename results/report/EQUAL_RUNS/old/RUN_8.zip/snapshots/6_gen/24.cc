tcb->m_ssThresh = (int) (52.561+(59.873)+(42.735)+(72.936));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (99.711*(segmentsAcked));

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(71.81)+(29.385))/((0.1)+(0.1)));
	segmentsAcked = (int) (61.412+(63.504)+(11.488)+(tcb->m_ssThresh)+(46.031)+(84.832));
	tcb->m_cWnd = (int) (10.848-(4.066)-(48.78));

}
tcb->m_segmentSize = (int) (64.531-(84.163)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(36.571)-(23.613)-(63.834));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (segmentsAcked+(40.861)+(36.345)+(6.852));

} else {
	tcb->m_segmentSize = (int) ((((86.341-(14.068)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(87.437)-(79.816)-(57.321)))+(0.1)+(11.888)+(0.1))/((0.1)+(33.244)+(0.1)));
	tcb->m_ssThresh = (int) (59.282+(27.584)+(52.284)+(81.451)+(49.693)+(15.148)+(21.254));
	segmentsAcked = (int) (44.824-(39.833));

}
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_segmentSize = (int) (5.128+(24.871)+(17.686));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (0.1/31.31);

} else {
	tcb->m_segmentSize = (int) ((tcb->m_ssThresh+(62.944))/91.263);

}
tcb->m_ssThresh = (int) (((3.446)+(0.1)+(0.1)+(0.1))/((30.245)+(95.698)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_cWnd) {
	segmentsAcked = (int) (97.911+(tcb->m_ssThresh)+(71.194)+(94.473)+(42.021));
	tcb->m_ssThresh = (int) (50.489+(39.363)+(tcb->m_cWnd)+(66.626)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(60.383)+(13.369));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (91.269-(36.703)-(tcb->m_cWnd)-(42.026)-(77.738)-(tcb->m_cWnd)-(92.318)-(54.335)-(56.66));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
