TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (43.562*(-54.39));
tcb->m_segmentSize = (int) (-47.61*(-12.484));
segmentsAcked = (int) (((3.314)+(96.445)+(-27.255)+(-53.005)+(28.801))/((4.23)));
segmentsAcked = (int) (((21.698)+(93.167)+(88.257)+(-18.373)+(0.179))/((23.949)));
