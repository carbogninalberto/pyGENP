float QZqeURUzQvLtpiXG = (float) (-32.838+(-96.102)+(-60.623)+(95.879)+(-78.244)+(-22.251));
float MLgJLJzibLmYTEYu = (float) (81.327*(70.095)*(-88.495)*(23.293));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-48.277*(13.442));
tcb->m_segmentSize = (int) (57.482*(-77.433));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (93.118*(-44.955));
tcb->m_segmentSize = (int) (0.17*(-92.533));
