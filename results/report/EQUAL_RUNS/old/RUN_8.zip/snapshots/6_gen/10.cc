float ERnDofRXJbBchLXP = (float) (69.212+(-20.869)+(53.245)+(55.088)+(6.872)+(42.085)+(-60.235)+(-99.778)+(43.587));
float oXLyOWWaWwMYAECH = (float) (44.296*(-98.267)*(7.682)*(-78.234));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
