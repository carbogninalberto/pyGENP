ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (5.779*(-3.085));
tcb->m_segmentSize = (int) (-88.136*(91.864));
segmentsAcked = (int) (((61.683)+(16.772)+(27.46)+(55.142)+(47.634))/((-86.392)));
segmentsAcked = (int) (((-24.919)+(85.772)+(2.48)+(-97.758)+(-1.669))/((-25.005)));
segmentsAcked = (int) (((-5.424)+(-60.567)+(94.124)+(22.334)+(-98.177))/((-99.384)));
