CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-61.715*(-91.709)*(52.087)*(-32.779)*(78.414)*(-23.495)*(-51.767)*(83.758)*(-74.58));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (94.584*(97.336)*(66.638)*(-6.242)*(-27.504)*(-35.529));
