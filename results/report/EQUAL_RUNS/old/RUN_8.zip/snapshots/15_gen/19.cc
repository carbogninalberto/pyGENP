ReduceCwnd (tcb);
tcb->m_cWnd = (int) (92.61*(tcb->m_ssThresh)*(21.562));
tcb->m_cWnd = (int) (60.186*(99.73)*(99.389)*(34.457)*(58.94)*(19.668)*(82.195));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (segmentsAcked+(tcb->m_segmentSize)+(67.152));

} else {
	tcb->m_segmentSize = (int) (95.162+(58.575)+(34.823)+(segmentsAcked)+(32.753)+(32.268)+(6.134)+(tcb->m_segmentSize));

}
