float bxKzTRdNTIxNvNiM = (float) (((-12.223)+(-98.63)+(-40.902)+(23.368)+(-72.322))/((47.222)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-40.334-(46.273)-(58.66)-(19.008));
segmentsAcked = SlowStart (tcb, segmentsAcked);
