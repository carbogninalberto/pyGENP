CongestionAvoidance (tcb, segmentsAcked);
int CmiqekSZsRAeCSnB = (int) (-0.626*(-40.985)*(4.938)*(55.493)*(25.702)*(-69.688)*(-18.466)*(-57.829));
tcb->m_cWnd = (int) (49.147*(-83.799)*(-41.816)*(-16.35)*(54.194)*(-23.147)*(1.249)*(87.356)*(82.542));
if (tcb->m_segmentSize != segmentsAcked) {
	segmentsAcked = (int) (-87.378*(79.734)*(48.831)*(41.002)*(67.663));
	segmentsAcked = (int) (62.895+(75.303)+(5.967)+(68.08)+(segmentsAcked)+(79.072)+(41.841));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (93.625-(48.031));

}
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (21.733*(20.686)*(72.131)*(-11.358)*(-72.253)*(-45.93));
tcb->m_cWnd = (int) (-45.439*(84.823)*(48.765)*(1.135)*(-48.441)*(87.206)*(-71.552)*(86.502)*(74.743));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (9.439*(-31.469)*(-18.88)*(47.634)*(-53.375)*(-99.581));
