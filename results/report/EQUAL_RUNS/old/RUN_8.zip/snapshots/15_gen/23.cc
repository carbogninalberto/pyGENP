segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
float FaxpsQMTPmvSaOcJ = (float) ((11.597+(88.116)+(62.442)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(71.675)+(23.164))/37.126);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
FaxpsQMTPmvSaOcJ = (float) (((66.503)+((FaxpsQMTPmvSaOcJ*(5.851)*(9.206)*(78.699)*(48.454)*(5.079)))+(0.1)+(0.1)+(0.1)+(0.1)+(53.921))/((0.1)));
