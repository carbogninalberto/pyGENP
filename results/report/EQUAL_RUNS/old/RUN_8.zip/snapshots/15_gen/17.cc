segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (5.055-(79.02)-(76.683)-(27.576)-(2.134)-(64.808)-(59.023)-(99.378));
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (90.655+(segmentsAcked)+(segmentsAcked));
	tcb->m_segmentSize = (int) (0.1/(67.431*(tcb->m_cWnd)*(27.261)*(6.766)*(42.253)*(1.001)*(80.041)));
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+((76.928+(tcb->m_segmentSize)+(15.143)+(17.922)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(30.97)+(29.185)))+(43.935)+(13.732)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked*(89.937)*(71.376)*(tcb->m_cWnd)*(50.335)*(tcb->m_ssThresh));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (24.26+(6.214)+(85.584)+(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (99.524*(61.359)*(tcb->m_ssThresh)*(segmentsAcked)*(30.022)*(tcb->m_segmentSize)*(93.707));

}
