float ERnDofRXJbBchLXP = (float) (98.147+(72.622)+(93.534)+(36.798)+(25.552)+(-67.455)+(75.332)+(4.187)+(33.427));
float oXLyOWWaWwMYAECH = (float) (31.893*(53.876)*(46.44)*(-59.014));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
