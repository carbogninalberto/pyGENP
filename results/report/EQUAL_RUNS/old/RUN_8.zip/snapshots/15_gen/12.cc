segmentsAcked = (int) ((20.092+(tcb->m_ssThresh))/5.925);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (97.666+(81.424)+(95.157));
	tcb->m_segmentSize = (int) (18.018*(tcb->m_cWnd)*(99.944));

} else {
	tcb->m_ssThresh = (int) (47.211-(62.535)-(9.815)-(tcb->m_cWnd)-(24.481)-(79.476)-(56.537)-(97.979));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (61.569*(52.04));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
