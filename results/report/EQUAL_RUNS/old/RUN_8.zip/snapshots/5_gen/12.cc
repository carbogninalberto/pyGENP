segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-60.194/-76.842);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
