float ERnDofRXJbBchLXP = (float) (47.915+(69.957)+(85.821)+(-5.448)+(-26.312)+(88.57)+(-87.854)+(-26.668)+(79.621));
float oXLyOWWaWwMYAECH = (float) (-60.711*(58.652)*(-65.954)*(-27.432));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
