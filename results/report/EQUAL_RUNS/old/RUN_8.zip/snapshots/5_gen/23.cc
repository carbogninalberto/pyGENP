if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (78.118+(52.985)+(54.584)+(48.484)+(46.847)+(75.611)+(92.028)+(70.12));

} else {
	segmentsAcked = (int) ((83.218+(1.547)+(73.616))/0.1);
	segmentsAcked = (int) (83.517-(85.777)-(96.447));

}
float cMrCwKdVFInUwGAG = (float) ((-48.092*(23.74)*(49.322)*(-66.117))/31.445);
tcb->m_cWnd = (int) (-97.88-(-58.119)-(-14.08)-(73.948));
float vSSfxVuTvcEGlvTM = (float) (17.77+(-79.938)+(-25.478)+(79.826)+(-97.46)+(-96.284)+(29.506)+(-99.361));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-72.773-(41.142)-(-21.961)-(-22.805));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (23.683-(-19.481)-(-75.614)-(-20.332));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-89.834-(-9.539)-(35.962)-(-84.242));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-19.971-(-96.216)-(52.707)-(10.367));
ReduceCwnd (tcb);
