float LCHIrKconykNVUXy = (float) (10.301-(-19.531));
