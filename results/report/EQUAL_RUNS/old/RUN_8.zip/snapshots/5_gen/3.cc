int GFHiKannrYnTAhHL = (int) 48.41;
segmentsAcked = (int) (-24.91/21.123);
