if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (78.118+(52.985)+(54.584)+(48.484)+(46.847)+(75.611)+(92.028)+(70.12));

} else {
	segmentsAcked = (int) ((83.218+(1.547)+(73.616))/0.1);
	segmentsAcked = (int) (83.517-(85.777)-(96.447));

}
float cMrCwKdVFInUwGAG = (float) ((77.619*(-73.666)*(10.957)*(-53.032))/-5.95);
ReduceCwnd (tcb);
float vSSfxVuTvcEGlvTM = (float) (57.233+(16.135)+(4.916)+(-7.6)+(-63.375)+(-67.424)+(-73.9)+(6.121));
tcb->m_cWnd = (int) (57.34-(16.974)-(-32.729)-(-70.168));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (0.356-(61.862)-(56.212)-(-24.723));
ReduceCwnd (tcb);
