float vSSfxVuTvcEGlvTM = (float) (8.063+(6.507)+(75.419)+(-46.777)+(-5.654)+(-20.855)+(55.689)+(-15.056));
float cMrCwKdVFInUwGAG = (float) ((70.771*(-15.821)*(18.943)*(-42.117))/18.779);
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (78.118+(52.985)+(54.584)+(48.484)+(46.847)+(75.611)+(92.028)+(70.12));

} else {
	segmentsAcked = (int) ((83.218+(1.547)+(73.616))/0.1);
	segmentsAcked = (int) (83.517-(85.777)-(96.447));

}
tcb->m_cWnd = (int) (-61.863-(70.154)-(-91.486)-(-79.446));
ReduceCwnd (tcb);
