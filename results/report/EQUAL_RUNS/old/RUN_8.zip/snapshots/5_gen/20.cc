segmentsAcked = (int) (-61.353/13.854);
ReduceCwnd (tcb);
int GFHiKannrYnTAhHL = (int) 53.4;
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
