if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) ((83.218+(1.547)+(73.616))/0.1);
	segmentsAcked = (int) (83.517-(85.777)-(96.447));

} else {
	segmentsAcked = (int) (78.118+(52.985)+(54.584)+(48.484)+(46.847)+(75.611)+(92.028)+(70.12));

}
float cMrCwKdVFInUwGAG = (float) ((82.106*(28.353)*(50.075)*(-4.262))/30.47);
ReduceCwnd (tcb);
float vSSfxVuTvcEGlvTM = (float) (-68.782+(-50.533)+(15.364)+(73.764)+(90.745)+(-57.135)+(-56.763)+(-62.568));
tcb->m_cWnd = (int) (28.743-(25.227)-(-56.371)-(4.081));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (20.728-(52.415)-(-18.869)-(16.349));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (83.454-(-53.422)-(34.095)-(94.157));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (16.727-(-11.937)-(-31.288)-(7.95));
ReduceCwnd (tcb);
