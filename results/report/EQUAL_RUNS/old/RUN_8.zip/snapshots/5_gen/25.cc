float ERnDofRXJbBchLXP = (float) (26.287+(-41.181)+(31.428)+(83.655)+(-85.44)+(48.129)+(30.893)+(8.91)+(-2.758));
float oXLyOWWaWwMYAECH = (float) (47.931*(-33.773)*(43.537)*(-47.305));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
