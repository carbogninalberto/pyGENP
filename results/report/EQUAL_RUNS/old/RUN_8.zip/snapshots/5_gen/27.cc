float ERnDofRXJbBchLXP = (float) (45.961+(45.945)+(21.771)+(-59.641)+(-5.666)+(-36.435)+(-25.778)+(17.033)+(-43.267));
float oXLyOWWaWwMYAECH = (float) (-58.68*(22.27)*(-76.728)*(32.923));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
