float ERnDofRXJbBchLXP = (float) (-31.256+(53.954)+(-62.031)+(78.292)+(19.542)+(17.392)+(21.804)+(-8.171)+(-41.536));
float oXLyOWWaWwMYAECH = (float) (-71.181*(36.67)*(63.291)*(-69.921));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
