float ERnDofRXJbBchLXP = (float) (85.089+(8.836)+(-99.404)+(92.093)+(24.858)+(77.731)+(-79.928)+(48.268)+(92.547));
float oXLyOWWaWwMYAECH = (float) (49.589*(17.708)*(-73.911)*(-20.051));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
