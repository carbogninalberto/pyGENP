float QJXPBdawSXTFlaUN = (float) (-88.377/38.601);
float YrrtBBvUeOBwhfYY = (float) (42.74+(-74.813)+(88.263)+(-39.888)+(-91.047)+(-84.62)+(-12.926)+(1.095)+(-84.726));
