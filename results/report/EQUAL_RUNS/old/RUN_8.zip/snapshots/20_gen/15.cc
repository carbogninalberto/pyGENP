ReduceCwnd (tcb);
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_cWnd = (int) (87.402/(69.177+(56.799)+(51.754)+(52.253)));

} else {
	tcb->m_cWnd = (int) (3.608+(59.116)+(0.04)+(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (66.417/86.895);

}
if (segmentsAcked <= segmentsAcked) {
	segmentsAcked = (int) (37.968/(21.604*(75.484)*(tcb->m_ssThresh)*(67.432)*(31.282)*(91.932)));
	tcb->m_cWnd = (int) (6.252*(5.274)*(55.516)*(3.434)*(segmentsAcked)*(99.536));

} else {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (22.646/0.1);
	segmentsAcked = (int) (((10.162)+(30.677)+(0.1)+(40.132)+(0.1))/((14.5)+(3.341)+(0.1)+(0.1)));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (91.163/75.368);

} else {
	tcb->m_segmentSize = (int) (58.366*(54.27)*(70.264)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(22.212)*(tcb->m_ssThresh)*(95.604));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (51.793+(50.0)+(0.947)+(11.852)+(21.649));
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_ssThresh = (int) (37.444+(61.955)+(3.146)+(tcb->m_cWnd)+(80.342));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(33.379)-(39.271)-(83.306)-(49.944)-(85.447));
	tcb->m_segmentSize = (int) (84.928/43.623);

}
