if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_segmentSize = (int) (6.708-(14.976)-(94.601)-(47.565));
	segmentsAcked = (int) (87.044-(0.335)-(segmentsAcked)-(42.808)-(60.424)-(51.954)-(34.611)-(63.692)-(18.284));
	segmentsAcked = (int) (6.017-(41.882)-(tcb->m_ssThresh)-(22.752)-(43.444)-(38.92)-(81.002)-(tcb->m_ssThresh)-(42.623));

} else {
	tcb->m_segmentSize = (int) (16.635*(7.34));

}
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(segmentsAcked)*(83.508)*(8.294));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (0.1/3.937);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (15.681-(segmentsAcked)-(97.322)-(1.295)-(15.234)-(86.673)-(22.558));

}
float PqQdvBRxmKNumkKp = (float) (12.745-(tcb->m_ssThresh)-(45.701)-(29.598)-(1.026)-(tcb->m_segmentSize));
if (PqQdvBRxmKNumkKp < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (94.645+(14.375)+(71.598)+(7.931)+(67.011)+(64.007)+(21.907)+(40.785)+(66.24));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (10.102*(90.612)*(11.41)*(segmentsAcked)*(95.058)*(30.175)*(2.389));

} else {
	tcb->m_segmentSize = (int) (82.47-(90.165)-(48.791)-(69.363)-(52.242)-(2.461));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (92.748+(98.234)+(85.511)+(tcb->m_ssThresh));
if (PqQdvBRxmKNumkKp != segmentsAcked) {
	tcb->m_cWnd = (int) (15.052*(92.895)*(71.727)*(25.397));
	segmentsAcked = (int) (8.185+(2.051)+(33.91)+(58.176)+(tcb->m_ssThresh));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (90.091+(85.588)+(PqQdvBRxmKNumkKp));

}
