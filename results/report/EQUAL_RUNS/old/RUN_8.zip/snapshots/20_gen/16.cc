CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_ssThresh+(tcb->m_segmentSize));
tcb->m_ssThresh = (int) (58.404-(tcb->m_ssThresh)-(7.48));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.172+(82.524)+(84.594)+(23.451)+(92.28)+(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (64.848+(92.59)+(10.992)+(7.198)+(tcb->m_cWnd)+(19.201)+(25.539));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(39.898)-(segmentsAcked)-(tcb->m_segmentSize)-(56.596)-(64.741));
	tcb->m_ssThresh = (int) (34.643-(22.952)-(21.061)-(96.343)-(69.721)-(segmentsAcked)-(83.83));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_cWnd > tcb->m_cWnd) {
	segmentsAcked = (int) (((23.826)+(71.951)+(27.105)+(32.929))/((76.36)));

} else {
	segmentsAcked = (int) (9.46*(61.019)*(75.058)*(66.397)*(tcb->m_ssThresh)*(95.716)*(94.125)*(50.966));
	tcb->m_cWnd = (int) (37.384*(tcb->m_ssThresh)*(35.592)*(23.92)*(73.97));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (66.921*(29.841)*(tcb->m_segmentSize)*(46.843)*(29.655));
	segmentsAcked = (int) (15.051-(0.17)-(96.097)-(16.256)-(56.166)-(94.98)-(38.118));

} else {
	tcb->m_segmentSize = (int) (77.81*(18.098)*(66.723));
	segmentsAcked = (int) (0.1/0.1);

}
