tcb->m_segmentSize = (int) (93.598/0.1);
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (30.88-(49.032)-(91.903)-(73.564)-(99.835));
	segmentsAcked = (int) (((0.1)+(16.474)+(0.1)+(0.1))/((39.65)+(0.1)+(54.041)+(50.669)));

} else {
	tcb->m_ssThresh = (int) (48.412-(85.835)-(63.163)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(74.818));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (27.153+(tcb->m_segmentSize)+(31.049)+(17.58)+(12.406)+(80.821));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (74.791+(96.106)+(31.182)+(88.571)+(77.219)+(22.363)+(66.435)+(54.132));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (88.699/(12.784-(tcb->m_ssThresh)-(31.817)-(68.665)-(99.699)));
tcb->m_segmentSize = (int) ((((58.112+(7.36)+(96.129)+(tcb->m_ssThresh)+(82.236)))+((tcb->m_cWnd-(41.556)-(27.294)-(58.12)-(tcb->m_segmentSize)-(48.374)))+(0.1)+(27.271))/((0.1)+(61.261)));
