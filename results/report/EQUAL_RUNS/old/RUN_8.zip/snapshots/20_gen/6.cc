int IXwdayXckogAgEpl = (int) 82.263;
