if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (4.893-(segmentsAcked)-(96.576)-(tcb->m_ssThresh)-(81.789)-(26.666));

} else {
	tcb->m_ssThresh = (int) (29.692+(35.598));
	tcb->m_ssThresh = (int) (0.603*(32.495)*(8.769)*(34.424)*(segmentsAcked)*(segmentsAcked)*(70.905));

}
float pRRSZZTCNlMJoSbO = (float) (((0.1)+((33.839-(81.436)-(80.897)-(94.076)-(32.226)-(29.788)))+(0.1)+((35.117*(48.036)*(segmentsAcked)*(19.315)*(13.759)))+(7.286))/((0.1)+(0.1)+(19.499)+(61.611)));
int RsnHgKwxrAqrEzTu = (int) (68.405/0.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_ssThresh) {
	RsnHgKwxrAqrEzTu = (int) (12.299-(65.169)-(segmentsAcked)-(31.319)-(3.815));
	tcb->m_segmentSize = (int) (39.035-(77.284)-(60.086)-(43.367)-(31.081)-(70.032)-(87.507)-(RsnHgKwxrAqrEzTu));
	pRRSZZTCNlMJoSbO = (float) (RsnHgKwxrAqrEzTu*(90.325));

} else {
	RsnHgKwxrAqrEzTu = (int) (2.322/32.046);
	RsnHgKwxrAqrEzTu = (int) (((89.579)+((21.659-(tcb->m_segmentSize)-(RsnHgKwxrAqrEzTu)-(segmentsAcked)-(47.083)-(75.63)-(99.266)-(RsnHgKwxrAqrEzTu)))+(0.1)+(28.788)+(0.1)+(87.02))/((23.465)));
	tcb->m_ssThresh = (int) (80.812*(77.361)*(tcb->m_ssThresh)*(10.293)*(63.84)*(15.106)*(tcb->m_cWnd)*(43.869)*(segmentsAcked));

}
