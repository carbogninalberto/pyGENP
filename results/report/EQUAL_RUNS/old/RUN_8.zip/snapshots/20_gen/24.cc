if (tcb->m_segmentSize < tcb->m_ssThresh) {
	segmentsAcked = (int) (32.664+(tcb->m_segmentSize)+(tcb->m_cWnd)+(44.777)+(54.731)+(27.044)+(tcb->m_segmentSize)+(6.78));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(23.039)*(85.17)*(69.37));
	segmentsAcked = (int) ((76.056+(96.394)+(tcb->m_segmentSize)+(47.429)+(19.746)+(22.408)+(22.619)+(78.772)+(60.7))/0.1);

} else {
	segmentsAcked = (int) ((40.301+(46.745)+(97.878)+(tcb->m_ssThresh)+(52.81))/4.686);
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (tcb->m_ssThresh+(70.806)+(19.065)+(53.087)+(tcb->m_ssThresh)+(56.327)+(92.902));
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (3.346/(12.022*(tcb->m_cWnd)*(44.924)*(57.148)*(42.969)*(94.509)*(66.706)*(tcb->m_cWnd)));
	segmentsAcked = (int) (69.069*(98.724)*(27.801)*(69.769)*(tcb->m_segmentSize)*(26.212));
	tcb->m_ssThresh = (int) (56.612+(tcb->m_cWnd)+(56.469)+(49.206)+(27.844)+(80.212)+(segmentsAcked)+(42.181));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (70.946-(29.329)-(tcb->m_ssThresh)-(62.818)-(4.101));

}
tcb->m_segmentSize = (int) (segmentsAcked-(69.614)-(80.433)-(22.048)-(45.469)-(47.818)-(tcb->m_ssThresh));
segmentsAcked = SlowStart (tcb, segmentsAcked);
