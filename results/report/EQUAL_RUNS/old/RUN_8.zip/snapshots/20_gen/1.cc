tcb->m_cWnd = (int) (-32.17/44.296);
tcb->m_segmentSize = (int) (42.916/-54.307);
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (12.847/69.708);
	segmentsAcked = (int) (42.908-(93.914)-(31.061)-(tcb->m_cWnd)-(98.511)-(20.759)-(34.0));
	tcb->m_segmentSize = (int) (92.514*(65.937)*(72.03)*(21.08)*(98.824)*(6.883));

} else {
	segmentsAcked = (int) (0.1/45.78);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (72.53*(tcb->m_cWnd)*(84.557)*(10.369)*(69.225)*(segmentsAcked));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (95.164-(segmentsAcked)-(71.277)-(35.317)-(99.464)-(44.824)-(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (97.977*(49.379)*(97.259)*(0.654)*(11.04)*(15.097)*(89.181)*(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (12.361+(71.361)+(97.426)+(8.29)+(23.011)+(34.018)+(-57.625)+(7.326)+(16.062));

}
