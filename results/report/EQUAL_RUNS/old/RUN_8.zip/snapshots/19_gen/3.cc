int foRmFdfBFsAOZnDw = (int) (71.139*(-60.541)*(27.053)*(-61.112)*(40.605)*(91.091)*(16.789));
int oKSlqbhuAwnfCoMj = (int) (-48.689/24.106);
tcb->m_cWnd = (int) (-83.583+(87.372));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
