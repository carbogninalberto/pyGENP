float MResjBZLqmIvRJwx = (float) (85.247/39.675);
CongestionAvoidance (tcb, segmentsAcked);
int CzLWDRNFUNyLgnlw = (int) (36.32-(96.864)-(-90.92)-(44.754)-(-7.94)-(36.423)-(-34.178));
segmentsAcked = (int) (50.673-(2.832)-(-91.035)-(-53.645));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-50.832-(63.332)-(-28.21)-(46.767));
