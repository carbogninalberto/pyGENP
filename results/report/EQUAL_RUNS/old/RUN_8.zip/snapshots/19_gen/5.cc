tcb->m_segmentSize = (int) (((-7.588)+(38.733)+(-3.427)+(16.32)+(-73.254)+(-70.486)+(-85.761))/((-58.589)+(-52.427)));
float MResjBZLqmIvRJwx = (float) 46.695;
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-59.487-(65.253)-(-20.589)-(40.035));
