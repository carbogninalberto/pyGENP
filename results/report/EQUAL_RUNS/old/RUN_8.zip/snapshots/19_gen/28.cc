segmentsAcked = (int) (74.13-(82.159)-(91.633)-(37.433)-(tcb->m_segmentSize));
segmentsAcked = (int) (0.1/86.326);
segmentsAcked = (int) (66.09-(80.557)-(tcb->m_segmentSize)-(94.665)-(91.591)-(95.543)-(57.66)-(86.664));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_ssThresh = (int) (82.363-(38.568));

} else {
	tcb->m_ssThresh = (int) (72.875+(88.861)+(94.245)+(34.428)+(11.841)+(26.023)+(11.397)+(77.7)+(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(65.899)-(17.378));

}
int IXwdayXckogAgEpl = (int) (96.959*(81.28)*(41.422)*(77.007)*(23.077)*(24.413));
if (tcb->m_segmentSize > IXwdayXckogAgEpl) {
	tcb->m_segmentSize = (int) (47.95+(47.853)+(45.654)+(48.97));
	segmentsAcked = (int) (56.985-(tcb->m_ssThresh)-(33.112)-(79.373)-(86.076)-(96.915));
	tcb->m_cWnd = (int) (97.122*(69.94)*(62.65)*(96.277)*(28.164)*(89.743));

} else {
	tcb->m_segmentSize = (int) ((86.394-(78.094)-(26.724)-(49.583)-(16.615)-(27.962)-(26.033)-(17.666))/27.285);

}
