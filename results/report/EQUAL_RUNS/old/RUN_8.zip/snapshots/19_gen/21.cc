if (segmentsAcked < segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(tcb->m_cWnd)+(35.037)+(79.721)+(41.302)+(5.756));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (46.802-(54.946)-(80.365)-(tcb->m_cWnd)-(83.92));

}
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (61.266+(segmentsAcked)+(7.688)+(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (56.791*(13.44)*(segmentsAcked)*(tcb->m_cWnd));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (30.519*(90.651)*(27.381));
	segmentsAcked = (int) (27.27/41.357);

} else {
	segmentsAcked = (int) (98.832-(24.947)-(44.78)-(segmentsAcked)-(39.83)-(84.396)-(15.072)-(88.879));
	tcb->m_segmentSize = (int) (22.848+(7.791)+(9.811)+(2.531)+(31.906));

}
tcb->m_segmentSize = (int) (35.347-(tcb->m_ssThresh));
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(8.573));
	tcb->m_cWnd = (int) (17.222*(53.867)*(97.412)*(63.592)*(15.318));
	segmentsAcked = (int) (51.543+(48.129)+(segmentsAcked)+(76.786)+(segmentsAcked)+(10.916)+(2.136)+(98.817));

} else {
	tcb->m_ssThresh = (int) (57.486-(7.366)-(tcb->m_ssThresh));

}
segmentsAcked = (int) (2.828+(38.114)+(67.211));
CongestionAvoidance (tcb, segmentsAcked);
