segmentsAcked = (int) (-15.466-(-46.908)-(-45.277));
