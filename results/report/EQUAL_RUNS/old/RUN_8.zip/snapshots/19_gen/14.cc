ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (segmentsAcked+(tcb->m_ssThresh)+(33.127)+(73.515)+(38.766)+(42.72));
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (segmentsAcked+(99.697)+(59.76)+(61.466)+(87.906)+(27.321));
	tcb->m_segmentSize = (int) (67.542-(16.757)-(76.715)-(99.93)-(41.414)-(59.43)-(95.862)-(48.802));

} else {
	tcb->m_ssThresh = (int) (11.775*(93.335)*(39.793)*(69.954)*(32.514)*(89.803)*(segmentsAcked));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (8.018*(20.088)*(1.765)*(tcb->m_segmentSize)*(74.717)*(45.024)*(50.447)*(77.789));
tcb->m_segmentSize = (int) (62.986+(78.624)+(29.845)+(tcb->m_cWnd));
tcb->m_ssThresh = (int) (tcb->m_ssThresh-(36.867)-(21.08)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(81.919));
segmentsAcked = SlowStart (tcb, segmentsAcked);
