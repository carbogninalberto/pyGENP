float vfkVBsUZUhsbGyTn = (float) (((0.1)+(0.1)+(0.1)+(87.549))/((0.1)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_cWnd = (int) (92.987+(91.21)+(26.439)+(36.441)+(16.681)+(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);

}
tcb->m_segmentSize = (int) (40.737+(14.07)+(32.852)+(75.993)+(65.012)+(segmentsAcked)+(82.447));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float velAzGfbDtjXxeAe = (float) (vfkVBsUZUhsbGyTn*(98.033));
if (tcb->m_segmentSize >= segmentsAcked) {
	velAzGfbDtjXxeAe = (float) (tcb->m_segmentSize-(41.35)-(segmentsAcked)-(90.006)-(61.691)-(tcb->m_segmentSize)-(38.391)-(88.238));
	vfkVBsUZUhsbGyTn = (float) (37.248+(52.821)+(6.275)+(17.988)+(59.663)+(38.981)+(68.099));
	segmentsAcked = (int) (tcb->m_segmentSize+(15.419)+(25.225)+(76.372)+(60.865)+(tcb->m_segmentSize)+(64.689)+(64.968)+(83.247));

} else {
	velAzGfbDtjXxeAe = (float) (96.847*(79.343)*(86.314)*(56.364)*(42.085)*(30.188)*(tcb->m_segmentSize)*(63.591));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (velAzGfbDtjXxeAe-(51.486)-(40.505)-(segmentsAcked));

}
tcb->m_ssThresh = (int) (58.551-(9.498)-(52.74)-(25.219)-(64.143));
CongestionAvoidance (tcb, segmentsAcked);
