CongestionAvoidance (tcb, segmentsAcked);
float IJeTSufbbYcyYSHq = (float) (-87.122-(-18.935)-(-25.489)-(-63.757)-(26.634));
ReduceCwnd (tcb);
int DajfqveGjjMKlQHc = (int) (44.403-(-6.08)-(20.464)-(-45.989)-(16.695));
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (((0.1)+(99.511)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));

} else {
	segmentsAcked = (int) (0.1/2.939);
	tcb->m_cWnd = (int) (93.821+(65.696)+(15.488));

}
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (((0.1)+(99.511)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));

} else {
	segmentsAcked = (int) (0.1/2.939);
	tcb->m_cWnd = (int) (93.821+(65.696)+(15.488));

}
IJeTSufbbYcyYSHq = (float) (10.308*(-25.524)*(-43.813)*(-45.33)*(63.12));
IJeTSufbbYcyYSHq = (float) (58.066*(-20.737)*(-73.966)*(69.694)*(-84.917));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
