int dcdqjLOFKiuJIOhh = (int) 47.567;
ReduceCwnd (tcb);
