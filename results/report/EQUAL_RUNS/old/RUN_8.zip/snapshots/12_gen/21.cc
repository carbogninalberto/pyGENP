tcb->m_ssThresh = (int) (33.409-(32.089)-(tcb->m_ssThresh)-(86.337));
tcb->m_segmentSize = (int) (0.1/1.511);
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(8.336)+(12.047)+(70.947)+(3.309))/((74.227)+(78.277)));
	tcb->m_ssThresh = (int) (67.391*(82.257)*(77.909));
	tcb->m_ssThresh = (int) (36.683-(74.509)-(77.957));

} else {
	segmentsAcked = (int) (segmentsAcked*(segmentsAcked)*(89.361)*(7.755)*(12.276)*(24.44)*(88.685));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (88.946-(77.178)-(9.473)-(95.476)-(65.769)-(95.72));

}
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (81.942+(65.708)+(66.916)+(tcb->m_ssThresh)+(41.852)+(77.768)+(26.981)+(86.444)+(80.932));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(1.729));

} else {
	tcb->m_cWnd = (int) (32.149+(10.197)+(9.437)+(34.757)+(19.852)+(98.76));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (9.119*(42.412)*(segmentsAcked)*(48.778));
