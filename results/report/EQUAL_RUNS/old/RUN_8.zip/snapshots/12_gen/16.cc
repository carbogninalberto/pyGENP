float ERnDofRXJbBchLXP = (float) (-94.234+(-3.528)+(58.8)+(39.959)+(-95.227)+(-39.702)+(-2.177)+(-13.276)+(-16.504));
float oXLyOWWaWwMYAECH = (float) (-1.124*(75.918)*(-81.71)*(-67.046));
CongestionAvoidance (tcb, segmentsAcked);
