float ERnDofRXJbBchLXP = (float) (-80.989+(-86.303)+(76.226)+(4.587)+(-42.777)+(50.224)+(68.858)+(7.104)+(-38.613));
float oXLyOWWaWwMYAECH = (float) (39.197*(21.462)*(-14.603)*(-73.8));
CongestionAvoidance (tcb, segmentsAcked);
