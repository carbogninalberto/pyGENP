float lQOgMFPinSstsxAj = (float) 93.345;
if (lQOgMFPinSstsxAj < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (46.874-(35.016)-(7.223)-(62.491)-(49.396)-(94.014)-(20.891)-(7.917));
	lQOgMFPinSstsxAj = (float) (23.257-(57.132)-(60.297)-(66.49)-(10.703)-(25.24)-(47.766)-(81.131));

} else {
	tcb->m_segmentSize = (int) (11.412-(69.11)-(84.252)-(tcb->m_cWnd)-(95.708)-(62.494)-(30.153)-(65.174));

}
if (tcb->m_cWnd <= tcb->m_cWnd) {
	segmentsAcked = (int) (34.997*(3.963)*(46.407)*(39.594)*(63.861)*(28.655)*(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) ((((48.696-(segmentsAcked)-(56.989)-(73.092)))+(85.205)+(0.1)+(0.1))/((89.81)+(0.1)));

}
if (segmentsAcked <= tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (51.624/49.942);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
