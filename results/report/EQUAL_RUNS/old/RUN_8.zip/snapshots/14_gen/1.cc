float ERnDofRXJbBchLXP = (float) (-30.595+(99.17)+(-71.035)+(-67.357)+(98.089)+(2.5)+(-99.749)+(-75.249)+(-96.362));
float oXLyOWWaWwMYAECH = (float) (-26.262*(-38.725)*(-50.001)*(-14.47));
CongestionAvoidance (tcb, segmentsAcked);
