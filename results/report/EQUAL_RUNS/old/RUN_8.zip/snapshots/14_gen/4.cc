if (tcb->m_segmentSize != segmentsAcked) {
	segmentsAcked = (int) (-87.378*(79.734)*(48.831)*(41.002)*(67.663));
	segmentsAcked = (int) (62.895+(75.303)+(5.967)+(68.08)+(segmentsAcked)+(79.072)+(41.841));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (93.625-(48.031));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (87.864*(92.148)*(23.728)*(71.388)*(-17.149)*(-98.606)*(41.705)*(-82.145)*(32.918));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-66.997*(-39.445)*(89.104)*(18.694)*(-58.088)*(-42.95));
