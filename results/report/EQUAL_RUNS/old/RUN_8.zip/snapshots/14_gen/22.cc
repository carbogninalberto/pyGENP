if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (87.319-(91.359)-(65.936)-(46.44)-(89.639)-(tcb->m_ssThresh)-(25.169)-(25.776)-(75.237));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (tcb->m_cWnd+(51.492)+(83.522)+(75.794)+(32.526));

} else {
	tcb->m_segmentSize = (int) (18.704+(35.25)+(30.62)+(segmentsAcked)+(34.467)+(85.494));

}
int xPNouLjGPzdjdsrN = (int) (90.699+(26.185)+(27.359)+(7.573));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
