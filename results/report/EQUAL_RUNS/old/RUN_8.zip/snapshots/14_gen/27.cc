if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((((0.363*(98.72)*(46.486)))+(21.616)+((8.211-(75.023)-(13.913)))+((16.173-(20.382)-(42.067)-(39.289)))+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (84.185*(27.043)*(tcb->m_segmentSize)*(48.771)*(98.881)*(45.212));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (30.571*(26.138)*(tcb->m_ssThresh)*(67.844)*(segmentsAcked)*(0.248)*(7.871)*(10.385)*(93.364));
	tcb->m_ssThresh = (int) (50.079-(15.519)-(67.171));

} else {
	tcb->m_ssThresh = (int) (2.15+(21.982)+(tcb->m_ssThresh)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) ((57.359-(62.788)-(0.853)-(18.558)-(24.448))/7.287);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((0.1)+(96.341)+(88.404)+(0.1)+(41.194)+(98.096)+(0.1)+(0.1))/((45.641)));
	tcb->m_ssThresh = (int) (51.977*(tcb->m_segmentSize)*(1.301)*(76.582)*(79.893)*(tcb->m_segmentSize)*(3.698)*(15.268)*(93.46));

} else {
	tcb->m_cWnd = (int) (40.51+(91.356)+(segmentsAcked)+(81.806)+(12.464)+(3.888)+(tcb->m_segmentSize)+(7.528)+(86.202));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (39.479*(74.919));
segmentsAcked = (int) (13.13*(tcb->m_ssThresh)*(19.511)*(tcb->m_cWnd)*(3.452)*(16.541)*(77.648)*(13.639));
