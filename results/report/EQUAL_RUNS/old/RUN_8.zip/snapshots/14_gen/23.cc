segmentsAcked = SlowStart (tcb, segmentsAcked);
float bxKzTRdNTIxNvNiM = (float) (((12.577)+(64.1)+(96.22)+(35.763)+(0.1))/((0.1)));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(83.926)*(95.142)*(88.04));

} else {
	tcb->m_ssThresh = (int) (2.369-(15.138)-(tcb->m_cWnd)-(83.702)-(88.886)-(49.497)-(18.757)-(tcb->m_cWnd)-(33.809));

}
tcb->m_segmentSize = (int) (88.157-(82.55)-(37.019)-(67.151));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	bxKzTRdNTIxNvNiM = (float) (98.759*(58.848)*(tcb->m_ssThresh)*(69.626)*(41.875)*(52.47));
	bxKzTRdNTIxNvNiM = (float) (96.336*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(67.765)*(tcb->m_segmentSize)*(78.945)*(tcb->m_ssThresh)*(92.852));

} else {
	bxKzTRdNTIxNvNiM = (float) (26.979*(42.549)*(84.408));
	tcb->m_ssThresh = (int) (63.635*(76.062)*(88.091)*(12.529)*(92.905)*(69.939)*(42.487)*(79.105));

}
