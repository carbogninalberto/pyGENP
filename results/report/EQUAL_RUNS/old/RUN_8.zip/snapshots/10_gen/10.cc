float ERnDofRXJbBchLXP = (float) (52.648+(93.715)+(-23.753)+(-55.724)+(-75.255)+(57.193)+(33.254)+(94.191)+(55.686));
float oXLyOWWaWwMYAECH = (float) (-42.111*(31.406)*(-22.176)*(-64.081));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
