CongestionAvoidance (tcb, segmentsAcked);
float IJeTSufbbYcyYSHq = (float) (-39.879-(-47.327)-(-7.04)-(-51.984)-(71.798));
ReduceCwnd (tcb);
int DajfqveGjjMKlQHc = (int) (92.007-(97.985)-(-16.183)-(-11.194)-(79.004));
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/2.939);
	tcb->m_cWnd = (int) (93.821+(65.696)+(15.488));

} else {
	segmentsAcked = (int) (((0.1)+(99.511)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));

}
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (((0.1)+(99.511)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));

} else {
	segmentsAcked = (int) (0.1/2.939);
	tcb->m_cWnd = (int) (93.821+(65.696)+(15.488));

}
IJeTSufbbYcyYSHq = (float) (-29.231*(-19.67)*(22.058)*(19.105)*(-63.828));
IJeTSufbbYcyYSHq = (float) (30.722*(-69.364)*(-85.263)*(-41.329)*(-55.704));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
