float lQOgMFPinSstsxAj = (float) (30.69+(tcb->m_segmentSize)+(37.19)+(80.371)+(77.078)+(42.58)+(70.274)+(segmentsAcked)+(tcb->m_ssThresh));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (87.226+(lQOgMFPinSstsxAj));

} else {
	tcb->m_ssThresh = (int) (84.971+(8.802)+(15.918)+(2.607)+(80.043));
	tcb->m_ssThresh = (int) (38.635/47.97);

}
if (lQOgMFPinSstsxAj < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (46.874-(35.016)-(7.223)-(62.491)-(49.396)-(tcb->m_ssThresh)-(20.891)-(7.917));
	lQOgMFPinSstsxAj = (float) (23.257-(57.132)-(60.297)-(66.49)-(10.703)-(25.24)-(47.766)-(81.131));

} else {
	tcb->m_segmentSize = (int) (11.412-(69.11)-(84.252)-(tcb->m_cWnd)-(95.708)-(62.494)-(tcb->m_ssThresh)-(65.174));

}
float uBKYGjjBieOKOYrf = (float) (29.548-(tcb->m_cWnd)-(65.417)-(79.838));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	segmentsAcked = (int) (34.997*(3.963)*(46.407)*(39.594)*(63.861)*(28.655)*(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) ((((48.696-(segmentsAcked)-(56.989)-(73.092)))+(85.205)+(0.1)+(0.1))/((89.81)+(0.1)));

}
if (uBKYGjjBieOKOYrf > tcb->m_ssThresh) {
	lQOgMFPinSstsxAj = (float) (segmentsAcked+(34.618)+(67.437));
	tcb->m_cWnd = (int) (lQOgMFPinSstsxAj+(74.718)+(tcb->m_cWnd)+(70.255)+(84.398)+(96.27)+(9.968));

} else {
	lQOgMFPinSstsxAj = (float) (8.631*(10.418)*(21.708)*(tcb->m_cWnd)*(24.031)*(55.828)*(93.674));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(91.623)-(28.658)-(54.12));
	tcb->m_ssThresh = (int) (9.169-(91.371));

}
if (segmentsAcked <= tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (51.624/49.942);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (10.596*(20.292)*(18.953)*(71.219)*(50.588));
