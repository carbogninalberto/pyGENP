CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (segmentsAcked*(89.838)*(93.842)*(57.174)*(76.553));
tcb->m_cWnd = (int) (0.1/45.09);
tcb->m_cWnd = (int) (89.03/47.054);
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_cWnd = (int) (79.234-(tcb->m_segmentSize)-(11.244)-(18.421)-(tcb->m_cWnd)-(tcb->m_segmentSize)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (((63.802)+(0.1)+(96.532)+(0.1)+(0.1))/((0.1)+(0.1)+(19.983)+(0.1)));

}
