ReduceCwnd (tcb);
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (97.201*(92.667)*(tcb->m_segmentSize)*(61.62));

} else {
	tcb->m_cWnd = (int) (17.737*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (91.049+(49.289)+(41.249)+(96.412)+(95.658)+(90.025)+(71.67));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	segmentsAcked = (int) (59.433+(86.763)+(41.405)+(5.304));
	tcb->m_ssThresh = (int) (98.727+(52.197)+(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) (13.858/39.034);
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (0.1/79.955);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (32.564-(60.727)-(72.822)-(91.864)-(tcb->m_segmentSize)-(52.801)-(1.969)-(30.772));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
