int dgDDWncjfAroLdJW = (int) (68.54-(84.198)-(10.082)-(89.723)-(tcb->m_ssThresh)-(22.778)-(30.199));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((11.973)+(14.891)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)));

} else {
	tcb->m_cWnd = (int) (87.169-(55.768)-(81.347)-(tcb->m_cWnd));

}
float XDqnmSudMTAlhNjE = (float) (dgDDWncjfAroLdJW-(31.269)-(65.584)-(73.064)-(71.897)-(90.191));
if (XDqnmSudMTAlhNjE != XDqnmSudMTAlhNjE) {
	XDqnmSudMTAlhNjE = (float) (43.579+(73.46)+(43.283)+(9.496)+(96.636)+(26.41)+(XDqnmSudMTAlhNjE)+(50.946)+(81.23));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	XDqnmSudMTAlhNjE = (float) (11.927-(3.614)-(45.702)-(98.821));

}
if (XDqnmSudMTAlhNjE > dgDDWncjfAroLdJW) {
	tcb->m_segmentSize = (int) (81.283*(93.22)*(98.318)*(tcb->m_segmentSize)*(67.419)*(tcb->m_segmentSize)*(88.957));
	tcb->m_segmentSize = (int) (19.699*(tcb->m_ssThresh)*(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (23.848-(42.623)-(segmentsAcked)-(34.632)-(85.441)-(42.622)-(dgDDWncjfAroLdJW)-(42.755));

}
float gFDIxyxihDVOBcuK = (float) (61.393-(26.739)-(21.233));
int CIiVOEUQfsqbysdZ = (int) (64.644-(67.978)-(42.933)-(2.401)-(28.791)-(segmentsAcked)-(96.699)-(81.669));
if (tcb->m_segmentSize >= gFDIxyxihDVOBcuK) {
	CIiVOEUQfsqbysdZ = (int) (tcb->m_ssThresh*(72.509));
	dgDDWncjfAroLdJW = (int) (59.828+(XDqnmSudMTAlhNjE)+(51.953)+(23.942)+(89.526)+(86.192));
	tcb->m_ssThresh = (int) (((86.154)+(0.1)+(0.1)+((58.798-(46.254)-(70.809)-(3.121)-(XDqnmSudMTAlhNjE)))+(0.1))/((30.14)+(28.922)+(25.227)+(0.1)));

} else {
	CIiVOEUQfsqbysdZ = (int) (48.961+(79.458)+(CIiVOEUQfsqbysdZ)+(21.956)+(68.571)+(88.097)+(41.988)+(15.969)+(20.111));

}
