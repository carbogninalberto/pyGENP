float ERnDofRXJbBchLXP = (float) (-18.671+(36.396)+(-64.91)+(-48.542)+(64.912)+(-20.01)+(37.598)+(-61.118)+(-24.463));
float oXLyOWWaWwMYAECH = (float) (91.216*(65.381)*(-54.948)*(61.144));
CongestionAvoidance (tcb, segmentsAcked);
