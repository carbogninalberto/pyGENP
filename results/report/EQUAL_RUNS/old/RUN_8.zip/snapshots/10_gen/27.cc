ReduceCwnd (tcb);
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_cWnd = (int) (19.523*(31.26)*(segmentsAcked)*(51.537)*(65.761)*(85.256)*(82.079)*(62.433));
	tcb->m_segmentSize = (int) (94.985+(22.414)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(25.634)+(31.831));

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(71.161)+(0.1)+(0.1)+(0.1)));

}
tcb->m_cWnd = (int) (tcb->m_ssThresh*(tcb->m_cWnd)*(3.864));
tcb->m_segmentSize = (int) (tcb->m_cWnd*(tcb->m_cWnd)*(10.978)*(90.332)*(54.843)*(66.677));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (48.808-(tcb->m_segmentSize)-(14.216)-(73.582)-(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(98.662)-(0.833)-(33.195)-(93.885)-(7.304)-(14.564));
	segmentsAcked = (int) (6.807-(83.777)-(20.377)-(19.914)-(55.819)-(42.142)-(tcb->m_ssThresh)-(56.364)-(18.789));
	tcb->m_cWnd = (int) (68.07*(48.113)*(tcb->m_ssThresh)*(42.369)*(92.259)*(45.982)*(tcb->m_segmentSize)*(53.215)*(49.475));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
