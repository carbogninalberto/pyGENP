int oTGtbPETPUKDlTit = (int) (20.22*(2.282)*(47.701)*(-81.036)*(-33.26));
int XiqEgDxTAdHPwADT = (int) (((13.84)+(79.607)+(-60.008)+(10.01)+(-47.951))/((59.816)+(0.572)+(83.784)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	XiqEgDxTAdHPwADT = (int) (68.927-(63.756)-(7.158)-(29.601)-(36.538)-(segmentsAcked)-(95.217));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (tcb->m_cWnd-(64.215)-(segmentsAcked)-(55.736)-(65.509)-(61.339));

} else {
	XiqEgDxTAdHPwADT = (int) (91.22+(84.364)+(9.292)+(95.65)+(tcb->m_cWnd));
	oTGtbPETPUKDlTit = (int) (20.74/23.075);

}
