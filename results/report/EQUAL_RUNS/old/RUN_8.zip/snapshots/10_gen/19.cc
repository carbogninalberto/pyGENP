CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (76.561*(76.292)*(38.886)*(segmentsAcked)*(67.425)*(66.343)*(98.752)*(5.831));
tcb->m_ssThresh = (int) (23.266*(82.368));
tcb->m_segmentSize = (int) (11.053*(segmentsAcked)*(94.093)*(49.325)*(66.812));
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((0.1)+(23.092)+(64.575)+(0.1)+(65.345)+(18.827)+(0.1))/((0.1)+(0.1)));
	segmentsAcked = (int) (49.756*(25.765)*(84.036)*(97.793)*(37.988)*(28.44)*(67.823));

} else {
	tcb->m_cWnd = (int) (48.084+(5.314)+(72.416)+(tcb->m_segmentSize)+(tcb->m_segmentSize));

}
segmentsAcked = (int) (4.34-(tcb->m_cWnd)-(75.443)-(44.702)-(68.218)-(51.605)-(35.904)-(38.525));
