float ERnDofRXJbBchLXP = (float) (-87.044+(61.499)+(4.404)+(5.271)+(93.516)+(-53.28)+(-43.227)+(-88.47)+(78.294));
float oXLyOWWaWwMYAECH = (float) (-13.639*(61.156)*(8.86)*(73.913));
CongestionAvoidance (tcb, segmentsAcked);
