int GFHiKannrYnTAhHL = (int) (-61.488-(39.751)-(-44.796)-(49.025)-(35.595));
float aNBCdEhXXHSMOrbo = (float) 22.617;
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
