tcb->m_segmentSize = (int) (17.815*(-69.41)*(-12.261)*(33.999)*(61.287)*(-95.236));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-57.177+(58.063)+(-12.467)+(-7.446)+(23.424));
CongestionAvoidance (tcb, segmentsAcked);
