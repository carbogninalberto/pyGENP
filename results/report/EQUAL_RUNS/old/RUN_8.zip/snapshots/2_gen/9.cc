float iSblmSBapydTCzSU = (float) (55.012/27.22);
if (tcb->m_segmentSize <= segmentsAcked) {
	iSblmSBapydTCzSU = (float) (10.842*(46.102)*(61.137)*(84.385));
	segmentsAcked = (int) (tcb->m_segmentSize*(7.536)*(32.513)*(iSblmSBapydTCzSU)*(41.498)*(44.443)*(31.983));

} else {
	iSblmSBapydTCzSU = (float) (32.252+(23.915)+(99.304));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
