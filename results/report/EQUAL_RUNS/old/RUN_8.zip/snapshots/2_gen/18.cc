float TazhYLQVqEzUdzXG = (float) 95.184;
