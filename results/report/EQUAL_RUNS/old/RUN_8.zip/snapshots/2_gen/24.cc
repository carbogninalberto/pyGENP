int bJYmoGbAoPVPoIgf = (int) (86.903*(-55.5)*(-96.628)*(-5.48)*(-0.393)*(45.133));
float aNBCdEhXXHSMOrbo = (float) 31.437;
