tcb->m_segmentSize = (int) (18.996+(13.726)+(-73.146)+(1.827)+(-90.976));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
