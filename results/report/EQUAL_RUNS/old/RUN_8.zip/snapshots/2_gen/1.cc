int inCqfibQnmooMVCN = (int) ((49.758*(90.702)*(31.48)*(5.12)*(-11.888)*(99.917)*(-48.258)*(-54.463))/58.08);
float YWdaOfUmqThGRBKo = (float) (-28.7/-67.969);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
