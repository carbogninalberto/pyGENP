int GFHiKannrYnTAhHL = (int) (-53.228-(65.245)-(-47.015)-(-34.527)-(-78.452));
float aNBCdEhXXHSMOrbo = (float) 88.338;
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
