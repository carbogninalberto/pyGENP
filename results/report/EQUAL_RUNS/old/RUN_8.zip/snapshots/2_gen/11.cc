float vSSfxVuTvcEGlvTM = (float) (-52.155+(-87.472)+(70.121)+(49.927)+(62.113)+(-60.855)+(22.471)+(-42.861));
float cMrCwKdVFInUwGAG = (float) ((33.708*(-13.821)*(31.433)*(-25.426))/89.95);
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) ((83.218+(1.547)+(73.616))/0.1);
	segmentsAcked = (int) (83.517-(85.777)-(96.447));

} else {
	segmentsAcked = (int) (78.118+(52.985)+(54.584)+(48.484)+(46.847)+(75.611)+(92.028)+(70.12));

}
tcb->m_cWnd = (int) (-12.857-(81.604)-(-28.882)-(26.686));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-72.018-(-82.214)-(49.991)-(52.46));
ReduceCwnd (tcb);
