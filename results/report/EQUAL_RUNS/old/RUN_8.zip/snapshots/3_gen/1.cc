if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (78.118+(52.985)+(54.584)+(48.484)+(46.847)+(75.611)+(92.028)+(70.12));

} else {
	segmentsAcked = (int) ((83.218+(1.547)+(73.616))/0.1);
	segmentsAcked = (int) (83.517-(85.777)-(96.447));

}
float cMrCwKdVFInUwGAG = (float) ((-78.496*(-11.799)*(-57.441)*(-68.527))/-97.117);
tcb->m_cWnd = (int) (35.889-(-54.698)-(52.334)-(30.653));
float vSSfxVuTvcEGlvTM = (float) (-47.574+(47.452)+(-2.204)+(-13.315)+(-10.237)+(59.942)+(-23.185)+(-68.682));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (62.809-(54.218)-(22.901)-(70.846));
ReduceCwnd (tcb);
