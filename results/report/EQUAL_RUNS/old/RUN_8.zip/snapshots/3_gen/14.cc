float ERnDofRXJbBchLXP = (float) (-81.737+(-64.421)+(91.731)+(-4.35)+(51.867)+(-48.505)+(-71.308)+(77.978)+(-78.517));
float oXLyOWWaWwMYAECH = (float) (27.232*(-96.465)*(33.717)*(-73.294));
CongestionAvoidance (tcb, segmentsAcked);
