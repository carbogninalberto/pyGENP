tcb->m_segmentSize = (int) (33.81+(1.54)+(-63.334)+(-11.844)+(-88.3));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
