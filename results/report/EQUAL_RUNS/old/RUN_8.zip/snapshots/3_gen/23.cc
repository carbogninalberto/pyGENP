if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) ((83.218+(1.547)+(73.616))/0.1);
	segmentsAcked = (int) (83.517-(85.777)-(96.447));

} else {
	segmentsAcked = (int) (78.118+(52.985)+(54.584)+(48.484)+(46.847)+(75.611)+(92.028)+(70.12));

}
float cMrCwKdVFInUwGAG = (float) ((61.524*(-37.203)*(-43.183)*(-24.866))/48.419);
ReduceCwnd (tcb);
float vSSfxVuTvcEGlvTM = (float) (62.435+(3.213)+(95.518)+(88.194)+(31.661)+(-8.894)+(56.099)+(95.785));
tcb->m_cWnd = (int) (-31.416-(-64.109)-(91.863)-(-26.626));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-69.35-(33.712)-(25.469)-(-46.073));
ReduceCwnd (tcb);
