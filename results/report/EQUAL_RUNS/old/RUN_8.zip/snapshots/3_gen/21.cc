float vSSfxVuTvcEGlvTM = (float) (73.098+(28.474)+(44.034)+(6.468)+(81.666)+(71.06)+(-45.169)+(73.219));
float cMrCwKdVFInUwGAG = (float) ((-88.461*(-32.653)*(78.729)*(13.274))/79.8);
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (78.118+(52.985)+(54.584)+(48.484)+(46.847)+(75.611)+(92.028)+(70.12));

} else {
	segmentsAcked = (int) ((83.218+(1.547)+(73.616))/0.1);
	segmentsAcked = (int) (83.517-(85.777)-(96.447));

}
tcb->m_cWnd = (int) (-86.904-(-22.613)-(29.781)-(-13.585));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-75.544-(-56.623)-(-94.844)-(89.356));
ReduceCwnd (tcb);
