float YWdaOfUmqThGRBKo = (float) (-17.908/94.999);
tcb->m_cWnd = (int) (-26.409-(-99.428)-(6.847)-(-27.833)-(-67.399)-(-6.179));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
