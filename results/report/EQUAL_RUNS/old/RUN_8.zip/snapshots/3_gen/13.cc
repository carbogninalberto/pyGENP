ReduceCwnd (tcb);
float iSblmSBapydTCzSU = (float) 90.086;
if (tcb->m_segmentSize <= segmentsAcked) {
	iSblmSBapydTCzSU = (float) (32.252+(23.915)+(99.304));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	iSblmSBapydTCzSU = (float) (10.842*(46.102)*(61.137)*(84.385));
	segmentsAcked = (int) (tcb->m_segmentSize*(7.536)*(32.513)*(iSblmSBapydTCzSU)*(41.498)*(44.443)*(31.983));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
