float YWdaOfUmqThGRBKo = (float) (79.028/38.189);
tcb->m_segmentSize = (int) (91.814*(-45.552)*(-74.392)*(-2.748)*(-26.463)*(42.114));
YWdaOfUmqThGRBKo = (float) (6.371/10.379);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
