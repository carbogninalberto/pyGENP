float aNBCdEhXXHSMOrbo = (float) 22.617;
int GFHiKannrYnTAhHL = (int) (6.059-(-10.472)-(-16.275)-(-43.394)-(-43.595));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
