float aNBCdEhXXHSMOrbo = (float) 22.617;
tcb->m_segmentSize = (int) (-1.266-(46.846)-(45.263)-(31.891)-(-89.443)-(-48.093)-(-12.578)-(-52.811));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
