float vSSfxVuTvcEGlvTM = (float) (60.013+(-60.408)+(55.926)+(79.202)+(53.449)+(-16.299)+(-70.549)+(-20.187));
float cMrCwKdVFInUwGAG = (float) ((27.083*(-15.749)*(76.337)*(46.954))/66.382);
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (78.118+(52.985)+(54.584)+(48.484)+(46.847)+(75.611)+(92.028)+(70.12));

} else {
	segmentsAcked = (int) ((83.218+(1.547)+(73.616))/0.1);
	segmentsAcked = (int) (83.517-(85.777)-(96.447));

}
tcb->m_cWnd = (int) (65.92-(-53.327)-(-99.389)-(92.274));
ReduceCwnd (tcb);
