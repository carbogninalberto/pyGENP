float vSSfxVuTvcEGlvTM = (float) (-70.676+(-96.673)+(31.575)+(-6.811)+(-51.851)+(-73.897)+(63.963)+(1.546));
float cMrCwKdVFInUwGAG = (float) ((-47.735*(64.542)*(3.624)*(-2.951))/13.702);
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (78.118+(52.985)+(54.584)+(48.484)+(46.847)+(75.611)+(92.028)+(70.12));

} else {
	segmentsAcked = (int) ((83.218+(1.547)+(73.616))/0.1);
	segmentsAcked = (int) (83.517-(85.777)-(96.447));

}
tcb->m_cWnd = (int) (-28.888-(-8.078)-(-98.24)-(99.066));
ReduceCwnd (tcb);
