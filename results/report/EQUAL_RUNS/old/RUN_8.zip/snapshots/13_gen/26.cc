TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (52.333+(24.477));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(89.288)*(87.831)*(1.256)*(46.845)*(20.695)*(58.076)*(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (44.378/89.309);
	tcb->m_ssThresh = (int) (29.247-(tcb->m_ssThresh)-(19.423)-(44.355)-(49.8)-(segmentsAcked)-(33.229)-(80.0)-(tcb->m_ssThresh));

}
if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(34.891)+(63.003)+(50.297)+(41.803)+(6.105)+(54.6)+(5.063)+(49.428));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (11.105/86.507);

} else {
	tcb->m_cWnd = (int) (0.1/31.313);

}
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (33.486-(34.164)-(9.985)-(3.384)-(tcb->m_segmentSize)-(3.946)-(segmentsAcked)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (29.692+(51.997)+(80.256)+(tcb->m_cWnd));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (60.057-(1.973)-(98.371));
	segmentsAcked = (int) (tcb->m_ssThresh*(57.758)*(tcb->m_segmentSize)*(66.791)*(98.102)*(17.19)*(segmentsAcked)*(9.755));
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (tcb->m_ssThresh+(98.435)+(22.65)+(83.768)+(segmentsAcked)+(63.795)+(84.843));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
float xYOiFcbDfOvDfBEz = (float) (((0.1)+(34.159)+(0.1)+(64.451))/((0.1)));
