float ERnDofRXJbBchLXP = (float) (0.35+(-2.155)+(-0.477)+(98.304)+(-86.306)+(-82.043)+(-33.328)+(39.744)+(-60.72));
float oXLyOWWaWwMYAECH = (float) (90.76*(78.203)*(16.389)*(-88.347));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
