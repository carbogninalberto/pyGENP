CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (9.569-(16.634)-(70.206)-(tcb->m_segmentSize)-(23.919));
segmentsAcked = (int) (16.284+(16.883)+(42.798)+(36.13)+(16.035)+(15.422)+(20.561)+(tcb->m_ssThresh));
tcb->m_segmentSize = (int) (47.485/0.1);
tcb->m_ssThresh = (int) (96.743+(69.643)+(tcb->m_segmentSize));
