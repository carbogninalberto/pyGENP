int DajfqveGjjMKlQHc = (int) (8.867-(-60.887)-(5.088)-(-3.534)-(99.94));
float IJeTSufbbYcyYSHq = (float) (27.637-(-31.331)-(-2.399)-(74.398)-(-15.723));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/2.939);
	tcb->m_cWnd = (int) (93.821+(65.696)+(15.488));

} else {
	segmentsAcked = (int) (((0.1)+(99.511)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));

}
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (((0.1)+(99.511)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));

} else {
	segmentsAcked = (int) (0.1/2.939);
	tcb->m_cWnd = (int) (93.821+(65.696)+(15.488));

}
IJeTSufbbYcyYSHq = (float) (-58.24*(-95.031)*(-54.339)*(31.32)*(30.673));
IJeTSufbbYcyYSHq = (float) (-46.806*(29.24)*(36.251)*(-9.259)*(-61.041));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
