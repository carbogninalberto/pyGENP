if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_ssThresh = (int) ((((17.871+(97.081)+(35.662)+(97.883)))+(0.1)+(59.523)+(93.844)+(74.947))/((41.971)+(0.1)+(0.1)));
	tcb->m_segmentSize = (int) (73.298+(57.973)+(98.338)+(tcb->m_cWnd)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (41.107+(73.345)+(tcb->m_cWnd)+(tcb->m_cWnd)+(tcb->m_cWnd)+(20.735));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(44.436)-(segmentsAcked)-(63.114)-(tcb->m_ssThresh)-(9.636)-(13.394));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (99.128*(9.055)*(20.299)*(24.696)*(tcb->m_segmentSize)*(segmentsAcked)*(76.453)*(82.361)*(8.664));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (98.345*(17.241)*(42.262)*(tcb->m_ssThresh)*(78.109)*(14.302));
