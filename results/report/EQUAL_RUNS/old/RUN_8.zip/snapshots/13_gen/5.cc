int yhtmsCKXxDdxnSBU = (int) (22.55-(53.241));
segmentsAcked = (int) (45.226+(32.467)+(-77.115)+(-76.714)+(20.489)+(-93.926));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (85.295+(-86.962)+(-64.869));
segmentsAcked = SlowStart (tcb, segmentsAcked);
