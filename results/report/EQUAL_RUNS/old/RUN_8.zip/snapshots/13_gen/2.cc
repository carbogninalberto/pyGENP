float rBzfPcgTGBYHQhfU = (float) (65.559+(-46.237)+(-65.206)+(85.694)+(-12.666)+(-5.141)+(19.381));
segmentsAcked = (int) (82.637/18.045);
