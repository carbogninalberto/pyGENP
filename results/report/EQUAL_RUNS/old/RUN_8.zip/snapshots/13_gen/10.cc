int yhtmsCKXxDdxnSBU = (int) (24.312-(-50.148));
yhtmsCKXxDdxnSBU = (int) (75.488-(-96.139)-(-8.478)-(-68.611)-(-52.908)-(-9.472));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (24.283+(40.468)+(-15.934));
