float ERnDofRXJbBchLXP = (float) (91.416+(-18.446)+(-21.862)+(38.844)+(-42.875)+(-5.241)+(-87.149)+(83.673)+(-40.817));
float oXLyOWWaWwMYAECH = (float) (48.247*(97.008)*(-91.017)*(98.676));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
