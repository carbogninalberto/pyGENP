segmentsAcked = (int) (tcb->m_cWnd*(58.455)*(40.258)*(45.399)*(segmentsAcked)*(31.117)*(segmentsAcked));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (1.506*(49.96)*(42.238)*(81.822));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	segmentsAcked = (int) (8.306*(97.646)*(81.41)*(tcb->m_cWnd)*(57.049));

} else {
	segmentsAcked = (int) (76.482+(83.79));

}
tcb->m_segmentSize = (int) (10.292*(19.007)*(tcb->m_ssThresh));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (43.566+(93.441)+(61.847));
