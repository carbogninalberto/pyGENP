float ERnDofRXJbBchLXP = (float) (-21.026+(-31.996)+(-12.306)+(27.515)+(-66.152)+(44.241)+(-3.837)+(76.78)+(49.509));
float oXLyOWWaWwMYAECH = (float) (94.976*(82.72)*(66.149)*(-57.915));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
