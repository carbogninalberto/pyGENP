tcb->m_ssThresh = (int) (36.713-(99.146)-(2.191));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (92.264*(91.737)*(57.167)*(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
tcb->m_cWnd = (int) ((tcb->m_ssThresh-(66.277)-(65.775)-(62.897)-(tcb->m_cWnd))/32.069);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (11.557-(53.043)-(9.675)-(81.466)-(segmentsAcked)-(33.758)-(95.516)-(tcb->m_ssThresh)-(75.748));

} else {
	tcb->m_segmentSize = (int) (66.794-(91.464)-(54.826)-(79.265)-(88.125)-(17.396));
	tcb->m_ssThresh = (int) (68.309*(72.959)*(94.07));

}
tcb->m_cWnd = (int) (29.28+(9.733)+(17.695)+(84.949)+(tcb->m_ssThresh)+(segmentsAcked)+(segmentsAcked)+(79.81));
