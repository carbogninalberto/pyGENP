float PulgTzDQsWdYZLRP = (float) ((((73.875-(79.524)-(38.705)-(tcb->m_cWnd)-(27.361)-(26.164)-(5.826)-(31.461)))+((70.197-(85.358)-(tcb->m_ssThresh)-(60.966)-(94.111)-(61.104)-(37.318)-(6.047)))+(77.73)+(16.17))/((0.1)+(0.1)+(0.1)+(27.627)));
tcb->m_segmentSize = (int) (segmentsAcked-(segmentsAcked)-(tcb->m_cWnd)-(6.359)-(35.538)-(91.217));
tcb->m_ssThresh = (int) (80.914-(52.495)-(71.212)-(41.379)-(46.596)-(35.244));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
