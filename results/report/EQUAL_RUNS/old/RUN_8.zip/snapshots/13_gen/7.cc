float ERnDofRXJbBchLXP = (float) (-55.379+(-76.894)+(-6.697)+(-36.44)+(-43.029)+(3.851)+(-65.291)+(-10.182)+(7.244));
float oXLyOWWaWwMYAECH = (float) (98.613*(2.096)*(33.185)*(63.781));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
