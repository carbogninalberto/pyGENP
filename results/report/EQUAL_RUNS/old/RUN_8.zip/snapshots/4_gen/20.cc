float vSSfxVuTvcEGlvTM = (float) (-84.029+(-2.415)+(-65.745)+(-58.123)+(77.253)+(66.28)+(-57.203)+(24.055));
float cMrCwKdVFInUwGAG = (float) ((-32.097*(-5.092)*(-3.635)*(71.023))/78.851);
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (78.118+(52.985)+(54.584)+(48.484)+(46.847)+(75.611)+(92.028)+(70.12));

} else {
	segmentsAcked = (int) ((83.218+(1.547)+(73.616))/0.1);
	segmentsAcked = (int) (83.517-(85.777)-(96.447));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (13.962-(98.962)-(-82.257)-(52.026));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (3.028-(70.485)-(-35.036)-(91.955));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (59.499-(50.522)-(39.489)-(5.941));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (36.009-(33.118)-(83.131)-(20.156));
ReduceCwnd (tcb);
