float vSSfxVuTvcEGlvTM = (float) (51.654+(33.357)+(71.729)+(10.396)+(38.383)+(66.258)+(-50.164)+(-10.92));
float cMrCwKdVFInUwGAG = (float) ((64.374*(14.018)*(-69.696)*(-92.838))/2.781);
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) ((83.218+(1.547)+(73.616))/0.1);
	segmentsAcked = (int) (83.517-(85.777)-(96.447));

} else {
	segmentsAcked = (int) (78.118+(52.985)+(54.584)+(48.484)+(46.847)+(75.611)+(92.028)+(70.12));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-44.622-(2.658)-(-25.492)-(-79.543));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-57.269-(57.873)-(93.406)-(36.368));
ReduceCwnd (tcb);
