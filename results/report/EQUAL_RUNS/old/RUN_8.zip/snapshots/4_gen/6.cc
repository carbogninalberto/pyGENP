tcb->m_cWnd = (int) (-26.645+(91.412)+(-74.868)+(-16.089)+(-6.4)+(-0.253)+(32.501)+(-12.691));
float YWdaOfUmqThGRBKo = (float) 89.202;
tcb->m_segmentSize = (int) (-83.679*(-42.554)*(76.149)*(84.223)*(-40.786)*(-51.982));
YWdaOfUmqThGRBKo = (float) (61.11/6.981);
