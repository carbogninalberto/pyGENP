float vSSfxVuTvcEGlvTM = (float) (11.327+(-70.515)+(38.418)+(-55.979)+(99.451)+(-83.379)+(-37.715)+(-83.914));
float cMrCwKdVFInUwGAG = (float) ((-21.494*(50.633)*(-51.534)*(-74.973))/3.686);
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) ((83.218+(1.547)+(73.616))/0.1);
	segmentsAcked = (int) (83.517-(85.777)-(96.447));

} else {
	segmentsAcked = (int) (78.118+(52.985)+(54.584)+(48.484)+(46.847)+(75.611)+(92.028)+(70.12));

}
tcb->m_cWnd = (int) (-0.696-(91.147)-(0.126)-(28.211));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (9.482-(94.037)-(-42.981)-(-99.43));
ReduceCwnd (tcb);
