int inCqfibQnmooMVCN = (int) ((-13.331*(30.662)*(-27.301)*(-41.599)*(86.404)*(-43.465)*(94.546)*(-10.231))/-96.282);
float YWdaOfUmqThGRBKo = (float) (-70.326/-71.806);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
