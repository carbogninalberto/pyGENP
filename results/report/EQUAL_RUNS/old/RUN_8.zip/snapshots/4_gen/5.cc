if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (78.118+(52.985)+(54.584)+(48.484)+(46.847)+(75.611)+(92.028)+(70.12));

} else {
	segmentsAcked = (int) ((83.218+(1.547)+(73.616))/0.1);
	segmentsAcked = (int) (83.517-(85.777)-(96.447));

}
float cMrCwKdVFInUwGAG = (float) ((23.515*(32.498)*(38.07)*(42.949))/55.632);
tcb->m_cWnd = (int) (-64.819-(92.577)-(41.821)-(-34.636));
float vSSfxVuTvcEGlvTM = (float) (-92.509+(95.806)+(5.206)+(2.2)+(12.711)+(7.582)+(-19.469)+(-96.498));
ReduceCwnd (tcb);
