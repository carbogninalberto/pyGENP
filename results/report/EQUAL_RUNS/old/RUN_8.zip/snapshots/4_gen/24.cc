if (tcb->m_segmentSize <= segmentsAcked) {
	segmentsAcked = (int) (tcb->m_cWnd*(64.194)*(95.204)*(36.413));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (21.764*(81.998)*(67.112)*(79.126)*(79.818)*(70.885)*(93.73)*(83.307));

} else {
	segmentsAcked = (int) (95.883+(79.367)+(93.65)+(3.028)+(88.819));
	tcb->m_segmentSize = (int) (0.1/87.566);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
