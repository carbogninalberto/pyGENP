tcb->m_segmentSize = (int) (62.204-(-44.374)-(57.851)-(-70.63)-(-29.021)-(-60.661)-(-0.345)-(-89.188)-(79.046));
segmentsAcked = (int) ((((41.355-(63.062)))+((-36.022*(69.385)*(-94.017)))+(-68.31)+(24.042)+(-42.593))/((-60.127)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-92.004+(-51.917)+(-39.071)+(-80.448)+(-79.862)+(-8.199)+(84.429)+(0.346)+(-0.818));
