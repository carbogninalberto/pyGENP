tcb->m_segmentSize = (int) (-1.233-(-23.847)-(24.149)-(99.402)-(54.517)-(10.146)-(56.475)-(-99.366)-(-3.542));
segmentsAcked = (int) ((((54.235-(-1.633)))+((70.146*(64.93)*(57.941)))+(30.384)+(3.378)+(-12.834))/((-73.9)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (36.193+(49.907)+(95.406)+(52.836)+(-43.651)+(-36.436)+(45.817)+(75.061)+(-52.927));
segmentsAcked = (int) ((((-69.736-(71.799)))+((-17.296*(-98.155)*(-23.426)))+(38.604)+(95.105)+(-69.28))/((-54.834)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (71.445+(-15.43)+(-94.74)+(45.436)+(1.759)+(49.942)+(45.077)+(46.935)+(-41.395));
