float oBAraVnEohyIHHwN = (float) 58.793;
float sdUgYFhqxBtljBhN = (float) (-35.241+(51.921)+(55.445)+(61.672)+(15.018)+(-92.966)+(-42.503)+(-95.372));
