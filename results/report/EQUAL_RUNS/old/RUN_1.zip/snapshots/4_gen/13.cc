tcb->m_segmentSize = (int) (-81.367-(37.003)-(-77.185)-(-53.767)-(50.0)-(16.42)-(-6.382)-(70.917)-(-20.238));
segmentsAcked = (int) ((((58.218-(50.483)))+((94.687*(-24.097)*(-21.352)))+(50.669)+(-9.244)+(-57.466))/((42.565)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-34.174+(-52.227)+(96.198)+(-60.982)+(16.623)+(21.989)+(47.285)+(-13.443)+(79.638));
