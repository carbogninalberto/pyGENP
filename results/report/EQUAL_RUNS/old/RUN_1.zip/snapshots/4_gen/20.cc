tcb->m_segmentSize = (int) (-69.683-(-33.581)-(31.31)-(67.702)-(-86.687)-(51.665)-(-15.796)-(46.168)-(77.828));
segmentsAcked = (int) ((((66.764-(-46.829)))+((32.502*(62.919)*(55.972)))+(-45.836)+(-52.674)+(-5.526))/((90.939)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (71.75+(2.948)+(-52.115)+(-24.021)+(63.197)+(64.526)+(96.575)+(60.897)+(8.774));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (41.637+(-43.307)+(-7.867)+(-30.37)+(5.613)+(3.55)+(-6.799)+(90.278)+(32.82));
