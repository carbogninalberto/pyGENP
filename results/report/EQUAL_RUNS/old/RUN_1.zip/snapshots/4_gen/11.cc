tcb->m_segmentSize = (int) (-82.871-(-83.177)-(-56.587)-(92.059)-(-48.969)-(-73.656)-(-86.435)-(-53.679)-(83.07));
segmentsAcked = (int) ((((6.316-(-74.558)))+((18.202*(16.694)*(-1.519)))+(82.389)+(-48.908)+(-72.075))/((-17.487)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-59.911+(-3.686)+(-71.824)+(38.318)+(40.162)+(72.749)+(28.869)+(94.051)+(-32.039));
segmentsAcked = (int) ((((91.099-(-81.586)))+((9.782*(84.601)*(98.227)))+(38.402)+(-13.513)+(9.611))/((-3.288)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-81.983+(34.647)+(-57.525)+(-9.378)+(-71.345)+(57.288)+(-84.439)+(-86.884)+(-31.72));
