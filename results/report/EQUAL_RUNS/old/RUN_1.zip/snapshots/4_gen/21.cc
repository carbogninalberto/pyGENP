tcb->m_segmentSize = (int) (-94.232-(94.398)-(88.484)-(-30.949)-(19.761)-(-81.294)-(23.718)-(53.175)-(-73.261));
segmentsAcked = (int) ((((40.283-(-38.976)))+((43.174*(-98.353)*(38.883)))+(-50.79)+(-29.084)+(96.678))/((14.408)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-39.214+(-31.692)+(47.062)+(-28.076)+(-31.78)+(45.353)+(-65.381)+(6.577)+(78.487));
