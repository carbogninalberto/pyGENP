tcb->m_segmentSize = (int) (-93.464-(-81.253)-(-26.006)-(-92.957)-(-17.408)-(-29.393)-(25.654)-(-88.268)-(70.741));
segmentsAcked = (int) ((((63.904-(40.427)))+((-37.247*(8.459)*(56.839)))+(6.943)+(-6.522)+(86.1))/((8.479)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (53.859+(-33.509)+(-87.781)+(-8.599)+(5.15)+(76.736)+(-37.515)+(-26.011)+(18.288));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-30.089+(-67.521)+(64.779)+(58.426)+(2.195)+(-47.987)+(-31.152)+(-59.204)+(37.183));
