tcb->m_segmentSize = (int) (-93.397-(-83.788)-(-43.878)-(47.523)-(98.53)-(8.994)-(-29.344)-(-75.661)-(40.758));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) ((((-39.601-(-58.136)))+((91.781*(13.899)*(22.31)))+(99.557)+(48.094)+(4.174))/((-97.441)));
tcb->m_segmentSize = (int) (71.722+(-50.942)+(28.172)+(-15.321)+(99.374)+(-56.344)+(98.757)+(-87.998)+(-64.294));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (8.664+(-85.793)+(-91.468)+(-33.436)+(3.003)+(52.994)+(-88.601)+(-22.479)+(-21.0));
