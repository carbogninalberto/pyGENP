tcb->m_segmentSize = (int) (-34.665-(93.882)-(-58.391)-(-58.679)-(-54.204)-(82.652)-(25.77)-(97.784)-(85.855));
segmentsAcked = (int) ((((64.556-(22.627)))+((-38.677*(1.466)*(-41.344)))+(90.272)+(-55.617)+(-71.602))/((-77.144)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (56.537+(-44.687)+(16.265)+(88.525)+(-45.681)+(39.791)+(18.744)+(-46.428)+(58.774));
segmentsAcked = (int) ((((58.695-(-15.597)))+((-63.397*(-49.497)*(-86.917)))+(-52.526)+(15.643)+(-30.148))/((-28.009)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (4.491+(-87.377)+(-92.486)+(54.964)+(-28.597)+(95.741)+(-24.597)+(36.312)+(-79.71));
