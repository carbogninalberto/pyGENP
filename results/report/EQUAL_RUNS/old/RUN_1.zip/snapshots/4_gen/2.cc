float NuIUpzPUuzZNtGWZ = (float) (32.248+(-87.424)+(-60.411)+(-3.294));
