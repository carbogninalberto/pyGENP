tcb->m_segmentSize = (int) (-18.905-(-95.509)-(91.502)-(89.252)-(-45.127)-(38.762)-(97.38)-(-57.388)-(44.25));
segmentsAcked = (int) ((((36.973-(29.475)))+((73.476*(-36.931)*(86.745)))+(62.402)+(-79.423)+(62.042))/((32.581)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) ((((75.98-(69.82)))+((-95.043*(-24.074)*(-37.872)))+(61.6)+(6.208)+(80.403))/((-67.368)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (33.187+(39.321)+(31.166)+(82.077)+(-15.736)+(-73.435)+(16.62)+(-98.53)+(-31.973));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-59.241+(50.927)+(97.506)+(-8.389)+(41.28)+(-51.586)+(82.78)+(62.973)+(60.853));
