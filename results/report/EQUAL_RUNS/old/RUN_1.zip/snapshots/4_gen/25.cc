float oBAraVnEohyIHHwN = (float) 58.793;
tcb->m_segmentSize = (int) (-47.973*(-1.157)*(-3.699)*(77.713)*(90.61));
tcb->m_segmentSize = (int) (31.722*(-26.212)*(-35.274)*(-57.093)*(-46.483));
if (oBAraVnEohyIHHwN > segmentsAcked) {
	tcb->m_segmentSize = (int) (3.243*(69.068)*(64.025)*(18.806)*(tcb->m_segmentSize)*(15.01)*(57.904)*(97.738));

} else {
	tcb->m_segmentSize = (int) (78.697-(tcb->m_cWnd)-(85.054)-(55.623)-(97.019)-(80.413)-(82.431)-(77.4));
	segmentsAcked = (int) (oBAraVnEohyIHHwN*(segmentsAcked)*(tcb->m_segmentSize)*(77.311));
	oBAraVnEohyIHHwN = (float) (tcb->m_cWnd-(72.251)-(22.152)-(27.756)-(40.176));

}
if (oBAraVnEohyIHHwN > segmentsAcked) {
	tcb->m_segmentSize = (int) (78.697-(tcb->m_cWnd)-(85.054)-(55.623)-(97.019)-(80.413)-(82.431)-(77.4));
	segmentsAcked = (int) (oBAraVnEohyIHHwN*(segmentsAcked)*(tcb->m_segmentSize)*(77.311));
	oBAraVnEohyIHHwN = (float) (tcb->m_cWnd-(72.251)-(22.152)-(27.756)-(40.176));

} else {
	tcb->m_segmentSize = (int) (3.243*(69.068)*(64.025)*(18.806)*(tcb->m_segmentSize)*(15.01)*(57.904)*(97.738));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((-32.2)+(-76.296)+(69.881)+(85.249))/((-36.064)+(-67.689)));
