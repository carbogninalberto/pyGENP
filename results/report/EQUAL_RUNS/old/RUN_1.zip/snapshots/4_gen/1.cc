tcb->m_segmentSize = (int) (40.742-(25.668)-(-66.773)-(55.637)-(17.905)-(55.313)-(-28.954)-(-74.723)-(-52.473));
segmentsAcked = (int) ((((77.618-(76.334)))+((-49.632*(2.264)*(-60.592)))+(-50.295)+(89.908)+(56.654))/((6.813)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (17.596+(-71.558)+(42.644)+(92.8)+(2.068)+(33.813)+(-32.171)+(88.451)+(8.163));
