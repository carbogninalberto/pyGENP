tcb->m_segmentSize = (int) (-58.126-(-72.201)-(67.32)-(-78.618)-(49.66)-(54.694)-(81.501)-(-97.756)-(74.897));
segmentsAcked = (int) ((((7.871-(45.691)))+((90.427*(-27.848)*(-83.483)))+(-69.871)+(-40.228)+(-44.793))/((-51.35)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (66.227+(77.941)+(-90.811)+(-42.712)+(-33.937)+(17.914)+(52.253)+(-36.508)+(-31.301));
segmentsAcked = (int) ((((49.393-(-45.415)))+((53.539*(87.266)*(-50.034)))+(-12.636)+(14.567)+(-99.275))/((-51.33)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (50.334+(-58.429)+(75.624)+(-84.554)+(-50.762)+(-96.199)+(75.247)+(-91.142)+(-6.916));
