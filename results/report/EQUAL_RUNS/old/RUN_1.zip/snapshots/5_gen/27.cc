tcb->m_cWnd = (int) ((((segmentsAcked+(59.243)+(-73.223)+(2.343)))+((81.809-(-40.103)))+(-87.131)+(-54.586)+(-78.207)+(-75.737)+(-87.603))/((-87.069)+(70.916)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (3.273-(76.695));
tcb->m_cWnd = (int) (31.05-(-99.234));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-36.106/-45.068);
tcb->m_cWnd = (int) (74.775/13.224);
