tcb->m_segmentSize = (int) (-39.997-(-76.417)-(-27.257)-(-2.405)-(-62.442)-(11.106)-(-15.129)-(81.667)-(-22.338));
segmentsAcked = (int) ((((-94.517-(54.188)))+((96.267*(79.655)*(-51.951)))+(93.293)+(14.586)+(18.803))/((46.817)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (72.927+(80.984)+(56.692)+(47.987)+(4.341)+(45.455)+(-61.247)+(74.511)+(61.169));
