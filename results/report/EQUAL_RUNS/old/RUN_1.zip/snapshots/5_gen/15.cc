tcb->m_segmentSize = (int) (-28.598-(91.039)-(-15.287)-(-68.614)-(-29.756)-(13.914)-(-93.539)-(-11.296)-(-3.433));
segmentsAcked = (int) ((((-91.463-(-97.884)))+((76.437*(7.611)*(-90.007)))+(-53.868)+(71.955)+(-10.098))/((-69.722)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-34.725+(9.676)+(21.153)+(-39.078)+(52.664)+(-58.382)+(-37.992)+(-49.058)+(-83.991));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-10.813+(-55.626)+(-16.891)+(30.146)+(21.697)+(91.977)+(-73.319)+(-57.808)+(-91.879));
