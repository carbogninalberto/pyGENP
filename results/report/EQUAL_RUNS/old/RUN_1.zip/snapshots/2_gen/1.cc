float dGHDDOirKIBgSpWC = (float) 17.697;
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (68.373/63.045);
