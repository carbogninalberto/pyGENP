ReduceCwnd (tcb);
float zLtihywhHgLqesaP = (float) 38.257;
zLtihywhHgLqesaP = (float) (9.314*(96.245)*(-35.474)*(97.539)*(-22.143)*(-88.397)*(56.085));
if (zLtihywhHgLqesaP == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (59.719+(92.401)+(tcb->m_segmentSize)+(57.438)+(30.233)+(tcb->m_cWnd)+(50.018)+(77.934));
	segmentsAcked = (int) (69.483+(72.091)+(86.999)+(3.706)+(28.149));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (74.245*(78.924));

}
