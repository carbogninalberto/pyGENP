float oBAraVnEohyIHHwN = (float) (-99.8-(83.786)-(79.993)-(-84.357)-(-31.682));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/17.498);
	tcb->m_cWnd = (int) ((71.758+(67.785)+(73.02)+(94.949))/45.627);
	tcb->m_segmentSize = (int) (80.819+(58.776)+(67.736));

} else {
	segmentsAcked = (int) (78.603-(65.707)-(segmentsAcked)-(37.46)-(59.166)-(42.306)-(73.483));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((-68.863)+(-11.28)+(-36.437)+(84.362))/((38.279)+(72.173)));
