tcb->m_segmentSize = (int) (50.888-(-12.61)-(44.211)-(0.361)-(60.186)-(49.18)-(77.342)-(-22.347)-(-1.636));
segmentsAcked = (int) ((((-64.875-(-32.201)))+((80.294*(9.225)*(25.282)))+(-2.181)+(6.414)+(-5.733))/((-68.676)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (96.921+(-83.68)+(32.309)+(-98.482)+(-45.374)+(-5.64)+(-5.045)+(51.591)+(13.788));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (23.096+(-17.53)+(60.56)+(-82.487)+(93.613)+(-15.943)+(35.895)+(-1.817)+(-7.432));
