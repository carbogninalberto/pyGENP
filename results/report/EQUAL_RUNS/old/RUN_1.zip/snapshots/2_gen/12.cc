int lLbSnyNlexHRkaas = (int) (-16.572-(61.041)-(-60.713)-(-1.65)-(-56.433)-(64.858)-(67.012)-(-58.714)-(65.58));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
