int RUlnAanqyiqhaYnv = (int) (-65.603/-56.007);
float yRCPkvCsHDXVJiPy = (float) (-99.772+(82.928)+(-34.306)+(21.019)+(14.005)+(79.927)+(-78.016));
tcb->m_segmentSize = (int) (83.983/81.01);
if (segmentsAcked != RUlnAanqyiqhaYnv) {
	segmentsAcked = (int) (((42.926)+((64.92*(tcb->m_segmentSize)))+(0.1)+(0.1)+((60.664+(tcb->m_ssThresh)+(7.692)+(47.97)+(35.235)+(0.597)+(87.493)+(54.517)))+(0.1)+(14.935)+(0.1))/((91.257)));
	RUlnAanqyiqhaYnv = (int) (yRCPkvCsHDXVJiPy-(42.698)-(71.714)-(28.011)-(2.548)-(56.724));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (16.028-(19.714)-(16.107)-(81.08)-(98.301)-(78.512)-(48.655)-(-75.424));

}
if (yRCPkvCsHDXVJiPy < tcb->m_segmentSize) {
	RUlnAanqyiqhaYnv = (int) (3.52+(45.343)+(49.945)+(68.99)+(18.999)+(63.269)+(82.34)+(16.15));

} else {
	RUlnAanqyiqhaYnv = (int) (91.927+(40.904)+(91.037));
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked != RUlnAanqyiqhaYnv) {
	segmentsAcked = (int) (((42.926)+((64.92*(tcb->m_segmentSize)))+(0.1)+(0.1)+((60.664+(tcb->m_ssThresh)+(7.692)+(47.97)+(35.235)+(0.597)+(87.493)+(54.517)))+(0.1)+(14.935)+(0.1))/((91.257)));
	RUlnAanqyiqhaYnv = (int) (yRCPkvCsHDXVJiPy-(42.698)-(71.714)-(28.011)-(2.548)-(56.724));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (16.028-(19.714)-(16.107)-(81.08)-(98.301)-(-46.749)-(48.655)-(43.831));

}
if (yRCPkvCsHDXVJiPy < tcb->m_segmentSize) {
	RUlnAanqyiqhaYnv = (int) (3.52+(45.343)+(49.945)+(68.99)+(18.999)+(63.269)+(82.34)+(16.15));

} else {
	RUlnAanqyiqhaYnv = (int) (91.927+(40.904)+(91.037));
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
