tcb->m_segmentSize = (int) (-68.57-(48.68)-(57.974)-(-2.349)-(-57.053)-(71.947)-(63.521)-(-9.118)-(96.352));
segmentsAcked = (int) ((((-54.937-(89.582)))+((-21.495*(3.86)*(87.404)))+(-54.411)+(43.643)+(46.488))/((-66.729)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) ((((87.981-(-91.776)))+((24.653*(23.685)*(0.395)))+(36.841)+(-5.148)+(43.795))/((44.074)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (47.636+(88.425)+(94.825)+(-30.513)+(51.19)+(-55.095)+(9.846)+(-19.359)+(1.082));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (22.446+(80.735)+(-94.89)+(-82.124)+(33.229)+(7.348)+(-27.218)+(-60.648)+(-61.749));
