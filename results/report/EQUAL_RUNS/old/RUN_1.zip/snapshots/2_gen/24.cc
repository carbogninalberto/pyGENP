float oBAraVnEohyIHHwN = (float) (-47.465-(-3.377)-(26.77)-(-96.746)-(83.547));
if (oBAraVnEohyIHHwN > segmentsAcked) {
	tcb->m_segmentSize = (int) (78.697-(tcb->m_cWnd)-(85.054)-(55.623)-(97.019)-(80.413)-(82.431)-(77.4));
	segmentsAcked = (int) (oBAraVnEohyIHHwN*(segmentsAcked)*(tcb->m_segmentSize)*(77.311));
	oBAraVnEohyIHHwN = (float) (tcb->m_cWnd-(72.251)-(22.152)-(27.756)-(40.176));

} else {
	tcb->m_segmentSize = (int) (3.243*(69.068)*(64.025)*(18.806)*(tcb->m_segmentSize)*(15.01)*(57.904)*(97.738));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((-47.952)+(17.729)+(6.754)+(-78.706))/((-48.908)+(99.237)));
