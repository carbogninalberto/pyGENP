if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (46.978-(78.442)-(73.089)-(68.998)-(31.771));
	tcb->m_cWnd = (int) (37.666+(76.875));

} else {
	tcb->m_ssThresh = (int) (54.61+(33.745)+(32.719)+(88.646)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(71.166)+(9.512)+(77.881));

}
int gvzJfYTehMLkCJyY = (int) (7.824*(64.268)*(90.091)*(77.525)*(segmentsAcked)*(34.369)*(72.52)*(42.076)*(61.887));
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (42.48-(tcb->m_ssThresh)-(26.689)-(tcb->m_segmentSize)-(33.869)-(64.334)-(gvzJfYTehMLkCJyY)-(35.155)-(87.818));
	gvzJfYTehMLkCJyY = (int) (57.471-(90.986));
	tcb->m_cWnd = (int) (15.465*(98.032)*(33.736));

} else {
	tcb->m_cWnd = (int) (82.376-(6.169)-(77.797)-(91.57)-(98.872)-(tcb->m_ssThresh)-(92.932));

}
int glvXXQkEuAjjsevU = (int) (16.757-(30.311)-(69.645));
if (segmentsAcked == tcb->m_ssThresh) {
	glvXXQkEuAjjsevU = (int) (54.284*(17.104));

} else {
	glvXXQkEuAjjsevU = (int) (50.861+(35.982)+(32.71)+(81.967)+(65.771)+(82.368)+(6.859));

}
