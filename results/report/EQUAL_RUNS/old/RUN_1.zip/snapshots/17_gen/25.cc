tcb->m_ssThresh = (int) (((5.627)+(99.207)+(12.192)+(0.1)+((tcb->m_cWnd*(44.36)*(segmentsAcked)*(tcb->m_ssThresh)))+(34.32))/((0.1)));
tcb->m_cWnd = (int) (((0.1)+(94.913)+(0.1)+(0.1))/((53.095)+(52.708)));
tcb->m_segmentSize = (int) (6.138*(68.457)*(28.694)*(43.387));
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(37.821)-(segmentsAcked)-(76.606)-(84.913));
	tcb->m_cWnd = (int) ((77.087-(tcb->m_ssThresh)-(84.422)-(25.501)-(6.68))/61.666);

} else {
	tcb->m_segmentSize = (int) (82.493*(tcb->m_ssThresh)*(33.898)*(27.036)*(59.021));

}
tcb->m_cWnd = (int) (95.684/0.1);
