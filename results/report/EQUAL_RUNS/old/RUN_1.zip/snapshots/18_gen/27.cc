CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (3.955+(tcb->m_ssThresh)+(79.842)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(81.859)+(59.235));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh < tcb->m_cWnd) {
	segmentsAcked = (int) (34.961-(66.345)-(68.096)-(15.474)-(65.848)-(45.912)-(47.301)-(tcb->m_cWnd)-(99.704));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(90.714)*(tcb->m_cWnd)*(76.548)*(88.02)*(23.493)*(96.605)*(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(83.485)*(0.322)*(32.557)*(5.759)*(60.259)*(segmentsAcked)*(14.77));
	tcb->m_cWnd = (int) (((42.382)+(0.1)+(51.667)+(82.455))/((46.056)+(63.563)+(54.201)+(19.503)+(0.1)));
	segmentsAcked = (int) (29.131-(67.713)-(69.313)-(53.712));

}
