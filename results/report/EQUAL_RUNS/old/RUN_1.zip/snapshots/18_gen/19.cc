float RQMEwzzKkbZKywck = (float) (((0.1)+((21.96*(80.216)*(58.619)*(28.54)*(17.818)*(7.459)))+(0.1)+(38.423)+(0.1))/((2.965)+(64.842)+(0.1)+(0.1)));
RQMEwzzKkbZKywck = (float) (5.617+(89.375)+(69.061)+(14.565)+(28.895));
segmentsAcked = (int) (55.078+(26.274)+(65.392)+(75.945)+(59.407)+(41.358)+(70.123)+(77.817));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (28.146*(99.94));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (40.841-(79.27)-(44.437)-(RQMEwzzKkbZKywck));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (28.301-(48.277)-(11.271)-(tcb->m_ssThresh)-(segmentsAcked)-(RQMEwzzKkbZKywck));
CongestionAvoidance (tcb, segmentsAcked);
