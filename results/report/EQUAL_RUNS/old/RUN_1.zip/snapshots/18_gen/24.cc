float cgWuPzfJEOpoePbC = (float) (70.363-(27.802)-(38.286)-(79.21)-(tcb->m_cWnd)-(segmentsAcked)-(37.302)-(54.164)-(54.374));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (cgWuPzfJEOpoePbC >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (92.803-(81.543)-(78.764)-(89.251)-(31.85)-(55.77)-(cgWuPzfJEOpoePbC));
	tcb->m_ssThresh = (int) (28.554+(53.551)+(93.908)+(tcb->m_cWnd)+(69.225)+(42.038)+(12.531));

} else {
	tcb->m_cWnd = (int) (52.318/67.913);
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (30.802+(74.617)+(98.018)+(42.511)+(58.424)+(29.033));

}
cgWuPzfJEOpoePbC = (float) (86.721+(60.202)+(57.922)+(9.351)+(93.588)+(tcb->m_segmentSize)+(82.714)+(23.093));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (37.367*(97.435)*(59.834)*(29.288)*(cgWuPzfJEOpoePbC)*(38.937)*(tcb->m_ssThresh)*(97.89)*(92.286));
ReduceCwnd (tcb);
