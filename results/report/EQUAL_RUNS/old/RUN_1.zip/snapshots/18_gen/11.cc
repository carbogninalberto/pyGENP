int yWcuyykrMHqlATjD = (int) (-66.866*(-81.244)*(39.279));
if (tcb->m_segmentSize < yWcuyykrMHqlATjD) {
	tcb->m_segmentSize = (int) (14.643+(36.446)+(-80.218)+(22.333)+(89.507));
	tcb->m_cWnd = (int) (24.23*(yWcuyykrMHqlATjD)*(73.635)*(74.501)*(-38.036)*(70.49)*(89.918)*(18.674));
	yWcuyykrMHqlATjD = (int) (86.499*(26.652)*(95.301)*(47.707));

} else {
	tcb->m_segmentSize = (int) (67.473*(74.59)*(21.341)*(tcb->m_segmentSize)*(65.204));
	tcb->m_cWnd = (int) (((0.1)+(7.69)+((tcb->m_segmentSize+(41.12)+(segmentsAcked)+(42.952)+(25.03)))+((87.519-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(94.167)-(74.16)-(yWcuyykrMHqlATjD)))+(99.824)+(0.1))/((1.102)+(95.188)+(85.914)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (22.919+(-48.6)+(14.304)+(63.557)+(34.58)+(11.063)+(-58.782)+(-22.406));
