int wtMzSdCloVnnYJlt = (int) (71.145+(63.844)+(2.226)+(47.418)+(-12.652));
int XpXfCRNqtbaULLbN = (int) (-16.526*(-81.827));
