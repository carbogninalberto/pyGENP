tcb->m_cWnd = (int) (56.785+(39.859)+(tcb->m_cWnd)+(78.358)+(59.821)+(77.122)+(33.424)+(38.874));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) (81.302+(10.651)+(74.092)+(20.035)+(63.483)+(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (63.931*(37.993)*(98.046)*(52.005)*(62.709)*(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (80.236+(24.331)+(16.059));
	segmentsAcked = (int) (83.711*(87.737)*(69.048)*(81.965)*(segmentsAcked));

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (9.252*(4.621)*(55.973)*(tcb->m_cWnd)*(21.398)*(97.683)*(tcb->m_segmentSize)*(11.776)*(95.156));
	segmentsAcked = (int) (0.1/71.17);

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(90.469)-(tcb->m_ssThresh)-(98.39)-(tcb->m_segmentSize)-(99.75)-(4.553));
	segmentsAcked = (int) (39.114/75.566);
	tcb->m_ssThresh = (int) (82.605-(28.141)-(16.042)-(50.02)-(14.532)-(segmentsAcked)-(99.532));

}
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) ((86.92*(93.819)*(70.619))/19.188);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (64.684+(24.23));

}
tcb->m_segmentSize = (int) (32.739+(tcb->m_ssThresh)+(tcb->m_cWnd)+(65.125)+(tcb->m_cWnd)+(14.789)+(segmentsAcked));
tcb->m_ssThresh = (int) (87.161+(segmentsAcked));
