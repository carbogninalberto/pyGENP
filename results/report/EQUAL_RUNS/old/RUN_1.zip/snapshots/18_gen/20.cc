tcb->m_segmentSize = (int) (60.509*(75.559)*(tcb->m_segmentSize)*(81.203)*(52.99)*(8.986));
if (segmentsAcked != tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_ssThresh+(18.772)+(85.462));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (63.448/10.58);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (70.42+(tcb->m_segmentSize));
ReduceCwnd (tcb);
