tcb->m_segmentSize = (int) (92.189*(89.588)*(54.519)*(74.336)*(47.139)*(segmentsAcked)*(64.125)*(segmentsAcked)*(48.926));
int HcsSXsKGiFmpDbWW = (int) (37.655+(72.026)+(85.079)+(92.638)+(32.186)+(71.671));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
