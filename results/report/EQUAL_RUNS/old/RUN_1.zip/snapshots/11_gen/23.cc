segmentsAcked = SlowStart (tcb, segmentsAcked);
float ZigqhttjQPZZqYqh = (float) 89.615;
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (95.874+(6.459)+(25.604)+(67.102)+(79.782)+(14.508)+(77.982));
	ZigqhttjQPZZqYqh = (float) (segmentsAcked+(57.471)+(54.386)+(segmentsAcked)+(16.029)+(89.55)+(70.284));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (14.163*(1.548)*(90.037)*(31.269));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize < segmentsAcked) {
	ZigqhttjQPZZqYqh = (float) ((75.449+(ZigqhttjQPZZqYqh)+(53.448)+(86.699)+(tcb->m_ssThresh)+(segmentsAcked)+(28.415)+(tcb->m_cWnd))/0.1);

} else {
	ZigqhttjQPZZqYqh = (float) (99.266*(8.729)*(30.443)*(83.36)*(55.644)*(92.908)*(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize < segmentsAcked) {
	ZigqhttjQPZZqYqh = (float) ((75.449+(ZigqhttjQPZZqYqh)+(53.448)+(86.699)+(tcb->m_ssThresh)+(segmentsAcked)+(28.415)+(tcb->m_cWnd))/0.1);

} else {
	ZigqhttjQPZZqYqh = (float) (99.266*(8.729)*(30.443)*(83.36)*(55.644)*(92.908)*(tcb->m_cWnd));

}
if (tcb->m_segmentSize < segmentsAcked) {
	ZigqhttjQPZZqYqh = (float) ((75.449+(ZigqhttjQPZZqYqh)+(53.448)+(86.699)+(tcb->m_ssThresh)+(segmentsAcked)+(28.415)+(tcb->m_cWnd))/0.1);

} else {
	ZigqhttjQPZZqYqh = (float) (99.266*(8.729)*(30.443)*(83.36)*(55.644)*(92.908)*(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize < segmentsAcked) {
	ZigqhttjQPZZqYqh = (float) ((75.449+(ZigqhttjQPZZqYqh)+(53.448)+(86.699)+(tcb->m_ssThresh)+(segmentsAcked)+(28.415)+(tcb->m_cWnd))/0.1);

} else {
	ZigqhttjQPZZqYqh = (float) (99.266*(8.729)*(30.443)*(83.36)*(55.644)*(92.908)*(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize < segmentsAcked) {
	ZigqhttjQPZZqYqh = (float) ((75.449+(ZigqhttjQPZZqYqh)+(53.448)+(86.699)+(tcb->m_ssThresh)+(segmentsAcked)+(28.415)+(tcb->m_cWnd))/0.1);

} else {
	ZigqhttjQPZZqYqh = (float) (99.266*(8.729)*(30.443)*(83.36)*(55.644)*(92.908)*(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize < segmentsAcked) {
	ZigqhttjQPZZqYqh = (float) ((75.449+(ZigqhttjQPZZqYqh)+(53.448)+(86.699)+(tcb->m_ssThresh)+(segmentsAcked)+(28.415)+(tcb->m_cWnd))/0.1);

} else {
	ZigqhttjQPZZqYqh = (float) (99.266*(8.729)*(30.443)*(83.36)*(55.644)*(92.908)*(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
