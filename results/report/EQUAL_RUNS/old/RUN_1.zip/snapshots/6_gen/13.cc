tcb->m_segmentSize = (int) (-96.742-(44.028)-(-51.346)-(-49.817)-(-61.627)-(80.736)-(-81.989)-(-66.229)-(7.967));
segmentsAcked = (int) ((((-24.568-(-4.191)))+((80.311*(32.103)*(60.764)))+(-0.418)+(61.269)+(-72.696))/((-20.141)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-38.965+(11.368)+(1.796)+(-95.525)+(-7.424)+(83.502)+(87.673)+(-32.124)+(-69.737));
segmentsAcked = (int) ((((-66.928-(44.594)))+((92.889*(-94.991)*(95.193)))+(37.834)+(-28.395)+(-35.248))/((83.684)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-46.176+(87.478)+(80.337)+(97.217)+(31.213)+(84.857)+(-21.313)+(7.003)+(52.203));
