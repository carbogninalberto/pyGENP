tcb->m_segmentSize = (int) (66.413-(-54.657)-(3.594)-(90.482)-(59.014)-(97.208)-(-74.756)-(-24.286)-(-37.319));
segmentsAcked = (int) ((((3.3-(21.377)))+((75.673*(-1.851)*(-38.875)))+(6.785)+(-69.558)+(-98.879))/((65.068)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (52.929+(91.794)+(41.481)+(-29.618)+(-75.927)+(-48.664)+(99.324)+(57.214)+(-2.127));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (33.867+(-61.503)+(-65.833)+(63.025)+(-97.271)+(-59.087)+(-53.591)+(-86.502)+(-94.951));
