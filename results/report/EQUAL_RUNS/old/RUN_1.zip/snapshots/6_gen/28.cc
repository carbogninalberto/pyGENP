tcb->m_segmentSize = (int) (82.244-(11.716)-(-89.482)-(-70.173)-(89.275)-(9.819)-(-43.291)-(52.639)-(61.127));
segmentsAcked = (int) ((((50.725-(25.963)))+((-9.704*(-5.348)*(82.231)))+(35.575)+(1.649)+(-6.876))/((81.415)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (20.614+(9.068)+(-26.105)+(-68.73)+(41.954)+(-76.129)+(-11.46)+(-82.652)+(44.059));
tcb->m_segmentSize = (int) (-66.024+(-85.862)+(88.855)+(-72.016)+(-74.429)+(-11.335)+(58.543)+(66.585)+(51.742));
