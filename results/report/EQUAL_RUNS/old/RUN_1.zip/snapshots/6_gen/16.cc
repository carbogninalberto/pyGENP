tcb->m_segmentSize = (int) (31.108-(-76.869)-(88.895)-(-98.447)-(-32.015)-(22.218)-(-5.926)-(-16.181)-(-43.528));
segmentsAcked = (int) ((((-91.471-(50.711)))+((-23.237*(87.89)*(-44.034)))+(-90.429)+(-34.855)+(-91.767))/((84.585)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-58.05+(-76.62)+(77.21)+(30.924)+(11.605)+(-10.706)+(80.913)+(-60.442)+(-97.014));
