segmentsAcked = (int) (52.253+(-30.228)+(21.584)+(21.239)+(-28.335)+(22.817)+(-68.408));
if (segmentsAcked <= segmentsAcked) {
	tcb->m_cWnd = (int) (31.028-(5.027)-(94.497)-(91.803)-(12.656)-(32.515));
	tcb->m_cWnd = (int) (87.181+(tcb->m_cWnd)+(73.639)+(72.454));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (segmentsAcked+(86.346)+(66.475)+(63.884)+(73.513)+(20.755)+(87.787)+(62.569)+(45.496));
	tcb->m_segmentSize = (int) (52.685+(0.607)+(47.517)+(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
