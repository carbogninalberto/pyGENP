segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (41.9*(tcb->m_cWnd)*(63.88)*(13.848)*(36.205)*(91.699)*(28.338)*(4.429)*(10.212));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (78.069+(99.083)+(77.663)+(78.844)+(81.155)+(3.931));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(28.753)-(89.365)-(94.612)-(43.26)-(28.821)-(42.254));

}
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/69.717);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (46.029+(segmentsAcked));
	tcb->m_segmentSize = (int) (92.847+(71.875)+(10.784)+(69.604)+(36.467)+(36.75)+(28.679)+(tcb->m_segmentSize)+(59.549));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
