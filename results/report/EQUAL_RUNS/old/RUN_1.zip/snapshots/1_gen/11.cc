tcb->m_ssThresh = (int) (0.1/24.142);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int xVyhIKmpIcAhqhsg = (int) (segmentsAcked*(98.887)*(1.873)*(26.088)*(9.289)*(78.993)*(77.521));
xVyhIKmpIcAhqhsg = (int) (14.791-(segmentsAcked)-(53.122));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	xVyhIKmpIcAhqhsg = (int) (77.187*(tcb->m_ssThresh)*(58.427)*(19.128)*(30.04));
	xVyhIKmpIcAhqhsg = (int) (43.295*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(95.908)*(69.555)*(12.865)*(94.814));

} else {
	xVyhIKmpIcAhqhsg = (int) (43.008-(tcb->m_segmentSize)-(24.484)-(89.033)-(63.613)-(85.116)-(21.566));
	xVyhIKmpIcAhqhsg = (int) (8.288*(59.05));

}
ReduceCwnd (tcb);
