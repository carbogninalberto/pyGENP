if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/17.498);
	tcb->m_cWnd = (int) ((71.758+(67.785)+(73.02)+(94.949))/45.627);
	tcb->m_segmentSize = (int) (80.819+(58.776)+(67.736));

} else {
	segmentsAcked = (int) (78.603-(65.707)-(segmentsAcked)-(37.46)-(59.166)-(42.306)-(73.483));

}
float oBAraVnEohyIHHwN = (float) (21.371-(tcb->m_segmentSize)-(60.638)-(tcb->m_ssThresh)-(tcb->m_cWnd));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(4.147)+(0.1))/((86.772)));
	tcb->m_ssThresh = (int) (oBAraVnEohyIHHwN+(49.018)+(13.001)+(54.483)+(15.916)+(26.085)+(84.653)+(tcb->m_cWnd)+(46.3));
	tcb->m_ssThresh = (int) (91.898-(17.652)-(9.535)-(tcb->m_ssThresh)-(93.17)-(42.13)-(93.487));

} else {
	tcb->m_ssThresh = (int) (0.1/91.876);

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((9.273)+(0.1)+(0.1)+(56.861))/((0.1)+(92.444)));
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked*(8.267)*(24.513)*(51.448)*(74.179)*(62.239)*(2.84)*(58.225)*(27.981));

} else {
	segmentsAcked = (int) (74.696*(oBAraVnEohyIHHwN)*(21.068)*(12.207)*(60.232));
	tcb->m_ssThresh = (int) (88.933-(49.405)-(71.945)-(61.822)-(49.872)-(45.702)-(49.935)-(96.322));
	tcb->m_segmentSize = (int) (21.545+(74.097)+(segmentsAcked)+(89.207)+(tcb->m_ssThresh)+(68.056)+(segmentsAcked)+(segmentsAcked));

}
