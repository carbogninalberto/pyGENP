if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (10.893*(64.577)*(19.816)*(42.446)*(87.572)*(56.487)*(4.625));

} else {
	tcb->m_segmentSize = (int) (67.744/0.1);

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((78.043)+(21.004)+(57.55)+(32.283))/((72.286)));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (62.395*(21.778)*(21.396)*(29.282)*(22.896)*(tcb->m_ssThresh)*(33.592));

} else {
	tcb->m_segmentSize = (int) (22.251*(28.243)*(21.826)*(48.182)*(49.679)*(83.693)*(16.305)*(36.412));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (74.037+(83.168)+(60.261)+(7.845)+(40.117));

}
