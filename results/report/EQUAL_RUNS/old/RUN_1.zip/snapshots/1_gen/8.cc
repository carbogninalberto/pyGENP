CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	segmentsAcked = (int) ((57.519-(94.25)-(3.844))/32.946);

} else {
	segmentsAcked = (int) ((((87.127-(24.289)-(69.847)-(tcb->m_cWnd)-(64.53)))+(74.484)+(76.356)+(0.1)+(12.651))/((95.793)+(3.726)));
	tcb->m_segmentSize = (int) (31.627+(92.391)+(53.723));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = (int) (98.324+(83.11)+(tcb->m_ssThresh)+(29.781)+(21.215)+(43.616)+(92.076)+(39.836)+(70.564));
segmentsAcked = (int) (13.716*(52.483)*(tcb->m_segmentSize)*(segmentsAcked)*(45.925)*(85.675)*(20.712)*(5.176));
tcb->m_segmentSize = (int) (77.822-(57.314));
