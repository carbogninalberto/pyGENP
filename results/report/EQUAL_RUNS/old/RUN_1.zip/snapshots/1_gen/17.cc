if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(94.742)*(60.195)*(2.499)*(50.902)*(83.371));

} else {
	tcb->m_segmentSize = (int) (32.103/45.534);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (tcb->m_ssThresh*(6.832)*(tcb->m_cWnd)*(73.199)*(tcb->m_segmentSize)*(79.368));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (7.983-(82.822)-(70.651));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (((0.1)+(69.125)+(25.948)+(0.1)+(0.1)+((4.747+(72.119)+(67.733)+(94.019)+(16.578)))+((10.324-(32.687)-(tcb->m_segmentSize)-(66.572)-(52.099)-(63.4)))+(0.1))/((18.556)));

} else {
	tcb->m_segmentSize = (int) (99.157+(64.982)+(34.0)+(14.5)+(64.097));
	tcb->m_cWnd = (int) (40.406+(66.082));
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
