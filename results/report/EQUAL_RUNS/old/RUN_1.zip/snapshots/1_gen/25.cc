int aTbTEiRcywOttxOc = (int) (tcb->m_ssThresh*(91.909)*(69.327)*(22.833)*(22.668)*(73.296));
float BkpzVDJfLmNSXCaN = (float) (tcb->m_ssThresh-(89.027));
if (aTbTEiRcywOttxOc >= aTbTEiRcywOttxOc) {
	tcb->m_ssThresh = (int) (13.024+(75.242));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (tcb->m_cWnd-(tcb->m_ssThresh)-(40.153)-(40.743)-(16.776)-(67.932)-(38.155)-(tcb->m_segmentSize)-(76.857));

} else {
	tcb->m_ssThresh = (int) (BkpzVDJfLmNSXCaN+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(8.457));
	tcb->m_ssThresh = (int) (((13.277)+((84.671-(32.367)-(tcb->m_ssThresh)-(95.868)))+(0.1)+(1.953))/((0.1)+(0.1)));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	aTbTEiRcywOttxOc = (int) ((tcb->m_ssThresh+(19.626)+(49.118))/31.948);
	tcb->m_segmentSize = (int) (15.663/20.252);
	aTbTEiRcywOttxOc = (int) (31.011+(20.556)+(77.539)+(15.182)+(20.285)+(29.504)+(27.735)+(17.147)+(BkpzVDJfLmNSXCaN));

} else {
	aTbTEiRcywOttxOc = (int) (54.344*(44.742)*(17.304)*(7.842));

}
