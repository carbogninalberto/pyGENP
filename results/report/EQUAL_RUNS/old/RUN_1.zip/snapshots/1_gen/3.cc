int ybCvoipQbldVqdfx = (int) (0.1/18.668);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_cWnd) {
	segmentsAcked = (int) (53.18-(97.191));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh+(70.471)+(2.414)+(36.448)+(24.349)+(tcb->m_ssThresh)+(54.23)+(32.185)+(21.606));

}
if (ybCvoipQbldVqdfx != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (77.071*(92.066)*(42.789)*(99.374)*(33.032));

} else {
	tcb->m_cWnd = (int) (ybCvoipQbldVqdfx*(97.684)*(63.214)*(21.699)*(94.25)*(34.629)*(tcb->m_cWnd)*(1.603));

}
int WJhHNpfUgLNEUEWv = (int) (39.434+(tcb->m_cWnd)+(tcb->m_ssThresh)+(70.672)+(tcb->m_cWnd)+(34.125));
if (ybCvoipQbldVqdfx == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((99.057)+(50.099)+((ybCvoipQbldVqdfx*(4.85)*(15.222)*(80.875)*(49.642)*(ybCvoipQbldVqdfx)*(83.372)))+(59.438)+(11.528)+(0.1)+(28.12)+(14.62))/((85.331)));
	ybCvoipQbldVqdfx = (int) (50.796-(44.435)-(WJhHNpfUgLNEUEWv)-(72.438)-(62.432)-(71.489)-(45.034));

} else {
	tcb->m_ssThresh = (int) (WJhHNpfUgLNEUEWv-(segmentsAcked)-(tcb->m_cWnd)-(84.381)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(29.89)-(12.328)-(68.785));

}
if (tcb->m_segmentSize < ybCvoipQbldVqdfx) {
	tcb->m_segmentSize = (int) (52.209+(62.928)+(18.561)+(62.872)+(58.776)+(96.157));
	tcb->m_segmentSize = (int) (WJhHNpfUgLNEUEWv-(72.655)-(69.995)-(19.09)-(9.954)-(28.05));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(70.606)+(3.686)+(0.1)+(0.1)+(0.1))/((41.477)));
	ybCvoipQbldVqdfx = (int) (tcb->m_segmentSize*(81.18)*(12.022)*(62.329)*(13.505));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
