tcb->m_segmentSize = (int) (72.507-(-16.475)-(60.634)-(65.202)-(-32.922)-(89.957)-(17.695)-(-52.929)-(-17.526));
segmentsAcked = (int) ((((-17.835-(-19.741)))+((11.895*(-94.47)*(-42.26)))+(71.257)+(-7.96)+(33.812))/((32.018)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-70.235+(-19.9)+(-63.523)+(-8.46)+(-17.215)+(97.84)+(84.805)+(-6.361)+(-51.453));
segmentsAcked = (int) ((((19.902-(-73.308)))+((61.818*(1.77)*(92.197)))+(-51.257)+(15.016)+(-0.258))/((7.793)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-34.378+(90.521)+(-63.168)+(-73.114)+(-92.882)+(-1.461)+(79.846)+(-97.331)+(84.414));
