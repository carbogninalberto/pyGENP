segmentsAcked = (int) (-34.703/-9.097);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(61.78));

} else {
	tcb->m_cWnd = (int) (56.742-(94.156)-(11.18)-(83.255)-(61.064)-(49.906)-(tcb->m_segmentSize));
	segmentsAcked = (int) (0.1/0.1);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
