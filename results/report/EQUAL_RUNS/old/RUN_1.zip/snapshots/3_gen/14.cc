tcb->m_segmentSize = (int) (-24.364-(-97.82)-(97.396)-(-62.674)-(7.486)-(-64.794)-(-17.338)-(24.066)-(69.237));
segmentsAcked = (int) ((((21.669-(48.421)))+((93.214*(11.981)*(22.584)))+(-13.686)+(44.991)+(-71.644))/((-57.119)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-26.131+(-26.586)+(-69.871)+(27.5)+(22.971)+(-82.799)+(-6.397)+(-68.851)+(68.712));
segmentsAcked = (int) ((((-26.112-(12.507)))+((-97.388*(9.206)*(-41.978)))+(94.337)+(66.11)+(-42.14))/((-49.832)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (9.539+(-41.412)+(-34.055)+(95.729)+(3.375)+(-57.521)+(-69.67)+(-38.976)+(80.103));
