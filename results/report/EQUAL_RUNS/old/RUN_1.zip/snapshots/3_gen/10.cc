float zLtihywhHgLqesaP = (float) 40.372;
tcb->m_segmentSize = (int) (-11.666*(-71.554));
zLtihywhHgLqesaP = (float) (-88.96*(-48.516)*(59.875)*(-59.367)*(8.257)*(-39.137)*(34.726));
if (zLtihywhHgLqesaP == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (59.719+(92.401)+(tcb->m_segmentSize)+(57.438)+(30.233)+(tcb->m_cWnd)+(50.018)+(77.934));
	segmentsAcked = (int) (69.483+(72.091)+(86.999)+(-66.088)+(28.149));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (74.245*(78.924));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
