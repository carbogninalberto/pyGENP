if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (segmentsAcked*(86.44)*(78.712)*(92.069)*(90.597)*(64.565));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (0.637+(20.586)+(26.558)+(55.683)+(42.439)+(36.329)+(segmentsAcked));
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(59.422)+(8.69)+(tcb->m_cWnd)+(97.61));

}
