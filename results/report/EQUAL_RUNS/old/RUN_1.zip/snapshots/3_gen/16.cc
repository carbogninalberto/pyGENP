tcb->m_segmentSize = (int) (61.067-(-55.836)-(-50.989)-(-0.185)-(-7.242)-(7.957)-(-69.497)-(-33.389)-(37.275));
segmentsAcked = (int) ((((-7.452-(-36.063)))+((-70.334*(7.047)*(62.347)))+(73.852)+(49.474)+(37.52))/((-95.581)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (55.926+(46.215)+(-86.6)+(42.284)+(47.26)+(97.759)+(55.602)+(60.792)+(53.779));
