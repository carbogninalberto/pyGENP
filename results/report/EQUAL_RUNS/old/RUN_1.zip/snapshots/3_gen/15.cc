tcb->m_segmentSize = (int) (-40.112-(23.936)-(70.182)-(67.309)-(-36.928)-(3.656)-(-31.498)-(-39.845)-(6.795));
segmentsAcked = (int) ((((-63.46-(95.482)))+((-23.649*(-68.516)*(-71.485)))+(95.446)+(27.014)+(38.906))/((35.82)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) ((((-32.901-(40.355)))+((27.431*(64.219)*(-75.576)))+(88.774)+(56.836)+(39.321))/((-17.556)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-23.139+(13.327)+(49.934)+(-83.768)+(75.415)+(-84.115)+(-12.928)+(-30.645)+(79.068));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-93.238+(66.458)+(-37.393)+(84.742)+(-74.017)+(0.898)+(86.701)+(-88.512)+(47.139));
