if (tcb->m_segmentSize != segmentsAcked) {
	segmentsAcked = (int) (7.558-(73.567)-(46.849)-(12.826));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (38.137+(15.067)+(30.156)+(53.205)+(29.623)+(13.707));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(29.697)+(13.245)+(21.923)+(27.796));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (-88.914+(-95.217)+(-84.219)+(-99.312)+(48.283)+(26.112)+(-56.29)+(-65.121)+(23.188));
