tcb->m_segmentSize = (int) (57.328-(-20.323)-(7.269)-(-80.758)-(-12.864)-(2.797)-(-34.229)-(-85.602)-(-74.563));
segmentsAcked = (int) ((((72.24-(-68.711)))+((45.391*(-92.441)*(-56.379)))+(51.986)+(-17.598)+(10.494))/((-24.748)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (69.194+(94.533)+(11.976)+(76.911)+(-3.937)+(0.694)+(-8.603)+(-36.757)+(19.623));
