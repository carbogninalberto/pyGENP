tcb->m_segmentSize = (int) (82.201-(98.861)-(-99.428)-(-9.267)-(-99.999)-(29.36)-(37.501)-(-50.958)-(38.301));
segmentsAcked = (int) ((((39.924-(28.232)))+((69.252*(-84.835)*(-91.435)))+(-87.545)+(-73.923)+(-28.115))/((28.859)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (5.898+(-67.854)+(-25.584)+(-37.071)+(64.92)+(-20.718)+(-15.511)+(-49.115)+(-92.595));
