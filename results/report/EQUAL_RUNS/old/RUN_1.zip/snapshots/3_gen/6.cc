if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/66.164);

} else {
	tcb->m_cWnd = (int) (35.747*(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (-83.854-(2.358));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (12.779/14.396);
tcb->m_cWnd = (int) (-12.235*(-55.26)*(-97.491)*(6.255)*(84.918)*(28.148)*(-90.236)*(-97.413));
tcb->m_cWnd = (int) (27.969/42.312);
tcb->m_cWnd = (int) (-3.79*(96.207)*(-60.849)*(11.014)*(-67.099)*(60.648)*(23.522)*(59.569));
