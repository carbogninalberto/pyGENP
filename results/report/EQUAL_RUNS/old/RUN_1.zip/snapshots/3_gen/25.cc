ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((-66.746)+(-23.03)+(77.046)+(-63.82))/((24.767)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((-73.574)+(97.558)+(77.797)+(54.853))/((33.832)));
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (62.395*(21.778)*(21.396)*(29.282)*(22.896)*(-28.459)*(33.592));

} else {
	tcb->m_segmentSize = (int) (22.251*(28.243)*(21.826)*(48.182)*(49.679)*(83.693)*(16.305)*(36.412));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (74.037+(83.168)+(60.261)+(7.845)+(40.117));

}
