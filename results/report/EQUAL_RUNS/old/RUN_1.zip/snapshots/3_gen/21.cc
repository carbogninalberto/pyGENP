tcb->m_segmentSize = (int) (-29.043-(-56.038)-(-71.505)-(-51.783)-(12.084)-(-68.982)-(38.428)-(3.168)-(85.074));
segmentsAcked = (int) ((((-97.477-(4.903)))+((-6.486*(-60.916)*(-10.89)))+(-35.75)+(96.039)+(70.693))/((24.393)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-58.254+(1.802)+(-84.149)+(68.61)+(3.158)+(58.227)+(88.34)+(-57.651)+(-83.123));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-11.621+(46.949)+(84.583)+(-47.13)+(52.249)+(61.783)+(-99.856)+(54.269)+(82.322));
