if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (62.288*(23.268)*(70.248)*(segmentsAcked)*(13.364));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) ((56.899+(49.217)+(88.326)+(8.787)+(67.056))/41.64);

} else {
	tcb->m_cWnd = (int) (-72.244-(63.406)-(90.056)-(85.632)-(72.797)-(56.08));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (28.502*(95.906)*(90.661)*(tcb->m_segmentSize)*(77.329)*(82.525)*(28.157)*(69.585)*(tcb->m_cWnd));

}
int wXEcebNOHUqkUzkX = (int) (94.234-(4.73)-(-12.799)-(-40.793)-(-98.728)-(-11.019)-(-75.163));
segmentsAcked = (int) (-34.535-(-31.526)-(36.853));
