float dDNRuMuMAQxNXUbW = (float) (75.755*(64.245)*(40.947)*(27.291)*(12.095)*(5.474));
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	segmentsAcked = (int) (37.599+(86.02)+(69.474)+(17.055)+(29.422)+(71.795));

} else {
	segmentsAcked = (int) (segmentsAcked*(0.679)*(16.812)*(44.761)*(95.15));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (79.671+(5.721)+(-74.537)+(55.937)+(-40.124));
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	segmentsAcked = (int) (37.599+(86.02)+(69.474)+(17.055)+(29.422)+(71.795));

} else {
	segmentsAcked = (int) (segmentsAcked*(0.679)*(16.812)*(44.761)*(95.15));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked > dDNRuMuMAQxNXUbW) {
	segmentsAcked = (int) (-46.555+(65.027)+(92.04)+(32.955)+(23.498)+(53.991)+(98.469)+(41.523));
	tcb->m_segmentSize = (int) (86.854-(92.145)-(78.037)-(8.104)-(tcb->m_cWnd)-(83.914));

} else {
	segmentsAcked = (int) (92.289+(66.307)+(75.827)+(96.423)+(53.239)+(36.065)+(84.605)+(89.596)+(32.667));
	segmentsAcked = (int) (86.758-(tcb->m_cWnd)-(segmentsAcked)-(41.691)-(86.712)-(56.709)-(86.039)-(50.186));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (26.916+(52.733)+(30.572)+(31.015)+(81.534));
tcb->m_cWnd = (int) (-35.159*(-80.951)*(49.574)*(53.676)*(29.315)*(-67.481)*(6.92)*(-83.699)*(33.851));
if (segmentsAcked > dDNRuMuMAQxNXUbW) {
	segmentsAcked = (int) (-46.555+(65.027)+(92.04)+(32.955)+(23.498)+(53.991)+(98.469)+(41.523));
	tcb->m_segmentSize = (int) (86.854-(92.145)-(78.037)-(8.104)-(tcb->m_cWnd)-(83.914));

} else {
	segmentsAcked = (int) (92.289+(66.307)+(75.827)+(96.423)+(53.239)+(36.065)+(84.605)+(89.596)+(32.667));
	segmentsAcked = (int) (86.758-(tcb->m_cWnd)-(segmentsAcked)-(41.691)-(86.712)-(56.709)-(86.039)-(50.186));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-47.059*(-64.602)*(-50.369)*(26.122)*(-75.592)*(-55.638)*(-81.003)*(82.536)*(-85.782));
