int cofGXsZTTDsDlQHb = (int) 93.531;
int FWiFMkFaauINmWvp = (int) 21.734;
