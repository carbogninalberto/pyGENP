segmentsAcked = (int) (11.1/23.006);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	segmentsAcked = (int) (segmentsAcked*(0.679)*(16.812)*(44.761)*(95.15));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (37.599+(86.02)+(69.474)+(17.055)+(29.422)+(71.795));

}
tcb->m_segmentSize = (int) (-91.573+(22.288)+(-11.185)+(-92.695)+(22.431));
