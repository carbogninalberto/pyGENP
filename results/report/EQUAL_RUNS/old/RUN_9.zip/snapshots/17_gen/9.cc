float oVgyllGlLfIoiEEc = (float) (-88.852*(-88.197)*(-41.765)*(31.176)*(25.191));
tcb->m_segmentSize = (int) (77.463-(-55.083)-(36.32));
