if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (62.288*(23.268)*(70.248)*(segmentsAcked)*(-93.377));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) ((56.899+(49.217)+(88.326)+(8.787)+(67.056))/41.64);

} else {
	tcb->m_cWnd = (int) (37.036-(63.406)-(90.056)-(85.632)-(72.797)-(56.08));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (28.502*(95.906)*(90.661)*(tcb->m_segmentSize)*(22.99)*(82.525)*(28.157)*(69.585)*(tcb->m_cWnd));

}
segmentsAcked = (int) (32.526-(71.3)-(55.891)-(-41.536)-(74.852)-(85.003)-(96.979)-(-24.656)-(-8.231));
segmentsAcked = (int) (-31.835-(-98.288)-(-3.122));
