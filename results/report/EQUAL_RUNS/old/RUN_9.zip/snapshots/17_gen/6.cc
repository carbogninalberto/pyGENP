int nZuGeEqoeNESWecS = (int) (-13.437-(-59.893)-(44.815)-(20.193)-(-27.701)-(64.496)-(-40.787)-(-30.241));
int ZYoTtekuLtwbGCtO = (int) (-13.231*(-42.539)*(-61.719)*(92.057)*(-19.034)*(-89.3)*(-76.645)*(33.067)*(-9.38));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (((40.759)+(-68.873)+(-84.641)+(44.234)+(-19.868)+((-24.283*(-93.206)*(segmentsAcked)*(46.327)*(-5.928)*(43.501)))+(-3.453))/((-41.386)));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (((-44.719)+(32.605)+(17.09)+((45.474*(-87.015)*(-86.121)*(96.199)))+(43.495)+(10.319))/((-91.997)));
ReduceCwnd (tcb);
