segmentsAcked = (int) (((-19.469)+(-33.534)+(-94.408)+(-97.81)+(-69.993))/((68.363)+(70.06)+(-30.358)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
