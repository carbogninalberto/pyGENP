segmentsAcked = (int) (-50.772-(-84.28));
