ReduceCwnd (tcb);
segmentsAcked = (int) (-77.342+(68.2)+(95.04)+(-82.451)+(92.613)+(-35.864));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (56.585+(-28.716)+(3.265)+(-32.419)+(-47.507)+(-61.673)+(-55.501));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-23.782*(-43.196)*(-92.698));
segmentsAcked = (int) (60.174+(-17.897)+(-92.717)+(79.543)+(-13.409)+(91.021)+(-68.652));
tcb->m_segmentSize = (int) (-31.703*(-54.578)*(99.636));
