ReduceCwnd (tcb);
segmentsAcked = (int) (89.791+(61.689)+(-71.46)+(-43.825)+(23.717)+(40.893));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-12.999+(65.035)+(96.53)+(-21.324)+(50.069)+(-32.32)+(28.55));
segmentsAcked = (int) (-61.825+(-99.456)+(93.595)+(-75.776)+(-1.006)+(78.242));
tcb->m_segmentSize = (int) (81.146*(36.605)*(-35.531));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (45.743+(55.666)+(47.284)+(60.803)+(-26.182)+(-88.636)+(50.919));
tcb->m_segmentSize = (int) (-91.434*(-19.606)*(-2.445));
