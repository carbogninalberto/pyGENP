int wlRLmtwEnJtebCIW = (int) (86.177-(33.418)-(96.32)-(-12.98)-(12.25)-(-31.155));
float imdTcvqfhuiAwHwT = (float) (-18.569*(18.234)*(50.413)*(-7.26));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-24.566+(-57.441)+(40.924)+(-6.952)+(-45.325)+(-46.931)+(-37.908)+(4.175));
segmentsAcked = SlowStart (tcb, segmentsAcked);
