ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-51.802+(-53.916)+(-48.389)+(-5.922)+(-92.83)+(84.04));
segmentsAcked = (int) (62.49+(82.45)+(-38.73)+(9.757)+(47.333)+(21.292)+(75.445));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-96.803*(39.663)*(52.967));
segmentsAcked = (int) (15.932+(43.945)+(76.101)+(94.843)+(82.123)+(-96.931)+(-4.207));
tcb->m_segmentSize = (int) (12.258*(-55.426)*(43.366));
