int fxUynXknOoSlwLmx = (int) (41.332-(64.415)-(-95.464)-(99.039)-(47.913));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
