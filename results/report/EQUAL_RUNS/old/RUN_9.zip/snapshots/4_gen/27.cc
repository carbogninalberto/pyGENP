int iaWpsSxHVFljfrWx = (int) (32.268*(38.624));
tcb->m_segmentSize = (int) (54.482+(95.256)+(90.301)+(-62.311)+(46.814)+(79.958)+(-28.01));
int YwmPczmphihKTOUF = (int) 32.689;
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (96.061+(44.912)+(-36.743)+(64.677)+(70.191)+(18.833)+(88.976));
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (14.565+(66.765)+(76.634)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (14.565+(66.765)+(-14.565)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (14.565+(66.765)+(-14.565)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (14.565+(66.765)+(76.634)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (14.565+(66.765)+(76.634)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (14.565+(66.765)+(-14.565)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (14.565+(66.765)+(76.634)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

}
