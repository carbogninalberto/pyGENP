ReduceCwnd (tcb);
int YwmPczmphihKTOUF = (int) 40.833;
YwmPczmphihKTOUF = (int) (32.973/73.717);
tcb->m_segmentSize = (int) (43.617+(-8.954)+(77.007)+(-89.002)+(-9.196)+(-20.399)+(-9.867));
ReduceCwnd (tcb);
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (14.565+(66.765)+(-14.565)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (14.565+(66.765)+(-14.565)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

}
