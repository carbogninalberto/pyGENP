int ZZhNoyhPKuroMfzZ = (int) (31.442-(-76.634)-(-1.265)-(55.24)-(-84.645));
float cLGEtrRGIqqytYNo = (float) (-25.222+(-48.275)+(-16.21));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (cLGEtrRGIqqytYNo == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (30.613-(tcb->m_cWnd)-(88.977)-(50.366)-(83.649));

} else {
	tcb->m_cWnd = (int) (39.96*(89.707)*(41.74)*(41.097));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (cLGEtrRGIqqytYNo == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (39.96*(89.707)*(41.74)*(41.097));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (30.613-(tcb->m_cWnd)-(88.977)-(33.014)-(83.649));

}
