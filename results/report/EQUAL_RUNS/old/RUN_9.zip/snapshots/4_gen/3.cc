int ZHtTyKHsjJSlSfnw = (int) 70.213;
