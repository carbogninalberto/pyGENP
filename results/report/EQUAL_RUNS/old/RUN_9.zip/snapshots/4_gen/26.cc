int YwmPczmphihKTOUF = (int) 20.25;
YwmPczmphihKTOUF = (int) (-38.947/62.91);
int RNeMgmJRgBRiYVYZ = (int) (53.481+(-19.608));
tcb->m_segmentSize = (int) (-36.367+(22.145)+(48.563)+(-0.863)+(54.903)+(-17.625)+(-37.238));
ReduceCwnd (tcb);
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (14.565+(66.765)+(-14.565)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

}
YwmPczmphihKTOUF = (int) (-17.686/-78.025);
tcb->m_segmentSize = (int) (-55.955+(-22.387)+(-86.6)+(-84.154)+(45.438)+(-3.848)+(-18.826));
ReduceCwnd (tcb);
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (14.565+(66.765)+(-14.565)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
