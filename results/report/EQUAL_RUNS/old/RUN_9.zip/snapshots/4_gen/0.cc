ReduceCwnd (tcb);
segmentsAcked = (int) (67.218+(-87.615)+(-45.096)+(-34.89)+(92.525)+(14.589));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (83.823+(77.489)+(12.399)+(-56.91)+(37.193)+(1.533)+(36.379));
tcb->m_segmentSize = (int) (-1.953*(77.489)*(81.22));
