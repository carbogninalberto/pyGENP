int ZHtTyKHsjJSlSfnw = (int) 34.034;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ZHtTyKHsjJSlSfnw = (int) ((-93.098+(-60.496)+(-65.481)+(67.395)+(49.205)+(51.674)+(segmentsAcked)+(-1.477)+(-35.439))/3.193);
