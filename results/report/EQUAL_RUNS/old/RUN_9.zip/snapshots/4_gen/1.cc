int fxUynXknOoSlwLmx = (int) (50.092-(86.795)-(-54.965)-(53.205)-(56.235));
