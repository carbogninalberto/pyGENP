CongestionAvoidance (tcb, segmentsAcked);
int fxUynXknOoSlwLmx = (int) (5.431-(40.069)-(-26.035)-(99.422)-(16.035));
segmentsAcked = SlowStart (tcb, segmentsAcked);
