int ZHtTyKHsjJSlSfnw = (int) 37.259;
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ZHtTyKHsjJSlSfnw = (int) ((-91.815+(12.157)+(-0.397)+(11.699)+(20.635)+(24.948)+(segmentsAcked)+(12.329)+(-41.329))/-92.98);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
