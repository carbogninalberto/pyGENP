ReduceCwnd (tcb);
segmentsAcked = (int) (-42.932+(76.322)+(34.953)+(-5.947)+(-62.323)+(-33.88));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (56.107+(12.857)+(-30.428)+(-25.648)+(-27.226)+(28.296)+(48.692));
tcb->m_segmentSize = (int) (36.996*(-25.026)*(-52.947));
