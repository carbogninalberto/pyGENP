ReduceCwnd (tcb);
segmentsAcked = (int) (31.622+(80.243)+(-59.462)+(15.281)+(61.067)+(-94.66));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-51.715+(95.78)+(60.436)+(92.632)+(-14.365)+(-45.223)+(-37.854));
tcb->m_segmentSize = (int) (7.317*(-50.257)*(-90.824));
