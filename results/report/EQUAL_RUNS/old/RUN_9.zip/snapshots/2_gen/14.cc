segmentsAcked = (int) (40.211-(-37.948));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (31.352-(82.452));
	tcb->m_cWnd = (int) (99.149-(23.712)-(85.421)-(38.231)-(29.827));

} else {
	tcb->m_cWnd = (int) (segmentsAcked+(46.78)+(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (31.352-(82.452));
	tcb->m_cWnd = (int) (99.149-(23.712)-(85.421)-(38.231)-(29.827));

} else {
	tcb->m_cWnd = (int) (segmentsAcked+(46.78)+(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
