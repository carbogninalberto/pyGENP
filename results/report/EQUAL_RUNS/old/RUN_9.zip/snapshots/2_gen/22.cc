int YwmPczmphihKTOUF = (int) (29.705-(-51.912)-(-91.769)-(12.701)-(-73.815)-(37.832)-(11.565));
tcb->m_segmentSize = (int) (-95.741*(-1.328)*(-29.625)*(92.013)*(-70.414));
tcb->m_segmentSize = (int) (13.671+(-1.629)+(33.225)+(0.792)+(20.185)+(27.185)+(-71.742));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (14.565+(66.765)+(2.881)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (14.565+(66.765)+(-15.245)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

}
