int YwmPczmphihKTOUF = (int) (-40.666-(39.236)-(-78.631)-(-4.123)-(-59.079)-(-4.12)-(-96.201));
tcb->m_segmentSize = (int) (81.326+(3.996)+(55.286)+(-78.796)+(-39.826)+(-30.824)+(63.786));
ReduceCwnd (tcb);
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (14.565+(66.765)+(17.897)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

}
