tcb->m_segmentSize = (int) (-71.753-(12.885)-(-90.772)-(47.767));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (31.352-(82.452));
	tcb->m_cWnd = (int) (99.149-(23.712)-(85.421)-(38.231)-(29.827));

} else {
	tcb->m_cWnd = (int) (segmentsAcked+(46.78)+(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
