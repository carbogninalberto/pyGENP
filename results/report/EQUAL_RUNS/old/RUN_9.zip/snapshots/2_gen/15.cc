int ZHtTyKHsjJSlSfnw = (int) 9.064;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ZHtTyKHsjJSlSfnw = (int) ((32.209+(30.145)+(82.771)+(19.437)+(81.923)+(-56.152)+(segmentsAcked)+(49.897)+(10.028))/26.982);
