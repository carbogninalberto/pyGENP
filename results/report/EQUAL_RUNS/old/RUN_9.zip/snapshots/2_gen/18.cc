segmentsAcked = (int) (64.767+(44.586)+(1.44));
float MKPVJhgulrNEwmEY = (float) (78.346+(93.219)+(-34.043)+(-20.642));
