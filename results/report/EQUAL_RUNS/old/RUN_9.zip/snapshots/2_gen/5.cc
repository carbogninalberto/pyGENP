segmentsAcked = (int) (((-60.74)+(-54.984)+(-48.033)+(-48.879))/((31.821)+(97.481)+(-55.711)+(86.596)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
