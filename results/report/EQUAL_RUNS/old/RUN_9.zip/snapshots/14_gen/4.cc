int iFTmaprIGnPiZhJR = (int) 2.209;
iFTmaprIGnPiZhJR = (int) (7.103+(37.469)+(21.457)+(20.617)+(98.411));
