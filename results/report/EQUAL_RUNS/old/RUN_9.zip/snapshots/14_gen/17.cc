if (tcb->m_cWnd > tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_ssThresh*(93.736));
	segmentsAcked = (int) (0.155*(81.398)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(55.749)*(78.082)*(45.481));
	tcb->m_cWnd = (int) (45.8*(54.429)*(50.166)*(57.76)*(3.196));

} else {
	segmentsAcked = (int) (99.786+(18.362)+(55.777)+(segmentsAcked)+(87.264)+(96.817));
	segmentsAcked = (int) (22.53+(71.431));
	tcb->m_ssThresh = (int) (74.154+(tcb->m_cWnd)+(17.627)+(segmentsAcked));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (46.972-(92.503)-(tcb->m_cWnd)-(81.351)-(42.113)-(36.094)-(74.148));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (16.677+(33.204)+(16.293)+(tcb->m_ssThresh)+(1.911));

} else {
	tcb->m_ssThresh = (int) (80.684-(29.563)-(69.151));
	segmentsAcked = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
