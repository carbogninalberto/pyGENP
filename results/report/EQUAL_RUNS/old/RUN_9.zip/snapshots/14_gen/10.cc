segmentsAcked = (int) (((-17.821)+((tcb->m_ssThresh-(-70.206)-(tcb->m_segmentSize)-(0.07)-(72.323)))+(54.524)+(-71.686)+(75.461))/((-49.268)+(-80.121)));
ReduceCwnd (tcb);
