float PfIlxhiUkfBfnAMz = (float) (3.903/60.626);
