ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (51.641*(55.215)*(42.921)*(91.039)*(54.645)*(tcb->m_ssThresh));
	segmentsAcked = (int) (58.727*(27.673));

} else {
	tcb->m_cWnd = (int) (21.668*(41.386)*(92.111)*(76.471)*(segmentsAcked)*(70.665)*(14.346));
	tcb->m_segmentSize = (int) (0.341-(75.839)-(tcb->m_cWnd)-(tcb->m_cWnd)-(19.062)-(97.184)-(tcb->m_segmentSize)-(tcb->m_cWnd));

}
tcb->m_ssThresh = (int) (61.62-(9.699));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (62.545/0.1);
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(17.597)-(49.673));
	tcb->m_cWnd = (int) (79.555*(7.756)*(64.079)*(47.78)*(85.717)*(tcb->m_segmentSize)*(76.125)*(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (0.1/7.887);

} else {
	tcb->m_ssThresh = (int) (((10.209)+(41.982)+(55.003)+((segmentsAcked-(35.445)-(42.476)-(26.62)-(72.864)-(34.615)-(82.576)-(0.43)))+(55.649)+(0.1)+(92.25))/((0.1)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (0.1/0.1);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
