float SxOElxRJpQVqEUUD = (float) (89.839+(27.634)+(57.306)+(83.608)+(-33.16));
SxOElxRJpQVqEUUD = (float) (90.684+(-79.956)+(66.851)+(27.927)+(56.863)+(43.238)+(73.399)+(-9.548));
segmentsAcked = (int) (-14.893-(-18.449)-(84.395)-(-82.703)-(93.465)-(43.768)-(38.335)-(3.877));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((-22.477)+((-18.041+(25.081)+(-31.541)+(73.435)+(tcb->m_cWnd)+(6.115)+(segmentsAcked)+(16.628)+(-43.728)))+(65.38)+(67.485))/((28.806)));
segmentsAcked = (int) (-15.531-(10.16)-(-82.62)-(-11.861)-(-74.67)-(-32.544)-(-12.947)-(-61.42));
