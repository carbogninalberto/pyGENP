tcb->m_segmentSize = (int) (-70.177/6.905);
ReduceCwnd (tcb);
