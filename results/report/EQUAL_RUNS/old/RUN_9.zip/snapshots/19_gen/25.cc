if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (93.615*(89.576)*(39.747)*(59.608)*(tcb->m_ssThresh)*(82.888)*(74.582)*(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (95.652-(36.524));
	segmentsAcked = (int) (90.593-(4.592)-(63.485)-(81.14)-(tcb->m_cWnd)-(9.174));
	tcb->m_ssThresh = (int) (43.252+(85.138)+(14.688));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (0.1/0.1);
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(61.209)+(20.002)+(80.335)+(62.62)+(31.338)+(58.045)+(tcb->m_ssThresh)+(48.376));
	tcb->m_cWnd = (int) (62.126+(tcb->m_cWnd)+(23.938)+(tcb->m_cWnd)+(18.956)+(34.427)+(75.283)+(tcb->m_cWnd)+(83.14));
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (3.247*(49.184)*(70.42)*(tcb->m_ssThresh)*(58.508));
	tcb->m_cWnd = (int) (5.194-(85.914)-(16.921));
	tcb->m_cWnd = (int) (segmentsAcked*(17.18)*(55.168)*(tcb->m_ssThresh)*(11.338)*(70.785)*(tcb->m_segmentSize)*(9.427)*(95.988));

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (76.419+(tcb->m_ssThresh)+(94.499)+(38.659));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(20.485)*(36.394)*(80.179)*(segmentsAcked)*(42.383)*(63.579)*(8.168));
	tcb->m_ssThresh = (int) (35.013/5.884);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
