ReduceCwnd (tcb);
segmentsAcked = (int) (-81.779+(-27.473)+(-58.088)+(91.969)+(22.577)+(89.288));
segmentsAcked = (int) (45.133+(-29.455)+(-7.508)+(-65.122)+(53.139)+(31.927)+(-83.612));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (7.395*(97.189)*(-5.351));
segmentsAcked = (int) (31.125+(-27.915)+(-51.593)+(39.572)+(-34.736)+(13.43)+(63.729));
tcb->m_segmentSize = (int) (68.896*(94.024)*(47.195));
