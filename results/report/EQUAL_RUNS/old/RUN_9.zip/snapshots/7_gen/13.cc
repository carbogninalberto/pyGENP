int LropxGBZURRCODRR = (int) (38.819-(62.979)-(-78.353)-(60.289)-(91.799)-(10.345));
segmentsAcked = (int) (-44.601+(95.058));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (49.169*(92.347)*(11.215)*(-22.75)*(6.911)*(27.312)*(57.457));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (69.468*(-31.036)*(95.458)*(20.6)*(48.492)*(49.097)*(-11.88));
ReduceCwnd (tcb);
