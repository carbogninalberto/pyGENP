if (tcb->m_segmentSize <= segmentsAcked) {
	segmentsAcked = (int) ((55.079+(73.208)+(43.633)+(13.652)+(20.957)+(4.931)+(42.225)+(64.882)+(24.783))/23.228);

} else {
	segmentsAcked = (int) (73.267+(tcb->m_cWnd)+(95.002)+(64.336)+(tcb->m_ssThresh)+(segmentsAcked)+(45.333)+(8.603));
	tcb->m_ssThresh = (int) (92.775*(71.351)*(tcb->m_cWnd)*(94.058)*(86.888));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (16.385*(tcb->m_cWnd)*(37.615)*(tcb->m_segmentSize));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
