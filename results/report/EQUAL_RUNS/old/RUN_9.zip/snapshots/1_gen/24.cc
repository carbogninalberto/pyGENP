tcb->m_segmentSize = (int) (36.113-(95.402)-(71.112)-(segmentsAcked));
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_ssThresh = (int) (70.972-(63.968)-(74.044)-(70.91));

} else {
	tcb->m_ssThresh = (int) (18.755+(48.755)+(tcb->m_segmentSize));

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked >= tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_segmentSize+(11.631)+(77.463)+(1.289));

} else {
	segmentsAcked = (int) (90.976+(tcb->m_cWnd)+(96.97)+(42.464)+(11.973)+(tcb->m_cWnd)+(46.966)+(segmentsAcked));

}
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (31.352-(82.452));
	tcb->m_cWnd = (int) (99.149-(23.712)-(85.421)-(38.231)-(29.827));

} else {
	tcb->m_cWnd = (int) (segmentsAcked+(46.78)+(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
