if (tcb->m_segmentSize < tcb->m_ssThresh) {
	segmentsAcked = (int) (99.358*(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (2.091+(segmentsAcked)+(87.138)+(tcb->m_segmentSize)+(93.292)+(48.211)+(31.402)+(99.4)+(98.629));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (((0.1)+(54.909)+(58.997)+(14.508)+(25.154)+(95.247)+(0.1))/((40.13)));
tcb->m_segmentSize = (int) (43.824*(5.643)*(48.666)*(26.958)*(68.769)*(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (21.346/0.1);

} else {
	tcb->m_ssThresh = (int) (91.91*(4.686)*(93.956)*(40.026)*(81.036)*(93.243)*(87.453));
	tcb->m_ssThresh = (int) (8.495/0.1);
	tcb->m_cWnd = (int) (32.392-(86.75)-(63.395)-(tcb->m_segmentSize));

}
