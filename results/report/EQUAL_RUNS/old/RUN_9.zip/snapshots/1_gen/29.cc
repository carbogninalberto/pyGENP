tcb->m_ssThresh = (int) (((0.1)+((segmentsAcked*(22.84)*(tcb->m_cWnd)*(89.921)*(82.858)))+(0.1)+(0.1)+((74.354*(63.996)*(89.857)*(tcb->m_ssThresh)*(38.311)*(92.055)*(39.855)*(70.33)))+(26.889))/((17.635)+(63.515)+(0.1)));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (((19.781)+(0.1)+(9.327)+(5.117))/((38.643)+(0.1)+(88.237)+(0.1)+(39.206)));
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	segmentsAcked = (int) (77.647+(24.868)+(40.795)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (0.1/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (segmentsAcked+(29.278)+(49.001)+(79.8)+(52.46)+(segmentsAcked));
