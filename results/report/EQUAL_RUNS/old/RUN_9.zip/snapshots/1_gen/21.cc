CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (segmentsAcked*(27.4)*(tcb->m_segmentSize)*(54.688));
tcb->m_cWnd = (int) (16.1*(64.192)*(tcb->m_ssThresh)*(55.351)*(89.959)*(57.561)*(tcb->m_cWnd)*(56.533));
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(75.597)+(76.004)+(71.837)+(13.394)+(28.502)+(83.204)+(45.216));
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	segmentsAcked = (int) (75.032+(tcb->m_segmentSize)+(51.908)+(81.237)+(47.489));
	segmentsAcked = (int) (9.338-(98.16)-(25.121)-(18.966)-(28.859));

} else {
	segmentsAcked = (int) (segmentsAcked+(84.908)+(71.626));
	tcb->m_cWnd = (int) (0.1/0.1);
	ReduceCwnd (tcb);

}
