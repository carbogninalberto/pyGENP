tcb->m_segmentSize = (int) (0.1/50.799);
segmentsAcked = (int) (tcb->m_segmentSize-(89.363)-(51.31)-(83.27)-(85.624)-(segmentsAcked)-(77.621));
tcb->m_segmentSize = (int) (5.022*(6.321)*(tcb->m_segmentSize)*(25.587)*(12.748));
segmentsAcked = (int) (88.636*(6.396)*(58.94)*(27.167)*(75.195)*(tcb->m_ssThresh)*(57.788)*(tcb->m_ssThresh)*(93.172));
tcb->m_ssThresh = (int) (segmentsAcked+(tcb->m_cWnd)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(11.943)+(45.638)+(41.694));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
