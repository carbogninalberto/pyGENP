tcb->m_cWnd = (int) (68.675-(tcb->m_ssThresh)-(74.023)-(12.34)-(29.529)-(17.121)-(53.979)-(23.733));
tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(49.278))/((71.63)+(0.1)+(29.279)+(0.1)));
tcb->m_ssThresh = (int) (50.52+(tcb->m_ssThresh)+(57.002)+(49.959)+(85.796)+(segmentsAcked));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
