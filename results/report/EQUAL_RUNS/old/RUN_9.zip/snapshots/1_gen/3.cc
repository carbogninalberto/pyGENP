tcb->m_ssThresh = (int) (0.1/(tcb->m_cWnd*(14.446)*(tcb->m_segmentSize)*(58.198)*(34.178)*(75.756)*(27.3)));
int sztNJfsxqbuplNza = (int) (tcb->m_segmentSize*(69.227)*(58.158));
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (90.827/0.1);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	segmentsAcked = (int) (57.795+(3.621)+(44.818)+(sztNJfsxqbuplNza)+(48.522)+(53.724)+(33.336)+(13.073));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) ((5.693*(43.226)*(29.892))/0.1);

} else {
	segmentsAcked = (int) (81.144/46.934);
	tcb->m_segmentSize = (int) (4.014/0.1);
	segmentsAcked = (int) (28.551+(55.297)+(32.356)+(84.919)+(6.111));

}
if (tcb->m_cWnd < sztNJfsxqbuplNza) {
	sztNJfsxqbuplNza = (int) (92.541+(7.858)+(tcb->m_ssThresh)+(18.785)+(15.295)+(68.371)+(78.785)+(43.374));
	tcb->m_cWnd = (int) ((1.537-(70.951)-(segmentsAcked)-(62.197)-(0.575)-(30.774))/(20.963+(58.298)+(22.656)+(80.36)+(82.645)+(tcb->m_ssThresh)+(34.776)+(26.769)));

} else {
	sztNJfsxqbuplNza = (int) (38.083-(tcb->m_segmentSize)-(62.5)-(sztNJfsxqbuplNza)-(17.236)-(89.66)-(segmentsAcked)-(98.199)-(77.961));
	tcb->m_segmentSize = (int) (((28.363)+(0.1)+(0.1)+((segmentsAcked*(tcb->m_ssThresh)*(31.713)*(60.423)*(59.666)*(47.634)*(39.711)*(36.632)))+(65.926))/((59.53)+(68.274)));

}
segmentsAcked = (int) (55.419-(33.928)-(48.032)-(78.256)-(1.878));
if (segmentsAcked >= tcb->m_cWnd) {
	segmentsAcked = (int) (68.366-(40.342)-(segmentsAcked)-(tcb->m_segmentSize)-(80.328)-(54.767));
	sztNJfsxqbuplNza = (int) (46.989*(61.967)*(84.544));

} else {
	segmentsAcked = (int) (78.326*(81.123)*(13.061));
	tcb->m_ssThresh = (int) (75.893+(75.286)+(65.733)+(92.599));
	CongestionAvoidance (tcb, segmentsAcked);

}
