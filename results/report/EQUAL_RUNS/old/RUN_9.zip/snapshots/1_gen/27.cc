if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (0.1/34.211);
	tcb->m_segmentSize = (int) (0.1/48.184);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (55.4+(47.081)+(tcb->m_segmentSize)+(82.395)+(segmentsAcked));

}
segmentsAcked = (int) (12.332+(11.016)+(5.778)+(14.646)+(14.432)+(57.923));
tcb->m_ssThresh = (int) (35.207+(33.897)+(tcb->m_cWnd)+(69.084)+(74.442));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (13.593+(11.83)+(22.875)+(tcb->m_ssThresh)+(26.401)+(96.487)+(59.713));
tcb->m_ssThresh = (int) (86.889*(segmentsAcked));
tcb->m_segmentSize = (int) (62.103*(4.165)*(63.092));
