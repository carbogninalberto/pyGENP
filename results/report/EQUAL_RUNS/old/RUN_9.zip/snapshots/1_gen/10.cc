tcb->m_cWnd = (int) (77.321-(8.277));
int bZiLtnVJlWLlxHGy = (int) (5.673*(17.976)*(13.988)*(tcb->m_segmentSize));
bZiLtnVJlWLlxHGy = (int) (22.276-(18.748)-(tcb->m_cWnd)-(88.494)-(74.606)-(84.324)-(13.305)-(30.252));
segmentsAcked = (int) (42.767*(99.237));
if (tcb->m_segmentSize == bZiLtnVJlWLlxHGy) {
	tcb->m_ssThresh = (int) (7.067*(41.766));
	tcb->m_ssThresh = (int) (74.364+(tcb->m_cWnd)+(5.414)+(96.769)+(tcb->m_ssThresh)+(43.109)+(80.705)+(33.19));

} else {
	tcb->m_ssThresh = (int) (68.346-(22.032)-(80.368)-(57.982)-(79.236));
	tcb->m_segmentSize = (int) (81.108/19.617);

}
if (bZiLtnVJlWLlxHGy < tcb->m_ssThresh) {
	segmentsAcked = (int) (91.836+(43.113)+(41.714)+(tcb->m_segmentSize)+(19.783)+(9.621)+(segmentsAcked)+(3.409));

} else {
	segmentsAcked = (int) (((0.1)+((42.854-(53.131)-(tcb->m_ssThresh)-(14.832)-(50.55)-(bZiLtnVJlWLlxHGy)-(tcb->m_segmentSize)-(52.417)-(87.617)))+(0.1)+(54.453))/((0.1)));
	tcb->m_segmentSize = (int) ((((70.898-(48.982)))+(0.1)+(0.1)+(51.202))/((16.278)));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_cWnd < bZiLtnVJlWLlxHGy) {
	tcb->m_ssThresh = (int) (20.768-(tcb->m_cWnd)-(68.011)-(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(69.457)-(18.999)-(2.168)-(61.994)-(93.736)-(82.992));
	tcb->m_segmentSize = (int) (0.1/(63.745*(76.397)*(18.972)*(91.855)*(bZiLtnVJlWLlxHGy)*(bZiLtnVJlWLlxHGy)));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < bZiLtnVJlWLlxHGy) {
	tcb->m_cWnd = (int) (segmentsAcked*(36.03)*(86.992)*(84.768)*(72.785)*(32.589)*(76.57));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);

}
