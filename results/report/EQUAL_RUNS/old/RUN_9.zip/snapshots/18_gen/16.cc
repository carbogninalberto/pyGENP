tcb->m_cWnd = (int) (69.104-(-38.298)-(87.755)-(29.054)-(37.448));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
