int frkBYjOwDVwREayx = (int) 20.646;
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (3.568+(-12.476)+(27.492));
