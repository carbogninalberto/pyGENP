ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (45.671-(99.962)-(30.53)-(tcb->m_segmentSize)-(38.473)-(52.729)-(95.515)-(35.282));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(30.814)+(0.1))/((1.767)+(0.1)+(0.1)+(0.1)));

}
