int frkBYjOwDVwREayx = (int) 20.646;
if (segmentsAcked > frkBYjOwDVwREayx) {
	tcb->m_segmentSize = (int) (51.607-(93.715)-(segmentsAcked)-(41.418)-(53.19)-(49.016)-(79.706)-(-69.795)-(65.012));
	tcb->m_segmentSize = (int) (86.637+(51.908)+(5.275)+(5.378)+(31.91)+(3.844)+(81.601)+(86.488));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(90.79)-(16.489)-(64.229)-(8.354)-(segmentsAcked)-(45.696)-(84.134)-(45.552));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(3.446))/((0.1)+(0.1)));

}
