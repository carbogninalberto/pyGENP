segmentsAcked = SlowStart (tcb, segmentsAcked);
int SoTxtvziUcHDEaAJ = (int) 35.695;
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
SoTxtvziUcHDEaAJ = (int) (60.935-(-76.277)-(36.159)-(82.046)-(38.36)-(42.348)-(-82.463)-(-26.441)-(-94.387));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
SoTxtvziUcHDEaAJ = (int) (70.496-(67.556)-(1.954)-(10.411)-(-91.73)-(35.33)-(-40.206)-(-56.406)-(1.39));
