ReduceCwnd (tcb);
segmentsAcked = (int) (-13.672+(46.39)+(-30.972)+(-56.256)+(63.789)+(-6.571));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (12.152*(-79.161)*(-70.46));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (42.659+(42.728)+(-31.488)+(9.53)+(-91.831)+(-4.527)+(22.864));
segmentsAcked = (int) (-51.001+(45.271)+(-12.71)+(94.039)+(-8.679)+(7.933)+(-70.415));
tcb->m_segmentSize = (int) (12.936*(-29.223)*(-11.291));
tcb->m_segmentSize = (int) (20.79*(65.948)*(16.724));
