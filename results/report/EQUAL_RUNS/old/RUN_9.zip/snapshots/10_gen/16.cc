int YsQirGBsPkBlteys = (int) (51.932*(-24.593)*(-98.592)*(66.507)*(18.296));
