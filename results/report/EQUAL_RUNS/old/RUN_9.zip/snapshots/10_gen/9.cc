ReduceCwnd (tcb);
segmentsAcked = (int) (-96.009+(4.61)+(46.386)+(-16.457)+(-37.158)+(25.136));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (1.155+(72.159)+(64.068)+(33.344)+(-46.225)+(-27.201)+(22.936));
segmentsAcked = (int) (63.068+(30.131)+(-32.692)+(-31.673)+(45.696)+(-44.23)+(-41.383));
tcb->m_segmentSize = (int) (12.503*(-88.077)*(-34.773));
tcb->m_segmentSize = (int) (-29.874*(44.136)*(61.324));
