segmentsAcked = SlowStart (tcb, segmentsAcked);
int SoTxtvziUcHDEaAJ = (int) 22.989;
segmentsAcked = SlowStart (tcb, segmentsAcked);
SoTxtvziUcHDEaAJ = (int) (67.905-(-67.891)-(-4.61)-(-20.656)-(-61.601)-(9.851)-(-50.89)-(79.646)-(-98.61));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
SoTxtvziUcHDEaAJ = (int) (99.405-(-13.5)-(39.933)-(1.531)-(-6.183)-(49.797)-(75.709)-(-34.75)-(58.091));
