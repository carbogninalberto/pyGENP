segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (87.09-(28.5)-(49.656)-(49.916)-(53.118)-(74.108)-(-89.103)-(15.151)-(5.213));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(8.543));

} else {
	tcb->m_segmentSize = (int) (30.868/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-83.081*(-83.469)*(-86.235)*(-75.347)*(-51.918)*(18.474)*(41.4));
CongestionAvoidance (tcb, segmentsAcked);
