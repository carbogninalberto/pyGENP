ReduceCwnd (tcb);
segmentsAcked = (int) (45.469+(-46.78)+(57.408)+(-49.287)+(70.289)+(98.501));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (96.255+(34.374)+(-4.38)+(28.456)+(50.846)+(6.018)+(-83.727));
tcb->m_segmentSize = (int) (69.791*(-43.347)*(-97.968));
