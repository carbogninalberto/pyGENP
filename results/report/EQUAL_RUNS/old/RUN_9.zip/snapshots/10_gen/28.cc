ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_segmentSize = (int) (78.426/(19.161-(64.697)-(35.683)-(10.621)-(16.15)-(segmentsAcked)));

} else {
	tcb->m_segmentSize = (int) (64.295-(68.729)-(tcb->m_segmentSize)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(95.647)+(1.963)+(56.846)+(tcb->m_cWnd)+(77.546)+(tcb->m_segmentSize)+(91.943));

}
tcb->m_cWnd = (int) (-16.395*(-7.541)*(-26.232)*(-50.469)*(-28.844)*(98.93)*(55.306)*(81.355));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_segmentSize = (int) (78.426/(19.161-(64.697)-(35.683)-(10.621)-(16.15)-(segmentsAcked)));

} else {
	tcb->m_segmentSize = (int) (64.295-(68.729)-(tcb->m_segmentSize)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(95.647)+(1.963)+(56.846)+(tcb->m_cWnd)+(77.546)+(tcb->m_segmentSize)+(91.943));

}
