ReduceCwnd (tcb);
segmentsAcked = (int) (56.989+(85.469)+(59.554)+(35.199)+(69.714)+(-81.366)+(-37.834));
segmentsAcked = (int) (86.284+(77.344)+(-9.644)+(-84.994)+(-62.742)+(-81.611));
tcb->m_segmentSize = (int) (81.53*(93.49)*(-83.593));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-42.057+(11.623)+(-74.446)+(-25.135)+(47.337)+(-49.302)+(-62.689));
tcb->m_segmentSize = (int) (-85.294*(-28.472)*(49.438));
