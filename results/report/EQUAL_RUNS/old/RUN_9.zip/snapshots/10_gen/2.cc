ReduceCwnd (tcb);
int SoTxtvziUcHDEaAJ = (int) 65.207;
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
SoTxtvziUcHDEaAJ = (int) (25.45-(32.8)-(-33.99)-(94.4)-(-38.752)-(-60.937)-(92.757)-(60.884)-(-85.073));
