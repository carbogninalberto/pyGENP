ReduceCwnd (tcb);
segmentsAcked = (int) (96.947+(-80.25)+(97.071)+(47.499)+(30.945)+(-12.409));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (20.3+(-0.255)+(21.877)+(10.152)+(-66.82)+(-17.632)+(-66.379));
segmentsAcked = (int) (73.053+(29.5)+(-87.381)+(-19.584)+(-81.167)+(-96.614)+(-63.979));
tcb->m_segmentSize = (int) (95.045*(76.019)*(-78.405));
tcb->m_segmentSize = (int) (-10.635*(-29.537)*(-16.438));
