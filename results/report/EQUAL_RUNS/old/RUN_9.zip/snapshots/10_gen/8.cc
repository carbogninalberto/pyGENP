ReduceCwnd (tcb);
segmentsAcked = (int) (-30.562+(-62.875)+(49.963)+(33.971)+(56.266)+(29.583));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-7.843+(-56.526)+(-86.042)+(98.538)+(-8.801)+(36.375)+(-41.782));
tcb->m_segmentSize = (int) (55.167*(95.283)*(-13.91));
