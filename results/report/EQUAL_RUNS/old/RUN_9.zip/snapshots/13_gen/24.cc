tcb->m_ssThresh = (int) (((39.123)+(0.1)+(0.1)+(0.1)+(42.564)+(0.1)+(0.1))/((0.1)));
tcb->m_cWnd = (int) (((0.1)+(73.552)+(0.1)+(0.1)+(41.535))/((0.1)+(7.567)));
tcb->m_ssThresh = (int) (3.578-(segmentsAcked)-(19.348)-(82.555)-(segmentsAcked)-(94.669));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (94.516-(tcb->m_ssThresh)-(56.837)-(segmentsAcked)-(4.249)-(29.104)-(22.538)-(24.858)-(53.666));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
