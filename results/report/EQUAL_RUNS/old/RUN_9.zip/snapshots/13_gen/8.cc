int iFTmaprIGnPiZhJR = (int) (-50.662-(-71.723));
iFTmaprIGnPiZhJR = (int) (67.362+(17.968)+(-31.889)+(-59.554)+(22.721));
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (30.851-(74.981)-(11.557)-(8.437));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (4.312-(68.919)-(65.573)-(85.321)-(1.457)-(87.576)-(83.995)-(tcb->m_cWnd)-(2.72));

}
segmentsAcked = (int) (((-69.367)+((-4.821+(tcb->m_cWnd)))+(-44.704)+(-75.126)+(-32.025))/((-36.218)+(51.64)+(-72.468)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
