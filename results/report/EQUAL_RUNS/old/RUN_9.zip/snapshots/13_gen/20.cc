segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (70.045*(66.753)*(49.358)*(65.245)*(98.213)*(48.085)*(tcb->m_ssThresh)*(32.843));
tcb->m_segmentSize = (int) (17.936/0.1);
tcb->m_ssThresh = (int) (60.746*(93.739)*(6.461)*(tcb->m_segmentSize)*(69.795)*(72.659)*(5.465)*(1.046));
tcb->m_cWnd = (int) (57.91+(85.507)+(81.91)+(80.686)+(70.425));
