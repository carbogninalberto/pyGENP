tcb->m_segmentSize = (int) (67.995*(tcb->m_ssThresh)*(82.66)*(segmentsAcked));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (25.947+(tcb->m_ssThresh)+(90.446));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (80.4-(11.364)-(62.508)-(91.879)-(tcb->m_cWnd)-(25.178)-(15.827)-(28.507));
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	segmentsAcked = (int) (segmentsAcked+(11.744)+(59.988)+(90.036));
	tcb->m_segmentSize = (int) (56.003+(tcb->m_segmentSize)+(48.092)+(94.869)+(18.216)+(tcb->m_ssThresh)+(71.309));

} else {
	segmentsAcked = (int) (67.536*(88.946));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
