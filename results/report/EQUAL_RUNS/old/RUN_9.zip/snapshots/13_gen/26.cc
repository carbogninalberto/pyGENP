if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (87.095+(71.719)+(tcb->m_cWnd));
	segmentsAcked = (int) (((73.238)+(36.169)+(0.1)+((88.399*(63.969)))+(0.1)+((90.518*(tcb->m_cWnd)*(90.937)*(15.98)*(43.441)*(30.088)*(23.625)))+(0.1))/((0.1)+(40.049)));
	tcb->m_cWnd = (int) (0.1/12.359);

} else {
	tcb->m_segmentSize = (int) (20.95+(9.503)+(47.854)+(72.057)+(tcb->m_cWnd));
	segmentsAcked = (int) (((0.1)+(39.731)+(0.1)+(0.1)+(0.1))/((95.3)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((41.28)+(27.666)+(89.35)+((48.611*(2.299)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(11.958)*(35.18)))+(0.1)+(10.651))/((0.1)+(0.1)));
segmentsAcked = (int) (7.473-(56.698)-(14.465)-(87.326)-(43.465)-(1.491)-(20.03));
