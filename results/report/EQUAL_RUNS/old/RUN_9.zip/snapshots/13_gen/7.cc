int yboTWXqHDrptLGIP = (int) (83.241/33.403);
ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	segmentsAcked = (int) (25.085+(42.528)+(9.747)+(13.229));

} else {
	segmentsAcked = (int) (23.593-(92.278)-(69.509));

}
tcb->m_segmentSize = (int) (59.124+(16.521)+(5.875)+(-4.316)+(81.689)+(40.304)+(83.455)+(-23.404));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(tcb->m_cWnd)-(segmentsAcked)-(83.422)-(segmentsAcked));
	tcb->m_cWnd = (int) (49.6-(47.335)-(52.172));

} else {
	tcb->m_cWnd = (int) (0.1/36.448);

}
