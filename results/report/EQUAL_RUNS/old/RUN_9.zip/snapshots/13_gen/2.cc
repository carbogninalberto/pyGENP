ReduceCwnd (tcb);
segmentsAcked = (int) (95.764+(48.884)+(70.904)+(-39.756)+(-79.383)+(-91.939));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (72.525+(-42.833)+(38.107)+(65.209)+(21.42)+(-96.911)+(-11.888));
tcb->m_segmentSize = (int) (78.936*(3.042)*(2.037));
