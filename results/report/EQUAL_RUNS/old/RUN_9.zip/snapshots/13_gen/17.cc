int yboTWXqHDrptLGIP = (int) (35.04/-19.297);
tcb->m_segmentSize = (int) (45.985*(12.237)*(65.555)*(29.313)*(23.79)*(-9.334)*(-82.636)*(-83.652));
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	segmentsAcked = (int) (25.085+(42.528)+(9.747)+(13.229));

} else {
	segmentsAcked = (int) (23.593-(92.278)-(69.509));

}
tcb->m_segmentSize = (int) (-88.039+(75.015)+(-92.61)+(40.302)+(86.476)+(99.825)+(18.378)+(-44.979));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(tcb->m_cWnd)-(segmentsAcked)-(83.422)-(segmentsAcked));
	tcb->m_cWnd = (int) (49.6-(47.335)-(52.172));

} else {
	tcb->m_cWnd = (int) (0.1/36.448);

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	segmentsAcked = (int) (25.085+(42.528)+(9.747)+(13.229));

} else {
	segmentsAcked = (int) (23.593-(92.278)-(69.509));

}
tcb->m_segmentSize = (int) (-19.49+(-88.929)+(98.167)+(-86.731)+(-77.662)+(90.235)+(66.86)+(-17.967));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(tcb->m_cWnd)-(segmentsAcked)-(83.422)-(segmentsAcked));
	tcb->m_cWnd = (int) (49.6-(47.335)-(52.172));

} else {
	tcb->m_cWnd = (int) (0.1/36.448);

}
