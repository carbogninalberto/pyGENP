float ufptDjvqBOELybEt = (float) 14.066;
segmentsAcked = (int) (-93.57-(38.505)-(-36.191)-(-82.856)-(-93.255)-(77.481)-(-32.47)-(-39.204));
int KnaCDLAcDCMntaSt = (int) 27.772;
float wmcflaDNOlajtvpM = (float) 88.744;
