int frkBYjOwDVwREayx = (int) 5.883;
