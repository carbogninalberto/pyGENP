TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (42.145+(tcb->m_cWnd)+(71.328)+(51.259));
if (segmentsAcked <= tcb->m_ssThresh) {
	segmentsAcked = (int) ((19.386+(51.077)+(tcb->m_segmentSize))/0.1);

} else {
	segmentsAcked = (int) ((86.287+(81.0)+(tcb->m_ssThresh)+(65.656)+(21.251)+(57.001)+(1.22)+(72.751))/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (97.922/57.362);
tcb->m_ssThresh = (int) ((segmentsAcked+(93.568)+(96.104)+(87.985))/0.1);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
