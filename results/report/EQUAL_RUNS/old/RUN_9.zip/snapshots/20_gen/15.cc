tcb->m_segmentSize = (int) (0.1/39.743);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(34.25)-(34.341)-(8.484)-(38.294)-(72.527));

} else {
	tcb->m_segmentSize = (int) (96.163+(56.158)+(61.039)+(57.137)+(72.643)+(99.108)+(8.99)+(43.95));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(22.117)+(8.533)+(86.808)+(46.57));
	tcb->m_ssThresh = (int) (36.311-(tcb->m_ssThresh)-(61.024)-(31.764)-(tcb->m_ssThresh)-(23.56)-(10.938));

}
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (22.896/0.1);
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(85.48)-(40.233)-(45.762)-(3.323)-(65.656)-(77.033));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(24.565));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (0.1/52.813);

}
