CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (17.635+(segmentsAcked));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(0.912)*(11.83));
	tcb->m_ssThresh = (int) (40.564*(76.382)*(39.833)*(53.255)*(87.855)*(segmentsAcked)*(47.249));
	segmentsAcked = (int) (6.067+(60.6)+(68.222)+(tcb->m_segmentSize)+(86.213));

}
float DxdMbJxINqIlnpxg = (float) (segmentsAcked+(97.641)+(89.452)+(38.443)+(4.587));
