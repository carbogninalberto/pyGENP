segmentsAcked = (int) (-64.528*(40.81)*(-90.327));
