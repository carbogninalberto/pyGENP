ReduceCwnd (tcb);
float nhmpKRVQLIsuECwo = (float) 37.8;
tcb->m_segmentSize = (int) (-69.625+(13.523)+(-92.348));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (30.868/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (87.09-(28.5)-(49.656)-(49.916)-(53.118)-(74.108)-(-89.103)-(15.151)-(5.213));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(8.543));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-96.779*(-62.87)*(-23.576)*(22.853)*(-98.605)*(96.372)*(64.402));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_segmentSize) {
	nhmpKRVQLIsuECwo = (float) (51.665-(26.057)-(57.885)-(17.416)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(42.405)-(50.28)-(86.614)-(81.176)-(81.298)-(23.414)-(30.391));

} else {
	nhmpKRVQLIsuECwo = (float) (tcb->m_segmentSize-(14.363)-(4.153)-(40.81)-(44.296)-(segmentsAcked)-(78.284));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-33.588*(47.226)*(-68.654)*(-28.587)*(46.173)*(-79.471)*(-26.335));
nhmpKRVQLIsuECwo = (float) (8.65*(-0.874));
if (segmentsAcked > tcb->m_segmentSize) {
	nhmpKRVQLIsuECwo = (float) (51.665-(26.057)-(57.885)-(17.416)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(42.405)-(50.28)-(86.614)-(81.176)-(81.298)-(23.414)-(30.391));

} else {
	nhmpKRVQLIsuECwo = (float) (tcb->m_segmentSize-(14.363)-(4.153)-(40.81)-(44.296)-(segmentsAcked)-(78.284));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
nhmpKRVQLIsuECwo = (float) (85.718*(-43.186));
tcb->m_cWnd = (int) (-16.311*(-19.132)*(92.785)*(1.193)*(-27.322)*(-14.698)*(-48.424));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_segmentSize) {
	nhmpKRVQLIsuECwo = (float) (51.665-(26.057)-(57.885)-(17.416)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(42.405)-(50.28)-(86.614)-(81.176)-(81.298)-(23.414)-(30.391));

} else {
	nhmpKRVQLIsuECwo = (float) (tcb->m_segmentSize-(14.363)-(4.153)-(40.81)-(44.296)-(segmentsAcked)-(78.284));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-21.157*(-39.617)*(74.331)*(62.076)*(-43.548)*(1.059)*(60.283));
nhmpKRVQLIsuECwo = (float) (8.508*(-49.131));
if (segmentsAcked > tcb->m_segmentSize) {
	nhmpKRVQLIsuECwo = (float) (51.665-(26.057)-(57.885)-(17.416)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(42.405)-(50.28)-(86.614)-(81.176)-(81.298)-(23.414)-(30.391));

} else {
	nhmpKRVQLIsuECwo = (float) (tcb->m_segmentSize-(14.363)-(4.153)-(40.81)-(44.296)-(segmentsAcked)-(78.284));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
nhmpKRVQLIsuECwo = (float) (98.814*(-68.948));
