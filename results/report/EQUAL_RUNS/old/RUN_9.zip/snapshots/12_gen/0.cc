segmentsAcked = (int) (-62.797+(-8.05)+(45.596)+(-54.749)+(56.234)+(51.054)+(-40.919));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (23.299-(-23.236)-(67.185));
segmentsAcked = SlowStart (tcb, segmentsAcked);
