ReduceCwnd (tcb);
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (74.107-(13.645));
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((70.636)+(0.1)));

} else {
	tcb->m_segmentSize = (int) ((67.621*(97.244)*(14.722)*(19.42)*(67.515)*(8.473)*(48.157)*(44.147)*(50.305))/70.08);
	tcb->m_cWnd = (int) (91.841+(99.475)+(60.938)+(3.324)+(50.987));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (92.151+(tcb->m_ssThresh)+(segmentsAcked)+(14.103)+(tcb->m_ssThresh)+(22.397)+(29.315));
	tcb->m_ssThresh = (int) (segmentsAcked-(31.357)-(99.823)-(83.621)-(68.892)-(51.826)-(85.163)-(86.727));

} else {
	tcb->m_ssThresh = (int) (38.229*(33.551));
	segmentsAcked = (int) (63.339/59.864);
	tcb->m_ssThresh = (int) (75.435-(81.504)-(segmentsAcked)-(65.452)-(2.126)-(89.593)-(18.071)-(33.293));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
