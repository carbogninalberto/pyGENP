segmentsAcked = (int) (-68.24-(40.542)-(-99.617)-(-36.62)-(-13.659)-(27.414));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(34.012)-(45.759)-(60.459)-(35.596));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(35.815)+(50.228));

}
