segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (61.177*(tcb->m_cWnd)*(49.598)*(15.696)*(28.849)*(86.67)*(91.258)*(88.575));
tcb->m_segmentSize = (int) (93.548-(37.924)-(tcb->m_cWnd)-(76.864)-(36.68)-(segmentsAcked));
tcb->m_segmentSize = (int) (68.095/57.133);
tcb->m_segmentSize = (int) (14.754-(41.972)-(69.501)-(42.189)-(15.832)-(84.123)-(tcb->m_cWnd)-(71.304));
segmentsAcked = (int) (tcb->m_cWnd*(5.726)*(94.21)*(82.452)*(tcb->m_cWnd)*(18.68)*(82.723)*(9.584));
