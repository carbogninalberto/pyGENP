ReduceCwnd (tcb);
segmentsAcked = (int) (-53.231+(9.82)+(0.395)+(-72.833)+(-37.246)+(49.017));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-74.475+(-4.886)+(78.84)+(93.133)+(-34.602)+(-54.093)+(27.827));
tcb->m_segmentSize = (int) (60.853*(-17.449)*(-18.152));
