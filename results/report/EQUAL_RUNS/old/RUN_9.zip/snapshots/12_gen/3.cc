ReduceCwnd (tcb);
segmentsAcked = (int) (37.208+(-41.233)+(8.907)+(76.251)+(93.981)+(-28.003));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-26.264+(91.23)+(62.481)+(-74.649)+(-85.036)+(62.79)+(65.135));
tcb->m_segmentSize = (int) (-15.208*(-84.87)*(71.519));
