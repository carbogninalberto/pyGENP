tcb->m_ssThresh = (int) (83.427-(60.896)-(segmentsAcked)-(63.406)-(47.861)-(15.145)-(tcb->m_cWnd));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((54.0)+(0.1)+((tcb->m_cWnd*(3.084)*(segmentsAcked)*(65.998)*(65.475)*(32.883)))+(56.116))/((67.787)));
	tcb->m_ssThresh = (int) (15.056+(28.682)+(segmentsAcked)+(48.298)+(83.209)+(59.917)+(57.581));
	tcb->m_cWnd = (int) (43.896+(96.348)+(46.069)+(83.667)+(32.926)+(88.47)+(61.097)+(79.375)+(64.032));

} else {
	tcb->m_cWnd = (int) (((27.914)+(49.004)+((1.106-(60.022)))+(76.996))/((0.1)+(28.622)+(30.029)));

}
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (16.127/74.233);
	segmentsAcked = (int) (83.656+(67.214)+(6.983));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(10.595)+(36.649)+(89.399)+(26.279)+(59.214));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(tcb->m_cWnd)*(47.953)*(tcb->m_cWnd));
	tcb->m_segmentSize = (int) ((((79.811+(24.16)+(37.932)+(73.024)+(86.019)+(80.143)+(90.882)+(2.174)))+(68.846)+(0.1)+(0.1)+(0.1)+(13.504))/((0.1)));
	tcb->m_ssThresh = (int) (((0.1)+(15.149)+(0.1)+(0.1)+((tcb->m_cWnd+(43.469)+(85.266)+(27.254)+(35.055)+(tcb->m_segmentSize)+(37.104)))+(79.574))/((31.908)));

}
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	segmentsAcked = (int) (79.335-(69.062)-(91.6)-(49.974)-(37.419)-(57.988)-(tcb->m_ssThresh)-(89.403)-(33.183));

} else {
	segmentsAcked = (int) (28.981+(75.355)+(tcb->m_segmentSize)+(80.131)+(85.301));
	segmentsAcked = (int) (tcb->m_cWnd+(74.734)+(67.51)+(4.033)+(26.522));

}
