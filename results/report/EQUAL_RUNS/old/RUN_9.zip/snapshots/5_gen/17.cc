int GxPIIFwSVduBijQN = (int) (segmentsAcked-(77.39)-(80.854)-(6.841)-(62.789)-(13.769)-(82.246));
float TTxlLJVgRsXjsMKZ = (float) (42.288-(16.92)-(10.435)-(32.117)-(15.974)-(76.965)-(16.364)-(8.111)-(64.454));
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) ((78.44*(92.389)*(97.811)*(47.944)*(42.391))/0.1);
	tcb->m_ssThresh = (int) (33.479*(1.249)*(43.485)*(81.545)*(19.023)*(tcb->m_segmentSize)*(18.581)*(57.477));
	tcb->m_segmentSize = (int) ((((33.62+(51.59)+(28.23)+(90.043)+(84.704)+(25.36)+(18.31)))+((18.9+(tcb->m_cWnd)+(84.261)+(43.729)+(17.652)+(31.507)+(45.174)))+(77.449)+(60.429)+(0.1))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (76.797-(56.105)-(12.094)-(15.734)-(11.507)-(11.748)-(tcb->m_ssThresh)-(TTxlLJVgRsXjsMKZ));
	tcb->m_cWnd = (int) (83.958/64.796);

}
if (segmentsAcked <= TTxlLJVgRsXjsMKZ) {
	tcb->m_segmentSize = (int) (69.361-(51.325)-(79.475));

} else {
	tcb->m_segmentSize = (int) (56.053*(GxPIIFwSVduBijQN)*(19.84));

}
if (segmentsAcked < TTxlLJVgRsXjsMKZ) {
	segmentsAcked = (int) (30.245-(53.449)-(45.296)-(48.977)-(90.56)-(9.452)-(13.421)-(30.317)-(27.65));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (59.235-(35.459)-(28.939)-(99.886)-(GxPIIFwSVduBijQN)-(40.289));

} else {
	segmentsAcked = (int) (1.537*(72.686)*(tcb->m_ssThresh)*(1.433));
	GxPIIFwSVduBijQN = (int) (46.18+(tcb->m_cWnd)+(tcb->m_cWnd)+(65.265)+(38.723)+(64.302)+(10.872));

}
if (TTxlLJVgRsXjsMKZ >= segmentsAcked) {
	GxPIIFwSVduBijQN = (int) (((25.724)+(0.1)+(87.913)+((GxPIIFwSVduBijQN-(57.426)-(tcb->m_cWnd)-(99.267)-(13.208)))+(87.483)+(82.497))/((38.052)+(81.023)));

} else {
	GxPIIFwSVduBijQN = (int) (((59.582)+(80.581)+(19.347)+(0.1)+(73.53))/((20.609)+(87.559)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (GxPIIFwSVduBijQN == TTxlLJVgRsXjsMKZ) {
	GxPIIFwSVduBijQN = (int) (61.559/99.819);
	tcb->m_cWnd = (int) (7.008/40.005);

} else {
	GxPIIFwSVduBijQN = (int) (((68.659)+((99.433-(77.37)-(tcb->m_segmentSize)-(GxPIIFwSVduBijQN)-(53.982)-(segmentsAcked)-(58.492)-(3.296)-(78.315)))+(0.1)+(95.582)+(0.1))/((84.078)));

}
GxPIIFwSVduBijQN = (int) (85.853-(38.711)-(tcb->m_cWnd)-(86.758)-(22.504)-(60.099)-(tcb->m_ssThresh)-(1.702));
