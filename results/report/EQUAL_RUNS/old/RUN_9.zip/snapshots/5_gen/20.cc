tcb->m_segmentSize = (int) (((45.165)+((tcb->m_ssThresh*(2.9)*(tcb->m_ssThresh)*(0.352)*(68.33)))+(0.1)+((37.922+(42.571)+(79.932)))+(0.1)+(0.1))/((0.1)));
int CyTXYMvjQKXjquOD = (int) (67.349/0.1);
if (tcb->m_ssThresh >= CyTXYMvjQKXjquOD) {
	segmentsAcked = (int) ((((27.044-(segmentsAcked)-(20.138)-(44.527)-(16.905)-(tcb->m_ssThresh)-(40.891)-(20.371)))+((75.127-(tcb->m_cWnd)-(94.59)))+(8.756)+(0.1))/((78.486)));

} else {
	segmentsAcked = (int) (2.373+(63.653)+(87.172)+(46.156)+(83.33)+(50.918)+(50.638)+(38.629));
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(10.126)+(4.633)+(57.684)+(8.565));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (61.668*(tcb->m_segmentSize)*(51.421)*(6.39)*(2.567)*(21.223)*(39.252));
	CongestionAvoidance (tcb, segmentsAcked);
	CyTXYMvjQKXjquOD = (int) (3.285-(41.761)-(20.931)-(segmentsAcked)-(21.308)-(tcb->m_ssThresh)-(85.432)-(50.653));

} else {
	tcb->m_cWnd = (int) (90.561+(48.459)+(79.928));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (((85.449)+(5.738)+(0.1)+(0.1))/((0.1)));
