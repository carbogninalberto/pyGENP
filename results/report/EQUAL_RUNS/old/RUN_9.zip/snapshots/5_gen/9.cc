ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (58.599+(54.164)+(-50.171)+(90.563)+(-42.879)+(14.685));
segmentsAcked = (int) (-96.931+(33.727)+(71.224)+(-97.186)+(97.489)+(-53.817)+(-66.682));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-82.682*(22.783)*(66.533));
segmentsAcked = (int) (-48.882+(-52.671)+(-52.645)+(29.755)+(90.862)+(-85.077)+(95.91));
tcb->m_segmentSize = (int) (36.98*(42.055)*(1.289));
