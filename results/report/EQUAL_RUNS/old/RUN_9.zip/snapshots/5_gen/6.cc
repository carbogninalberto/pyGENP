ReduceCwnd (tcb);
segmentsAcked = (int) (48.735+(-18.213)+(36.011)+(-6.284)+(-62.838)+(77.124));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-54.171+(84.662)+(0.554)+(1.144)+(-80.629)+(22.338)+(-89.657));
tcb->m_segmentSize = (int) (89.576*(32.104)*(75.21));
