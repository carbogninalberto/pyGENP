if (tcb->m_cWnd <= segmentsAcked) {
	segmentsAcked = (int) (10.435-(93.284));
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (45.541-(97.494)-(59.06)-(19.753)-(42.346)-(68.446));

} else {
	segmentsAcked = (int) (76.028*(20.882));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (53.58+(77.762)+(73.186)+(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (14.942+(89.102)+(63.533)+(73.603)+(92.382)+(79.935));
	segmentsAcked = (int) (tcb->m_segmentSize*(39.795)*(99.334));

} else {
	tcb->m_ssThresh = (int) (88.412*(3.282)*(58.377)*(87.501)*(55.999)*(70.733)*(60.47));

}
CongestionAvoidance (tcb, segmentsAcked);
