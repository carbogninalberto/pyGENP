if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_cWnd = (int) (71.498+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(segmentsAcked)+(74.897)+(73.279)+(35.633));
	tcb->m_segmentSize = (int) (57.507*(44.222)*(12.917)*(segmentsAcked)*(segmentsAcked));
	tcb->m_ssThresh = (int) (8.975-(17.124)-(tcb->m_ssThresh)-(67.743)-(15.044)-(92.645));

} else {
	tcb->m_cWnd = (int) (59.182*(67.328)*(40.193)*(65.846)*(tcb->m_cWnd)*(60.881)*(10.242));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	segmentsAcked = (int) (segmentsAcked*(18.007)*(79.97)*(44.015)*(14.731));
	tcb->m_cWnd = (int) (37.681-(29.111)-(77.281)-(tcb->m_cWnd)-(8.541));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(48.834)*(tcb->m_ssThresh)*(94.91)*(9.406)*(18.522));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (4.94*(98.402)*(59.033)*(segmentsAcked)*(segmentsAcked));
	tcb->m_cWnd = (int) ((tcb->m_ssThresh*(tcb->m_segmentSize)*(tcb->m_cWnd)*(7.455)*(80.562))/69.437);
	tcb->m_cWnd = (int) (42.688/0.1);

} else {
	tcb->m_ssThresh = (int) (74.34+(24.381)+(87.686)+(15.134)+(50.143)+(tcb->m_ssThresh));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (4.478-(4.246)-(23.886));
