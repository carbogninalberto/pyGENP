int YwmPczmphihKTOUF = (int) 40.833;
float FnHtKdfVTpOrwLOr = (float) (-36.718*(56.148)*(39.548)*(65.228)*(-60.951));
