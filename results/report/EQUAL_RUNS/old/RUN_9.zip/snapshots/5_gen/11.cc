int ZHtTyKHsjJSlSfnw = (int) 87.296;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ZHtTyKHsjJSlSfnw = (int) ((-79.651+(-20.72)+(26.948)+(-93.218)+(-27.753)+(-78.851)+(segmentsAcked)+(1.431)+(23.355))/-23.75);
