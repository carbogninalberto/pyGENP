ReduceCwnd (tcb);
if (tcb->m_ssThresh >= segmentsAcked) {
	segmentsAcked = (int) (66.08*(64.845)*(tcb->m_cWnd)*(88.008)*(39.207)*(96.12)*(segmentsAcked)*(19.317)*(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (91.903-(28.306)-(80.567)-(79.319)-(52.985)-(70.64));
	tcb->m_cWnd = (int) (96.09-(3.435)-(13.217)-(69.169)-(51.205)-(24.926));

} else {
	segmentsAcked = (int) (0.1/15.372);

}
tcb->m_cWnd = (int) (36.064+(18.319)+(98.628)+(12.775)+(77.113)+(tcb->m_segmentSize)+(61.701)+(segmentsAcked));
segmentsAcked = (int) (26.388/53.986);
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (8.354*(54.948)*(tcb->m_cWnd)*(91.544));
	tcb->m_ssThresh = (int) (11.087/0.1);
	tcb->m_cWnd = (int) (93.548-(53.9));

} else {
	tcb->m_segmentSize = (int) ((tcb->m_ssThresh+(19.367)+(68.803)+(14.391)+(15.603)+(8.345)+(50.526))/(89.92+(13.337)+(segmentsAcked)));
	tcb->m_segmentSize = (int) (58.914+(88.49)+(36.696)+(27.113)+(44.085)+(47.598));
	tcb->m_cWnd = (int) (59.717+(47.701));

}
segmentsAcked = (int) (5.753*(segmentsAcked)*(98.963)*(10.125)*(tcb->m_cWnd)*(35.45)*(segmentsAcked)*(16.263)*(69.375));
