if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (3.12*(91.696)*(67.6)*(37.224)*(39.843)*(74.41)*(tcb->m_segmentSize)*(43.389)*(86.649));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (6.799-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (0.1/7.336);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (13.617+(86.802));
segmentsAcked = (int) (27.775*(62.507)*(83.63)*(74.282)*(46.38)*(94.257)*(39.87));
tcb->m_cWnd = (int) ((57.924+(28.024)+(22.201)+(69.453)+(segmentsAcked)+(27.57))/23.966);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (29.525*(17.119)*(tcb->m_cWnd)*(64.541)*(74.917)*(51.137)*(segmentsAcked)*(82.237)*(79.502));
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(23.323))/((0.1)+(0.1)));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(17.804)-(22.982)-(tcb->m_ssThresh));

}
