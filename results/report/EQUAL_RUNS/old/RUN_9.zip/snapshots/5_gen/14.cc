int YwmPczmphihKTOUF = (int) 34.795;
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (98.126+(45.037)+(-12.675)+(-14.255)+(-80.929)+(-8.005)+(-73.261));
YwmPczmphihKTOUF = (int) (43.608/78.109);
tcb->m_segmentSize = (int) (-6.149+(5.726)+(41.324)+(-20.397)+(71.365)+(-4.286)+(94.323));
