int IUbMgGgpmdbbGJPj = (int) (((-95.693)+(-86.627)+(28.299)+((-38.387+(52.945)+(27.582)+(-23.2)+(98.343)+(50.865)+(92.236)+(1.242)+(52.015)))+((37.07*(44.278)*(9.092)*(93.293)*(-42.37)*(-77.877)))+(9.888)+(-50.413))/((-65.037)+(-84.545)));
int mYGRtXUEbBNBoHes = (int) (5.775/-42.732);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (16.9-(92.352)-(segmentsAcked)-(67.413)-(7.218)-(tcb->m_cWnd)-(37.031));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (57.598-(-67.04)-(66.461)-(-42.493)-(-50.45));
