ReduceCwnd (tcb);
segmentsAcked = (int) (-55.993+(59.417)+(-16.192)+(-22.966)+(-66.342)+(79.382));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-68.884+(14.095)+(56.392)+(93.63)+(-40.703)+(-92.28)+(82.682));
tcb->m_segmentSize = (int) (39.612*(43.537)*(-44.759));
