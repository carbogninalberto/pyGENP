int YwmPczmphihKTOUF = (int) 20.25;
