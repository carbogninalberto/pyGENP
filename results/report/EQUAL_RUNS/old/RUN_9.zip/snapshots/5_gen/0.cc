ReduceCwnd (tcb);
segmentsAcked = (int) (5.738+(4.33)+(93.005)+(81.716)+(10.461)+(83.286));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (80.784+(-21.907)+(-75.543)+(-33.613)+(56.019)+(27.561)+(-50.018));
tcb->m_segmentSize = (int) (24.675*(-20.787)*(89.034));
