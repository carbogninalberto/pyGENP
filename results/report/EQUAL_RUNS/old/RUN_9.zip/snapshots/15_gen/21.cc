segmentsAcked = (int) (0.1/72.094);
float btikmidaGatlRDIQ = (float) (86.034*(6.274)*(2.959));
tcb->m_segmentSize = (int) (82.939*(16.665)*(tcb->m_ssThresh));
ReduceCwnd (tcb);
if (btikmidaGatlRDIQ == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (28.982-(34.397)-(53.542)-(84.149)-(73.823)-(segmentsAcked)-(tcb->m_ssThresh)-(tcb->m_cWnd));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (95.649-(56.954)-(25.768)-(51.708)-(32.014));

}
tcb->m_segmentSize = (int) (0.1/54.156);
if (btikmidaGatlRDIQ == tcb->m_cWnd) {
	segmentsAcked = (int) ((98.174-(btikmidaGatlRDIQ))/(68.413-(23.784)));

} else {
	segmentsAcked = (int) (13.908*(tcb->m_ssThresh));
	segmentsAcked = (int) (segmentsAcked+(46.749)+(14.586));

}
