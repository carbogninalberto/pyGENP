int iFTmaprIGnPiZhJR = (int) 82.389;
iFTmaprIGnPiZhJR = (int) ((33.675+(-45.522)+(-78.23)+(-95.336)+(74.752)+(tcb->m_segmentSize)+(17.985)+(-61.017)+(4.971))/39.958);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (30.851-(74.981)-(11.557)-(8.437));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (4.312-(68.919)-(65.573)-(85.321)-(1.457)-(87.576)-(83.995)-(tcb->m_cWnd)-(2.72));

}
segmentsAcked = (int) (((-46.049)+((-40.614+(tcb->m_cWnd)))+(79.099)+(-59.589)+(64.075))/((80.789)+(-22.31)+(-45.189)));
