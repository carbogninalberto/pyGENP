if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (95.239*(31.103)*(95.29)*(76.143)*(tcb->m_cWnd)*(23.678)*(45.448)*(75.704));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(93.324));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = (int) (17.379-(75.806)-(77.931)-(58.228));
tcb->m_cWnd = (int) (35.334/15.785);
tcb->m_segmentSize = (int) (73.757*(segmentsAcked)*(tcb->m_segmentSize)*(78.747)*(70.9)*(tcb->m_cWnd)*(33.505));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (5.508*(tcb->m_segmentSize)*(23.235));

} else {
	tcb->m_segmentSize = (int) (0.1/(35.232*(segmentsAcked)*(61.331)*(tcb->m_cWnd)*(58.098)*(53.529)*(73.781)*(52.499)));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (37.772+(tcb->m_segmentSize));

}
