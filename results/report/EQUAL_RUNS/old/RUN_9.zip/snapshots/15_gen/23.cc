ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(19.607));

} else {
	tcb->m_segmentSize = (int) (19.539*(tcb->m_cWnd)*(95.043)*(46.009));
	tcb->m_cWnd = (int) (82.681/44.807);
	CongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) ((tcb->m_ssThresh+(58.672)+(49.74)+(66.346)+(7.197)+(tcb->m_ssThresh)+(50.249)+(38.214)+(3.411))/0.1);
segmentsAcked = (int) (88.92*(60.339)*(48.5)*(15.845)*(93.173)*(5.154)*(50.624)*(tcb->m_segmentSize));
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (25.525+(39.576)+(59.093));
	segmentsAcked = (int) (85.099-(83.835)-(14.316)-(48.756)-(21.005)-(57.133)-(28.32)-(49.51));

} else {
	tcb->m_cWnd = (int) (3.317-(50.671)-(65.005)-(65.351)-(tcb->m_segmentSize)-(36.279)-(21.135)-(39.252));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (64.317/(36.308+(tcb->m_cWnd)+(16.7)+(6.382)+(67.565)+(87.28)+(44.732)));

}
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (72.116*(12.841));

} else {
	tcb->m_ssThresh = (int) (14.599/69.387);

}
