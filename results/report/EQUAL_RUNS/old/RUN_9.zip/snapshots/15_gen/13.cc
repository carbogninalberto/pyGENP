if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (80.208*(80.268)*(86.284)*(39.743)*(84.22)*(25.629));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (42.129+(16.417)+(38.779)+(73.731)+(54.708)+(49.818)+(52.346));
	tcb->m_segmentSize = (int) (66.979*(89.704));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
