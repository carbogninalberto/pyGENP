ReduceCwnd (tcb);
segmentsAcked = (int) (77.769+(-29.09)+(-87.111)+(-83.8)+(-41.488)+(-65.367));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-13.894+(87.754)+(30.474)+(97.517)+(-97.194)+(-4.448)+(11.043));
segmentsAcked = (int) (57.402+(64.309)+(-93.589)+(-87.551)+(95.402)+(-22.611)+(-49.452));
tcb->m_segmentSize = (int) (-85.274*(90.897)*(45.633));
tcb->m_segmentSize = (int) (44.471*(99.272)*(70.415));
