ReduceCwnd (tcb);
segmentsAcked = (int) (19.213+(55.325)+(82.332)+(90.139)+(1.41)+(-49.229));
segmentsAcked = (int) (75.887+(-87.303)+(11.197)+(78.573)+(92.1)+(-90.138)+(49.759));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-57.786*(-53.298)*(66.187));
segmentsAcked = (int) (14.458+(-31.801)+(75.646)+(-79.719)+(77.06)+(40.179)+(45.968));
tcb->m_segmentSize = (int) (30.036*(13.803)*(-95.731));
