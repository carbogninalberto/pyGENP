float ibWxRcZfmJNziFcc = (float) (60.943*(77.716)*(91.979)*(63.054)*(53.208)*(tcb->m_segmentSize)*(61.667)*(tcb->m_ssThresh)*(63.638));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == ibWxRcZfmJNziFcc) {
	tcb->m_ssThresh = (int) (64.354-(ibWxRcZfmJNziFcc));
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(47.596))/((8.43)+(0.1)+(96.222)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (0.943*(tcb->m_segmentSize));
	segmentsAcked = (int) ((((61.817-(72.691)-(92.298)-(9.776)-(tcb->m_segmentSize)-(61.442)-(33.606)-(99.242)-(81.002)))+(0.1)+(0.1)+(88.207)+(56.592))/((0.1)+(49.805)));
	tcb->m_ssThresh = (int) ((ibWxRcZfmJNziFcc-(29.869)-(51.415)-(28.919)-(3.665)-(tcb->m_ssThresh)-(86.099)-(ibWxRcZfmJNziFcc))/43.652);

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (ibWxRcZfmJNziFcc-(tcb->m_ssThresh)-(segmentsAcked)-(18.495)-(86.079)-(55.223)-(30.779));
	tcb->m_cWnd = (int) (17.164+(tcb->m_segmentSize)+(83.014)+(23.198)+(0.18)+(1.273)+(3.785)+(27.478)+(1.469));

} else {
	tcb->m_cWnd = (int) (84.999-(segmentsAcked)-(33.206)-(40.609)-(24.765)-(tcb->m_segmentSize)-(7.912));
	tcb->m_segmentSize = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(tcb->m_ssThresh)+(94.281));
if (ibWxRcZfmJNziFcc <= tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_ssThresh-(34.18)-(84.703)-(50.959)-(18.491));

} else {
	segmentsAcked = (int) (48.303-(10.345)-(tcb->m_segmentSize));
	ibWxRcZfmJNziFcc = (float) (90.629+(92.132));
	ibWxRcZfmJNziFcc = (float) (61.112-(96.437)-(ibWxRcZfmJNziFcc)-(71.791)-(82.149)-(95.241));

}
ibWxRcZfmJNziFcc = (float) (70.59/95.675);
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	ibWxRcZfmJNziFcc = (float) (14.192-(19.577)-(43.414)-(95.97)-(21.14)-(55.105)-(6.65)-(tcb->m_ssThresh)-(42.533));

} else {
	ibWxRcZfmJNziFcc = (float) (24.076*(36.293));
	ibWxRcZfmJNziFcc = (float) (30.63+(59.089));

}
if (tcb->m_segmentSize > ibWxRcZfmJNziFcc) {
	tcb->m_segmentSize = (int) (0.404*(29.374)*(59.753)*(71.818)*(tcb->m_cWnd)*(18.743)*(25.469)*(68.85));

} else {
	tcb->m_segmentSize = (int) (0.1/22.243);
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
