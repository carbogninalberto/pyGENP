tcb->m_ssThresh = (int) (((0.1)+(60.027)+(62.875)+(98.77)+((18.772-(68.29)-(8.155)-(84.133)-(23.652)))+(0.1))/((0.1)));
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_ssThresh = (int) (0.1/37.548);
	tcb->m_segmentSize = (int) (74.742-(tcb->m_ssThresh)-(tcb->m_segmentSize));
	segmentsAcked = (int) (((78.009)+(0.1)+(64.869)+(67.78))/((0.1)+(0.1)+(87.019)));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(33.157)+(66.238)+(99.366)+(43.908)+(69.972)+(85.08)+(4.695));

}
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_cWnd = (int) (14.39+(12.575)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(99.886));

} else {
	tcb->m_cWnd = (int) (0.671*(55.478)*(6.666)*(tcb->m_segmentSize)*(segmentsAcked)*(26.577)*(73.472));
	tcb->m_segmentSize = (int) (95.661+(11.1));

}
tcb->m_ssThresh = (int) (80.918/0.1);
tcb->m_cWnd = (int) (79.301+(94.202)+(72.509)+(tcb->m_cWnd)+(39.621)+(63.131));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/77.399);
	segmentsAcked = (int) (40.457+(tcb->m_cWnd)+(27.788)+(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) ((((26.462*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(16.804)*(14.704)*(tcb->m_cWnd)*(34.763)*(60.451)))+(85.259)+((90.037*(38.732)))+(0.1)+(84.858))/((18.312)+(18.729)+(0.1)+(0.1)));

}
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/66.566);
	tcb->m_segmentSize = (int) (55.584-(73.602)-(19.808)-(43.072)-(23.12)-(99.106)-(48.765)-(76.79));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(60.151)+(0.1)+(0.1)+(68.095)+(0.1))/((98.252)));
	tcb->m_cWnd = (int) (64.643-(80.866)-(94.098)-(48.553)-(67.56)-(32.265)-(49.397));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (tcb->m_cWnd-(68.755)-(segmentsAcked));
segmentsAcked = SlowStart (tcb, segmentsAcked);
