ReduceCwnd (tcb);
segmentsAcked = (int) (50.986+(segmentsAcked));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (60.761*(15.286)*(72.855)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(1.729)*(13.546));
int LropxGBZURRCODRR = (int) (52.286-(77.938)-(32.0)-(30.097)-(75.175)-(tcb->m_ssThresh));
ReduceCwnd (tcb);
