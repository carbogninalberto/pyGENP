if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_segmentSize = (int) (52.803*(59.645));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (88.085*(4.425)*(22.755)*(32.019)*(segmentsAcked)*(27.161)*(tcb->m_ssThresh)*(tcb->m_cWnd));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (92.799/(39.652+(tcb->m_segmentSize)+(tcb->m_cWnd)+(66.369)));
tcb->m_cWnd = (int) (56.667+(7.428)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(60.1)+(54.988)+(39.651)+(46.25));
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_cWnd*(20.318)*(43.591)*(90.747)*(79.295)*(segmentsAcked));
