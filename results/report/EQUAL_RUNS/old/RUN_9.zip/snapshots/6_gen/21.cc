tcb->m_segmentSize = (int) (39.286+(53.984)+(0.562)+(67.508)+(96.756)+(68.153));
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((66.529)+(0.1)+((28.123+(tcb->m_ssThresh)+(11.855)+(32.154)+(99.223)+(50.364)+(45.215)+(91.326)))+(86.668))/((23.899)+(61.703)+(58.464)+(0.1)));

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(27.211)+(59.288)));

}
segmentsAcked = (int) (70.325/96.624);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (((0.1)+(57.211)+(0.1)+(51.779))/((26.893)));
ReduceCwnd (tcb);
if (tcb->m_ssThresh != segmentsAcked) {
	segmentsAcked = (int) (60.229-(35.401));

} else {
	segmentsAcked = (int) (50.489*(segmentsAcked)*(52.788));
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
