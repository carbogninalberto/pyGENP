ReduceCwnd (tcb);
int eNgRJUIKiIFIGnCg = (int) (22.68+(37.75)+(96.631)+(tcb->m_ssThresh)+(31.721)+(96.659));
tcb->m_cWnd = (int) (66.81-(6.759)-(47.392)-(tcb->m_segmentSize)-(70.636)-(3.849)-(58.698));
int RfIMQMpPSXXKzZSB = (int) (50.688-(segmentsAcked)-(66.355)-(31.75));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
