ReduceCwnd (tcb);
segmentsAcked = (int) (59.322+(98.306)+(49.267)+(-29.102)+(97.756)+(-18.432));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (53.932+(-2.947)+(18.571)+(0.898)+(16.086)+(25.146)+(-18.229));
tcb->m_segmentSize = (int) (-52.659*(25.413)*(-62.082));
