ReduceCwnd (tcb);
float bZUDBaKTSQGCNLEz = (float) (0.162+(-59.731)+(-10.956)+(-54.758)+(10.476)+(-60.848)+(-99.036)+(80.982)+(39.338));
segmentsAcked = (int) (-71.092-(-28.009)-(5.424)-(13.549)-(28.545)-(76.525)-(-97.209)-(-58.943));
float avUHJQvAPBItZznK = (float) 61.145;
