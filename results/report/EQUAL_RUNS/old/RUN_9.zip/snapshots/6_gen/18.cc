segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (60.755/0.1);
	tcb->m_ssThresh = (int) (91.028+(segmentsAcked)+(40.53)+(16.345)+(48.17)+(51.571)+(2.531)+(86.059));

} else {
	tcb->m_segmentSize = (int) (8.601+(69.835)+(54.924));
	tcb->m_segmentSize = (int) (segmentsAcked-(53.177)-(61.038)-(58.017)-(59.314)-(segmentsAcked)-(71.214)-(tcb->m_segmentSize)-(76.982));

}
tcb->m_cWnd = (int) (((0.1)+(1.948)+(50.377)+(0.1))/((0.1)));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (99.562-(27.576)-(segmentsAcked));
