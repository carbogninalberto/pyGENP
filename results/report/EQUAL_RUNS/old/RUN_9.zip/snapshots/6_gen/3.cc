ReduceCwnd (tcb);
segmentsAcked = (int) (-21.596+(-67.254)+(71.537)+(-83.79)+(-10.168)+(-79.663));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (72.539+(91.058)+(60.104)+(10.027)+(62.303)+(72.058)+(28.112));
tcb->m_segmentSize = (int) (-78.448*(14.545)*(-39.86));
