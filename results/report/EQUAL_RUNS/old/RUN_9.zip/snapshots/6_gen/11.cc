ReduceCwnd (tcb);
segmentsAcked = (int) (82.347+(-3.655)+(51.857)+(89.24)+(-62.148)+(97.558));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (14.867+(-14.661)+(5.453)+(-20.189)+(51.101)+(44.901)+(54.011));
segmentsAcked = (int) (-49.986+(55.767)+(79.923)+(-31.583)+(59.544)+(-99.988)+(-31.31));
tcb->m_segmentSize = (int) (-81.361*(39.079)*(-98.814));
tcb->m_segmentSize = (int) (75.127*(8.48)*(7.985));
