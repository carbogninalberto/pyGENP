float nhmpKRVQLIsuECwo = (float) 17.507;
tcb->m_segmentSize = (int) (-42.132+(80.066)+(-22.337));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (30.868/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (87.09-(28.5)-(49.656)-(49.916)-(53.118)-(74.108)-(-89.103)-(15.151)-(5.213));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(8.543));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (69.389*(-41.473)*(35.755)*(23.688)*(-90.036)*(3.459)*(70.322));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_segmentSize) {
	nhmpKRVQLIsuECwo = (float) (51.665-(26.057)-(57.885)-(17.416)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(42.405)-(50.28)-(86.614)-(81.176)-(81.298)-(23.414)-(30.391));

} else {
	nhmpKRVQLIsuECwo = (float) (tcb->m_segmentSize-(14.363)-(4.153)-(40.81)-(44.296)-(segmentsAcked)-(78.284));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-77.439*(-92.342)*(-88.545)*(-19.692)*(75.824)*(-66.118)*(-45.067));
nhmpKRVQLIsuECwo = (float) (-73.234*(-87.066));
if (segmentsAcked > tcb->m_segmentSize) {
	nhmpKRVQLIsuECwo = (float) (51.665-(26.057)-(57.885)-(17.416)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(42.405)-(50.28)-(86.614)-(81.176)-(81.298)-(23.414)-(30.391));

} else {
	nhmpKRVQLIsuECwo = (float) (tcb->m_segmentSize-(14.363)-(4.153)-(40.81)-(44.296)-(segmentsAcked)-(78.284));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
nhmpKRVQLIsuECwo = (float) (-3.54*(75.547));
tcb->m_cWnd = (int) (12.44*(50.884)*(-95.549)*(0.948)*(-66.233)*(56.772)*(6.308));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_segmentSize) {
	nhmpKRVQLIsuECwo = (float) (51.665-(26.057)-(57.885)-(17.416)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(42.405)-(50.28)-(86.614)-(81.176)-(81.298)-(23.414)-(30.391));

} else {
	nhmpKRVQLIsuECwo = (float) (tcb->m_segmentSize-(14.363)-(4.153)-(40.81)-(44.296)-(segmentsAcked)-(78.284));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-67.418*(30.087)*(-3.914)*(90.064)*(88.305)*(-73.031)*(-65.088));
nhmpKRVQLIsuECwo = (float) (43.58*(-5.344));
if (segmentsAcked > tcb->m_segmentSize) {
	nhmpKRVQLIsuECwo = (float) (51.665-(26.057)-(57.885)-(17.416)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(42.405)-(50.28)-(86.614)-(81.176)-(81.298)-(23.414)-(30.391));

} else {
	nhmpKRVQLIsuECwo = (float) (tcb->m_segmentSize-(14.363)-(4.153)-(40.81)-(44.296)-(segmentsAcked)-(78.284));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
nhmpKRVQLIsuECwo = (float) (97.561*(96.783));
