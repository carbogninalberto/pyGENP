ReduceCwnd (tcb);
segmentsAcked = (int) (-96.295+(-71.922)+(2.503)+(-64.188)+(83.013)+(-18.382));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (19.694+(-59.673)+(62.517)+(83.4)+(-49.167)+(-91.975)+(82.577));
tcb->m_segmentSize = (int) (83.329*(50.106)*(-91.023));
