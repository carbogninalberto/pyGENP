tcb->m_cWnd = (int) (77.352*(60.809)*(72.576));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (28.896-(98.079)-(83.704));
segmentsAcked = SlowStart (tcb, segmentsAcked);
