ReduceCwnd (tcb);
segmentsAcked = (int) (24.602+(71.003)+(-43.871)+(-97.569)+(-28.304)+(-15.74)+(-57.934));
segmentsAcked = (int) (49.401+(6.838)+(99.828)+(69.577)+(7.67)+(-53.909));
tcb->m_segmentSize = (int) (86.862*(67.904)*(74.788));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-30.488+(10.369)+(62.454)+(-37.395)+(15.206)+(-6.429)+(-89.821));
tcb->m_segmentSize = (int) (-85.048*(48.784)*(-97.024));
