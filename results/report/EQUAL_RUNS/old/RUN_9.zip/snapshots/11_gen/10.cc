ReduceCwnd (tcb);
segmentsAcked = (int) (-83.65+(32.664)+(3.629)+(48.417)+(77.86)+(96.8));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (2.074*(-79.45)*(-89.055));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-50.595+(97.787)+(-37.362)+(64.463)+(-11.173)+(-90.06)+(-38.442));
segmentsAcked = (int) (-13.021+(-22.357)+(2.292)+(-21.426)+(-21.953)+(-14.258)+(49.268));
tcb->m_segmentSize = (int) (40.011*(91.902)*(-21.664));
tcb->m_segmentSize = (int) (87.267*(-40.967)*(-22.295));
