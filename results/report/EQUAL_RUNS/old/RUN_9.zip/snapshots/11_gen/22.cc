CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (89.578+(14.294)+(62.297)+(58.973)+(45.29)+(tcb->m_cWnd)+(51.173));
	tcb->m_segmentSize = (int) (15.423+(85.988)+(tcb->m_ssThresh)+(1.379)+(2.696)+(45.144));

} else {
	tcb->m_cWnd = (int) (97.97/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (46.212-(8.632));
tcb->m_segmentSize = (int) (57.852+(8.767)+(33.448));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (9.143+(61.191)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(35.209)+(18.452)+(tcb->m_ssThresh)+(tcb->m_cWnd));
ReduceCwnd (tcb);
