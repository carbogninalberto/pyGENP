ReduceCwnd (tcb);
segmentsAcked = (int) (-32.254+(-89.963)+(66.109)+(56.295)+(-86.696)+(22.733));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-57.704+(-78.951)+(93.045)+(-84.517)+(-57.534)+(-81.254)+(-42.463));
segmentsAcked = (int) (-2.846+(-41.709)+(99.369)+(-63.06)+(-14.947)+(-39.964)+(-12.439));
tcb->m_segmentSize = (int) (76.828*(47.157)*(17.733));
tcb->m_segmentSize = (int) (-4.889*(-89.265)*(-89.902));
