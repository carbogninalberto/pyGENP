ReduceCwnd (tcb);
segmentsAcked = (int) (-17.464+(24.759)+(6.17)+(73.211)+(-60.872)+(62.387));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-79.742+(-94.587)+(-20.447)+(81.872)+(38.758)+(-97.583)+(-35.604));
tcb->m_segmentSize = (int) (49.327*(96.307)*(68.832));
