segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-10.858*(47.649)*(86.145)*(-52.141));
ReduceCwnd (tcb);
