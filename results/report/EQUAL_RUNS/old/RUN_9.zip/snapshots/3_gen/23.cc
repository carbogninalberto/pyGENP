segmentsAcked = (int) (91.01*(9.285)*(70.975));
