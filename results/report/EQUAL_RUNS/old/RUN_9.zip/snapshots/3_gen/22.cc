ReduceCwnd (tcb);
int ZHtTyKHsjJSlSfnw = (int) 95.628;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ZHtTyKHsjJSlSfnw = (int) ((-88.749+(36.22)+(-54.364)+(-48.53)+(51.282)+(-80.413)+(segmentsAcked)+(94.541)+(-34.052))/-93.152);
ZHtTyKHsjJSlSfnw = (int) ((-85.063+(27.414)+(-48.5)+(-23.834)+(7.029)+(48.942)+(segmentsAcked)+(39.709)+(0.719))/-90.659);
