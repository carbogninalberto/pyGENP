tcb->m_cWnd = (int) (-90.616-(-11.897)-(57.845)-(-54.074)-(-57.253)-(21.517));
int ZHtTyKHsjJSlSfnw = (int) 34.034;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ZHtTyKHsjJSlSfnw = (int) ((55.392+(81.877)+(-71.928)+(-70.204)+(44.009)+(-22.042)+(segmentsAcked)+(70.123)+(-81.271))/-81.907);
