ReduceCwnd (tcb);
segmentsAcked = (int) (-59.403+(-39.009)+(7.736)+(73.828)+(22.556)+(-35.015));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (78.393+(-0.975)+(-21.822)+(53.583)+(-52.349)+(-49.093)+(-1.876));
tcb->m_segmentSize = (int) (50.946*(56.928)*(78.609));
