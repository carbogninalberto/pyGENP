ReduceCwnd (tcb);
segmentsAcked = (int) (-65.61+(87.716)+(20.815)+(12.974)+(27.581)+(-73.264));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (30.714+(56.895)+(-51.299)+(10.389)+(-86.176)+(10.89)+(-51.06));
segmentsAcked = (int) (73.505+(-50.165)+(75.324)+(-75.994)+(29.281)+(-64.323));
tcb->m_segmentSize = (int) (37.389*(-20.718)*(-4.975));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-64.302+(51.805)+(-75.209)+(-85.82)+(48.321)+(-88.385)+(16.328));
tcb->m_segmentSize = (int) (26.988*(-95.724)*(74.451));
