ReduceCwnd (tcb);
segmentsAcked = (int) (-68.257+(-17.45)+(-0.133)+(44.409)+(86.811)+(-69.425));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-39.463+(-51.831)+(-50.282)+(-41.197)+(82.389)+(68.968)+(-81.061));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-17.562*(-98.906)*(-37.877));
segmentsAcked = (int) (54.621+(56.67)+(-15.697)+(-0.107)+(6.941)+(5.617)+(53.131));
tcb->m_segmentSize = (int) (-82.775*(-87.328)*(-17.674));
