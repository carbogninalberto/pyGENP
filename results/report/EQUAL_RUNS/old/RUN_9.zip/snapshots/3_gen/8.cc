int YwmPczmphihKTOUF = (int) 77.706;
YwmPczmphihKTOUF = (int) (-40.886/-8.543);
tcb->m_segmentSize = (int) (-65.58+(62.055)+(-12.118)+(-24.63)+(68.982)+(50.662)+(29.106));
