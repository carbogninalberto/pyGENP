int YwmPczmphihKTOUF = (int) 33.171;
YwmPczmphihKTOUF = (int) (-64.696/52.287);
tcb->m_segmentSize = (int) (-98.175+(58.549)+(82.511)+(73.609)+(-79.546)+(-24.949)+(-5.401));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-21.615+(1.372)+(-6.983)+(-81.883)+(-27.403)+(-68.024)+(93.939));
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (14.565+(66.765)+(-14.565)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (14.565+(66.765)+(76.634)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (14.565+(66.765)+(-14.565)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (((42.309)+(0.1)+(79.243)+(46.69)+(1.078))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (14.565+(66.765)+(76.634)+(23.191)+(tcb->m_cWnd)+(34.657)+(79.346));
	ReduceCwnd (tcb);

}
