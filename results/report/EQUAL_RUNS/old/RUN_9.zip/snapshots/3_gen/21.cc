CongestionAvoidance (tcb, segmentsAcked);
int ZHtTyKHsjJSlSfnw = (int) 37.259;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ZHtTyKHsjJSlSfnw = (int) ((-68.877+(88.745)+(-91.61)+(83.632)+(-64.684)+(-4.024)+(segmentsAcked)+(-97.353)+(-7.905))/-7.586);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ZHtTyKHsjJSlSfnw = (int) ((-74.223+(5.782)+(62.541)+(0.33)+(-65.087)+(58.427)+(segmentsAcked)+(49.504)+(-79.705))/89.951);
