float cLGEtrRGIqqytYNo = (float) (59.884+(26.537)+(-69.24));
segmentsAcked = (int) (25.107+(-37.171)+(94.061));
ReduceCwnd (tcb);
