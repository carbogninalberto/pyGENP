ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-32.324+(88.352)+(-27.238)+(-56.014)+(61.415)+(-50.622)+(72.136)+(-5.195));
