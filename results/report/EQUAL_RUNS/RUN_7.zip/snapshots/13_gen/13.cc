CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-61.708-(51.572)-(-44.186));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-11.076-(-39.685)-(-98.843));
tcb->m_segmentSize = (int) (-57.59-(-9.39)-(91.389));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-46.167-(87.619)-(24.981));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(25.967)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(-40.911)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

}
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

} else {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(25.967)-(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (-77.387-(-5.483)-(-8.648)-(-54.989)-(-79.384)-(-54.754)-(-16.142));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(-40.911)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

}
tcb->m_cWnd = (int) (96.76-(64.441)-(-3.643)-(-88.185)-(36.516)-(53.335)-(-85.99));
tcb->m_cWnd = (int) (-30.351-(-98.113)-(-23.637)-(76.107)-(90.419)-(-84.75)-(98.703));
tcb->m_segmentSize = (int) (98.781+(99.358)+(10.81)+(-62.63)+(10.912)+(70.587)+(-6.652)+(71.465));
tcb->m_cWnd = (int) (-6.904-(33.065)-(7.336)-(-65.656)-(7.917)-(55.017)-(-24.017));
tcb->m_segmentSize = (int) (54.592+(-70.62)+(-40.494)+(-45.729)+(-34.347)+(94.897)+(90.068)+(-47.975));
tcb->m_segmentSize = (int) (67.127+(-37.405)+(50.741)+(98.411)+(-32.074)+(-21.574)+(94.699)+(-67.92));
