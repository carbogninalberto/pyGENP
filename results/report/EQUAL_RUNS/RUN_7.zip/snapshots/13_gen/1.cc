TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (81.896+(1.75));
segmentsAcked = (int) (33.537+(37.368));
segmentsAcked = (int) (-43.732+(7.462));
segmentsAcked = (int) (59.701+(-40.914));
