TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (80.84+(3.839));
segmentsAcked = (int) (-30.381+(-42.397));
segmentsAcked = (int) (30.418+(4.657));
segmentsAcked = (int) (-45.555+(-64.777));
segmentsAcked = (int) (-5.281+(0.334));
