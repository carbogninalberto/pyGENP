segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (tcb->m_ssThresh*(65.586)*(30.409)*(60.354)*(3.338)*(53.873));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(51.942));

} else {
	tcb->m_segmentSize = (int) (0.1/31.932);
	segmentsAcked = (int) (36.994-(38.965));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
