segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (0.1/95.295);
tcb->m_segmentSize = (int) (36.813+(16.384));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	segmentsAcked = (int) (82.285+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (0.1/29.343);

} else {
	segmentsAcked = (int) (31.043+(59.132)+(60.795)+(tcb->m_ssThresh)+(15.051)+(84.349));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
