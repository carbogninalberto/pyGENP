segmentsAcked = (int) (83.671/30.652);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-50.136-(-78.226)-(87.474));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

} else {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(25.967)-(tcb->m_cWnd));

}
tcb->m_segmentSize = (int) (50.256-(18.822)-(-70.382));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(-40.911)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (30.389-(-57.566)-(39.514)-(-33.649)-(1.368)-(86.282)-(68.865));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (84.92-(49.724)-(53.586)-(62.901)-(77.167)-(77.86)-(-32.695));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(25.967)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

}
tcb->m_segmentSize = (int) (-8.455+(-8.95)+(6.284)+(96.402)+(-33.13)+(9.63)+(-86.727)+(-10.067));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(-40.911)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

}
tcb->m_segmentSize = (int) (-67.162+(44.052)+(-6.665)+(-40.219)+(-3.175)+(-45.434)+(48.601)+(31.759));
tcb->m_cWnd = (int) (58.522-(-70.986)-(-16.89)-(-35.636)-(46.302)-(-76.723)-(88.584));
tcb->m_cWnd = (int) (53.237-(56.545)-(-15.361)-(-7.967)-(-10.188)-(14.017)-(55.907));
tcb->m_segmentSize = (int) (-6.313+(75.378)+(65.571)+(79.097)+(49.581)+(81.929)+(-77.485)+(-44.349));
tcb->m_segmentSize = (int) (7.209+(-35.322)+(-10.376)+(31.834)+(-61.076)+(80.556)+(33.908)+(-18.685));
