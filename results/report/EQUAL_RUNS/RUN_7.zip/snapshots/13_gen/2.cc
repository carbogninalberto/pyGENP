TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-27.08+(-59.788));
segmentsAcked = (int) (40.037+(-0.842));
segmentsAcked = (int) (-97.085+(1.253));
segmentsAcked = (int) (23.6+(-4.487));
segmentsAcked = (int) (-8.261+(-73.289));
