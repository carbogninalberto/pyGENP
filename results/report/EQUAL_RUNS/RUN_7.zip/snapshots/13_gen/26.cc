segmentsAcked = (int) (0.276+(tcb->m_cWnd)+(32.972)+(72.79));
int GJmPUnahMHtCtBbh = (int) (49.965*(tcb->m_cWnd)*(71.469)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(97.303)*(78.744)*(45.925)*(tcb->m_cWnd));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (44.461+(88.322)+(segmentsAcked)+(56.023)+(70.474)+(60.268)+(0.319));
tcb->m_segmentSize = (int) (96.709-(46.762)-(66.804));
float uIdbKjbLyLlDOikB = (float) (97.407*(30.74));
GJmPUnahMHtCtBbh = (int) (GJmPUnahMHtCtBbh*(segmentsAcked)*(97.868)*(36.634)*(79.543)*(61.738)*(83.558));
segmentsAcked = (int) (37.662+(15.123)+(44.804)+(44.585)+(73.217)+(69.982)+(95.309)+(97.272)+(1.642));
