segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-37.2-(-18.752)-(-29.2)-(-15.568)-(-75.781));
segmentsAcked = (int) (-79.213/6.045);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (85.281/43.01);
segmentsAcked = (int) (41.15-(-97.487)-(-49.936)-(34.549)-(40.023));
segmentsAcked = (int) (92.45/79.267);
