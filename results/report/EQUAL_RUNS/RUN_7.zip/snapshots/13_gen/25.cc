if (segmentsAcked == segmentsAcked) {
	segmentsAcked = (int) (4.498-(42.957));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (70.705*(50.209)*(tcb->m_segmentSize)*(48.223)*(29.335)*(8.408)*(27.152)*(65.488));
	tcb->m_cWnd = (int) (19.339-(segmentsAcked)-(91.222)-(46.632)-(10.814)-(25.146)-(7.285));
	tcb->m_segmentSize = (int) (41.203*(60.788)*(50.761)*(84.76)*(47.577));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (37.644*(tcb->m_segmentSize)*(tcb->m_cWnd)*(62.391));
tcb->m_ssThresh = (int) (69.602*(85.393)*(64.648)*(22.938)*(21.931));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (45.114*(99.127)*(71.465)*(43.372)*(23.158)*(segmentsAcked)*(12.672));
