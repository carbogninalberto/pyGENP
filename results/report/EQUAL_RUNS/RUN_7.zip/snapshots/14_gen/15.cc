tcb->m_segmentSize = (int) (15.769-(88.188)-(-98.116));
