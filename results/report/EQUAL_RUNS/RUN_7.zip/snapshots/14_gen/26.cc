tcb->m_segmentSize = (int) ((27.223*(41.234)*(5.546)*(44.334)*(50.03)*(40.415))/47.195);
segmentsAcked = (int) (tcb->m_segmentSize+(73.627)+(62.499)+(53.403)+(61.816)+(37.886)+(13.641)+(67.672)+(55.257));
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_cWnd = (int) (34.451*(70.086)*(18.42)*(88.812)*(23.461)*(50.007));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (46.959*(tcb->m_cWnd)*(16.089)*(tcb->m_ssThresh)*(78.516)*(69.075)*(tcb->m_segmentSize)*(98.587)*(32.553));

} else {
	tcb->m_cWnd = (int) (47.155-(85.535)-(81.225)-(49.758)-(47.433)-(38.777));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (0.1/90.782);
float urFPjvfNIrtwuOyy = (float) (97.086+(tcb->m_cWnd)+(76.176)+(82.637));
