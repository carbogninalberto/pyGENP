ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (26.538+(-16.652)+(-26.624)+(11.313)+(-52.382)+(-15.871)+(70.34)+(-7.481));
tcb->m_segmentSize = (int) (18.697+(-57.612)+(-99.649)+(88.232)+(27.574)+(73.004)+(14.634)+(-42.389));
