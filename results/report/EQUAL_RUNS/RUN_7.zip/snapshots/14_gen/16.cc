TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-27.696+(-41.424));
segmentsAcked = (int) (-5.098+(40.72));
segmentsAcked = (int) (68.394+(-46.431));
segmentsAcked = (int) (-40.507+(33.632));
segmentsAcked = (int) (82.779+(-40.61));
segmentsAcked = (int) (-2.261+(-92.817));
segmentsAcked = (int) (-81.026+(-11.776));
