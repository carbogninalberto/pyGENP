TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (53.811+(-59.633));
segmentsAcked = (int) (35.274+(60.546));
segmentsAcked = (int) (53.479+(-85.389));
segmentsAcked = (int) (16.838+(-46.967));
segmentsAcked = (int) (41.529+(-54.495));
segmentsAcked = (int) (-98.858+(-59.522));
