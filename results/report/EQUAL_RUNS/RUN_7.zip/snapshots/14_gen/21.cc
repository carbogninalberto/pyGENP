ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(tcb->m_ssThresh)-(30.259)-(tcb->m_cWnd));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (54.881*(segmentsAcked)*(66.805));

}
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	segmentsAcked = (int) (66.871+(99.266)+(61.611));
	tcb->m_ssThresh = (int) (74.414-(34.422)-(tcb->m_ssThresh)-(84.803)-(78.714)-(94.335)-(46.259)-(74.598)-(21.525));

} else {
	segmentsAcked = (int) (tcb->m_cWnd-(37.123));

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (46.768+(14.978)+(47.499));
tcb->m_segmentSize = (int) (36.359-(66.143)-(tcb->m_ssThresh)-(76.265)-(segmentsAcked)-(46.036)-(18.306)-(89.998)-(6.4));
segmentsAcked = (int) (41.942-(82.6)-(25.609)-(71.569)-(51.907));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
