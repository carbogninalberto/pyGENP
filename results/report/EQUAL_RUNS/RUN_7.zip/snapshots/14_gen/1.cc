segmentsAcked = (int) (37.319-(-56.141)-(44.968)-(21.249)-(13.88));
segmentsAcked = (int) (53.783/-49.333);
