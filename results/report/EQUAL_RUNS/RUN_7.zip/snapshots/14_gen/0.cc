TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (35.396+(-94.609));
segmentsAcked = (int) (84.078+(-67.5));
segmentsAcked = (int) (96.943+(28.808));
segmentsAcked = (int) (-51.527+(-76.794));
segmentsAcked = (int) (86.321+(-80.484));
