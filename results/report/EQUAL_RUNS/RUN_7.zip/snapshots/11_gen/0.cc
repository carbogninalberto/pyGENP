ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (24.382+(41.408)+(-79.023)+(-82.662)+(-39.093)+(29.511)+(21.705)+(-55.534));
