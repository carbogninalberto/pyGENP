ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-55.961+(91.234)+(-25.793)+(82.366)+(31.846)+(4.457)+(-18.531)+(-80.086));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-74.993+(-55.499)+(93.415)+(15.741)+(-41.616)+(90.498)+(67.431)+(-7.27));
