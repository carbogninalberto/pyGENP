int QbJhVMcjtweIZJVA = (int) (62.418+(54.177)+(83.194));
