TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (49.528+(-50.499));
segmentsAcked = (int) (-56.265+(-87.761));
segmentsAcked = (int) (29.965+(-28.516));
segmentsAcked = (int) (-6.194+(97.768));
segmentsAcked = (int) (-91.484+(-49.2));
