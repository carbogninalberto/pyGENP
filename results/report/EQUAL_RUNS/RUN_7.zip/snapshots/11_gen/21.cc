float fXBeMszcSESaCDwr = (float) 62.112;
fXBeMszcSESaCDwr = (float) ((0.897+(-4.912)+(53.39)+(68.375)+(18.031)+(-30.696))/-81.841);
fXBeMszcSESaCDwr = (float) ((13.777+(93.168)+(-20.466)+(-8.603)+(-48.258)+(-18.948))/-18.889);
if (fXBeMszcSESaCDwr < tcb->m_segmentSize) {
	segmentsAcked = (int) (76.946*(33.206)*(68.437)*(26.792)*(86.116)*(43.319));
	fXBeMszcSESaCDwr = (float) (24.595-(78.878)-(25.117)-(33.847)-(48.231)-(62.83)-(16.868));

} else {
	segmentsAcked = (int) (91.837*(13.173)*(23.179)*(56.42)*(segmentsAcked)*(30.814));
	tcb->m_segmentSize = (int) (fXBeMszcSESaCDwr+(10.163)+(40.421));

}
if (fXBeMszcSESaCDwr < tcb->m_segmentSize) {
	segmentsAcked = (int) (76.946*(33.206)*(68.437)*(26.792)*(86.116)*(43.319));
	fXBeMszcSESaCDwr = (float) (24.595-(78.878)-(25.117)-(33.847)-(48.231)-(62.83)-(16.868));

} else {
	segmentsAcked = (int) (91.837*(13.173)*(23.179)*(56.42)*(segmentsAcked)*(30.814));
	tcb->m_segmentSize = (int) (fXBeMszcSESaCDwr+(10.163)+(40.421));

}
