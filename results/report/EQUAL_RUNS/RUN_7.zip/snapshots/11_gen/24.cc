tcb->m_cWnd = (int) (33.73/(tcb->m_ssThresh+(76.103)+(-23.666)+(57.786)+(90.675)+(tcb->m_ssThresh)));
tcb->m_segmentSize = (int) (-99.851-(63.391)-(-69.779));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(-79.049)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

}
tcb->m_cWnd = (int) (-52.802-(-80.487)-(73.867)-(-70.296)-(55.138)-(-28.151)-(8.219));
tcb->m_segmentSize = (int) (32.658+(99.793)+(-33.24)+(63.673)+(-46.324)+(-0.126)+(-15.667)+(35.333));
