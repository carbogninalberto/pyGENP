TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-86.525/-37.541);
segmentsAcked = (int) (70.353-(-68.053)-(-90.456)-(-81.023)-(-68.342));
