ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-8.605-(-84.576)-(78.568));
tcb->m_segmentSize = (int) (98.109-(-65.088)-(-6.674));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(-44.14)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

}
tcb->m_cWnd = (int) (-90.8-(-37.542)-(-11.294)-(29.635)-(64.032)-(-76.481)-(-65.944));
tcb->m_segmentSize = (int) (85.236+(59.522)+(-91.501)+(-82.273)+(-25.084)+(-52.309)+(-2.724)+(23.26));
