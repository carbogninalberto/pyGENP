ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (58.368+(-11.49)+(58.417)+(-15.773)+(98.142)+(2.903)+(-67.331)+(-33.654));
tcb->m_segmentSize = (int) (47.677+(86.2)+(99.064)+(-55.148)+(17.119)+(-41.28)+(-5.758)+(6.132));
