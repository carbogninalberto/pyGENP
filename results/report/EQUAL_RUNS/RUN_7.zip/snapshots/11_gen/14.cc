int ejRCjTPeHEWSQZFl = (int) 52.576;
int gXdlWqrvaOxfPbHM = (int) (91.091-(-86.764)-(13.306)-(-26.898)-(66.211)-(-64.204)-(-15.393)-(-29.275)-(-52.884));
tcb->m_segmentSize = (int) (-79.855+(-71.412)+(59.284)+(92.14)+(31.839));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(41.916));

} else {
	tcb->m_cWnd = (int) (86.845-(2.8)-(11.485)-(0.06)-(84.756)-(86.071)-(31.046)-(33.96));

}
if (ejRCjTPeHEWSQZFl <= segmentsAcked) {
	tcb->m_cWnd = (int) (26.235+(-21.23)+(66.531)+(11.014)+(33.697)+(27.509)+(76.325)+(60.231));
	segmentsAcked = (int) (((0.1)+(87.212)+(0.1)+(0.1))/((48.348)+(0.1)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (79.312*(36.818)*(98.069)*(24.577)*(segmentsAcked)*(74.077));

}
segmentsAcked = (int) (92.645/63.941);
if (ejRCjTPeHEWSQZFl <= segmentsAcked) {
	tcb->m_cWnd = (int) (26.235+(-21.23)+(66.531)+(11.014)+(33.697)+(27.509)+(76.325)+(60.231));
	segmentsAcked = (int) (((0.1)+(87.212)+(0.1)+(0.1))/((48.348)+(0.1)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (79.312*(36.818)*(98.069)*(24.577)*(segmentsAcked)*(74.077));

}
segmentsAcked = (int) (-65.569/49.126);
