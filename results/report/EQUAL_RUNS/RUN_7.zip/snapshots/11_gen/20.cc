tcb->m_segmentSize = (int) (14.873+(-66.635)+(54.865)+(-10.39));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (90.811-(5.807)-(-91.465));
tcb->m_segmentSize = (int) (58.321-(-63.578)-(53.466));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

} else {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(25.967)-(tcb->m_cWnd));

}
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(-40.911)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

}
tcb->m_cWnd = (int) (-66.531-(43.844)-(44.745)-(-11.544)-(66.528)-(59.12)-(82.732));
tcb->m_cWnd = (int) (-69.687-(55.534)-(-28.185)-(-32.582)-(-28.149)-(10.057)-(6.943));
tcb->m_segmentSize = (int) (-16.848+(60.794)+(-84.073)+(14.166)+(9.738)+(40.69)+(44.888)+(60.099));
tcb->m_segmentSize = (int) (-39.043+(-6.874)+(-4.818)+(-45.149)+(-66.894)+(-37.995)+(-39.23)+(63.354));
