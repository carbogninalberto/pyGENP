segmentsAcked = (int) (47.786/54.217);
segmentsAcked = (int) (44.025-(28.568)-(56.515)-(-1.75)-(-67.404));
segmentsAcked = (int) (85.351/96.873);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-60.677/98.883);
segmentsAcked = (int) (-82.851-(-28.464)-(-57.748)-(-95.428)-(42.545));
segmentsAcked = (int) (-22.416/-71.989);
