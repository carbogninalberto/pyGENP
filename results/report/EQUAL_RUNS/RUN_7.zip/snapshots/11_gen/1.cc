TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (97.043+(-74.71));
segmentsAcked = (int) (-1.855+(43.661));
segmentsAcked = (int) (47.739+(-85.905));
segmentsAcked = (int) (90.547+(-24.1));
