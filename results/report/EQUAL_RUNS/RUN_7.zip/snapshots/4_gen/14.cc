float LUoLyXFudoQFEdHy = (float) (-80.795*(69.325)*(-79.113)*(36.401)*(62.533)*(-85.727)*(51.613));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
