float IcrKYHxTaOxrqFYs = (float) (((-94.885)+((10.943*(-28.584)*(-16.766)*(82.881)*(-55.161)*(-18.676)*(-62.963)*(-37.232)))+(66.906)+(-44.251)+(65.242))/((-27.796)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-27.25*(-94.636)*(-73.828)*(83.311)*(-34.981)*(1.113)*(-13.276));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (72.068*(-17.15)*(52.563));
tcb->m_segmentSize = (int) (-93.71*(80.722)*(-70.067)*(12.184)*(-46.347)*(0.696)*(42.723));
CongestionAvoidance (tcb, segmentsAcked);
