float IcrKYHxTaOxrqFYs = (float) (((-86.775)+((70.694*(-31.046)*(-93.705)*(25.492)*(37.758)*(-27.384)*(-38.67)*(6.1)))+(33.638)+(-41.637)+(-28.485))/((21.041)));
tcb->m_segmentSize = (int) (-55.584*(-3.135)*(-95.613)*(-41.675)*(-85.574)*(50.135)*(19.633));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-11.964*(-13.625)*(-85.324));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-32.143*(-71.42)*(-21.594)*(2.602)*(-15.658)*(87.673)*(88.808));
