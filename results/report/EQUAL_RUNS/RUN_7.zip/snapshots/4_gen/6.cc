segmentsAcked = SlowStart (tcb, segmentsAcked);
int oCRGVsyLtcbtsnVW = (int) 94.093;
tcb->m_cWnd = (int) (3.817*(10.459)*(-68.632)*(-26.477)*(46.22)*(-3.569)*(40.528)*(98.981)*(48.96));
oCRGVsyLtcbtsnVW = (int) (-92.564-(-49.791));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (25.149+(6.768)+(3.032)+(75.443)+(33.464)+(55.751)+(tcb->m_cWnd)+(88.148)+(50.582));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (38.712+(21.778)+(63.602)+(tcb->m_cWnd)+(91.037)+(44.146)+(70.598)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (18.94-(11.637));

}
