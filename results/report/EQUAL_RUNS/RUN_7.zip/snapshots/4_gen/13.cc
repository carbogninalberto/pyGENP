ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-17.007+(67.021)+(98.009)+(36.006)+(-65.859)+(-9.925)+(17.626)+(-13.901)+(61.508));
