segmentsAcked = (int) (93.701/-79.281);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-80.814+(70.431)+(41.146)+(-51.551)+(55.586)+(-71.035)+(-45.983)+(-63.033)+(-71.395));
segmentsAcked = SlowStart (tcb, segmentsAcked);
