int geRQPScMBQrpeanB = (int) (-34.996+(55.547)+(71.818)+(79.217)+(-2.892));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float diijVQJykFAMPayc = (float) 80.62;
diijVQJykFAMPayc = (float) (-51.833-(1.375)-(1.556)-(-62.114)-(-23.928));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-88.96+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-88.96+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
diijVQJykFAMPayc = (float) (-86.193-(14.662)-(-67.031)-(-47.126)-(-61.529));
diijVQJykFAMPayc = (float) (55.244*(-69.317)*(-36.979)*(52.307)*(30.784)*(-37.227)*(-1.196)*(-77.905));
ReduceCwnd (tcb);
diijVQJykFAMPayc = (float) (-27.011*(-17.404)*(-4.601)*(33.824)*(59.539)*(-88.087)*(-99.581)*(-61.314));
ReduceCwnd (tcb);
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-71.049+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-88.96+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-71.049+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-88.96+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
diijVQJykFAMPayc = (float) (81.719*(47.62)*(32.174)*(72.388)*(-5.924)*(-73.277)*(41.087)*(17.218));
