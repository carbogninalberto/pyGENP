ReduceCwnd (tcb);
segmentsAcked = (int) (-27.7+(-77.857)+(-4.09)+(51.349)+(-49.062)+(24.651)+(-5.789)+(-20.363)+(-63.201));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-68.006+(-35.09)+(-55.531)+(67.488)+(-17.269)+(-33.235)+(63.123)+(-17.003)+(-45.528));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
