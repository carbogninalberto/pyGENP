segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-2.561+(-11.663));
segmentsAcked = (int) (34.863+(-63.674));
