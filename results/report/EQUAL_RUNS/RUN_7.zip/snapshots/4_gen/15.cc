int geRQPScMBQrpeanB = (int) (52.815+(-65.923)+(60.662)+(25.807)+(89.256));
float diijVQJykFAMPayc = (float) 33.992;
diijVQJykFAMPayc = (float) (90.218-(61.859)-(92.015)-(-42.026)-(-63.51));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-88.96+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-88.96+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
diijVQJykFAMPayc = (float) (84.183*(95.467)*(-26.984)*(93.561)*(-21.725)*(-9.698)*(-95.762)*(-81.207));
diijVQJykFAMPayc = (float) (-94.993*(-17.452)*(-78.28)*(-93.705)*(-4.099)*(75.045)*(-35.36)*(54.323));
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-71.049+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-71.049+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
