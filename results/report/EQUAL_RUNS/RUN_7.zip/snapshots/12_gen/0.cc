ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (16.409+(53.022)+(-59.231)+(-82.37)+(-70.201)+(13.731)+(4.399)+(-12.863));
