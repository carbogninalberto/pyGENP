tcb->m_segmentSize = (int) (27.721+(-33.202)+(65.764)+(53.856));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (61.209-(99.649)-(16.039));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (58.496-(51.635)-(-51.305));
tcb->m_segmentSize = (int) (-33.434-(-80.097)-(37.429));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-93.751-(80.578)-(-43.754));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

} else {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(25.967)-(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(-40.911)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

}
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

} else {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(25.967)-(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (-38.054-(28.608)-(59.978)-(75.869)-(-76.07)-(-46.219)-(21.695));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (71.085-(84.661)-(-40.911)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (78.763*(60.733)*(37.023)*(42.333)*(83.12));

}
tcb->m_cWnd = (int) (-92.752-(-20.467)-(-41.805)-(13.747)-(50.374)-(52.958)-(-53.375));
tcb->m_cWnd = (int) (-72.635-(-97.004)-(-0.533)-(88.704)-(36.91)-(-30.114)-(-21.225));
tcb->m_segmentSize = (int) (22.091+(34.539)+(5.569)+(42.078)+(68.134)+(-43.519)+(-98.457)+(-28.01));
tcb->m_cWnd = (int) (67.08-(58.675)-(-17.74)-(19.724)-(51.148)-(93.61)-(26.121));
tcb->m_segmentSize = (int) (-66.349+(-12.584)+(-80.581)+(-96.588)+(33.986)+(-82.546)+(76.834)+(8.593));
tcb->m_segmentSize = (int) (78.925+(18.367)+(86.468)+(26.119)+(96.874)+(9.943)+(26.71)+(-63.136));
