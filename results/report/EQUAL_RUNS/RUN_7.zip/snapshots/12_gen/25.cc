TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (84.741+(-39.362));
segmentsAcked = (int) (-62.144+(88.419));
segmentsAcked = (int) (21.397+(92.581));
segmentsAcked = (int) (27.642+(-77.696));
segmentsAcked = (int) (-66.141+(90.613));
segmentsAcked = (int) (63.463+(-28.739));
segmentsAcked = (int) (70.948+(-21.509));
segmentsAcked = (int) (-80.414+(38.298));
