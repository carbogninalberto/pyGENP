if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (32.328*(tcb->m_segmentSize)*(76.217)*(10.24)*(72.727)*(58.326)*(34.854));

}
segmentsAcked = (int) (-33.76*(-76.751)*(-85.506)*(50.102)*(46.676)*(-42.614));
segmentsAcked = (int) (-36.568-(5.51)-(-37.833)-(-35.522)-(-24.785));
segmentsAcked = (int) (17.848/-95.6);
segmentsAcked = (int) ((44.183+(-55.383)+(-84.704)+(44.337)+(76.296)+(69.643)+(-87.37)+(-21.367))/61.715);
segmentsAcked = (int) (48.743/81.64);
segmentsAcked = (int) ((45.252+(-25.137)+(45.498)+(20.303)+(36.01)+(-87.807)+(85.316)+(-21.426))/46.741);
