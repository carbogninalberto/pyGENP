float fXBeMszcSESaCDwr = (float) 34.946;
fXBeMszcSESaCDwr = (float) ((-58.886+(4.785)+(-41.233)+(-30.308)+(-64.616)+(68.771))/-2.852);
fXBeMszcSESaCDwr = (float) ((16.441+(-70.313)+(20.709)+(66.769)+(47.576)+(59.651))/77.33);
if (fXBeMszcSESaCDwr < tcb->m_segmentSize) {
	segmentsAcked = (int) (91.837*(13.173)*(23.179)*(56.42)*(segmentsAcked)*(30.814));
	tcb->m_segmentSize = (int) (fXBeMszcSESaCDwr+(10.163)+(40.421));

} else {
	segmentsAcked = (int) (76.946*(33.206)*(68.437)*(26.792)*(86.116)*(43.319));
	fXBeMszcSESaCDwr = (float) (24.595-(78.878)-(25.117)-(33.847)-(48.231)-(62.83)-(16.868));

}
if (fXBeMszcSESaCDwr < tcb->m_segmentSize) {
	segmentsAcked = (int) (76.946*(33.206)*(68.437)*(26.792)*(86.116)*(43.319));
	fXBeMszcSESaCDwr = (float) (24.595-(78.878)-(25.117)-(33.847)-(48.231)-(62.83)-(16.868));

} else {
	segmentsAcked = (int) (91.837*(13.173)*(23.179)*(56.42)*(segmentsAcked)*(30.814));
	tcb->m_segmentSize = (int) (fXBeMszcSESaCDwr+(10.163)+(40.421));

}
if (fXBeMszcSESaCDwr < tcb->m_segmentSize) {
	segmentsAcked = (int) (76.946*(33.206)*(68.437)*(26.792)*(86.116)*(43.319));
	fXBeMszcSESaCDwr = (float) (24.595-(78.878)-(25.117)-(33.847)-(48.231)-(62.83)-(16.868));

} else {
	segmentsAcked = (int) (91.837*(13.173)*(23.179)*(56.42)*(segmentsAcked)*(30.814));
	tcb->m_segmentSize = (int) (fXBeMszcSESaCDwr+(10.163)+(40.421));

}
