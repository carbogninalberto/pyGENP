ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (42.979+(-9.017)+(-66.488)+(64.865)+(-68.996)+(-74.213)+(-79.296)+(90.136));
tcb->m_segmentSize = (int) (-31.044+(36.047)+(-54.659)+(33.889)+(-73.939)+(-73.954)+(77.812)+(-35.08));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-24.497+(-57.995)+(-98.642)+(-63.975)+(-2.28)+(39.376)+(89.494)+(-19.076));
tcb->m_segmentSize = (int) (68.288+(78.651)+(-78.257)+(89.083)+(-30.211)+(-79.307)+(0.409)+(-56.448));
