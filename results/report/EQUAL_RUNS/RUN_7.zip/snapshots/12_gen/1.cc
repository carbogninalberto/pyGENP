TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (5.19+(41.439));
segmentsAcked = (int) (39.867+(37.3));
segmentsAcked = (int) (98.929+(-8.648));
segmentsAcked = (int) (84.498+(-13.366));
