TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (16.616+(-66.383));
segmentsAcked = (int) (95.945+(73.724));
segmentsAcked = (int) (-61.609+(0.137));
segmentsAcked = (int) (78.51+(0.097));
segmentsAcked = (int) (-87.808+(76.229));
