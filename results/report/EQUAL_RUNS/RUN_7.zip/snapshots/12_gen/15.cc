float fXBeMszcSESaCDwr = (float) 40.287;
fXBeMszcSESaCDwr = (float) ((-94.016+(38.118)+(-68.235)+(-52.322)+(98.388)+(22.246))/4.063);
fXBeMszcSESaCDwr = (float) ((75.711+(15.765)+(-30.829)+(-34.382)+(61.158)+(-46.333))/23.013);
if (fXBeMszcSESaCDwr < tcb->m_segmentSize) {
	segmentsAcked = (int) (76.946*(33.206)*(68.437)*(26.792)*(86.116)*(43.319));
	fXBeMszcSESaCDwr = (float) (24.595-(78.878)-(25.117)-(33.847)-(48.231)-(62.83)-(16.868));

} else {
	segmentsAcked = (int) (91.837*(13.173)*(23.179)*(56.42)*(segmentsAcked)*(30.814));
	tcb->m_segmentSize = (int) (fXBeMszcSESaCDwr+(10.163)+(40.421));

}
if (fXBeMszcSESaCDwr < tcb->m_segmentSize) {
	segmentsAcked = (int) (76.946*(33.206)*(68.437)*(26.792)*(86.116)*(43.319));
	fXBeMszcSESaCDwr = (float) (24.595-(78.878)-(25.117)-(33.847)-(48.231)-(62.83)-(16.868));

} else {
	segmentsAcked = (int) (91.837*(13.173)*(23.179)*(56.42)*(segmentsAcked)*(30.814));
	tcb->m_segmentSize = (int) (fXBeMszcSESaCDwr+(10.163)+(40.421));

}
