tcb->m_segmentSize = (int) (86.721+(-20.52)+(-53.657)+(-5.024));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
