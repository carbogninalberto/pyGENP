ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (6.893+(-5.405)+(-79.606)+(44.394)+(67.077)+(22.521)+(-50.666)+(12.065));
tcb->m_segmentSize = (int) (26.492+(-51.9)+(-72.271)+(88.676)+(7.946)+(47.759)+(83.197)+(-71.818));
