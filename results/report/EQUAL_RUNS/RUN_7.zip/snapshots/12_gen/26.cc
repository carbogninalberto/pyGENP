ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (23.063+(-0.842)+(26.864)+(28.231)+(-46.799)+(-85.068)+(-2.78)+(-93.558));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (18.09+(15.86)+(-22.334)+(59.048)+(-24.273)+(77.315)+(-39.404)+(93.49));
