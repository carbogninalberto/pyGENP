segmentsAcked = (int) (-32.17/49.163);
float yYAqhUyXfVaSbAHj = (float) (-84.677-(18.08)-(-70.458)-(31.703)-(52.652)-(95.136));
segmentsAcked = (int) (-27.067-(21.292)-(98.412)-(-84.861)-(-6.056));
