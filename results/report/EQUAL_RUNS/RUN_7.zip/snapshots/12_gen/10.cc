tcb->m_cWnd = (int) (60.489+(-99.09));
segmentsAcked = (int) (-38.178-(-20.606)-(-77.436)-(-41.339)-(30.828));
segmentsAcked = (int) (-4.27/-51.992);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-77.337/64.057);
segmentsAcked = (int) (14.144-(-94.759)-(-27.327)-(21.353)-(91.538));
segmentsAcked = (int) (60.155/97.007);
