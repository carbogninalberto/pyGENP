segmentsAcked = (int) (-92.356/-60.85);
segmentsAcked = (int) (12.443/-93.81);
segmentsAcked = (int) (-3.081-(-50.011)-(-53.862)-(65.96)-(-31.59));
segmentsAcked = (int) (-8.731/-24.129);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-87.463/39.548);
segmentsAcked = (int) (-92.559-(72.463)-(0.106)-(-16.87)-(29.01));
