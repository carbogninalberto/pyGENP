ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (52.145+(52.026)+(79.848)+(-85.196)+(89.0)+(-80.315)+(-93.029)+(-26.019));
