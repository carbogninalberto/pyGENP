tcb->m_ssThresh = (int) (87.525/0.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
float ehKcsakraFhiZEva = (float) (((0.1)+(0.1)+(0.1)+((55.468-(50.772)-(77.033)-(52.065)-(28.44)))+(0.1))/((0.1)+(0.1)+(0.1)));
segmentsAcked = (int) ((30.34*(ehKcsakraFhiZEva)*(segmentsAcked))/0.1);
