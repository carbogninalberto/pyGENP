int HmwjbecshWSaQxKd = (int) (-83.303-(58.901)-(7.041)-(-45.091)-(88.508));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	segmentsAcked = (int) (78.233-(40.002)-(17.107)-(48.75)-(82.774)-(70.537));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (31.94-(segmentsAcked)-(89.665));
	ReduceCwnd (tcb);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (73.831-(65.333)-(-94.3)-(-53.482)-(25.674)-(-37.832));
HmwjbecshWSaQxKd = (int) (85.985-(63.366)-(-35.419)-(49.729)-(-10.197)-(-75.107));
segmentsAcked = SlowStart (tcb, segmentsAcked);
