ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (93.471+(40.342)+(73.234)+(35.532)+(-6.385)+(61.152)+(-60.382)+(6.228));
tcb->m_segmentSize = (int) (53.107+(-42.219)+(-73.689)+(89.813)+(48.738)+(19.244)+(-40.786)+(-88.117));
