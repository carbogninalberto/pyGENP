ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-89.213+(-8.896)+(53.905)+(-25.312)+(-36.947)+(64.49)+(22.056)+(59.725));
tcb->m_segmentSize = (int) (99.768+(95.392)+(38.426)+(4.72)+(94.686)+(58.622)+(-54.138)+(14.964));
