int HmwjbecshWSaQxKd = (int) (-46.913-(-26.161)-(97.07)-(82.5)-(-51.126));
HmwjbecshWSaQxKd = (int) (60.99-(80.311)-(-7.831)-(87.781)-(54.82)-(-25.862));
segmentsAcked = (int) (-98.954-(-37.006)-(64.463)-(79.01)-(-30.046)-(-62.544));
segmentsAcked = SlowStart (tcb, segmentsAcked);
