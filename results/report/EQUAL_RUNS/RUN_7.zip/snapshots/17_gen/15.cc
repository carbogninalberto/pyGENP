if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) ((59.15-(75.456))/90.843);

} else {
	segmentsAcked = (int) (44.445+(70.615));
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(tcb->m_ssThresh)+(94.133)+(tcb->m_ssThresh)+(3.043)+(segmentsAcked)+(4.43));

}
tcb->m_cWnd = (int) (74.416*(4.896)*(84.319)*(91.181)*(40.466)*(tcb->m_cWnd));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (38.837*(95.402)*(47.64)*(94.695)*(tcb->m_ssThresh)*(37.704)*(tcb->m_ssThresh)*(75.767));
