ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (98.578+(10.971)+(-21.648)+(-47.413)+(-78.369)+(-1.014)+(11.307)+(71.728));
