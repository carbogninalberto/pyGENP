if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (85.02-(19.102)-(30.129)-(14.984)-(3.358)-(27.391));
	tcb->m_ssThresh = (int) (0.1/47.942);

} else {
	tcb->m_cWnd = (int) (12.144+(87.454)+(7.267));

}
segmentsAcked = (int) (57.881/13.457);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(21.184)-(32.419)-(14.36));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(82.715)+(61.356)+(segmentsAcked)+(tcb->m_cWnd)+(98.849)+(27.142));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (29.784+(tcb->m_cWnd)+(78.72)+(tcb->m_cWnd)+(76.02)+(4.216));
segmentsAcked = (int) (79.204-(tcb->m_cWnd)-(86.36)-(28.836)-(3.804)-(0.447));
