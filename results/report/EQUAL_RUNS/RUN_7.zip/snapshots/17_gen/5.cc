ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (84.007+(47.972)+(-1.578)+(14.963)+(-16.149)+(-38.413)+(-58.742)+(44.089));
