int VsCMYxDwJJlzUPdn = (int) (((25.715)+(-20.984)+(-64.715)+(40.133)+(25.971))/((73.851)+(11.828)+(79.28)+(81.318)));
CongestionAvoidance (tcb, segmentsAcked);
