ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(53.0)-(62.249)-(segmentsAcked)-(tcb->m_cWnd)-(70.192));
	tcb->m_cWnd = (int) (93.358*(27.067)*(13.766)*(20.895)*(66.407)*(75.134));

} else {
	tcb->m_segmentSize = (int) (6.377-(84.5)-(28.074)-(tcb->m_cWnd)-(segmentsAcked)-(6.628)-(91.952));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (21.613-(88.517));
float xTTfJmquWZHjfyaS = (float) (((0.1)+(0.1)+(0.1)+(0.1)+(0.1)+(26.646))/((1.018)));
tcb->m_cWnd = (int) (75.241*(6.066)*(96.079)*(xTTfJmquWZHjfyaS)*(tcb->m_cWnd)*(29.454)*(tcb->m_segmentSize)*(80.8)*(87.684));
if (xTTfJmquWZHjfyaS >= tcb->m_ssThresh) {
	xTTfJmquWZHjfyaS = (float) (97.803*(88.78)*(0.355)*(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	xTTfJmquWZHjfyaS = (float) (35.619+(xTTfJmquWZHjfyaS)+(1.46)+(91.057)+(44.092));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(81.483)-(79.246)-(tcb->m_ssThresh)-(xTTfJmquWZHjfyaS)-(tcb->m_segmentSize));

}
CongestionAvoidance (tcb, segmentsAcked);
