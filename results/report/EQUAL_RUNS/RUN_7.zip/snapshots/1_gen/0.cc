if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(44.884)*(97.4)*(segmentsAcked)*(tcb->m_ssThresh)*(96.277));
	tcb->m_segmentSize = (int) (55.849/99.475);

} else {
	tcb->m_segmentSize = (int) (29.147-(77.177)-(48.021)-(81.572)-(29.671)-(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (24.024-(segmentsAcked)-(27.09)-(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (73.753*(tcb->m_ssThresh)*(63.333)*(8.011)*(tcb->m_cWnd)*(21.831));
tcb->m_ssThresh = (int) (72.296+(tcb->m_cWnd)+(segmentsAcked));
segmentsAcked = (int) (0.1/19.172);
segmentsAcked = (int) (0.1/45.815);
