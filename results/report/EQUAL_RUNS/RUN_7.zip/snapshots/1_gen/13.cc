CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(18.501)-(57.149)-(2.09)-(51.6)-(41.478)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(66.865));
	tcb->m_ssThresh = (int) (14.348+(tcb->m_segmentSize)+(50.737)+(80.972)+(24.988));

} else {
	tcb->m_cWnd = (int) (61.44-(segmentsAcked));
	segmentsAcked = (int) (tcb->m_cWnd-(58.702)-(tcb->m_cWnd)-(19.365)-(tcb->m_segmentSize)-(segmentsAcked));

}
tcb->m_ssThresh = (int) (21.771*(13.511)*(79.772)*(25.483)*(72.255)*(31.5)*(16.092)*(34.958));
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (50.954-(95.255));

} else {
	tcb->m_ssThresh = (int) (33.248/0.1);
	tcb->m_segmentSize = (int) (56.925-(19.267)-(23.376)-(63.484));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(79.07)+(44.793)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(20.29)+(17.651));

}
ReduceCwnd (tcb);
