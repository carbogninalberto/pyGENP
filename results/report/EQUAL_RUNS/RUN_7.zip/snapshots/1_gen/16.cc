ReduceCwnd (tcb);
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	segmentsAcked = (int) (51.41+(56.063)+(95.907)+(segmentsAcked)+(34.794)+(29.416)+(segmentsAcked)+(24.978)+(segmentsAcked));
	segmentsAcked = (int) (31.502-(78.527));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (83.514-(34.077)-(28.539)-(16.319)-(27.304)-(26.813)-(21.799)-(tcb->m_cWnd)-(segmentsAcked));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float cfBdcTUTniUEnAuQ = (float) (80.831*(tcb->m_cWnd));
tcb->m_segmentSize = (int) (26.589+(93.867)+(1.026)+(18.015)+(15.664)+(33.127)+(62.531)+(98.442));
tcb->m_cWnd = (int) (((0.1)+(13.121)+(40.185)+(88.236))/((0.1)+(0.1)+(91.717)+(0.1)));
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (52.389*(95.336)*(64.031)*(45.236)*(39.697)*(19.46)*(43.295)*(54.558)*(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (92.2+(52.492)+(57.941)+(52.953)+(79.966)+(15.693)+(3.088)+(74.888)+(cfBdcTUTniUEnAuQ));

}
