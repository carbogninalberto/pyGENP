segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (57.714*(63.63)*(51.248));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (37.494+(1.298)+(22.039)+(84.207)+(23.434)+(11.27));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (27.308-(28.451)-(tcb->m_cWnd)-(85.388)-(82.737)-(27.605));
