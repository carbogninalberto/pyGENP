tcb->m_segmentSize = (int) (11.669-(33.058)-(tcb->m_ssThresh)-(47.948)-(34.944)-(tcb->m_cWnd)-(42.893)-(78.701)-(tcb->m_ssThresh));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (0.1/58.631);
segmentsAcked = (int) (tcb->m_segmentSize*(74.645)*(21.67)*(64.516)*(52.245)*(27.947));
tcb->m_ssThresh = (int) (46.142-(84.1));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (12.688-(74.918)-(37.916)-(23.353)-(96.227)-(20.989)-(5.758)-(17.4));
