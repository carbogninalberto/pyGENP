float HzYQvKqEFyOsrtVj = (float) (2.775+(tcb->m_cWnd)+(segmentsAcked)+(79.556)+(48.529)+(2.207)+(51.53)+(82.287));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float mccMmbpuPiaFOMMu = (float) (45.894+(26.323)+(35.15));
if (tcb->m_ssThresh == HzYQvKqEFyOsrtVj) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(tcb->m_segmentSize)*(97.581)*(54.42)*(76.285)*(53.067)*(tcb->m_ssThresh)*(tcb->m_segmentSize));
	HzYQvKqEFyOsrtVj = (float) (HzYQvKqEFyOsrtVj+(46.816)+(68.1)+(52.078)+(26.878)+(HzYQvKqEFyOsrtVj)+(segmentsAcked)+(52.6)+(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (24.378*(99.314)*(37.026));
	mccMmbpuPiaFOMMu = (float) ((53.205*(17.051)*(98.101))/32.428);

}
tcb->m_cWnd = (int) (38.577-(HzYQvKqEFyOsrtVj)-(63.535)-(27.092));
tcb->m_cWnd = (int) (9.499+(37.572)+(43.317)+(97.877)+(15.6)+(67.229)+(16.32)+(tcb->m_cWnd)+(16.375));
HzYQvKqEFyOsrtVj = (float) (0.1/39.37);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked < segmentsAcked) {
	segmentsAcked = (int) (tcb->m_ssThresh-(68.52));

} else {
	segmentsAcked = (int) (85.512-(98.366)-(90.141)-(tcb->m_ssThresh)-(mccMmbpuPiaFOMMu)-(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (70.82+(7.718));
	tcb->m_cWnd = (int) (77.387-(tcb->m_ssThresh)-(48.419)-(15.445)-(56.494)-(mccMmbpuPiaFOMMu));

}
