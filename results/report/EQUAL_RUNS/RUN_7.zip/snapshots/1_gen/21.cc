CongestionAvoidance (tcb, segmentsAcked);
float DzoptRDoYjSzDJXc = (float) ((tcb->m_segmentSize+(64.193)+(13.436)+(56.771)+(4.917)+(35.116)+(30.159))/0.1);
tcb->m_segmentSize = (int) ((((41.02-(75.429)-(63.356)-(29.252)-(92.709)-(tcb->m_ssThresh)-(95.173)-(78.341)))+(0.1)+(0.1)+(14.509)+(0.1))/((52.335)+(77.528)));
if (DzoptRDoYjSzDJXc > DzoptRDoYjSzDJXc) {
	tcb->m_cWnd = (int) (91.504+(segmentsAcked)+(91.401)+(8.498)+(78.01)+(66.487));
	tcb->m_cWnd = (int) (74.937+(tcb->m_segmentSize)+(24.171)+(tcb->m_segmentSize)+(segmentsAcked)+(38.105)+(tcb->m_ssThresh)+(3.978));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(72.521)-(segmentsAcked)-(DzoptRDoYjSzDJXc)-(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (63.719*(64.79)*(35.8));

} else {
	tcb->m_ssThresh = (int) ((tcb->m_segmentSize-(52.155)-(44.588))/80.668);
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (0.875+(tcb->m_ssThresh)+(tcb->m_cWnd)+(32.705)+(74.758)+(45.251));
segmentsAcked = SlowStart (tcb, segmentsAcked);
