if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (21.2*(10.727)*(68.41)*(99.927)*(6.571)*(25.649));

} else {
	tcb->m_cWnd = (int) (68.856+(56.109)+(11.955)+(tcb->m_segmentSize)+(2.282));
	tcb->m_cWnd = (int) (43.285+(7.405)+(30.211));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (67.495/0.1);
	tcb->m_ssThresh = (int) (segmentsAcked*(17.319)*(tcb->m_ssThresh)*(84.376)*(6.615));

} else {
	tcb->m_segmentSize = (int) (39.866*(segmentsAcked)*(22.533)*(21.837)*(97.818)*(29.354)*(38.429)*(19.516));
	segmentsAcked = (int) (53.434+(79.399)+(98.185)+(1.784)+(36.554)+(98.545)+(segmentsAcked)+(tcb->m_cWnd)+(segmentsAcked));
	tcb->m_ssThresh = (int) (15.436+(37.515)+(tcb->m_cWnd)+(55.008));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (75.315+(67.07)+(60.522)+(64.634)+(51.404)+(31.153)+(segmentsAcked)+(tcb->m_ssThresh)+(69.814));

} else {
	tcb->m_segmentSize = (int) (0.1/78.406);

}
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (55.38+(52.108));
	tcb->m_ssThresh = (int) (16.277*(11.447)*(29.687)*(91.59)*(tcb->m_segmentSize)*(33.0)*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (24.386+(segmentsAcked)+(17.206)+(70.216));
	segmentsAcked = (int) (((13.411)+((tcb->m_segmentSize+(32.974)))+(0.1)+(82.564))/((0.1)+(15.795)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

}
