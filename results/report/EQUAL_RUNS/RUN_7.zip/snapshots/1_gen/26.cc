ReduceCwnd (tcb);
ReduceCwnd (tcb);
float BMYjiykJPcBZgVZj = (float) (84.973-(98.263)-(33.62)-(17.837));
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_cWnd = (int) ((24.216-(99.627))/16.168);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(96.017));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
