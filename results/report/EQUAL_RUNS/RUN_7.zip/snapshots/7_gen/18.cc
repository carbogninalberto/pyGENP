if (tcb->m_segmentSize >= tcb->m_cWnd) {
	segmentsAcked = (int) (38.643-(segmentsAcked)-(93.672)-(tcb->m_cWnd)-(16.898));

} else {
	segmentsAcked = (int) (0.1/0.1);

}
tcb->m_ssThresh = (int) (76.815-(2.104)-(tcb->m_ssThresh)-(79.133)-(73.577)-(segmentsAcked)-(31.685));
float NMMkTYGyIILdAlWs = (float) (((96.845)+(2.142)+(31.11)+(0.1)+(0.1)+(0.1))/((76.83)+(26.207)+(0.1)));
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (98.003*(13.588)*(17.497)*(95.348)*(tcb->m_cWnd)*(NMMkTYGyIILdAlWs));

} else {
	tcb->m_ssThresh = (int) ((57.21-(29.8)-(71.72)-(segmentsAcked)-(37.022))/(9.802*(tcb->m_segmentSize)*(49.031)*(tcb->m_ssThresh)*(75.486)*(63.846)));
	tcb->m_ssThresh = (int) (10.73/0.1);

}
if (tcb->m_ssThresh > NMMkTYGyIILdAlWs) {
	segmentsAcked = (int) (27.332*(tcb->m_ssThresh)*(NMMkTYGyIILdAlWs)*(64.49)*(56.901)*(19.294));
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (66.109+(70.574)+(tcb->m_cWnd)+(NMMkTYGyIILdAlWs));
	tcb->m_ssThresh = (int) (((0.1)+((75.278-(tcb->m_cWnd)-(48.533)))+(0.1)+(0.1)+(0.1))/((69.542)+(99.591)+(0.1)));

}
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (95.472*(44.235));

} else {
	tcb->m_ssThresh = (int) (31.454-(33.164)-(48.485)-(27.587)-(10.108));
	ReduceCwnd (tcb);

}
