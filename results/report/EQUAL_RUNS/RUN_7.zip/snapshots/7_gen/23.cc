ReduceCwnd (tcb);
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (95.891-(17.867)-(tcb->m_ssThresh)-(29.992)-(55.925)-(91.581));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(96.897));

} else {
	tcb->m_cWnd = (int) (24.39*(tcb->m_segmentSize)*(32.289)*(64.145)*(74.929)*(tcb->m_ssThresh)*(26.167));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (0.1/57.833);

}
tcb->m_segmentSize = (int) (24.429+(57.816));
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((0.1)+(92.54)+((61.134-(57.221)-(90.503)-(41.57)-(50.07)))+(0.1))/((0.1)+(2.505)+(0.1)));

} else {
	tcb->m_cWnd = (int) (69.004+(tcb->m_ssThresh)+(79.762));
	tcb->m_segmentSize = (int) (0.1/99.439);

}
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (20.049*(segmentsAcked)*(42.48));
