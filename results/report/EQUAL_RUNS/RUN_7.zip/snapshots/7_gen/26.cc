tcb->m_segmentSize = (int) (12.85+(50.347)+(tcb->m_cWnd)+(60.65)+(89.04)+(54.21)+(26.191)+(tcb->m_segmentSize)+(43.189));
tcb->m_cWnd = (int) (32.2-(72.617)-(48.439)-(58.386)-(tcb->m_cWnd)-(tcb->m_cWnd)-(0.944)-(91.078));
tcb->m_cWnd = (int) (35.289-(80.418)-(tcb->m_segmentSize)-(17.039));
tcb->m_segmentSize = (int) (tcb->m_cWnd-(27.515)-(49.091));
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_cWnd = (int) (17.749*(27.18)*(tcb->m_segmentSize)*(11.448));

} else {
	tcb->m_cWnd = (int) (27.732-(8.284)-(31.373)-(98.249)-(60.512)-(77.775)-(30.42)-(90.79)-(0.605));
	tcb->m_cWnd = (int) (30.729+(84.123)+(tcb->m_ssThresh)+(23.998)+(19.921)+(34.011));
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(64.793)+(tcb->m_ssThresh)+(10.896));

}
