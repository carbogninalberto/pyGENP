segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (95.834*(-86.926)*(-14.914)*(4.126)*(58.927)*(58.152)*(-69.633)*(-37.978)*(-19.132));
tcb->m_cWnd = (int) (-98.502*(-70.745)*(-12.596)*(21.963)*(26.835)*(5.944)*(-92.348)*(14.425)*(-18.72));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
