float iVhTpoXJxZXFPOTX = (float) (15.614+(-14.408)+(-36.214)+(-71.239)+(-65.899));
int oCRGVsyLtcbtsnVW = (int) 97.871;
segmentsAcked = (int) (42.668-(-11.818)-(45.275)-(-42.791));
oCRGVsyLtcbtsnVW = (int) (-17.941-(3.061));
