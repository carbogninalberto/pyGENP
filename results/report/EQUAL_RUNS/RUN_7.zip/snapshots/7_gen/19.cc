tcb->m_cWnd = (int) (78.607*(38.686)*(51.832)*(15.54)*(78.76)*(segmentsAcked)*(91.346)*(96.376));
segmentsAcked = (int) (48.503+(80.436));
int OCtnsQYqVZmgdhsx = (int) (12.258*(segmentsAcked)*(72.172)*(43.869)*(76.237));
tcb->m_ssThresh = (int) (0.1/0.1);
ReduceCwnd (tcb);
