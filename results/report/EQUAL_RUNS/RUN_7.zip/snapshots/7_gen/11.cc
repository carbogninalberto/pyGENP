segmentsAcked = (int) (-39.666*(-22.505)*(39.657)*(26.686)*(81.563));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-80.829*(-6.45)*(14.451)*(-18.674)*(-96.169)*(-45.462)*(27.608)*(7.502)*(71.805));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
