segmentsAcked = (int) (7.115*(9.333));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((1.058*(46.213)*(14.76)*(27.288)*(tcb->m_cWnd)*(62.238)*(82.954)*(90.336)*(71.056))/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (76.358-(26.747)-(57.255)-(74.233)-(51.188)-(0.899)-(tcb->m_cWnd)-(64.49));

}
if (segmentsAcked != tcb->m_segmentSize) {
	segmentsAcked = (int) ((8.2+(88.817)+(55.289)+(tcb->m_cWnd)+(63.311)+(39.32)+(0.537))/0.1);
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(23.811)-(22.157)-(2.016)-(49.624));
	segmentsAcked = (int) (20.664-(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) (46.417+(64.407)+(55.277)+(97.294)+(10.452)+(tcb->m_ssThresh)+(68.545)+(22.446));

}
tcb->m_ssThresh = (int) ((48.635-(76.996)-(14.622)-(45.122)-(17.52)-(34.385)-(tcb->m_segmentSize)-(83.981))/0.1);
