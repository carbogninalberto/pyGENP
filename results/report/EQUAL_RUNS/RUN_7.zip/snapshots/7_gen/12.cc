segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-36.876*(-69.802)*(-54.886)*(75.025)*(44.381));
ReduceCwnd (tcb);
