TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (6.195+(-23.575));
segmentsAcked = (int) (97.526+(-68.889));
segmentsAcked = (int) (-90.131+(-24.022));
