TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (57.17/47.218);

} else {
	tcb->m_segmentSize = (int) (0.1/98.576);

}
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (79.073-(tcb->m_cWnd)-(7.476)-(59.941)-(9.736));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(46.88)-(81.393)-(26.945)-(57.196));

} else {
	tcb->m_segmentSize = (int) (87.942-(segmentsAcked)-(43.37)-(72.194)-(segmentsAcked)-(tcb->m_ssThresh)-(88.526)-(93.597)-(71.735));

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) ((27.01+(88.141)+(11.389)+(84.203)+(58.531)+(81.509))/0.1);

} else {
	tcb->m_cWnd = (int) (((92.549)+(19.143)+(0.1)+((6.196+(94.875)))+((73.686*(tcb->m_cWnd)*(94.921)*(64.341)*(tcb->m_cWnd)))+(7.318)+(0.1))/((27.046)+(0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
