tcb->m_cWnd = (int) (-66.963*(35.439)*(39.082)*(73.841));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (34.611+(-58.57)+(-49.764)+(16.762)+(-6.214)+(19.829)+(4.17)+(90.933)+(19.602));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (53.251+(50.569)+(10.379)+(-1.746)+(-82.654)+(-66.843));
tcb->m_cWnd = (int) (-55.205+(73.738)+(-58.382)+(-29.564)+(-69.614));
