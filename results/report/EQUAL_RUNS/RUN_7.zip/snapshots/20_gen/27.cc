if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (37.163/0.1);
	tcb->m_segmentSize = (int) ((((98.849+(82.088)+(18.346)))+(0.1)+(70.082)+(0.1))/((0.1)+(0.1)+(74.512)+(0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (11.007*(23.184)*(3.518)*(25.235)*(96.561)*(90.748));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (82.437-(64.339)-(tcb->m_segmentSize)-(48.545)-(31.358)-(99.869));

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (30.244/74.476);
