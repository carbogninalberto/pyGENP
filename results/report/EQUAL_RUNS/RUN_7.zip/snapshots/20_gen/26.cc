ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-28.179+(-42.023)+(77.35)+(4.613)+(57.637)+(91.585)+(11.835)+(-30.351));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-23.696+(92.802)+(-44.095)+(-1.729)+(26.055)+(20.461)+(90.574)+(-9.963));
