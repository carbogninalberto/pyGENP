float DrcdQpVrHqzzKmGO = (float) (81.198*(2.755)*(36.196)*(22.259)*(34.736)*(tcb->m_cWnd)*(62.018)*(39.284));
tcb->m_segmentSize = (int) (((95.862)+(98.892)+(0.1)+(0.1)+(0.1)+(0.1)+(30.341))/((99.871)));
DrcdQpVrHqzzKmGO = (float) (41.914+(91.038)+(46.776)+(52.619)+(tcb->m_ssThresh)+(38.056)+(18.089)+(segmentsAcked));
int QAgEiqORSlfZJExY = (int) (0.1/90.73);
if (QAgEiqORSlfZJExY >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (segmentsAcked-(44.858)-(77.227)-(88.486)-(69.085)-(12.955)-(66.637));

} else {
	tcb->m_segmentSize = (int) (27.884+(60.259)+(46.277)+(97.035)+(70.28));
	QAgEiqORSlfZJExY = (int) (29.766/0.1);

}
tcb->m_segmentSize = (int) (76.347-(19.289)-(38.591)-(DrcdQpVrHqzzKmGO)-(20.116)-(29.572)-(94.591)-(52.151)-(4.95));
int AespAyfgaSqofzPA = (int) (39.586-(tcb->m_segmentSize));
if (DrcdQpVrHqzzKmGO >= DrcdQpVrHqzzKmGO) {
	QAgEiqORSlfZJExY = (int) (86.763*(8.241)*(tcb->m_cWnd)*(68.0)*(38.43));

} else {
	QAgEiqORSlfZJExY = (int) ((36.873*(87.974)*(13.85)*(48.644)*(54.474)*(tcb->m_segmentSize))/0.1);
	tcb->m_segmentSize = (int) (0.1/0.1);

}
if (tcb->m_ssThresh == segmentsAcked) {
	AespAyfgaSqofzPA = (int) (49.861*(97.546)*(96.227)*(32.395)*(74.294)*(tcb->m_segmentSize)*(8.733)*(56.439)*(1.794));
	QAgEiqORSlfZJExY = (int) (0.1/0.1);
	segmentsAcked = (int) (16.795*(73.089)*(84.541)*(4.235)*(78.945)*(84.877));

} else {
	AespAyfgaSqofzPA = (int) (11.134+(61.343)+(25.829)+(36.179)+(10.92)+(43.754));
	tcb->m_ssThresh = (int) (20.019+(89.017));
	segmentsAcked = (int) (70.271+(DrcdQpVrHqzzKmGO)+(40.712)+(70.681)+(41.442)+(6.198));

}
