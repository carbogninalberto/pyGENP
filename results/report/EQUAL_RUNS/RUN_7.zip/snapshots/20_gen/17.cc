if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) ((99.294+(74.142)+(segmentsAcked))/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (92.268*(60.322)*(6.425));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (43.014/23.407);

}
if (segmentsAcked != segmentsAcked) {
	tcb->m_cWnd = (int) (65.529-(57.872)-(90.585)-(70.548)-(3.316)-(27.679));
	segmentsAcked = (int) (tcb->m_ssThresh+(tcb->m_ssThresh)+(64.373)+(tcb->m_cWnd)+(90.078));
	segmentsAcked = (int) (7.412-(tcb->m_ssThresh)-(82.113));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(4.606)*(42.937)*(57.856)*(91.384)*(7.049));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (37.983-(96.903)-(27.592)-(74.293)-(14.266)-(tcb->m_segmentSize));
