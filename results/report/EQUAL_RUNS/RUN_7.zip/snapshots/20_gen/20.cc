CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= segmentsAcked) {
	segmentsAcked = (int) (90.694-(74.112));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(69.816)*(80.24)*(tcb->m_ssThresh)*(97.738)*(53.074)*(11.648));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	segmentsAcked = (int) ((89.244-(62.183)-(15.769)-(41.751))/0.1);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(0.666)*(54.085)*(87.643)*(54.185)*(tcb->m_ssThresh)*(59.526));
	tcb->m_segmentSize = (int) (12.391*(90.711)*(63.594)*(18.052));

} else {
	segmentsAcked = (int) (39.707*(86.23)*(97.368));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(segmentsAcked)*(52.93)*(60.628));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(70.134)*(2.91));

}
