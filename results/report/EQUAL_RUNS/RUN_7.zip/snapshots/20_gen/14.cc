tcb->m_ssThresh = (int) ((66.721+(tcb->m_cWnd)+(1.319)+(20.69)+(6.694)+(segmentsAcked))/75.747);
int vvKjnemOOItfzSqu = (int) (99.371+(76.723)+(tcb->m_ssThresh)+(80.25)+(34.046)+(19.517)+(98.511));
tcb->m_ssThresh = (int) (16.162-(56.981)-(28.619));
vvKjnemOOItfzSqu = (int) (33.886/36.04);
ReduceCwnd (tcb);
