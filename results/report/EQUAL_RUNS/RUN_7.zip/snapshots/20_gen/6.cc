tcb->m_cWnd = (int) (45.523+(82.489)+(19.159)+(31.548)+(31.751)+(28.289)+(96.404)+(47.485)+(97.672));
ReduceCwnd (tcb);
if (tcb->m_segmentSize != segmentsAcked) {
	segmentsAcked = (int) (54.499*(30.622)*(72.848)*(40.458)*(42.444)*(tcb->m_ssThresh)*(61.679));
	tcb->m_cWnd = (int) (5.4*(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) (98.413-(84.146)-(80.467));
	tcb->m_segmentSize = (int) (61.196-(68.302)-(segmentsAcked));

}
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (40.603+(91.22)+(7.219)+(2.292));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (26.584+(78.322)+(segmentsAcked)+(61.431)+(32.787)+(segmentsAcked)+(99.139));
	segmentsAcked = (int) (tcb->m_segmentSize-(10.312)-(63.941)-(73.058)-(6.828));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
