if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (89.612-(21.228)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(82.022)-(96.573)-(28.348)-(89.583)-(63.548));

} else {
	tcb->m_segmentSize = (int) (59.581-(90.333)-(70.993)-(68.74)-(83.974));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) ((32.173+(77.92)+(80.191)+(11.352)+(49.191)+(60.951)+(17.605)+(64.494)+(57.386))/0.1);

} else {
	tcb->m_cWnd = (int) (35.425+(95.944)+(97.957)+(53.444)+(23.879)+(42.126));
	tcb->m_cWnd = (int) (segmentsAcked+(28.731)+(tcb->m_cWnd)+(42.154)+(75.393)+(53.047)+(67.543)+(58.389)+(62.27));

}
