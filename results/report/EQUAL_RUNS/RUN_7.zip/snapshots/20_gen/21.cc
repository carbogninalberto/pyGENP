if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (50.594+(57.777)+(segmentsAcked)+(5.351)+(98.914)+(63.863)+(59.067)+(32.898)+(segmentsAcked));
	tcb->m_cWnd = (int) (36.425/35.063);

}
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (79.525+(30.636)+(86.938)+(tcb->m_ssThresh));
	segmentsAcked = (int) (19.397+(83.792)+(22.753)+(65.417)+(segmentsAcked)+(10.428));

} else {
	tcb->m_cWnd = (int) (37.592-(67.726)-(tcb->m_segmentSize)-(67.88)-(37.57)-(70.207)-(74.391)-(46.853));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
