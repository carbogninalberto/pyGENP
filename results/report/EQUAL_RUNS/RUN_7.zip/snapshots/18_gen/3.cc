int tYAhCPsxUkaRquWY = (int) (45.968-(48.961)-(-51.545)-(78.07)-(-45.965)-(-87.401)-(11.712));
float yOCixuvkzgNnCSqx = (float) (8.871+(88.392)+(-82.002)+(-14.792)+(82.417)+(72.264)+(-85.9));
int IYcBflYMTeMONEzZ = (int) (68.191*(-70.884)*(-99.631)*(52.889)*(-16.502)*(34.452));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= IYcBflYMTeMONEzZ) {
	tcb->m_segmentSize = (int) (71.251+(10.196)+(72.796)+(39.022)+(19.095)+(37.93)+(62.693)+(18.265));
	IYcBflYMTeMONEzZ = (int) ((((segmentsAcked+(29.112)+(20.565)+(73.201)+(segmentsAcked)))+(94.331)+((segmentsAcked+(21.398)+(0.041)+(79.168)))+(0.1)+(0.1)+(0.1)+(64.597))/((0.1)+(48.846)));

} else {
	tcb->m_segmentSize = (int) (65.673+(tcb->m_segmentSize)+(-76.1)+(IYcBflYMTeMONEzZ));

}
int JfvQvZjjDuDUkwaM = (int) (((-72.265)+(7.81)+(-2.21)+(72.293))/((-27.027)+(85.88)+(75.972)+(32.704)+(-93.624)));
yOCixuvkzgNnCSqx = (float) (11.48+(83.089)+(31.627)+(69.505)+(82.227)+(-1.74)+(-8.401)+(-77.62));
if (tcb->m_segmentSize <= IYcBflYMTeMONEzZ) {
	tcb->m_segmentSize = (int) (71.251+(10.196)+(72.796)+(39.022)+(19.095)+(37.93)+(62.693)+(18.265));
	IYcBflYMTeMONEzZ = (int) ((((segmentsAcked+(29.112)+(20.565)+(73.201)+(segmentsAcked)))+(94.331)+((segmentsAcked+(21.398)+(0.041)+(79.168)))+(0.1)+(0.1)+(0.1)+(64.597))/((0.1)+(48.846)));

} else {
	tcb->m_segmentSize = (int) (65.673+(tcb->m_segmentSize)+(2.638)+(IYcBflYMTeMONEzZ));

}
yOCixuvkzgNnCSqx = (float) (-3.16+(-24.732)+(21.985)+(-8.966)+(-34.164)+(-3.604)+(83.959)+(-98.091));
