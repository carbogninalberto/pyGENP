segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (73.086-(23.415)-(52.477));
tcb->m_cWnd = (int) (82.318/0.1);
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (14.771+(20.67)+(32.221)+(tcb->m_segmentSize)+(11.824)+(74.737)+(tcb->m_segmentSize)+(82.152));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (0.1/60.821);

}
tcb->m_cWnd = (int) (83.169*(tcb->m_cWnd)*(31.312)*(42.566)*(46.122)*(segmentsAcked));
