int tYAhCPsxUkaRquWY = (int) (1.396-(-16.6)-(-72.067)-(13.163)-(-89.544)-(88.166)-(-20.478));
float yOCixuvkzgNnCSqx = (float) (-16.586+(-39.888)+(66.705)+(10.101)+(-64.372)+(31.368)+(60.836));
int IYcBflYMTeMONEzZ = (int) (60.56*(75.183)*(95.874)*(-56.23)*(-63.581)*(-78.203));
if (segmentsAcked != segmentsAcked) {
	tcb->m_segmentSize = (int) (93.921-(42.065)-(77.349)-(8.766)-(92.047)-(1.342)-(54.793)-(66.242)-(61.618));
	segmentsAcked = (int) (21.822-(40.464));

} else {
	tcb->m_segmentSize = (int) (((97.766)+(26.075)+(0.1)+(0.1)+(98.859))/((0.1)));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= IYcBflYMTeMONEzZ) {
	tcb->m_segmentSize = (int) (71.251+(10.196)+(72.796)+(39.022)+(19.095)+(37.93)+(62.693)+(18.265));
	IYcBflYMTeMONEzZ = (int) ((((segmentsAcked+(29.112)+(20.565)+(73.201)+(segmentsAcked)))+(94.331)+((segmentsAcked+(21.398)+(0.041)+(79.168)))+(0.1)+(0.1)+(0.1)+(64.597))/((0.1)+(48.846)));

} else {
	tcb->m_segmentSize = (int) (65.673+(tcb->m_segmentSize)+(66.368)+(IYcBflYMTeMONEzZ));

}
if (tcb->m_segmentSize <= IYcBflYMTeMONEzZ) {
	tcb->m_segmentSize = (int) (71.251+(10.196)+(72.796)+(39.022)+(19.095)+(37.93)+(62.693)+(18.265));
	IYcBflYMTeMONEzZ = (int) ((((segmentsAcked+(29.112)+(20.565)+(73.201)+(segmentsAcked)))+(94.331)+((segmentsAcked+(21.398)+(0.041)+(79.168)))+(0.1)+(0.1)+(0.1)+(64.597))/((0.1)+(48.846)));

} else {
	tcb->m_segmentSize = (int) (65.673+(tcb->m_segmentSize)+(-95.474)+(IYcBflYMTeMONEzZ));

}
yOCixuvkzgNnCSqx = (float) (-47.835+(-22.893)+(48.708)+(-49.637)+(-19.32)+(23.656)+(-33.422)+(-70.541));
yOCixuvkzgNnCSqx = (float) (10.211+(33.703)+(26.267)+(24.515)+(34.591)+(-32.118)+(39.214)+(36.912));
