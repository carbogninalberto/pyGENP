float oxmpmZdNTZiVPiAi = (float) (16.374-(67.374));
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_segmentSize = (int) (55.243*(79.333));

} else {
	tcb->m_segmentSize = (int) (8.526-(8.331)-(36.721));

}
if (segmentsAcked > segmentsAcked) {
	segmentsAcked = (int) (0.1/40.69);
	segmentsAcked = (int) (49.876-(63.954)-(83.186)-(14.985)-(46.63));

} else {
	segmentsAcked = (int) (71.929-(segmentsAcked)-(29.844));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (0.1/0.1);
if (segmentsAcked >= oxmpmZdNTZiVPiAi) {
	segmentsAcked = (int) (85.151+(58.856)+(71.374)+(tcb->m_cWnd)+(15.564)+(oxmpmZdNTZiVPiAi)+(46.217));

} else {
	segmentsAcked = (int) (74.415*(94.106)*(74.319)*(98.815)*(11.537)*(25.005)*(segmentsAcked));

}
oxmpmZdNTZiVPiAi = (float) (63.351+(oxmpmZdNTZiVPiAi)+(98.008)+(3.202)+(45.574)+(94.143)+(66.049)+(82.516)+(oxmpmZdNTZiVPiAi));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (39.133+(53.756)+(tcb->m_cWnd)+(93.811)+(54.243));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (81.179-(23.372)-(tcb->m_segmentSize));

}
