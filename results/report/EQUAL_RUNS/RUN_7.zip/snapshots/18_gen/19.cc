ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_ssThresh = (int) (64.622-(77.703)-(51.917)-(48.311));
	tcb->m_ssThresh = (int) (65.558+(83.471));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(94.027)*(segmentsAcked)*(27.268)*(13.573)*(tcb->m_segmentSize)*(93.925)*(58.258));

} else {
	tcb->m_ssThresh = (int) (58.56+(34.512)+(66.729)+(31.248));

}
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (60.459*(tcb->m_cWnd)*(7.167)*(54.584));
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(72.847)+(0.1)+(71.515))/((13.89)+(0.1)+(0.1)+(45.801)));

} else {
	segmentsAcked = (int) (41.551-(80.309)-(89.018));

}
