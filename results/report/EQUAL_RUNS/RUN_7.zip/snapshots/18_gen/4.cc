float yOCixuvkzgNnCSqx = (float) (-78.583+(-90.788)+(-49.261)+(9.947)+(-40.721)+(-16.251)+(-9.0));
int IYcBflYMTeMONEzZ = (int) (-86.405*(-13.72)*(-29.075)*(-75.132)*(-51.031)*(-95.773));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
yOCixuvkzgNnCSqx = (float) (-72.178+(-63.034)+(-14.162)+(-19.51)+(33.992)+(53.185)+(56.575)+(-0.804));
ReduceCwnd (tcb);
