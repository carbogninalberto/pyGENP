int YIFiGaTkyIICwFtj = (int) (34.958-(-71.963)-(8.023)-(-69.898)-(74.626)-(65.834)-(34.839));
segmentsAcked = (int) (-21.93-(-17.522)-(-51.189)-(-17.257)-(29.973)-(79.915));
int HmwjbecshWSaQxKd = (int) 40.293;
segmentsAcked = SlowStart (tcb, segmentsAcked);
