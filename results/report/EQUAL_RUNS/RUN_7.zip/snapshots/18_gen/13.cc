CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (21.175+(32.202));
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_segmentSize) {
	segmentsAcked = (int) (22.129+(73.644)+(0.778)+(90.246)+(94.344)+(24.746)+(93.273));

} else {
	segmentsAcked = (int) (49.101+(12.404)+(61.028)+(94.224));
	tcb->m_cWnd = (int) (8.929*(93.382)*(16.948)*(85.844));
	CongestionAvoidance (tcb, segmentsAcked);

}
