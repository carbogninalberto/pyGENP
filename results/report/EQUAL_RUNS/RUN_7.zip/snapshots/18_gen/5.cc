TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int HmwjbecshWSaQxKd = (int) 78.19;
HmwjbecshWSaQxKd = (int) (37.852-(63.398)-(37.707)-(76.684)-(-95.213)-(-31.758));
segmentsAcked = (int) (25.31-(28.891)-(98.948)-(24.126)-(-53.77)-(-72.2));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (80.613-(27.451)-(97.443)-(2.598)-(31.361)-(-75.859));
segmentsAcked = SlowStart (tcb, segmentsAcked);
