segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (48.128+(64.9));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (59.135+(19.6));
segmentsAcked = (int) (-95.214+(-4.487));
segmentsAcked = (int) (-66.262+(-66.125));
