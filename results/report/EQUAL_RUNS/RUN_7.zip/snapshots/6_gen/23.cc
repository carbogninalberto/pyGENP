TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-80.029+(-34.238));
segmentsAcked = (int) (93.802+(-46.064));
segmentsAcked = (int) (66.067+(-24.74));
