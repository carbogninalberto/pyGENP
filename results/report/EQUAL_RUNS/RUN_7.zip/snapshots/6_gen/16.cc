ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-68.753*(-11.775)*(-42.107)*(-77.563)*(9.323)*(50.904)*(-51.016)*(-23.065)*(36.999));
tcb->m_cWnd = (int) (-68.673*(32.462)*(-62.381)*(-27.081)*(97.398)*(-24.387)*(-20.388)*(-16.433)*(30.24));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
