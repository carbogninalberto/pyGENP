TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (27.543+(12.619));
segmentsAcked = (int) (-41.551+(46.315));
segmentsAcked = (int) (51.204+(-28.649));
segmentsAcked = (int) (-73.229+(-4.353));
