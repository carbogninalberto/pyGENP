TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (70.935+(51.976)+(-74.015)+(50.249)+(62.775)+(-57.564)+(33.326)+(67.385)+(22.209));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
