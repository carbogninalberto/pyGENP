ReduceCwnd (tcb);
segmentsAcked = (int) (46.499*(-13.119)*(-33.995)*(-25.456)*(-72.965));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-48.366*(-10.983)*(23.606)*(21.027)*(-63.084)*(11.601)*(43.094)*(-2.495)*(97.416));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
