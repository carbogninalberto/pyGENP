TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-32.371*(-84.501)*(70.64)*(-19.24)*(35.667));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (23.927*(24.491)*(75.127)*(-10.392)*(-42.704)*(84.615)*(-34.22)*(-2.24)*(20.371));
