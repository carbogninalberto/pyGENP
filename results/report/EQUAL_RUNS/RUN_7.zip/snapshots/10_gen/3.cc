int CcAxxTbCxMQypsvH = (int) 17.629;
