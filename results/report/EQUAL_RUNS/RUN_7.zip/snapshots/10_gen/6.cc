ReduceCwnd (tcb);
float ShYzryZQkWxCdupY = (float) (-13.134/-99.879);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (97.602*(-80.84)*(30.106)*(-22.553)*(72.153));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
