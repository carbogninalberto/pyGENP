segmentsAcked = (int) (-40.349-(-40.869)-(76.535)-(74.227)-(57.64)-(14.617));
segmentsAcked = (int) (-95.626/-47.732);
segmentsAcked = (int) (-12.367-(-6.307)-(-82.972)-(7.586)-(5.975));
segmentsAcked = (int) (1.549/21.798);
CongestionAvoidance (tcb, segmentsAcked);
