ReduceCwnd (tcb);
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (78.872-(97.414)-(22.688));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (11.042*(13.849)*(60.091)*(66.871)*(87.215)*(98.717));

} else {
	tcb->m_cWnd = (int) (77.556-(18.216)-(46.332));

}
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+(95.693)+(0.1)+((23.395*(56.197)*(2.461)*(40.112)*(segmentsAcked)*(20.851)))+(20.517))/((0.1)));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) ((62.514-(96.493)-(27.66))/0.1);

} else {
	tcb->m_segmentSize = (int) (segmentsAcked+(5.212)+(30.061)+(60.122));
	tcb->m_segmentSize = (int) (3.53*(97.87)*(60.071)*(tcb->m_cWnd)*(63.156)*(25.839)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(10.407));
	tcb->m_cWnd = (int) (84.511*(67.3)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(14.188)*(3.294)*(50.165)*(tcb->m_cWnd)*(40.244));

}
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (74.181+(31.671)+(5.588)+(12.999)+(81.766)+(18.396));
	segmentsAcked = (int) (5.74+(38.749)+(98.482)+(23.633)+(84.642)+(12.297));

} else {
	tcb->m_ssThresh = (int) (((0.1)+(78.335)+(0.1)+(65.167)+(0.1)+(74.343))/((13.821)+(8.804)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (93.43+(83.73)+(79.756)+(37.119)+(14.028)+(tcb->m_cWnd)+(29.004)+(79.983));

}
tcb->m_segmentSize = (int) (98.361-(segmentsAcked)-(91.827)-(57.119)-(27.552)-(41.279)-(56.311)-(8.078));
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_ssThresh = (int) (85.531*(56.964)*(88.119)*(49.762)*(86.112)*(78.715)*(tcb->m_segmentSize));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(72.358)-(32.506)-(61.904)-(31.519));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (40.441-(89.226)-(60.473)-(tcb->m_segmentSize)-(1.085)-(97.309)-(87.223)-(10.654)-(49.448));
CongestionAvoidance (tcb, segmentsAcked);
