if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (30.449*(53.957)*(92.902)*(34.959)*(26.995));
	tcb->m_ssThresh = (int) (92.156-(44.681)-(44.016));

} else {
	tcb->m_segmentSize = (int) (32.458/35.622);

}
tcb->m_cWnd = (int) (tcb->m_cWnd-(tcb->m_ssThresh)-(49.772)-(15.332));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
