tcb->m_ssThresh = (int) (tcb->m_ssThresh-(14.988)-(tcb->m_ssThresh));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (44.715*(5.589)*(46.842)*(47.137)*(55.203));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (24.444*(87.438));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(85.626));

}
ReduceCwnd (tcb);
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(42.597)-(92.385)-(73.145)-(67.657));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
