segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (85.748-(51.441)-(40.71)-(-27.413));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	segmentsAcked = (int) ((40.311-(47.294)-(74.593)-(segmentsAcked))/0.1);
	tcb->m_cWnd = (int) ((tcb->m_cWnd-(2.055)-(tcb->m_segmentSize)-(98.329)-(37.554))/16.33);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (14.85-(tcb->m_cWnd)-(83.71));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
