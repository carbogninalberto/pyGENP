tcb->m_cWnd = (int) (-38.045/74.176);
segmentsAcked = (int) (6.887*(-54.433)*(-92.75)*(98.744)*(69.657));
ReduceCwnd (tcb);
