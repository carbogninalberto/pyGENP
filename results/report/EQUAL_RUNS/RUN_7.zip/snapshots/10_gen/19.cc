if (segmentsAcked >= tcb->m_ssThresh) {
	segmentsAcked = (int) (14.07+(14.308)+(86.477)+(tcb->m_ssThresh)+(30.402)+(98.835)+(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (98.699*(17.586)*(46.607)*(98.167));
	ReduceCwnd (tcb);
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (86.101*(55.406)*(segmentsAcked)*(21.815));
	segmentsAcked = (int) (61.52-(42.187)-(71.76)-(tcb->m_segmentSize)-(30.988)-(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (28.689+(tcb->m_cWnd)+(17.603)+(67.973)+(29.538));
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(44.476)+(76.46)+(69.031)+(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (59.147/0.1);

}
tcb->m_segmentSize = (int) (97.236+(31.606)+(tcb->m_cWnd)+(72.77)+(tcb->m_segmentSize)+(41.964)+(36.503)+(78.236));
