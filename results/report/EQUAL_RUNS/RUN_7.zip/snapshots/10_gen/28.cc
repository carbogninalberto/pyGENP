TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (1.294*(20.208)*(tcb->m_ssThresh)*(43.273));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (68.138*(tcb->m_segmentSize)*(tcb->m_cWnd)*(77.217)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(36.023)*(7.839)*(5.486));

}
if (tcb->m_ssThresh > segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(99.69)+(61.106)+(96.113)+(64.42)+(88.585)+(segmentsAcked));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (97.938+(62.292)+(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_cWnd-(67.082)-(64.471)-(9.849)-(segmentsAcked)-(45.217)-(89.985)-(tcb->m_ssThresh)-(tcb->m_segmentSize));
