if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (88.874-(65.331)-(9.697)-(14.807)-(14.331)-(38.944));

} else {
	tcb->m_cWnd = (int) (37.663-(25.71)-(54.038)-(segmentsAcked)-(34.174)-(11.324)-(46.0));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (38.734-(61.245)-(36.194)-(10.885)-(32.327)-(77.365)-(72.952)-(55.656));
tcb->m_cWnd = (int) (94.503/0.1);
segmentsAcked = (int) (23.602-(49.852)-(6.269)-(6.466));
