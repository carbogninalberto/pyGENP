float VamXXctGLiJUztQt = (float) (44.727*(-80.26));
