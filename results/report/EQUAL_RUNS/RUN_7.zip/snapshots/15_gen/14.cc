segmentsAcked = (int) (17.404/-28.06);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (53.256+(41.413)+(-77.971)+(37.938)+(77.51)+(98.42)+(15.132)+(85.625));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) ((72.952+(tcb->m_segmentSize)+(segmentsAcked)+(70.257)+(tcb->m_segmentSize)+(83.272)+(tcb->m_segmentSize))/29.542);
	segmentsAcked = (int) (0.1/6.657);

}
segmentsAcked = (int) (82.66/29.891);
