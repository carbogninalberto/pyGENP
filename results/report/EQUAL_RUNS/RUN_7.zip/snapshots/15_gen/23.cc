segmentsAcked = (int) (38.909*(70.876)*(16.923)*(84.123)*(79.922)*(36.442)*(tcb->m_ssThresh)*(69.113)*(68.87));
float SlhNvkOfMncVTHbd = (float) (0.1/7.944);
tcb->m_cWnd = (int) (43.096*(46.81)*(11.384)*(93.326)*(66.321)*(87.172));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (SlhNvkOfMncVTHbd*(58.44)*(tcb->m_segmentSize)*(39.857)*(32.719)*(85.622));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (22.57*(tcb->m_ssThresh)*(11.081)*(96.252));
