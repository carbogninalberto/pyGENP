TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-67.818+(-0.982));
segmentsAcked = (int) (6.206+(-7.918));
segmentsAcked = (int) (-65.818+(38.06));
segmentsAcked = (int) (25.947+(-61.338));
segmentsAcked = (int) (47.399+(-7.916));
segmentsAcked = (int) (61.376+(41.127));
