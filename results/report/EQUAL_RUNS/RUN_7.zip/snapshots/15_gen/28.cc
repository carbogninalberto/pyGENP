tcb->m_cWnd = (int) (0.1/99.759);
tcb->m_ssThresh = (int) (44.337+(64.816)+(97.665)+(86.887)+(84.742)+(62.575));
segmentsAcked = (int) (96.083/61.566);
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(7.543)+(47.657));
tcb->m_segmentSize = (int) (66.953*(61.271));
ReduceCwnd (tcb);
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+((6.326*(91.814)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(66.849)*(tcb->m_ssThresh)*(81.037)*(95.244)*(61.458)))+(92.888)+(0.1)+(16.844)+(0.1))/((75.306)+(66.215)));
	tcb->m_cWnd = (int) (69.798/0.1);

} else {
	tcb->m_segmentSize = (int) (60.729*(tcb->m_ssThresh)*(65.318)*(14.621)*(tcb->m_ssThresh)*(segmentsAcked));
	tcb->m_cWnd = (int) (17.277-(58.813)-(41.452)-(segmentsAcked)-(80.345)-(75.802)-(tcb->m_segmentSize));

}
segmentsAcked = (int) (92.897/86.614);
