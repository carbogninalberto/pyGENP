if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (24.147-(43.393)-(4.665)-(26.845)-(2.88)-(74.363));
	tcb->m_segmentSize = (int) (0.933+(74.043)+(segmentsAcked)+(87.371)+(segmentsAcked)+(33.603)+(74.995)+(tcb->m_segmentSize)+(21.422));

} else {
	tcb->m_cWnd = (int) (7.371+(1.689)+(6.98)+(53.619)+(52.448)+(86.613)+(18.566));
	segmentsAcked = (int) (((65.848)+(65.875)+((86.415*(21.787)*(tcb->m_ssThresh)))+(0.1)+(55.915)+(0.1))/((0.1)+(22.943)));
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (53.256+(41.413)+(-51.341)+(-35.279)+(-97.294)+(98.42)+(15.132)+(85.625));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) ((72.952+(tcb->m_segmentSize)+(segmentsAcked)+(70.257)+(tcb->m_segmentSize)+(83.272)+(tcb->m_segmentSize))/29.542);
	segmentsAcked = (int) (0.1/6.657);

}
segmentsAcked = (int) (-15.467/7.799);
