tcb->m_segmentSize = (int) (((75.722)+(64.869)+((6.399*(5.536)*(tcb->m_segmentSize)*(21.346)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(96.417)))+(7.419)+(0.1)+(0.1)+(28.768))/((0.1)+(0.1)));
tcb->m_ssThresh = (int) (tcb->m_cWnd-(3.874)-(60.235)-(92.883)-(99.2)-(89.649)-(27.068)-(segmentsAcked));
tcb->m_ssThresh = (int) (59.468-(94.748)-(62.13)-(49.695)-(3.315)-(segmentsAcked)-(1.757));
tcb->m_ssThresh = (int) (54.381-(43.108)-(43.748)-(tcb->m_segmentSize)-(segmentsAcked)-(71.849)-(tcb->m_ssThresh)-(85.096));
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (0.858-(tcb->m_ssThresh)-(39.833)-(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(segmentsAcked)-(tcb->m_segmentSize)-(65.393)-(87.416)-(22.674)-(tcb->m_segmentSize)-(72.327)-(52.598));

}
segmentsAcked = (int) (31.689-(segmentsAcked)-(3.865)-(27.064)-(59.151)-(67.452));
