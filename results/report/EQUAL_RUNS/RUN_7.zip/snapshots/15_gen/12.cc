tcb->m_cWnd = (int) (37.56*(38.618));
segmentsAcked = (int) (29.391-(88.103)-(81.716)-(92.828)-(21.258));
segmentsAcked = (int) (-46.621/-51.888);
