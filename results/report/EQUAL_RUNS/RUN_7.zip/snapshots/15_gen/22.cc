if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(50.521)*(tcb->m_ssThresh)*(5.78)*(51.087)*(39.915)*(75.752));
	tcb->m_ssThresh = (int) (13.189*(45.828)*(68.057)*(86.437)*(95.085)*(59.093)*(43.983));

} else {
	tcb->m_ssThresh = (int) (70.392*(22.839)*(78.198)*(40.997)*(5.254)*(38.713)*(15.103));
	segmentsAcked = (int) (97.182-(54.464)-(50.762)-(20.677)-(96.839)-(69.751)-(tcb->m_cWnd)-(94.143)-(38.091));
	tcb->m_cWnd = (int) (55.03/17.831);

}
if (segmentsAcked == tcb->m_cWnd) {
	segmentsAcked = (int) (89.027+(75.873)+(89.953)+(18.782)+(48.861));
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(43.909)-(12.184)-(29.417));
	tcb->m_cWnd = (int) (85.413+(32.601)+(tcb->m_ssThresh)+(2.567)+(12.96)+(74.599)+(44.65)+(74.469)+(76.18));

} else {
	segmentsAcked = (int) (0.1/0.1);

}
tcb->m_cWnd = (int) (32.992*(33.699)*(92.433)*(52.974));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
