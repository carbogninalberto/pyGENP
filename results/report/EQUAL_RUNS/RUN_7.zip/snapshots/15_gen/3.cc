TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-5.422+(-64.683));
segmentsAcked = (int) (60.677+(50.218));
segmentsAcked = (int) (46.886+(9.727));
segmentsAcked = (int) (-78.643+(39.416));
segmentsAcked = (int) (58.323+(-35.43));
segmentsAcked = (int) (31.503+(35.691));
segmentsAcked = (int) (-3.124+(-64.309));
