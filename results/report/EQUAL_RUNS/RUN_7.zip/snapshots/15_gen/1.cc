TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (14.385+(-62.424));
segmentsAcked = (int) (25.379+(-77.769));
segmentsAcked = (int) (58.577+(-82.277));
segmentsAcked = (int) (-96.089+(-32.295));
segmentsAcked = (int) (32.827+(6.523));
