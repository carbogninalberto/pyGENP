ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-4.586+(93.77)+(25.135)+(-33.503)+(-98.192)+(-30.662)+(-57.932)+(-73.509));
