int AVsNCSfNVWrhXYBs = (int) (19.945-(75.262));
float zhWAdDUJJEVfeKdt = (float) (75.498-(63.99)-(-24.452)-(-58.128)-(-51.857)-(-16.874)-(43.557)-(60.143));
