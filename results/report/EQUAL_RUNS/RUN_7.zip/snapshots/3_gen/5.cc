float PavqilsHUWmFqlsw = (float) (-22.346-(-51.936)-(17.591)-(84.074)-(94.026)-(-28.273)-(-12.952)-(61.473));
float xfFLFpinwDwfAzMJ = (float) (-23.465/-14.557);
