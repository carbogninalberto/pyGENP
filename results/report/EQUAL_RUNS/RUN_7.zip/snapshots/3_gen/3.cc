segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (83.973+(36.872));
segmentsAcked = (int) (38.746+(-3.915));
