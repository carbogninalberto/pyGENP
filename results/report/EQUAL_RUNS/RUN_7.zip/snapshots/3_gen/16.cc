float diijVQJykFAMPayc = (float) 9.151;
int geRQPScMBQrpeanB = (int) (-22.503+(-51.737)+(47.574)+(-0.364)+(97.54));
diijVQJykFAMPayc = (float) (-56.293-(78.274)-(-12.982)-(-30.968)-(-67.315));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-88.96+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-88.96+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
diijVQJykFAMPayc = (float) (46.309*(-9.638)*(-12.044)*(-98.987)*(-26.016)*(11.526)*(45.977)*(-63.459));
diijVQJykFAMPayc = (float) (30.436*(19.068)*(14.808)*(89.56)*(-75.917)*(76.283)*(-78.432)*(-48.985));
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-71.049+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-71.049+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
