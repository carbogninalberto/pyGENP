TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-45.803*(-23.463)*(54.827)*(30.072)*(-56.332)*(96.548)*(21.819)*(-2.192)*(60.183));
CongestionAvoidance (tcb, segmentsAcked);
