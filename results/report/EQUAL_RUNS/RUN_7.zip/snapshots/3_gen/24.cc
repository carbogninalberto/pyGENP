float iuRQqyUUVnRGBOEc = (float) (40.921+(27.413)+(98.2)+(29.563)+(-48.694)+(98.555));
ReduceCwnd (tcb);
int nMBtmWlgKSTrxxUg = (int) (9.206+(-30.319)+(90.034)+(-69.669)+(-65.911));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
