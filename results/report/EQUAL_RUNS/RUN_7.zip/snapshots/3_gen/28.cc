if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (30.439-(2.376)-(72.327)-(12.195)-(tcb->m_cWnd)-(38.915)-(segmentsAcked));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (75.787*(40.24)*(64.821));
	segmentsAcked = (int) (99.103+(7.928)+(23.417)+(53.973)+(69.395));
	tcb->m_segmentSize = (int) (10.225*(70.775)*(4.485)*(47.356)*(43.192)*(17.068));

}
