int osiUAhosoBUHFrwS = (int) (79.185+(38.493)+(46.453)+(-35.299));
ReduceCwnd (tcb);
segmentsAcked = (int) (61.188+(-90.302));
