int oBiivAQNuONZcFcY = (int) (23.631*(56.465)*(31.509)*(-11.459));
