float diijVQJykFAMPayc = (float) 9.151;
int geRQPScMBQrpeanB = (int) -0.025;
ReduceCwnd (tcb);
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

} else {
	segmentsAcked = (int) (-88.96+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

}
diijVQJykFAMPayc = (float) (86.111*(-62.631)*(-79.521)*(-20.181)*(-36.494)*(23.803)*(-81.783)*(2.544));
if (tcb->m_segmentSize > diijVQJykFAMPayc) {
	segmentsAcked = (int) (-71.049+(52.552)+(segmentsAcked)+(41.896));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (55.886*(44.939)*(20.302)*(25.546)*(3.202)*(tcb->m_segmentSize)*(22.244)*(36.472));
	diijVQJykFAMPayc = (float) (1.052*(18.933)*(21.653)*(11.198));
	tcb->m_cWnd = (int) (0.1/23.915);

}
