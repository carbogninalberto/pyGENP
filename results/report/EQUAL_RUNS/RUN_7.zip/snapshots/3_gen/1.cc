int INcKZzRggSeVTjeC = (int) 66.354;
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (6.35+(-34.245)+(23.649)+(-88.231)+(-47.168)+(-38.614)+(-82.864)+(-40.857)+(17.527));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
