tcb->m_segmentSize = (int) (65.084*(57.947)*(34.926)*(-93.002)*(-94.795)*(-93.466)*(33.025));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-18.782*(58.747)*(31.929));
