tcb->m_segmentSize = (int) (-50.102*(66.315)*(37.542)*(13.328)*(-49.036));
segmentsAcked = (int) (16.173+(-13.368)+(89.235)+(48.391)+(56.422)+(-92.343)+(74.026)+(44.754)+(-5.126));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (81.953+(-56.108)+(84.582)+(-91.507)+(-83.885)+(-52.223)+(-51.556)+(0.535)+(-88.274));
