int gAkxWjuQWiUOXpum = (int) (-14.593-(47.902)-(-28.659)-(94.689));
