int vkQpjKqUbMmoqFNY = (int) (-16.584-(-51.84));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-89.164*(-86.025)*(76.326)*(-25.347)*(17.01)*(4.101)*(38.997)*(88.598)*(-21.332));
tcb->m_cWnd = (int) (-87.185*(-93.176)*(96.74)*(19.295)*(18.615)*(-62.178)*(6.751)*(-84.811)*(79.928));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
