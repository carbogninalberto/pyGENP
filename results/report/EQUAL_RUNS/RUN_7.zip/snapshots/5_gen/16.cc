tcb->m_segmentSize = (int) (28.2-(80.79)-(-19.863)-(47.743)-(47.053)-(51.624)-(-31.092));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (49.958*(-59.301)*(-17.01)*(-26.67)*(-49.876)*(99.153)*(56.35));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-10.749*(53.323)*(-9.962));
tcb->m_segmentSize = (int) (-61.86*(1.246)*(56.931)*(-36.197)*(79.183)*(28.494)*(28.077));
