segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-93.501+(-74.772));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-27.729+(50.674));
segmentsAcked = (int) (-1.67+(72.277));
segmentsAcked = (int) (61.099+(93.141));
