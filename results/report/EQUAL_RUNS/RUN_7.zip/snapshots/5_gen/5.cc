tcb->m_cWnd = (int) (-57.721/40.462);
int oCRGVsyLtcbtsnVW = (int) 97.871;
if (segmentsAcked != tcb->m_cWnd) {
	segmentsAcked = (int) (4.932*(oCRGVsyLtcbtsnVW)*(5.119)*(30.994)*(77.192)*(47.67)*(18.666));
	segmentsAcked = (int) (69.349+(80.874)+(63.469)+(18.616)+(24.479)+(67.395)+(42.399)+(58.284)+(12.72));

} else {
	segmentsAcked = (int) (7.493+(60.026)+(36.552)+(96.035));

}
oCRGVsyLtcbtsnVW = (int) (53.584-(63.856));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (25.149+(6.768)+(3.032)+(75.443)+(33.464)+(55.751)+(tcb->m_cWnd)+(88.148)+(50.582));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (38.712+(21.778)+(63.602)+(tcb->m_cWnd)+(91.037)+(44.146)+(70.598)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (18.94-(11.637));

}
