if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (91.504+(53.022)+(23.943)+(segmentsAcked)+(15.59)+(20.804));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(94.1)+(40.225)+(10.425));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (63.147-(73.828)-(8.479)-(74.514));
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((5.099)+(10.557)+(29.13)+(0.1))/((31.572)+(47.6)+(0.1)));
	segmentsAcked = (int) (0.1/0.1);
	segmentsAcked = (int) (69.188*(3.303)*(19.228)*(67.13)*(9.138)*(20.374)*(73.4));

} else {
	tcb->m_ssThresh = (int) ((51.425-(tcb->m_segmentSize)-(18.668)-(22.503)-(81.759)-(15.272))/0.1);
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
