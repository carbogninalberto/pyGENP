if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_segmentSize = (int) ((45.31*(36.102)*(39.407)*(30.873)*(35.784)*(13.163)*(75.661))/49.881);
	segmentsAcked = (int) (((0.1)+((segmentsAcked-(8.617)-(46.794)-(tcb->m_cWnd)))+(31.406)+(7.021))/((0.1)+(0.1)+(46.494)+(0.1)+(0.1)));
	tcb->m_segmentSize = (int) (11.569*(54.437));

} else {
	tcb->m_segmentSize = (int) (61.858+(74.023)+(99.682)+(74.531)+(tcb->m_segmentSize)+(56.016));
	ReduceCwnd (tcb);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
