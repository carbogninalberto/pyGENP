float VueYCZyCHSwxJrxP = (float) (segmentsAcked*(65.114)*(tcb->m_segmentSize)*(14.776)*(33.079));
ReduceCwnd (tcb);
if (VueYCZyCHSwxJrxP < VueYCZyCHSwxJrxP) {
	tcb->m_ssThresh = (int) (((6.407)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(98.467)+(0.1)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) ((69.191*(52.95)*(-0.056)*(6.575)*(95.751)*(26.775)*(tcb->m_ssThresh)*(84.331))/(18.755*(16.744)*(74.791)*(31.049)*(74.505)*(81.932)));
	VueYCZyCHSwxJrxP = (float) ((76.513*(91.269)*(32.992)*(27.986)*(68.317))/0.1);

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (18.514*(21.604)*(50.182));
