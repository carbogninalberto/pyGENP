TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (47.79*(46.747)*(6.967)*(14.377)*(segmentsAcked)*(37.633)*(tcb->m_segmentSize)*(64.017)*(73.083));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	segmentsAcked = (int) (71.797-(60.512)-(74.293)-(89.046)-(82.456)-(35.313));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (67.167*(92.961)*(4.301)*(11.852)*(85.011)*(tcb->m_ssThresh)*(98.49)*(87.62));

} else {
	segmentsAcked = (int) (51.739-(75.087)-(26.72)-(8.489)-(tcb->m_segmentSize)-(53.839)-(92.904)-(80.968));
	tcb->m_cWnd = (int) (45.927+(83.984)+(tcb->m_ssThresh)+(89.523)+(tcb->m_ssThresh));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (41.572-(5.717)-(segmentsAcked)-(1.205)-(22.886)-(7.166)-(5.979)-(49.203));
