ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-32.233+(-86.741)+(-51.038)+(49.199)+(20.727)+(60.112)+(-54.657)+(-37.74));
tcb->m_segmentSize = (int) (40.597+(-73.141)+(54.743)+(17.124)+(82.443)+(-54.612)+(89.544)+(-63.783));
