segmentsAcked = (int) (67.712-(71.588)-(36.253));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (56.445+(57.748)+(0.348)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(81.486)+(tcb->m_cWnd)+(38.605));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (26.208+(77.945)+(54.767)+(segmentsAcked)+(84.328)+(94.324));
tcb->m_cWnd = (int) (39.007+(tcb->m_cWnd)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(77.979));
