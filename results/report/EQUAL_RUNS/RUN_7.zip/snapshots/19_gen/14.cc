if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (35.518-(17.773)-(17.373)-(55.758));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(tcb->m_ssThresh)*(99.459)*(42.094));

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (53.553-(66.13)-(62.125)-(50.977)-(91.029)-(76.476)-(65.659)-(tcb->m_ssThresh)-(79.937));
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (87.669/49.874);

} else {
	tcb->m_segmentSize = (int) (32.448-(tcb->m_ssThresh)-(47.118)-(99.983)-(28.225)-(31.197)-(tcb->m_cWnd)-(99.337)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (52.413-(88.283)-(tcb->m_ssThresh)-(92.352));
	tcb->m_ssThresh = (int) (98.179/5.471);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (60.472/0.1);
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (54.581+(14.712)+(6.883)+(62.557)+(6.517));
	tcb->m_ssThresh = (int) (10.914+(36.529)+(5.408));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(53.396)+(45.77)+(91.283)+(segmentsAcked)+(93.016)+(67.521)+(8.866)+(32.263));
	tcb->m_cWnd = (int) (60.038*(96.209)*(71.096)*(49.099)*(90.594)*(segmentsAcked));

}
