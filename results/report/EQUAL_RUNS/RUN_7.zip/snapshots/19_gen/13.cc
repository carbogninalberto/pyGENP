segmentsAcked = (int) (27.092*(54.305)*(93.116)*(82.058)*(26.848)*(46.105)*(64.086)*(tcb->m_cWnd)*(tcb->m_ssThresh));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (44.814-(tcb->m_ssThresh));
tcb->m_segmentSize = (int) (39.951-(2.865)-(4.931)-(22.894)-(29.023)-(19.567)-(87.973)-(25.553));
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (45.332+(segmentsAcked)+(16.936)+(3.733)+(79.212));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (segmentsAcked-(tcb->m_segmentSize)-(42.175)-(96.26)-(77.748)-(57.0));

} else {
	tcb->m_ssThresh = (int) (0.1/19.077);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
