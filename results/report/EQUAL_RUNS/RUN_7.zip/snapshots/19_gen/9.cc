ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-39.272+(49.124)+(10.343)+(35.509)+(-31.538)+(53.424)+(-32.22)+(-52.742));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (57.669+(5.2)+(-45.595)+(66.376)+(89.981)+(-82.332)+(-46.818)+(25.264));
