segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (45.237+(60.271));
segmentsAcked = (int) (19.274+(28.762));
