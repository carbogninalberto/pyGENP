segmentsAcked = (int) (22.436/-57.062);
segmentsAcked = (int) (80.728+(-19.668));
segmentsAcked = (int) (-0.055+(-60.211));
