float DzoptRDoYjSzDJXc = (float) ((-66.812+(-65.892)+(-46.584)+(58.262)+(84.857)+(41.461)+(-17.001))/-86.821);
tcb->m_segmentSize = (int) (9.515/27.608);
tcb->m_segmentSize = (int) ((((-54.594-(61.029)-(34.633)-(89.915)-(-85.927)-(tcb->m_ssThresh)-(71.113)-(-8.246)))+(61.049)+(55.742)+(54.357)+(-93.754))/((-49.494)+(-3.012)));
if (DzoptRDoYjSzDJXc > DzoptRDoYjSzDJXc) {
	tcb->m_cWnd = (int) (91.504+(segmentsAcked)+(91.401)+(8.498)+(78.01)+(66.487));
	tcb->m_cWnd = (int) (74.937+(tcb->m_segmentSize)+(24.171)+(tcb->m_segmentSize)+(segmentsAcked)+(38.105)+(-92.199)+(3.978));

} else {
	tcb->m_cWnd = (int) (67.62-(72.521)-(segmentsAcked)-(DzoptRDoYjSzDJXc)-(76.204));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (68.36+(44.162)+(-79.195)+(-9.315)+(-67.078)+(64.812));
segmentsAcked = SlowStart (tcb, segmentsAcked);
