segmentsAcked = SlowStart (tcb, segmentsAcked);
float TGWKVQyeuqkBkjwG = (float) (18.184/6.883);
ReduceCwnd (tcb);
