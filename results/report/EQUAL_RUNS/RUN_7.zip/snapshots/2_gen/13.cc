float BMYjiykJPcBZgVZj = (float) (29.251-(11.733)-(26.287)-(71.361));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
