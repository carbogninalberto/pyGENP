int osiUAhosoBUHFrwS = (int) (53.174+(-14.892)+(-72.387)+(-95.088));
ReduceCwnd (tcb);
segmentsAcked = (int) (-16.403+(4.278));
