int oCRGVsyLtcbtsnVW = (int) (17.737-(-98.082)-(87.365)-(9.864)-(8.224)-(34.549));
tcb->m_segmentSize = (int) (37.144*(-55.374)*(26.962)*(-45.909)*(-2.369)*(97.172));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (25.149+(6.768)+(3.032)+(75.443)+(33.464)+(55.751)+(tcb->m_cWnd)+(88.148)+(50.582));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (38.712+(21.778)+(63.602)+(tcb->m_cWnd)+(91.037)+(44.146)+(70.598)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (18.94-(11.637));

}
