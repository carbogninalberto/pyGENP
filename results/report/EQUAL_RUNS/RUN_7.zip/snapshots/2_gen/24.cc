float BMYjiykJPcBZgVZj = (float) (-90.282-(-67.277)-(16.056)-(-61.063));
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/(17.387-(53.537)));

} else {
	tcb->m_cWnd = (int) ((tcb->m_cWnd+(tcb->m_segmentSize)+(51.943)+(tcb->m_cWnd)+(15.727))/74.506);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
