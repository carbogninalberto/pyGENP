if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(54.355)*(tcb->m_cWnd)*(tcb->m_cWnd)*(7.467)*(segmentsAcked)*(69.314)*(35.805));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (84.233+(15.171)+(25.254)+(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (segmentsAcked+(44.733)+(59.736)+(tcb->m_segmentSize)+(7.313)+(85.355)+(98.486)+(27.076)+(45.55));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (63.803/50.261);
	segmentsAcked = (int) (tcb->m_ssThresh+(91.842)+(tcb->m_cWnd)+(46.941));

} else {
	tcb->m_ssThresh = (int) (19.604-(12.334)-(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (47.691*(65.608)*(79.673)*(27.85));
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+((47.779+(42.374)+(8.298)+(51.987)+(98.889)))+(0.1))/((0.1)+(79.528)+(90.87)));

}
segmentsAcked = (int) (44.626*(52.513)*(85.555)*(8.908)*(segmentsAcked)*(74.967)*(59.936));
tcb->m_ssThresh = (int) (15.536*(tcb->m_ssThresh)*(2.31)*(24.112)*(72.751));
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (7.106*(80.061)*(14.876)*(88.111)*(85.161)*(97.742)*(1.235)*(62.298));
	tcb->m_segmentSize = (int) (((0.1)+((52.164-(48.924)-(segmentsAcked)))+((82.014*(27.379)*(91.902)*(84.345)*(59.115)*(70.707)*(segmentsAcked)*(66.613)*(tcb->m_cWnd)))+(49.825))/((0.1)+(0.1)+(0.1)+(0.1)+(40.889)));

} else {
	tcb->m_segmentSize = (int) ((91.067*(tcb->m_segmentSize))/0.1);

}
tcb->m_ssThresh = (int) (57.27*(34.74)*(segmentsAcked)*(tcb->m_segmentSize)*(98.425)*(64.636)*(38.55)*(65.519));
