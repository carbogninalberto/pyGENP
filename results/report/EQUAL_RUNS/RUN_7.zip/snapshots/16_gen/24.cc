TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (((0.1)+((tcb->m_ssThresh+(tcb->m_cWnd)))+(63.323)+(0.1))/((96.863)+(0.1)));
if (segmentsAcked < segmentsAcked) {
	tcb->m_segmentSize = (int) (38.826*(86.047)*(12.393)*(88.22)*(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (88.291*(4.648)*(90.059)*(5.871)*(tcb->m_cWnd)*(59.278)*(46.436)*(39.096));

} else {
	tcb->m_segmentSize = (int) (76.026-(5.57)-(47.603)-(59.478)-(88.67)-(segmentsAcked)-(77.49));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((((40.824+(18.006)+(15.87)+(52.519)+(47.435)))+(80.253)+(66.727)+(75.769)+(90.964)+(0.1))/((0.1)+(4.197)+(54.77)));

} else {
	tcb->m_segmentSize = (int) (93.024+(19.493)+(99.693)+(tcb->m_segmentSize)+(38.819)+(tcb->m_segmentSize)+(32.006));
	tcb->m_cWnd = (int) (80.156+(66.329)+(56.593)+(26.639)+(tcb->m_ssThresh)+(47.071)+(57.909)+(13.356));
	tcb->m_ssThresh = (int) (1.235-(91.393));

}
segmentsAcked = (int) (90.129-(tcb->m_segmentSize)-(34.68)-(tcb->m_cWnd));
CongestionAvoidance (tcb, segmentsAcked);
