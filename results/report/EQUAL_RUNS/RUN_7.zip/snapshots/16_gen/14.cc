ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) ((((84.741+(73.388)+(58.652)+(40.942)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(56.404)))+(9.155)+(12.227)+((31.947-(88.482)-(77.423)-(6.445)-(89.79)-(tcb->m_cWnd)-(56.492)-(29.521)))+(0.1)+(0.1))/((96.529)+(0.1)+(0.1)));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (67.727+(70.994)+(37.002)+(47.361)+(tcb->m_segmentSize));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (42.625*(78.56)*(26.241)*(63.213)*(tcb->m_cWnd)*(84.881)*(80.953));
CongestionAvoidance (tcb, segmentsAcked);
