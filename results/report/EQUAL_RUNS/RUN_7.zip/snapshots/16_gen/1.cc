TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (89.519+(-3.268));
segmentsAcked = (int) (98.204+(-7.113));
segmentsAcked = (int) (-51.854+(-20.586));
segmentsAcked = (int) (-7.519+(-45.534));
segmentsAcked = (int) (-50.837+(-41.568));
