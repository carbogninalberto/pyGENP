float SlhNvkOfMncVTHbd = (float) (-41.689/84.467);
tcb->m_cWnd = (int) (-46.016*(81.425));
tcb->m_cWnd = (int) (49.951*(-12.559)*(-68.254)*(-73.046)*(20.61)*(-78.23));
ReduceCwnd (tcb);
