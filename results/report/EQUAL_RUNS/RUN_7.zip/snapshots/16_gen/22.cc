CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (28.473+(21.225)+(6.021)+(28.04)+(31.354));

} else {
	segmentsAcked = (int) (((0.1)+(59.658)+(0.1)+((81.843*(segmentsAcked)))+(0.1))/((1.692)+(0.1)));

}
float hYywEosibmwqaorG = (float) (89.852-(50.462));
segmentsAcked = (int) (((87.771)+(60.802)+(0.1)+(40.997))/((0.1)));
tcb->m_cWnd = (int) (25.814-(80.817)-(62.956)-(52.316)-(87.316)-(8.368)-(42.691)-(86.997));
CongestionAvoidance (tcb, segmentsAcked);
