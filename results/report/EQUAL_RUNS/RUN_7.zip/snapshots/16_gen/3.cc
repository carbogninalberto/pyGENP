ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-79.273+(67.474)+(28.754)+(-38.865)+(62.525)+(-37.072)+(92.026)+(-75.776));
