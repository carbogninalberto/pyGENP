if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (44.424*(62.025)*(63.178));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(59.474)-(36.219)-(51.083)-(53.387)-(85.849)-(90.843)-(tcb->m_ssThresh)-(14.67));
	tcb->m_ssThresh = (int) (78.554+(7.018)+(53.133)+(66.855)+(54.182));

} else {
	tcb->m_segmentSize = (int) (((0.1)+((71.308*(tcb->m_ssThresh)))+(87.672)+(83.096)+(0.1)+(69.518))/((0.1)));
	tcb->m_segmentSize = (int) (25.538*(93.433)*(tcb->m_cWnd)*(98.32));

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (((39.277)+(29.598)+(0.1)+(64.324))/((57.969)+(0.1)+(39.657)+(3.388)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_ssThresh = (int) (81.683-(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (38.566+(19.834)+(tcb->m_segmentSize)+(33.43)+(tcb->m_segmentSize)+(88.112)+(54.737));

}
