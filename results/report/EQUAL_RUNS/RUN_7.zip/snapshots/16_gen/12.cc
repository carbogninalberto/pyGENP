tcb->m_ssThresh = (int) (30.759+(8.318));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (6.066-(64.272)-(11.17));

} else {
	tcb->m_ssThresh = (int) (57.463+(tcb->m_ssThresh)+(48.209)+(segmentsAcked)+(27.572));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
float IEPjZxswBlUMWSon = (float) (43.805*(tcb->m_cWnd)*(29.347)*(63.615)*(14.748)*(15.129)*(21.703));
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (18.568+(11.278)+(IEPjZxswBlUMWSon)+(9.753)+(20.24)+(57.378)+(19.01)+(94.91)+(1.282));

} else {
	tcb->m_ssThresh = (int) (((0.1)+((35.361*(segmentsAcked)))+((42.858-(12.972)-(74.925)))+(0.1)+(7.061))/((62.717)+(38.714)+(2.8)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (96.428-(tcb->m_ssThresh)-(97.463)-(77.319)-(tcb->m_ssThresh)-(33.438));
ReduceCwnd (tcb);
