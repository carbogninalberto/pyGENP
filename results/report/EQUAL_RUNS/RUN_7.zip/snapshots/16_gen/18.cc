segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (24.414+(78.633)+(74.906)+(tcb->m_segmentSize)+(20.143)+(97.899)+(77.896)+(segmentsAcked)+(55.54));
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (68.805-(57.732));

} else {
	segmentsAcked = (int) (55.323+(69.416)+(32.072));
	tcb->m_ssThresh = (int) (77.499+(39.352)+(44.948));

}
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	segmentsAcked = (int) (46.977-(50.421)-(tcb->m_cWnd));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (51.251+(59.438)+(23.428)+(42.923)+(41.415)+(35.096));
	segmentsAcked = (int) (tcb->m_segmentSize*(86.46)*(60.985)*(90.013)*(77.016)*(48.422)*(75.697)*(tcb->m_segmentSize)*(41.476));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = (int) (tcb->m_segmentSize*(4.986)*(84.212)*(41.519)*(87.772)*(segmentsAcked)*(61.627));
