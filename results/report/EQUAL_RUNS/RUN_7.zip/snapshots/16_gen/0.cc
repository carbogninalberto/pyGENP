ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (98.002+(80.493)+(-17.638)+(16.34)+(43.49)+(-19.148)+(32.543)+(86.207));
