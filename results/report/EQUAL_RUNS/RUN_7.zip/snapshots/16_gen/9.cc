int mfMXtqkcCUlFmTjV = (int) (75.586-(-44.966)-(55.854)-(-25.461)-(-56.301)-(36.346));
segmentsAcked = (int) (25.731/-60.959);
tcb->m_segmentSize = (int) (33.043+(85.407)+(-33.917));
tcb->m_segmentSize = (int) (3.46*(43.608));
ReduceCwnd (tcb);
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (60.729*(-15.992)*(65.318)*(14.621)*(24.378)*(segmentsAcked));
	tcb->m_cWnd = (int) (17.277-(58.813)-(41.452)-(segmentsAcked)-(80.345)-(75.802)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+((6.326*(91.814)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(66.849)*(tcb->m_ssThresh)*(81.037)*(95.244)*(61.458)))+(92.888)+(0.1)+(16.844)+(0.1))/((75.306)+(66.215)));
	tcb->m_cWnd = (int) (69.798/0.1);

}
segmentsAcked = (int) (-17.121/54.755);
