ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (52.235+(-83.627)+(-4.59)+(-88.436)+(-99.589)+(-28.603)+(-9.252)+(-22.877));
tcb->m_segmentSize = (int) (75.471+(-82.297)+(4.149)+(29.296)+(-0.224)+(-66.192)+(-77.848)+(82.34));
