CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (40.789*(tcb->m_ssThresh)*(tcb->m_segmentSize));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (9.98-(1.761)-(28.538)-(28.045)-(72.92));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
