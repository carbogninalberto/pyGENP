float tPWOYrCfUBznzxnS = (float) (26.612-(-60.924)-(62.887));
tcb->m_cWnd = (int) (-82.82*(0.715)*(-19.016)*(37.295)*(-12.312));
tcb->m_cWnd = (int) (-16.279*(-89.453)*(49.656)*(-35.34)*(11.036));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (4.452*(-50.207)*(96.453)*(-7.094)*(-9.123));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
