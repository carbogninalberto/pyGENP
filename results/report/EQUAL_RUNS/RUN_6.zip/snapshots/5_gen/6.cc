float vxNDAEUXDkbKpEVL = (float) (-15.844-(20.346)-(-86.482)-(34.911)-(14.841));
segmentsAcked = (int) (-1.552-(62.651)-(72.963));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (62.925-(30.012)-(5.881)-(81.217)-(34.748)-(96.029)-(-16.417));

}
