float MOOCydgKFUhJXJCc = (float) (-0.027+(77.227)+(segmentsAcked)+(14.982)+(57.324)+(74.781));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (99.745+(92.456)+(tcb->m_segmentSize)+(38.748)+(10.758)+(2.828));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(48.127)+(0.1)+(46.532)+(13.831)+(0.1))/((0.1)+(93.98)));

} else {
	tcb->m_cWnd = (int) (66.373*(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (42.59-(96.676)-(87.822)-(71.869)-(MOOCydgKFUhJXJCc)-(segmentsAcked)-(11.267)-(87.187)-(24.747));
	tcb->m_ssThresh = (int) (84.029+(24.525)+(tcb->m_cWnd)+(81.422)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(90.578)+(tcb->m_ssThresh)+(82.094));

}
int KFGFdCYLEsjbTwIj = (int) (53.393+(tcb->m_cWnd)+(5.069)+(38.089)+(43.176));
int vYizIqMDOolVENFa = (int) (15.292+(20.38));
CongestionAvoidance (tcb, segmentsAcked);
