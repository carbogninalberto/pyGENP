int ePoHyPrJRufhuCrh = (int) (tcb->m_ssThresh-(tcb->m_segmentSize)-(30.476)-(tcb->m_ssThresh)-(13.067)-(tcb->m_segmentSize)-(82.33)-(tcb->m_cWnd)-(64.001));
CongestionAvoidance (tcb, segmentsAcked);
int XJDJncazocoZGDly = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(13.792)+(0.1))/((0.1)+(49.315)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
