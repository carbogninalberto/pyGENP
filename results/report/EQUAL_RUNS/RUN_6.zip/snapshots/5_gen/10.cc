float tPWOYrCfUBznzxnS = (float) (50.357-(80.971)-(70.109));
tcb->m_cWnd = (int) (34.844*(86.194)*(-94.419)*(78.842)*(-97.039));
tcb->m_cWnd = (int) (10.641*(-53.606)*(-91.266)*(-53.744)*(-68.6));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
