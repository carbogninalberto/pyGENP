TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (segmentsAcked*(56.54)*(75.655)*(73.911)*(83.377)*(tcb->m_cWnd)*(76.915)*(1.657)*(82.265));

} else {
	tcb->m_ssThresh = (int) (68.204*(tcb->m_segmentSize)*(98.674)*(32.231));

}
