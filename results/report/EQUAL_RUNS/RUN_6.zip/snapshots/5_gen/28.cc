if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (97.641*(90.518)*(17.982)*(tcb->m_segmentSize)*(62.603)*(31.133)*(19.312)*(80.033));
	tcb->m_cWnd = (int) (66.683*(14.873)*(64.191)*(13.687)*(72.048)*(tcb->m_ssThresh));
	segmentsAcked = (int) (62.467*(51.144)*(11.104)*(0.091)*(72.815)*(30.675)*(11.545)*(15.914)*(14.5));

} else {
	tcb->m_ssThresh = (int) (42.777-(83.629)-(4.427)-(34.398)-(75.049)-(56.847));
	tcb->m_segmentSize = (int) (0.1/51.723);

}
segmentsAcked = (int) (2.18/90.093);
ReduceCwnd (tcb);
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_segmentSize = (int) (31.952/0.1);
	tcb->m_cWnd = (int) (18.409*(84.888)*(43.474)*(63.877)*(tcb->m_cWnd)*(54.187)*(34.809));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (41.97+(segmentsAcked)+(52.869)+(tcb->m_cWnd)+(96.656)+(43.659)+(tcb->m_ssThresh)+(9.044)+(29.241));
	tcb->m_cWnd = (int) (((0.1)+(56.748)+(0.1)+(64.132))/((8.354)+(4.674)+(20.23)));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (tcb->m_ssThresh*(70.528)*(72.813)*(57.096)*(41.266)*(6.59)*(93.62));
tcb->m_ssThresh = (int) (66.625-(29.628)-(tcb->m_cWnd)-(53.822)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(95.11));
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (96.926/0.1);
	segmentsAcked = (int) (40.175-(98.051)-(77.939)-(22.907));

} else {
	tcb->m_ssThresh = (int) (31.69/81.675);

}
if (tcb->m_cWnd <= segmentsAcked) {
	segmentsAcked = (int) (tcb->m_ssThresh*(88.237)*(49.362)*(tcb->m_cWnd)*(64.134)*(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (89.051-(92.009)-(47.044)-(45.963));
	tcb->m_segmentSize = (int) (83.24-(88.539)-(59.427)-(29.569)-(94.377)-(27.395)-(88.469));

}
