float tPWOYrCfUBznzxnS = (float) (81.516-(85.886)-(20.578));
tcb->m_cWnd = (int) (-67.638*(23.527)*(3.533)*(-60.5)*(65.385));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-27.306*(67.156)*(-32.499)*(56.02)*(-24.179));
ReduceCwnd (tcb);
