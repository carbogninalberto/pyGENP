if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (62.925-(-33.219)-(5.881)-(81.217)-(34.748)-(96.029)-(41.942));

}
float vxNDAEUXDkbKpEVL = (float) (35.065-(-63.971)-(-23.445)-(-60.431)-(24.5));
segmentsAcked = (int) (19.74-(-37.913)-(-51.984));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (62.925-(30.012)-(5.881)-(81.217)-(34.748)-(96.029)-(-16.417));

}
