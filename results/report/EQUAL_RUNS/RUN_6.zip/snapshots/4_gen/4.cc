float tPWOYrCfUBznzxnS = (float) (68.279-(-36.124)-(29.581));
tcb->m_cWnd = (int) (-13.066*(80.918)*(54.488)*(86.871)*(-65.629));
ReduceCwnd (tcb);
