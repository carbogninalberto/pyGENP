float tPWOYrCfUBznzxnS = (float) (-63.72-(-24.55)-(77.058));
tcb->m_cWnd = (int) (87.652*(-39.563)*(1.16)*(5.515)*(17.758));
ReduceCwnd (tcb);
