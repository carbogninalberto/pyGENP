float tPWOYrCfUBznzxnS = (float) (86.497-(-80.214)-(71.584));
tcb->m_cWnd = (int) (-94.589*(32.465)*(50.822)*(88.287)*(98.013));
ReduceCwnd (tcb);
