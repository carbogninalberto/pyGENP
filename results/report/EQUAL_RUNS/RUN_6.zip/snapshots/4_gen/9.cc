float tPWOYrCfUBznzxnS = (float) (58.876-(96.703)-(-81.191));
tcb->m_cWnd = (int) (-61.505*(97.333)*(-41.604)*(-84.757)*(70.142));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (32.958*(-99.426)*(86.396)*(-55.751)*(51.206));
ReduceCwnd (tcb);
