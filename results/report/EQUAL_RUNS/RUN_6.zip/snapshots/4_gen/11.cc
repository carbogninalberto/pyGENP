float tPWOYrCfUBznzxnS = (float) (28.597-(-46.718)-(-1.158));
tcb->m_cWnd = (int) (-97.766*(59.795)*(-58.1)*(13.814)*(44.856));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-21.384*(59.483)*(-77.202)*(-75.784)*(50.492));
ReduceCwnd (tcb);
