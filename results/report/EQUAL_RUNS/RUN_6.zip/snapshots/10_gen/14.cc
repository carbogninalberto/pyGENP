float tPWOYrCfUBznzxnS = (float) (56.5-(-96.236)-(68.226));
tcb->m_cWnd = (int) (93.689*(79.639)*(-86.205)*(53.051)*(46.684));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-51.871*(-27.336)*(-65.216)*(-4.881)*(-30.675));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (93.651*(66.811)*(-50.744)*(44.452)*(-60.055));
ReduceCwnd (tcb);
