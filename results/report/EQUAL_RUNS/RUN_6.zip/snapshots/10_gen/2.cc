ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
