tcb->m_segmentSize = (int) (-24.052/-96.258);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-11.164/81.774);
tcb->m_segmentSize = (int) (-14.256*(94.388)*(-32.024)*(0.303)*(22.138)*(24.713)*(18.114));
tcb->m_segmentSize = (int) (47.218-(78.878)-(56.941)-(-63.46)-(-73.594)-(96.956)-(-51.862)-(67.209)-(-95.952));
