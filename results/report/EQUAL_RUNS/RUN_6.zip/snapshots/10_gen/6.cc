float zhrlTnwaZwZlevid = (float) (-28.622/-86.484);
int RNXBKUnpezqHwtFL = (int) (-60.043-(-19.338)-(36.877)-(-51.616)-(89.142)-(44.599)-(-97.5)-(55.184));
int gqKFXwfFgpoPppvL = (int) (95.535*(-35.992));
int sPCWUpZFmDwRvIpj = (int) (((6.863)+(-35.711)+(-65.791)+(-81.022))/((33.709)));
float nREiKEvpwSpXzdrQ = (float) 52.115;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
nREiKEvpwSpXzdrQ = (float) (42.424+(-59.677)+(76.402)+(14.426)+(72.98));
