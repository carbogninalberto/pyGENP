float tPWOYrCfUBznzxnS = (float) (-2.754-(57.895)-(10.631));
tcb->m_cWnd = (int) (41.823*(9.973)*(-38.104)*(33.252)*(63.684));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (58.116*(65.61)*(81.397)*(-87.707)*(-95.113));
ReduceCwnd (tcb);
