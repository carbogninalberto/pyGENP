float qSzZgAcjIZAGdcjg = (float) 95.688;
int qvTrlZQsjHQAupwP = (int) 63.259;
