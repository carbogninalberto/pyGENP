float fnBMIrgxTUQWtCAG = (float) 58.365;
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

} else {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (-78.629-(-3.814)-(-62.104)-(-58.588)-(-61.588)-(10.39));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (37.794-(4.887)-(-83.95)-(-98.126)-(64.681)-(89.559));
segmentsAcked = (int) (87.17-(94.256)-(-17.799)-(-57.971)-(-93.596)-(82.842));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (34.738-(51.69)-(-63.244)-(-38.282)-(-78.94)-(61.512));
segmentsAcked = (int) (66.395-(-87.861)-(-54.962)-(12.986)-(-32.722)-(82.216));
segmentsAcked = (int) (6.515-(19.863)-(-26.31)-(63.248)-(83.009)-(35.73));
segmentsAcked = (int) (30.975-(-52.882)-(-71.052)-(51.343)-(93.291)-(-8.096));
segmentsAcked = (int) (-33.573-(18.85)-(76.648)-(-53.376)-(36.874)-(-16.155));
