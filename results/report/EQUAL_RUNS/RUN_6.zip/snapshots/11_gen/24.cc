if (tcb->m_ssThresh != segmentsAcked) {
	segmentsAcked = (int) (tcb->m_cWnd*(2.834));
	tcb->m_cWnd = (int) (tcb->m_cWnd*(32.134)*(tcb->m_cWnd)*(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (77.401/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (26.895+(95.904)+(81.702)+(54.535)+(69.581));
tcb->m_cWnd = (int) (22.774/42.633);
segmentsAcked = (int) (18.098/86.872);
tcb->m_ssThresh = (int) (tcb->m_segmentSize*(60.042)*(39.276)*(84.955));
