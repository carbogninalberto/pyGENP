if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (24.819/0.1);
	tcb->m_ssThresh = (int) (segmentsAcked*(92.216)*(13.55));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (44.83*(tcb->m_segmentSize)*(43.417));

}
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((0.1)+((16.069-(98.47)))+(0.1)+(96.371)+(0.1))/((0.1)+(0.1)+(24.355)+(4.557)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (segmentsAcked+(95.961));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(24.195)-(77.567)-(25.856)-(27.339)-(31.92)-(71.383)-(tcb->m_segmentSize)-(59.219));

}
int pJvLpEpiXfsAxOob = (int) (6.255+(segmentsAcked)+(31.597));
if (pJvLpEpiXfsAxOob <= pJvLpEpiXfsAxOob) {
	segmentsAcked = (int) (9.624*(29.958)*(77.275)*(11.068));
	segmentsAcked = (int) (28.705-(21.867)-(10.171)-(7.109)-(47.033)-(7.782)-(22.883));
	tcb->m_segmentSize = (int) (86.149-(42.973));

} else {
	segmentsAcked = (int) (tcb->m_cWnd*(89.317)*(31.836)*(10.457)*(61.154));
	tcb->m_segmentSize = (int) ((segmentsAcked-(tcb->m_segmentSize))/5.311);
	tcb->m_ssThresh = (int) (pJvLpEpiXfsAxOob+(40.845));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
