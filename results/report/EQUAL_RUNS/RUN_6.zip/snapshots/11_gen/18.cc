float fnBMIrgxTUQWtCAG = (float) 58.365;
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

} else {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (-43.58-(58.973)-(-39.265)-(56.432)-(91.654)-(-88.007));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (-30.42-(-62.987)-(-12.628)-(28.981)-(23.11)-(-90.658));
segmentsAcked = (int) (17.683-(96.676)-(22.525)-(-83.862)-(96.104)-(10.604));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (10.34-(-62.941)-(-89.012)-(64.433)-(-21.13)-(34.877));
segmentsAcked = (int) (96.807-(-74.021)-(35.435)-(-62.333)-(32.605)-(-80.721));
segmentsAcked = (int) (-88.489-(68.564)-(-45.069)-(91.555)-(-21.847)-(4.578));
segmentsAcked = (int) (-68.556-(-88.436)-(-11.096)-(-81.172)-(-60.849)-(-9.704));
segmentsAcked = (int) (97.474-(78.081)-(21.943)-(63.343)-(-76.086)-(-91.828));
segmentsAcked = (int) (-46.479-(-14.49)-(-33.391)-(68.26)-(-27.944)-(-47.463));
segmentsAcked = (int) (-25.879-(63.221)-(-87.827)-(-44.809)-(49.583)-(43.212));
