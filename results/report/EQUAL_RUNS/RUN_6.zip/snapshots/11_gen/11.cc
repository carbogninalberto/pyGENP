float GMVwrBmxOBMGPwlq = (float) (-72.23+(-81.143)+(-89.745));
tcb->m_cWnd = (int) (-68.369*(-6.264)*(51.548)*(54.163)*(77.307)*(-86.706)*(-6.322)*(-5.599));
int TmnQVKLdvSXUxKyU = (int) 35.6;
