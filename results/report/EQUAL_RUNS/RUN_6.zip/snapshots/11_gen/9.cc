float GMVwrBmxOBMGPwlq = (float) (84.308+(-70.079)+(25.503));
int TmnQVKLdvSXUxKyU = (int) (32.376*(54.127)*(-80.766)*(10.243)*(90.679)*(-77.43)*(-7.062)*(-36.547)*(-57.358));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-65.424*(-69.867)*(-54.209)*(-59.044)*(-10.826)*(-83.99)*(10.019)*(82.947));
TmnQVKLdvSXUxKyU = (int) (79.488-(97.921)-(-23.79)-(-1.602)-(-17.264)-(85.342));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
