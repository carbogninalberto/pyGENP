if (tcb->m_ssThresh >= tcb->m_cWnd) {
	segmentsAcked = (int) (26.429+(tcb->m_cWnd)+(28.635)+(90.756)+(7.111));
	tcb->m_ssThresh = (int) (4.737*(tcb->m_segmentSize)*(21.537)*(tcb->m_cWnd)*(57.372)*(84.41)*(71.891));

} else {
	segmentsAcked = (int) (53.775+(tcb->m_ssThresh)+(21.281)+(3.62)+(66.317)+(94.572)+(67.9));
	segmentsAcked = (int) (52.98+(19.631)+(54.15)+(82.513)+(18.442)+(69.6)+(22.108)+(tcb->m_ssThresh)+(51.261));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (41.948+(tcb->m_segmentSize)+(99.473)+(75.563)+(90.718)+(46.087));
	tcb->m_ssThresh = (int) (25.819-(67.415)-(tcb->m_ssThresh)-(91.369)-(29.861));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(tcb->m_ssThresh)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (((77.616)+(7.829)+((25.228*(22.327)*(tcb->m_cWnd)*(3.043)))+(0.1)+((96.117+(62.404)+(3.631)+(58.011)+(66.653)+(88.556)+(97.846)+(99.86)))+(0.1))/((42.818)+(23.794)+(33.345)));
	tcb->m_cWnd = (int) (47.055-(87.252)-(48.073)-(50.93)-(segmentsAcked)-(67.726)-(segmentsAcked)-(13.783)-(91.409));

}
