segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (8.494+(63.695)+(31.228)+(18.878)+(segmentsAcked));
	tcb->m_ssThresh = (int) (((51.53)+(50.389)+(0.1)+(0.1)+(0.1)+(79.053))/((14.753)+(0.1)+(2.222)));

} else {
	tcb->m_segmentSize = (int) (38.636+(50.554)+(32.689)+(23.114)+(5.785)+(46.927)+(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (54.548*(89.872)*(1.029)*(11.929)*(tcb->m_segmentSize)*(58.849)*(9.772)*(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (23.829-(25.008)-(96.685)-(84.474)-(75.821)-(80.179)-(67.105)-(77.378)-(22.026));
tcb->m_cWnd = (int) (24.97-(tcb->m_cWnd)-(4.848)-(69.731)-(49.127));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (55.362+(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(tcb->m_ssThresh)+(tcb->m_cWnd)+(71.662)+(65.862)+(tcb->m_segmentSize)+(93.349)+(66.499));

} else {
	tcb->m_ssThresh = (int) (94.575+(35.083)+(64.616)+(24.007)+(68.459)+(35.096)+(20.724));
	CongestionAvoidance (tcb, segmentsAcked);

}
