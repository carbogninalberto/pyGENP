float fnBMIrgxTUQWtCAG = (float) 58.365;
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (57.373-(-30.886)-(-30.329)-(-45.783)-(-90.944)-(3.906));
segmentsAcked = (int) (-30.109-(65.278)-(-80.483)-(-26.309)-(17.72)-(-84.646));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (-77.327-(-53.843)-(-47.199)-(15.037)-(-29.468)-(-23.479));
segmentsAcked = (int) (27.858-(41.793)-(-15.343)-(-57.661)-(-65.42)-(65.312));
segmentsAcked = (int) (-38.021-(81.093)-(21.267)-(-52.3)-(-57.339)-(61.497));
segmentsAcked = (int) (59.995-(-78.333)-(-65.563)-(93.225)-(-97.096)-(41.034));
segmentsAcked = (int) (72.752-(-51.809)-(80.753)-(-90.251)-(-59.26)-(-75.006));
segmentsAcked = (int) (-89.735-(8.685)-(-14.714)-(-95.468)-(0.282)-(59.007));
