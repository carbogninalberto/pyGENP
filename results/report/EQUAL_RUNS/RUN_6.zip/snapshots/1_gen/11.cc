tcb->m_ssThresh = (int) (40.114/0.1);
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	segmentsAcked = (int) (70.861+(segmentsAcked)+(tcb->m_ssThresh)+(71.177)+(56.449));
	segmentsAcked = (int) (tcb->m_cWnd+(10.993)+(65.714)+(51.879)+(96.95));

} else {
	segmentsAcked = (int) (68.777+(19.61)+(tcb->m_cWnd)+(11.083)+(74.638)+(75.929)+(6.223)+(61.084));
	tcb->m_cWnd = (int) (((94.939)+(0.1)+(0.1)+(51.651)+(0.1))/((0.1)+(0.1)));

}
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (80.049-(60.307)-(66.648)-(37.324)-(segmentsAcked)-(30.625));
	tcb->m_ssThresh = (int) (50.282-(tcb->m_ssThresh)-(9.711)-(25.65)-(tcb->m_ssThresh)-(89.284)-(59.814)-(94.964));

} else {
	tcb->m_segmentSize = (int) (6.433*(81.338)*(49.169)*(tcb->m_cWnd)*(84.33)*(tcb->m_ssThresh));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(12.78)+(93.387)+(68.217));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (77.73/13.183);
	segmentsAcked = (int) (69.662*(84.747)*(86.8)*(38.479)*(46.046)*(46.382)*(37.467));
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(44.485)*(93.902)*(60.339)*(75.113)*(59.542)*(8.643)*(95.897)*(56.183));

}
