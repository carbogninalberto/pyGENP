segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (89.388*(84.626)*(78.948)*(75.4)*(segmentsAcked));
if (segmentsAcked != segmentsAcked) {
	tcb->m_cWnd = (int) ((12.725-(tcb->m_cWnd)-(1.597)-(97.404)-(tcb->m_ssThresh)-(52.399))/50.207);
	segmentsAcked = (int) (22.657*(18.229)*(3.009)*(61.88)*(14.622)*(61.129)*(90.206));
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(86.049)*(50.472)*(6.066)*(0.835)*(0.492)*(91.587)*(12.614)*(38.891));

} else {
	tcb->m_cWnd = (int) (10.439+(35.386)+(47.15)+(92.924)+(23.061)+(84.246)+(35.951));
	tcb->m_cWnd = (int) (((0.1)+(78.938)+(0.1)+(69.501)+(35.029)+(0.1))/((0.1)));
	tcb->m_ssThresh = (int) (((42.439)+((53.096*(0.056)*(40.154)*(8.456)*(69.593)))+(0.1)+(0.1)+(31.902)+(42.102))/((62.349)+(0.1)));

}
if (segmentsAcked > tcb->m_ssThresh) {
	segmentsAcked = (int) (50.126/0.1);
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(82.126)+(18.014)+(tcb->m_segmentSize)+(69.995)+(54.27)+(67.315));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (26.604+(24.644)+(14.316)+(89.278)+(18.153)+(43.075)+(segmentsAcked));

}
tcb->m_cWnd = (int) (47.865-(79.587)-(2.351)-(8.336)-(37.762)-(76.998)-(31.385));
