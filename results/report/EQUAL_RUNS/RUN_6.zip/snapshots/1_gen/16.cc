ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (33.16*(59.586)*(14.979)*(79.054)*(64.213)*(17.366)*(44.676));
tcb->m_segmentSize = (int) (8.631-(73.748)-(17.358)-(61.739)-(segmentsAcked)-(8.238)-(54.743));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (71.922/0.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
