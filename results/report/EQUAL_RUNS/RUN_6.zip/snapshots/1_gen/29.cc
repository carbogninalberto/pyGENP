segmentsAcked = (int) (32.123*(10.873)*(22.358)*(65.364)*(36.015));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (58.944-(63.031)-(62.485));
tcb->m_cWnd = (int) (tcb->m_segmentSize+(65.41)+(19.433)+(58.726)+(segmentsAcked)+(38.122)+(0.465)+(1.323));
int ssaVMGMoUjehYzkU = (int) (4.538-(14.41)-(tcb->m_ssThresh)-(68.985)-(tcb->m_cWnd)-(tcb->m_cWnd)-(89.714)-(74.645));
