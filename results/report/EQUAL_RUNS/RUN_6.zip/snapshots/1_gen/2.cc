segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (48.801*(2.353)*(89.41)*(29.557)*(39.558)*(39.004));
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(47.593));
	tcb->m_cWnd = (int) (98.99+(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (54.448+(45.777)+(54.087)+(tcb->m_segmentSize)+(segmentsAcked)+(95.682)+(5.658)+(63.112)+(33.613));
	segmentsAcked = (int) (segmentsAcked*(56.582)*(segmentsAcked)*(62.817)*(tcb->m_ssThresh)*(84.623)*(segmentsAcked)*(67.789));
	tcb->m_cWnd = (int) (77.914+(16.212)+(65.798)+(tcb->m_cWnd)+(segmentsAcked));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (0.1/33.519);
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (23.671*(tcb->m_segmentSize)*(76.371)*(69.617)*(23.501)*(40.382)*(tcb->m_cWnd)*(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (78.224+(44.192)+(12.05)+(segmentsAcked)+(23.052)+(73.138));

}
