tcb->m_ssThresh = (int) (34.224*(37.975));
tcb->m_segmentSize = (int) (18.644-(24.578)-(tcb->m_segmentSize)-(95.348)-(26.461));
tcb->m_ssThresh = (int) (28.765/0.1);
tcb->m_ssThresh = (int) (5.265-(83.575)-(segmentsAcked)-(4.085)-(98.003)-(tcb->m_ssThresh)-(68.138));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (0.1/0.1);
