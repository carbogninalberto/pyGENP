if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (87.921-(38.806)-(18.114)-(54.518)-(11.617)-(8.149));

} else {
	tcb->m_cWnd = (int) (3.651-(24.546)-(39.79)-(25.858)-(24.406)-(tcb->m_ssThresh)-(44.328)-(tcb->m_cWnd)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (((0.1)+((16.048-(15.547)-(segmentsAcked)-(78.704)-(61.089)))+((45.769+(segmentsAcked)+(75.946)+(84.042)+(54.734)+(78.396)+(80.014)+(30.237)))+(14.015))/((23.65)));
	tcb->m_segmentSize = (int) (82.768+(30.26));

}
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	segmentsAcked = (int) (87.063+(85.003)+(9.54)+(tcb->m_cWnd)+(30.901));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(20.007)+(tcb->m_cWnd)+(75.507)+(27.737)+(68.027)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(92.831));
	tcb->m_ssThresh = (int) (18.962*(55.943)*(94.48)*(74.989)*(52.708));
	tcb->m_segmentSize = (int) (92.897*(18.219)*(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (49.397-(29.217)-(94.996));
tcb->m_ssThresh = (int) (23.253*(tcb->m_cWnd)*(tcb->m_ssThresh)*(32.557)*(25.34)*(18.132)*(74.292)*(66.659)*(14.386));
