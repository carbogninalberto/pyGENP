int yGcOasLheTAcBKYS = (int) (40.424/13.867);
float RQNAbCMlgxUspLus = (float) 56.778;
