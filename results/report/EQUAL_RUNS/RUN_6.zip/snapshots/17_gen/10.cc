float PVIQnwLUZyCkkOUJ = (float) (-9.818*(42.572)*(1.607)*(19.445)*(-37.329)*(-37.528)*(51.718));
int STdDBVCQObUpEhze = (int) (-80.13-(-67.323)-(11.371)-(-66.963)-(28.923));
tcb->m_segmentSize = (int) (41.705+(-27.149));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize <= segmentsAcked) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (4.06*(tcb->m_cWnd)*(72.118)*(segmentsAcked)*(92.086)*(59.643));

}
segmentsAcked = (int) (30.993+(71.506)+(-41.659)+(55.175)+(-68.437)+(51.73));
tcb->m_cWnd = (int) (-7.458-(-75.522)-(38.413)-(-80.967)-(14.636)-(44.849)-(2.136)-(-45.334));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) ((((16.298*(-87.656)*(39.988)*(segmentsAcked)*(63.757)*(35.09)*(-59.302)*(42.478)*(87.812)))+((-73.682*(62.554)*(-71.462)*(34.181)*(-12.259)))+(79.088)+(69.226))/((-59.219)));
