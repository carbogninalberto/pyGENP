CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) ((((21.016+(42.391)+(tcb->m_ssThresh)+(30.729)+(-15.829)+(-6.064)))+(-58.634)+(49.893)+(18.665))/((-40.954)+(26.695)));
