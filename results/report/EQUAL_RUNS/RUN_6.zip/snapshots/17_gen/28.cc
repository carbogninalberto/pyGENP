if (tcb->m_ssThresh <= tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_cWnd = (int) ((87.037*(segmentsAcked)*(30.108)*(tcb->m_segmentSize)*(89.05)*(8.611)*(80.985))/(32.279-(83.744)-(83.345)));
	segmentsAcked = (int) (96.486-(98.211)-(72.005)-(98.743)-(79.428)-(28.649)-(34.391));

} else {
	segmentsAcked = (int) (39.662-(20.891)-(30.383));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (47.077-(9.932));

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (67.351-(25.753)-(91.807)-(53.468)-(52.684)-(16.469)-(84.916));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(tcb->m_segmentSize)-(13.296)-(84.83)-(1.201)-(70.724)-(77.815)-(41.175)-(49.476));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (26.46/49.486);
tcb->m_ssThresh = (int) (3.641-(92.39)-(38.783)-(29.916)-(28.191)-(48.632)-(87.876)-(79.935)-(35.811));
tcb->m_segmentSize = (int) (91.033-(35.802));
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	segmentsAcked = (int) (((39.889)+(0.1)+(0.1)+(63.275)+(96.77))/((30.301)+(72.857)));

} else {
	segmentsAcked = (int) (46.003-(59.168)-(36.566)-(60.945)-(24.357)-(54.701)-(70.564)-(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
