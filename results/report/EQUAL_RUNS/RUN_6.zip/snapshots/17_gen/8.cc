float JIQAlXCQibrHHYTf = (float) (-95.861/-17.201);
