segmentsAcked = (int) (72.281-(80.484)-(58.506)-(38.322));
int NPPrfowAUXWcdSRa = (int) (tcb->m_cWnd+(97.131)+(29.299)+(18.467));
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (35.646/85.635);

} else {
	tcb->m_cWnd = (int) (47.648/54.698);

}
tcb->m_ssThresh = (int) (52.484-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(15.872));
if (segmentsAcked > NPPrfowAUXWcdSRa) {
	segmentsAcked = (int) (74.725*(8.477)*(96.676)*(52.353));
	NPPrfowAUXWcdSRa = (int) (92.734*(59.312)*(14.722)*(40.032)*(29.061)*(78.513));
	segmentsAcked = (int) (90.305-(2.546)-(41.705)-(36.906)-(49.067)-(88.657)-(47.825)-(29.347)-(72.896));

} else {
	segmentsAcked = (int) (41.862-(NPPrfowAUXWcdSRa)-(82.321)-(98.555)-(43.069)-(26.47)-(56.081));
	tcb->m_cWnd = (int) (83.558+(5.825)+(1.908)+(50.316)+(68.029)+(16.35)+(63.949)+(35.851)+(33.729));
	segmentsAcked = (int) (62.84+(53.287)+(22.682));

}
