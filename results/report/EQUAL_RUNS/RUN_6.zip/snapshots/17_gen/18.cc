tcb->m_segmentSize = (int) (76.274*(52.077)*(-9.144)*(-18.031)*(-42.15));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	segmentsAcked = (int) (47.921/0.1);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (0.1/98.777);

} else {
	segmentsAcked = (int) (44.411*(71.845)*(51.362));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	segmentsAcked = (int) (44.411*(71.845)*(51.362));

} else {
	segmentsAcked = (int) (47.921/0.1);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (0.1/98.777);

}
CongestionAvoidance (tcb, segmentsAcked);
