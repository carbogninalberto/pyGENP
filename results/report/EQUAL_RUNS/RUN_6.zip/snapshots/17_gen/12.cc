float npdKcDEMgiyXfoxD = (float) (-17.991*(-15.343)*(3.459));
