float fnBMIrgxTUQWtCAG = (float) 58.365;
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

} else {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (17.154-(39.667)-(-87.354)-(5.609)-(85.079)-(90.919));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (-37.867-(-89.656)-(28.41)-(11.429)-(26.881)-(-42.711));
segmentsAcked = (int) (-41.422-(92.467)-(55.291)-(-48.311)-(-66.46)-(-2.073));
segmentsAcked = (int) (14.215-(-12.476)-(-19.078)-(13.385)-(-92.812)-(26.966));
segmentsAcked = (int) (-52.586-(36.419)-(49.948)-(-6.454)-(20.322)-(-36.48));
segmentsAcked = (int) (-55.302-(-6.84)-(-0.136)-(44.719)-(-82.213)-(31.869));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (42.001-(45.322)-(-20.984)-(-85.783)-(62.998)-(98.095));
segmentsAcked = (int) (-28.828-(17.017)-(-96.04)-(66.54)-(78.384)-(43.001));
segmentsAcked = (int) (45.733-(-17.463)-(89.704)-(-68.67)-(-89.071)-(-93.018));
segmentsAcked = (int) (-24.627-(18.279)-(78.154)-(-55.5)-(-26.835)-(-12.473));
