float fnBMIrgxTUQWtCAG = (float) 58.365;
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

} else {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (-51.977-(-3.004)-(-42.07)-(-22.641)-(-97.178)-(83.791));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

} else {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (14.633-(-55.06)-(-43.686)-(11.41)-(56.315)-(-89.898));
segmentsAcked = (int) (-83.387-(99.635)-(-86.617)-(2.133)-(52.257)-(79.106));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (-35.819-(-12.199)-(-34.155)-(-30.618)-(61.393)-(-43.803));
segmentsAcked = (int) (4.563-(58.247)-(18.068)-(-38.426)-(77.562)-(-56.627));
segmentsAcked = (int) (-24.592-(42.965)-(38.692)-(-15.864)-(-40.672)-(-65.384));
segmentsAcked = (int) (-59.157-(50.075)-(51.905)-(58.957)-(4.643)-(55.674));
segmentsAcked = (int) (69.268-(-71.297)-(-11.283)-(32.838)-(-40.329)-(-68.996));
segmentsAcked = (int) (73.385-(38.434)-(71.105)-(-29.684)-(-95.25)-(27.913));
segmentsAcked = (int) (-7.641-(-1.237)-(74.695)-(-83.938)-(-84.803)-(-63.181));
