float tPWOYrCfUBznzxnS = (float) (-53.422-(44.718)-(81.441));
tcb->m_cWnd = (int) (-41.268*(17.316)*(20.094)*(-42.204)*(-92.2));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (46.37*(-80.808)*(-92.43)*(-63.985)*(96.146));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (85.736*(82.759)*(-11.328)*(-20.962)*(-51.937));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-35.694*(-0.326)*(91.52)*(-60.854)*(-32.013));
ReduceCwnd (tcb);
