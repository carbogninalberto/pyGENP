float fnBMIrgxTUQWtCAG = (float) 58.365;
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

} else {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (36.852-(-36.773)-(-11.702)-(60.119)-(34.813)-(-4.225));
segmentsAcked = (int) (-61.372-(-18.048)-(-45.945)-(-35.214)-(-13.813)-(85.95));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (-95.342-(82.64)-(-68.134)-(-49.342)-(80.042)-(-55.709));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (-59.589-(-3.664)-(-92.203)-(-61.231)-(63.166)-(70.065));
segmentsAcked = (int) (-46.106-(75.971)-(65.624)-(-63.458)-(83.39)-(65.584));
segmentsAcked = (int) (92.929-(-59.336)-(-87.91)-(-20.771)-(88.494)-(99.576));
segmentsAcked = (int) (75.062-(-44.431)-(16.583)-(7.973)-(-16.464)-(13.737));
segmentsAcked = (int) (-57.765-(-75.742)-(-44.448)-(57.763)-(90.125)-(76.711));
segmentsAcked = (int) (-61.199-(91.731)-(82.445)-(51.015)-(54.957)-(66.438));
segmentsAcked = (int) (19.722-(12.814)-(-56.408)-(46.686)-(-86.967)-(99.651));
segmentsAcked = (int) (-83.209-(-5.591)-(-33.748)-(-99.302)-(-12.014)-(16.694));
segmentsAcked = (int) (-71.061-(90.801)-(17.508)-(-6.041)-(-74.681)-(-24.72));
segmentsAcked = (int) (-25.856-(-35.015)-(86.061)-(-95.508)-(-88.44)-(30.004));
segmentsAcked = (int) (66.49-(-26.378)-(76.686)-(97.454)-(48.531)-(96.155));
