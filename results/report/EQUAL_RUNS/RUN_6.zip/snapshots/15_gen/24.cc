float OqCRPGhSRyfuuJYZ = (float) ((-3.927-(80.741)-(63.677)-(-18.97)-(74.078)-(-80.226))/-50.953);
if (tcb->m_cWnd <= OqCRPGhSRyfuuJYZ) {
	segmentsAcked = (int) ((tcb->m_cWnd-(45.502)-(99.305)-(66.902))/0.1);

} else {
	segmentsAcked = (int) (((73.386)+(0.1)+(58.667)+(43.924)+(0.1))/((0.1)+(0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
int yVLtEBIWwudsYoTo = (int) (-25.157+(-27.786)+(-57.767)+(62.401)+(-51.083)+(28.23)+(-90.586)+(60.819)+(-10.179));
segmentsAcked = (int) (((-34.575)+(53.606)+(-2.546)+(-49.663)+(-80.33)+(-9.832)+(-92.55)+(-47.223))/((99.413)));
tcb->m_segmentSize = (int) (-57.309*(46.51)*(37.631)*(-65.252)*(16.02)*(60.869)*(-74.554)*(-59.343));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-11.536*(-35.405)*(-73.419)*(-96.857)*(7.65)*(-34.618)*(99.235)*(53.791));
if (tcb->m_cWnd <= OqCRPGhSRyfuuJYZ) {
	segmentsAcked = (int) ((tcb->m_cWnd-(45.502)-(99.305)-(66.902))/0.1);

} else {
	segmentsAcked = (int) (((73.386)+(0.1)+(58.667)+(43.924)+(0.1))/((0.1)+(0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = (int) (((-25.211)+(69.082)+(-39.665)+(-5.736)+(5.047)+(92.624)+(54.495)+(61.104))/((-16.428)));
tcb->m_segmentSize = (int) (81.989*(70.735)*(27.861)*(-91.11)*(-67.108)*(-53.922)*(65.736)*(91.73));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-37.525*(-62.998)*(52.237)*(-56.388)*(-92.476)*(91.898)*(-0.487)*(45.034));
