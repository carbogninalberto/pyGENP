float fnBMIrgxTUQWtCAG = (float) 58.365;
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

} else {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (-14.639-(-63.602)-(0.274)-(72.947)-(2.044)-(-83.42));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (51.962-(44.605)-(-98.735)-(83.928)-(-25.432)-(34.823));
segmentsAcked = (int) (26.666-(89.327)-(93.725)-(9.443)-(67.99)-(55.398));
segmentsAcked = (int) (9.739-(72.69)-(-58.224)-(-94.539)-(71.503)-(55.657));
