float fnBMIrgxTUQWtCAG = (float) 58.365;
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (21.471-(96.314)-(45.633)-(-96.05)-(41.969)-(90.479));
segmentsAcked = (int) (-17.48-(19.772)-(-88.969)-(44.44)-(-53.869)-(66.876));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (-10.279-(-34.317)-(51.463)-(-39.16)-(57.868)-(56.32));
segmentsAcked = (int) (-20.297-(25.69)-(-23.537)-(-29.156)-(40.898)-(-17.392));
segmentsAcked = (int) (-37.679-(65.901)-(-22.062)-(85.28)-(-68.229)-(-76.606));
segmentsAcked = (int) (23.71-(-87.964)-(-83.015)-(85.455)-(-16.215)-(-90.173));
segmentsAcked = (int) (7.776-(51.656)-(45.12)-(88.475)-(-56.23)-(-59.393));
segmentsAcked = (int) (1.425-(-98.832)-(-95.979)-(57.806)-(73.607)-(-60.054));
