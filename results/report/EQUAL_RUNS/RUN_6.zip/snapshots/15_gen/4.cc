float afHwXIkmJmdgqeFf = (float) 58.281;
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (47.335+(88.111)+(34.578)+(59.618)+(0.812)+(afHwXIkmJmdgqeFf)+(40.342)+(tcb->m_segmentSize)+(26.113));

} else {
	tcb->m_cWnd = (int) (60.928-(17.845));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
