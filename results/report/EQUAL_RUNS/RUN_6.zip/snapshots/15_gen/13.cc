float fnBMIrgxTUQWtCAG = (float) 58.365;
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (-66.29-(-79.367)-(-28.353)-(42.597)-(-56.008)-(93.19));
segmentsAcked = (int) (-67.004-(93.102)-(-39.934)-(6.284)-(7.269)-(-49.214));
segmentsAcked = (int) (-85.046-(3.318)-(43.678)-(-58.509)-(-66.899)-(32.739));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (-2.398-(-22.113)-(-64.023)-(46.347)-(44.529)-(69.242));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (65.577-(87.877)-(-49.493)-(38.411)-(-55.697)-(99.849));
segmentsAcked = (int) (-77.662-(-0.088)-(-43.515)-(47.333)-(-46.932)-(-21.462));
segmentsAcked = (int) (-66.23-(-14.628)-(90.931)-(86.164)-(-80.564)-(-11.962));
segmentsAcked = (int) (88.07-(-68.795)-(-75.259)-(-61.587)-(37.725)-(-47.45));
segmentsAcked = (int) (-58.021-(-61.796)-(14.379)-(-69.489)-(74.242)-(67.768));
segmentsAcked = (int) (91.768-(43.308)-(-75.585)-(-46.869)-(-6.127)-(-60.945));
segmentsAcked = (int) (48.222-(-52.823)-(-78.015)-(18.216)-(-10.437)-(92.865));
segmentsAcked = (int) (-3.638-(51.214)-(25.88)-(-61.664)-(-88.88)-(-45.55));
