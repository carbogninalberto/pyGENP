float fnBMIrgxTUQWtCAG = (float) 58.365;
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (-99.011-(-71.553)-(71.165)-(59.295)-(58.197)-(-62.835));
segmentsAcked = (int) (10.862-(-66.605)-(-5.394)-(-14.836)-(14.421)-(-32.033));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (-25.333-(31.766)-(42.436)-(39.394)-(-18.952)-(-28.203));
segmentsAcked = (int) (67.365-(4.566)-(-90.034)-(-43.51)-(-96.217)-(94.714));
segmentsAcked = (int) (23.134-(-11.942)-(49.096)-(-36.75)-(-24.931)-(-97.756));
segmentsAcked = (int) (-90.622-(-20.934)-(-35.571)-(62.682)-(31.448)-(44.256));
segmentsAcked = (int) (69.384-(20.511)-(69.356)-(-29.941)-(-52.241)-(-61.793));
segmentsAcked = (int) (-78.172-(3.16)-(31.8)-(62.397)-(-34.225)-(-51.222));
