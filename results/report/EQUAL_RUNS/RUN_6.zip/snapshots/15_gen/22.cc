if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked+(segmentsAcked)+(5.713)+(tcb->m_cWnd)+(67.651)+(99.557));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (53.553*(45.79));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(67.33));
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(80.608))/((26.101)+(0.1)));

}
