float zhrlTnwaZwZlevid = (float) (88.875/55.707);
tcb->m_segmentSize = (int) (4.79+(-29.438)+(-72.978)+(38.696)+(81.751));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (23.565-(49.985)-(98.295));

} else {
	tcb->m_cWnd = (int) (79.594+(78.014)+(16.18)+(61.467)+(segmentsAcked)+(45.938)+(77.127)+(27.439)+(23.2));

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (23.565-(49.985)-(98.295));

} else {
	tcb->m_cWnd = (int) (79.594+(78.014)+(16.18)+(61.467)+(segmentsAcked)+(45.938)+(77.127)+(27.439)+(23.2));

}
