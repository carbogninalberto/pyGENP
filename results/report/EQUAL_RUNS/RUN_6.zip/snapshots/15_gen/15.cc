TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((70.592)+(57.355)+(60.793)+(15.35))/((-72.439)+(91.342)+(96.6)));
tcb->m_segmentSize = (int) (-91.759*(-41.281)*(7.994)*(77.39)*(-13.759)*(17.977)*(38.62)*(80.11));
CongestionAvoidance (tcb, segmentsAcked);
