if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (23.565-(49.985)-(98.295));

} else {
	tcb->m_cWnd = (int) (79.594+(78.014)+(16.18)+(61.467)+(segmentsAcked)+(45.938)+(77.127)+(27.439)+(23.2));

}
float zhrlTnwaZwZlevid = (float) (-84.324/38.421);
float iyrzJRHOSxjHJpnQ = (float) (56.859-(33.631)-(55.482)-(-81.032)-(-59.917)-(24.307)-(80.981)-(83.16)-(86.678));
