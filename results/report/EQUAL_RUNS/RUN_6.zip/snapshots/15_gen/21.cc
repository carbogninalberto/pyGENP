float fnBMIrgxTUQWtCAG = (float) 58.365;
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

} else {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (-15.162-(-20.585)-(-79.88)-(-15.014)-(-78.51)-(57.56));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (-20.222-(61.304)-(-69.308)-(53.577)-(20.442)-(95.314));
segmentsAcked = (int) (-72.434-(-78.812)-(-0.33)-(-90.388)-(23.694)-(-72.915));
segmentsAcked = (int) (17.308-(10.129)-(-6.915)-(-64.777)-(-59.253)-(46.625));
segmentsAcked = (int) (53.697-(-40.593)-(-45.242)-(13.829)-(32.723)-(-77.308));
