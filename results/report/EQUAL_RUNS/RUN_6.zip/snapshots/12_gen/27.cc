ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_ssThresh = (int) (88.672/22.185);
	tcb->m_ssThresh = (int) (1.506*(66.871));

} else {
	tcb->m_ssThresh = (int) (2.555+(9.884)+(53.247)+(86.638));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (11.358*(tcb->m_ssThresh)*(63.828)*(tcb->m_segmentSize)*(88.723)*(28.871)*(1.678));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
