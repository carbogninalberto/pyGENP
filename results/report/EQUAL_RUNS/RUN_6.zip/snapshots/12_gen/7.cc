TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	segmentsAcked = (int) (75.258*(22.191));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (80.043-(2.703)-(22.841)-(84.177)-(5.593)-(92.761)-(62.964));

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
