float nREiKEvpwSpXzdrQ = (float) (30.876*(-38.121)*(14.329)*(-89.776)*(80.738)*(-27.524)*(-37.768)*(-67.682));
float zhrlTnwaZwZlevid = (float) (-28.31/-29.839);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (79.594+(78.014)+(16.18)+(61.467)+(segmentsAcked)+(45.938)+(77.127)+(27.439)+(23.2));

} else {
	tcb->m_cWnd = (int) (23.565-(49.985)-(98.295));

}
