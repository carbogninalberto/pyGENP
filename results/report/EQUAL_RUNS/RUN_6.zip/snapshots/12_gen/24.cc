tcb->m_segmentSize = (int) (((22.811)+(38.202)+((42.706*(30.197)))+(0.1))/((6.618)+(79.288)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) ((22.093*(segmentsAcked)*(25.189)*(79.627)*(tcb->m_segmentSize))/48.468);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (11.441+(32.014)+(26.293)+(tcb->m_ssThresh));
tcb->m_ssThresh = (int) (22.161*(93.215)*(60.799)*(14.001));
