float tPWOYrCfUBznzxnS = (float) (-21.875-(66.986)-(-32.142));
tcb->m_cWnd = (int) (61.02*(-14.494)*(-45.121)*(-22.012)*(63.908));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (47.281*(13.561)*(74.92)*(10.329)*(-83.835));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
