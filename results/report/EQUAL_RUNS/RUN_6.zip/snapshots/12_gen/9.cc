float tPWOYrCfUBznzxnS = (float) (33.549-(-0.284)-(-15.705));
tcb->m_cWnd = (int) (-73.114*(62.851)*(-4.756)*(14.655)*(-45.824));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-37.709*(89.97)*(54.455)*(40.076)*(-13.491));
ReduceCwnd (tcb);
