tcb->m_ssThresh = (int) (40.246+(75.661)+(65.707)+(29.288)+(55.065)+(37.664)+(tcb->m_cWnd)+(14.408));
tcb->m_ssThresh = (int) (29.138-(3.124)-(4.431)-(segmentsAcked));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_cWnd*(94.141)*(18.273)*(88.018)*(tcb->m_cWnd)*(27.807)*(tcb->m_segmentSize)*(48.762));
tcb->m_ssThresh = (int) (44.325*(69.705)*(19.532)*(93.404));
