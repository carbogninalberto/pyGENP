segmentsAcked = SlowStart (tcb, segmentsAcked);
float pphUaIobnratkXfn = (float) (38.373*(69.229)*(32.26)*(tcb->m_segmentSize)*(4.814)*(4.557)*(10.39));
if (tcb->m_cWnd != pphUaIobnratkXfn) {
	tcb->m_ssThresh = (int) (63.798+(3.991)+(pphUaIobnratkXfn)+(42.967)+(12.112)+(71.241));
	tcb->m_cWnd = (int) (36.268*(27.884)*(45.997));
	tcb->m_segmentSize = (int) (76.097*(62.67)*(tcb->m_cWnd)*(segmentsAcked)*(11.374)*(2.06)*(6.491));

} else {
	tcb->m_ssThresh = (int) (35.732*(79.025)*(19.898)*(29.791)*(tcb->m_cWnd)*(9.203));
	pphUaIobnratkXfn = (float) (96.662*(tcb->m_cWnd)*(29.263)*(42.225)*(15.752)*(61.61)*(22.785));

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (89.786-(12.437));
	tcb->m_cWnd = (int) (89.175-(96.819)-(1.685));

} else {
	tcb->m_segmentSize = (int) (56.102+(tcb->m_ssThresh)+(tcb->m_cWnd)+(2.272));
	tcb->m_ssThresh = (int) (11.555-(21.827)-(71.557)-(35.615)-(83.472)-(tcb->m_segmentSize));

}
CongestionAvoidance (tcb, segmentsAcked);
pphUaIobnratkXfn = (float) (tcb->m_cWnd+(tcb->m_ssThresh)+(pphUaIobnratkXfn)+(82.232)+(14.147)+(93.625));
pphUaIobnratkXfn = (float) (77.32+(60.137)+(35.12)+(44.148)+(30.795)+(segmentsAcked)+(98.197)+(50.161));
