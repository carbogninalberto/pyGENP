if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (22.585/95.988);
	tcb->m_ssThresh = (int) (52.137/3.292);

} else {
	tcb->m_cWnd = (int) (65.89*(23.287));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (88.297-(tcb->m_ssThresh)-(23.412)-(77.736)-(4.863));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (8.099*(51.778)*(52.144)*(95.169)*(74.791)*(31.407));

}
tcb->m_ssThresh = (int) (6.071-(19.085)-(71.542)-(tcb->m_cWnd));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) ((tcb->m_ssThresh-(tcb->m_cWnd))/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (20.099*(segmentsAcked)*(30.305)*(26.761)*(98.684)*(18.488));

}
ReduceCwnd (tcb);
