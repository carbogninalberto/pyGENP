int EFjlIybsAftJLoCg = (int) (11.537*(30.728)*(3.695)*(11.756)*(74.257)*(tcb->m_segmentSize)*(segmentsAcked)*(30.538)*(85.496));
if (EFjlIybsAftJLoCg == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (93.148+(95.41)+(43.391)+(64.868)+(68.066)+(15.183)+(24.796));
	tcb->m_ssThresh = (int) (80.612+(68.638)+(63.033)+(tcb->m_cWnd)+(76.351));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	EFjlIybsAftJLoCg = (int) (15.567+(18.64)+(8.043)+(33.884)+(78.397)+(EFjlIybsAftJLoCg)+(9.259)+(48.61)+(91.395));

}
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked != EFjlIybsAftJLoCg) {
	tcb->m_segmentSize = (int) (91.828*(62.684)*(9.297)*(21.042)*(43.813)*(9.747)*(88.732)*(EFjlIybsAftJLoCg));

} else {
	tcb->m_segmentSize = (int) (69.963/82.47);

}
tcb->m_cWnd = (int) ((19.659*(4.045)*(EFjlIybsAftJLoCg)*(38.718)*(56.054)*(11.922)*(tcb->m_ssThresh)*(24.465)*(EFjlIybsAftJLoCg))/0.1);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
