if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_segmentSize = (int) (63.354-(24.794)-(98.392)-(tcb->m_segmentSize)-(36.006)-(83.737)-(tcb->m_cWnd)-(70.183)-(76.016));

} else {
	tcb->m_segmentSize = (int) (33.537*(97.73)*(26.298)*(68.083)*(28.482)*(84.717));

}
CongestionAvoidance (tcb, segmentsAcked);
