tcb->m_cWnd = (int) (tcb->m_ssThresh+(28.553)+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (9.238-(tcb->m_cWnd)-(43.178)-(tcb->m_cWnd)-(77.342)-(56.028)-(75.233));
	tcb->m_ssThresh = (int) (((0.1)+((89.37*(29.509)*(55.677)*(12.653)*(91.816)))+(0.1)+((68.391*(86.668)))+(47.637)+(32.582)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (98.669+(28.936)+(63.032)+(13.825)+(92.923)+(17.971)+(tcb->m_ssThresh)+(13.684));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(2.501)+(62.541)+(53.097)+(84.746)+(77.847));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (44.422+(84.853)+(5.904)+(22.541));
CongestionAvoidance (tcb, segmentsAcked);
