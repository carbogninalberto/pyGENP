TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (38.291-(tcb->m_segmentSize)-(segmentsAcked));
tcb->m_segmentSize = (int) (12.165-(tcb->m_ssThresh)-(64.721)-(67.326));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (59.969-(67.2)-(98.346)-(13.957));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
