float JICLZcjfxvBUgIrA = (float) (11.141*(40.764)*(93.768)*(47.316)*(44.064));
ReduceCwnd (tcb);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (27.643-(95.412)-(JICLZcjfxvBUgIrA)-(92.743)-(16.769));

} else {
	segmentsAcked = (int) ((90.823*(81.935)*(tcb->m_ssThresh)*(58.029)*(tcb->m_cWnd)*(42.007)*(21.0))/36.276);
	JICLZcjfxvBUgIrA = (float) (76.396-(7.645));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (74.586-(93.544)-(81.11)-(29.285)-(36.163)-(30.89)-(tcb->m_segmentSize)-(16.378)-(1.512));
segmentsAcked = (int) (tcb->m_segmentSize+(54.282)+(64.25)+(JICLZcjfxvBUgIrA)+(23.265)+(segmentsAcked)+(60.161)+(segmentsAcked));
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_cWnd = (int) (((92.255)+(52.19)+(54.797)+(60.671)+(38.113))/((80.353)));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(78.737)*(30.009)*(49.628)*(tcb->m_ssThresh)*(50.42)*(24.476)*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) ((23.063+(25.995)+(98.14)+(74.724)+(65.155)+(59.819))/0.1);

}
if (JICLZcjfxvBUgIrA == tcb->m_ssThresh) {
	segmentsAcked = (int) (19.469+(95.624)+(JICLZcjfxvBUgIrA)+(37.173)+(tcb->m_segmentSize));
	segmentsAcked = (int) (48.174-(tcb->m_segmentSize)-(80.19)-(77.929));

} else {
	segmentsAcked = (int) (80.26+(29.836)+(79.92));
	CongestionAvoidance (tcb, segmentsAcked);

}
