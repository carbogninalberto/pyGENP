if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_cWnd = (int) (92.48*(tcb->m_cWnd)*(19.106)*(65.476));

} else {
	tcb->m_cWnd = (int) (23.296+(tcb->m_cWnd)+(35.633)+(6.901)+(26.365)+(5.287)+(51.964)+(28.436)+(67.578));
	segmentsAcked = (int) (55.207+(tcb->m_ssThresh)+(56.056)+(43.393)+(54.263)+(16.469)+(56.799)+(87.773));
	tcb->m_segmentSize = (int) (26.388*(73.829)*(55.266)*(99.42)*(43.428));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
float qhgsHCGDiEVDRTdf = (float) (71.842*(92.159)*(48.083));
tcb->m_cWnd = (int) (75.382+(qhgsHCGDiEVDRTdf));
if (qhgsHCGDiEVDRTdf > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (0.1/25.631);
	qhgsHCGDiEVDRTdf = (float) (tcb->m_ssThresh*(59.275)*(tcb->m_ssThresh)*(87.076)*(37.06));
	qhgsHCGDiEVDRTdf = (float) (((29.442)+(0.1)+(14.481)+(86.412)+(0.1))/((24.072)+(0.1)+(83.543)));

}
float MzOFlZZQtiynMVyN = (float) (49.035*(67.14));
if (segmentsAcked >= tcb->m_ssThresh) {
	MzOFlZZQtiynMVyN = (float) (0.1/86.661);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (15.592+(14.648)+(tcb->m_ssThresh)+(56.761)+(21.45)+(14.281)+(8.032)+(34.819));

} else {
	MzOFlZZQtiynMVyN = (float) (82.523-(57.428)-(69.351));

}
if (qhgsHCGDiEVDRTdf >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (34.741*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (37.019/0.1);

}
tcb->m_segmentSize = (int) (14.52-(19.752)-(qhgsHCGDiEVDRTdf)-(92.742)-(17.081));
