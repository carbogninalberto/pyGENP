if (tcb->m_ssThresh >= segmentsAcked) {
	segmentsAcked = (int) (((43.962)+(66.645)+(64.155)+((tcb->m_cWnd-(96.225)-(tcb->m_segmentSize)-(74.82)-(95.308)-(49.19)-(3.627)-(tcb->m_ssThresh)))+(0.1)+(47.309))/((83.322)));

} else {
	segmentsAcked = (int) (((62.387)+(0.1)+(49.257)+(11.298))/((0.1)+(50.694)));
	tcb->m_segmentSize = (int) (68.584-(58.683)-(tcb->m_ssThresh)-(80.986)-(54.23)-(segmentsAcked)-(33.749)-(75.959));

}
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((94.259*(44.295)*(50.69))/(tcb->m_segmentSize+(74.129)+(52.398)+(66.85)+(tcb->m_segmentSize)+(segmentsAcked)));
	tcb->m_segmentSize = (int) (71.333-(95.418)-(tcb->m_segmentSize)-(11.977)-(48.122)-(tcb->m_cWnd)-(tcb->m_cWnd)-(21.228));
	tcb->m_cWnd = (int) ((58.054-(50.637)-(tcb->m_ssThresh)-(62.333)-(32.502))/(tcb->m_cWnd*(62.732)));

} else {
	tcb->m_ssThresh = (int) (53.289+(tcb->m_ssThresh)+(90.203)+(tcb->m_cWnd)+(60.764)+(76.738)+(73.299));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (63.759*(71.634)*(segmentsAcked)*(94.56)*(segmentsAcked)*(90.877)*(tcb->m_segmentSize)*(88.04));
	tcb->m_segmentSize = (int) (54.343+(tcb->m_cWnd)+(12.466));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(segmentsAcked)+(55.631)+(tcb->m_ssThresh)+(22.559));

}
tcb->m_ssThresh = (int) (92.424-(53.499)-(43.038)-(67.556)-(20.655)-(tcb->m_cWnd)-(segmentsAcked)-(35.192)-(82.485));
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	segmentsAcked = (int) (8.506-(18.239)-(16.911)-(77.594));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(11.864)+(86.514)+(96.509)+(66.867));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (((38.42)+(0.1)+(18.191)+((83.926-(41.397)-(32.863)))+(0.1))/((63.701)));

}
