int MHaFFTVmbCkzrXeH = (int) (22.216-(tcb->m_segmentSize)-(29.606)-(segmentsAcked)-(tcb->m_segmentSize)-(27.062)-(segmentsAcked)-(18.616)-(3.84));
tcb->m_ssThresh = (int) (72.528*(77.33)*(31.64)*(36.23)*(segmentsAcked));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (84.222+(89.783)+(tcb->m_ssThresh)+(MHaFFTVmbCkzrXeH));
tcb->m_segmentSize = (int) (46.054*(57.082)*(17.462)*(96.117)*(65.681)*(82.753)*(tcb->m_segmentSize));
tcb->m_ssThresh = (int) (32.971+(7.343));
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (61.595*(segmentsAcked));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (29.93/0.1);

}
