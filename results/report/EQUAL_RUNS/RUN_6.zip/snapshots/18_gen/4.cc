if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (43.887*(92.637)*(40.806)*(80.332)*(26.4)*(52.332)*(-54.384));

} else {
	tcb->m_segmentSize = (int) (5.724/60.309);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (41.969+(89.332)+(88.06)+(63.048));

}
float OqCRPGhSRyfuuJYZ = (float) ((-40.495-(-38.554)-(-85.164)-(33.59)-(-46.41)-(3.892))/9.402);
segmentsAcked = (int) (((-18.26)+(47.859)+(15.692)+(54.464)+(-19.276)+(-64.9)+(78.853)+(-30.729))/((87.615)));
