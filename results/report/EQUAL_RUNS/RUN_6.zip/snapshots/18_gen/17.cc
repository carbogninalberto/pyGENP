ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
int rztZGzsOozqlxDIp = (int) (56.484+(10.593)+(tcb->m_segmentSize)+(31.188));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
rztZGzsOozqlxDIp = (int) (46.128*(rztZGzsOozqlxDIp)*(86.707)*(45.454)*(93.235)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(11.906));
