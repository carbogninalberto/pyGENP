float bfVQBkTzciplfSEM = (float) 6.249;
bfVQBkTzciplfSEM = (float) (((-15.043)+(-71.751)+(41.673)+(57.399)+(-71.104)+(68.258))/((-48.628)));
