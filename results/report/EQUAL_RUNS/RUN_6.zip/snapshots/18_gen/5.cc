ReduceCwnd (tcb);
float OqCRPGhSRyfuuJYZ = (float) 68.999;
OqCRPGhSRyfuuJYZ = (float) (41.518-(-4.781)-(57.133)-(-23.389));
segmentsAcked = (int) (((14.59)+(-12.424)+(52.092)+(66.454)+(-68.941)+(-59.802)+(66.183)+(15.455))/((48.659)));
tcb->m_segmentSize = (int) (-43.114*(56.576)*(15.478)*(-45.09)*(80.235)*(-85.992)*(-60.539)*(-83.39));
segmentsAcked = (int) (((-31.726)+(60.56)+(99.65)+(5.937)+(90.309)+(-42.122)+(31.615)+(-79.574))/((-12.061)));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (78.301*(-96.042)*(23.359)*(56.401)*(99.147)*(-4.663)*(-37.042)*(39.637));
tcb->m_segmentSize = (int) (-46.149*(-81.16)*(72.549)*(-31.847)*(29.93)*(13.25)*(-15.16)*(-94.394));
ReduceCwnd (tcb);
if (tcb->m_cWnd <= OqCRPGhSRyfuuJYZ) {
	segmentsAcked = (int) (((73.386)+(0.1)+(58.667)+(43.924)+(0.1))/((0.1)+(0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) ((tcb->m_cWnd-(45.502)-(99.305)-(66.902))/0.1);

}
tcb->m_segmentSize = (int) (-96.889*(44.541)*(-55.099)*(13.596)*(-3.741)*(57.023)*(-4.514)*(22.712));
segmentsAcked = (int) (((-90.886)+(41.748)+(5.63)+(17.717)+(11.217)+(74.316)+(-98.341)+(-5.923))/((-56.065)));
if (tcb->m_cWnd <= OqCRPGhSRyfuuJYZ) {
	segmentsAcked = (int) ((tcb->m_cWnd-(45.502)-(99.305)-(66.902))/0.1);

} else {
	segmentsAcked = (int) (((73.386)+(0.1)+(58.667)+(43.924)+(0.1))/((0.1)+(0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (-43.076*(-99.715)*(-33.762)*(93.403)*(9.662)*(-94.742)*(-40.9)*(-75.143));
