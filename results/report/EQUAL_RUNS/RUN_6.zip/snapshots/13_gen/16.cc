ReduceCwnd (tcb);
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (segmentsAcked*(60.7)*(segmentsAcked));
	segmentsAcked = (int) (58.117*(51.875)*(68.434)*(56.92)*(38.892)*(1.639));

} else {
	tcb->m_ssThresh = (int) (92.48-(77.248)-(tcb->m_cWnd)-(60.492)-(21.549)-(3.586)-(79.804)-(segmentsAcked));
	tcb->m_segmentSize = (int) (6.381*(38.018)*(23.362));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (90.297*(64.786)*(48.243)*(24.465)*(tcb->m_cWnd)*(65.0)*(96.147)*(85.147));
CongestionAvoidance (tcb, segmentsAcked);
float pgGCfySmCHGhanbD = (float) (32.879/98.736);
