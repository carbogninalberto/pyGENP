if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (23.565-(49.985)-(98.295));

} else {
	tcb->m_cWnd = (int) (79.594+(78.014)+(16.18)+(61.467)+(segmentsAcked)+(45.938)+(77.127)+(27.439)+(23.2));

}
float zhrlTnwaZwZlevid = (float) (-84.07/-93.648);
float nREiKEvpwSpXzdrQ = (float) (66.911*(75.898)*(7.485)*(75.098)*(-19.143)*(30.577)*(-28.636)*(18.334));
