if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) ((((tcb->m_cWnd*(46.925)*(78.443)*(tcb->m_cWnd)*(75.313)*(67.942)*(81.612)*(96.756)))+(94.228)+(12.675)+(0.1)+(0.1)+(12.618))/((0.1)+(0.1)));

} else {
	segmentsAcked = (int) ((((89.23-(32.864)-(63.855)))+(40.706)+(1.982)+(0.1))/((0.1)+(0.1)+(0.1)+(58.04)+(0.1)));
	tcb->m_ssThresh = (int) (3.737-(69.67)-(63.692)-(48.989)-(30.137)-(tcb->m_cWnd));

}
tcb->m_segmentSize = (int) (84.733-(tcb->m_cWnd)-(44.405)-(98.576)-(tcb->m_segmentSize)-(7.944));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (6.937*(44.743)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(32.094)*(69.835)*(tcb->m_cWnd)*(1.836)*(segmentsAcked));
	tcb->m_ssThresh = (int) (40.723*(43.905)*(63.607)*(60.978)*(98.899));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(1.729)-(70.663)-(8.847)-(87.321)-(52.587));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (29.535-(53.718)-(19.204)-(36.05)-(62.004)-(69.555)-(85.004)-(54.895)-(22.962));
segmentsAcked = (int) (8.252-(85.219)-(55.785)-(56.083)-(35.36)-(59.173));
