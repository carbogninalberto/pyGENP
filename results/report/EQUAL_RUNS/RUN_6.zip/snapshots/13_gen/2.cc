float fnBMIrgxTUQWtCAG = (float) 58.365;
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

} else {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (2.892-(-71.219)-(-78.97)-(81.769)-(-96.533)-(64.753));
segmentsAcked = (int) (84.231-(-45.268)-(52.299)-(-77.346)-(-19.948)-(-83.961));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (-69.741-(-45.838)-(-0.064)-(-75.216)-(40.639)-(47.485));
segmentsAcked = (int) (-60.233-(-0.744)-(16.408)-(-11.056)-(2.341)-(93.803));
segmentsAcked = (int) (20.211-(31.06)-(-76.587)-(-92.647)-(97.755)-(46.588));
segmentsAcked = (int) (-48.454-(-36.265)-(3.627)-(79.454)-(-56.173)-(-51.932));
segmentsAcked = (int) (-54.562-(24.249)-(-93.592)-(35.944)-(-49.809)-(-24.951));
segmentsAcked = (int) (-7.877-(-81.821)-(-39.862)-(87.864)-(-68.76)-(-26.299));
