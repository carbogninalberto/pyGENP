segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (52.745-(14.36)-(tcb->m_ssThresh)-(62.016)-(55.456));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (12.392+(66.502));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (20.973/78.05);

} else {
	tcb->m_cWnd = (int) ((71.32+(56.528)+(tcb->m_ssThresh)+(32.168)+(87.545))/(45.183+(94.818)+(66.039)+(58.736)+(41.162)+(99.358)));
	segmentsAcked = (int) (tcb->m_segmentSize-(78.281)-(68.742)-(97.617)-(25.821));

}
tcb->m_cWnd = (int) (55.725-(28.954)-(tcb->m_ssThresh)-(25.192)-(segmentsAcked));
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (54.259-(segmentsAcked)-(84.304)-(99.447)-(56.712)-(27.017));
	segmentsAcked = (int) (81.865-(28.639)-(61.287)-(segmentsAcked)-(92.358));
	tcb->m_ssThresh = (int) ((segmentsAcked*(segmentsAcked)*(0.872)*(tcb->m_ssThresh))/(79.253-(95.639)-(22.086)));

} else {
	segmentsAcked = (int) (((19.582)+(0.1)+(0.1)+(62.879)+(10.4)+(10.709)+(31.817))/((0.1)+(6.522)));

}
