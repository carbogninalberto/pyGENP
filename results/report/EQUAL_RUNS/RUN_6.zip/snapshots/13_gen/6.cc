tcb->m_cWnd = (int) (-71.842*(70.531)*(85.051)*(-6.778)*(-3.062));
float tPWOYrCfUBznzxnS = (float) (-67.335-(-63.594)-(-20.605));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (0.697*(16.132)*(-93.025)*(91.088)*(19.161));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
