float tPWOYrCfUBznzxnS = (float) (89.71-(-79.885)-(-8.212));
tcb->m_cWnd = (int) (31.682*(-0.12)*(94.581)*(74.054)*(10.89));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (55.796*(64.932)*(19.145)*(-67.248)*(-91.028));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (78.294*(-35.969)*(53.862)*(32.99)*(56.75));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-51.829*(28.155)*(87.383)*(52.86)*(-39.635));
ReduceCwnd (tcb);
