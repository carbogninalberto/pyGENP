tcb->m_cWnd = (int) (0.1/0.1);
int FLQfOZlGGkKagIZG = (int) (57.787+(45.964)+(4.717)+(segmentsAcked)+(tcb->m_ssThresh)+(26.866)+(43.296)+(8.006));
tcb->m_segmentSize = (int) (0.1/0.1);
if (tcb->m_cWnd <= FLQfOZlGGkKagIZG) {
	tcb->m_ssThresh = (int) (segmentsAcked-(12.004)-(64.187)-(80.414));
	tcb->m_cWnd = (int) (((74.488)+(0.1)+(26.048)+((11.666*(49.905)*(6.155)*(tcb->m_cWnd)*(16.834)*(tcb->m_ssThresh)*(45.418)*(81.074)*(31.378)))+(0.1))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (69.688+(66.024)+(80.982)+(79.995)+(80.506)+(85.822)+(tcb->m_cWnd)+(69.253));
	segmentsAcked = (int) (segmentsAcked+(19.862)+(70.574));
	tcb->m_ssThresh = (int) (0.1/0.1);

}
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((0.1)+((10.093+(26.167)+(55.496)+(57.045)+(90.353)+(44.131)+(62.535)+(11.038)+(99.409)))+(0.1)+(0.1)+(16.191))/((0.1)+(0.1)+(0.1)+(0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(44.162)+(99.796)+(FLQfOZlGGkKagIZG)+(39.928)+(53.012));

} else {
	tcb->m_ssThresh = (int) (((22.148)+(0.1)+(0.1)+(22.111))/((37.505)+(0.1)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (FLQfOZlGGkKagIZG == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (20.235*(51.203)*(69.76)*(74.831)*(52.944)*(65.233)*(26.553)*(79.037)*(70.288));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (34.721-(59.322));

}
FLQfOZlGGkKagIZG = (int) (82.883-(65.361)-(27.482)-(tcb->m_segmentSize)-(92.174)-(21.278)-(22.597)-(87.962));
