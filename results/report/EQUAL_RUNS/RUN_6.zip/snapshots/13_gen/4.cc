tcb->m_cWnd = (int) (69.04*(27.112)*(-10.357)*(31.35)*(78.919));
float tPWOYrCfUBznzxnS = (float) (-47.78-(-92.768)-(94.931));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-16.32*(-32.607)*(39.716)*(-52.469)*(64.612));
ReduceCwnd (tcb);
