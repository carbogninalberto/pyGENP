tcb->m_segmentSize = (int) (10.428+(74.56)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(14.251)+(64.656));
if (segmentsAcked >= tcb->m_segmentSize) {
	segmentsAcked = (int) (23.469*(98.71)*(tcb->m_cWnd));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (71.158-(87.39)-(9.35)-(69.763)-(49.181)-(68.76)-(60.637)-(13.333));

} else {
	segmentsAcked = (int) (81.78-(74.48)-(93.938)-(56.15)-(16.503)-(67.871));
	tcb->m_cWnd = (int) (32.891-(29.914)-(18.215)-(89.74)-(95.167)-(tcb->m_segmentSize));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
