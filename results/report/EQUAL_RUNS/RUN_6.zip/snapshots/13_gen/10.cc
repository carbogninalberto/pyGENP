segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (11.439+(14.313)+(39.52)+(88.041)+(segmentsAcked)+(18.654)+(54.922));

} else {
	tcb->m_segmentSize = (int) (0.1/60.801);

}
tcb->m_cWnd = (int) (-80.554*(84.036)*(83.44)*(33.666)*(-81.466)*(90.919));
tcb->m_cWnd = (int) (63.351-(30.583)-(-29.175)-(51.407)-(50.44));
