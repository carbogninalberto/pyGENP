float tPWOYrCfUBznzxnS = (float) (-15.303-(-47.379)-(-82.619));
tcb->m_cWnd = (int) (-2.032*(-60.458)*(47.291)*(-23.444)*(-74.102));
ReduceCwnd (tcb);
