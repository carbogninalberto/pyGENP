int rovJReFnMsCdRTyJ = (int) (30.248+(-41.441));
tcb->m_segmentSize = (int) (-52.154-(-81.995)-(-19.361)-(-65.997)-(-81.631));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
rovJReFnMsCdRTyJ = (int) (-36.21+(24.142)+(-12.357)+(-0.547)+(92.945)+(56.489)+(63.95));
rovJReFnMsCdRTyJ = (int) (23.603+(-23.169)+(-30.97)+(-15.399)+(-49.984)+(-88.447)+(6.636));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) ((32.707*(15.385)*(80.044)*(68.063)*(tcb->m_ssThresh))/0.1);
	segmentsAcked = (int) (63.185*(tcb->m_cWnd)*(47.84)*(65.508)*(33.56)*(19.907)*(77.479)*(31.009)*(13.039));

} else {
	segmentsAcked = (int) (90.387-(30.8)-(16.721)-(43.769)-(40.411)-(47.963)-(94.942)-(60.058));

}
if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (90.387-(30.8)-(16.721)-(43.769)-(40.411)-(47.963)-(94.942)-(60.058));

} else {
	segmentsAcked = (int) ((32.707*(15.385)*(80.044)*(68.063)*(tcb->m_ssThresh))/0.1);
	segmentsAcked = (int) (63.185*(tcb->m_cWnd)*(47.84)*(65.508)*(33.56)*(19.907)*(77.479)*(-29.93)*(13.039));

}
