int nsuOgmwDSfeXDJNR = (int) 28.294;
int CbhgQXPgMmyhoffp = (int) 48.739;
