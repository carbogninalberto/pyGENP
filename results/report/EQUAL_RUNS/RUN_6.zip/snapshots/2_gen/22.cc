float tPWOYrCfUBznzxnS = (float) (26.469-(83.923)-(-50.007));
tcb->m_cWnd = (int) (66.902*(-54.119)*(-42.452)*(2.933)*(26.428));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (16.303*(-57.667)*(-75.858)*(68.651)*(-45.136));
ReduceCwnd (tcb);
