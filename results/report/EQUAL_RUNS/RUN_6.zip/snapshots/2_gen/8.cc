int rovJReFnMsCdRTyJ = (int) 79.439;
CongestionAvoidance (tcb, segmentsAcked);
rovJReFnMsCdRTyJ = (int) (-96.033+(97.962)+(-16.671)+(95.6)+(-58.54)+(-52.266)+(85.18));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) ((32.707*(15.385)*(80.044)*(68.063)*(tcb->m_ssThresh))/0.1);
	segmentsAcked = (int) (63.185*(tcb->m_cWnd)*(47.84)*(65.508)*(33.56)*(19.907)*(77.479)*(23.159)*(13.039));

} else {
	segmentsAcked = (int) (90.387-(30.8)-(16.721)-(43.769)-(40.411)-(47.963)-(94.942)-(60.058));

}
