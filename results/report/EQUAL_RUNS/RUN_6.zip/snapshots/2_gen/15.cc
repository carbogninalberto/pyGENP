int nsuOgmwDSfeXDJNR = (int) (66.317-(78.68)-(-5.022)-(11.636)-(-85.535));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int CbhgQXPgMmyhoffp = (int) 84.089;
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
