int jOvQzNBbPHaAXBdw = (int) (-95.324/-60.487);
segmentsAcked = (int) (11.054-(30.23)-(-23.521));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (62.925-(-33.219)-(5.881)-(81.217)-(34.748)-(96.029)-(41.942));

}
segmentsAcked = (int) (77.166-(9.093)-(82.678));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (62.925-(30.012)-(5.881)-(81.217)-(34.748)-(96.029)-(-16.417));

}
