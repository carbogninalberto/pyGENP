int nsuOgmwDSfeXDJNR = (int) (24.69-(68.483)-(96.797)-(56.881)-(66.93));
float tHLujyGXvekpZzGY = (float) (-23.188-(67.412)-(-73.898)-(-48.212)-(-56.06)-(-60.284)-(85.271)-(30.484)-(-85.65));
int CbhgQXPgMmyhoffp = (int) 1.953;
