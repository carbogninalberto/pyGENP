int ssaVMGMoUjehYzkU = (int) (46.741-(75.071)-(-23.994)-(-71.538)-(-49.428)-(-95.025)-(90.222)-(-75.941));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-16.841-(-38.315)-(-90.792));
tcb->m_cWnd = (int) (-26.383+(-83.35)+(-99.699)+(82.068)+(37.914)+(-22.458)+(-66.135)+(54.602));
tcb->m_segmentSize = (int) (-5.166-(36.635)-(-56.489));
tcb->m_cWnd = (int) (-66.422+(65.99)+(-53.963)+(59.621)+(97.908)+(-37.924)+(-61.204)+(60.122));
