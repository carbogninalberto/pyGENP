float tPWOYrCfUBznzxnS = (float) (63.291-(-6.323)-(10.241));
tcb->m_cWnd = (int) (7.111*(18.846)*(74.762)*(-7.506)*(73.618));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (52.183*(-85.104)*(-81.04)*(-14.745)*(64.641));
ReduceCwnd (tcb);
