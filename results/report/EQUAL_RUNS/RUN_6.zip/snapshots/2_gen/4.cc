int jOvQzNBbPHaAXBdw = (int) (17.756/-59.131);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (67.801-(-22.305)-(-53.917));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (62.925-(-71.525)-(5.881)-(81.217)-(34.748)-(96.029)-(-30.859));

}
