float tPWOYrCfUBznzxnS = (float) (-41.585-(-82.27)-(-23.035));
tcb->m_cWnd = (int) (-6.951*(30.56)*(-3.011)*(-52.07)*(-11.292));
ReduceCwnd (tcb);
