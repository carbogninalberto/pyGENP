float tPWOYrCfUBznzxnS = (float) (-22.206-(65.803)-(-3.457));
tcb->m_cWnd = (int) (1.705*(-23.711)*(41.284)*(-29.562)*(9.859));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-75.951*(0.476)*(-12.504)*(5.627)*(26.666));
ReduceCwnd (tcb);
