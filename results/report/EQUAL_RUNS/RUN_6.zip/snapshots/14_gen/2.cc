float zhrlTnwaZwZlevid = (float) (38.827/-9.76);
