int sHQpUdDSidJFhXaH = (int) (27.885-(12.588)-(-61.849)-(-71.22)-(96.973)-(64.513));
float zhrlTnwaZwZlevid = (float) (-11.488/87.445);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (23.565-(49.985)-(98.295));

} else {
	tcb->m_cWnd = (int) (79.594+(78.014)+(16.18)+(61.467)+(segmentsAcked)+(45.938)+(77.127)+(27.439)+(23.2));

}
