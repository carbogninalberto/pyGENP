tcb->m_cWnd = (int) (78.228*(-58.177)*(-2.087)*(-20.014)*(-68.419));
float tPWOYrCfUBznzxnS = (float) (42.42-(65.916)-(17.257));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-30.377*(-40.659)*(-41.59)*(-35.943)*(-28.73));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-22.644*(-50.002)*(-78.465)*(-72.795)*(2.784));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (64.143*(15.951)*(-61.322)*(30.124)*(48.806));
ReduceCwnd (tcb);
