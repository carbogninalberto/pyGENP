CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (53.505-(-98.311)-(80.805)-(-22.427)-(-59.423)-(95.734)-(75.213)-(8.506)-(-82.172));
