segmentsAcked = (int) (13.981+(59.646)+(61.837)+(27.791)+(41.678));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (20.537*(16.946)*(16.759)*(79.065)*(2.726)*(tcb->m_ssThresh)*(29.161));
tcb->m_segmentSize = (int) (69.685*(segmentsAcked)*(segmentsAcked)*(tcb->m_cWnd)*(4.642)*(10.665)*(50.445));
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (88.172-(tcb->m_segmentSize)-(32.769)-(30.183)-(14.274)-(68.625));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (11.881-(46.476)-(24.916)-(48.011)-(53.965));

}
