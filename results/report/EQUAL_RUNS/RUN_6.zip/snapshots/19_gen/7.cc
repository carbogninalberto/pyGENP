tcb->m_segmentSize = (int) (68.58+(-77.607)+(-67.743)+(-25.89)+(-10.828)+(-5.957));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (76.018*(59.948)*(47.896)*(69.832)*(21.073)*(86.297)*(96.296));

} else {
	segmentsAcked = (int) ((((tcb->m_segmentSize-(43.727)-(47.293)-(58.839)-(22.677)-(49.806)-(55.4)))+(0.1)+(0.1)+((55.7*(16.491)*(74.627)*(80.189)))+(0.1)+(0.1))/((0.1)+(84.478)));

}
