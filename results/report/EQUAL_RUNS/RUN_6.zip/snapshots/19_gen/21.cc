CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (84.182/0.1);
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	segmentsAcked = (int) (68.149*(47.254)*(51.1)*(5.165)*(88.657)*(tcb->m_cWnd)*(63.937)*(40.268));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) ((52.386*(41.942)*(tcb->m_cWnd)*(16.392))/74.976);

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(17.892)+(segmentsAcked)+(tcb->m_segmentSize)+(segmentsAcked)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (43.981*(tcb->m_cWnd)*(59.466)*(76.675)*(40.958)*(36.045));

} else {
	tcb->m_cWnd = (int) (92.16+(17.216)+(1.487)+(95.88)+(73.509)+(24.42)+(85.858)+(32.453));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (35.167-(93.439)-(5.414));

}
CongestionAvoidance (tcb, segmentsAcked);
