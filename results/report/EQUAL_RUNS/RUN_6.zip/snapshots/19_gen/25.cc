segmentsAcked = (int) (0.1/38.725);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (34.698+(tcb->m_segmentSize)+(15.903)+(43.364)+(83.698)+(56.707)+(tcb->m_ssThresh)+(22.79));

} else {
	segmentsAcked = (int) (0.1/0.1);

}
segmentsAcked = (int) (0.1/0.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_cWnd = (int) (90.431/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) ((((53.259*(40.989)*(69.616)*(85.344)*(segmentsAcked)*(segmentsAcked)*(39.169)*(19.568)))+(0.1)+(0.1)+(0.1))/((25.138)+(0.1)));

}
