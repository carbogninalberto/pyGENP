if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (46.77*(3.601)*(32.831)*(88.525)*(86.526)*(14.982)*(0.316)*(67.851)*(12.732));

} else {
	tcb->m_ssThresh = (int) (88.732*(segmentsAcked)*(23.949)*(tcb->m_cWnd)*(88.75)*(3.711)*(87.355)*(14.115)*(13.681));

}
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(19.766)-(14.142)-(17.599)-(86.362)-(tcb->m_cWnd));
	segmentsAcked = (int) (96.149-(41.475)-(63.813)-(9.448)-(43.201)-(43.158)-(53.344));

} else {
	tcb->m_segmentSize = (int) (29.983*(86.221)*(76.615)*(7.333));
	tcb->m_ssThresh = (int) (62.942*(92.338)*(12.02)*(42.351)*(39.541)*(27.734)*(49.878));
	ReduceCwnd (tcb);

}
if (segmentsAcked > tcb->m_ssThresh) {
	segmentsAcked = (int) (66.579*(tcb->m_ssThresh)*(85.624));
	tcb->m_cWnd = (int) (((99.787)+(67.854)+(14.537)+(47.858)+(19.418)+(0.1)+(29.542))/((0.1)));

} else {
	segmentsAcked = (int) (74.187-(83.509)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(78.315)-(65.686)-(58.978)-(97.689)-(86.586));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (69.594*(tcb->m_segmentSize)*(5.299)*(40.569)*(12.747)*(25.794)*(21.355)*(32.812)*(41.975));
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/85.932);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (((0.1)+(12.966)+(59.265)+(0.1))/((0.1)));

}
