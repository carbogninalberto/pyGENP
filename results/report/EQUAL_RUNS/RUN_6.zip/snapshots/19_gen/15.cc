CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (89.431-(13.222)-(71.879)-(-75.487)-(-7.693)-(20.967)-(-39.314)-(94.905)-(45.216));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-56.885-(50.644)-(-75.405)-(-75.786)-(-25.081)-(7.421)-(5.235)-(-19.892)-(-36.628));
