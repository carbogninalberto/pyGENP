float esCjKYGCVIHWeCBB = (float) (-84.823/-95.524);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(5.955)-(6.522)-(-70.947));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(7.866)+(53.076)+(segmentsAcked)+(37.732)+(57.817)+(segmentsAcked)+(50.745));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (56.991*(34.329)*(tcb->m_segmentSize)*(60.22)*(segmentsAcked)*(65.653));

}
int vOxWFdLdkBQlvzMC = (int) (-70.869*(36.091)*(-53.272)*(-47.21)*(5.69));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd+(81.101)+(39.232));
	tcb->m_cWnd = (int) (0.1/(41.448+(18.522)));

} else {
	segmentsAcked = (int) (15.488+(86.711)+(13.013)+(76.329)+(60.442)+(12.039)+(92.618)+(4.311));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize > tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd+(81.101)+(39.232));
	tcb->m_cWnd = (int) (0.1/(41.448+(18.522)));

} else {
	segmentsAcked = (int) (15.488+(86.711)+(13.013)+(76.329)+(60.442)+(12.039)+(92.618)+(4.311));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
