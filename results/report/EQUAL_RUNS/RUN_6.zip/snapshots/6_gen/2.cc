float tPWOYrCfUBznzxnS = (float) (23.312-(66.484)-(-55.403));
tcb->m_cWnd = (int) (31.931*(71.406)*(-67.081)*(17.371)*(-6.394));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-13.241*(79.452)*(-92.557)*(18.274)*(-14.657));
ReduceCwnd (tcb);
