float fnBMIrgxTUQWtCAG = (float) 58.365;
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

}
segmentsAcked = (int) (-46.362-(-79.569)-(-13.339)-(-66.157)-(97.508)-(14.933));
segmentsAcked = (int) (50.333-(-85.453)-(-2.824)-(43.039)-(3.931)-(-96.677));
