ReduceCwnd (tcb);
tcb->m_cWnd = (int) (58.027*(83.535)*(17.815));
int scQdjtyDHxGseMZS = (int) (((67.918)+(0.1)+((9.756*(52.652)*(11.951)*(46.692)*(tcb->m_segmentSize)))+(0.1)+(0.1))/((0.1)));
tcb->m_cWnd = (int) (42.485-(78.701)-(90.495)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(88.141)-(17.011)-(51.214));
int GVYcILDuwkBYqFKb = (int) (((0.1)+(62.191)+(76.025)+(63.578))/((0.1)+(0.1)));
scQdjtyDHxGseMZS = (int) ((15.718*(30.266))/0.1);
tcb->m_ssThresh = (int) (56.018+(tcb->m_segmentSize)+(tcb->m_cWnd));
tcb->m_segmentSize = (int) ((11.476-(89.026)-(43.834))/0.1);
