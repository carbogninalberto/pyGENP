tcb->m_cWnd = (int) (65.841*(12.643)*(45.223)*(-98.37)*(-35.978));
float tPWOYrCfUBznzxnS = (float) (52.361-(-84.009)-(40.237));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (81.99*(2.995)*(97.543)*(-69.219)*(-66.954));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-71.246*(35.174)*(59.143)*(79.917)*(-15.826));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (29.022*(-52.108)*(75.418)*(-94.181)*(46.966));
ReduceCwnd (tcb);
