float tPWOYrCfUBznzxnS = (float) (25.802-(-18.532)-(82.319));
tcb->m_cWnd = (int) (-83.62*(-99.474)*(-69.395)*(-85.256)*(-26.884));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
