float hxTYeZknNCwSHCiX = (float) (-53.823*(-17.816)*(99.449)*(23.857));
float WPaIXPEgNqZpOaDe = (float) (-41.458*(-20.581)*(34.418)*(29.425)*(-50.188)*(75.011));
tcb->m_cWnd = (int) (30.988*(7.158)*(-73.575)*(21.617)*(85.026)*(18.022)*(33.662)*(-70.945)*(-1.673));
CongestionAvoidance (tcb, segmentsAcked);
