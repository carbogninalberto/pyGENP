segmentsAcked = (int) (9.1/57.554);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (62.358+(35.438)+(12.54)+(16.65));
segmentsAcked = (int) (0.1/81.847);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (87.182-(46.782));
	tcb->m_segmentSize = (int) (78.767+(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(23.571)*(67.885)*(tcb->m_cWnd)*(95.193)*(segmentsAcked)*(97.655)*(32.961)*(77.866));

}
CongestionAvoidance (tcb, segmentsAcked);
