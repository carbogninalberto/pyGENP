segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (2.209-(92.644)-(93.025));
	tcb->m_ssThresh = (int) (13.158-(63.762)-(18.442)-(tcb->m_ssThresh)-(59.313)-(5.269));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (53.954-(62.897)-(55.351)-(27.848)-(66.511)-(2.787)-(27.394)-(66.628)-(70.236));
	tcb->m_cWnd = (int) (90.545-(segmentsAcked)-(tcb->m_cWnd)-(29.451)-(28.669)-(63.914)-(58.523));

}
segmentsAcked = (int) (53.33-(20.541)-(39.661)-(88.638)-(segmentsAcked)-(81.369));
tcb->m_cWnd = (int) (55.264*(40.399));
tcb->m_ssThresh = (int) (20.831+(64.612)+(15.661)+(9.001)+(tcb->m_segmentSize)+(72.41));
