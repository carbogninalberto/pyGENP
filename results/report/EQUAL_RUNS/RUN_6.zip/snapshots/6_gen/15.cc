int pQMVnakyaYkQMPyc = (int) (((84.422)+(0.1)+(99.141)+(0.1)+(0.1)+(76.556))/((0.1)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float vFYMHgkYqlebCDAG = (float) (98.488-(51.767)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(31.419)-(55.618)-(85.291)-(51.066)-(54.142));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (((76.756)+(0.1)+(0.1)+(38.472)+(0.1)+(0.1))/((0.1)+(0.1)));
CongestionAvoidance (tcb, segmentsAcked);
int CVfCUcAbPKNlRUQl = (int) (12.692*(tcb->m_segmentSize)*(67.429)*(16.732)*(96.493)*(93.205)*(pQMVnakyaYkQMPyc)*(51.986));
ReduceCwnd (tcb);
segmentsAcked = (int) (4.319-(76.356)-(68.684));
