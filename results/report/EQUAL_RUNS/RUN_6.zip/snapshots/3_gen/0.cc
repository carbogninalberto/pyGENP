float fnBMIrgxTUQWtCAG = (float) 58.365;
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (89.452-(70.68)-(tcb->m_segmentSize)-(32.032)-(12.796));
	segmentsAcked = (int) (44.837*(51.805)*(tcb->m_segmentSize)*(57.676)*(2.331)*(91.578)*(86.336));

} else {
	segmentsAcked = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (29.233-(-27.37)-(3.718)-(44.169)-(39.15)-(68.631));
