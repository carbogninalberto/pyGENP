if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (83.833+(tcb->m_segmentSize)+(99.405)+(63.125)+(56.829)+(96.431)+(segmentsAcked)+(73.857));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (32.079*(73.334)*(68.464));

} else {
	tcb->m_segmentSize = (int) (34.967+(tcb->m_segmentSize)+(57.157)+(67.583)+(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
