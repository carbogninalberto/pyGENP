float tPWOYrCfUBznzxnS = (float) (57.876-(9.156)-(50.37));
tcb->m_cWnd = (int) (-21.709*(80.203)*(-37.898)*(82.681)*(-59.476));
tcb->m_cWnd = (int) (-50.466*(-64.169)*(-31.411)*(-22.629)*(-87.913));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
