tcb->m_cWnd = (int) (-98.763*(-95.437)*(37.454)*(-74.316)*(99.797));
float tPWOYrCfUBznzxnS = (float) (88.543-(69.877)-(3.771));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (53.65*(41.185)*(65.484)*(-41.775)*(54.703));
ReduceCwnd (tcb);
