CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-41.453-(37.569)-(-16.71));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (62.925-(-71.525)-(5.881)-(81.217)-(34.748)-(96.029)-(-30.859));

}
