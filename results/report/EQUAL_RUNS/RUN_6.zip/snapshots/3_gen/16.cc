int CbhgQXPgMmyhoffp = (int) 1.953;
float tHLujyGXvekpZzGY = (float) (-7.895-(81.189)-(-19.26)-(-43.578)-(46.315)-(76.1)-(-51.95)-(-83.414)-(-34.496));
int nsuOgmwDSfeXDJNR = (int) (-4.793-(-56.057)-(-65.839)-(82.653)-(86.187));
