tcb->m_cWnd = (int) (24.404*(-66.185)*(-2.334)*(76.838)*(-7.56));
float tPWOYrCfUBznzxnS = (float) (39.881-(-6.127)-(-3.251));
ReduceCwnd (tcb);
