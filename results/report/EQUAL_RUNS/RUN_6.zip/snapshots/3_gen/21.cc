float tPWOYrCfUBznzxnS = (float) (-48.227-(-69.043)-(89.994));
tcb->m_cWnd = (int) (-49.869*(39.103)*(32.263)*(-94.884)*(-71.367));
tcb->m_cWnd = (int) (89.985*(96.833)*(3.712)*(-41.925)*(-5.845));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
