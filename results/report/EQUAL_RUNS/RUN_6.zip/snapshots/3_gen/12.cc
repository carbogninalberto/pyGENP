segmentsAcked = (int) (-37.689-(0.366)-(-63.537));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (62.925-(-33.219)-(5.881)-(81.217)-(34.748)-(96.029)-(41.942));

}
segmentsAcked = (int) (-32.558-(-99.909)-(-48.148));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (62.925-(30.012)-(5.881)-(81.217)-(34.748)-(96.029)-(-16.417));

}
