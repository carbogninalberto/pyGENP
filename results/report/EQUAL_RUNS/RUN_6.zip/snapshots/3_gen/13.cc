tcb->m_cWnd = (int) (49.319*(38.933)*(56.757)*(88.649)*(68.929));
float tPWOYrCfUBznzxnS = (float) (96.265-(76.961)-(-42.79));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (21.882*(-56.155)*(19.872)*(50.461)*(54.559));
ReduceCwnd (tcb);
