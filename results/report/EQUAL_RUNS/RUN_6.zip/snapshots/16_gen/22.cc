if (tcb->m_cWnd >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.052*(tcb->m_segmentSize)*(17.993)*(63.32)*(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) (91.533+(tcb->m_cWnd)+(17.965));
	tcb->m_segmentSize = (int) (12.539+(15.395)+(segmentsAcked)+(19.173)+(6.283));

}
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (1.834+(81.501)+(58.171));
	tcb->m_segmentSize = (int) (66.615*(44.503)*(91.478)*(tcb->m_segmentSize)*(37.04)*(59.607)*(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (13.144+(40.415)+(6.534)+(segmentsAcked)+(11.917)+(tcb->m_segmentSize)+(46.923)+(49.214)+(48.335));

}
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (9.926*(72.633)*(5.815)*(56.701)*(84.883)*(tcb->m_ssThresh)*(75.253));

} else {
	tcb->m_cWnd = (int) (33.205*(4.083)*(17.301));
	segmentsAcked = (int) (21.768+(40.321)+(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (14.043*(71.029)*(tcb->m_ssThresh)*(segmentsAcked)*(50.811)*(69.119));

}
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (38.948+(tcb->m_ssThresh)+(tcb->m_cWnd)+(59.103)+(30.378));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(tcb->m_ssThresh)+(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(77.417)*(44.954)*(79.014)*(46.827)*(91.818)*(tcb->m_segmentSize)*(63.432));

}
tcb->m_cWnd = (int) (65.425+(67.04)+(4.732)+(44.274)+(tcb->m_segmentSize)+(81.567)+(53.041));
