if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (47.45*(21.389));
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(52.886)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(2.296)+(segmentsAcked)+(tcb->m_ssThresh)+(40.077)+(1.309));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) ((((61.393+(11.609)+(tcb->m_ssThresh)+(43.698)+(3.59)+(77.402)))+(0.1)+(28.872)+(84.79))/((0.1)+(0.1)));
if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (22.572/0.1);
	tcb->m_segmentSize = (int) (((0.1)+(96.411)+(0.1)+(0.1)+(0.1))/((91.401)+(99.356)+(0.1)+(42.003)));
	tcb->m_ssThresh = (int) (21.421*(52.403)*(segmentsAcked)*(0.968)*(85.373)*(86.613));

} else {
	segmentsAcked = (int) (tcb->m_cWnd+(56.494)+(0.906)+(43.198)+(73.004));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(46.598)-(tcb->m_cWnd));
segmentsAcked = (int) (tcb->m_ssThresh*(63.901)*(76.366)*(36.499)*(segmentsAcked)*(5.422)*(tcb->m_segmentSize)*(74.419));
segmentsAcked = SlowStart (tcb, segmentsAcked);
