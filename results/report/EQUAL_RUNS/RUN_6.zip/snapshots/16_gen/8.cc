float OqCRPGhSRyfuuJYZ = (float) 32.335;
ReduceCwnd (tcb);
segmentsAcked = (int) (((-29.666)+(-14.532)+(78.721)+(96.001)+(-71.69)+(-89.362)+(-72.37)+(34.176))/((8.268)));
if (tcb->m_cWnd <= OqCRPGhSRyfuuJYZ) {
	segmentsAcked = (int) (((73.386)+(0.1)+(58.667)+(43.924)+(0.1))/((0.1)+(0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) ((tcb->m_cWnd-(45.502)-(99.305)-(66.902))/0.1);

}
tcb->m_segmentSize = (int) (61.086*(21.881)*(11.938)*(-89.265)*(23.326)*(24.12)*(17.589)*(0.569));
