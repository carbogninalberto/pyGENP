if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (18.33-(55.284)-(segmentsAcked)-(58.662)-(tcb->m_cWnd)-(21.421)-(91.354)-(75.153)-(71.12));

} else {
	tcb->m_cWnd = (int) (((0.1)+((48.387*(66.483)*(14.884)*(6.434)*(29.527)*(24.265)*(80.421)*(tcb->m_ssThresh)*(45.802)))+((76.645+(59.013)+(30.561)))+((21.672*(25.755)))+(0.1))/((0.1)+(35.184)+(0.1)+(43.068)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (tcb->m_cWnd*(16.808)*(tcb->m_ssThresh)*(42.448)*(8.453)*(segmentsAcked)*(94.961)*(82.648)*(segmentsAcked));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (62.622-(0.143)-(69.312));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (15.166+(43.899)+(14.341)+(88.963));

} else {
	tcb->m_cWnd = (int) (57.455*(63.21)*(segmentsAcked)*(35.583)*(56.753)*(61.324)*(35.735));
	tcb->m_segmentSize = (int) (59.863*(29.661));

}
