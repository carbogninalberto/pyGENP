tcb->m_segmentSize = (int) (94.2/74.128);
tcb->m_segmentSize = (int) (6.949*(8.535)*(85.614)*(83.338)*(91.359)*(segmentsAcked)*(segmentsAcked));
segmentsAcked = (int) (19.696+(83.415)+(tcb->m_ssThresh));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
