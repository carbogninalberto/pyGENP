if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (38.956*(tcb->m_ssThresh)*(22.297)*(70.307)*(54.648)*(5.042)*(tcb->m_ssThresh)*(58.817)*(37.533));
	tcb->m_cWnd = (int) (46.864*(segmentsAcked)*(10.111)*(1.052));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(41.01)-(91.347)-(98.362)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (52.565*(27.099)*(83.917)*(81.453)*(12.413)*(segmentsAcked)*(tcb->m_segmentSize));
	ReduceCwnd (tcb);

}
CongestionAvoidance (tcb, segmentsAcked);
int vtteVOvUjEjbaoWm = (int) (90.993+(39.281));
vtteVOvUjEjbaoWm = (int) (39.389*(53.891));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
