TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (65.659*(72.702)*(13.372)*(50.937));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (21.57-(85.602)-(90.523)-(2.716)-(17.064)-(46.484));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
