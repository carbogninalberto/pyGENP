tcb->m_segmentSize = (int) (25.07-(-33.928)-(74.624));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (56.313-(-76.493)-(80.34));
ReduceCwnd (tcb);
if (segmentsAcked == segmentsAcked) {
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (76.531*(20.476)*(92.072)*(8.252)*(61.167)*(93.762));

}
