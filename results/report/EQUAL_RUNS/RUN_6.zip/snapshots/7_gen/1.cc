float ymXjsRDRAulEFavk = (float) (24.816/-6.586);
int djmxNqYTHRguxDlK = (int) 87.331;
