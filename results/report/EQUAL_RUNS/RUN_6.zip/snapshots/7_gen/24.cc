tcb->m_ssThresh = (int) (77.005-(86.575)-(14.593));
tcb->m_segmentSize = (int) (32.47/0.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	segmentsAcked = (int) (57.18+(69.745)+(71.682)+(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (77.398+(64.452)+(76.775)+(72.47)+(49.143)+(segmentsAcked));

} else {
	segmentsAcked = (int) (segmentsAcked+(16.62)+(74.429)+(79.187)+(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (33.22/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
