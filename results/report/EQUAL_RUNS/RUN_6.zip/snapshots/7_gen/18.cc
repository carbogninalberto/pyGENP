tcb->m_cWnd = (int) (2.733-(54.464)-(40.733)-(1.77));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (32.657/0.1);

} else {
	tcb->m_ssThresh = (int) (12.795*(46.918));
	segmentsAcked = (int) (35.853*(82.632)*(20.219)*(43.278)*(32.132)*(56.797));

}
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((0.1)+(95.061)+(0.1)+(31.827)+(0.1))/((35.764)));

} else {
	tcb->m_segmentSize = (int) (42.047-(27.856)-(47.16)-(22.331)-(69.369)-(segmentsAcked)-(tcb->m_cWnd)-(66.072)-(12.719));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (0.1/0.1);
ReduceCwnd (tcb);
