tcb->m_cWnd = (int) (11.868*(21.097)*(18.678)*(32.707)*(12.116));
float tPWOYrCfUBznzxnS = (float) (58.715-(-6.228)-(44.462));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-70.854*(60.411)*(-50.799)*(82.121)*(-35.277));
tcb->m_cWnd = (int) (-16.729*(-37.057)*(54.799)*(-65.532)*(83.073));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-48.328*(-80.538)*(26.124)*(99.069)*(-87.132));
ReduceCwnd (tcb);
