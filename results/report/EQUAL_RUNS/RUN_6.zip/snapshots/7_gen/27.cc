tcb->m_segmentSize = (int) (55.63*(tcb->m_cWnd)*(90.212)*(37.174));
int AkGKnqjSTImjbrKF = (int) (27.19+(37.13)+(84.955)+(tcb->m_ssThresh));
tcb->m_segmentSize = (int) (73.541*(21.003)*(18.71)*(45.76)*(18.385)*(tcb->m_cWnd)*(86.852));
float QxTICNSeNThkxxjH = (float) ((tcb->m_ssThresh-(13.078))/0.1);
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (35.313+(tcb->m_segmentSize)+(5.434)+(10.011)+(72.436)+(89.979));

} else {
	tcb->m_ssThresh = (int) (56.244-(23.171)-(3.396)-(84.611)-(79.308));

}
