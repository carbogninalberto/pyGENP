ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
int RNXBKUnpezqHwtFL = (int) (86.847-(29.142)-(1.033)-(2.502)-(37.79)-(79.574)-(84.587)-(0.385));
float zhrlTnwaZwZlevid = (float) (9.535/0.1);
float nREiKEvpwSpXzdrQ = (float) (18.046*(23.072)*(15.316)*(93.419)*(72.108)*(RNXBKUnpezqHwtFL)*(26.186)*(71.313));
nREiKEvpwSpXzdrQ = (float) (79.593+(RNXBKUnpezqHwtFL)+(tcb->m_cWnd)+(54.604)+(80.448));
int sPCWUpZFmDwRvIpj = (int) (((0.1)+(0.1)+(81.964)+(80.364))/((5.905)));
tcb->m_ssThresh = (int) (55.369*(73.592)*(54.524)*(72.55)*(sPCWUpZFmDwRvIpj)*(10.428)*(81.942));
