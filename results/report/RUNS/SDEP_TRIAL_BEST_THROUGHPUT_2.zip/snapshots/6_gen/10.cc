int EovJcrtBLhDBKGpO = (int) 81.929;
tcb->m_segmentSize = (int) (20.292*(-66.68)*(-88.002)*(85.706)*(31.937));
segmentsAcked = (int) ((-80.986*(81.116))/(-8.217+(53.501)+(99.619)));
