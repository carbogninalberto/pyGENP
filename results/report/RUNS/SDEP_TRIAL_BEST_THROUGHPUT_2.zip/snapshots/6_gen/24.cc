tcb->m_cWnd = (int) (73.302-(21.188));
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) (79.887-(71.543)-(83.014)-(tcb->m_segmentSize)-(36.743)-(65.587)-(3.631));

} else {
	segmentsAcked = (int) ((((segmentsAcked-(5.954)-(tcb->m_segmentSize)-(99.996)-(95.746)-(18.458)-(segmentsAcked)-(72.555)-(46.767)))+(0.1)+(47.09)+(0.1))/((0.1)+(62.773)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(98.009)*(tcb->m_segmentSize)*(16.582)*(29.89)*(11.175)*(63.882)*(90.434)*(0.738));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (56.276-(12.675));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (53.17*(70.466)*(39.481)*(tcb->m_segmentSize)*(9.268)*(83.213));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) ((((segmentsAcked-(5.954)-(tcb->m_segmentSize)-(99.996)-(95.746)-(18.458)-(segmentsAcked)-(72.555)-(46.767)))+(0.1)+(47.09)+(0.1))/((0.1)+(62.773)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(98.009)*(tcb->m_segmentSize)*(16.582)*(29.89)*(11.175)*(63.882)*(90.434)*(0.738));

} else {
	segmentsAcked = (int) (79.887-(71.543)-(83.014)-(tcb->m_segmentSize)-(36.743)-(65.587)-(3.631));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (92.651+(99.008));
ReduceCwnd (tcb);
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) ((((segmentsAcked-(5.954)-(tcb->m_segmentSize)-(99.996)-(95.746)-(18.458)-(segmentsAcked)-(72.555)-(46.767)))+(0.1)+(47.09)+(0.1))/((0.1)+(62.773)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(98.009)*(tcb->m_segmentSize)*(16.582)*(29.89)*(11.175)*(63.882)*(90.434)*(0.738));

} else {
	segmentsAcked = (int) (79.887-(71.543)-(83.014)-(tcb->m_segmentSize)-(36.743)-(53.96)-(3.631));

}
tcb->m_segmentSize = (int) (73.551+(-38.92));
tcb->m_segmentSize = (int) (97.683+(-99.082));
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) ((((segmentsAcked-(5.954)-(tcb->m_segmentSize)-(99.996)-(95.746)-(18.458)-(segmentsAcked)-(72.555)-(46.767)))+(0.1)+(47.09)+(0.1))/((0.1)+(62.773)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(98.009)*(tcb->m_segmentSize)*(16.582)*(29.89)*(11.175)*(63.882)*(90.434)*(0.738));

} else {
	segmentsAcked = (int) (79.887-(71.543)-(83.014)-(tcb->m_segmentSize)-(36.743)-(53.96)-(3.631));

}
tcb->m_segmentSize = (int) (-27.164+(71.129));
tcb->m_segmentSize = (int) (16.059+(-5.294));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (53.17*(70.466)*(39.481)*(tcb->m_segmentSize)*(9.268)*(83.213));

} else {
	tcb->m_segmentSize = (int) (56.276-(12.675));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (54.3+(18.233));
tcb->m_segmentSize = (int) (-74.872+(95.777));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (53.17*(70.466)*(39.481)*(tcb->m_segmentSize)*(9.268)*(83.213));

} else {
	tcb->m_segmentSize = (int) (56.276-(12.675));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (53.17*(70.466)*(39.481)*(tcb->m_segmentSize)*(9.268)*(83.213));

} else {
	tcb->m_segmentSize = (int) (56.276-(12.675));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (-94.253+(-24.224));
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) ((((segmentsAcked-(5.954)-(tcb->m_segmentSize)-(99.996)-(95.746)-(18.458)-(segmentsAcked)-(72.555)-(46.767)))+(0.1)+(47.09)+(0.1))/((0.1)+(62.773)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(98.009)*(tcb->m_segmentSize)*(16.582)*(29.89)*(11.175)*(63.882)*(90.434)*(0.738));

} else {
	segmentsAcked = (int) (79.887-(71.543)-(83.014)-(tcb->m_segmentSize)-(36.743)-(53.96)-(3.631));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (53.17*(70.466)*(39.481)*(tcb->m_segmentSize)*(9.268)*(83.213));

} else {
	tcb->m_segmentSize = (int) (56.276-(12.675));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) ((((segmentsAcked-(5.954)-(tcb->m_segmentSize)-(99.996)-(95.746)-(18.458)-(segmentsAcked)-(72.555)-(46.767)))+(0.1)+(47.09)+(0.1))/((0.1)+(62.773)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(98.009)*(tcb->m_segmentSize)*(16.582)*(29.89)*(11.175)*(63.882)*(90.434)*(0.738));

} else {
	segmentsAcked = (int) (79.887-(71.543)-(83.014)-(tcb->m_segmentSize)-(36.743)-(53.96)-(3.631));

}
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) ((((segmentsAcked-(5.954)-(tcb->m_segmentSize)-(99.996)-(95.746)-(18.458)-(segmentsAcked)-(72.555)-(46.767)))+(0.1)+(47.09)+(0.1))/((0.1)+(62.773)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(98.009)*(tcb->m_segmentSize)*(16.582)*(29.89)*(11.175)*(63.882)*(90.434)*(0.738));

} else {
	segmentsAcked = (int) (79.887-(71.543)-(83.014)-(tcb->m_segmentSize)-(36.743)-(53.96)-(3.631));

}
tcb->m_segmentSize = (int) (20.473+(-26.301));
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) ((((segmentsAcked-(5.954)-(tcb->m_segmentSize)-(99.996)-(95.746)-(18.458)-(segmentsAcked)-(72.555)-(46.767)))+(0.1)+(47.09)+(0.1))/((0.1)+(62.773)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(98.009)*(tcb->m_segmentSize)*(16.582)*(29.89)*(11.175)*(63.882)*(90.434)*(0.738));

} else {
	segmentsAcked = (int) (79.887-(71.543)-(83.014)-(tcb->m_segmentSize)-(36.743)-(53.96)-(3.631));

}
tcb->m_segmentSize = (int) (-86.065+(-37.204));
tcb->m_segmentSize = (int) (76.201+(-8.669));
tcb->m_segmentSize = (int) (-32.824+(50.219));
