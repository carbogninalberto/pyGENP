segmentsAcked = (int) (-35.99+(-88.457)+(20.729)+(70.214)+(-87.111));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (((9.759)+(-76.133)+(-37.451)+(-72.896))/((-52.853)+(30.974)+(-18.941)));
