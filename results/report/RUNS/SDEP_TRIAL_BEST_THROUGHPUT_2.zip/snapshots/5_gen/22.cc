int YILtaSvjXGaUrvme = (int) (95.098+(46.363)+(-37.573)+(6.364)+(-89.141)+(88.108)+(-46.566));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) ((((2.838-(-95.331)-(-25.224)-(YILtaSvjXGaUrvme)))+((21.488-(25.062)-(58.42)-(-72.09)))+(35.832)+(-23.523))/((-42.667)+(30.743)+(-59.701)));
CongestionAvoidance (tcb, segmentsAcked);
