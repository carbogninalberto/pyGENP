int fqiHlURmZBZeWdNG = (int) (-14.851/63.022);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (9.039*(fqiHlURmZBZeWdNG)*(71.155)*(48.247)*(7.726));
	tcb->m_segmentSize = (int) (43.666+(37.25)+(-19.375)+(80.54)+(0.209));
	tcb->m_segmentSize = (int) (27.757-(73.073));

} else {
	segmentsAcked = (int) (39.456+(20.807)+(65.726)+(99.267));

}
