if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (56.276-(12.675));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (53.17*(70.466)*(39.481)*(tcb->m_segmentSize)*(9.268)*(83.213));

}
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) ((((segmentsAcked-(5.954)-(tcb->m_segmentSize)-(99.996)-(95.746)-(18.458)-(segmentsAcked)-(72.555)-(46.767)))+(0.1)+(47.09)+(0.1))/((0.1)+(62.773)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(98.009)*(tcb->m_segmentSize)*(16.582)*(29.89)*(11.175)*(63.882)*(90.434)*(0.738));

} else {
	segmentsAcked = (int) (79.887-(71.543)-(83.014)-(tcb->m_segmentSize)-(36.743)-(65.587)-(3.631));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (98.649+(-39.809));
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) ((((segmentsAcked-(5.954)-(tcb->m_segmentSize)-(99.996)-(95.746)-(18.458)-(segmentsAcked)-(72.555)-(46.767)))+(0.1)+(47.09)+(0.1))/((0.1)+(62.773)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(98.009)*(tcb->m_segmentSize)*(16.582)*(29.89)*(11.175)*(63.882)*(90.434)*(0.738));

} else {
	segmentsAcked = (int) (79.887-(71.543)-(83.014)-(tcb->m_segmentSize)-(36.743)-(53.96)-(3.631));

}
tcb->m_segmentSize = (int) (10.455+(-34.637));
tcb->m_segmentSize = (int) (34.896+(46.412));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (53.17*(70.466)*(39.481)*(tcb->m_segmentSize)*(9.268)*(83.213));

} else {
	tcb->m_segmentSize = (int) (56.276-(12.675));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (-0.717+(-33.606));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (53.17*(70.466)*(39.481)*(tcb->m_segmentSize)*(9.268)*(83.213));

} else {
	tcb->m_segmentSize = (int) (56.276-(12.675));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) ((((segmentsAcked-(5.954)-(tcb->m_segmentSize)-(99.996)-(95.746)-(18.458)-(segmentsAcked)-(72.555)-(46.767)))+(0.1)+(47.09)+(0.1))/((0.1)+(62.773)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(98.009)*(tcb->m_segmentSize)*(16.582)*(29.89)*(11.175)*(63.882)*(90.434)*(0.738));

} else {
	segmentsAcked = (int) (79.887-(71.543)-(83.014)-(tcb->m_segmentSize)-(36.743)-(53.96)-(3.631));

}
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) ((((segmentsAcked-(5.954)-(tcb->m_segmentSize)-(99.996)-(95.746)-(18.458)-(segmentsAcked)-(72.555)-(46.767)))+(0.1)+(47.09)+(0.1))/((0.1)+(62.773)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(98.009)*(tcb->m_segmentSize)*(16.582)*(29.89)*(11.175)*(63.882)*(90.434)*(0.738));

} else {
	segmentsAcked = (int) (79.887-(71.543)-(83.014)-(tcb->m_segmentSize)-(36.743)-(53.96)-(3.631));

}
tcb->m_segmentSize = (int) (72.683+(-82.444));
tcb->m_segmentSize = (int) (-54.495+(38.655));
