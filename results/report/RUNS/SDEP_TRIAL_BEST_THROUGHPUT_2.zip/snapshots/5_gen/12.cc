int DgDphvzGFfeNHisY = (int) 43.248;
float CEAogErjKXHhiYtM = (float) 44.77;
