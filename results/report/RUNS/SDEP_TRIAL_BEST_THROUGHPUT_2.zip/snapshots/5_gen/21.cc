int tfdMLdxODEbnKtWf = (int) (((94.507)+((-81.643+(-79.042)+(-92.554)+(66.738)))+(28.506)+(-49.854)+(75.294)+(43.198))/((-63.896)+(-59.592)));
if (tfdMLdxODEbnKtWf != tcb->m_cWnd) {
	segmentsAcked = (int) (14.108*(segmentsAcked)*(39.92)*(4.08)*(95.006));

} else {
	segmentsAcked = (int) (58.398*(66.222)*(5.219)*(66.505)*(tcb->m_cWnd)*(7.42)*(27.579)*(56.455)*(87.814));

}
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+(28.016)+((35.097-(segmentsAcked)-(29.302)-(9.681)-(78.412)-(67.219)-(60.957)-(tcb->m_segmentSize)-(18.181)))+(54.649)+(0.1))/((76.698)+(0.1)));
	segmentsAcked = (int) (66.998+(85.024)+(32.417)+(19.893)+(17.073));

} else {
	tcb->m_segmentSize = (int) (63.459/0.1);
	segmentsAcked = (int) (segmentsAcked+(42.892)+(6.933)+(segmentsAcked)+(71.778)+(4.676)+(47.294)+(34.9));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tfdMLdxODEbnKtWf = (int) (((-16.825)+((44.78*(-23.704)*(-49.431)*(30.485)*(segmentsAcked)*(tcb->m_cWnd)*(-81.398)*(14.908)))+(86.119)+((-65.75+(-12.179)+(48.201)+(39.066)+(9.958)))+(-59.688)+(52.645)+(-40.57))/((-52.201)));
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+(28.016)+((35.097-(segmentsAcked)-(29.302)-(9.681)-(78.412)-(67.219)-(60.957)-(tcb->m_segmentSize)-(18.181)))+(54.649)+(0.1))/((76.698)+(0.1)));
	segmentsAcked = (int) (66.998+(85.024)+(32.417)+(19.893)+(17.073));

} else {
	tcb->m_segmentSize = (int) (63.459/0.1);
	segmentsAcked = (int) (segmentsAcked+(42.892)+(6.933)+(segmentsAcked)+(71.778)+(4.676)+(47.294)+(34.9));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (-97.726*(-69.551));
tfdMLdxODEbnKtWf = (int) (((98.033)+((20.4*(-82.898)*(42.928)*(-27.76)*(segmentsAcked)*(tcb->m_cWnd)*(-67.856)*(-73.429)))+(-86.676)+((-61.232+(44.966)+(-43.045)+(95.009)+(48.097)))+(74.887)+(48.698)+(-65.62))/((-87.678)));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (48.074*(-95.555));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
