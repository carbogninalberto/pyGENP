int YILtaSvjXGaUrvme = (int) (-95.203+(4.548)+(38.795)+(-85.793)+(30.84)+(-92.74)+(89.428));
if (segmentsAcked != segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(80.479)-(23.644)-(94.42)-(49.394)-(42.549)-(90.979));
	tcb->m_segmentSize = (int) (25.637+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(38.068)-(64.768)-(YILtaSvjXGaUrvme)-(25.554)-(56.075)-(69.545));
	YILtaSvjXGaUrvme = (int) (92.87+(70.673));
	tcb->m_cWnd = (int) (3.014-(70.841)-(22.08)-(88.45)-(5.836));

}
ReduceCwnd (tcb);
