if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+(28.016)+((35.097-(segmentsAcked)-(29.302)-(9.681)-(78.412)-(67.219)-(60.957)-(tcb->m_segmentSize)-(18.181)))+(54.649)+(0.1))/((76.698)+(0.1)));
	segmentsAcked = (int) (66.998+(85.024)+(32.417)+(19.893)+(17.073));

} else {
	tcb->m_segmentSize = (int) (63.459/0.1);
	segmentsAcked = (int) (segmentsAcked+(42.892)+(6.933)+(segmentsAcked)+(71.778)+(4.676)+(47.294)+(34.9));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
