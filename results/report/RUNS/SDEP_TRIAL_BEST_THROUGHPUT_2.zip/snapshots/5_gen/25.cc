TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (25.256-(-39.509)-(-83.008)-(-51.987));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-26.44*(26.619)*(6.919));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (35.702*(3.773)*(-44.35));
ReduceCwnd (tcb);
