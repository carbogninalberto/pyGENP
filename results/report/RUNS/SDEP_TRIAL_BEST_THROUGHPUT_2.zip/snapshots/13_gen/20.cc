ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (17.903*(tcb->m_cWnd)*(16.488));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(85.777)*(94.045)*(75.959)*(65.348)*(tcb->m_ssThresh));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (64.196-(12.897)-(segmentsAcked));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_ssThresh) {
	segmentsAcked = (int) (74.428*(74.764)*(71.018)*(32.682)*(tcb->m_cWnd));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (37.047+(53.279)+(25.481));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (62.533*(64.051)*(56.692)*(81.802)*(segmentsAcked));
segmentsAcked = SlowStart (tcb, segmentsAcked);
