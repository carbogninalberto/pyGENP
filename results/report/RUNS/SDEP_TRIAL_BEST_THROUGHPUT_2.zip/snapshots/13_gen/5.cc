tcb->m_segmentSize = (int) (-67.239-(20.714)-(-78.273));
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (76.693-(tcb->m_cWnd)-(45.137)-(75.086)-(segmentsAcked)-(42.358)-(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (65.26-(segmentsAcked)-(33.428)-(69.313)-(17.518)-(80.071)-(82.853)-(69.346));

} else {
	segmentsAcked = (int) (3.0-(tcb->m_segmentSize)-(92.85));
	tcb->m_segmentSize = (int) (10.128-(88.297));

}
