if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (34.869-(27.736)-(44.589)-(2.577)-(14.017)-(39.826));
	tcb->m_ssThresh = (int) (21.887/0.1);

} else {
	tcb->m_cWnd = (int) (67.52+(53.869));
	segmentsAcked = (int) (41.694-(8.429)-(49.072)-(72.911)-(58.3)-(74.465));

}
tcb->m_segmentSize = (int) (69.71-(91.186)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(44.504)-(78.187));
float hqCIyFXuCAJEltCY = (float) (29.892-(78.622)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(43.14)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(7.118));
int ZgdCSipOiZduLTCy = (int) (26.644+(tcb->m_segmentSize)+(tcb->m_cWnd)+(36.611)+(91.711)+(31.43));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((0.1)+((12.699+(33.71)+(16.189)))+(54.659)+(75.089))/((0.1)+(0.1)+(43.841)));

} else {
	tcb->m_ssThresh = (int) (94.36+(hqCIyFXuCAJEltCY));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (62.923-(25.754)-(88.625)-(83.039)-(81.788)-(48.01)-(50.836)-(75.135)-(33.259));

}
