if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (((50.294)+(55.675)+(0.1)+(27.933))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (70.187-(74.273)-(35.714)-(31.81));
	tcb->m_cWnd = (int) ((82.216+(75.284)+(tcb->m_ssThresh)+(tcb->m_cWnd))/38.686);

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (41.694*(87.598)*(51.478)*(36.238)*(-49.042)*(1.084)*(43.223)*(48.439)*(tcb->m_cWnd));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (41.972-(81.31));

} else {
	tcb->m_cWnd = (int) ((5.637+(40.692)+(52.376)+(tcb->m_ssThresh)+(20.196))/59.203);

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (((-40.6)+((72.409-(-32.0)-(tcb->m_ssThresh)-(-57.306)-(-21.025)))+(59.476)+(-12.061))/((-7.772)+(49.103)+(-65.754)));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (41.694*(87.598)*(26.904)*(36.238)*(84.419)*(1.084)*(-33.874)*(48.439)*(tcb->m_cWnd));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (41.972-(81.31));

} else {
	tcb->m_cWnd = (int) ((5.637+(40.692)+(52.376)+(tcb->m_ssThresh)+(20.196))/59.203);

}
tcb->m_cWnd = (int) (((-98.528)+((37.011-(-8.801)-(tcb->m_ssThresh)-(-39.647)-(-74.909)))+(-77.79)+(-88.269))/((-24.457)+(-95.966)+(9.271)));
