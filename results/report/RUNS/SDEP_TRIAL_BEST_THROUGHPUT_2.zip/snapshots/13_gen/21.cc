if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((51.853)+(52.068)+((21.49-(72.447)-(22.761)-(segmentsAcked)-(84.374)-(88.588)-(51.302)-(29.401)))+(44.095)+(2.148)+(0.1)+(0.1))/((0.1)+(0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (77.267-(55.681)-(24.175)-(38.749)-(tcb->m_cWnd));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (segmentsAcked-(57.684)-(19.319)-(67.949)-(97.078)-(24.521)-(98.493));

}
if (tcb->m_cWnd != tcb->m_cWnd) {
	segmentsAcked = (int) (49.523*(55.738)*(tcb->m_cWnd)*(19.307)*(98.7)*(31.065)*(segmentsAcked));

} else {
	segmentsAcked = (int) (38.641-(81.683)-(69.27)-(18.251)-(26.37)-(36.934)-(24.153)-(8.885)-(95.042));

}
tcb->m_segmentSize = (int) (62.122*(segmentsAcked)*(25.067));
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_segmentSize = (int) (65.303+(53.574)+(81.191)+(97.838)+(89.145)+(47.622)+(76.131)+(30.95));
	tcb->m_ssThresh = (int) (48.414+(56.42)+(71.735));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (34.122*(76.115)*(segmentsAcked));
	tcb->m_cWnd = (int) (20.835+(88.67)+(68.054));
	tcb->m_cWnd = (int) (0.1/0.1);

}
tcb->m_ssThresh = (int) (((25.011)+(0.1)+((tcb->m_cWnd*(78.726)))+(98.261))/((0.1)+(0.1)+(0.1)));
tcb->m_ssThresh = (int) (41.735-(22.266)-(tcb->m_ssThresh)-(47.462)-(19.138)-(82.367));
