tcb->m_segmentSize = (int) (26.755*(tcb->m_cWnd)*(73.284)*(3.816)*(tcb->m_cWnd)*(42.7)*(32.496)*(segmentsAcked));
if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (34.276-(46.971)-(12.876)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (12.837*(91.858)*(35.461)*(38.562)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(34.137)*(25.984)*(92.119));

} else {
	tcb->m_ssThresh = (int) (2.937*(29.175)*(21.59)*(90.083));
	tcb->m_segmentSize = (int) (68.189*(segmentsAcked)*(68.794)*(31.337));

}
float VhxSPEhmMvgNFDpY = (float) (tcb->m_cWnd*(65.577)*(32.668)*(tcb->m_ssThresh)*(88.017)*(segmentsAcked)*(59.996));
if (VhxSPEhmMvgNFDpY != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) ((((tcb->m_segmentSize+(tcb->m_ssThresh)+(segmentsAcked)+(6.38)+(44.616)))+(65.137)+(0.1)+(55.272))/((81.766)+(0.1)+(74.078)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked*(89.928)*(56.237)*(9.583));

}
VhxSPEhmMvgNFDpY = (float) ((16.798*(19.688)*(72.313)*(51.267)*(23.977))/0.1);
if (tcb->m_segmentSize == VhxSPEhmMvgNFDpY) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(81.416)*(84.38)*(71.007)*(VhxSPEhmMvgNFDpY)*(60.75));

} else {
	tcb->m_segmentSize = (int) ((50.986*(54.757)*(99.947)*(41.553))/16.936);
	VhxSPEhmMvgNFDpY = (float) (28.629/0.1);

}
