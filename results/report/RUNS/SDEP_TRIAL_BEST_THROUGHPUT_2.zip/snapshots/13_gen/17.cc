TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int wQtOPSkAXKZCCgyw = (int) (11.844+(segmentsAcked)+(segmentsAcked));
tcb->m_cWnd = (int) (67.161*(49.906)*(37.626)*(97.344)*(17.7)*(47.168)*(56.037)*(tcb->m_segmentSize)*(80.654));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
