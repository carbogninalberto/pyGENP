tcb->m_cWnd = (int) (-91.705+(52.668)+(60.136)+(46.208)+(52.223)+(3.387));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (70.187-(74.273)-(35.714)-(31.81));
	tcb->m_cWnd = (int) ((82.216+(75.284)+(tcb->m_ssThresh)+(tcb->m_cWnd))/38.686);

} else {
	tcb->m_segmentSize = (int) (((50.294)+(55.675)+(0.1)+(27.933))/((0.1)+(0.1)));

}
