tcb->m_cWnd = (int) (24.406*(tcb->m_cWnd)*(73.242)*(39.123));
tcb->m_segmentSize = (int) (13.464*(47.938)*(29.848)*(10.236)*(42.994)*(3.681)*(54.913)*(segmentsAcked));
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (44.714-(segmentsAcked));
	tcb->m_segmentSize = (int) (segmentsAcked*(tcb->m_ssThresh));
	segmentsAcked = (int) (tcb->m_cWnd*(22.904)*(80.144)*(tcb->m_cWnd)*(1.742)*(61.78));

} else {
	tcb->m_cWnd = (int) ((((88.39+(77.948)+(91.167)+(69.67)+(25.354)+(tcb->m_segmentSize)+(84.541)+(8.422)))+(0.1)+(76.009)+(53.215)+(59.251)+((26.99-(91.901)-(85.22)-(tcb->m_ssThresh)-(33.317)-(87.847)))+(6.453)+(32.377))/((36.914)));
	tcb->m_segmentSize = (int) (18.69*(47.738)*(41.864));
	ReduceCwnd (tcb);

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) ((14.995*(2.802)*(87.488))/42.836);
	tcb->m_cWnd = (int) (segmentsAcked-(18.872));
	tcb->m_segmentSize = (int) (37.358+(40.332)+(60.864)+(76.074)+(74.764)+(25.105)+(88.371));

} else {
	tcb->m_ssThresh = (int) ((((tcb->m_ssThresh-(89.74)-(39.06)-(tcb->m_ssThresh)-(47.058)))+(0.1)+((tcb->m_ssThresh*(53.339)*(5.35)))+(18.08))/((86.654)+(17.23)+(21.302)+(37.764)+(74.542)));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
