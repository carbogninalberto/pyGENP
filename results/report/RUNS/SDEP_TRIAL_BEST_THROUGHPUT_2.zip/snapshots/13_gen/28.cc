tcb->m_ssThresh = (int) (22.792-(33.269)-(43.301)-(47.128)-(31.245)-(39.432)-(70.868));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
float jeQFgpNvwmYRRpjQ = (float) (31.907/97.135);
float EKEsVknSgSRzmECb = (float) (2.664*(jeQFgpNvwmYRRpjQ)*(tcb->m_cWnd)*(37.719)*(55.862)*(segmentsAcked)*(24.974));
tcb->m_cWnd = (int) (47.997+(EKEsVknSgSRzmECb)+(96.063));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
