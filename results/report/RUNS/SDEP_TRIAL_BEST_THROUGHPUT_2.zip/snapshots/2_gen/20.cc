CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (31.531-(32.078)-(9.123)-(-91.741)-(-33.25));
segmentsAcked = (int) (((-95.349)+(29.985)+(46.044)+(87.799)+(-96.271)+(-38.45))/((-35.295)));
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(segmentsAcked)+(56.196)+(42.031)+(95.549)+(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (97.43-(54.965)-(80.102)-(tcb->m_cWnd)-(74.982)-(85.111)-(40.295)-(71.103));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (58.098/0.1);

}
tcb->m_segmentSize = (int) (-41.244-(70.474)-(-9.108));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (50.132*(segmentsAcked)*(78.781)*(35.298)*(12.911)*(4.827));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (59.788+(47.917)+(29.661)+(30.664));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
