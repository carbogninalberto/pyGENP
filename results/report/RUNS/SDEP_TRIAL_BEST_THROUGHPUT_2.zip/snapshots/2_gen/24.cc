CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (1.319-(51.087)-(18.612));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (10.729-(-75.723)-(-15.589));
