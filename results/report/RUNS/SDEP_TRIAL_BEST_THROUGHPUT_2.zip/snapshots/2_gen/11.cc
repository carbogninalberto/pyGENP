int txXGzsFvOOIYjHas = (int) (23.255+(-44.814));
float HXpfapcziBKzJcPA = (float) 5.251;
