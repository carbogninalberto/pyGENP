float LqDAxjRogGPXcTOl = (float) 61.618;
LqDAxjRogGPXcTOl = (float) (-44.773-(-38.21)-(-68.194)-(-52.214));
tcb->m_segmentSize = (int) (-13.057*(-9.716)*(-85.071)*(7.516)*(47.207)*(89.195));
LqDAxjRogGPXcTOl = (float) (21.297-(14.001)-(7.318)-(49.237));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
LqDAxjRogGPXcTOl = (float) (-59.684-(60.166)-(31.82)-(40.806));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
