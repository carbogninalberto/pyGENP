TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (43.044-(-54.054)-(33.541)-(-48.033));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (67.658*(54.452)*(99.639));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-42.329*(19.637)*(87.942));
ReduceCwnd (tcb);
