float LqDAxjRogGPXcTOl = (float) 0.452;
LqDAxjRogGPXcTOl = (float) (51.968-(-54.577)-(38.286)-(-95.186));
