float iTCaEpDdfaVqCBIS = (float) (83.803/40.609);
int gKhqlskRrYyZCaVY = (int) (((-93.1)+((18.631*(-92.741)*(-74.591)*(78.015)*(2.186)*(74.498)*(-56.464)))+(57.901)+(62.96))/((25.699)+(94.133)));
int SZOFaMQZuPXRUHjX = (int) (71.687*(-30.007)*(32.572)*(92.747)*(36.342)*(55.201)*(-11.065)*(-90.786)*(85.847));
if (gKhqlskRrYyZCaVY >= gKhqlskRrYyZCaVY) {
	gKhqlskRrYyZCaVY = (int) ((14.884*(SZOFaMQZuPXRUHjX)*(23.397)*(49.434)*(tcb->m_cWnd)*(segmentsAcked)*(34.583))/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	gKhqlskRrYyZCaVY = (int) (51.397*(30.243)*(tcb->m_segmentSize)*(61.775)*(77.885));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (-70.18-(-61.547)-(-94.24));
