tcb->m_cWnd = (int) (41.517/-78.944);
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	segmentsAcked = (int) (30.159/0.1);

} else {
	segmentsAcked = (int) ((((12.563*(tcb->m_ssThresh)*(tcb->m_cWnd)*(62.8)*(tcb->m_cWnd)*(93.502)))+(62.73)+((tcb->m_segmentSize-(92.809)-(13.747)-(71.905)-(94.515)-(86.48)))+(0.1)+(30.674))/((94.041)));
	tcb->m_cWnd = (int) (27.26-(94.887)-(13.255)-(66.067));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
