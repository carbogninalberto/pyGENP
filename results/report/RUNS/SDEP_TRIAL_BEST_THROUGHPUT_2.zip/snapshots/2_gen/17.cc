CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (87.571-(-44.97)-(99.771)-(8.567)-(89.496));
segmentsAcked = (int) (((-63.8)+(-75.348)+(25.993)+(-24.496)+(86.504)+(24.773))/((5.691)));
