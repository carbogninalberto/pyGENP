float HXpfapcziBKzJcPA = (float) (20.532*(45.796)*(-12.553)*(75.122)*(36.026)*(12.548));
segmentsAcked = (int) (2.402-(24.707)-(-56.065)-(70.873)-(38.735)-(98.997)-(98.042)-(-4.636));
float EoMLISlvkskKPall = (float) 87.91;
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
EoMLISlvkskKPall = (float) (-71.711/35.441);
