TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (38.268-(-67.194)-(68.535)-(81.731));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (13.384*(-98.753)*(77.946));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-5.922*(35.418)*(-47.79));
ReduceCwnd (tcb);
