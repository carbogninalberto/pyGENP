int YILtaSvjXGaUrvme = (int) 94.151;
ReduceCwnd (tcb);
