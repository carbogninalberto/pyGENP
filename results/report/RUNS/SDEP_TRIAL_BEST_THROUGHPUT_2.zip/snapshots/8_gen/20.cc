CongestionAvoidance (tcb, segmentsAcked);
float qcfAIyYmRpoTLYfp = (float) (((0.1)+(61.458)+(0.1)+(0.1)+(88.688)+(0.1)+(0.1))/((77.996)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (78.523*(42.412));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (segmentsAcked*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(35.804)*(32.599)*(15.128));
	CongestionAvoidance (tcb, segmentsAcked);

}
qcfAIyYmRpoTLYfp = (float) (37.054-(65.44)-(22.237)-(tcb->m_segmentSize)-(13.737)-(60.289)-(82.153)-(40.093)-(87.054));
