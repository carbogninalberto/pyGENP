tcb->m_cWnd = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(tcb->m_segmentSize)*(94.495)*(55.898)*(27.142)*(tcb->m_segmentSize));
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (69.617+(88.912)+(63.207)+(7.046)+(1.203)+(56.974)+(43.639)+(tcb->m_cWnd)+(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (10.78+(37.603)+(73.933)+(46.603)+(2.448)+(53.481)+(99.488)+(35.412));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = (int) (86.494*(tcb->m_cWnd)*(84.706)*(tcb->m_ssThresh));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < segmentsAcked) {
	segmentsAcked = (int) (48.217*(52.355));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (63.811+(tcb->m_ssThresh)+(99.331)+(74.052)+(97.672)+(39.656)+(segmentsAcked)+(65.41)+(tcb->m_ssThresh));

}
