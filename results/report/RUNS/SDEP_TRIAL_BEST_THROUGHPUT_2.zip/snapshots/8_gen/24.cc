tcb->m_segmentSize = (int) (37.929+(tcb->m_cWnd)+(76.643)+(57.425)+(segmentsAcked)+(48.08)+(90.568));
float aLKqpRGFiAPqhXjN = (float) (7.377-(15.171)-(segmentsAcked)-(39.311)-(16.455)-(12.293)-(21.25));
tcb->m_segmentSize = (int) (95.135+(25.85)+(tcb->m_segmentSize)+(aLKqpRGFiAPqhXjN)+(27.767)+(segmentsAcked));
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (66.827*(40.724)*(60.413)*(5.293));

} else {
	tcb->m_segmentSize = (int) (69.973-(17.34)-(65.645)-(96.98)-(42.492)-(95.972)-(22.685)-(35.585)-(aLKqpRGFiAPqhXjN));
	tcb->m_cWnd = (int) (78.137+(2.139)+(47.796));
	aLKqpRGFiAPqhXjN = (float) (tcb->m_cWnd*(37.479)*(tcb->m_ssThresh)*(33.026)*(3.249)*(10.119)*(tcb->m_ssThresh)*(43.779));

}
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	segmentsAcked = (int) (75.751*(tcb->m_segmentSize)*(52.694)*(63.082)*(10.951)*(27.295)*(70.737)*(20.047));
	tcb->m_cWnd = (int) (62.314+(15.582)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(42.688)+(38.613));

} else {
	segmentsAcked = (int) (segmentsAcked*(67.572)*(52.216)*(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (68.627-(27.306)-(77.058));

}
float ggxPYODjgHUwLUpq = (float) (87.145-(6.911)-(36.71)-(71.059)-(19.479)-(64.357)-(85.979)-(96.264));
if (aLKqpRGFiAPqhXjN != aLKqpRGFiAPqhXjN) {
	tcb->m_cWnd = (int) (31.23-(21.89)-(73.752)-(aLKqpRGFiAPqhXjN)-(81.011));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(46.175)+(aLKqpRGFiAPqhXjN)+(31.479)+(33.114)+(70.494)+(aLKqpRGFiAPqhXjN));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
