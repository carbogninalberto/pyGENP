segmentsAcked = (int) (78.9+(35.958)+(64.124)+(95.749)+(99.991)+(32.151));
tcb->m_cWnd = (int) (57.49-(13.557)-(6.806)-(50.019)-(55.313)-(segmentsAcked)-(3.081));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	segmentsAcked = (int) (59.896*(35.7)*(55.306)*(87.307)*(84.458));
	tcb->m_segmentSize = (int) (47.21*(8.438)*(36.527)*(79.193));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (tcb->m_cWnd*(tcb->m_ssThresh)*(segmentsAcked)*(12.032));
	tcb->m_cWnd = (int) (89.564*(70.852)*(66.469)*(48.582)*(tcb->m_ssThresh)*(0.679)*(9.436)*(tcb->m_ssThresh)*(11.692));
	tcb->m_segmentSize = (int) (segmentsAcked-(33.231)-(13.044)-(7.279)-(tcb->m_ssThresh)-(33.005));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
