float FhaUfvYGiHZTjfur = (float) ((40.974+(84.433)+(-86.017)+(27.903)+(22.278)+(7.836)+(31.959)+(-98.002)+(-1.152))/-44.635);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
FhaUfvYGiHZTjfur = (float) (64.153/26.59);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (50.764*(-30.994)*(-99.945)*(43.817)*(-50.057)*(-72.674)*(2.251)*(-51.941)*(-11.528));
ReduceCwnd (tcb);
FhaUfvYGiHZTjfur = (float) (94.817/10.107);
tcb->m_cWnd = (int) (57.324*(8.177)*(-77.096)*(-82.625)*(82.16)*(-34.859)*(22.258)*(-82.297)*(-51.215));
