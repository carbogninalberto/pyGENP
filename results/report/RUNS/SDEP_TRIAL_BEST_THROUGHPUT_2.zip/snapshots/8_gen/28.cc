tcb->m_ssThresh = (int) (39.47*(99.164)*(segmentsAcked)*(85.064)*(56.491)*(60.681)*(32.097)*(41.515));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int NqPsGxXaXIpLSpOM = (int) (52.704+(74.99)+(47.684)+(19.626)+(81.985)+(7.226)+(8.308)+(23.055));
int DQZAsOlELrCFZKue = (int) (79.166-(53.953)-(47.781)-(tcb->m_cWnd)-(2.209)-(84.649)-(66.378));
if (DQZAsOlELrCFZKue > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (94.742/0.1);
	segmentsAcked = (int) (43.637-(tcb->m_cWnd)-(45.09)-(73.756)-(77.218)-(14.086)-(46.081)-(55.816));

} else {
	tcb->m_segmentSize = (int) (31.631-(39.069)-(68.455)-(21.461)-(48.434)-(99.783));

}
if (NqPsGxXaXIpLSpOM <= NqPsGxXaXIpLSpOM) {
	tcb->m_ssThresh = (int) (46.547*(97.758)*(43.978)*(9.433)*(8.124)*(4.433)*(tcb->m_segmentSize));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	DQZAsOlELrCFZKue = (int) (81.295+(10.068));

} else {
	tcb->m_ssThresh = (int) (62.276-(82.753)-(10.647)-(tcb->m_segmentSize)-(85.353)-(8.984)-(7.932));

}
