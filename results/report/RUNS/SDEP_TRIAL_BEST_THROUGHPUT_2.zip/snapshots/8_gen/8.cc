float nsTnnZTxNbmZfIns = (float) (79.706*(30.72)*(-14.674)*(-88.39)*(-63.199)*(-54.214)*(-2.769));
int kTfcAFBjVQTikuBC = (int) (-6.554/25.291);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
kTfcAFBjVQTikuBC = (int) (-11.883-(-18.894)-(-10.641)-(-87.235)-(1.002)-(3.876)-(50.643)-(-24.114)-(-60.042));
