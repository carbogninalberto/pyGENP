float FhaUfvYGiHZTjfur = (float) ((16.348+(-89.125)+(48.875)+(-43.859)+(-87.525)+(63.923)+(-37.981)+(12.704)+(67.55))/-56.792);
tcb->m_cWnd = (int) (46.556+(-33.356)+(-9.649)+(30.694)+(62.899)+(-31.683));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
FhaUfvYGiHZTjfur = (float) (28.569/-61.835);
