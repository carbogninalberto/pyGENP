int diIEmUXzGPXPvEGs = (int) (3.536+(61.398));
int oBubKjuhBUhKWJlq = (int) (-65.215-(14.827)-(-4.854));
segmentsAcked = (int) (-79.938-(72.069)-(-88.194)-(87.02)-(-88.272)-(-87.616)-(11.005)-(-86.564));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
