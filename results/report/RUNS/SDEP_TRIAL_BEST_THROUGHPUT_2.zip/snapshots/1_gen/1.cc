int oqTDFjqyFYyEQBjy = (int) (-67.477/58.846);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-51.898-(82.103)-(-38.807));
