if (tcb->m_cWnd >= tcb->m_ssThresh) {
	segmentsAcked = (int) (60.721*(tcb->m_ssThresh)*(segmentsAcked));
	tcb->m_cWnd = (int) (segmentsAcked*(71.748));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (90.949+(tcb->m_ssThresh)+(43.892)+(2.82)+(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (98.652+(96.384)+(tcb->m_ssThresh)+(27.573)+(63.722)+(82.986)+(90.588));

}
tcb->m_segmentSize = (int) (43.026-(34.295)-(81.247)-(44.835)-(71.345));
segmentsAcked = (int) (((0.1)+(0.1)+(69.352)+(37.891)+(27.808)+(0.1))/((60.552)));
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(segmentsAcked)+(56.196)+(42.031)+(95.549)+(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (97.43-(54.965)-(80.102)-(tcb->m_cWnd)-(74.982)-(85.111)-(40.295)-(71.103));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (58.098/0.1);

}
tcb->m_segmentSize = (int) (2.063-(tcb->m_segmentSize)-(tcb->m_cWnd));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (20.912*(29.71));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(47.718)+(84.45)+(81.185)+(29.396)+(62.357)+(10.461)+(50.317));
	segmentsAcked = (int) (((95.584)+((59.72-(30.37)))+(18.441)+(0.1))/((3.955)+(61.766)+(88.207)+(0.1)));

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (50.132*(segmentsAcked)*(78.781)*(35.298)*(12.911)*(4.827));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (59.788+(47.917)+(29.661)+(30.664));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
