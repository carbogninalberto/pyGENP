if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_segmentSize = (int) (76.754*(26.823)*(tcb->m_cWnd)*(27.585)*(74.716)*(44.037)*(96.093));

} else {
	tcb->m_segmentSize = (int) (0.1/(63.94+(77.455)+(tcb->m_cWnd)+(tcb->m_segmentSize)));
	segmentsAcked = (int) (81.882+(42.6)+(47.664)+(33.029));

}
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	segmentsAcked = (int) (30.159/0.1);

} else {
	segmentsAcked = (int) ((((12.563*(tcb->m_ssThresh)*(tcb->m_cWnd)*(62.8)*(tcb->m_cWnd)*(93.502)))+(62.73)+((tcb->m_segmentSize-(92.809)-(13.747)-(71.905)-(94.515)-(86.48)))+(0.1)+(30.674))/((94.041)));
	tcb->m_cWnd = (int) (27.26-(94.887)-(13.255)-(66.067));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
