float LqDAxjRogGPXcTOl = (float) 29.458;
