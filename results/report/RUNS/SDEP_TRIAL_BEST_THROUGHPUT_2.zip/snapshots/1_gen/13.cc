TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_ssThresh = (int) (1.079*(45.278)*(99.112)*(41.834)*(99.543)*(48.054));
	tcb->m_ssThresh = (int) (44.358*(58.154)*(90.399));
	segmentsAcked = (int) (((0.1)+(0.1)+((52.43+(83.653)+(97.042)+(54.966)+(63.27)))+(44.184))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (((0.1)+((62.719+(15.22)))+(49.043)+(69.571)+((tcb->m_segmentSize*(72.028)*(tcb->m_cWnd)*(7.984)*(55.524)))+(0.1))/((0.1)+(86.017)+(31.285)));

}
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (((35.672)+(0.1)+(36.158)+(72.072))/((0.1)+(35.295)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (3.509-(72.445)-(42.204)-(tcb->m_segmentSize)-(97.359)-(86.918)-(12.442)-(tcb->m_segmentSize)-(83.609));
