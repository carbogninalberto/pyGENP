int kTfcAFBjVQTikuBC = (int) (-8.376/15.176);
tcb->m_cWnd = (int) (16.506-(69.766)-(26.285)-(11.699)-(-55.613)-(-28.973));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
kTfcAFBjVQTikuBC = (int) (82.454-(5.601)-(-39.015)-(-39.335)-(82.292)-(-91.086)-(-59.067)-(-13.502)-(53.401));
