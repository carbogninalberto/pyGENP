segmentsAcked = (int) (-26.848*(-44.839)*(-77.194)*(-24.178));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < segmentsAcked) {
	segmentsAcked = (int) (48.217*(52.355));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (63.811+(-52.993)+(99.331)+(74.052)+(97.672)+(39.656)+(segmentsAcked)+(65.41)+(83.671));

}
