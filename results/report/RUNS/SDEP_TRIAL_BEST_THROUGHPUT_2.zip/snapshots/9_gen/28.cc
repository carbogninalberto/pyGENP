tcb->m_segmentSize = (int) (79.081/0.1);
segmentsAcked = (int) (48.656+(43.378)+(3.036));
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (2.857+(37.81)+(tcb->m_cWnd)+(24.076)+(49.484));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (92.569*(59.316)*(70.968)*(4.021)*(13.577));
	tcb->m_cWnd = (int) (0.1/23.383);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (21.418*(50.086)*(95.796)*(27.011)*(12.504)*(9.164));
