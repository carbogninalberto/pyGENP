float aLKqpRGFiAPqhXjN = (float) 39.451;
float ggxPYODjgHUwLUpq = (float) 67.76;
