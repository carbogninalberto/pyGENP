if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (39.605+(14.045));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(16.655)-(80.449)-(15.384)-(72.079)-(43.004));
	tcb->m_segmentSize = (int) (46.979-(tcb->m_ssThresh)-(82.084)-(tcb->m_cWnd));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (58.081/0.1);
tcb->m_cWnd = (int) (61.619*(segmentsAcked)*(43.885)*(69.609)*(95.295)*(43.169)*(42.779)*(28.632)*(segmentsAcked));
segmentsAcked = (int) (0.1/0.1);
tcb->m_ssThresh = (int) (69.17+(60.708));
