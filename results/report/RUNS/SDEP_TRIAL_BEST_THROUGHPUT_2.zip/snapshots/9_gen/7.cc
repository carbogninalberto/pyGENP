TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (40.096-(-52.465)-(-9.568)-(-58.873));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-72.964*(-56.193)*(47.022));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (59.638*(-3.446)*(-35.713));
ReduceCwnd (tcb);
