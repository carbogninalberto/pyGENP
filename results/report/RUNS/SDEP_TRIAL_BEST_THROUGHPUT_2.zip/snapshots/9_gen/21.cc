if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_segmentSize = (int) (65.393-(71.188)-(61.275)-(tcb->m_ssThresh)-(30.831)-(27.912));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(tcb->m_ssThresh)+(20.56));

}
segmentsAcked = (int) (8.068*(tcb->m_cWnd)*(21.532)*(59.932));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (93.604+(69.061)+(5.334));

} else {
	tcb->m_segmentSize = (int) ((((12.096*(tcb->m_ssThresh)*(50.617)))+((63.705+(28.929)+(75.108)+(87.731)+(43.843)+(19.403)))+((46.066+(20.051)+(tcb->m_segmentSize)+(segmentsAcked)+(61.45)))+(84.56)+(0.1))/((32.846)+(48.851)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) ((53.67+(14.258)+(34.976)+(32.459))/57.317);
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (21.922*(tcb->m_segmentSize)*(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (54.812*(tcb->m_ssThresh)*(3.909)*(84.713)*(52.441));
	segmentsAcked = (int) (50.046+(78.561)+(37.084)+(35.499)+(18.75)+(65.524)+(tcb->m_ssThresh)+(66.262));
	tcb->m_cWnd = (int) (((59.927)+(0.1)+(72.228)+(99.373)+(33.874))/((99.352)+(45.58)+(85.546)+(0.1)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
