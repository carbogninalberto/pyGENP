float mMLYHLumSyLJDPON = (float) (90.8*(21.346)*(89.92)*(12.241)*(72.344));
segmentsAcked = (int) (12.517*(8.352)*(tcb->m_ssThresh)*(12.288)*(tcb->m_segmentSize));
tcb->m_cWnd = (int) (64.14-(5.781)-(51.073)-(65.025)-(44.439)-(35.68));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
mMLYHLumSyLJDPON = (float) (80.118/0.1);
