if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((18.63)+((67.294-(36.841)-(15.763)-(8.643)-(30.386)-(48.848)))+(0.1)+(65.216))/((0.1)+(47.618)+(0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (67.167+(57.445)+(segmentsAcked)+(10.422)+(tcb->m_segmentSize)+(6.137));
	tcb->m_ssThresh = (int) (21.614*(20.802)*(93.713)*(36.632)*(50.352)*(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (57.421-(4.316)-(25.872)-(60.556)-(tcb->m_ssThresh));

}
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (78.576+(78.804)+(98.943)+(41.877)+(segmentsAcked)+(92.152)+(57.23)+(11.385));
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(51.995));
	tcb->m_ssThresh = (int) (84.669*(54.24)*(96.6)*(77.931)*(52.424)*(73.311));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(58.61));
	segmentsAcked = (int) (20.126-(49.788)-(60.48)-(13.612)-(2.342)-(80.569)-(58.675));

}
tcb->m_segmentSize = (int) (51.368*(3.306)*(38.681)*(36.929)*(97.762));
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (96.204+(25.895));

} else {
	tcb->m_segmentSize = (int) (6.902-(21.331)-(tcb->m_segmentSize)-(57.373)-(24.443));
	tcb->m_cWnd = (int) (20.451-(28.056)-(tcb->m_segmentSize)-(96.185)-(96.783)-(94.073));
	tcb->m_segmentSize = (int) (23.47+(29.878)+(58.268)+(10.409)+(72.275)+(52.358)+(1.35)+(71.838)+(85.026));

}
tcb->m_ssThresh = (int) ((40.913*(tcb->m_cWnd)*(segmentsAcked)*(2.127))/69.014);
