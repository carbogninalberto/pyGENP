ReduceCwnd (tcb);
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((0.1)+(23.278)+(0.1)+((21.825*(segmentsAcked)*(44.321)*(25.536)*(10.04)*(43.339)))+(0.1))/((58.619)+(76.854)));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (11.608/0.1);

} else {
	tcb->m_segmentSize = (int) (28.026-(12.786)-(99.086)-(tcb->m_cWnd)-(54.722)-(tcb->m_segmentSize)-(58.945)-(95.88)-(18.947));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(segmentsAcked)-(24.892)-(43.308)-(98.19));

}
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (87.279*(68.721)*(24.46)*(15.012)*(44.225));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) ((((13.51-(52.891)-(33.046)-(23.688)))+(0.1)+(0.1)+(85.535))/((0.1)));
	tcb->m_segmentSize = (int) (94.462+(59.542)+(32.167)+(48.388)+(94.086)+(76.392)+(78.622));

}
tcb->m_segmentSize = (int) (25.569+(76.479)+(70.571)+(tcb->m_cWnd));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (78.614-(43.578)-(52.189)-(67.708)-(tcb->m_ssThresh)-(2.967)-(39.922)-(80.118));

} else {
	tcb->m_cWnd = (int) (61.103/90.81);
	segmentsAcked = (int) (62.198-(96.502)-(34.236)-(segmentsAcked)-(11.909)-(4.573)-(69.597)-(62.39));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
