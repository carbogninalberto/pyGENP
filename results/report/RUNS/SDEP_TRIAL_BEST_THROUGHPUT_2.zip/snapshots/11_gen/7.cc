int fvjbkZdIdAIDwTqq = (int) 77.08;
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (81.838-(55.47)-(2.214));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (69.104/90.783);
	tcb->m_segmentSize = (int) (88.531/0.1);
	tcb->m_segmentSize = (int) (99.716-(82.55)-(tcb->m_cWnd)-(fvjbkZdIdAIDwTqq)-(24.778)-(21.367));

} else {
	tcb->m_segmentSize = (int) (70.841-(16.288)-(9.416)-(-30.616)-(80.64)-(32.389)-(fvjbkZdIdAIDwTqq)-(63.494));

}
