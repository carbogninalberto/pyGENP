float HhkpPxXIsFbOsNBO = (float) (-36.845+(-45.437)+(-8.05)+(69.497)+(-8.988)+(-57.186)+(16.71)+(6.675)+(-62.0));
float cjmlWhXxKCiNOIYU = (float) (-76.171*(-66.22)*(-73.393)*(83.346)*(-66.702)*(71.646));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_cWnd) {
	segmentsAcked = (int) ((91.486-(10.992)-(94.951)-(68.509)-(tcb->m_segmentSize)-(66.962))/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (79.572-(13.543)-(92.708)-(77.134));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (HhkpPxXIsFbOsNBO >= HhkpPxXIsFbOsNBO) {
	segmentsAcked = (int) (62.798+(20.854)+(32.428)+(53.506)+(17.148));

} else {
	segmentsAcked = (int) (14.653+(33.161)+(cjmlWhXxKCiNOIYU));
	tcb->m_cWnd = (int) (14.885*(49.549)*(7.031)*(98.645)*(cjmlWhXxKCiNOIYU)*(49.289));

}
