int fvjbkZdIdAIDwTqq = (int) 31.28;
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (70.841-(16.288)-(9.416)-(88.257)-(80.64)-(32.389)-(fvjbkZdIdAIDwTqq)-(63.494));

} else {
	tcb->m_segmentSize = (int) (69.104/90.783);
	tcb->m_segmentSize = (int) (88.531/0.1);
	tcb->m_segmentSize = (int) (99.716-(82.55)-(tcb->m_cWnd)-(fvjbkZdIdAIDwTqq)-(24.778)-(21.367));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-46.988-(60.565)-(92.103));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
