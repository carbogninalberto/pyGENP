TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (46.489-(-96.215)-(35.563)-(22.007));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-40.621*(-69.475)*(4.171));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (48.701*(-27.53)*(-82.815));
ReduceCwnd (tcb);
