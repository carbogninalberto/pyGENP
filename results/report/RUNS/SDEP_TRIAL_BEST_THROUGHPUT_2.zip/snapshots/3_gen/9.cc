float LqDAxjRogGPXcTOl = (float) 61.618;
tcb->m_segmentSize = (int) (35.221*(-98.077)*(-42.875)*(37.028)*(-73.196)*(53.193));
LqDAxjRogGPXcTOl = (float) (-25.166-(-94.592)-(-75.195)-(69.669));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
LqDAxjRogGPXcTOl = (float) (91.212-(-35.667)-(51.747)-(-33.827));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
