TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_segmentSize+(50.482)+(2.154)+(tcb->m_segmentSize)+(73.847));
tcb->m_ssThresh = (int) (21.448/48.207);
float LyTSymuRHeCNgiGY = (float) (31.731-(76.531)-(6.9)-(tcb->m_segmentSize)-(61.076)-(tcb->m_cWnd)-(58.335));
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	segmentsAcked = (int) (51.556-(tcb->m_segmentSize)-(LyTSymuRHeCNgiGY));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (79.32-(79.34)-(43.148)-(9.296)-(60.944)-(tcb->m_segmentSize)-(23.282));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
