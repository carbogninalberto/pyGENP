tcb->m_segmentSize = (int) (40.01*(62.579)*(74.147)*(88.326)*(segmentsAcked)*(58.777)*(36.936));
tcb->m_ssThresh = (int) (16.851-(65.899));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (66.693*(14.035)*(92.721));
ReduceCwnd (tcb);
