float auKINonBJbFKPXfT = (float) (15.875-(7.163));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (auKINonBJbFKPXfT != segmentsAcked) {
	tcb->m_cWnd = (int) (34.669-(14.147)-(segmentsAcked)-(20.823)-(auKINonBJbFKPXfT));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (44.097+(38.569)+(23.118)+(18.034)+(segmentsAcked)+(auKINonBJbFKPXfT)+(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (37.962-(31.657)-(segmentsAcked)-(segmentsAcked)-(34.177));

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (60.403-(34.558)-(47.76)-(48.224)-(34.931)-(9.15)-(93.918)-(35.23));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(55.447)-(25.655)-(65.036)-(tcb->m_cWnd)-(90.078)-(tcb->m_segmentSize)-(tcb->m_cWnd));

}
if (auKINonBJbFKPXfT != segmentsAcked) {
	tcb->m_cWnd = (int) (34.669-(14.147)-(segmentsAcked)-(20.823)-(auKINonBJbFKPXfT));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (44.097+(38.569)+(23.118)+(18.034)+(segmentsAcked)+(auKINonBJbFKPXfT)+(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (37.962-(31.657)-(segmentsAcked)-(segmentsAcked)-(34.177));

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (60.403-(34.558)-(47.76)-(48.224)-(34.931)-(9.15)-(93.918)-(35.23));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(55.447)-(25.655)-(65.036)-(tcb->m_cWnd)-(90.078)-(tcb->m_segmentSize)-(tcb->m_cWnd));

}
