tcb->m_segmentSize = (int) (21.124*(25.739)*(76.551)*(56.783)*(18.179));
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_segmentSize = (int) (98.236-(96.284)-(26.222)-(91.258)-(43.865));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (21.621-(68.242)-(99.258)-(98.272)-(61.759));

} else {
	tcb->m_segmentSize = (int) (99.806+(57.411)+(30.31)+(15.376)+(66.48)+(45.792)+(39.631)+(42.437));
	segmentsAcked = (int) (17.379*(segmentsAcked)*(0.559)*(segmentsAcked));

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
