tcb->m_ssThresh = (int) (69.739-(73.736)-(2.557)-(43.246)-(segmentsAcked));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (18.429+(76.771)+(segmentsAcked)+(52.101)+(55.984)+(segmentsAcked)+(26.906)+(37.369));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_ssThresh+(54.146)+(72.516)+(82.197)+(47.345)+(23.638)+(25.052)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh*(segmentsAcked)*(4.496)*(51.167));

}
tcb->m_cWnd = (int) (54.243+(segmentsAcked)+(91.459)+(60.574)+(22.313)+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (23.277+(6.034)+(10.386)+(5.4));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
