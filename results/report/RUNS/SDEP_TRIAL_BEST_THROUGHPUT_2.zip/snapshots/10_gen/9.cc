float TKSLeXcKROkclxmS = (float) 86.283;
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-22.441+(55.256)+(-45.305)+(-74.32)+(-21.209)+(-94.786)+(-58.843)+(-2.139)+(-13.264));
segmentsAcked = (int) (-64.186+(-26.345)+(14.561)+(87.38)+(81.283)+(-0.931)+(-85.236)+(98.871)+(14.498));
if (TKSLeXcKROkclxmS <= TKSLeXcKROkclxmS) {
	TKSLeXcKROkclxmS = (float) (96.432*(47.431)*(60.399));

} else {
	TKSLeXcKROkclxmS = (float) (tcb->m_segmentSize*(tcb->m_segmentSize)*(14.455)*(50.26)*(1.497)*(69.243)*(9.863)*(TKSLeXcKROkclxmS));
	ReduceCwnd (tcb);

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-18.997-(-93.365)-(53.765)-(86.935)-(32.765)-(-58.052)-(-10.348)-(-99.968)-(-97.854));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (97.108+(-68.135)+(-47.347)+(49.889)+(-32.702)+(-30.406)+(-86.776)+(93.794)+(-77.365));
