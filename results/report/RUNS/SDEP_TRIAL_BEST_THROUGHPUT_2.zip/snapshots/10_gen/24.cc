float PgtMpFoZGZGgsZtD = (float) (37.61-(tcb->m_cWnd)-(42.916)-(tcb->m_ssThresh)-(88.743)-(57.625)-(76.148)-(tcb->m_cWnd));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (0.1/0.1);
ReduceCwnd (tcb);
