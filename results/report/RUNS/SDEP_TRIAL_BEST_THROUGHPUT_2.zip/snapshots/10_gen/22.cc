tcb->m_segmentSize = (int) (69.122-(tcb->m_ssThresh)-(80.738)-(1.689)-(87.076)-(tcb->m_cWnd)-(tcb->m_ssThresh));
ReduceCwnd (tcb);
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_cWnd = (int) (40.903-(segmentsAcked)-(71.618));

} else {
	tcb->m_cWnd = (int) ((34.093-(tcb->m_ssThresh)-(tcb->m_cWnd)-(6.832)-(8.888)-(35.278)-(39.141)-(53.605))/23.515);
	tcb->m_ssThresh = (int) (segmentsAcked+(18.36)+(91.377)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(0.1)+(0.1)+(67.009))/((0.1)+(8.412)));

}
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (88.684+(45.661)+(75.181));

} else {
	tcb->m_ssThresh = (int) (0.1/80.262);
	tcb->m_segmentSize = (int) (((0.1)+((tcb->m_cWnd+(tcb->m_ssThresh)+(49.263)+(37.665)))+(0.1)+(30.108)+(4.905))/((0.1)));
	segmentsAcked = (int) (tcb->m_cWnd*(28.88));

}
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/11.567);
	tcb->m_ssThresh = (int) (39.059-(tcb->m_cWnd)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(24.751));
	tcb->m_cWnd = (int) (7.162*(10.887)*(27.804));

} else {
	tcb->m_segmentSize = (int) (18.468-(46.398)-(19.418)-(17.076)-(18.212));
	segmentsAcked = (int) (81.399*(tcb->m_ssThresh));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
