tcb->m_ssThresh = (int) ((tcb->m_cWnd-(60.073)-(40.023)-(89.039)-(6.784)-(1.989)-(tcb->m_segmentSize))/0.1);
tcb->m_segmentSize = (int) (76.803-(75.68)-(7.195)-(10.376)-(99.562)-(13.135));
if (tcb->m_ssThresh < tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd*(tcb->m_segmentSize)*(29.344)*(6.949)*(37.204)*(7.16));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (24.012/0.1);

} else {
	segmentsAcked = (int) (16.668-(15.505)-(tcb->m_cWnd)-(29.602)-(51.565));

}
segmentsAcked = (int) (17.886+(64.91)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(67.561)+(47.77)+(57.114)+(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (7.38+(27.863)+(98.505)+(64.705)+(39.426)+(76.761));
