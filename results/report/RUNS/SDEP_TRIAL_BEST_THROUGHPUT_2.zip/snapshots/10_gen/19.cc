if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (39.769+(68.115));
	tcb->m_segmentSize = (int) (25.331-(84.811)-(61.7)-(7.511)-(tcb->m_segmentSize)-(78.012)-(67.032)-(20.627)-(79.098));
	segmentsAcked = (int) (1.468*(73.844)*(40.866)*(segmentsAcked)*(65.363)*(15.939)*(tcb->m_cWnd)*(51.796));

} else {
	tcb->m_segmentSize = (int) (85.727*(79.88)*(59.413)*(16.546)*(2.405)*(20.835));

}
tcb->m_ssThresh = (int) (83.765+(64.676)+(27.692)+(37.84));
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (84.346*(9.794)*(60.748)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(tcb->m_cWnd)*(80.564));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(tcb->m_ssThresh)-(93.748)-(71.248)-(23.53)-(77.56)-(4.074));
	tcb->m_cWnd = (int) ((((74.335-(44.326)-(13.588)-(62.992)-(tcb->m_ssThresh)-(7.269)))+(72.701)+(41.996)+(0.1))/((58.696)+(12.783)+(0.1)));
	tcb->m_cWnd = (int) (19.646*(24.957)*(73.876)*(16.115)*(99.975));

}
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (92.39*(25.894)*(80.207)*(20.431));
	segmentsAcked = (int) (0.884*(49.341));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (82.142+(38.248)+(segmentsAcked)+(7.53)+(82.063)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (10.397+(98.119)+(2.482));
	tcb->m_segmentSize = (int) ((tcb->m_cWnd+(92.673)+(8.766)+(81.365))/(70.04-(tcb->m_segmentSize)-(27.923)-(21.089)-(10.386)-(18.95)));

}
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_ssThresh = (int) (59.166+(25.147)+(86.798)+(tcb->m_segmentSize)+(46.305)+(tcb->m_cWnd));
	segmentsAcked = (int) (3.779*(49.472)*(56.636)*(59.435)*(27.595)*(1.834));

} else {
	tcb->m_ssThresh = (int) (0.1/18.542);
	segmentsAcked = (int) (26.826-(73.58)-(84.217)-(48.826)-(45.814)-(8.402)-(47.494));

}
ReduceCwnd (tcb);
