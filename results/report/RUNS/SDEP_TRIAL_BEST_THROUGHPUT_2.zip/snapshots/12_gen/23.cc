CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (87.176-(44.741)-(14.344)-(74.679)-(41.175));
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (78.56+(33.683)+(60.471));

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+((63.092-(53.933)-(95.051)-(88.248)-(12.632)))+(0.1))/((80.981)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) ((38.802*(1.052)*(85.569)*(66.114)*(tcb->m_ssThresh)*(94.143)*(88.656)*(51.113)*(11.092))/0.1);
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (41.765/85.141);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (69.439*(tcb->m_segmentSize)*(76.317)*(71.395)*(43.651)*(21.882)*(94.099));
	segmentsAcked = (int) (tcb->m_ssThresh-(tcb->m_segmentSize)-(71.202));

}
ReduceCwnd (tcb);
