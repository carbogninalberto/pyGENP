CongestionAvoidance (tcb, segmentsAcked);
int WbiWLVUvIoYGuZZf = (int) (12.809*(70.646)*(83.791)*(segmentsAcked)*(segmentsAcked)*(11.16)*(22.72)*(tcb->m_segmentSize)*(96.638));
if (WbiWLVUvIoYGuZZf < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (57.398-(51.163)-(93.835)-(17.763)-(70.968)-(95.043)-(tcb->m_ssThresh)-(8.834)-(60.053));
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (60.363+(33.981)+(WbiWLVUvIoYGuZZf)+(tcb->m_segmentSize)+(89.152)+(7.688)+(92.815));

}
CongestionAvoidance (tcb, segmentsAcked);
int imRBtYPyQFMGAWaj = (int) (41.878*(40.35)*(94.408)*(6.794)*(30.71)*(33.042));
if (WbiWLVUvIoYGuZZf != tcb->m_ssThresh) {
	imRBtYPyQFMGAWaj = (int) (72.932*(57.574)*(tcb->m_ssThresh)*(21.935)*(37.112)*(43.591)*(WbiWLVUvIoYGuZZf));

} else {
	imRBtYPyQFMGAWaj = (int) (49.73+(96.024)+(tcb->m_segmentSize)+(23.945)+(74.574)+(91.304)+(40.784));
	tcb->m_cWnd = (int) (91.714+(64.676)+(43.302));

}
