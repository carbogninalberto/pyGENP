tcb->m_ssThresh = (int) (tcb->m_ssThresh+(5.452)+(tcb->m_segmentSize)+(34.551)+(83.949)+(3.087)+(78.686)+(25.443)+(segmentsAcked));
segmentsAcked = (int) (0.1/(43.976+(2.264)+(49.58)+(47.664)));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	segmentsAcked = (int) (17.44*(69.456)*(84.438));
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(57.571)*(76.881));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (14.298*(tcb->m_ssThresh)*(7.979)*(tcb->m_ssThresh)*(89.082)*(26.113)*(tcb->m_segmentSize)*(tcb->m_cWnd));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (67.005*(68.402)*(segmentsAcked));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (89.842+(12.171)+(segmentsAcked)+(49.699)+(16.378)+(54.043)+(94.541)+(57.252));
