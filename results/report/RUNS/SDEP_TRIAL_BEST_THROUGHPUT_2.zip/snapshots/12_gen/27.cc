float ACghvbCBYLjbbAQj = (float) ((tcb->m_ssThresh*(20.676)*(85.342)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(37.966))/0.1);
if (ACghvbCBYLjbbAQj != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (43.195-(63.11)-(tcb->m_ssThresh)-(4.455)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(68.022));
	tcb->m_ssThresh = (int) (0.1/81.77);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (50.546*(65.251)*(1.426)*(68.612)*(38.979)*(83.226)*(51.241)*(74.018)*(8.701));
	segmentsAcked = (int) (12.078-(61.521)-(10.295)-(28.318)-(22.898)-(71.932));

}
float oNaZQpaURoPhpxIA = (float) (34.214-(69.632));
if (tcb->m_cWnd == ACghvbCBYLjbbAQj) {
	tcb->m_cWnd = (int) (59.0+(51.442)+(45.343)+(7.71)+(78.929)+(81.56)+(13.9)+(66.057)+(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (11.632-(25.388));

} else {
	tcb->m_cWnd = (int) (84.501*(80.022)*(98.662)*(45.176)*(33.705)*(24.664)*(36.812)*(91.499));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (47.955+(84.047)+(16.901)+(96.608)+(segmentsAcked));

}
tcb->m_cWnd = (int) ((((oNaZQpaURoPhpxIA-(oNaZQpaURoPhpxIA)-(segmentsAcked)-(2.28)-(tcb->m_cWnd)-(46.857)))+(13.928)+(21.467)+(0.1))/((52.952)+(76.082)+(17.014)+(0.1)+(0.1)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) ((ACghvbCBYLjbbAQj+(34.565)+(33.377)+(86.767)+(88.223)+(10.047)+(93.879)+(25.064)+(71.48))/0.1);
