float FptmpRObmcjRLVTS = (float) (92.141+(99.828)+(-32.037)+(-60.339)+(-57.428)+(-97.635));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (9.264-(-33.933)-(-93.535)-(11.585)-(-11.324)-(-84.108));
