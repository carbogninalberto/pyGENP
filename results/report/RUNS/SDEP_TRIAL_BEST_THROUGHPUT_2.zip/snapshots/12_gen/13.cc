if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (32.424+(90.172)+(17.532)+(tcb->m_cWnd)+(64.296)+(3.745)+(tcb->m_segmentSize)+(83.656));

} else {
	tcb->m_cWnd = (int) (23.806*(49.178)*(segmentsAcked)*(37.844)*(21.492)*(83.42)*(28.533)*(87.829));
	tcb->m_segmentSize = (int) (14.555*(40.505)*(52.494)*(77.977)*(73.735)*(tcb->m_segmentSize)*(segmentsAcked)*(91.529));

}
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (22.466+(82.818));

} else {
	tcb->m_cWnd = (int) (18.052*(71.753)*(14.682)*(84.082)*(4.815)*(segmentsAcked)*(tcb->m_cWnd)*(46.177)*(70.104));
	tcb->m_cWnd = (int) (((72.563)+(0.1)+(54.651)+(94.074)+(67.788)+(0.1)+(0.1)+(59.326))/((0.1)));
	tcb->m_segmentSize = (int) (38.655*(74.297)*(34.326)*(90.542)*(segmentsAcked)*(53.51)*(31.103)*(34.65));

}
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (26.474-(38.775)-(14.975)-(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (94.664*(95.529)*(segmentsAcked)*(10.421)*(segmentsAcked)*(85.129)*(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (87.105+(4.649));
	tcb->m_ssThresh = (int) ((((80.746-(19.6)-(35.145)-(53.632)-(1.774)))+(41.087)+(0.1)+(24.371))/((99.409)+(4.092)+(50.001)));
	tcb->m_cWnd = (int) (78.457+(74.647)+(42.207)+(tcb->m_segmentSize)+(87.736)+(33.307)+(48.49)+(86.932)+(40.917));

}
segmentsAcked = (int) (tcb->m_cWnd+(tcb->m_ssThresh)+(33.2)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(36.725)+(tcb->m_cWnd)+(tcb->m_ssThresh));
