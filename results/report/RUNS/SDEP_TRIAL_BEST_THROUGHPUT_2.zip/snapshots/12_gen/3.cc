int AHUzhmQUXrEZerKH = (int) (-4.642-(-8.041)-(-25.088)-(56.777)-(-92.509));
