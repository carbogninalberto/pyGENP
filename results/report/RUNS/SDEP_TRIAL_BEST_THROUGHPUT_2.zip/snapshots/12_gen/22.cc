tcb->m_segmentSize = (int) (tcb->m_segmentSize*(50.389)*(tcb->m_segmentSize)*(72.762)*(31.759));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (((50.294)+(55.675)+(0.1)+(27.933))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (70.187-(74.273)-(35.714)-(31.81));
	tcb->m_cWnd = (int) ((82.216+(75.284)+(tcb->m_ssThresh)+(tcb->m_cWnd))/38.686);

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (41.694*(87.598)*(tcb->m_ssThresh)*(36.238)*(tcb->m_ssThresh)*(1.084)*(tcb->m_ssThresh)*(48.439)*(tcb->m_cWnd));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (41.972-(81.31));

} else {
	tcb->m_cWnd = (int) ((5.637+(40.692)+(52.376)+(tcb->m_ssThresh)+(20.196))/59.203);

}
tcb->m_cWnd = (int) (((21.982)+((tcb->m_cWnd-(60.039)-(tcb->m_ssThresh)-(59.195)-(13.529)))+(40.583)+(72.107))/((0.1)+(72.415)+(0.1)));
