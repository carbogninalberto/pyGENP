if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (71.182-(37.253)-(19.456)-(tcb->m_cWnd)-(25.05)-(65.61)-(45.525));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (87.827+(tcb->m_cWnd)+(48.158)+(36.015)+(60.739)+(tcb->m_ssThresh));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (7.752-(20.718)-(84.725)-(3.126));

} else {
	tcb->m_ssThresh = (int) (31.278+(81.941)+(34.124)+(45.516)+(27.371)+(71.668));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (((15.362)+(63.417)+(78.063)+(0.1))/((92.783)+(0.1)+(31.194)));
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (8.702-(59.126)-(36.889)-(25.252)-(11.266));
	segmentsAcked = (int) (82.703+(55.14)+(48.988)+(52.588)+(78.954)+(33.504));
	tcb->m_cWnd = (int) (0.1/1.886);

} else {
	tcb->m_cWnd = (int) (0.1/3.556);

}
tcb->m_cWnd = (int) (47.777-(72.407)-(tcb->m_cWnd)-(tcb->m_segmentSize)-(10.727)-(3.551)-(segmentsAcked)-(44.612));
