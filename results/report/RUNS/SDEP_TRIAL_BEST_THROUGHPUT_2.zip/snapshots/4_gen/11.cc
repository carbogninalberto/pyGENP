segmentsAcked = (int) (49.441-(79.914)-(76.363)-(34.357)-(-72.29)-(-59.704));
float bLYHFPuOtuBZQRpI = (float) 81.429;
