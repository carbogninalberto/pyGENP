if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (87.283-(92.502)-(segmentsAcked)-(5.838));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (89.662+(44.775)+(15.0)+(57.702)+(99.953)+(25.735));

} else {
	tcb->m_cWnd = (int) (21.282-(73.139)-(12.555)-(8.641)-(tcb->m_cWnd)-(63.863));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (0.1/15.3);
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (47.775*(68.644)*(tcb->m_ssThresh)*(87.712)*(16.196)*(15.049)*(50.051)*(tcb->m_ssThresh)*(31.617));
	tcb->m_ssThresh = (int) (2.032+(13.573)+(81.988)+(25.641));

} else {
	tcb->m_segmentSize = (int) (62.86+(41.722)+(61.945)+(39.065)+(9.04));

}
if (tcb->m_ssThresh == tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd+(36.3)+(93.37)+(16.16)+(72.196)+(7.978)+(43.63));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (0.1/95.7);

}
