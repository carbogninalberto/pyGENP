int wQtOPSkAXKZCCgyw = (int) (-96.704+(-21.888)+(35.132));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (52.773+(71.587)+(25.23)+(84.512));
	tcb->m_cWnd = (int) (19.294/0.1);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-96.155*(-38.459)*(-43.479)*(-80.571)*(-44.804)*(-66.375)*(-9.273)*(-39.795)*(55.92));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
