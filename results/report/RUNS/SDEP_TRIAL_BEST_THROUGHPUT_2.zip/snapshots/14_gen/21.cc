CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (41.422/0.1);
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (93.133*(25.956)*(94.307)*(43.558)*(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (0.1/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (80.166*(tcb->m_segmentSize)*(66.671)*(42.881)*(88.354)*(tcb->m_cWnd)*(segmentsAcked)*(13.145));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked+(12.694)+(segmentsAcked)+(59.999));

}
tcb->m_ssThresh = (int) (14.724*(34.925)*(tcb->m_segmentSize)*(56.602)*(43.906)*(28.931));
