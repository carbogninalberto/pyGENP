tcb->m_cWnd = (int) (71.188-(segmentsAcked)-(6.332)-(7.393)-(84.117)-(tcb->m_ssThresh));
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_cWnd+(69.683)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) ((((tcb->m_ssThresh-(46.265)-(6.815)-(tcb->m_ssThresh)-(41.578)-(24.864)))+((88.258*(14.47)))+(0.1)+(0.1)+(0.1)+(73.139))/((0.1)+(0.1)+(90.665)));

}
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(98.792)+(54.822)+(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (20.488/76.336);

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (47.461+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(73.937)+(87.06)+(91.332)+(87.478)+(3.22)+(73.845));
	tcb->m_cWnd = (int) (((64.123)+(0.1)+((7.681+(29.096)+(38.287)))+(0.1)+(55.219)+(62.676)+((97.108-(tcb->m_ssThresh)-(70.951)-(12.751)-(45.927)-(segmentsAcked)-(94.836)-(tcb->m_segmentSize)-(85.019)))+(0.1))/((0.1)));
	tcb->m_cWnd = (int) (68.927+(72.508)+(31.661));

} else {
	tcb->m_segmentSize = (int) (37.25+(47.243)+(tcb->m_segmentSize)+(47.506));
	tcb->m_cWnd = (int) (0.1/0.1);

}
tcb->m_cWnd = (int) (9.405-(53.043)-(75.083)-(19.077)-(71.225)-(11.487));
