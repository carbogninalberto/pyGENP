CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (((12.881)+(52.454)+(91.204)+(85.227)+(77.938)+(23.903)+(0.1))/((0.1)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (23.608*(tcb->m_ssThresh)*(42.104)*(78.862)*(98.048)*(59.995)*(35.992)*(segmentsAcked));
ReduceCwnd (tcb);
