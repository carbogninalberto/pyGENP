segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (((0.1)+(91.766)+(65.507)+(15.904)+(29.591)+(0.1)+(0.1))/((49.981)+(36.845)));
	tcb->m_segmentSize = (int) (segmentsAcked+(20.061)+(88.731)+(62.718)+(54.096)+(44.366)+(83.603)+(62.853));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
float fdOrHgKPSrmUirUs = (float) (16.545*(79.721)*(37.717)*(67.298));
tcb->m_cWnd = (int) (26.158*(tcb->m_segmentSize));
