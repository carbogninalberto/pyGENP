tcb->m_segmentSize = (int) (85.296*(8.822)*(tcb->m_cWnd)*(30.833)*(tcb->m_cWnd)*(7.528));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (0.1/47.469);
tcb->m_cWnd = (int) (71.026/27.858);
segmentsAcked = SlowStart (tcb, segmentsAcked);
