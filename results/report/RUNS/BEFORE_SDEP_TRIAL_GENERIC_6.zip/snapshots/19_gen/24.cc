if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (16.53+(tcb->m_segmentSize)+(9.27));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(17.59));

}
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (16.53+(tcb->m_segmentSize)+(9.27));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(17.59));

}
segmentsAcked = (int) (2+(-17)+(9));
segmentsAcked = (int) (1+(-14)+(-6));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (16.53+(tcb->m_segmentSize)+(9.27));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(17.59));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (16.53+(tcb->m_segmentSize)+(9.27));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(17.59));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (3+(-13)+(-18));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (1+(-6)+(19));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (16.53+(tcb->m_segmentSize)+(9.27));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(17.59));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (16.53+(tcb->m_segmentSize)+(9.27));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(17.59));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-6+(14)+(-14));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-17+(-14)+(-1));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
