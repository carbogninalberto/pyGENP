int UGoNprfOUntYVbvJ = (int) (-3/-12);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (-10+(13)+(14));
UGoNprfOUntYVbvJ = (int) (-11+(9)+(12));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
