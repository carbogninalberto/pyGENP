int UGoNprfOUntYVbvJ = (int) (2/-7);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (-15+(10)+(9));
UGoNprfOUntYVbvJ = (int) (-13+(-8)+(3));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
