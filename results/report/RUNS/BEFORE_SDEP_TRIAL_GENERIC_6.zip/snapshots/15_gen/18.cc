CongestionAvoidance (tcb, segmentsAcked);
int UGoNprfOUntYVbvJ = (int) (-9+(-1)+(4)+(-9));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (-20+(-15)+(6));
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (1+(18)+(18));
UGoNprfOUntYVbvJ = (int) (-15+(12)+(7));
UGoNprfOUntYVbvJ = (int) (-4+(-18)+(10));
CongestionAvoidance (tcb, segmentsAcked);
