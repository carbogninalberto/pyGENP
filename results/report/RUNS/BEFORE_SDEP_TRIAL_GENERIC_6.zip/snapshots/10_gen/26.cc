int UGoNprfOUntYVbvJ = (int) (-2*(-14)*(-10)*(1));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (-15+(-8)+(-18));
UGoNprfOUntYVbvJ = (int) (6+(15)+(-10));
UGoNprfOUntYVbvJ = (int) (-4+(-11)+(-15));
UGoNprfOUntYVbvJ = (int) (8+(-6)+(-11));
