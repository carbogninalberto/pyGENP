int UGoNprfOUntYVbvJ = (int) (-10*(4)*(-7)*(12));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (2+(-13)+(-18));
UGoNprfOUntYVbvJ = (int) (-5+(8)+(-10));
UGoNprfOUntYVbvJ = (int) (18+(16)+(11));
