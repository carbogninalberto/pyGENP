int UGoNprfOUntYVbvJ = (int) (-12-(-7)-(-13));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (-9+(15)+(-6));
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (19+(6)+(17));
UGoNprfOUntYVbvJ = (int) (17+(16)+(12));
UGoNprfOUntYVbvJ = (int) (9+(-9)+(12));
UGoNprfOUntYVbvJ = (int) (-4+(-8)+(-1));
