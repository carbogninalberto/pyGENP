TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int UGoNprfOUntYVbvJ = (int) (-19+(-15)+(-15)+(-12));
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (13+(1)+(13));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (13+(-4)+(-3));
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (-20+(11)+(9));
UGoNprfOUntYVbvJ = (int) (18+(11)+(4));
