int UGoNprfOUntYVbvJ = (int) (-7-(18)-(-10));
