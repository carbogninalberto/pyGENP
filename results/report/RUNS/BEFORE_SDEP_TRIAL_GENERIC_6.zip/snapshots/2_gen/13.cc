float sjcJgfYXtdBsaJDT = (float) (-9-(-3)-(-18));
