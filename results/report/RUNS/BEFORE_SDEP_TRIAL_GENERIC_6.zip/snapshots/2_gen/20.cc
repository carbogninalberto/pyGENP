int nlkVqdsRBGQQjkpI = (int) (-3+(-8));
int DNEucACXQUpsNTgL = (int) (18+(11)+(-3)+(-5));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	DNEucACXQUpsNTgL = (int) (12.95*(11.92));

} else {
	DNEucACXQUpsNTgL = (int) (7.15-(11.51)-(7.92)-(7.01));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (nlkVqdsRBGQQjkpI < segmentsAcked) {
	segmentsAcked = (int) (13.7-(17.19));
	nlkVqdsRBGQQjkpI = (int) (5.7/10.73);
	tcb->m_cWnd = (int) (2.65*(16.66));

} else {
	segmentsAcked = (int) (7.51*(14.52));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (19.51*(segmentsAcked)*(8.62));

} else {
	tcb->m_cWnd = (int) (8.24/7.05);
	DNEucACXQUpsNTgL = (int) (2.08-(9.25)-(13.11));

}
if (nlkVqdsRBGQQjkpI < segmentsAcked) {
	segmentsAcked = (int) (13.7-(17.19));
	nlkVqdsRBGQQjkpI = (int) (5.7/10.73);
	tcb->m_cWnd = (int) (2.65*(16.66));

} else {
	segmentsAcked = (int) (7.51*(14.52));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (19.51*(segmentsAcked)*(8.62));

} else {
	tcb->m_cWnd = (int) (8.24/7.05);
	DNEucACXQUpsNTgL = (int) (2.08-(9.25)-(13.11));

}
