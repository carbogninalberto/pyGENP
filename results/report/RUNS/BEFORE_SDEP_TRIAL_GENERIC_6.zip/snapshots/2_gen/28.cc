int UGoNprfOUntYVbvJ = (int) (-9/-7);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (11+(-6)+(-19));
UGoNprfOUntYVbvJ = (int) (-19+(3)+(3));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
