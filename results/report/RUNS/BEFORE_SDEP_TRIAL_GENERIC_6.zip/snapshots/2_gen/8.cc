int nlkVqdsRBGQQjkpI = (int) (-13+(3));
int DNEucACXQUpsNTgL = (int) (15+(4)+(-12)+(-14));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (10.03-(tcb->m_segmentSize)-(segmentsAcked)-(17.05));

} else {
	tcb->m_segmentSize = (int) ((2.41*(16.36))/1);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (nlkVqdsRBGQQjkpI < segmentsAcked) {
	segmentsAcked = (int) (13.7-(17.19));
	nlkVqdsRBGQQjkpI = (int) (5.7/10.73);
	tcb->m_cWnd = (int) (2.65*(16.66));

} else {
	segmentsAcked = (int) (7.51*(14.52));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (19.51*(segmentsAcked)*(8.62));

} else {
	tcb->m_cWnd = (int) (8.24/7.05);
	DNEucACXQUpsNTgL = (int) (2.08-(9.25)-(13.11));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (19.51*(segmentsAcked)*(8.62));

} else {
	tcb->m_cWnd = (int) (8.24/7.05);
	DNEucACXQUpsNTgL = (int) (2.08-(9.25)-(13.11));

}
