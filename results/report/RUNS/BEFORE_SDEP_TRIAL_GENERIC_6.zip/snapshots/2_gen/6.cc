int nlkVqdsRBGQQjkpI = (int) (11+(-11));
int DNEucACXQUpsNTgL = (int) (9+(17)+(4)+(18));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	DNEucACXQUpsNTgL = (int) (6.5/4.43);

} else {
	DNEucACXQUpsNTgL = (int) (6.46-(17.19)-(DNEucACXQUpsNTgL)-(4.2));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (nlkVqdsRBGQQjkpI < segmentsAcked) {
	segmentsAcked = (int) (13.7-(17.19));
	nlkVqdsRBGQQjkpI = (int) (5.7/10.73);
	tcb->m_cWnd = (int) (2.65*(16.66));

} else {
	segmentsAcked = (int) (7.51*(14.52));

}
if (nlkVqdsRBGQQjkpI < segmentsAcked) {
	segmentsAcked = (int) (13.7-(17.19));
	nlkVqdsRBGQQjkpI = (int) (5.7/10.73);
	tcb->m_cWnd = (int) (2.65*(16.66));

} else {
	segmentsAcked = (int) (7.51*(14.52));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (19.51*(segmentsAcked)*(8.62));

} else {
	tcb->m_cWnd = (int) (8.24/7.05);
	DNEucACXQUpsNTgL = (int) (2.08-(9.25)-(13.11));

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (19.51*(segmentsAcked)*(8.62));

} else {
	tcb->m_cWnd = (int) (8.24/7.05);
	DNEucACXQUpsNTgL = (int) (2.08-(9.25)-(13.11));

}
