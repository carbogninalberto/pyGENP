float sjcJgfYXtdBsaJDT = (float) (19*(8)*(8));
