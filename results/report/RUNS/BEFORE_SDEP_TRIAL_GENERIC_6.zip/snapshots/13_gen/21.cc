TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int UGoNprfOUntYVbvJ = (int) (-5/-15);
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (10+(-18)+(-7));
UGoNprfOUntYVbvJ = (int) (-12+(19)+(-12));
UGoNprfOUntYVbvJ = (int) (-2+(-12)+(4));
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (19+(5)+(14));
CongestionAvoidance (tcb, segmentsAcked);
