TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int UGoNprfOUntYVbvJ = (int) (15*(-13)*(-11)*(12));
UGoNprfOUntYVbvJ = (int) (-13+(-8)+(-2));
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (-5+(-19)+(5));
UGoNprfOUntYVbvJ = (int) (-9+(19)+(10));
UGoNprfOUntYVbvJ = (int) (-8+(-20)+(18));
CongestionAvoidance (tcb, segmentsAcked);
