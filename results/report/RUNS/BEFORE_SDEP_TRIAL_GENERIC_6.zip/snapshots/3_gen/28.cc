if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (16.53+(tcb->m_segmentSize)+(9.27));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(17.59));

}
segmentsAcked = (int) (-2+(-19)+(11));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
