segmentsAcked = SlowStart (tcb, segmentsAcked);
int ZxnyRIKsosukwKdJ = (int) (14+(3));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (ZxnyRIKsosukwKdJ >= segmentsAcked) {
	ZxnyRIKsosukwKdJ = (int) (3.52/2.34);
	segmentsAcked = (int) (4.97-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (4.16+(tcb->m_segmentSize));

} else {
	ZxnyRIKsosukwKdJ = (int) (9.82+(18.66)+(10.65));
	tcb->m_cWnd = (int) (14.56/8.54);
	ZxnyRIKsosukwKdJ = (int) (14.87/1);

}
if (ZxnyRIKsosukwKdJ >= segmentsAcked) {
	ZxnyRIKsosukwKdJ = (int) (3.52/2.34);
	segmentsAcked = (int) (4.97-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (4.16+(tcb->m_segmentSize));

} else {
	ZxnyRIKsosukwKdJ = (int) (9.82+(18.66)+(10.65));
	tcb->m_cWnd = (int) (14.56/8.54);
	ZxnyRIKsosukwKdJ = (int) (14.87/1);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked == ZxnyRIKsosukwKdJ) {
	ZxnyRIKsosukwKdJ = (int) (17.49+(18.81)+(10.2)+(segmentsAcked));
	ZxnyRIKsosukwKdJ = (int) (tcb->m_cWnd-(19.13));

} else {
	ZxnyRIKsosukwKdJ = (int) (11.11*(ZxnyRIKsosukwKdJ));
	segmentsAcked = (int) (19.49+(18.21)+(19.54));

}
if (segmentsAcked == ZxnyRIKsosukwKdJ) {
	ZxnyRIKsosukwKdJ = (int) (17.49+(18.81)+(10.2)+(segmentsAcked));
	ZxnyRIKsosukwKdJ = (int) (tcb->m_cWnd-(19.13));

} else {
	ZxnyRIKsosukwKdJ = (int) (11.11*(ZxnyRIKsosukwKdJ));
	segmentsAcked = (int) (19.49+(18.21)+(19.54));

}
