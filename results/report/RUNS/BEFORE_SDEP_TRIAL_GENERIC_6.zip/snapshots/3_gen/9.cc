if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (11.91*(17.2)*(10.24));

} else {
	tcb->m_cWnd = (int) (12.17*(8.14)*(15.81)*(13.2));
	tcb->m_cWnd = (int) (17.62-(12.25));
	segmentsAcked = (int) (5.14-(15.36)-(4.47)-(11.39));

}
int DNEucACXQUpsNTgL = (int) (-15+(-3)+(-17)+(-18));
int nlkVqdsRBGQQjkpI = (int) ((16.32+(20.0)+(19.21)+(10.52))/10);
