int UGoNprfOUntYVbvJ = (int) (-9/12);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (-15+(9)+(-13));
UGoNprfOUntYVbvJ = (int) (3+(-20)+(-6));
