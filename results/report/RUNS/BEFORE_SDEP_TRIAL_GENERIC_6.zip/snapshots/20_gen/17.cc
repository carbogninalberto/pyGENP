int UGoNprfOUntYVbvJ = (int) (-7/-16);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (-15+(-8)+(6));
UGoNprfOUntYVbvJ = (int) (18+(-4)+(-4));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
