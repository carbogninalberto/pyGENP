int UGoNprfOUntYVbvJ = (int) (2/8);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (2+(9)+(-1));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
