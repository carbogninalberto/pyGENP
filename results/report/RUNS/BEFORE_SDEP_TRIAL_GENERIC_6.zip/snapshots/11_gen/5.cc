TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int UGoNprfOUntYVbvJ = (int) (-12+(-16)+(6)+(15));
UGoNprfOUntYVbvJ = (int) (7+(-7)+(-19));
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (-3+(1)+(-9));
UGoNprfOUntYVbvJ = (int) (1+(-1)+(-15));
UGoNprfOUntYVbvJ = (int) (9+(-17)+(-14));
