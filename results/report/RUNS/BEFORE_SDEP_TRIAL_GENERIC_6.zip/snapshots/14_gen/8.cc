int UGoNprfOUntYVbvJ = (int) (-5*(-13)*(-6)*(9));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (19+(-12)+(-9));
CongestionAvoidance (tcb, segmentsAcked);
UGoNprfOUntYVbvJ = (int) (17+(-7)+(1));
UGoNprfOUntYVbvJ = (int) (-17+(-5)+(-15));
UGoNprfOUntYVbvJ = (int) (-14+(7)+(-11));
CongestionAvoidance (tcb, segmentsAcked);
