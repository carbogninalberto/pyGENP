segmentsAcked = (int) (15.76*(7.24));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (16.22-(7.21));
	tcb->m_segmentSize = (int) (1.03+(tcb->m_segmentSize)+(tcb->m_cWnd)+(2.48));
	tcb->m_cWnd = (int) (8.58*(segmentsAcked)*(18.78)*(9.65));

} else {
	tcb->m_cWnd = (int) (13.81*(4.63));
	tcb->m_segmentSize = (int) (10.94-(19.13)-(tcb->m_cWnd)-(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_segmentSize+(5.25)+(18.68)+(2.66));

} else {
	segmentsAcked = (int) (6.91+(9.36));
	segmentsAcked = (int) (15.43-(15.92)-(segmentsAcked));

}
tcb->m_cWnd = (int) (19.13-(4.2)-(6.9));
tcb->m_segmentSize = (int) (14.23/12.83);
