CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd*(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (4.94/2.9);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (segmentsAcked-(12.68)-(tcb->m_segmentSize));
tcb->m_cWnd = (int) (segmentsAcked+(1.51));
float IvCXZTgTKQljvKBI = (float) (3.57-(9.22)-(5.81));
IvCXZTgTKQljvKBI = (float) (18.05-(10.9));
