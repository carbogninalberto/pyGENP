if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (8.38/4.9);
	tcb->m_segmentSize = (int) (9.37*(10.81)*(5.35));
	tcb->m_segmentSize = (int) (19.67+(0.79)+(9.04));

} else {
	tcb->m_cWnd = (int) (8.75+(6.33)+(10.72));
	tcb->m_cWnd = (int) ((19.11+(4.58)+(3.45)+(5.2))/5.77);

}
segmentsAcked = (int) (10.8-(12.63)-(4.58));
tcb->m_cWnd = (int) (19.88+(4.68)+(0.27)+(1.81));
tcb->m_segmentSize = (int) (16.47-(7.94)-(5.1)-(4.71));
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (16.4-(10.47)-(2.19));

} else {
	tcb->m_segmentSize = (int) (1.52/13.41);
	tcb->m_segmentSize = (int) (15.98+(12.28)+(8.45)+(3.98));
	segmentsAcked = (int) (tcb->m_segmentSize*(segmentsAcked)*(1.6));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
