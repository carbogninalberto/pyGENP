CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (13.53-(5.96)-(17.09)-(5.94));
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (8.21*(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (10.66+(12.37));
	segmentsAcked = (int) (segmentsAcked*(tcb->m_cWnd));

}
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (segmentsAcked*(segmentsAcked)*(segmentsAcked)*(0.73));
	segmentsAcked = (int) (segmentsAcked+(8.24)+(6.75));

} else {
	tcb->m_cWnd = (int) (15.47*(5.38)*(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (14.52/6.39);

}
segmentsAcked = (int) (8.86+(10.14)+(tcb->m_cWnd));
