TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
int UGoNprfOUntYVbvJ = (int) (14.06/16.42);
UGoNprfOUntYVbvJ = (int) (6.19+(tcb->m_segmentSize)+(14.61));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
