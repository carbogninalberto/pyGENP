float ImEacHcPydJDDtAu = (float) (6.8*(4.87));
ImEacHcPydJDDtAu = (float) (tcb->m_segmentSize*(ImEacHcPydJDDtAu));
tcb->m_segmentSize = (int) (9.09-(ImEacHcPydJDDtAu)-(15.9)-(4.42));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(7.33));
	ImEacHcPydJDDtAu = (float) ((15.34+(18.66)+(14.97)+(14.72))/1.66);
	tcb->m_cWnd = (int) (1.34/1.9);

} else {
	tcb->m_cWnd = (int) (5.2*(ImEacHcPydJDDtAu)*(tcb->m_segmentSize)*(tcb->m_segmentSize));

}
int SHzmpJzUHONqNZoW = (int) (18.94/7.38);
tcb->m_segmentSize = (int) (10.85+(8.78));
if (ImEacHcPydJDDtAu != tcb->m_cWnd) {
	ImEacHcPydJDDtAu = (float) (4.14-(13.36)-(17.62)-(0.87));
	ImEacHcPydJDDtAu = (float) (11.24*(8.43));

} else {
	ImEacHcPydJDDtAu = (float) (18.24/5.67);
	SHzmpJzUHONqNZoW = (int) ((tcb->m_segmentSize+(0.57))/17.71);

}
if (SHzmpJzUHONqNZoW < SHzmpJzUHONqNZoW) {
	segmentsAcked = (int) (7.09+(5.24));
	SHzmpJzUHONqNZoW = (int) (11.73-(14.62)-(17.73));
	tcb->m_cWnd = (int) (13.41/(2.66*(4.96)));

} else {
	segmentsAcked = (int) (segmentsAcked-(15.57));
	tcb->m_segmentSize = (int) (16.86/5.87);
	tcb->m_segmentSize = (int) (13.32/6.22);

}
