segmentsAcked = (int) (15.91-(11.7));
tcb->m_segmentSize = (int) (9.23*(9.95)*(5.28));
tcb->m_cWnd = (int) (0.23-(tcb->m_cWnd)-(2.55)-(12.37));
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (8.08+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (9.34-(segmentsAcked)-(2.82));
	tcb->m_segmentSize = (int) (16.73+(14.57)+(7.25));

} else {
	tcb->m_segmentSize = (int) (18.23+(14.42));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
