tcb->m_segmentSize = (int) (4.38+(15.37)+(segmentsAcked));
float teQvgMxhEryKlTKn = (float) (3.51/(16.96-(19.69)));
CongestionAvoidance (tcb, segmentsAcked);
if (teQvgMxhEryKlTKn > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.92*(3.77));
	tcb->m_segmentSize = (int) (6.82/14.95);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(teQvgMxhEryKlTKn));

}
float qtTZTtRAOYPyQZem = (float) (tcb->m_segmentSize*(15.78)*(1.0));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
