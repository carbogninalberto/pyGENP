if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_segmentSize = (int) (5.45*(10.65)*(3.72));
	tcb->m_segmentSize = (int) (15.68*(8.59)*(11.4));

} else {
	tcb->m_segmentSize = (int) (3.59/15.39);
	tcb->m_cWnd = (int) (11.44/12.79);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
int OUocwHfjxPBQYFxd = (int) (13.22+(17.37)+(17.64)+(15.24));
float WLCTIImKaPwLTLvP = (float) (8.05/8.43);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
OUocwHfjxPBQYFxd = (int) (1.03/11.81);
