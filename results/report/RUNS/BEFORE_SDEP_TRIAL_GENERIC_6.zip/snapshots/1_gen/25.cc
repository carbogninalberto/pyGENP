segmentsAcked = (int) (1.96+(2.27)+(6.24));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (1.57-(9.38)-(8.77));

} else {
	tcb->m_cWnd = (int) (10.55-(16.19)-(8.11));

}
tcb->m_cWnd = (int) (17.71*(6.22)*(segmentsAcked));
if (tcb->m_cWnd > tcb->m_cWnd) {
	segmentsAcked = (int) (17.32/16.09);
	segmentsAcked = (int) (7.13-(segmentsAcked)-(11.68));
	tcb->m_cWnd = (int) (0.56*(18.45));

} else {
	segmentsAcked = (int) (18.34*(1.86));
	tcb->m_segmentSize = (int) (11.07-(6.44)-(0.83));
	tcb->m_cWnd = (int) (18.66+(14.82)+(13.74));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_segmentSize) {
	segmentsAcked = (int) (4.88*(segmentsAcked)*(16.51)*(16.49));
	tcb->m_segmentSize = (int) (10.14+(9.77)+(18.81)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (19.05/(10.86+(14.93)+(1.56)));

} else {
	segmentsAcked = (int) (16.17+(segmentsAcked));

}
segmentsAcked = (int) (16.61+(1.81)+(3.39)+(tcb->m_segmentSize));
