tcb->m_segmentSize = (int) (tcb->m_segmentSize*(10.65)*(segmentsAcked)*(tcb->m_segmentSize));
tcb->m_cWnd = (int) (10.03/12.39);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (3.69-(15.79)-(10.53));
	tcb->m_segmentSize = (int) (18.72+(10.01)+(6.61));

} else {
	tcb->m_cWnd = (int) (8.14-(4.5));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (17.68+(tcb->m_segmentSize)+(14.61)+(tcb->m_cWnd));
segmentsAcked = SlowStart (tcb, segmentsAcked);
