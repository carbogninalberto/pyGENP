TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int smTHJUYPvRJeuCtU = (int) (14.51-(tcb->m_cWnd)-(tcb->m_cWnd)-(1.33));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float ZNgmxuDRHsISkXxB = (float) (15.73/9.14);
float fOIkAvDZGTNWyWLs = (float) (3.13*(6.88)*(smTHJUYPvRJeuCtU)*(2.23));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (2.82/10.43);
