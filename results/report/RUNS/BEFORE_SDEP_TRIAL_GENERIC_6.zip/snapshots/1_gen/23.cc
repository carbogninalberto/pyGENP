int bMdbAzEnsgXLkXOW = (int) (2.59*(10.63)*(7.04)*(18.74));
segmentsAcked = (int) (0.94*(3.38)*(9.76));
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_cWnd = (int) (2.88/1.35);
	segmentsAcked = (int) (1.25/2.85);

} else {
	tcb->m_cWnd = (int) (4.25*(13.52));

}
tcb->m_segmentSize = (int) (6.01*(4.9)*(segmentsAcked)*(15.68));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked+(11.87)+(11.94));
	segmentsAcked = (int) (bMdbAzEnsgXLkXOW+(tcb->m_segmentSize)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (18.31-(13.51)-(7.62));
	tcb->m_cWnd = (int) (segmentsAcked*(tcb->m_cWnd));

}
