segmentsAcked = (int) (-79.761+(-16.397));
float EBsFsvHFqPajraTb = (float) (-38.318/45.807);
tcb->m_cWnd = (int) (62.948-(-65.117)-(-28.206)-(-47.522));
segmentsAcked = (int) (-66.686+(-61.141));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
tcb->m_cWnd = (int) (-15.751-(91.082)-(34.675)-(87.708));
segmentsAcked = (int) (94.544+(-88.582));
tcb->m_cWnd = (int) (5.046-(61.66)-(57.956)-(36.165));
segmentsAcked = (int) (-75.493+(-50.515));
segmentsAcked = (int) (18.657+(24.851));
tcb->m_cWnd = (int) (26.756-(-1.029)-(74.147)-(-43.274));
tcb->m_cWnd = (int) (-68.723-(12.76)-(47.092)-(12.048));
tcb->m_cWnd = (int) (-19.482-(74.969)-(-94.761)-(-91.872));
tcb->m_cWnd = (int) (38.932-(-66.688)-(73.323)-(-82.943));
tcb->m_cWnd = (int) (61.707-(7.499)-(84.01)-(27.316));
segmentsAcked = (int) (-81.37+(82.912));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
tcb->m_cWnd = (int) (72.11-(-26.466)-(-7.367)-(2.28));
segmentsAcked = (int) (-86.448+(-60.504));
segmentsAcked = (int) (52.613+(-24.942));
segmentsAcked = (int) (12.29+(72.555));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
tcb->m_cWnd = (int) (16.338-(33.362)-(59.13)-(51.231));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
tcb->m_cWnd = (int) (-13.041-(49.495)-(-76.408)-(87.577));
tcb->m_cWnd = (int) (88.768-(37.529)-(61.821)-(13.046));
tcb->m_cWnd = (int) (77.932-(53.424)-(-60.193)-(-26.363));
segmentsAcked = (int) (-78.342+(-8.802));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (-49.595-(-80.834)-(-72.017)-(46.161));
segmentsAcked = (int) (-49.352+(6.134));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
