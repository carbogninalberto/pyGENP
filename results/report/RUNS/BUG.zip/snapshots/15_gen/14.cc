segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (80.345+(11.381));
tcb->m_cWnd = (int) (-6.024-(-59.767)-(61.229)-(-19.123));
segmentsAcked = (int) (50.864+(-77.561));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
tcb->m_cWnd = (int) (-26.429-(54.735)-(88.389)-(96.285));
segmentsAcked = (int) (-30.73+(68.815));
tcb->m_cWnd = (int) (-13.677-(-55.14)-(-81.236)-(-52.495));
segmentsAcked = (int) (-64.619+(-71.11));
tcb->m_cWnd = (int) (-76.436-(98.513)-(-86.441)-(6.337));
tcb->m_cWnd = (int) (-60.885-(-12.126)-(-54.939)-(-94.164));
tcb->m_cWnd = (int) (-4.478-(38.501)-(31.488)-(-16.638));
tcb->m_cWnd = (int) (-29.036-(-23.133)-(3.45)-(-86.743));
segmentsAcked = (int) (23.856+(19.92));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
tcb->m_cWnd = (int) (6.924-(-74.721)-(57.832)-(-64.185));
segmentsAcked = (int) (-62.634+(-39.671));
segmentsAcked = (int) (13.657+(-46.536));
segmentsAcked = (int) (75.484+(-0.678));
tcb->m_cWnd = (int) (55.217-(20.842)-(15.655)-(87.288));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
segmentsAcked = (int) (-1.162+(-15.092));
tcb->m_cWnd = (int) (-35.233-(-12.399)-(19.859)-(13.447));
tcb->m_cWnd = (int) (37.368-(-93.987)-(83.615)-(36.733));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
tcb->m_cWnd = (int) (-90.696-(-39.43)-(36.495)-(12.85));
tcb->m_cWnd = (int) (42.165-(-96.871)-(35.454)-(22.131));
tcb->m_cWnd = (int) (-16.529-(36.536)-(79.64)-(-33.34));
tcb->m_cWnd = (int) (8.427-(95.894)-(7.488)-(-16.224));
tcb->m_cWnd = (int) (17.944-(57.689)-(56.332)-(56.454));
tcb->m_cWnd = (int) (34.031-(-92.791)-(12.394)-(-27.214));
segmentsAcked = (int) (21.024+(-76.92));
segmentsAcked = (int) (98.505+(-95.337));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (-86.231-(32.887)-(35.887)-(-86.13));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
segmentsAcked = (int) (-29.453+(-67.329));
tcb->m_cWnd = (int) (-96.416-(-38.606)-(-92.964)-(55.091));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
segmentsAcked = (int) (-13.29+(-66.062));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
segmentsAcked = (int) (-78.656+(-61.237));
segmentsAcked = (int) (-77.97+(80.92));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
tcb->m_cWnd = (int) (-54.164-(-12.646)-(-41.183)-(-68.686));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
tcb->m_cWnd = (int) (-9.97-(11.7)-(22.107)-(-52.388));
tcb->m_cWnd = (int) (93.268-(74.273)-(-68.44)-(97.777));
tcb->m_cWnd = (int) (-22.662-(96.96)-(-10.873)-(-45.45));
segmentsAcked = (int) (10.449+(-95.863));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (32.992-(-58.872)-(-79.193)-(-65.789));
segmentsAcked = (int) (48.093+(-51.391));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
