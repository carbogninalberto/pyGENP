segmentsAcked = (int) (-85.423+(22.303));
segmentsAcked = (int) (-27.83+(-62.276));
tcb->m_cWnd = (int) (67.877-(-40.549)-(-18.371)-(22.943));
tcb->m_cWnd = (int) (77.912-(17.562)-(13.44)-(-13.112));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
segmentsAcked = (int) (88.655+(24.461));
segmentsAcked = (int) (92.893+(32.028));
tcb->m_cWnd = (int) (-43.801-(-57.669)-(40.956)-(-28.954));
tcb->m_cWnd = (int) (-4.597-(-86.924)-(-96.026)-(-39.172));
tcb->m_cWnd = (int) (-49.759-(69.7)-(61.443)-(96.853));
tcb->m_cWnd = (int) (-61.106-(9.573)-(39.703)-(14.923));
segmentsAcked = (int) (-93.286+(-21.173));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (31.885-(25.703)-(-55.218)-(-36.897));
segmentsAcked = (int) (-73.783+(-88.312));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
segmentsAcked = (int) (-50.739+(26.402));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
segmentsAcked = (int) (95.847+(-9.454));
tcb->m_cWnd = (int) (70.399-(77.597)-(-70.645)-(84.356));
tcb->m_cWnd = (int) (4.825-(42.984)-(-62.862)-(4.066));
tcb->m_cWnd = (int) (-96.957-(-75.489)-(57.028)-(90.801));
tcb->m_cWnd = (int) (29.486-(26.45)-(-48.888)-(97.789));
segmentsAcked = (int) (37.169+(-17.85));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (38.08-(-53.884)-(90.637)-(92.187));
segmentsAcked = (int) (2.387+(87.379));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
