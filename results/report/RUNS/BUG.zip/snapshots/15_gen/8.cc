segmentsAcked = (int) (-88.838+(71.948));
float EGscZFCRTRBzIJFp = (float) (72.215+(-2.382)+(-68.262));
tcb->m_cWnd = (int) (-1.182-(94.737)-(14.369)-(-29.863));
segmentsAcked = (int) (-55.07+(86.136));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

}
tcb->m_cWnd = (int) (-53.799-(-82.786)-(-1.026)-(58.854));
segmentsAcked = (int) (34.638+(-76.001));
tcb->m_cWnd = (int) (74.642-(60.034)-(-16.739)-(87.989));
segmentsAcked = (int) (-60.055+(-38.018));
tcb->m_cWnd = (int) (55.279-(-47.274)-(85.312)-(72.918));
tcb->m_cWnd = (int) (98.03-(-86.012)-(34.5)-(-94.723));
tcb->m_cWnd = (int) (84.678-(29.622)-(-16.82)-(-81.075));
tcb->m_cWnd = (int) (35.155-(-20.882)-(59.032)-(-56.76));
segmentsAcked = (int) (-46.688+(-91.059));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
tcb->m_cWnd = (int) (-62.356-(70.575)-(30.385)-(98.856));
segmentsAcked = (int) (1.515+(61.446));
segmentsAcked = (int) (-15.998+(-40.26));
segmentsAcked = (int) (57.312+(37.11));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
tcb->m_cWnd = (int) (-43.982-(-31.931)-(-76.382)-(-50.967));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
tcb->m_cWnd = (int) (82.365-(-70.658)-(-57.255)-(49.914));
tcb->m_cWnd = (int) (-87.934-(-40.599)-(-9.813)-(5.916));
tcb->m_cWnd = (int) (43.728-(79.308)-(-77.203)-(-75.397));
segmentsAcked = (int) (-73.054+(-92.131));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (14.445-(67.559)-(96.657)-(-80.748));
segmentsAcked = (int) (27.441+(-15.263));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
