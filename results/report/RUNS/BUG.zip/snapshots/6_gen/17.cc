float FAoBoYUOISGWossW = (float) (27.44*(-84.75)*(-61.164)*(6.052));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (71.148*(-62.277)*(-96.577)*(34.645));
tcb->m_segmentSize = (int) (-19.369*(-69.143)*(-87.15)*(-46.503));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
