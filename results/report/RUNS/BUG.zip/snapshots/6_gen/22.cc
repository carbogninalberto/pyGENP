float SkuUtUElywLwuwqC = (float) (-84.475+(-28.361));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (69.306-(-39.161)-(-70.598)-(-27.864));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-63.38));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-86.719-(7.035));

}
segmentsAcked = (int) (-10.651+(51.002));
tcb->m_cWnd = (int) (-4.133-(-92.277)-(-98.684)-(3.223));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.706));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (39.325-(7.035));

}
segmentsAcked = (int) (-53.992+(-26.435));
tcb->m_cWnd = (int) (46.104-(33.587)-(-20.909)-(8.007));
tcb->m_cWnd = (int) (-4.887-(9.953)-(93.251)-(45.905));
segmentsAcked = (int) (44.363+(-29.246));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(6.392));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (38.15-(7.035));

}
