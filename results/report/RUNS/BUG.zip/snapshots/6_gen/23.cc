float SkuUtUElywLwuwqC = (float) (-16.254+(78.194));
tcb->m_cWnd = (int) (24.658-(61.067)-(-62.893)-(-38.486));
int hvPjGpklgfaEsCvS = (int) (0.628/-29.413);
segmentsAcked = (int) (-98.883+(58.889));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-15.487));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (82.029-(7.035));

}
tcb->m_cWnd = (int) (-28.093-(-27.314)-(49.027)-(21.077));
segmentsAcked = (int) (33.158+(-47.914));
tcb->m_cWnd = (int) (-55.219-(-92.574)-(23.826)-(-63.556));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-1.865));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (38.961-(7.035));

}
segmentsAcked = (int) (52.488+(85.144));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(34.589));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (95.911-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-13.793));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (52.169-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-54.369));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-84.597-(7.035));

}
segmentsAcked = (int) (-29.096+(44.445));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-9.661));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (79.476-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(40.039));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (10.767-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(83.699));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (82.506-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-64.683));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-10.936-(7.035));

}
segmentsAcked = (int) (-34.833+(90.915));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-35.091));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-58.989-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(97.841));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-93.572-(7.035));

}
tcb->m_cWnd = (int) (93.922-(-50.164)-(-54.274)-(-56.681));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(69.083));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-7.94-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-23.715));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-55.563-(7.035));

}
segmentsAcked = (int) (48.077+(-25.047));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-13.372));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (32.553-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-69.948));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-79.114-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-39.732));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (1.844-(7.035));

}
segmentsAcked = (int) (61.117+(22.497));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(4.035));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (24.01-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(35.217));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-58.71-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-97.53));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-45.71-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-74.757));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (84.507-(7.035));

}
segmentsAcked = (int) (87.212+(-17.549));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-19.285));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-68.35-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(50.113));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-34.73-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(59.776));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-11.961-(7.035));

}
