float XZcIRhvhAWbSdZcN = (float) (96.382*(-97.228)*(-7.927));
XZcIRhvhAWbSdZcN = (float) (11.233-(-94.947)-(47.526)-(97.311));
XZcIRhvhAWbSdZcN = (float) (-88.074-(-99.25)-(90.855)-(97.038));
XZcIRhvhAWbSdZcN = (float) (27.429-(64.945)-(-20.277)-(-76.029));
if (tcb->m_segmentSize >= XZcIRhvhAWbSdZcN) {
	XZcIRhvhAWbSdZcN = (float) (95.778*(tcb->m_segmentSize)*(18.667)*(46.491));
	segmentsAcked = (int) (48.423-(80.71)-(60.41));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	XZcIRhvhAWbSdZcN = (float) (91.641*(63.091));
	tcb->m_segmentSize = (int) ((95.83+(tcb->m_segmentSize)+(51.025)+(80.795))/17.65);
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= XZcIRhvhAWbSdZcN) {
	XZcIRhvhAWbSdZcN = (float) (95.778*(tcb->m_segmentSize)*(18.667)*(46.491));
	segmentsAcked = (int) (48.423-(80.71)-(60.41));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	XZcIRhvhAWbSdZcN = (float) (91.641*(63.091));
	tcb->m_segmentSize = (int) ((95.83+(tcb->m_segmentSize)+(51.025)+(80.795))/17.65);
	CongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
