float SkuUtUElywLwuwqC = (float) (-54.714+(-73.029));
float TvUggNCcdiCwQHWV = (float) (-11.808/-3.342);
tcb->m_segmentSize = (int) (61.723+(-45.893)+(-25.242)+(64.849));
tcb->m_cWnd = (int) (15.816-(86.071)-(83.99)-(72.707));
segmentsAcked = (int) (-12.659+(0.178));
segmentsAcked = (int) (73.896+(37.658));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
