float SkuUtUElywLwuwqC = (float) (28.617+(-36.973));
float TvUggNCcdiCwQHWV = (float) (-87.122/-53.969);
tcb->m_cWnd = (int) (56.897-(-34.046)-(20.1)-(-18.696));
segmentsAcked = (int) (-59.179+(92.943));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
