float SkuUtUElywLwuwqC = (float) (-96.279+(33.366));
float TvUggNCcdiCwQHWV = (float) (48.467/50.602);
tcb->m_cWnd = (int) (40.019-(-29.146)-(23.315)-(-65.302));
segmentsAcked = (int) (-55.225+(99.699));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
