int nuMcphbfPTdXXcLQ = (int) (-5.504*(73.211));
int jTklhakXfcyyqrZL = (int) (-84.775/-66.409);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
float CxOKsLzIVOfiFhQf = (float) (42.13+(-70.649)+(82.354));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
