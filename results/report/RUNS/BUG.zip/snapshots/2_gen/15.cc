float SkuUtUElywLwuwqC = (float) (92.586+(40.975));
float TvUggNCcdiCwQHWV = (float) (91.873/95.113);
if (segmentsAcked == SkuUtUElywLwuwqC) {
	TvUggNCcdiCwQHWV = (float) (15.513-(64.732)-(52.087));
	TvUggNCcdiCwQHWV = (float) (5.23-(1.126));

} else {
	TvUggNCcdiCwQHWV = (float) (95.366*(tcb->m_segmentSize)*(97.825));
	tcb->m_cWnd = (int) (42.922+(90.546)+(87.845)+(87.104));

}
segmentsAcked = (int) (-33.528+(-18.939));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
