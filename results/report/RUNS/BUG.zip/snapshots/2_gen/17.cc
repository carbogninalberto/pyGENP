float SkuUtUElywLwuwqC = (float) (-16.232+(12.266));
float TvUggNCcdiCwQHWV = (float) (-48.318/34.949);
if (tcb->m_cWnd != SkuUtUElywLwuwqC) {
	SkuUtUElywLwuwqC = (float) (66.376*(2.645));
	SkuUtUElywLwuwqC = (float) (SkuUtUElywLwuwqC*(30.113)*(79.852)*(71.089));
	SkuUtUElywLwuwqC = (float) (TvUggNCcdiCwQHWV*(segmentsAcked));

} else {
	SkuUtUElywLwuwqC = (float) (11.94/8.51);

}
segmentsAcked = (int) (-95.85+(-48.421));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
tcb->m_cWnd = (int) (-1.529-(1.722)-(16.857)-(86.355));
segmentsAcked = (int) (-28.382+(-5.44));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
