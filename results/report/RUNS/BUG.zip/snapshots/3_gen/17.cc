float TvUggNCcdiCwQHWV = (float) (-28.153/-16.903);
tcb->m_cWnd = (int) (-66.523-(-37.138)-(0.073)-(54.104));
segmentsAcked = (int) (-84.737+(90.78));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
