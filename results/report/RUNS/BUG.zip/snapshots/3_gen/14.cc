CongestionAvoidance (tcb, segmentsAcked);
float VYZlaTqNvCsAWqMu = (float) (26.082-(77.857)-(-58.286));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
