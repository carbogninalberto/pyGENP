tcb->m_cWnd = (int) (36.793-(segmentsAcked)-(48.132)-(13.01));
segmentsAcked = (int) (6.74+(98.978));
float TvUggNCcdiCwQHWV = (float) (4.47/17.44);
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
float SkuUtUElywLwuwqC = (float) (20.615+(20.029));
