ReduceCwnd (tcb);
segmentsAcked = (int) (86.276*(2.811));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (18.14/15.49);
	tcb->m_segmentSize = (int) ((65.44+(38.281))/1.95);

} else {
	tcb->m_cWnd = (int) (42.324+(72.082));
	segmentsAcked = (int) (78.567+(71.947)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (58.752-(89.508)-(12.288));

}
CongestionAvoidance (tcb, segmentsAcked);
