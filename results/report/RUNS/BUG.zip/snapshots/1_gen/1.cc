tcb->m_segmentSize = (int) (5.21/9.56);
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(92.234)-(50.25));

} else {
	tcb->m_cWnd = (int) (98.112+(21.329));
	tcb->m_segmentSize = (int) (64.909*(71.324));

}
segmentsAcked = (int) (6.783-(segmentsAcked));
int YWaqgXnIBArdhend = (int) (12.59/6.18);
if (YWaqgXnIBArdhend == tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_cWnd-(68.259)-(3.095));
	tcb->m_cWnd = (int) (28.292+(80.016)+(39.797));

} else {
	segmentsAcked = (int) (1/1.66);

}
