float FAoBoYUOISGWossW = (float) (6.879*(-93.366)*(11.502)*(6.074));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (66.002*(-28.986)*(-80.846)*(-94.863));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (11.983*(-1.952)*(-4.347)*(-20.589));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
