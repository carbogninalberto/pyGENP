tcb->m_segmentSize = (int) (7.331*(-50.19)*(-34.535)*(-98.682));
float tOqVtPRiMFUeODNh = (float) (13.174/67.181);
tcb->m_segmentSize = (int) (-7.337*(-32.877)*(-14.494)*(34.519));
