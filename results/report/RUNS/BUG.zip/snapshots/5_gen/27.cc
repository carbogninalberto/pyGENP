tcb->m_segmentSize = (int) (53.032*(58.821)*(-95.887)*(29.152));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (91.094+(-96.411));
segmentsAcked = (int) (84.642+(23.14));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(84.285));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-96.282-(7.035));

}
tcb->m_segmentSize = (int) (-98.41*(7.018)*(69.716)*(-12.469));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(5.033));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-94.741-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (66.854-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-42.038));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-88.529-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-58.04));

}
