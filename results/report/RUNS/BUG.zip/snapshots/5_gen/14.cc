segmentsAcked = SlowStart (tcb, segmentsAcked);
float FAoBoYUOISGWossW = (float) (-74.177*(-45.1)*(34.157)*(-7.911));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (-46.137*(12.477)*(6.651)*(52.193));
tcb->m_segmentSize = (int) (-86.714*(82.846)*(-45.083)*(90.787));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
