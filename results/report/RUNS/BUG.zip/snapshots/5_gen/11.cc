tcb->m_segmentSize = (int) (51.003+(27.843)+(63.204));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (6.022*(57.027)*(-66.174)*(72.494));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
