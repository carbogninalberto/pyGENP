tcb->m_cWnd = (int) (47.742-(85.937));
tcb->m_cWnd = (int) (-45.459-(68.366)-(78.782)-(62.641));
segmentsAcked = (int) (-45.458+(-11.012));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.181));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (74.734-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-59.447));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (29.385-(7.035));

}
