float IApCZhYMjBJyqkpC = (float) (-65.855-(15.654)-(14.429));
tcb->m_cWnd = (int) (67.316-(97.674)-(-35.55)-(99.31));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
segmentsAcked = (int) (-1.582+(51.314));
segmentsAcked = (int) (-90.8+(68.126));
tcb->m_cWnd = (int) (-94.067-(-54.537)-(-11.78)-(67.964));
tcb->m_cWnd = (int) (16.366-(38.73)-(42.474)-(0.482));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
segmentsAcked = (int) (12.286+(59.623));
segmentsAcked = (int) (-6.108+(-0.687));
tcb->m_cWnd = (int) (88.63-(60.62)-(-68.68)-(-88.372));
tcb->m_cWnd = (int) (23.169-(-61.406)-(54.322)-(-57.571));
tcb->m_cWnd = (int) (-78.975-(-1.943)-(-34.581)-(-10.165));
tcb->m_cWnd = (int) (-56.427-(93.032)-(9.461)-(-61.652));
segmentsAcked = (int) (89.438+(-2.539));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (16.25-(22.557)-(38.662)-(93.499));
segmentsAcked = (int) (12.885+(72.122));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
