float geXzXrxPNMckdtFh = (float) (-86.552/-88.67);
tcb->m_segmentSize = (int) (56.008*(5.8)*(0.284)*(82.723));
tcb->m_segmentSize = (int) (-97.621*(-50.72)*(87.603)*(73.457));
tcb->m_segmentSize = (int) (61.34*(9.943)*(12.072)*(72.994));
tcb->m_segmentSize = (int) (44.711*(95.723)*(52.083)*(-84.961));
tcb->m_segmentSize = (int) (-68.279*(60.866)*(-54.034)*(-10.136));
tcb->m_segmentSize = (int) (97.522*(69.44)*(-43.707)*(-74.78));
