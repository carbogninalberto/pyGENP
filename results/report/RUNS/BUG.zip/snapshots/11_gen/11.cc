float geXzXrxPNMckdtFh = (float) (-3.042/-82.547);
tcb->m_segmentSize = (int) (16.164*(-71.094)*(47.66)*(-67.38));
tcb->m_segmentSize = (int) (59.407*(4.897)*(-54.827)*(33.46));
tcb->m_segmentSize = (int) (-27.452*(-61.436)*(39.029)*(-52.907));
tcb->m_segmentSize = (int) (32.28*(28.003)*(-96.328)*(-1.193));
