float IApCZhYMjBJyqkpC = (float) (99.571-(67.171)-(-74.015));
tcb->m_cWnd = (int) (78.005-(-82.393)-(52.676)-(33.899));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
segmentsAcked = (int) (48.637+(99.954));
segmentsAcked = (int) (-94.486+(-60.253));
tcb->m_cWnd = (int) (80.346-(75.383)-(-41.782)-(81.779));
tcb->m_cWnd = (int) (-48.949-(-72.092)-(-93.14)-(97.596));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
segmentsAcked = (int) (85.093+(89.848));
segmentsAcked = (int) (45.421+(-36.127));
segmentsAcked = (int) (-14.5+(-50.379));
tcb->m_cWnd = (int) (93.831-(-24.783)-(4.345)-(-91.333));
tcb->m_cWnd = (int) (-30.544-(60.956)-(60.027)-(-53.89));
tcb->m_cWnd = (int) (-40.87-(96.092)-(21.662)-(32.148));
tcb->m_cWnd = (int) (90.779-(-83.183)-(85.305)-(46.13));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
tcb->m_cWnd = (int) (47.602-(-99.214)-(-90.549)-(71.053));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
tcb->m_cWnd = (int) (-36.901-(59.708)-(89.106)-(84.325));
segmentsAcked = (int) (-82.804+(71.239));
segmentsAcked = (int) (22.087+(-2.027));
segmentsAcked = (int) (-70.178+(-92.914));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (-39.252-(-56.774)-(57.16)-(81.747));
tcb->m_cWnd = (int) (-60.561-(-5.806)-(-55.58)-(35.243));
tcb->m_cWnd = (int) (83.96-(2.906)-(99.588)-(-71.439));
segmentsAcked = (int) (-11.17+(-14.828));
tcb->m_cWnd = (int) (75.127-(-39.534)-(-96.652)-(-42.968));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
tcb->m_cWnd = (int) (-62.734-(-30.815)-(-30.613)-(74.082));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
segmentsAcked = (int) (-50.117+(51.113));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (-37.357-(-7.665)-(48.087)-(-53.834));
segmentsAcked = (int) (-79.685+(21.693));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
