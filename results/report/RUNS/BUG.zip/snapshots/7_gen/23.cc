tcb->m_segmentSize = (int) (76.332*(40.873)*(7.365)*(4.14));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float FAoBoYUOISGWossW = (float) (-62.538*(18.569)*(14.532)*(52.218));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (75.073*(-13.106)*(-72.943)*(47.875));
tcb->m_segmentSize = (int) (-57.818*(-56.603)*(5.78)*(-36.668));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
