CongestionAvoidance (tcb, segmentsAcked);
float GLXreniXpcCaWRWP = (float) (-58.201/16.003);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
