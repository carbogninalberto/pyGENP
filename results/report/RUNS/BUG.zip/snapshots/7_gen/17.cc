float TvUggNCcdiCwQHWV = (float) (-31.285/-82.713);
TvUggNCcdiCwQHWV = (float) (43.342/-58.18);
tcb->m_cWnd = (int) (92.96-(-93.799)-(-49.492)-(3.264));
segmentsAcked = (int) (47.401+(-35.305));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

}
tcb->m_cWnd = (int) (-74.042-(-10.763)-(-31.365)-(87.46));
segmentsAcked = (int) (69.968+(62.856));
tcb->m_cWnd = (int) (-87.345-(-34.481)-(-37.113)-(33.012));
segmentsAcked = (int) (-46.027+(-18.142));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
tcb->m_cWnd = (int) (-85.664-(-58.81)-(53.696)-(-45.462));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
tcb->m_cWnd = (int) (-44.139-(23.817)-(-37.219)-(55.596));
segmentsAcked = (int) (56.752+(-53.185));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
segmentsAcked = (int) (40.744+(-58.037));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
tcb->m_cWnd = (int) (7.209-(-90.915)-(20.125)-(37.122));
segmentsAcked = (int) (55.963+(-78.007));
tcb->m_cWnd = (int) (-16.013-(32.844)-(63.802)-(-10.107));
segmentsAcked = (int) (41.278+(42.704));
tcb->m_cWnd = (int) (-53.799-(-6.283)-(64.05)-(79.801));
tcb->m_cWnd = (int) (37.098-(13.895)-(-41.461)-(56.933));
tcb->m_cWnd = (int) (22.026-(35.186)-(-12.031)-(75.783));
tcb->m_cWnd = (int) (-67.521-(-98.592)-(78.935)-(9.278));
segmentsAcked = (int) (11.761+(54.431));
tcb->m_cWnd = (int) (49.896-(-87.529)-(-6.019)-(64.213));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
tcb->m_cWnd = (int) (-68.301-(-14.619)-(10.854)-(78.074));
tcb->m_cWnd = (int) (-14.601-(-84.159)-(-49.542)-(-60.803));
segmentsAcked = (int) (24.81+(7.256));
segmentsAcked = (int) (-22.748+(-40.85));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
tcb->m_cWnd = (int) (-98.079-(-51.408)-(22.11)-(-76.63));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
segmentsAcked = (int) (-76.256+(73.018));
segmentsAcked = (int) (-94.666+(65.222));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
segmentsAcked = (int) (47.719+(58.661));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
segmentsAcked = (int) (-49.244+(-15.986));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
segmentsAcked = (int) (-60.84+(-36.408));
segmentsAcked = (int) (78.373+(21.147));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
segmentsAcked = (int) (47.436+(39.972));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
