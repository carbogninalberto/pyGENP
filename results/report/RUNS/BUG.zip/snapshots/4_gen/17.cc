float SkuUtUElywLwuwqC = (float) (45.54+(-18.453));
float TvUggNCcdiCwQHWV = (float) (74.703/30.117);
tcb->m_cWnd = (int) (13.658-(65.017)-(52.357)-(-29.433));
float MVSVIYgkhZEUEphC = (float) (9.562+(43.878)+(-14.311));
segmentsAcked = (int) (70.473+(50.481));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

}
segmentsAcked = (int) (76.207+(93.911));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
