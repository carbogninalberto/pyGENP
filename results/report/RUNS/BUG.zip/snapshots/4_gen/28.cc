float TvUggNCcdiCwQHWV = (float) (53.437/11.777);
