float SkuUtUElywLwuwqC = (float) (87.308+(-29.193));
float TvUggNCcdiCwQHWV = (float) (-33.901/-52.563);
if (tcb->m_cWnd != TvUggNCcdiCwQHWV) {
	SkuUtUElywLwuwqC = (float) (57.204-(79.069)-(48.738));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	SkuUtUElywLwuwqC = (float) (23.558*(77.429)*(SkuUtUElywLwuwqC));

}
tcb->m_cWnd = (int) (75.983-(59.313)-(87.225)-(61.355));
segmentsAcked = (int) (-34.058+(94.732));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
tcb->m_cWnd = (int) (46.901-(-36.803)-(15.606)-(-9.023));
segmentsAcked = (int) (81.197+(72.134));
tcb->m_cWnd = (int) (16.567-(37.091)-(-96.331)-(4.286));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
segmentsAcked = (int) (-94.863+(11.429));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
segmentsAcked = (int) (-22.665+(98.782));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(TvUggNCcdiCwQHWV));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (TvUggNCcdiCwQHWV-(7.035));

}
