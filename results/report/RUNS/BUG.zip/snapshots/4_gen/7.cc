if (tcb->m_segmentSize != tcb->m_cWnd) {
	segmentsAcked = (int) (26.504-(18.803)-(75.569));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(93.79)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (68.384+(78.33)+(65.021)+(tcb->m_segmentSize));
	segmentsAcked = (int) (46.051-(6.188)-(segmentsAcked));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	segmentsAcked = (int) (26.504-(18.803)-(75.569));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(93.79)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (68.384+(78.33)+(65.021)+(tcb->m_segmentSize));
	segmentsAcked = (int) (46.051-(6.188)-(segmentsAcked));

}
tcb->m_segmentSize = (int) (39.578*(39.618)*(-44.291)*(-29.996));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (81.243*(78.978)*(-64.068)*(95.946));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
