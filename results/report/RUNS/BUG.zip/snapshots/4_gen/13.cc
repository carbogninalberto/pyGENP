float TvUggNCcdiCwQHWV = (float) (23.301/55.438);
