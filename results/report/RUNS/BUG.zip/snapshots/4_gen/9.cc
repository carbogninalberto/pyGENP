int nuMcphbfPTdXXcLQ = (int) (-73.659*(-87.965));
int jTklhakXfcyyqrZL = (int) (-28.134/-0.321);
CongestionAvoidance (tcb, segmentsAcked);
float CxOKsLzIVOfiFhQf = (float) (52.367+(-65.503)+(88.232));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
