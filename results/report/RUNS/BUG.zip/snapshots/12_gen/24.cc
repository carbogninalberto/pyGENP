segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-82.422+(55.422));
tcb->m_cWnd = (int) (-1.966-(-97.849)-(-75.2)-(82.483));
segmentsAcked = (int) (20.834+(-51.063));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
tcb->m_cWnd = (int) (-23.773-(86.356)-(37.079)-(-74.251));
segmentsAcked = (int) (51.627+(12.708));
tcb->m_cWnd = (int) (46.546-(7.241)-(46.551)-(72.86));
segmentsAcked = (int) (-83.693+(53.279));
tcb->m_cWnd = (int) (65.406-(-90.877)-(-47.85)-(99.857));
tcb->m_cWnd = (int) (79.319-(40.696)-(47.734)-(77.786));
tcb->m_cWnd = (int) (-53.177-(-63.286)-(21.867)-(22.478));
tcb->m_cWnd = (int) (35.875-(-23.238)-(93.268)-(45.167));
segmentsAcked = (int) (-25.506+(-92.075));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
tcb->m_cWnd = (int) (20.815-(3.54)-(52.809)-(45.1));
segmentsAcked = (int) (-91.961+(1.843));
segmentsAcked = (int) (54.847+(19.467));
segmentsAcked = (int) (13.185+(62.896));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
tcb->m_cWnd = (int) (70.367-(-79.318)-(-50.976)-(-97.565));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
tcb->m_cWnd = (int) (-62.971-(-8.122)-(15.85)-(-97.155));
tcb->m_cWnd = (int) (29.97-(-64.145)-(-71.152)-(12.083));
tcb->m_cWnd = (int) (22.428-(-82.636)-(63.211)-(-20.069));
segmentsAcked = (int) (-94.176+(40.991));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (-69.381-(48.939)-(-57.055)-(-65.34));
segmentsAcked = (int) (-46.638+(75.356));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
