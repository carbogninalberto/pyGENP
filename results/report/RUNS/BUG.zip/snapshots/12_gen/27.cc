float hPdygOZZaIlvmYFB = (float) (76.441*(-31.293)*(-87.518)*(-72.956));
segmentsAcked = (int) (67.935+(54.74));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (99.077+(-23.749));
segmentsAcked = (int) (75.116+(70.179));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(84.285));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-96.282-(7.035));

}
segmentsAcked = (int) (94.878+(-23.326));
tcb->m_segmentSize = (int) (-45.748*(17.678)*(7.708)*(-34.552));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(84.285));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-96.282-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(5.033));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-94.741-(7.035));

}
tcb->m_segmentSize = (int) (74.947*(8.468)*(-90.538)*(-32.504));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (66.854-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-42.038));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(5.033));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-94.741-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-88.529-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-58.04));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (66.854-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-42.038));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-88.529-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-58.04));

}
