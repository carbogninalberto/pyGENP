tcb->m_cWnd = (int) (52.155-(20.794)-(-41.627)-(-36.361));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
segmentsAcked = (int) (-70.572+(43.447));
segmentsAcked = (int) (-88.079+(-46.932));
tcb->m_cWnd = (int) (75.131-(-33.12)-(97.766)-(-61.985));
tcb->m_cWnd = (int) (9.398-(-58.706)-(10.178)-(-78.694));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
segmentsAcked = (int) (-48.016+(-57.601));
segmentsAcked = (int) (-20.986+(-76.096));
tcb->m_cWnd = (int) (-53.569-(-28.97)-(-23.611)-(-55.444));
tcb->m_cWnd = (int) (17.66-(66.075)-(-45.543)-(-26.673));
tcb->m_cWnd = (int) (11.596-(-19.815)-(56.182)-(31.444));
tcb->m_cWnd = (int) (-72.676-(-62.059)-(-77.526)-(-30.559));
segmentsAcked = (int) (-89.403+(38.304));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (-56.944-(33.095)-(68.571)-(-84.052));
segmentsAcked = (int) (-20.218+(-54.713));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
segmentsAcked = (int) (-84.661+(62.749));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
segmentsAcked = (int) (-85.404+(-5.723));
tcb->m_cWnd = (int) (-94.89-(-84.223)-(-94.75)-(-42.802));
tcb->m_cWnd = (int) (41.525-(-78.168)-(28.681)-(-9.352));
tcb->m_cWnd = (int) (53.702-(21.777)-(-37.884)-(-68.353));
tcb->m_cWnd = (int) (-70.511-(97.832)-(-47.097)-(-39.251));
segmentsAcked = (int) (83.13+(-84.217));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (-63.634-(46.135)-(24.492)-(-89.575));
segmentsAcked = (int) (-46.08+(-86.416));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
