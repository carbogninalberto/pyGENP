float hPdygOZZaIlvmYFB = (float) (62.274*(-53.371)*(-82.948)*(-52.046));
segmentsAcked = (int) (-91.35+(-23.882));
