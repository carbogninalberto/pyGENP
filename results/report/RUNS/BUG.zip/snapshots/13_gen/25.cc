tcb->m_cWnd = (int) (54.791-(-81.491)-(46.743)-(-81.875));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
segmentsAcked = (int) (-58.751+(20.206));
segmentsAcked = (int) (-57.671+(-72.962));
tcb->m_cWnd = (int) (-35.919-(85.06)-(49.713)-(57.179));
tcb->m_cWnd = (int) (-57.288-(-11.971)-(-41.937)-(9.377));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
segmentsAcked = (int) (-30.606+(-23.991));
segmentsAcked = (int) (99.792+(71.627));
tcb->m_cWnd = (int) (-42.999-(19.565)-(-87.13)-(0.206));
tcb->m_cWnd = (int) (3.553-(-35.902)-(2.736)-(84.003));
tcb->m_cWnd = (int) (-49.378-(93.68)-(-95.485)-(-28.235));
tcb->m_cWnd = (int) (-4.301-(57.784)-(3.693)-(85.659));
segmentsAcked = (int) (-69.997+(59.78));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (63.088-(61.804)-(38.082)-(94.553));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
segmentsAcked = (int) (-65.451+(-74.283));
tcb->m_cWnd = (int) (-50.014-(-73.578)-(-19.421)-(-30.275));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
segmentsAcked = (int) (74.2+(69.611));
segmentsAcked = (int) (48.441+(70.416));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
segmentsAcked = (int) (-48.447+(-13.603));
segmentsAcked = (int) (-0.318+(25.987));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
tcb->m_cWnd = (int) (-19.982-(-28.175)-(30.148)-(84.903));
segmentsAcked = (int) (50.516+(15.78));
tcb->m_cWnd = (int) (-39.908-(-98.962)-(-55.127)-(-31.403));
tcb->m_cWnd = (int) (-24.944-(79.681)-(-47.494)-(99.912));
tcb->m_cWnd = (int) (-65.071-(4.83)-(59.296)-(-89.737));
tcb->m_cWnd = (int) (63.05-(49.129)-(-77.729)-(-99.264));
tcb->m_cWnd = (int) (-27.829-(10.853)-(33.958)-(-18.152));
tcb->m_cWnd = (int) (-87.402-(83.202)-(19.888)-(-59.076));
segmentsAcked = (int) (8.108+(26.017));
tcb->m_cWnd = (int) (-77.809-(-46.272)-(32.078)-(18.686));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
segmentsAcked = (int) (3.243+(-72.665));
tcb->m_cWnd = (int) (34.353-(82.483)-(-49.631)-(95.951));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
segmentsAcked = (int) (73.901+(-49.671));
tcb->m_cWnd = (int) (-12.566-(13.145)-(-43.676)-(-57.26));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
segmentsAcked = (int) (88.84+(-96.639));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
