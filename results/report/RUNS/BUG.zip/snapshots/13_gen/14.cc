segmentsAcked = (int) (-21.322+(7.0));
