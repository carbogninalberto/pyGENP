if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
segmentsAcked = (int) (95.645+(-50.383));
segmentsAcked = (int) (-58.097+(28.271));
tcb->m_cWnd = (int) (94.886-(82.142)-(-22.936)-(31.057));
tcb->m_cWnd = (int) (-85.545-(66.997)-(61.278)-(-3.641));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
segmentsAcked = (int) (-19.137+(-58.342));
segmentsAcked = (int) (-66.032+(7.733));
tcb->m_cWnd = (int) (68.632-(-63.201)-(-88.098)-(-92.034));
tcb->m_cWnd = (int) (-45.054-(-95.293)-(-98.041)-(-11.57));
tcb->m_cWnd = (int) (-3.157-(13.636)-(-84.174)-(-94.24));
tcb->m_cWnd = (int) (-93.656-(-21.743)-(-13.405)-(55.912));
segmentsAcked = (int) (38.258+(-87.624));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (44.754-(-71.149)-(99.653)-(-0.887));
segmentsAcked = (int) (-23.342+(43.759));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
segmentsAcked = (int) (75.912+(94.298));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
segmentsAcked = (int) (-82.777+(38.71));
tcb->m_cWnd = (int) (-25.614-(-78.105)-(69.559)-(-41.437));
tcb->m_cWnd = (int) (1.258-(89.201)-(-65.781)-(-98.806));
tcb->m_cWnd = (int) (-53.847-(-75.655)-(75.772)-(51.928));
tcb->m_cWnd = (int) (58.687-(-54.073)-(-53.684)-(46.601));
segmentsAcked = (int) (5.493+(-37.343));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (-66.195-(-18.901)-(96.602)-(62.8));
segmentsAcked = (int) (78.011+(-58.615));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
