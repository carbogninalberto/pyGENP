segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (24.479+(-94.14));
tcb->m_cWnd = (int) (-27.311-(43.019)-(-69.935)-(97.858));
segmentsAcked = (int) (-84.94+(-68.483));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
tcb->m_cWnd = (int) (-88.882-(76.877)-(-96.591)-(-30.053));
segmentsAcked = (int) (44.757+(-25.809));
tcb->m_cWnd = (int) (10.2-(-81.736)-(-94.316)-(42.034));
segmentsAcked = (int) (84.323+(-38.979));
tcb->m_cWnd = (int) (-83.703-(-93.914)-(92.025)-(-88.416));
tcb->m_cWnd = (int) (-95.87-(-86.274)-(-68.239)-(-6.678));
tcb->m_cWnd = (int) (72.01-(85.112)-(85.198)-(-5.641));
tcb->m_cWnd = (int) (85.869-(-19.63)-(-87.377)-(47.446));
segmentsAcked = (int) (47.577+(-99.775));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
tcb->m_cWnd = (int) (-68.467-(-5.223)-(-76.536)-(31.574));
segmentsAcked = (int) (84.189+(-14.525));
segmentsAcked = (int) (89.749+(-50.323));
segmentsAcked = (int) (-46.972+(-68.204));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
tcb->m_cWnd = (int) (55.726-(-7.551)-(35.047)-(-48.546));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
tcb->m_cWnd = (int) (41.352-(-56.252)-(32.624)-(74.073));
tcb->m_cWnd = (int) (-92.864-(-30.41)-(74.017)-(75.255));
tcb->m_cWnd = (int) (-98.126-(60.2)-(-39.819)-(-49.952));
segmentsAcked = (int) (43.558+(6.674));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (98.134-(-41.187)-(52.338)-(35.084));
segmentsAcked = (int) (-18.759+(-22.673));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
