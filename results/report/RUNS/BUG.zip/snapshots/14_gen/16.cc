if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
segmentsAcked = (int) (-79.581+(-78.985));
segmentsAcked = (int) (48.453+(89.729));
tcb->m_cWnd = (int) (4.589-(-12.736)-(-17.302)-(-75.412));
tcb->m_cWnd = (int) (71.151-(16.192)-(-70.293)-(-53.045));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
segmentsAcked = (int) (-81.581+(73.413));
segmentsAcked = (int) (80.927+(63.897));
tcb->m_cWnd = (int) (-83.978-(-65.424)-(-25.633)-(-60.522));
tcb->m_cWnd = (int) (74.686-(4.771)-(-1.765)-(-83.774));
tcb->m_cWnd = (int) (48.193-(-60.922)-(-96.472)-(-79.083));
tcb->m_cWnd = (int) (71.403-(39.364)-(73.538)-(40.725));
segmentsAcked = (int) (96.193+(62.197));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (34.906-(90.046)-(95.007)-(36.949));
segmentsAcked = (int) (10.437+(62.516));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
segmentsAcked = (int) (10.434+(-93.485));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
segmentsAcked = (int) (-84.432+(58.38));
tcb->m_cWnd = (int) (21.185-(-73.339)-(-57.247)-(-8.482));
tcb->m_cWnd = (int) (40.644-(-64.54)-(52.62)-(74.663));
tcb->m_cWnd = (int) (11.028-(17.892)-(-99.555)-(27.322));
tcb->m_cWnd = (int) (46.32-(-2.272)-(-45.449)-(65.969));
segmentsAcked = (int) (58.722+(53.454));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (66.698-(57.651)-(97.941)-(-44.198));
segmentsAcked = (int) (-35.655+(72.408));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
