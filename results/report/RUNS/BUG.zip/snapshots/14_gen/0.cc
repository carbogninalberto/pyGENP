tcb->m_cWnd = (int) (25.624-(-76.101)-(92.592)-(-98.791));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
segmentsAcked = (int) (-19.06+(29.051));
segmentsAcked = (int) (-1.991+(75.96));
