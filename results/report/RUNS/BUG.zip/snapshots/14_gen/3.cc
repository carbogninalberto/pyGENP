segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-16.023+(-52.674));
tcb->m_cWnd = (int) (-63.824-(-59.611)-(-96.276)-(-95.97));
segmentsAcked = (int) (62.938+(24.085));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
tcb->m_cWnd = (int) (0.887-(46.497)-(-56.055)-(-95.355));
segmentsAcked = (int) (-8.676+(1.12));
tcb->m_cWnd = (int) (-57.54-(34.728)-(93.048)-(-62.524));
segmentsAcked = (int) (17.558+(25.495));
tcb->m_cWnd = (int) (-67.9-(-32.318)-(-37.416)-(81.055));
tcb->m_cWnd = (int) (-66.401-(58.552)-(-4.845)-(-72.531));
tcb->m_cWnd = (int) (-40.085-(12.085)-(45.311)-(56.784));
tcb->m_cWnd = (int) (36.874-(-68.623)-(-0.316)-(69.371));
segmentsAcked = (int) (19.326+(74.867));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
tcb->m_cWnd = (int) (87.361-(-33.367)-(24.234)-(-93.848));
segmentsAcked = (int) (45.029+(57.218));
segmentsAcked = (int) (-20.084+(69.473));
segmentsAcked = (int) (46.022+(44.357));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
tcb->m_cWnd = (int) (-87.988-(-55.581)-(-57.559)-(3.27));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
tcb->m_cWnd = (int) (-80.34-(-59.448)-(45.534)-(81.537));
tcb->m_cWnd = (int) (-49.899-(-25.201)-(-11.154)-(-99.731));
tcb->m_cWnd = (int) (44.428-(58.02)-(-16.595)-(-13.26));
segmentsAcked = (int) (-52.54+(-31.782));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (19.101-(-1.153)-(67.316)-(-93.722));
segmentsAcked = (int) (12.016+(33.698));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
