if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
segmentsAcked = (int) (73.74+(55.644));
segmentsAcked = (int) (-72.041+(18.549));
tcb->m_cWnd = (int) (-32.17-(-24.705)-(-67.935)-(62.938));
tcb->m_cWnd = (int) (30.117-(12.224)-(38.339)-(2.644));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
segmentsAcked = (int) (52.615+(-40.204));
segmentsAcked = (int) (7.897+(-71.442));
tcb->m_cWnd = (int) (-12.609-(30.816)-(81.469)-(54.629));
tcb->m_cWnd = (int) (88.86-(-85.52)-(-36.361)-(12.897));
tcb->m_cWnd = (int) (-29.091-(3.084)-(-45.996)-(-18.336));
tcb->m_cWnd = (int) (31.399-(6.961)-(56.967)-(32.276));
segmentsAcked = (int) (94.664+(44.133));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (-75.185-(36.444)-(16.598)-(3.848));
segmentsAcked = (int) (-88.525+(90.017));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
segmentsAcked = (int) (-22.553+(83.939));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
segmentsAcked = (int) (88.496+(-85.418));
tcb->m_cWnd = (int) (-90.203-(66.216)-(95.606)-(54.272));
tcb->m_cWnd = (int) (85.79-(22.451)-(31.914)-(-82.852));
tcb->m_cWnd = (int) (-92.785-(-6.621)-(-13.563)-(11.474));
tcb->m_cWnd = (int) (76.247-(18.005)-(-67.986)-(-98.953));
segmentsAcked = (int) (-20.126+(-47.766));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (22.501-(27.858)-(78.058)-(24.688));
segmentsAcked = (int) (14.104+(71.314));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
