segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (23.686+(52.304));
tcb->m_cWnd = (int) (14.949-(20.93)-(-57.653)-(21.538));
segmentsAcked = (int) (-61.353+(-51.081));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
tcb->m_cWnd = (int) (50.67-(-3.507)-(48.122)-(-70.849));
segmentsAcked = (int) (46.507+(99.415));
tcb->m_cWnd = (int) (-59.702-(-71.828)-(-9.955)-(70.964));
segmentsAcked = (int) (18.054+(-12.021));
tcb->m_cWnd = (int) (-44.336-(-18.999)-(6.43)-(-12.936));
tcb->m_cWnd = (int) (-43.35-(96.849)-(-17.195)-(-19.597));
tcb->m_cWnd = (int) (-6.247-(-11.097)-(-59.221)-(-43.493));
tcb->m_cWnd = (int) (-99.867-(-94.888)-(89.984)-(67.648));
segmentsAcked = (int) (34.5+(-81.942));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
tcb->m_cWnd = (int) (-65.614-(0.041)-(-85.22)-(-87.801));
segmentsAcked = (int) (59.925+(64.489));
segmentsAcked = (int) (-27.904+(40.076));
segmentsAcked = (int) (5.512+(-23.41));
tcb->m_cWnd = (int) (97.995-(43.41)-(-54.305)-(82.717));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
segmentsAcked = (int) (60.978+(96.079));
tcb->m_cWnd = (int) (-43.29-(72.343)-(-29.238)-(-31.749));
tcb->m_cWnd = (int) (-88.103-(89.008)-(-61.284)-(70.56));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
tcb->m_cWnd = (int) (26.876-(-15.71)-(0.342)-(-97.527));
tcb->m_cWnd = (int) (2.482-(-15.504)-(60.22)-(33.519));
tcb->m_cWnd = (int) (-15.111-(22.973)-(98.546)-(53.406));
tcb->m_cWnd = (int) (88.577-(-25.114)-(-43.883)-(10.865));
tcb->m_cWnd = (int) (39.89-(37.461)-(-71.774)-(25.791));
tcb->m_cWnd = (int) (-12.05-(4.829)-(65.108)-(-67.436));
segmentsAcked = (int) (-82.674+(-60.881));
segmentsAcked = (int) (14.199+(59.465));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (-7.508-(-49.102)-(21.238)-(-1.798));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
segmentsAcked = (int) (-31.519+(-25.342));
tcb->m_cWnd = (int) (93.794-(44.076)-(-45.008)-(99.815));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
segmentsAcked = (int) (93.075+(-72.122));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
segmentsAcked = (int) (42.021+(-38.361));
segmentsAcked = (int) (-11.051+(-29.8));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
tcb->m_cWnd = (int) (-40.357-(-75.189)-(70.589)-(99.585));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
tcb->m_cWnd = (int) (-53.983-(53.077)-(8.188)-(-93.442));
tcb->m_cWnd = (int) (-58.392-(85.747)-(-78.692)-(47.445));
tcb->m_cWnd = (int) (-4.56-(-53.407)-(-50.366)-(43.561));
segmentsAcked = (int) (79.345+(82.075));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (78.472-(39.47)-(99.314)-(-62.482));
segmentsAcked = (int) (65.717+(-43.396));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
