segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-20.09+(23.158));
tcb->m_cWnd = (int) (29.259-(58.796)-(86.168)-(-97.551));
segmentsAcked = (int) (-58.982+(-51.108));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
tcb->m_cWnd = (int) (-62.305-(-91.494)-(51.588)-(3.684));
segmentsAcked = (int) (-45.149+(-44.724));
tcb->m_cWnd = (int) (53.656-(13.479)-(-1.101)-(67.044));
segmentsAcked = (int) (-12.393+(-72.025));
tcb->m_cWnd = (int) (86.087-(-60.957)-(-32.88)-(-10.405));
tcb->m_cWnd = (int) (-90.846-(80.475)-(-12.014)-(-52.835));
tcb->m_cWnd = (int) (69.823-(65.774)-(-63.05)-(-3.645));
tcb->m_cWnd = (int) (-97.316-(-6.915)-(21.37)-(-64.599));
segmentsAcked = (int) (21.41+(-80.012));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
tcb->m_cWnd = (int) (4.567-(54.089)-(81.099)-(-44.616));
tcb->m_cWnd = (int) (78.487-(32.461)-(78.565)-(-39.672));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
segmentsAcked = (int) (-48.054+(-35.659));
tcb->m_cWnd = (int) (31.748-(-92.23)-(56.494)-(-32.485));
segmentsAcked = (int) (5.031+(-19.894));
tcb->m_cWnd = (int) (-94.795-(63.236)-(51.67)-(-35.564));
segmentsAcked = (int) (54.686+(97.506));
tcb->m_cWnd = (int) (-28.974-(37.825)-(45.173)-(-8.215));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
segmentsAcked = (int) (79.859+(-33.065));
tcb->m_cWnd = (int) (15.87-(-20.509)-(-89.971)-(-59.45));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
tcb->m_cWnd = (int) (-45.218-(8.339)-(-2.002)-(-78.713));
tcb->m_cWnd = (int) (-26.734-(78.963)-(21.011)-(-89.344));
segmentsAcked = (int) (-75.781+(58.468));
tcb->m_cWnd = (int) (-31.509-(-53.405)-(-63.997)-(56.606));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
tcb->m_cWnd = (int) (-65.16-(-73.712)-(52.809)-(-94.956));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
segmentsAcked = (int) (63.292+(40.938));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (-60.61-(0.847)-(-11.396)-(8.226));
segmentsAcked = (int) (47.245+(97.058));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
