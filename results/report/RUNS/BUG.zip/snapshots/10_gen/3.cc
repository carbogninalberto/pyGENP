float FAoBoYUOISGWossW = (float) (-19.011*(-32.384)*(97.583)*(6.814));
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (6.24/17.77);
	tcb->m_segmentSize = (int) (61.852-(15.311)-(46.254)-(47.654));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (11.75/18.46);
	segmentsAcked = (int) (FAoBoYUOISGWossW+(34.091)+(FAoBoYUOISGWossW)+(82.79));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (2.885*(-39.804)*(19.74)*(45.64));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (25.522*(-17.597)*(-61.819)*(-8.704));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (FAoBoYUOISGWossW-(83.465)-(29.319)-(51.818));
	FAoBoYUOISGWossW = (float) (64.655*(29.698)*(93.915));

} else {
	tcb->m_cWnd = (int) (38.757*(67.842)*(62.91)*(36.983));
	FAoBoYUOISGWossW = (float) (88.223*(16.47)*(tcb->m_segmentSize));

}
