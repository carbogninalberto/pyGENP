float IApCZhYMjBJyqkpC = (float) (61.436-(69.116)-(-43.663));
if (segmentsAcked <= IApCZhYMjBJyqkpC) {
	tcb->m_segmentSize = (int) (8.13/4.67);
	segmentsAcked = (int) (-17.827+(59.314));
	tcb->m_segmentSize = (int) (20.349-(77.06)-(18.134));

} else {
	tcb->m_segmentSize = (int) (8.09/10.07);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (5.078-(-85.755)-(-99.015)-(64.8));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.686-(7.035));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(85.201));

}
segmentsAcked = (int) (43.213+(-86.592));
segmentsAcked = (int) (-79.254+(66.507));
tcb->m_cWnd = (int) (21.118-(-94.592)-(91.063)-(-58.455));
tcb->m_cWnd = (int) (-55.628-(71.436)-(7.876)-(-41.702));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(7.312));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-97.674-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-56.886));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (76.139-(7.035));

}
segmentsAcked = (int) (-5.87+(73.069));
segmentsAcked = (int) (-52.398+(-72.442));
tcb->m_cWnd = (int) (71.324-(58.03)-(93.515)-(-26.394));
tcb->m_cWnd = (int) (-16.606-(66.671)-(-92.372)-(93.929));
tcb->m_cWnd = (int) (-37.027-(47.939)-(53.659)-(-42.855));
tcb->m_cWnd = (int) (48.221-(89.613)-(-66.361)-(32.383));
segmentsAcked = (int) (-38.991+(-36.665));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-44.028));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (61.943-(7.035));

}
tcb->m_cWnd = (int) (49.123-(-96.535)-(-59.037)-(-85.339));
segmentsAcked = (int) (54.984+(-0.785));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(41.428));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (30.241-(7.035));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(53.087)*(45.182)*(-27.522));

} else {
	tcb->m_segmentSize = (int) (78.286*(25.618)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (-24.555-(7.035));

}
