tcb->m_segmentSize = (int) (-48.879*(40.141)*(70.799)*(58.268));
float geXzXrxPNMckdtFh = (float) (0.052/-94.268);
tcb->m_segmentSize = (int) (99.915*(55.18)*(-41.962)*(-48.352));
tcb->m_segmentSize = (int) (-8.204*(-9.047)*(-91.282)*(95.901));
tcb->m_segmentSize = (int) (-59.795*(-81.842)*(-15.534)*(78.266));
