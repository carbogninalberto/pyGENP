CongestionAvoidance (tcb, segmentsAcked);
int XRdzJHAEkOWMBQgm = (int) (-18.384*(-52.938)*(40.608)*(7.555)*(-70.57));
segmentsAcked = (int) (-76.605+(-81.171)+(-8.951)+(96.532));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-17.163+(-78.436)+(-43.517)+(87.573));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
