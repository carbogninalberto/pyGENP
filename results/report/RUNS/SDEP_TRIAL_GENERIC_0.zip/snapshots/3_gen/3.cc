int JbeeYvkoqUZssUoP = (int) (-15.141+(79.615));
float GOecigYFkdQiIcrb = (float) (-1.327*(42.353)*(59.705)*(78.258)*(66.538)*(96.559)*(9.631));
tcb->m_cWnd = (int) (-80.295+(51.006)+(-51.688)+(-91.39)+(58.63)+(-19.702)+(22.755)+(-83.971)+(-54.443));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (6.761*(59.087)*(88.436)*(-41.422));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (77.592+(19.361)+(-22.707)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
