if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/98.286);
	tcb->m_cWnd = (int) (22.549+(10.365)+(35.364)+(57.63));

} else {
	tcb->m_cWnd = (int) ((14.925*(8.594)*(73.272)*(83.243)*(BjDqJVJMhGSxTooX)*(6.997)*(53.973))/0.1);

}
