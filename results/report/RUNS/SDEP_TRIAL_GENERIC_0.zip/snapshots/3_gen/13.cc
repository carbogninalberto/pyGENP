ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-54.171-(-29.613)-(82.128)-(-22.725)-(67.766)-(-72.069)-(89.479));
tcb->m_cWnd = (int) (6.62*(-64.975));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (22.202*(72.232)*(-5.142)*(-77.947)*(-17.575)*(-39.636)*(12.495)*(-70.686)*(-13.508));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (18.44*(-79.268)*(15.153)*(-76.474)*(84.539)*(55.617)*(-62.409)*(-64.443)*(49.882));
