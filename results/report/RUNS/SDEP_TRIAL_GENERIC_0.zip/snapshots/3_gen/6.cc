CongestionAvoidance (tcb, segmentsAcked);
int wXrnFsDhBngyElNr = (int) (-47.814/-47.168);
CongestionAvoidance (tcb, segmentsAcked);
