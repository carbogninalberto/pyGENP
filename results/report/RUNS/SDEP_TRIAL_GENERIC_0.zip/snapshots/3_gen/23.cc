CongestionAvoidance (tcb, segmentsAcked);
int XRdzJHAEkOWMBQgm = (int) (-40.901*(25.004)*(-12.635)*(-39.579)*(-50.334));
segmentsAcked = (int) (48.477+(-31.359)+(69.294)+(-56.635));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-34.173+(-67.026)+(-97.387)+(-71.087));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
