int XRdzJHAEkOWMBQgm = (int) (43.357*(-6.943)*(-3.238)*(76.018)*(-54.391));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-63.155+(3.241)+(24.999)+(27.951));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (40.184+(-83.237)+(87.665)+(-29.679));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
