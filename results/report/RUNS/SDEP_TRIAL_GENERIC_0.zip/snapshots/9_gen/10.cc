int XRdzJHAEkOWMBQgm = (int) (63.109*(12.138)*(-67.374)*(-74.86)*(9.252));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (83.831+(95.46)+(-16.431)+(14.416));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (63.138+(-94.283)+(-98.162)+(96.95));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
