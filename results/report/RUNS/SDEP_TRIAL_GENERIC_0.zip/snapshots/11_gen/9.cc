int JbeeYvkoqUZssUoP = (int) (33.293+(3.174));
float GOecigYFkdQiIcrb = (float) (-49.822*(-62.68)*(37.744)*(32.91)*(28.193)*(-25.645)*(7.115));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (54.354+(64.996)+(22.149)+(10.561)+(59.273)+(-19.087)+(94.524)+(68.737)+(-12.211));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (71.337*(-58.037)*(39.419)*(13.764));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (77.592+(19.361)+(-37.529)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (77.592+(19.361)+(54.361)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (77.592+(19.361)+(-37.529)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (77.592+(19.361)+(54.361)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (19.078*(-55.429)*(-44.946)*(-31.407));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (77.592+(19.361)+(-37.529)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (77.592+(19.361)+(54.361)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

}
