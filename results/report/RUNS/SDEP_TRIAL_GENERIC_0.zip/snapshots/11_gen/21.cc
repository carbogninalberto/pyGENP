int JbeeYvkoqUZssUoP = (int) (-41.028+(-40.608));
tcb->m_cWnd = (int) (57.731+(44.342)+(-78.572)+(63.111)+(-3.588)+(34.824)+(-51.399)+(-4.697)+(16.929));
float GOecigYFkdQiIcrb = (float) (62.533*(-65.738)*(13.728)*(20.927)*(98.695)*(75.012)*(33.749));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-47.72+(-29.882)+(42.587)+(68.668)+(-33.85)+(-60.777)+(62.962)+(18.485)+(-17.869));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-85.615*(23.669)*(-97.09)*(72.677));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-54.269*(-81.735)*(-63.878)*(-19.68));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-12.392*(-19.175)*(17.651)*(-96.358));
tcb->m_cWnd = (int) (82.714*(-36.081)*(68.95)*(87.818));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (77.592+(19.361)+(37.623)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-1.185*(82.613)*(91.402)*(43.307));
tcb->m_cWnd = (int) (-12.154*(26.94)*(-21.658)*(-4.599));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (77.592+(19.361)+(37.623)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (77.592+(19.361)+(37.623)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-33.612*(73.227)*(-87.944)*(46.759));
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (77.592+(19.361)+(38.918)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (77.592+(19.361)+(37.623)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (77.592+(19.361)+(38.918)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (77.592+(19.361)+(38.918)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (77.592+(19.361)+(38.918)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

}
