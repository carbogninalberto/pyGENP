int XRdzJHAEkOWMBQgm = (int) (59.007*(-50.291)*(-16.441)*(16.698)*(-36.335));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (39.316+(-72.196)+(-7.9)+(-4.424));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-14.753+(65.994)+(-88.733)+(-64.166));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
