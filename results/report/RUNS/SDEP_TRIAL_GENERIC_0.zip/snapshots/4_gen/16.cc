int XRdzJHAEkOWMBQgm = (int) (42.399*(48.21)*(-18.301)*(94.492)*(-78.838));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-93.033+(20.383)+(-4.582)+(-33.692));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-34.452+(-64.502)+(-30.103)+(39.178));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
