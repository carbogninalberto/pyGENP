int XRdzJHAEkOWMBQgm = (int) (-65.579*(-42.583)*(17.391)*(80.096)*(-59.326));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (35.608+(-76.651)+(19.555)+(-73.675));
segmentsAcked = (int) (63.056+(-4.14)+(57.21)+(-65.326));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
