TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (29.382-(67.468)-(-67.646)-(-4.005)-(-33.982)-(-61.821)-(-87.252));
tcb->m_cWnd = (int) (21.39*(6.937));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-28.375*(-2.195)*(-99.554)*(-23.208)*(-76.527)*(-31.777)*(-51.788)*(94.71)*(-22.274));
segmentsAcked = (int) (78.698*(-91.667)*(-83.688)*(-42.737)*(97.612)*(92.477)*(43.262)*(35.143)*(60.124));
