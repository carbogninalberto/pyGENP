tcb->m_cWnd = (int) (-25.381-(-87.718)-(64.291)-(2.656)-(24.845)-(32.534)-(98.969));
tcb->m_cWnd = (int) (29.455*(-78.419));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-36.92*(-44.035)*(-76.115)*(78.18)*(-37.525)*(28.935)*(-34.692)*(18.402)*(58.776));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-30.905*(44.641)*(-71.462)*(-96.101)*(-26.551)*(47.03)*(-26.703)*(81.931)*(-24.12));
