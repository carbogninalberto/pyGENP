int XRdzJHAEkOWMBQgm = (int) (-65.914*(2.05)*(30.193)*(-21.711)*(42.47));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-97.267+(29.738)+(-25.28)+(-80.298));
segmentsAcked = (int) (-72.035+(-54.594)+(4.71)+(-48.533));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
