int XRdzJHAEkOWMBQgm = (int) (-26.834*(37.032)*(33.087)*(65.916)*(-99.953));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (18.034+(74.461)+(91.026)+(56.793));
segmentsAcked = (int) (32.084+(-97.419)+(82.273)+(95.073));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
