int XRdzJHAEkOWMBQgm = (int) (33.224*(-10.231)*(-77.45)*(58.964)*(5.044));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-1.423+(18.69)+(-22.544)+(-87.635));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
