segmentsAcked = (int) (((0.1)+(22.817)+(58.866)+(28.221)+((tcb->m_ssThresh*(64.208)*(51.723)*(43.599)*(59.989)*(31.025)*(21.748)*(80.287)*(94.352)))+(87.859)+(88.414))/((33.509)+(0.1)));
int TfotHciFXBpzvaKQ = (int) (70.561*(65.913)*(50.945)*(67.313)*(tcb->m_segmentSize)*(47.438)*(27.527)*(segmentsAcked));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (9.668*(TfotHciFXBpzvaKQ));
tcb->m_ssThresh = (int) (46.706+(4.452)+(20.414)+(58.544)+(5.103)+(74.382)+(39.927)+(95.807));
