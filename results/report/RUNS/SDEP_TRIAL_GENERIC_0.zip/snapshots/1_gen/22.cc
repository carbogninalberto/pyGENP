if (tcb->m_ssThresh >= segmentsAcked) {
	segmentsAcked = (int) (tcb->m_ssThresh+(9.619)+(12.579)+(segmentsAcked)+(87.376)+(tcb->m_ssThresh)+(84.07)+(2.908));
	tcb->m_segmentSize = (int) (77.726*(5.47)*(segmentsAcked)*(52.838));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) ((0.911-(68.91)-(58.743)-(38.776)-(78.804))/0.1);
	ReduceCwnd (tcb);
	segmentsAcked = (int) (76.708*(44.192));

}
if (tcb->m_cWnd != tcb->m_ssThresh) {
	segmentsAcked = (int) (5.057+(tcb->m_ssThresh)+(9.071));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (11.167-(44.828)-(tcb->m_ssThresh)-(22.903)-(78.248));

} else {
	segmentsAcked = (int) (58.634-(tcb->m_ssThresh)-(72.112)-(45.159)-(39.969)-(49.286));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (0.1/77.534);
tcb->m_ssThresh = (int) (((27.395)+(0.1)+(66.466)+(7.5)+(71.834)+((10.488-(segmentsAcked)))+(53.308))/((0.1)+(0.1)));
tcb->m_segmentSize = (int) (0.1/0.1);
