TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (segmentsAcked == segmentsAcked) {
	tcb->m_ssThresh = (int) (70.432*(66.122)*(44.206)*(43.615)*(4.006)*(62.981));

} else {
	tcb->m_ssThresh = (int) (25.625+(86.52)+(tcb->m_segmentSize)+(41.331)+(57.9)+(30.0)+(65.746)+(21.626)+(31.415));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (45.195-(42.834)-(69.065));
	tcb->m_cWnd = (int) (97.819/(76.197+(89.581)));
	segmentsAcked = (int) (((0.1)+(0.1)+((76.218-(4.885)-(87.927)-(44.474)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(45.399)-(26.58)))+(0.1)+(81.298)+(91.403))/((59.531)+(74.941)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (36.483-(99.138)-(74.838)-(92.444));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(10.955)-(17.21)-(21.798)-(65.946)-(34.167)-(32.41)-(49.629));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
