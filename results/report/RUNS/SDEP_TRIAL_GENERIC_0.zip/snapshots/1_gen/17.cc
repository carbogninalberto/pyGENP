float BHvCpmMJuNEpPJyf = (float) (tcb->m_ssThresh-(tcb->m_ssThresh)-(85.788)-(95.612)-(73.128)-(24.555));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (67.985*(BHvCpmMJuNEpPJyf)*(7.551));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (84.477/0.1);
