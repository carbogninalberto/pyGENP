tcb->m_segmentSize = (int) (segmentsAcked+(36.413)+(73.634)+(49.056)+(49.308)+(66.044)+(48.87));
int OAdcdplfdwAotYPU = (int) (segmentsAcked+(tcb->m_cWnd)+(15.366)+(82.237)+(segmentsAcked)+(23.664)+(71.122));
segmentsAcked = (int) (44.984+(52.711)+(tcb->m_segmentSize)+(98.426)+(25.681)+(42.908)+(3.209)+(tcb->m_cWnd)+(24.348));
tcb->m_cWnd = (int) (tcb->m_segmentSize+(tcb->m_cWnd));
ReduceCwnd (tcb);
