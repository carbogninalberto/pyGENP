segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((44.694)+(2.779)+(0.1)+(93.415)+(0.1)+(0.1))/((0.1)+(0.1)));
	tcb->m_cWnd = (int) (segmentsAcked+(tcb->m_segmentSize)+(tcb->m_cWnd)+(74.289)+(81.74)+(55.024)+(35.329)+(6.333));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(60.73)*(94.552)*(tcb->m_segmentSize)*(60.155)*(76.55));

}
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (15.647*(23.077)*(69.98)*(tcb->m_cWnd)*(86.9)*(38.406));
	tcb->m_segmentSize = (int) (35.988-(87.096));

} else {
	tcb->m_cWnd = (int) (76.701-(46.226)-(38.815)-(tcb->m_ssThresh)-(64.918)-(75.225)-(tcb->m_ssThresh)-(tcb->m_segmentSize));

}
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	segmentsAcked = (int) (83.393+(60.571));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (9.452+(41.917)+(tcb->m_segmentSize)+(segmentsAcked)+(86.15)+(75.178)+(99.659)+(71.159)+(17.491));
	tcb->m_ssThresh = (int) (35.867*(52.995));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_ssThresh = (int) (((0.1)+((tcb->m_segmentSize-(6.39)-(tcb->m_segmentSize)-(88.634)))+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (7.229-(36.503)-(tcb->m_segmentSize)-(20.532)-(19.066)-(28.443)-(47.843)-(95.492)-(tcb->m_cWnd));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(76.746)*(17.78)*(tcb->m_ssThresh)*(22.558)*(83.89)*(66.796)*(40.809)*(10.013));

}
