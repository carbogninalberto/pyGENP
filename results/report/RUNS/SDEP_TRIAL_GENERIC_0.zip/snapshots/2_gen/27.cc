CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-60.691-(-93.742)-(-10.11)-(-7.702)-(95.903)-(-68.169)-(-80.791));
tcb->m_cWnd = (int) (67.169*(-75.704));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-84.766*(-64.944)*(83.516)*(-22.037)*(-85.888)*(-28.736)*(-97.017)*(86.875)*(0.581));
