TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-36.872-(-72.683)-(99.512)-(-20.554)-(-70.052)-(66.682)-(62.177));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (37.164-(90.741)-(-84.425)-(-45.934)-(9.345)-(-99.005)-(-68.55));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-50.896*(28.717));
tcb->m_cWnd = (int) (48.267*(66.421));
segmentsAcked = (int) (-54.674*(-73.044)*(93.337)*(69.447)*(-6.545)*(31.753)*(-71.836)*(43.758)*(-59.694));
segmentsAcked = (int) (98.303*(-30.661)*(90.601)*(-84.757)*(-16.431)*(-8.441)*(81.826)*(6.232)*(93.435));
