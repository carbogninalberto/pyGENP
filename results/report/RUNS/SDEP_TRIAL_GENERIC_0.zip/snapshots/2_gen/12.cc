if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (86.307*(segmentsAcked)*(tcb->m_cWnd)*(89.626));
	segmentsAcked = (int) (tcb->m_cWnd*(17.737)*(3.741)*(57.626)*(53.64)*(31.637)*(tcb->m_cWnd)*(85.233));

} else {
	tcb->m_cWnd = (int) (38.439*(56.977)*(67.955)*(37.782)*(-70.911));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (((72.188)+(0.1)+(89.874)+(0.1))/((0.1)));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
