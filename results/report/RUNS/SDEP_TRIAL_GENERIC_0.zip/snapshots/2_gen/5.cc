tcb->m_cWnd = (int) (81.166/50.234);
int NFHrPSXggOJzVMfb = (int) (97.569-(81.557)-(-46.305)-(-69.001)-(-21.332)-(-51.724)-(36.55)-(26.409));
ReduceCwnd (tcb);
int NLAHvNUqXGWVOGwW = (int) (((-36.454)+(-43.526)+(-14.559)+(-84.702)+(-5.807))/((-11.651)));
NFHrPSXggOJzVMfb = (int) (-81.255-(-89.054));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-45.566+(0.21)+(69.641)+(7.362)+(60.155)+(23.721));
