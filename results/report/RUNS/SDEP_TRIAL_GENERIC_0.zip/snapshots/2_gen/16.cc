int JbeeYvkoqUZssUoP = (int) (-22.344+(-29.179));
float GOecigYFkdQiIcrb = (float) (-29.633*(-38.579)*(-93.858)*(-5.487)*(20.885)*(31.629)*(14.619));
tcb->m_cWnd = (int) (60.372+(47.389)+(-26.349)+(-49.689)+(-51.445)+(80.316)+(17.29)+(99.028)+(61.235));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-72.079*(12.005)*(-7.631)*(-70.483));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (21.325*(97.866)*(45.381)*(28.99));
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (77.592+(19.361)+(14.996)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (77.592+(19.361)+(-50.14)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
