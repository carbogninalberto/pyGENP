int JbeeYvkoqUZssUoP = (int) (-87.471+(54.146));
float GOecigYFkdQiIcrb = (float) (70.797*(33.056)*(6.576)*(96.314)*(-82.679)*(87.516)*(41.241));
tcb->m_cWnd = (int) (40.176+(-48.1)+(-18.69)+(47.297)+(-6.95)+(-7.591)+(-52.706)+(-39.879)+(-43.272));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (50.104*(-68.158)*(14.107)*(42.527));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (77.592+(19.361)+(33.178)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
