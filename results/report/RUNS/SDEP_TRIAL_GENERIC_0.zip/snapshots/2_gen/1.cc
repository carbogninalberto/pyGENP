int XRdzJHAEkOWMBQgm = (int) (-43.832*(-73.169)*(7.418)*(-39.097)*(30.362));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-57.604+(-71.854)+(-44.508)+(-21.216));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
