int NFHrPSXggOJzVMfb = (int) (70.069-(25.205)-(-50.577)-(0.104)-(70.094)-(-63.171)-(30.382)-(-86.436));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (54.37/-83.897);
