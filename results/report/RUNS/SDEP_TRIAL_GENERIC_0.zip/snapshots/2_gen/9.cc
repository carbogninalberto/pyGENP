int NFHrPSXggOJzVMfb = (int) (27.064-(97.145)-(-56.044)-(-93.852)-(-55.822)-(-92.645)-(-93.961)-(-42.127));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
