ReduceCwnd (tcb);
tcb->m_cWnd = (int) (34.063-(-63.14)-(-80.787)-(11.898)-(64.767)-(83.438)-(27.496));
tcb->m_cWnd = (int) (-47.353*(-79.778));
tcb->m_cWnd = (int) (-79.146*(-25.643));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (4.45*(-27.174)*(-62.923)*(15.842)*(8.106)*(-97.027)*(26.196)*(97.295)*(-51.661));
