int XRdzJHAEkOWMBQgm = (int) (-42.428*(-12.096)*(96.237)*(21.33)*(56.348));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-69.287+(34.569)+(-47.755)+(29.379));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (18.025+(11.95)+(15.122)+(-41.121));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
