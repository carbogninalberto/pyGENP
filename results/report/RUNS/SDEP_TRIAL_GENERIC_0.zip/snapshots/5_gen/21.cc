segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
int XRdzJHAEkOWMBQgm = (int) (-88.715*(98.773)*(60.341)*(38.889)*(90.608));
segmentsAcked = (int) (79.796+(-1.537)+(59.618)+(97.492));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
