segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-34.122*(44.854));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-99.459*(-7.582)*(-43.391)*(-38.489)*(34.845)*(-78.721)*(43.404)*(-27.973)*(-96.285));
segmentsAcked = (int) (31.155*(2.346)*(-24.41)*(-1.642)*(82.694)*(-96.401)*(28.933)*(-39.04)*(-12.781));
