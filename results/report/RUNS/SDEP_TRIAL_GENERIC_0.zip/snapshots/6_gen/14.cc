int XRdzJHAEkOWMBQgm = (int) (-76.099*(-7.315)*(61.981)*(-6.876)*(-35.234));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-32.369+(-74.906)+(-36.243)+(37.173));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (42.251+(-47.538)+(-76.976)+(-16.314));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
