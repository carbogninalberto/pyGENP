int XRdzJHAEkOWMBQgm = (int) (64.667*(26.585)*(-51.661)*(23.206)*(-21.151));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (31.166+(28.417)+(97.962)+(96.372));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
