tcb->m_cWnd = (int) (-1.874+(46.912)+(47.481)+(-87.486)+(75.486)+(6.905)+(62.113)+(5.281)+(-58.949));
float GOecigYFkdQiIcrb = (float) (48.674*(2.515)*(-42.11)*(-59.292)*(65.787)*(71.179)*(-8.383));
segmentsAcked = SlowStart (tcb, segmentsAcked);
int JbeeYvkoqUZssUoP = (int) (28.399+(20.632));
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (77.592+(19.361)+(6.09)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-2.351*(-83.936)*(-58.622)*(-52.883));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (77.592+(19.361)+(6.09)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (77.592+(19.361)+(83.223)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (34.786*(-10.687)*(-67.645)*(94.865));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (GOecigYFkdQiIcrb <= GOecigYFkdQiIcrb) {
	segmentsAcked = (int) (21.851/70.416);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (77.592+(19.361)+(83.223)+(27.216)+(tcb->m_segmentSize));
	segmentsAcked = (int) (47.765+(57.375)+(7.42)+(90.828));
	CongestionAvoidance (tcb, segmentsAcked);

}
