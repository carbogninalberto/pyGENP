int XRdzJHAEkOWMBQgm = (int) (50.202*(-64.152)*(-94.825)*(-50.284)*(-54.688));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-78.993+(-61.695)+(-22.346)+(21.164));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-71.953+(65.331)+(35.512)+(-21.134));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
