CongestionAvoidance (tcb, segmentsAcked);
int XRdzJHAEkOWMBQgm = (int) (49.406*(89.389)*(-69.646)*(-96.459)*(-88.219));
segmentsAcked = (int) (15.941+(-56.345)+(99.965)+(-95.662));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-78.814+(-91.06)+(-16.354)+(16.061));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
