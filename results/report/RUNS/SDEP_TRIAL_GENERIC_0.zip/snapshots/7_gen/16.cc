CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (54.588*(34.265));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-73.813*(-47.082)*(34.124)*(41.328)*(83.995)*(-46.638)*(-47.757)*(-57.768)*(-69.409));
segmentsAcked = (int) (43.563*(55.514)*(64.447)*(25.183)*(57.833)*(-88.051)*(72.612)*(41.569)*(-2.934));
