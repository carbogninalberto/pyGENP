int XRdzJHAEkOWMBQgm = (int) (98.59*(75.824)*(3.722)*(-34.944)*(-49.068));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (47.935+(-11.289)+(-40.746)+(-98.282));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-59.21+(-68.33)+(14.36)+(-8.327));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
