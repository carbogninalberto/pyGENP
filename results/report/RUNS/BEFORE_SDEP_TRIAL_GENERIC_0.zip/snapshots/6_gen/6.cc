int UCWAwZiUOluJEJYY = (int) ((-304.962-(-267.52)-(-270.399))/-134.766);
int cDJPouNCWmWvScWR = (int) (167.01-(-691.838));
float XfgbRfzBVADsjUVI = (float) (-35.214+(-198.679)+(487.477)+(645.883)+(-370.227)+(475.468)+(-311.744));
int ojNkaUcFLoeqAwbZ = (int) (((882.592)+(-863.104)+(-731.056)+(725.159))/((971.159)+(-811.557)+(804.827)+(109.062)+(686.182)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
