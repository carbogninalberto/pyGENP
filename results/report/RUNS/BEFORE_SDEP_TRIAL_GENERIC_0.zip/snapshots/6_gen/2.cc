int CrxpAbMCUUgkWQMr = (int) (((-911.685)+(-77.719)+(-42.817)+(166.321)+(908.111)+(306.251)+(230.829))/((628.183)+(-233.551)));
int ksMHSGdVSHKbyiGj = (int) (-742.199+(819.212));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
