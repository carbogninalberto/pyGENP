segmentsAcked = (int) (108.835*(888.362)*(271.4)*(-239.265));
float PfVwQZLVnrqjXLTB = (float) (-340.14*(851.43)*(54.24)*(438.417));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (538.821+(211.314)+(-205.733)+(711.245));
PfVwQZLVnrqjXLTB = (float) (-268.341-(100.784)-(-52.649)-(-749.128)-(531.49)-(738.235)-(974.44)-(-31.773));
segmentsAcked = (int) (896.658+(99.686)+(-464.66)+(563.804));
