segmentsAcked = (int) (-24.921*(-219.635)*(141.615)*(194.962));
float PfVwQZLVnrqjXLTB = (float) (468.531*(-604.395)*(528.985)*(-527.05));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (969.095+(-147.133)+(-17.249)+(258.484));
PfVwQZLVnrqjXLTB = (float) (-970.207-(-643.583)-(-133.097)-(487.646)-(84.23)-(-409.058)-(151.584)-(-101.049));
segmentsAcked = (int) (-830.539+(982.701)+(124.024)+(521.094));
segmentsAcked = (int) (380.835+(184.118)+(411.712)+(-457.011));
