segmentsAcked = (int) (25.232*(974.771)*(243.185)*(-447.061));
float PfVwQZLVnrqjXLTB = (float) (103.747*(-260.045)*(235.301)*(-110.873));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-683.435+(-601.79)+(-448.321)+(-852.702));
PfVwQZLVnrqjXLTB = (float) (132.36-(234.377)-(807.487)-(37.545)-(-584.607)-(433.322)-(-256.679)-(561.368));
segmentsAcked = (int) (353.258+(860.979)+(683.063)+(294.386));
