segmentsAcked = (int) (-644.493*(-971.149)*(454.944)*(-536.541));
float PfVwQZLVnrqjXLTB = (float) (761.039*(-824.004)*(884.736)*(-190.016));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (126.783+(-191.808)+(-323.048)+(240.209));
PfVwQZLVnrqjXLTB = (float) (-970.397-(-796.326)-(639.911)-(847.24)-(-45.562)-(598.569)-(396.735)-(360.437));
segmentsAcked = (int) (-533.571+(-232.213)+(75.158)+(-62.265));
