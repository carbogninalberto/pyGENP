segmentsAcked = (int) (-928.635*(-195.839)*(-477.698)*(643.411));
float PfVwQZLVnrqjXLTB = (float) (-181.445*(-788.561)*(-390.527)*(905.247));
CongestionAvoidance (tcb, segmentsAcked);
int lwdlgZqntDCPiGMf = (int) (336.981+(-450.82)+(938.181)+(827.583)+(366.033)+(88.04)+(271.957));
PfVwQZLVnrqjXLTB = (float) (537.923-(-554.953)-(-271.281)-(639.067)-(718.106)-(887.09)-(-481.85)-(-150.308));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-603.318+(960.528)+(-200.29)+(39.939));
PfVwQZLVnrqjXLTB = (float) (-491.278-(89.001)-(815.088)-(571.493)-(404.178)-(-858.875)-(-183.91)-(306.441));
segmentsAcked = (int) (337.083+(443.819)+(-559.233)+(-62.647));
