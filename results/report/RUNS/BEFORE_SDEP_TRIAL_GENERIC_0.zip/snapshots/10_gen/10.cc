int UCWAwZiUOluJEJYY = (int) ((703.974-(762.283)-(-404.967))/-528.151);
int cDJPouNCWmWvScWR = (int) (975.907-(-307.11));
float XfgbRfzBVADsjUVI = (float) (-345.994+(-740.815)+(-327.89)+(-812.63)+(889.564)+(671.26)+(301.57));
int ojNkaUcFLoeqAwbZ = (int) (((958.699)+(44.298)+(-977.799)+(-513.802))/((-424.738)+(940.819)+(-183.257)+(578.584)+(-678.067)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
