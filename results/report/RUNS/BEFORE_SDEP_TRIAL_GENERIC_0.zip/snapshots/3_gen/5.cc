float TnfBRaOGIdmcOGoS = (float) (715.022*(592.417)*(-300.715)*(577.716)*(524.873)*(467.635)*(25.729)*(260.58)*(-3.428));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TnfBRaOGIdmcOGoS = (float) (-697.107+(659.407)+(-471.983)+(-786.799)+(848.447)+(253.063)+(-653.953)+(922.527)+(198.612));
CongestionAvoidance (tcb, segmentsAcked);
