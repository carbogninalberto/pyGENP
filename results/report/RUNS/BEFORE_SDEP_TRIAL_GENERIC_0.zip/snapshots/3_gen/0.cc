int UCWAwZiUOluJEJYY = (int) ((415.978-(158.038)-(873.391))/-88.774);
int cDJPouNCWmWvScWR = (int) (676.446-(486.714));
float XfgbRfzBVADsjUVI = (float) (-692.765+(227.806)+(894.908)+(310.77)+(350.786)+(719.596)+(438.788));
int ojNkaUcFLoeqAwbZ = (int) (((578.349)+(-863.517)+(912.213)+(309.941))/((-252.481)+(342.881)+(299.369)+(-782.537)+(-640.635)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
