segmentsAcked = (int) (908.338+(918.153)+(827.652)+(-616.741)+(223.502)+(-625.163));
segmentsAcked = (int) (-629.945*(-553.93)*(445.774)*(-336.658));
segmentsAcked = (int) (966.036+(584.741)+(-825.377)+(-993.685));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (583.87+(1.861)+(201.695)+(473.802));
segmentsAcked = (int) (94.941+(-680.434)+(109.767)+(-231.858));
segmentsAcked = (int) (-473.511+(-755.995)+(687.761)+(452.708));
