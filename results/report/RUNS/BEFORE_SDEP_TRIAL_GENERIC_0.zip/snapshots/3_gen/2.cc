float xTdZdCttQEUSFOPc = (float) (-568.153-(15.76));
int ksMHSGdVSHKbyiGj = (int) (-953.777+(-602.599));
tcb->m_cWnd = (int) (878.8-(-11.287)-(117.788)-(249.438));
xTdZdCttQEUSFOPc = (float) (546.596+(-473.639)+(220.258)+(-633.624)+(-575.828));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (994.534-(955.071)-(997.004)-(-958.959));
xTdZdCttQEUSFOPc = (float) (-451.598+(751.303)+(-998.072)+(-591.798)+(-274.229));
CongestionAvoidance (tcb, segmentsAcked);
