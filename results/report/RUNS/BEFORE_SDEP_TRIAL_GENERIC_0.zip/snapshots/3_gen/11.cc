float TnfBRaOGIdmcOGoS = (float) (882.642*(-986.616)*(551.856)*(-726.298)*(116.806)*(-794.461)*(187.046)*(184.094)*(89.612));
tcb->m_cWnd = (int) (-756.902+(18.184)+(932.438)+(636.752)+(-162.354)+(-748.414));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TnfBRaOGIdmcOGoS = (float) (995.278+(377.807)+(146.507)+(-676.895)+(848.386)+(931.713)+(-173.197)+(346.935)+(-368.249));
CongestionAvoidance (tcb, segmentsAcked);
