float xTdZdCttQEUSFOPc = (float) (-106.13-(176.532));
int ksMHSGdVSHKbyiGj = (int) (372.029+(189.18));
tcb->m_cWnd = (int) (-304.123-(182.12)-(-871.214)-(846.208));
xTdZdCttQEUSFOPc = (float) (717.03+(515.12)+(-995.894)+(984.155)+(-521.328));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
