segmentsAcked = (int) (225.634*(-59.732)*(823.499)*(-387.516));
float PfVwQZLVnrqjXLTB = (float) (-805.378*(-466.647)*(576.024)*(-983.395));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (141.215+(-105.357)+(-848.217)+(-886.285));
PfVwQZLVnrqjXLTB = (float) (384.685-(-693.366)-(-782.293)-(-269.898)-(-494.081)-(373.991)-(800.81)-(-283.79));
segmentsAcked = (int) (-287.049+(-593.864)+(476.608)+(184.649));
