int VKCGdaKRfCnTayqu = (int) (-911.259*(39.509)*(-918.01));
int ksMHSGdVSHKbyiGj = (int) (293.71+(503.182));
float xTdZdCttQEUSFOPc = (float) (191.565-(524.809));
tcb->m_cWnd = (int) (-320.133-(-460.284)-(-873.696)-(-816.909));
xTdZdCttQEUSFOPc = (float) (63.818+(34.408)+(-875.906)+(-693.085)+(185.249));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
