int VKCGdaKRfCnTayqu = (int) (422.268*(-510.788)*(-322.443));
int ksMHSGdVSHKbyiGj = (int) (-30.24+(-776.172));
float xTdZdCttQEUSFOPc = (float) (494.941-(666.583));
tcb->m_cWnd = (int) (798.833-(317.076)-(-355.082)-(-749.7));
xTdZdCttQEUSFOPc = (float) (173.445+(-485.674)+(-400.306)+(801.694)+(-705.318));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (438.425-(-87.471)-(-502.808)-(-287.709));
xTdZdCttQEUSFOPc = (float) (-282.404+(124.047)+(-328.167)+(931.573)+(960.125));
CongestionAvoidance (tcb, segmentsAcked);
