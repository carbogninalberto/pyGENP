int UCWAwZiUOluJEJYY = (int) ((-511.746-(-555.329)-(-93.745))/-650.932);
int cDJPouNCWmWvScWR = (int) (-182.295-(860.958));
float XfgbRfzBVADsjUVI = (float) (300.164+(794.396)+(606.06)+(421.116)+(-790.472)+(245.358)+(520.35));
int ojNkaUcFLoeqAwbZ = (int) (((-567.402)+(-686.244)+(96.12)+(432.157))/((261.854)+(-959.943)+(690.106)+(593.516)+(718.559)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
