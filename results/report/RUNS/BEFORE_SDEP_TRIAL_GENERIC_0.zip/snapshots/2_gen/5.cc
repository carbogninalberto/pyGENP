int UCWAwZiUOluJEJYY = (int) ((-449.3-(485.039)-(23.903))/986.828);
int cDJPouNCWmWvScWR = (int) (514.914-(408.539));
float XfgbRfzBVADsjUVI = (float) (-306.38+(-75.627)+(-56.925)+(516.102)+(708.204)+(-332.247)+(68.625));
int ojNkaUcFLoeqAwbZ = (int) (((-309.367)+(54.474)+(-846.877)+(696.976))/((777.442)+(576.942)+(-746.838)+(-813.82)+(-177.618)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
