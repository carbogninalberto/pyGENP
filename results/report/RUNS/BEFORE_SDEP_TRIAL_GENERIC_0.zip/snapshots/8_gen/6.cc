int UCWAwZiUOluJEJYY = (int) ((-539.984-(-33.908)-(880.303))/260.309);
int cDJPouNCWmWvScWR = (int) (393.635-(-763.089));
float XfgbRfzBVADsjUVI = (float) (-859.554+(-749.831)+(997.532)+(779.741)+(938.311)+(-79.576)+(-334.745));
int ojNkaUcFLoeqAwbZ = (int) (((249.067)+(635.637)+(584.269)+(636.299))/((831.313)+(-788.759)+(-121.888)+(459.03)+(205.371)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
