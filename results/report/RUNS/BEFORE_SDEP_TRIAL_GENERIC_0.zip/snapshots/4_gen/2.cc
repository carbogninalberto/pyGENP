int UCWAwZiUOluJEJYY = (int) ((-385.292-(-917.281)-(-240.093))/-702.61);
int cDJPouNCWmWvScWR = (int) (843.728-(-815.791));
float XfgbRfzBVADsjUVI = (float) (981.023+(4.294)+(193.026)+(503.758)+(-359.539)+(163.414)+(-576.325));
int ojNkaUcFLoeqAwbZ = (int) (((723.939)+(653.737)+(400.901)+(448.851))/((-581.733)+(-28.968)+(279.496)+(-119.667)+(505.046)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
