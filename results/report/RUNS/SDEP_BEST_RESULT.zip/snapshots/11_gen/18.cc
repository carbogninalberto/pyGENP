ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-23.538-(-31.718)-(-96.495)-(45.855)-(-30.74)-(10.851));
tcb->m_cWnd = (int) (36.215-(-52.693)-(-53.685)-(86.991)-(-45.369)-(76.587));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
