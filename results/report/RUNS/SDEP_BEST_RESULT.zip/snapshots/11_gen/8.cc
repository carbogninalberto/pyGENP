ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-37.486-(88.641)-(-73.151)-(85.513)-(-44.795)-(-69.446));
tcb->m_cWnd = (int) (84.231-(-48.144)-(-24.763)-(98.606)-(-36.57)-(66.297));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
