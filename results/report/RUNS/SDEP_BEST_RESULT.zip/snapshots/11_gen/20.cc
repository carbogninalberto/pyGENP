ReduceCwnd (tcb);
tcb->m_cWnd = (int) (65.149-(85.189)-(98.99)-(29.88)-(30.474)-(75.164));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (14.779-(81.57)-(67.608)-(-84.166)-(-45.498)-(-27.225));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-78.687-(42.245)-(-14.071)-(75.883)-(-27.581)-(-86.491));
CongestionAvoidance (tcb, segmentsAcked);
