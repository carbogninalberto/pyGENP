ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-78.042-(-42.584)-(-49.395)-(53.126)-(-1.99)-(84.142));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
