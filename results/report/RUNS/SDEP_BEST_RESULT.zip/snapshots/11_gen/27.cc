ReduceCwnd (tcb);
tcb->m_cWnd = (int) (35.79-(62.261)-(-72.387)-(90.487)-(-3.245)-(-33.199));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (3.453-(-50.197)-(70.036)-(96.803)-(-87.729)-(55.228));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
