ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-60.071-(-30.668)-(32.466)-(-89.452)-(89.978)-(-58.203));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-89.616-(-36.203)-(-27.704)-(-40.661)-(-12.64)-(85.757));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (39.035-(28.998)-(92.839)-(-37.083)-(-82.613)-(27.787));
CongestionAvoidance (tcb, segmentsAcked);
