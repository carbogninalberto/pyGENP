ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-5.663-(-63.204)-(5.963)-(-68.677)-(61.323)-(-81.164));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-52.189-(-86.285)-(-22.649)-(-67.042)-(8.335)-(-64.641));
CongestionAvoidance (tcb, segmentsAcked);
