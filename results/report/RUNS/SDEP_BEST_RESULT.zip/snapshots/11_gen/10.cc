ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-82.936-(-28.966)-(82.51)-(-16.229)-(4.339)-(-12.397));
tcb->m_cWnd = (int) (24.841-(84.887)-(-10.948)-(-1.933)-(98.748)-(93.967));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
