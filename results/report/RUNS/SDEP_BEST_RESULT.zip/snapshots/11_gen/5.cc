ReduceCwnd (tcb);
tcb->m_cWnd = (int) (18.888-(-17.593)-(33.44)-(-29.58)-(-85.307)-(-71.837));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (24.816-(9.313)-(-66.541)-(-1.725)-(-15.095)-(99.788));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
