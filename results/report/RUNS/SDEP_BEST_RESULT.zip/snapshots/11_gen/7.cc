ReduceCwnd (tcb);
tcb->m_cWnd = (int) (96.633-(-19.18)-(-52.406)-(58.427)-(10.481)-(-42.956));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
