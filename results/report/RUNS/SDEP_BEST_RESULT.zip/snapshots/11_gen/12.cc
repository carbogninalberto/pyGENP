ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-80.576-(-37.937)-(-79.101)-(-75.566)-(-61.751)-(-36.21));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (35.558-(-68.868)-(-58.49)-(57.472)-(-70.032)-(62.317));
CongestionAvoidance (tcb, segmentsAcked);
