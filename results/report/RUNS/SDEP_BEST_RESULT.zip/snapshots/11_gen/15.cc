ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-53.926-(-3.58)-(-85.58)-(23.34)-(45.255)-(-12.67));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (62.022-(-34.176)-(89.247)-(16.942)-(66.603)-(-36.634));
tcb->m_cWnd = (int) (-91.274-(72.638)-(-12.106)-(33.527)-(71.241)-(72.86));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (46.773-(89.07)-(-92.829)-(4.37)-(-68.842)-(-74.542));
CongestionAvoidance (tcb, segmentsAcked);
