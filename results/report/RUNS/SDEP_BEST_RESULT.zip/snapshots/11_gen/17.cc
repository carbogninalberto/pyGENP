ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (2.659-(-67.504)-(-42.331)-(-76.105)-(11.632)-(7.743));
tcb->m_cWnd = (int) (-20.617-(-66.419)-(-4.67)-(-68.346)-(-20.824)-(46.534));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
