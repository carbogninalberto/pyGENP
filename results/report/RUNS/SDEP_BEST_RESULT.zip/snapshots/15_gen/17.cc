if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (94.523+(tcb->m_segmentSize)+(90.7)+(tcb->m_ssThresh)+(85.321)+(tcb->m_ssThresh)+(16.222)+(38.203));
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(78.486)-(89.254)-(75.456));

} else {
	tcb->m_segmentSize = (int) (16.116*(84.87)*(22.009)*(7.145)*(98.885));

}
tcb->m_ssThresh = (int) (64.519-(25.739)-(74.983));
float vbmUbIOLgmhpfsRH = (float) (85.043+(67.204)+(4.385)+(59.759)+(95.741)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(17.403));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (90.687*(72.427)*(22.005)*(54.222)*(26.118)*(6.999)*(15.251));
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (78.951*(tcb->m_segmentSize)*(45.871)*(75.9));

} else {
	tcb->m_segmentSize = (int) (55.91-(48.331)-(vbmUbIOLgmhpfsRH)-(23.096)-(vbmUbIOLgmhpfsRH)-(81.966)-(90.116));

}
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(21.538)*(14.951)*(27.92)*(86.252)*(86.941));
	tcb->m_ssThresh = (int) (65.323*(69.374)*(68.627)*(5.409)*(90.965)*(49.729)*(13.087)*(67.422)*(63.034));

} else {
	tcb->m_segmentSize = (int) ((89.001*(28.556)*(68.942)*(63.618)*(41.112)*(80.88))/0.1);
	ReduceCwnd (tcb);

}
