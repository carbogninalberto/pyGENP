ReduceCwnd (tcb);
tcb->m_cWnd = (int) (27.966-(98.728)-(48.304)-(94.581)-(-13.535)-(17.227));
tcb->m_cWnd = (int) (-13.459-(14.508)-(-48.724)-(63.788)-(19.785)-(52.151));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
