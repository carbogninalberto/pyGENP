ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-61.946-(13.246)-(51.535)-(52.183)-(-77.172)-(66.756));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-5.156-(-73.214)-(-13.308)-(58.889)-(51.445)-(-44.427));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
