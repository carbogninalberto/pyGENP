tcb->m_ssThresh = (int) (77.169-(tcb->m_segmentSize)-(49.961)-(72.194)-(2.451)-(6.726)-(41.945)-(87.486)-(16.58));
tcb->m_ssThresh = (int) (tcb->m_ssThresh*(tcb->m_cWnd)*(97.656)*(15.06)*(1.764)*(10.624)*(75.663)*(95.648)*(64.21));
segmentsAcked = (int) (tcb->m_cWnd-(30.505)-(68.45)-(50.474)-(84.016));
segmentsAcked = (int) (84.452+(tcb->m_ssThresh));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (74.144+(80.735)+(56.667)+(96.871));
ReduceCwnd (tcb);
