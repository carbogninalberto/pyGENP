float ILQVDbOEbKLCPDjF = (float) (13.597+(17.484));
if (ILQVDbOEbKLCPDjF == segmentsAcked) {
	ILQVDbOEbKLCPDjF = (float) (20.247*(28.168)*(tcb->m_ssThresh)*(60.45)*(55.605)*(8.489)*(64.937)*(tcb->m_ssThresh));

} else {
	ILQVDbOEbKLCPDjF = (float) (tcb->m_cWnd+(46.097)+(60.969)+(12.09)+(1.69)+(8.422)+(31.638));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_ssThresh = (int) (12.842-(57.119)-(tcb->m_cWnd)-(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (0.1/26.33);

}
tcb->m_segmentSize = (int) (50.977-(ILQVDbOEbKLCPDjF)-(96.609)-(23.248)-(62.658)-(40.029));
if (segmentsAcked < tcb->m_ssThresh) {
	ILQVDbOEbKLCPDjF = (float) (tcb->m_ssThresh-(50.349)-(4.338));
	tcb->m_ssThresh = (int) (71.865*(2.688)*(50.82)*(tcb->m_ssThresh)*(segmentsAcked)*(27.988));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	ILQVDbOEbKLCPDjF = (float) (85.979-(47.582)-(5.932)-(6.089));

}
CongestionAvoidance (tcb, segmentsAcked);
float tFBLGSPItkMtFIHj = (float) (6.062+(tcb->m_ssThresh)+(75.366)+(33.164)+(86.29)+(92.998)+(74.433));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (ILQVDbOEbKLCPDjF == tcb->m_ssThresh) {
	segmentsAcked = (int) (65.625-(98.388)-(24.683)-(90.077)-(36.911)-(30.8)-(14.604));
	tcb->m_cWnd = (int) (32.101*(32.579)*(20.057)*(9.466)*(57.012)*(50.346)*(89.933)*(tFBLGSPItkMtFIHj)*(90.208));
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (ILQVDbOEbKLCPDjF-(tcb->m_segmentSize)-(32.59)-(50.106)-(32.291)-(43.87)-(71.914));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
