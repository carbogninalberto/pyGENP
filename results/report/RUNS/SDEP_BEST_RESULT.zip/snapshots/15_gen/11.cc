float NoxwrhqXfXJGLBrC = (float) (49.938*(-98.157)*(79.794)*(75.875)*(68.318)*(92.845)*(-18.191)*(-63.857)*(-12.981));
tcb->m_segmentSize = (int) (-29.668*(-86.855));
float EAIggqjFSgxvivIQ = (float) 66.999;
tcb->m_segmentSize = (int) (2.473-(-94.727)-(4.004));
tcb->m_segmentSize = (int) (9.168-(-18.621)-(9.721)-(56.703)-(-9.975));
if (EAIggqjFSgxvivIQ < segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(12.411)-(73.05)-(73.112)-(78.009)-(EAIggqjFSgxvivIQ));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(74.918)-(44.616));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(63.295)-(segmentsAcked)-(11.521));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-77.251+(-65.638)+(67.307)+(-61.901)+(89.367));
