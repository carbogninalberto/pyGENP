ReduceCwnd (tcb);
tcb->m_cWnd = (int) (8.279-(94.189)-(12.849)-(-45.956)-(76.984)-(-27.197));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (13.325-(-63.704)-(71.601)-(19.026)-(87.559)-(29.491));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (36.336-(-3.651)-(-14.078)-(89.77)-(-28.191)-(-63.233));
CongestionAvoidance (tcb, segmentsAcked);
