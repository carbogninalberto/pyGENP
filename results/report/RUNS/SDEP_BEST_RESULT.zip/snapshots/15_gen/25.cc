tcb->m_cWnd = (int) (94.036*(11.608)*(79.225)*(38.435)*(tcb->m_cWnd)*(3.992)*(48.554)*(34.386));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (46.529-(90.495)-(34.914));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
