int EIWkIiAoSgxYbzMK = (int) 49.539;
