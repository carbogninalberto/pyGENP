ReduceCwnd (tcb);
segmentsAcked = (int) (62.078/-80.048);
tcb->m_segmentSize = (int) ((-19.072+(25.964)+(-49.565)+(-96.55)+(tcb->m_ssThresh))/-32.788);
