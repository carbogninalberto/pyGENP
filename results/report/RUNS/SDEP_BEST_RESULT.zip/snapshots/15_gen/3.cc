int LcOxIXeYMUlfzSpW = (int) ((-31.38*(-5.417)*(52.529))/-30.954);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
