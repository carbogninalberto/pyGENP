ReduceCwnd (tcb);
tcb->m_cWnd = (int) (79.51-(-9.951)-(40.701)-(80.061)-(11.71)-(-41.09));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
