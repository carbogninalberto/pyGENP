segmentsAcked = (int) (-81.571/-20.528);
float DFotVHEhvfwFEIqg = (float) (10.983-(73.139)-(64.485)-(-6.879)-(-64.693));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (95.483*(22.663)*(tcb->m_segmentSize)*(65.625)*(24.302)*(12.076)*(-1.157)*(93.975)*(79.705));
	segmentsAcked = (int) (((0.1)+(0.1)+(63.842)+(0.1)+(42.654))/((89.531)+(81.137)+(0.1)+(79.319)));

} else {
	tcb->m_cWnd = (int) (((0.1)+((96.191+(22.054)+(tcb->m_segmentSize)+(80.796)+(98.688)+(18.317)+(51.209)+(76.265)+(93.47)))+(0.1)+(45.873)+(0.1)+(0.1))/((67.055)+(0.1)+(45.761)));
	tcb->m_segmentSize = (int) (68.66+(31.415)+(50.364)+(98.91)+(98.99)+(5.837)+(27.394)+(40.699)+(54.584));
	ReduceCwnd (tcb);

}
float YFZztdLiRVLWYALB = (float) 87.61;
tcb->m_segmentSize = (int) (-76.762-(-95.175)-(-85.679)-(23.534));
tcb->m_segmentSize = (int) (-87.355-(37.465)-(-87.654)-(-92.082));
if (tcb->m_cWnd != YFZztdLiRVLWYALB) {
	tcb->m_segmentSize = (int) (46.116-(87.245)-(81.636)-(15.732)-(19.905)-(YFZztdLiRVLWYALB));

} else {
	tcb->m_segmentSize = (int) (9.2*(57.818)*(YFZztdLiRVLWYALB)*(89.447));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(-89.456)-(6.099)-(85.313)-(50.501)-(69.245));

}
if (tcb->m_cWnd != YFZztdLiRVLWYALB) {
	tcb->m_segmentSize = (int) (46.116-(87.245)-(81.636)-(15.732)-(19.905)-(YFZztdLiRVLWYALB));

} else {
	tcb->m_segmentSize = (int) (9.2*(57.818)*(YFZztdLiRVLWYALB)*(89.447));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(-89.456)-(6.099)-(85.313)-(50.501)-(69.245));

}
tcb->m_segmentSize = (int) (91.543-(-62.084)-(-43.797)-(89.822));
tcb->m_segmentSize = (int) (-32.945-(23.859)-(59.272)-(-82.808));
if (tcb->m_cWnd != YFZztdLiRVLWYALB) {
	tcb->m_segmentSize = (int) (46.116-(87.245)-(81.636)-(15.732)-(19.905)-(YFZztdLiRVLWYALB));

} else {
	tcb->m_segmentSize = (int) (9.2*(57.818)*(YFZztdLiRVLWYALB)*(89.447));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(70.501)-(6.099)-(85.313)-(50.501)-(69.245));

}
if (tcb->m_cWnd != YFZztdLiRVLWYALB) {
	tcb->m_segmentSize = (int) (46.116-(87.245)-(81.636)-(15.732)-(19.905)-(YFZztdLiRVLWYALB));

} else {
	tcb->m_segmentSize = (int) (9.2*(57.818)*(YFZztdLiRVLWYALB)*(89.447));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(70.501)-(6.099)-(85.313)-(50.501)-(69.245));

}
