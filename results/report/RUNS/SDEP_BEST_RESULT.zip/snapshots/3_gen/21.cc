tcb->m_segmentSize = (int) (-78.649*(65.946)*(-86.791));
int AFDeMuVBscvSOHBG = (int) (60.634+(-82.497)+(-17.245)+(81.735)+(28.8)+(-0.487));
tcb->m_segmentSize = (int) (28.414*(55.648)*(-66.707));
float XkXWQMqEPdQFFccz = (float) 78.56;
segmentsAcked = (int) (((68.695)+(-35.893)+(61.407)+(27.939))/((-93.55)+(68.342)+(75.458)+(-10.054)+(-91.185)));
segmentsAcked = (int) (((54.784)+(-12.428)+(-72.96)+(21.637))/((-73.455)+(98.452)+(-81.105)+(57.311)+(63.462)));
XkXWQMqEPdQFFccz = (float) ((49.996-(-42.769)-(segmentsAcked)-(segmentsAcked))/60.455);
XkXWQMqEPdQFFccz = (float) ((57.003-(-37.368)-(segmentsAcked)-(segmentsAcked))/64.041);
