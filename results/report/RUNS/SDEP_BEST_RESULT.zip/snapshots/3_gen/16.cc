float YFZztdLiRVLWYALB = (float) (33.487+(-34.894));
