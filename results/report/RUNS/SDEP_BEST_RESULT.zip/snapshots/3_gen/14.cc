tcb->m_cWnd = (int) (60.535-(54.03)-(56.463)-(-72.569)-(-10.986)-(-45.851)-(59.118)-(-1.309)-(8.913));
tcb->m_segmentSize = (int) (-85.63*(-8.723));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-46.783*(-72.789)*(81.804));
tcb->m_segmentSize = (int) (-46.64*(-89.18));
