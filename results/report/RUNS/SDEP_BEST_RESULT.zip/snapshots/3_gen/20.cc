ReduceCwnd (tcb);
tcb->m_cWnd = (int) (0.829-(-31.978)-(-38.797)-(-71.803)-(-33.751)-(94.52));
tcb->m_cWnd = (int) (-21.614-(3.086)-(53.058)-(80.964)-(-80.931)-(76.934));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
