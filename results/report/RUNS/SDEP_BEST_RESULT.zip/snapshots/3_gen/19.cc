ReduceCwnd (tcb);
tcb->m_cWnd = (int) (17.896-(-49.551)-(-51.367)-(-49.441)-(16.451)-(31.54));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (83.87-(-66.416)-(-54.907)-(-26.379)-(50.244)-(-91.257));
CongestionAvoidance (tcb, segmentsAcked);
