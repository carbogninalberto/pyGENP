tcb->m_segmentSize = (int) (5.198+(92.458)+(-31.129)+(-0.774)+(58.365));
tcb->m_segmentSize = (int) (-70.647*(-31.187));
tcb->m_segmentSize = (int) (-92.215*(18.959)*(-15.015));
