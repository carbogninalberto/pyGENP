segmentsAcked = (int) (85.538/-31.375);
