ReduceCwnd (tcb);
tcb->m_cWnd = (int) (8.399-(-56.994)-(-46.374)-(-52.406)-(23.649)-(9.372));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (27.966-(-50.35)-(93.783)-(59.075)-(-54.308)-(64.852));
CongestionAvoidance (tcb, segmentsAcked);
