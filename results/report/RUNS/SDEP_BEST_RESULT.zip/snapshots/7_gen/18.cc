ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-93.95-(-50.281)-(-4.491)-(-98.955)-(-68.342)-(23.552));
tcb->m_cWnd = (int) (24.622-(-89.161)-(-92.024)-(-40.426)-(-13.883)-(-3.674));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
