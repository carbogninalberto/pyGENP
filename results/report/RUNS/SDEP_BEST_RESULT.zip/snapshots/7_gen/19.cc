ReduceCwnd (tcb);
tcb->m_cWnd = (int) (30.734-(91.264)-(-14.336)-(56.174)-(53.19)-(-44.214));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
