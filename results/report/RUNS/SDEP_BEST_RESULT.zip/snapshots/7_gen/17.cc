ReduceCwnd (tcb);
tcb->m_cWnd = (int) (28.352-(50.807)-(80.718)-(-23.91)-(84.789)-(2.653));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
