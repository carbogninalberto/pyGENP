ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-96.974-(28.187)-(-77.956)-(-67.929)-(80.541)-(0.858));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-16.136-(89.114)-(48.896)-(-18.623)-(94.878)-(-60.014));
tcb->m_cWnd = (int) (78.938-(-20.64)-(87.48)-(-66.337)-(29.511)-(-63.587));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
