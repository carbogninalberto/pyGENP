ReduceCwnd (tcb);
tcb->m_cWnd = (int) (68.654-(17.5)-(59.426)-(-22.663)-(84.9)-(-61.537));
CongestionAvoidance (tcb, segmentsAcked);
