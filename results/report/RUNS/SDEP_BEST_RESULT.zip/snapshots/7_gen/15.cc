ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-69.447-(1.999)-(-60.064)-(28.025)-(72.539)-(42.469));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-11.312-(-97.705)-(54.105)-(-81.635)-(-61.157)-(41.269));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (87.892-(7.035)-(-46.583)-(-8.575)-(-66.859)-(32.948));
CongestionAvoidance (tcb, segmentsAcked);
