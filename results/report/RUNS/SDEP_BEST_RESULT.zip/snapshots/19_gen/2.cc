float QhuHcKafFDITyXYr = (float) 6.467;
segmentsAcked = (int) (-62.329+(7.152)+(-56.892)+(-36.916)+(-81.339)+(9.694)+(28.984));
ReduceCwnd (tcb);
