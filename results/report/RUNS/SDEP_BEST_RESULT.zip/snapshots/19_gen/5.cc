ReduceCwnd (tcb);
tcb->m_cWnd = (int) (41.819-(72.058)-(-79.261)-(-8.288)-(-43.857)-(-35.25));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (71.423-(-41.394)-(7.141)-(-61.292)-(-72.042)-(97.687));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
