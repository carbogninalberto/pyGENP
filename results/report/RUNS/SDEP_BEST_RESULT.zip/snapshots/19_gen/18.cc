ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (47.368-(6.96)-(97.293)-(segmentsAcked)-(88.152));

} else {
	tcb->m_segmentSize = (int) (57.032-(41.222)-(28.505)-(35.213)-(4.728)-(19.684));
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (79.06+(50.263)+(53.816)+(10.584)+(37.044)+(0.101)+(80.906)+(tcb->m_ssThresh));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_cWnd*(17.66)*(86.944)*(20.475));
