if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) (57.249*(94.778)*(tcb->m_cWnd)*(41.364)*(45.019)*(96.084)*(87.658));

} else {
	segmentsAcked = (int) (49.546+(85.938)+(59.314)+(48.535));
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (69.573*(64.959)*(22.65)*(34.945));
tcb->m_ssThresh = (int) (((0.1)+(0.1)+(44.713)+((2.901*(30.264)*(83.944)*(94.907)*(86.179)*(tcb->m_segmentSize)*(6.494)))+(10.78)+(0.1))/((66.13)+(12.182)+(0.1)));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (tcb->m_ssThresh-(78.865)-(95.234)-(tcb->m_cWnd)-(52.428)-(95.803)-(6.613)-(84.459));
tcb->m_cWnd = (int) (19.234*(segmentsAcked)*(segmentsAcked)*(83.222)*(16.625));
