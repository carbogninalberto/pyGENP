CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (62.328-(39.601)-(73.525)-(79.747));

} else {
	segmentsAcked = (int) (segmentsAcked+(31.709)+(24.999)+(76.757)+(91.555));

}
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_ssThresh = (int) (((81.467)+(59.718)+(0.1)+(43.725))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (20.511/73.38);
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (segmentsAcked*(80.723)*(0.763)*(segmentsAcked)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(57.227)*(17.166));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(75.765)+(80.767)+(tcb->m_cWnd)+(49.734)+(tcb->m_ssThresh));

}
segmentsAcked = (int) (80.329-(tcb->m_ssThresh)-(47.734)-(58.043));
