TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != segmentsAcked) {
	segmentsAcked = (int) (88.489+(57.148)+(83.008)+(35.357)+(65.545)+(8.614)+(77.626));

} else {
	segmentsAcked = (int) (17.075*(4.46)*(66.717)*(segmentsAcked)*(27.39)*(99.366)*(tcb->m_cWnd)*(27.259));

}
tcb->m_ssThresh = (int) ((((tcb->m_ssThresh-(51.316)-(98.688)-(99.289)-(5.93)-(2.641)))+((66.068+(33.055)))+(0.1)+(0.1))/((0.1)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (0.1/12.006);
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (5.728-(tcb->m_segmentSize)-(68.719)-(63.548)-(54.751)-(66.67)-(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (77.311*(66.433)*(64.229));
	tcb->m_segmentSize = (int) (89.872*(0.654)*(65.569));

}
