segmentsAcked = (int) (25.215*(69.046)*(tcb->m_ssThresh));
float wFcPEPquKRzVqRCS = (float) (50.663-(24.881)-(56.7)-(23.911)-(36.288));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (52.125+(54.817)+(31.113)+(98.661)+(53.747)+(29.747)+(28.629));
tcb->m_segmentSize = (int) (wFcPEPquKRzVqRCS-(11.284)-(20.766)-(73.582)-(17.297));
