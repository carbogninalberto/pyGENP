CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (4.323+(80.889)+(71.936)+(34.627)+(77.153)+(tcb->m_cWnd)+(98.432)+(30.633));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/3.581);

} else {
	tcb->m_ssThresh = (int) (60.866*(58.13)*(segmentsAcked)*(tcb->m_cWnd)*(38.671));

}
if (tcb->m_ssThresh < segmentsAcked) {
	segmentsAcked = (int) (tcb->m_segmentSize*(20.456)*(6.717));

} else {
	segmentsAcked = (int) (83.842-(8.176)-(25.488)-(94.342)-(17.504)-(0.52)-(76.628)-(65.641));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (27.116*(62.727)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(72.777)*(88.83)*(36.746));
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_ssThresh = (int) (54.241-(4.551)-(91.262)-(14.587)-(26.43)-(31.059)-(96.627)-(72.839));
	segmentsAcked = (int) (66.757-(82.395)-(11.256)-(22.583)-(18.274)-(1.596));

} else {
	tcb->m_ssThresh = (int) (27.483*(73.563)*(tcb->m_cWnd));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (37.296+(tcb->m_segmentSize)+(76.162)+(tcb->m_ssThresh)+(23.521)+(segmentsAcked)+(tcb->m_segmentSize)+(20.289));
	tcb->m_segmentSize = (int) (76.282+(23.455)+(tcb->m_ssThresh)+(37.671)+(63.826)+(segmentsAcked)+(tcb->m_segmentSize)+(segmentsAcked)+(3.749));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (65.626-(13.65)-(78.765)-(43.93)-(95.429)-(tcb->m_cWnd)-(3.423));
	segmentsAcked = (int) ((42.436+(tcb->m_segmentSize)+(1.143)+(99.539)+(9.502)+(98.497)+(segmentsAcked)+(5.909)+(73.481))/20.885);
	segmentsAcked = (int) (97.582-(85.951)-(37.843)-(45.888));

}
tcb->m_cWnd = (int) ((tcb->m_ssThresh-(8.999)-(43.462)-(86.749)-(98.621)-(tcb->m_ssThresh)-(63.647)-(tcb->m_ssThresh)-(72.702))/0.1);
