ReduceCwnd (tcb);
segmentsAcked = (int) (((50.728)+((33.485*(87.421)*(92.171)*(53.547)*(41.974)*(29.905)))+((59.389+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(62.885)+(96.559)+(39.995)+(95.577)+(33.469)+(65.5)))+((46.791-(20.801)-(94.734)-(7.95)-(86.721)-(85.656)-(50.433)))+(0.1))/((0.1)+(0.1)));
ReduceCwnd (tcb);
float zPsItjStiOPivoVk = (float) (23.427*(tcb->m_cWnd));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (33.844-(zPsItjStiOPivoVk)-(43.76)-(96.001)-(66.931)-(99.637)-(80.804)-(tcb->m_cWnd));
