if (tcb->m_ssThresh < tcb->m_segmentSize) {
	segmentsAcked = (int) (3.047-(tcb->m_cWnd)-(46.287)-(97.035));
	segmentsAcked = (int) (tcb->m_cWnd*(82.865));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh*(segmentsAcked)*(93.26)*(39.518)*(65.839)*(60.962)*(tcb->m_segmentSize)*(9.842)*(56.149));

}
tcb->m_ssThresh = (int) ((28.756-(62.159)-(15.494)-(tcb->m_cWnd)-(52.147)-(21.47))/0.1);
segmentsAcked = (int) (18.654-(54.559)-(1.161)-(51.988)-(22.084)-(61.863)-(52.673)-(tcb->m_ssThresh));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (68.988+(29.811)+(72.53)+(17.808)+(72.968)+(tcb->m_segmentSize)+(33.49)+(89.468)+(38.724));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (93.392+(16.828)+(49.94)+(88.74)+(71.471)+(segmentsAcked));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(61.156)+(59.081)+(78.487)+(58.167)+(46.832)+(63.763)+(19.888));

} else {
	tcb->m_segmentSize = (int) (((70.776)+(19.466)+((66.585+(81.548)+(79.97)+(79.67)))+(0.1)+(67.905)+(0.1)+(0.1)+(18.005))/((56.47)));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(7.114)-(73.984)-(60.017)-(18.796)-(48.738));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
