float VPqhqunUyNrwJdTz = (float) (-97.131+(-61.64)+(90.106)+(85.662)+(-86.101)+(-14.13)+(-32.743));
float KBjwWYFEHcllPPGj = (float) (57.552+(-0.784)+(-48.693)+(59.451)+(-97.591));
if (tcb->m_cWnd != VPqhqunUyNrwJdTz) {
	tcb->m_segmentSize = (int) (21.282+(30.96)+(segmentsAcked)+(44.111)+(95.104)+(19.636)+(76.469));

} else {
	tcb->m_segmentSize = (int) (85.759+(35.563)+(segmentsAcked)+(12.468));

}
tcb->m_cWnd = (int) (-38.735*(-81.539)*(74.063)*(37.845)*(-6.046)*(57.945)*(70.585)*(-15.104)*(14.922));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (47.788+(49.317)+(-31.841)+(0.262)+(71.889));
segmentsAcked = (int) (97.066+(-87.764));
if (tcb->m_cWnd < VPqhqunUyNrwJdTz) {
	VPqhqunUyNrwJdTz = (float) (63.515/0.1);
	ReduceCwnd (tcb);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	VPqhqunUyNrwJdTz = (float) (99.249*(23.711)*(73.486)*(12.786)*(50.849)*(43.267)*(78.239));
	CongestionAvoidance (tcb, segmentsAcked);

}
