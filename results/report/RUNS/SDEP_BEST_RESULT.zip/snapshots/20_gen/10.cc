if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((17.733)+((13.517+(66.469)+(36.509)))+(45.831)+(0.1))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (74.154/0.1);

}
if (tcb->m_cWnd != tcb->m_ssThresh) {
	segmentsAcked = (int) (63.933-(39.579)-(33.392)-(24.437)-(tcb->m_segmentSize)-(18.107)-(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (segmentsAcked-(63.4)-(5.298));
	tcb->m_segmentSize = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (76.623+(16.91)+(27.154)+(5.149)+(segmentsAcked)+(95.106));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(33.5)-(86.154)-(11.865));
	tcb->m_ssThresh = (int) (50.284*(tcb->m_ssThresh)*(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (14.145*(71.201));

}
tcb->m_segmentSize = (int) (60.638-(85.378)-(98.103));
