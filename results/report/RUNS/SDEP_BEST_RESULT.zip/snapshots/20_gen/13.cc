tcb->m_ssThresh = (int) (tcb->m_ssThresh+(31.272)+(80.81)+(41.656));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (4.527-(42.618)-(43.525)-(14.069)-(tcb->m_cWnd)-(15.116));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (96.387+(tcb->m_segmentSize)+(32.183)+(26.075)+(14.228)+(tcb->m_segmentSize)+(57.599)+(9.504)+(tcb->m_cWnd));
	tcb->m_cWnd = (int) (((0.1)+((12.709-(81.886)-(38.803)))+((13.846*(tcb->m_segmentSize)*(49.991)*(38.308)*(93.262)*(44.877)*(59.998)))+(79.692)+(0.1))/((17.685)+(0.1)+(94.091)));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (0.1/20.849);
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((36.522)+(36.095)+(29.999)+(0.1)+(45.547)+(0.1))/((35.395)+(33.485)));

} else {
	tcb->m_ssThresh = (int) (19.496-(69.946));
	tcb->m_segmentSize = (int) (42.564-(3.235)-(47.322)-(88.497)-(38.83)-(26.155));

}
