ReduceCwnd (tcb);
tcb->m_cWnd = (int) (52.36-(61.4)-(-90.496)-(3.252)-(77.27)-(97.977));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (42.831-(27.193)-(-11.365)-(41.208)-(-63.085)-(48.101));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-7.068-(39.232)-(23.648)-(-29.549)-(-52.43)-(-54.309));
CongestionAvoidance (tcb, segmentsAcked);
