if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (34.056*(0.526)*(28.594)*(tcb->m_segmentSize));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (-62.483*(72.452)*(53.182)*(11.41)*(59.704)*(tcb->m_cWnd)*(52.387)*(48.762)*(68.105));

}
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) (63.627-(77.169)-(35.677)-(0.336)-(segmentsAcked)-(99.261));

} else {
	tcb->m_cWnd = (int) (36.613-(10.227)-(75.323)-(-1.521)-(20.996));
	segmentsAcked = (int) (33.139+(tcb->m_cWnd)+(33.039)+(75.735));

}
tcb->m_segmentSize = (int) (-36.094-(-97.986)-(-6.514)-(8.496)-(61.992));
