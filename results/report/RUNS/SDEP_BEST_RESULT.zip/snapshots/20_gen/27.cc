segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (segmentsAcked+(84.302)+(22.236)+(4.559));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (28.351*(tcb->m_segmentSize)*(segmentsAcked)*(62.028)*(57.191));
int pTpeMSKzFFvwXJAH = (int) (27.297*(36.018));
