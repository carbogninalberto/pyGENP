float GlYnUfNEhhqeolSQ = (float) (8.51+(tcb->m_cWnd)+(38.256)+(7.915)+(tcb->m_ssThresh)+(72.449)+(19.041)+(98.594)+(44.525));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (91.464+(32.686)+(78.161)+(14.513)+(54.514)+(45.45));
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((tcb->m_segmentSize+(34.525)+(26.391)+(tcb->m_ssThresh)+(27.444)+(60.2)+(16.409)+(0.33))/20.32);

} else {
	tcb->m_segmentSize = (int) (2.916-(29.508)-(86.57)-(54.596)-(66.797)-(63.561)-(71.794)-(22.248));

}
tcb->m_cWnd = (int) (43.882*(93.862)*(segmentsAcked)*(84.951)*(54.632)*(16.501));
segmentsAcked = (int) (10.652-(GlYnUfNEhhqeolSQ)-(0.522)-(52.924)-(84.16)-(30.579));
int ysiQxcCuJrDRwzkw = (int) (1.698/26.006);
if (segmentsAcked != ysiQxcCuJrDRwzkw) {
	ysiQxcCuJrDRwzkw = (int) (42.17+(GlYnUfNEhhqeolSQ)+(GlYnUfNEhhqeolSQ)+(94.694)+(6.56)+(94.516)+(89.362)+(49.625));

} else {
	ysiQxcCuJrDRwzkw = (int) (0.1/55.531);

}
