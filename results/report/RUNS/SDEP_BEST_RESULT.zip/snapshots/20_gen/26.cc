if (segmentsAcked >= segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(tcb->m_ssThresh)-(38.944));

} else {
	tcb->m_ssThresh = (int) (50.398/(31.852-(69.319)-(84.878)));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	segmentsAcked = (int) (18.67/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (92.496*(38.265)*(segmentsAcked)*(segmentsAcked));
	tcb->m_cWnd = (int) (6.967*(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(4.864));

}
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(50.798)+(76.804)+(88.105)+(30.081)+(tcb->m_ssThresh)+(25.812)+(2.074)+(tcb->m_ssThresh));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (79.008*(1.568)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(18.854)*(81.507)*(49.857));

} else {
	tcb->m_segmentSize = (int) (94.807/64.543);
	segmentsAcked = (int) (11.384*(tcb->m_cWnd)*(74.183)*(90.058)*(71.988));

}
ReduceCwnd (tcb);
float IUXMcmEhyatyyRSq = (float) (58.424*(76.697)*(57.394)*(96.425)*(46.276)*(18.669)*(tcb->m_cWnd)*(21.381));
if (tcb->m_cWnd == IUXMcmEhyatyyRSq) {
	tcb->m_ssThresh = (int) (41.859*(54.28));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (tcb->m_segmentSize-(12.823)-(83.168)-(18.685)-(5.57)-(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (((36.673)+(46.476)+(71.262)+(0.1)+(78.049))/((0.1)+(0.1)+(0.1)));
	IUXMcmEhyatyyRSq = (float) (35.15*(82.027)*(segmentsAcked)*(47.978));
	tcb->m_cWnd = (int) (28.57*(4.094)*(74.789)*(79.052)*(tcb->m_segmentSize)*(67.989)*(segmentsAcked));

}
if (tcb->m_segmentSize < IUXMcmEhyatyyRSq) {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (((0.1)+((89.422*(59.107)*(8.376)*(tcb->m_cWnd)*(33.53)))+(87.791)+(51.915)+(0.1)+(49.224))/((0.1)));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((19.308)+(0.1)+(25.105)+((18.908+(10.135)+(93.441)+(tcb->m_cWnd)+(38.085)+(99.542)+(IUXMcmEhyatyyRSq)))+(67.31))/((76.511)+(0.1)+(0.1)));
	IUXMcmEhyatyyRSq = (float) (90.639*(9.62)*(IUXMcmEhyatyyRSq)*(56.422)*(33.43)*(segmentsAcked)*(66.942)*(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(7.716)-(62.217)-(98.608)-(1.934));

}
