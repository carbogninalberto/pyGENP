ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(73.937)*(47.829)*(28.492)*(49.558)*(69.644));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (tcb->m_cWnd+(segmentsAcked)+(34.849)+(83.536)+(68.782));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(segmentsAcked)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(49.287)+(77.897));
	tcb->m_cWnd = (int) (0.1/32.104);
	tcb->m_segmentSize = (int) (61.299*(60.748)*(89.636)*(61.919)*(42.737)*(39.306));

}
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	segmentsAcked = (int) (25.601+(34.321)+(3.289)+(55.476)+(21.466)+(83.681));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) ((54.937*(segmentsAcked)*(55.296)*(segmentsAcked)*(99.176))/0.1);
	tcb->m_segmentSize = (int) (68.255+(14.882)+(tcb->m_segmentSize)+(13.824)+(80.56)+(35.78)+(56.522));
	tcb->m_ssThresh = (int) (segmentsAcked*(80.288)*(30.416)*(tcb->m_segmentSize)*(23.784)*(75.931)*(80.343)*(tcb->m_ssThresh));

}
tcb->m_segmentSize = (int) ((6.097+(segmentsAcked)+(58.37))/34.466);
tcb->m_ssThresh = (int) (85.842+(89.732));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (30.856+(34.502)+(38.232)+(27.506)+(17.704));
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (21.281/0.1);

}
