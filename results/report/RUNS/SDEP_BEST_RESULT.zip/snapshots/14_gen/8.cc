if (segmentsAcked > segmentsAcked) {
	tcb->m_cWnd = (int) (35.517-(tcb->m_cWnd)-(segmentsAcked)-(64.592)-(96.307)-(71.812)-(43.67)-(9.685));

} else {
	tcb->m_cWnd = (int) (10.608*(63.919)*(63.475));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-53.201+(80.519)+(-40.484)+(-41.049)+(78.677)+(32.257)+(-42.413)+(5.41));
