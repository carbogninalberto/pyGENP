float hrjDKykyhiTVBEgp = (float) ((11.859+(49.917)+(86.813)+(12.815)+(3.289))/12.304);
tcb->m_ssThresh = (int) (29.437+(19.145)+(94.032)+(95.604)+(31.476)+(60.297)+(13.06)+(90.355));
ReduceCwnd (tcb);
segmentsAcked = (int) (hrjDKykyhiTVBEgp+(75.869)+(25.713)+(hrjDKykyhiTVBEgp)+(97.347));
hrjDKykyhiTVBEgp = (float) (0.1/49.798);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
