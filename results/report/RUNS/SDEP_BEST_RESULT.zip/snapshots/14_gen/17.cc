ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-20.233-(-95.507)-(55.645)-(26.136)-(15.768)-(-4.579));
tcb->m_cWnd = (int) (-98.563-(50.793)-(-41.972)-(-81.762)-(2.057)-(71.574));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
