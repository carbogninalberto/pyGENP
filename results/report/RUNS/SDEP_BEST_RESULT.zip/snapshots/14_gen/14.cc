ReduceCwnd (tcb);
tcb->m_cWnd = (int) (8.462-(77.097)-(86.482)-(-37.323)-(-9.331)-(29.198));
tcb->m_cWnd = (int) (18.753-(-42.165)-(72.171)-(-66.833)-(1.345)-(23.039));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
