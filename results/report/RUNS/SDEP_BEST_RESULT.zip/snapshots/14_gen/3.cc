ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-98.23-(-49.399)-(-38.691)-(-80.676)-(-72.197)-(-65.636));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-37.876-(2.796)-(-36.349)-(-9.298)-(89.165)-(-96.875));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (4.651-(-97.073)-(23.822)-(72.01)-(-86.394)-(37.951));
CongestionAvoidance (tcb, segmentsAcked);
