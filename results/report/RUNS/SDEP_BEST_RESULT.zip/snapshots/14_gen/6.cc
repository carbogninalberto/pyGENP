ReduceCwnd (tcb);
tcb->m_cWnd = (int) (49.534-(-63.377)-(76.26)-(15.813)-(36.784)-(-46.941));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (44.775-(94.388)-(51.407)-(-30.625)-(97.626)-(-96.699));
CongestionAvoidance (tcb, segmentsAcked);
