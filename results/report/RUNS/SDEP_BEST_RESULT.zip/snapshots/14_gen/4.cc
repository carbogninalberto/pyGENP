ReduceCwnd (tcb);
tcb->m_cWnd = (int) (27.529-(-7.914)-(-28.378)-(68.899)-(56.526)-(-65.912));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
