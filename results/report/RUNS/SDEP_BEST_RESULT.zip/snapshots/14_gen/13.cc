int qVJAyhQYowxyPfBJ = (int) 84.866;
segmentsAcked = (int) (-77.687/93.801);
tcb->m_segmentSize = (int) ((-69.1+(-57.833)+(-14.368)+(-47.112)+(tcb->m_ssThresh))/37.845);
