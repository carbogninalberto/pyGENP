if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (97.033-(segmentsAcked)-(56.709)-(tcb->m_ssThresh)-(83.654)-(85.863)-(tcb->m_cWnd)-(41.511)-(72.387));
	tcb->m_segmentSize = (int) (13.125/30.721);

} else {
	segmentsAcked = (int) (33.58*(92.398)*(tcb->m_ssThresh)*(12.703));

}
tcb->m_cWnd = (int) (41.596-(25.035)-(72.398)-(90.647)-(tcb->m_cWnd)-(38.016)-(37.987)-(32.604));
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (37.423+(6.206)+(86.475)+(36.967)+(98.352)+(98.284)+(65.159));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (93.71-(segmentsAcked)-(32.207)-(tcb->m_ssThresh)-(75.889)-(85.349)-(48.966)-(48.988)-(tcb->m_segmentSize));

}
float ILnTamHSMwMfIeFQ = (float) ((((48.044-(74.007)-(segmentsAcked)-(77.355)-(segmentsAcked)-(28.217)-(3.602)))+((88.919*(tcb->m_cWnd)*(tcb->m_cWnd)*(39.61)*(tcb->m_segmentSize)*(51.925)*(52.336)*(1.942)*(72.08)))+((tcb->m_cWnd+(72.237)+(tcb->m_ssThresh)+(72.072)+(44.322)))+(0.1))/((86.68)+(0.1)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	segmentsAcked = (int) ((((94.322-(30.682)-(segmentsAcked)-(26.558)-(19.73)-(94.663)-(13.045)-(66.312)-(27.613)))+(71.926)+(18.102)+((76.646*(tcb->m_ssThresh)*(1.6)))+(38.651)+(0.1))/((39.565)+(0.1)+(0.1)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) ((((59.11+(90.545)+(67.794)+(63.833)))+(0.1)+(19.256)+(38.883)+(0.1)+(39.431)+(0.1))/((0.1)));
	tcb->m_ssThresh = (int) (81.632*(ILnTamHSMwMfIeFQ)*(28.341));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
