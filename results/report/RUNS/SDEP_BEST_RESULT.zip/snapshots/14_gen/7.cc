ReduceCwnd (tcb);
tcb->m_cWnd = (int) (1.024-(21.621)-(-62.257)-(-97.881)-(39.351)-(-17.613));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (4.407-(26.495)-(29.064)-(62.58)-(11.066)-(-64.204));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
