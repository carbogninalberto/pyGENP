int JXbQtCngNVUYiHWW = (int) (-65.024/-22.799);
segmentsAcked = SlowStart (tcb, segmentsAcked);
int LcOxIXeYMUlfzSpW = (int) ((-27.294*(-34.798)*(-20.51))/-93.528);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
