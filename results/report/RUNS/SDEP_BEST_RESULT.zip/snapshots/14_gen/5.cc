ReduceCwnd (tcb);
tcb->m_cWnd = (int) (4.865-(-87.842)-(49.327)-(1.664)-(32.235)-(-78.635));
tcb->m_cWnd = (int) (73.728-(-69.126)-(-74.853)-(-54.118)-(-34.946)-(-6.992));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
