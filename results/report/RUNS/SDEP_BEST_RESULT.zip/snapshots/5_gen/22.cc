ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-38.729-(-14.544)-(38.845)-(61.264)-(30.702)-(-38.278));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (44.057-(63.079)-(47.892)-(-43.838)-(-22.606)-(20.26));
CongestionAvoidance (tcb, segmentsAcked);
