ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-48.795-(-61.416)-(-98.368)-(38.821)-(-80.517)-(84.859));
CongestionAvoidance (tcb, segmentsAcked);
