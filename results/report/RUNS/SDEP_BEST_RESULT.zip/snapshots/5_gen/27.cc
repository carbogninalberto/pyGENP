ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-97.082-(-31.877)-(39.921)-(29.271)-(-72.081)-(4.835));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (88.418-(39.919)-(-4.755)-(78.596)-(-31.151)-(19.58));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
