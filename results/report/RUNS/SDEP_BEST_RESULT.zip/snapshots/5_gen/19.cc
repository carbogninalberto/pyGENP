ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-81.627-(-0.793)-(-82.267)-(57.334)-(-38.54)-(-27.57));
tcb->m_cWnd = (int) (61.712-(-59.91)-(86.683)-(15.958)-(-33.11)-(-39.352));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (91.866-(-82.262)-(89.026)-(-5.744)-(-66.586)-(-22.742));
CongestionAvoidance (tcb, segmentsAcked);
