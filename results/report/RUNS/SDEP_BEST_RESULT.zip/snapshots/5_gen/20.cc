ReduceCwnd (tcb);
tcb->m_cWnd = (int) (8.891-(1.751)-(-93.899)-(-77.12)-(-26.199)-(-49.277));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (22.331-(-14.152)-(9.671)-(-91.416)-(25.218)-(-49.448));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
