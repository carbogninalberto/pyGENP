ReduceCwnd (tcb);
tcb->m_cWnd = (int) (40.076-(-92.389)-(63.896)-(-6.951)-(-48.556)-(-36.15));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (5.444-(-48.274)-(99.138)-(-88.556)-(-21.988)-(44.542));
CongestionAvoidance (tcb, segmentsAcked);
