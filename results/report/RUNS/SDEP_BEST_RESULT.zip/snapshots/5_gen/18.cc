ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-73.587-(-69.74)-(-86.036)-(61.17)-(-70.868)-(-94.881));
tcb->m_cWnd = (int) (-70.29-(16.992)-(34.787)-(-21.998)-(65.342)-(-9.807));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
