float xcNFlwcXGUfeiyZn = (float) (-65.256*(-9.533)*(-10.19)*(-71.424)*(-68.397)*(-32.812)*(-46.548)*(-35.066)*(-60.748));
segmentsAcked = (int) (-16.577-(21.7));
float qzqLlypKiwTYFdco = (float) (-11.701*(34.17)*(68.366)*(-67.637)*(-42.608));
if (segmentsAcked > tcb->m_cWnd) {
	qzqLlypKiwTYFdco = (float) (76.383-(69.598)-(81.543)-(7.425)-(segmentsAcked)-(tcb->m_segmentSize));

} else {
	qzqLlypKiwTYFdco = (float) (94.939-(17.349)-(25.929)-(79.372)-(76.489)-(32.658));
	tcb->m_cWnd = (int) (33.187+(24.643)+(tcb->m_segmentSize)+(23.85));
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(68.175)-(70.08)-(2.743));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (94.03+(81.701));
if (segmentsAcked > tcb->m_cWnd) {
	qzqLlypKiwTYFdco = (float) (94.939-(17.349)-(25.929)-(79.372)-(76.489)-(32.658));
	tcb->m_cWnd = (int) (33.187+(24.643)+(tcb->m_segmentSize)+(23.85));
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(68.175)-(70.08)-(2.743));

} else {
	qzqLlypKiwTYFdco = (float) (76.383-(69.598)-(81.543)-(7.425)-(segmentsAcked)-(tcb->m_segmentSize));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (33.247+(-44.239));
