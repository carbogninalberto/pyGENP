ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-90.466-(-54.696)-(-55.35)-(19.356)-(61.74)-(-98.93));
tcb->m_cWnd = (int) (-55.52-(7.468)-(-41.37)-(79.348)-(98.27)-(78.381));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
