int pjFDuvvSsKqdzEJQ = (int) (-80.073-(8.67)-(-93.34)-(-29.764)-(58.84)-(35.51)-(17.184)-(89.204));
segmentsAcked = (int) (-2.968*(59.881)*(93.611)*(18.288)*(-90.07)*(-85.133)*(91.363));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (45.601+(85.235)+(73.912)+(90.05)+(73.48));

} else {
	tcb->m_segmentSize = (int) (0.192*(84.937)*(98.445));

}
segmentsAcked = (int) (25.346*(-56.487)*(-63.827)*(-2.985)*(71.791)*(33.622)*(1.192));
if (pjFDuvvSsKqdzEJQ == segmentsAcked) {
	tcb->m_segmentSize = (int) (0.1/(23.236-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(87.431)-(57.535)-(pjFDuvvSsKqdzEJQ)-(67.355)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (88.427-(35.608)-(64.818)-(50.668)-(87.479)-(91.539));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (-28.029*(14.789)*(75.674)*(-22.002));
