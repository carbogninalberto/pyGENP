if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (10.317-(27.135)-(54.107)-(79.984)-(tcb->m_cWnd)-(89.201)-(79.138));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (75.22*(44.648)*(28.322)*(59.583)*(1.433));
	segmentsAcked = (int) (90.564+(15.242)+(segmentsAcked)+(74.428)+(57.902)+(56.518)+(19.95)+(62.137)+(85.576));

}
tcb->m_cWnd = (int) (21.38*(77.045)*(16.764)*(57.532)*(68.043)*(39.39)*(50.586)*(74.956));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (0.811*(6.74)*(69.717)*(72.208));
tcb->m_ssThresh = (int) (83.203+(55.395)+(21.352)+(12.768));
