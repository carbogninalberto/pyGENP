int GKTTZJRIyGYwfNPc = (int) (-49.549*(-58.861)*(-39.539)*(11.231)*(62.814)*(-65.939)*(-64.656)*(-16.838));
int lnQDKMKGPsyTxJnn = (int) (-80.666-(37.204)-(-54.55)-(-11.424)-(-42.987)-(93.657));
GKTTZJRIyGYwfNPc = (int) (14.311+(-24.055)+(-84.146)+(71.524)+(-1.72)+(-95.564));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	lnQDKMKGPsyTxJnn = (int) (54.547/48.271);
	lnQDKMKGPsyTxJnn = (int) (0.608-(87.551));

} else {
	lnQDKMKGPsyTxJnn = (int) (lnQDKMKGPsyTxJnn+(17.577)+(88.425));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (49.487*(66.833)*(-49.823)*(-78.874)*(-84.363)*(56.254)*(33.015)*(-80.639)*(18.969));
