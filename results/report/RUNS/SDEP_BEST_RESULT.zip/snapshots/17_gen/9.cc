tcb->m_segmentSize = (int) (14.814+(94.493)+(-65.482)+(92.996)+(98.645)+(14.521)+(-62.742));
segmentsAcked = SlowStart (tcb, segmentsAcked);
