if (segmentsAcked != tcb->m_segmentSize) {
	segmentsAcked = (int) (90.483*(46.117)*(tcb->m_cWnd)*(49.185)*(76.831)*(21.638)*(63.778));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh*(tcb->m_ssThresh)*(78.118)*(19.187)*(segmentsAcked)*(93.629)*(97.124));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (((0.1)+((39.536*(14.661)*(82.664)))+(0.1)+(71.241)+(0.1))/((14.71)+(0.1)+(0.1)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (43.545+(12.504)+(17.848)+(58.035));
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (47.995+(tcb->m_cWnd)+(13.96)+(11.582)+(71.216));

} else {
	tcb->m_cWnd = (int) (38.384-(45.477)-(78.287)-(72.639));

}
