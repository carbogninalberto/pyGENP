if (tcb->m_cWnd <= tcb->m_segmentSize) {
	segmentsAcked = (int) (48.106*(segmentsAcked)*(6.576)*(0.396)*(24.246)*(76.988));
	tcb->m_segmentSize = (int) (0.1/86.387);
	tcb->m_ssThresh = (int) (segmentsAcked*(tcb->m_ssThresh)*(67.243)*(60.087)*(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (98.1/77.054);
	segmentsAcked = (int) (43.691*(57.665)*(segmentsAcked)*(53.81)*(41.021)*(27.252));
	tcb->m_segmentSize = (int) (92.215*(27.189)*(95.324));

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	segmentsAcked = (int) (segmentsAcked-(tcb->m_cWnd)-(13.241)-(29.207)-(93.37)-(74.246)-(51.451));

} else {
	segmentsAcked = (int) (90.645-(80.705)-(segmentsAcked)-(58.67)-(78.372)-(0.149));
	segmentsAcked = (int) (15.539-(70.847)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(18.185)-(67.517)-(50.822));
	tcb->m_segmentSize = (int) (29.457*(84.618)*(62.533)*(95.281)*(2.79)*(tcb->m_cWnd));

}
tcb->m_segmentSize = (int) (55.67*(20.027));
tcb->m_cWnd = (int) (((38.26)+(79.785)+(10.911)+(43.16)+(74.775)+(0.1))/((79.137)));
tcb->m_ssThresh = (int) (9.663+(2.899)+(96.519)+(tcb->m_cWnd)+(57.744)+(55.276)+(48.144));
