ReduceCwnd (tcb);
tcb->m_cWnd = (int) (15.192-(-14.356)-(-16.41)-(-2.563)-(43.425)-(-68.225));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-82.173-(39.861)-(-78.662)-(-41.367)-(97.128)-(-89.219));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
