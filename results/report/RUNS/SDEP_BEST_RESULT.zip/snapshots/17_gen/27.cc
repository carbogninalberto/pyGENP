TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (26.375-(24.247)-(40.887)-(93.171)-(tcb->m_segmentSize)-(79.577));
float OrzfqKSUJiTMGrfH = (float) (6.444*(49.075)*(tcb->m_segmentSize)*(60.831)*(50.154)*(95.004));
if (OrzfqKSUJiTMGrfH <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(31.39)-(tcb->m_segmentSize)-(22.584)-(62.436)-(53.66));
	segmentsAcked = (int) (3.66+(85.177));
	tcb->m_segmentSize = (int) (45.537*(1.221)*(48.602)*(29.089)*(42.419)*(segmentsAcked)*(3.342));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(OrzfqKSUJiTMGrfH)+(11.798)+(2.451)+(27.229)+(98.452)+(81.985)+(53.725));

}
