ReduceCwnd (tcb);
float yKEhtVwSytywtiWt = (float) (-99.155-(74.691)-(-18.977)-(79.025)-(-75.64)-(-60.375)-(-35.203));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
