if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (16.116*(84.87)*(22.009)*(7.145)*(98.885));

} else {
	tcb->m_segmentSize = (int) (94.523+(tcb->m_segmentSize)+(90.7)+(12.857)+(85.321)+(-9.246)+(16.222)+(38.203));
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(78.486)-(89.254)-(75.456));

}
float bOmeLNsOkdEvQWrU = (float) (-73.311-(-51.599)-(62.706)-(-17.123)-(-81.033)-(-54.368)-(-36.3)-(27.772)-(-50.907));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
