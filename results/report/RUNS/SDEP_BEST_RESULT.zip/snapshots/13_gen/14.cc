if (tcb->m_ssThresh <= segmentsAcked) {
	segmentsAcked = (int) (81.588+(8.278)+(30.2)+(1.529)+(tcb->m_segmentSize)+(44.991)+(51.405));

} else {
	segmentsAcked = (int) (89.852*(segmentsAcked)*(17.44)*(98.893)*(10.173)*(26.918)*(81.4)*(85.062));
	tcb->m_segmentSize = (int) (7.316*(segmentsAcked)*(36.796)*(72.097)*(78.076)*(37.605));

}
tcb->m_ssThresh = (int) (57.428-(9.885)-(tcb->m_cWnd));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (25.979*(19.951)*(30.548)*(45.287)*(tcb->m_cWnd)*(48.712));

} else {
	tcb->m_cWnd = (int) (17.059-(43.262)-(tcb->m_cWnd)-(0.523));
	tcb->m_ssThresh = (int) (16.432+(51.614)+(23.974)+(64.453)+(85.172)+(38.736)+(55.522)+(46.033)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (21.203*(tcb->m_ssThresh)*(38.422)*(1.419)*(57.583)*(79.578)*(segmentsAcked)*(30.677));

}
tcb->m_segmentSize = (int) (0.1/1.874);
segmentsAcked = (int) (segmentsAcked-(36.067)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(segmentsAcked)-(85.264)-(30.445)-(89.59));
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_segmentSize = (int) (39.573/96.568);

} else {
	tcb->m_segmentSize = (int) (80.694+(tcb->m_segmentSize)+(56.741)+(53.991)+(33.074)+(52.243)+(92.354));

}
