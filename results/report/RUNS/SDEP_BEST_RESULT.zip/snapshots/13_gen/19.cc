ReduceCwnd (tcb);
tcb->m_cWnd = (int) (48.569+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(86.968)+(74.359)+(37.14)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(29.92));
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (35.038*(59.445)*(56.432));
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (77.372-(14.516)-(70.868));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(57.242));

}
tcb->m_segmentSize = (int) (((0.1)+((28.187+(tcb->m_segmentSize)+(34.46)+(92.288)+(91.202)+(23.152)))+(0.1)+(0.1)+(49.237)+(0.1)+((18.134-(15.971)-(59.592)))+(0.1))/((0.1)));
ReduceCwnd (tcb);
segmentsAcked = (int) (6.895+(45.615)+(97.417)+(tcb->m_ssThresh)+(9.436)+(87.284)+(10.948)+(tcb->m_segmentSize)+(96.256));
CongestionAvoidance (tcb, segmentsAcked);
