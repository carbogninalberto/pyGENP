ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_cWnd+(tcb->m_ssThresh));
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((40.869)+(70.943)+(76.23)+(1.747)+(0.1)+(68.342)+(0.1))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (95.052*(39.901)*(85.048));
	tcb->m_cWnd = (int) (0.1/12.709);

}
segmentsAcked = (int) (96.772-(84.568));
tcb->m_ssThresh = (int) (44.48+(32.104)+(56.005)+(43.748)+(8.65));
