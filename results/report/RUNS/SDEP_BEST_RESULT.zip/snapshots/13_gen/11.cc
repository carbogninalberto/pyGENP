ReduceCwnd (tcb);
tcb->m_cWnd = (int) (27.012-(85.68)-(55.47)-(-94.35)-(-14.929)-(95.623));
tcb->m_cWnd = (int) (59.235-(-91.938)-(29.322)-(78.741)-(-55.522)-(-90.647));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
