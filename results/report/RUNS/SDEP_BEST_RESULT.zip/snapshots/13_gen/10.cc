ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-35.534-(23.325)-(-84.535)-(-50.897)-(-50.837)-(-80.615));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-20.641-(76.018)-(68.156)-(-12.463)-(50.155)-(86.384));
CongestionAvoidance (tcb, segmentsAcked);
