ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-20.507-(26.151)-(17.416)-(11.649)-(12.429)-(72.983));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-37.066-(-61.801)-(-3.009)-(-71.653)-(-7.587)-(29.921));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (17.743-(37.494)-(-65.968)-(57.298)-(-89.448)-(58.646));
CongestionAvoidance (tcb, segmentsAcked);
