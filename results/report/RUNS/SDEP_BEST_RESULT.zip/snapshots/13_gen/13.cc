int JXbQtCngNVUYiHWW = (int) (61.124/50.208);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
