tcb->m_ssThresh = (int) (71.336-(86.697)-(42.624)-(89.418)-(74.768)-(41.289));
tcb->m_cWnd = (int) (56.641/31.569);
if (segmentsAcked < segmentsAcked) {
	segmentsAcked = (int) (48.305-(80.171)-(39.378)-(12.559)-(70.526)-(96.112)-(21.851)-(18.425)-(12.697));

} else {
	segmentsAcked = (int) (65.756+(6.746));
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (78.906+(11.531)+(1.84)+(82.432)+(70.601)+(tcb->m_ssThresh)+(55.152));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
