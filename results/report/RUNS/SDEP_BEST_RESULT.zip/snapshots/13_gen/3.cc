ReduceCwnd (tcb);
tcb->m_cWnd = (int) (27.306-(59.455)-(-17.096)-(60.858)-(31.42)-(24.373));
tcb->m_cWnd = (int) (37.259-(8.395)-(-29.047)-(14.65)-(9.168)-(31.592));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
