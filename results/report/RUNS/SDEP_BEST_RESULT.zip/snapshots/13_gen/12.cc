ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-83.709-(56.903)-(-73.893)-(-89.586)-(-89.762)-(32.516));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-42.113-(-69.214)-(-68.109)-(16.691)-(65.768)-(17.865));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
