if (segmentsAcked > segmentsAcked) {
	tcb->m_cWnd = (int) (35.517-(tcb->m_cWnd)-(segmentsAcked)-(64.592)-(96.307)-(tcb->m_ssThresh)-(43.67)-(9.685));

} else {
	tcb->m_cWnd = (int) (10.608*(63.919)*(63.475));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (85.473+(tcb->m_ssThresh)+(38.241)+(3.518)+(94.953)+(87.741)+(61.296)+(97.357));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
