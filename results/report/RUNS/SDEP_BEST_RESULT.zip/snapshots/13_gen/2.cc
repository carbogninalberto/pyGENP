ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-10.105-(36.066)-(81.154)-(71.837)-(-41.607)-(47.395));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
