CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (28.322*(79.081)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(95.126));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(77.154)+(60.423));

}
tcb->m_ssThresh = (int) (99.364*(71.775));
