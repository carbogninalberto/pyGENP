ReduceCwnd (tcb);
tcb->m_cWnd = (int) (92.047-(84.423)-(90.338)-(99.651)-(3.255)-(69.367));
tcb->m_cWnd = (int) (46.575-(2.53)-(24.484)-(82.396)-(74.997)-(-80.716));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
