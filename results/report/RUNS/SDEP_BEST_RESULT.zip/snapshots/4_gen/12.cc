ReduceCwnd (tcb);
tcb->m_cWnd = (int) (40.78-(-54.326)-(-20.89)-(51.687)-(93.091)-(-5.379));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (43.947-(-56.637)-(7.027)-(2.819)-(-19.774)-(45.701));
CongestionAvoidance (tcb, segmentsAcked);
