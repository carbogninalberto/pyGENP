ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-10.131-(53.299)-(-4.413)-(-9.124)-(54.676)-(-64.698));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-81.043-(-90.398)-(49.426)-(-4.255)-(-73.976)-(-73.969));
tcb->m_cWnd = (int) (13.239-(-30.535)-(-20.066)-(-58.847)-(12.556)-(-20.609));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (70.652-(-67.676)-(-88.53)-(-33.121)-(-75.736)-(-38.371));
CongestionAvoidance (tcb, segmentsAcked);
