ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-8.257-(-30.597)-(-4.46)-(-47.05)-(41.056)-(42.309));
tcb->m_cWnd = (int) (-59.16-(-74.085)-(45.268)-(83.612)-(-29.725)-(96.094));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (99.69-(-78.836)-(70.575)-(49.658)-(-59.549)-(-91.431));
CongestionAvoidance (tcb, segmentsAcked);
