ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-17.475-(-78.128)-(48.949)-(-90.215)-(34.563)-(89.57));
tcb->m_cWnd = (int) (-61.551-(-88.888)-(-84.01)-(-61.591)-(-55.979)-(71.853));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
