tcb->m_cWnd = (int) (76.445*(-43.604)*(7.799)*(50.554)*(-41.823)*(-41.245)*(-87.531)*(76.402)*(-10.585));
CongestionAvoidance (tcb, segmentsAcked);
