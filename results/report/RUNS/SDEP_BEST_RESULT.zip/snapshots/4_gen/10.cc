float XkXWQMqEPdQFFccz = (float) 5.034;
int vawxvRwdDlnxtbye = (int) ((82.407+(-47.782)+(-75.548)+(-24.096)+(58.87)+(77.097)+(-39.188))/(-62.981*(-56.189)*(-29.957)*(84.906)*(-47.0)*(-29.478)));
tcb->m_segmentSize = (int) (-91.124*(82.572)*(22.77));
segmentsAcked = (int) (((44.927)+(72.306)+(-72.755)+(81.456))/((51.048)+(21.049)+(-34.264)+(-24.575)+(-58.769)));
segmentsAcked = (int) (((-19.428)+(-34.523)+(-47.745)+(-78.989))/((38.038)+(47.658)+(-30.683)+(9.587)+(33.014)));
XkXWQMqEPdQFFccz = (float) ((-37.227-(72.264)-(segmentsAcked)-(segmentsAcked))/-53.378);
XkXWQMqEPdQFFccz = (float) ((-93.637-(-19.897)-(segmentsAcked)-(segmentsAcked))/-70.528);
