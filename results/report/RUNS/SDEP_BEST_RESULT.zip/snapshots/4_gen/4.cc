float BjbKRRSNZUFwGoHF = (float) (16.156+(-64.471)+(-5.836)+(-55.341)+(79.863)+(-22.735)+(52.267)+(64.478));
float HCBDTWiYnHAiYPiL = (float) (-45.439+(-15.907)+(-70.308)+(12.014));
tcb->m_cWnd = (int) (-78.753/-25.026);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (65.456+(13.511)+(2.547)+(44.859)+(tcb->m_cWnd)+(22.489)+(11.77)+(86.324)+(56.006));

} else {
	segmentsAcked = (int) ((((10.315+(97.925)))+(25.835)+((38.989+(tcb->m_cWnd)+(99.422)+(44.158)+(41.406)+(33.721)+(36.034)+(75.028)))+(0.1))/((0.1)+(0.1)+(0.1)));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((10.315+(97.925)))+(25.835)+((38.989+(tcb->m_cWnd)+(99.422)+(44.158)+(41.406)+(33.721)+(36.034)+(75.028)))+(0.1))/((0.1)+(0.1)+(0.1)));

} else {
	segmentsAcked = (int) (65.456+(13.511)+(2.547)+(44.859)+(tcb->m_cWnd)+(22.489)+(11.77)+(86.324)+(56.006));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
