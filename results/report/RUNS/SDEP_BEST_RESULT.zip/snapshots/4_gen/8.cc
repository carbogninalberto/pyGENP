ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-38.359-(-67.751)-(71.754)-(90.009)-(15.65)-(15.957));
CongestionAvoidance (tcb, segmentsAcked);
