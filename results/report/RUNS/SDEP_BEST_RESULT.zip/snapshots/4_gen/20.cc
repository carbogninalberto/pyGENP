ReduceCwnd (tcb);
tcb->m_cWnd = (int) (57.829-(-40.861)-(78.325)-(-96.617)-(56.081)-(-44.851));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
