segmentsAcked = (int) (72.955-(50.76)-(76.938)-(-27.318)-(-85.318)-(-78.182));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
