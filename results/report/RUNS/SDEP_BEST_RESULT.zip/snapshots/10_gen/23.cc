ReduceCwnd (tcb);
tcb->m_cWnd = (int) (2.957-(66.744)-(5.487)-(-44.261)-(32.348)-(-90.059));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (24.378-(-81.722)-(-56.779)-(-54.753)-(24.765)-(93.626));
tcb->m_cWnd = (int) (-63.968-(16.631)-(8.568)-(6.956)-(-12.67)-(-5.144));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (80.771-(61.035)-(79.329)-(53.931)-(27.263)-(89.615));
CongestionAvoidance (tcb, segmentsAcked);
