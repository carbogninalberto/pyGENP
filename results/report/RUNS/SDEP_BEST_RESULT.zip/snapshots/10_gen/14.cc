ReduceCwnd (tcb);
tcb->m_cWnd = (int) (28.201-(41.452)-(72.021)-(-11.286)-(14.328)-(36.298));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-3.947-(76.219)-(-16.43)-(-78.765)-(96.091)-(-37.456));
CongestionAvoidance (tcb, segmentsAcked);
