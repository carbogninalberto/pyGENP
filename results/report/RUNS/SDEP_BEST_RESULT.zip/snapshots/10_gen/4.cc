ReduceCwnd (tcb);
tcb->m_cWnd = (int) (28.42-(-10.816)-(2.301)-(5.361)-(-2.044)-(-22.659));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (44.197-(-95.463)-(-91.917)-(78.473)-(-58.691)-(99.895));
tcb->m_cWnd = (int) (44.659-(-43.037)-(30.342)-(59.265)-(17.577)-(-86.111));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
