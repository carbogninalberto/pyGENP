ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-21.768-(-33.081)-(-36.989)-(-33.447)-(-99.178)-(-35.4));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-0.995-(-47.241)-(84.079)-(-94.642)-(-49.316)-(86.072));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
