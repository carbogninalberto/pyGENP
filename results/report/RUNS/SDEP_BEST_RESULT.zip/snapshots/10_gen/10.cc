ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-97.828-(-3.726)-(30.825)-(-13.295)-(13.742)-(-7.738));
tcb->m_cWnd = (int) (25.214-(-15.217)-(-0.975)-(-47.319)-(0.513)-(-39.095));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
