ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-43.913-(-41.097)-(-84.978)-(-2.704)-(36.909)-(-27.963));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
