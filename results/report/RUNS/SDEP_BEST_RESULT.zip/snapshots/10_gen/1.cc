ReduceCwnd (tcb);
tcb->m_cWnd = (int) (32.766-(-83.585)-(-69.136)-(57.606)-(-28.805)-(11.71));
CongestionAvoidance (tcb, segmentsAcked);
