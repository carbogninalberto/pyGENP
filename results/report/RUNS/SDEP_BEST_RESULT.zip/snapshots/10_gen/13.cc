ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-0.552-(-75.291)-(-5.386)-(-19.168)-(-81.033)-(71.88));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (11.901-(-68.86)-(8.948)-(-25.517)-(42.234)-(-66.254));
CongestionAvoidance (tcb, segmentsAcked);
