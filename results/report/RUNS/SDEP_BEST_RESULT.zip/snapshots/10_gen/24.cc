ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (53.169-(-85.418)-(74.628)-(77.598)-(58.778)-(7.022));
tcb->m_cWnd = (int) (21.752-(31.474)-(-83.271)-(-67.324)-(24.102)-(-9.678));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
