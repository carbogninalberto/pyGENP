ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-48.162-(-54.047)-(-24.228)-(-56.665)-(-43.901)-(69.349));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (22.019-(-8.24)-(6.736)-(-96.211)-(-82.741)-(-24.303));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
