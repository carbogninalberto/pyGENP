ReduceCwnd (tcb);
tcb->m_cWnd = (int) (12.874-(2.006)-(64.036)-(-31.26)-(18.923)-(41.123));
tcb->m_cWnd = (int) (-91.984-(71.679)-(-73.103)-(-8.907)-(-8.181)-(29.392));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
