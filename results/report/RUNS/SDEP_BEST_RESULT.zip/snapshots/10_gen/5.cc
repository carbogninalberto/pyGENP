ReduceCwnd (tcb);
tcb->m_cWnd = (int) (79.265-(-85.571)-(76.945)-(47.652)-(-38.805)-(-96.299));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-62.696-(64.239)-(77.513)-(-47.334)-(-25.426)-(96.784));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
