ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-79.676-(80.422)-(-84.144)-(-48.924)-(56.081)-(85.204));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
