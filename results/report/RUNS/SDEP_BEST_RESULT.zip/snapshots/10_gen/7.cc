ReduceCwnd (tcb);
tcb->m_cWnd = (int) (25.498-(-47.189)-(-15.479)-(21.448)-(-33.801)-(-31.131));
tcb->m_cWnd = (int) (33.463-(-2.972)-(70.744)-(86.338)-(-48.135)-(-64.938));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
