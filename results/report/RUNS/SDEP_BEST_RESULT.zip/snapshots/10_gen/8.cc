ReduceCwnd (tcb);
tcb->m_cWnd = (int) (64.389-(5.496)-(42.315)-(-18.556)-(29.032)-(-31.85));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
