ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-79.435-(98.06)-(23.587)-(-52.029)-(-76.547)-(50.314));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (92.336-(3.563)-(3.868)-(57.525)-(-94.396)-(-97.609));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
