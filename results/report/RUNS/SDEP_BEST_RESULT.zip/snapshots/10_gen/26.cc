ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-98.971-(20.184)-(-3.647)-(-51.094)-(-9.952)-(-33.656));
tcb->m_cWnd = (int) (-4.183-(-31.649)-(-42.536)-(51.672)-(98.148)-(-1.639));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
