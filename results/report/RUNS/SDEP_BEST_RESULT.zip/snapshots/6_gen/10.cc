if (tcb->m_segmentSize <= tcb->m_cWnd) {
	segmentsAcked = (int) (8.605+(51.31)+(tcb->m_cWnd)+(98.653)+(tcb->m_segmentSize)+(69.336));
	segmentsAcked = (int) (31.462-(41.493)-(32.894)-(91.898)-(54.996)-(66.286)-(tcb->m_cWnd)-(5.483)-(segmentsAcked));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (74.657*(72.999)*(-67.459));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (32.312+(33.821)+(-1.693)+(65.528)+(26.72));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((10.315+(97.925)))+(25.835)+((38.989+(tcb->m_cWnd)+(99.422)+(44.158)+(41.406)+(33.721)+(36.034)+(75.028)))+(0.1))/((0.1)+(0.1)+(0.1)));

} else {
	segmentsAcked = (int) (65.456+(13.511)+(2.547)+(44.859)+(tcb->m_cWnd)+(22.489)+(11.77)+(86.324)+(56.006));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (65.456+(13.511)+(2.547)+(44.859)+(tcb->m_cWnd)+(22.489)+(11.77)+(86.324)+(56.006));

} else {
	segmentsAcked = (int) ((((10.315+(97.925)))+(25.835)+((38.989+(tcb->m_cWnd)+(99.422)+(44.158)+(41.406)+(33.721)+(36.034)+(75.028)))+(0.1))/((0.1)+(0.1)+(0.1)));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
