ReduceCwnd (tcb);
tcb->m_cWnd = (int) (99.774-(-36.201)-(99.465)-(-72.484)-(-19.433)-(-23.905));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (41.141-(4.697)-(-34.873)-(53.283)-(-19.628)-(98.481));
CongestionAvoidance (tcb, segmentsAcked);
