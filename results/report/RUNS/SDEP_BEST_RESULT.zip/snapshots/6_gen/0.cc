ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-18.463-(54.116)-(39.703)-(-8.117)-(-31.072)-(-34.722));
CongestionAvoidance (tcb, segmentsAcked);
