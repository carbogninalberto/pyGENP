ReduceCwnd (tcb);
tcb->m_cWnd = (int) (1.107-(-40.518)-(89.087)-(40.82)-(-79.294)-(44.062));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (60.528-(-58.722)-(-38.87)-(-49.669)-(81.708)-(7.704));
tcb->m_cWnd = (int) (-59.224-(-59.248)-(46.48)-(71.308)-(-10.73)-(-30.717));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
