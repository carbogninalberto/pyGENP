ReduceCwnd (tcb);
tcb->m_cWnd = (int) (8.412-(-52.558)-(-94.021)-(-79.47)-(-98.339)-(-8.11));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-47.919-(-76.712)-(-44.863)-(53.042)-(-81.035)-(-88.25));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
