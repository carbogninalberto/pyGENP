ReduceCwnd (tcb);
tcb->m_cWnd = (int) (14.111-(21.297)-(-83.753)-(-43.937)-(-64.782)-(82.586));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
