ReduceCwnd (tcb);
tcb->m_cWnd = (int) (86.157-(98.716)-(-71.67)-(-61.212)-(-79.609)-(-26.698));
tcb->m_cWnd = (int) (69.862-(53.91)-(-28.257)-(-67.236)-(-90.248)-(96.107));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
