ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-6.232-(74.802)-(-42.826)-(97.559)-(39.04)-(47.185));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-67.829-(37.909)-(-93.932)-(-70.507)-(57.813)-(-37.164));
CongestionAvoidance (tcb, segmentsAcked);
