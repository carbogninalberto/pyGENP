ReduceCwnd (tcb);
tcb->m_cWnd = (int) (15.95-(-38.728)-(-25.016)-(0.666)-(-33.208)-(-93.094));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-56.335-(65.835)-(44.968)-(-87.681)-(42.444)-(-64.308));
CongestionAvoidance (tcb, segmentsAcked);
