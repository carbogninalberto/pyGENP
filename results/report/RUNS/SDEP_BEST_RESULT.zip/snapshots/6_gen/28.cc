if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((10.315+(97.925)))+(25.835)+((38.989+(tcb->m_cWnd)+(99.422)+(44.158)+(41.406)+(33.721)+(36.034)+(75.028)))+(0.1))/((0.1)+(0.1)+(0.1)));

} else {
	segmentsAcked = (int) (65.456+(13.511)+(2.547)+(44.859)+(tcb->m_cWnd)+(22.489)+(11.77)+(86.324)+(56.006));

}
float HCBDTWiYnHAiYPiL = (float) (14.228+(-99.653)+(-95.262)+(71.284));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (65.456+(13.511)+(2.547)+(44.859)+(tcb->m_cWnd)+(22.489)+(11.77)+(86.324)+(56.006));

} else {
	segmentsAcked = (int) ((((10.315+(97.925)))+(25.835)+((38.989+(tcb->m_cWnd)+(99.422)+(44.158)+(41.406)+(33.721)+(36.034)+(75.028)))+(0.1))/((0.1)+(0.1)+(0.1)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
