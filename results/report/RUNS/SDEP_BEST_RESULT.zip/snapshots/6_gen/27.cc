ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-64.899-(-92.746)-(-61.65)-(-17.04)-(-18.397)-(24.31));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-83.506-(-41.73)-(-34.889)-(1.264)-(81.466)-(-98.522));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-58.636-(66.097)-(-46.885)-(36.539)-(-57.38)-(85.168));
CongestionAvoidance (tcb, segmentsAcked);
