ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (16.449-(-2.57)-(6.898)-(75.385)-(-99.957)-(-19.095));
tcb->m_cWnd = (int) (9.167-(-60.533)-(40.914)-(39.039)-(-91.417)-(-70.977));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
