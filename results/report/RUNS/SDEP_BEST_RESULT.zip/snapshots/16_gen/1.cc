ReduceCwnd (tcb);
tcb->m_cWnd = (int) (8.469-(1.271)-(-99.864)-(74.148)-(74.324)-(87.7));
tcb->m_cWnd = (int) (74.604-(68.802)-(17.267)-(12.526)-(21.919)-(-50.671));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
