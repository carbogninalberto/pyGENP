CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (((14.13)+((tcb->m_cWnd+(41.322)+(42.961)+(75.422)+(tcb->m_ssThresh)+(97.86)+(95.026)+(33.29)))+((tcb->m_segmentSize+(26.32)+(55.303)+(84.692)))+((73.782*(29.19)*(tcb->m_segmentSize)*(52.631)))+(0.1))/((0.1)+(17.609)));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(68.584)*(79.274)*(tcb->m_segmentSize)*(60.905)*(tcb->m_segmentSize)*(93.978)*(55.019));
	tcb->m_segmentSize = (int) (88.87-(tcb->m_cWnd)-(34.235)-(segmentsAcked)-(36.205)-(89.71));

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
