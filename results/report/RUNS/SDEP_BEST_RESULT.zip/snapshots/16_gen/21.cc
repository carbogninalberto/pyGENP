ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (70.599+(7.311)+(38.638)+(segmentsAcked)+(30.964)+(77.828)+(65.948));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (93.827+(86.44)+(2.714)+(11.297));

}
tcb->m_cWnd = (int) (29.532-(45.298)-(55.295)-(65.754)-(51.649)-(segmentsAcked));
tcb->m_segmentSize = (int) (39.406*(segmentsAcked)*(86.005)*(5.642)*(62.599)*(62.479)*(73.839));
