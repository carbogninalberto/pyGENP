float xJAeVXxqaUpOuwSk = (float) (63.673-(segmentsAcked)-(71.006)-(tcb->m_segmentSize)-(90.928));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked <= segmentsAcked) {
	tcb->m_cWnd = (int) (40.56+(79.9)+(tcb->m_segmentSize)+(36.609)+(15.634)+(58.704));

} else {
	tcb->m_cWnd = (int) (((0.1)+(76.592)+(0.1)+(92.786)+(27.589))/((32.274)+(0.1)+(56.477)));
	tcb->m_cWnd = (int) (78.171-(60.453)-(46.712)-(26.441)-(38.064)-(85.276)-(segmentsAcked)-(91.711));

}
if (segmentsAcked <= segmentsAcked) {
	tcb->m_ssThresh = (int) (6.4+(tcb->m_cWnd)+(tcb->m_ssThresh)+(6.77));

} else {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+((81.033+(69.367)+(52.255)+(xJAeVXxqaUpOuwSk)+(31.313)+(70.954)+(6.526)))+(0.1)+(0.1)+(96.267)+(26.352))/((0.1)));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(segmentsAcked)*(44.018)*(3.025)*(5.421)*(17.011)*(23.612));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
