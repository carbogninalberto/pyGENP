tcb->m_ssThresh = (int) (7.099*(tcb->m_cWnd)*(3.546));
tcb->m_segmentSize = (int) (89.721-(49.787)-(41.484)-(38.956));
float gWPavSZtSMFeXoIU = (float) ((((63.02*(41.555)))+(0.1)+(0.1)+(0.1)+(68.275)+(0.1)+(67.457)+(78.741))/((1.963)));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	segmentsAcked = (int) (92.244/52.755);
	tcb->m_cWnd = (int) (((0.1)+(38.896)+(68.438)+(33.913))/((0.1)));
	tcb->m_ssThresh = (int) (93.145+(69.354));

} else {
	segmentsAcked = (int) (81.795*(segmentsAcked));
	tcb->m_segmentSize = (int) (36.11*(90.679));

}
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (segmentsAcked+(6.626)+(71.628));
	gWPavSZtSMFeXoIU = (float) (55.037-(tcb->m_ssThresh)-(74.58)-(34.833)-(66.575)-(23.266)-(21.841)-(49.1));
	segmentsAcked = (int) (8.329-(13.551)-(60.447)-(81.701)-(gWPavSZtSMFeXoIU)-(60.242)-(41.39)-(42.495));

} else {
	tcb->m_segmentSize = (int) (gWPavSZtSMFeXoIU-(87.402)-(27.048)-(tcb->m_segmentSize));
	segmentsAcked = (int) (53.087+(19.736)+(67.694)+(tcb->m_segmentSize)+(38.528)+(93.925));

}
tcb->m_cWnd = (int) (tcb->m_segmentSize-(72.692)-(9.404)-(59.802));
