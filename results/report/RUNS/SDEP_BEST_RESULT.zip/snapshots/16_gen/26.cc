ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (44.216+(14.203));

} else {
	tcb->m_cWnd = (int) (88.911/83.721);
	segmentsAcked = (int) (78.201*(37.289)*(48.453)*(74.348)*(46.864));

}
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) ((14.597-(tcb->m_ssThresh)-(tcb->m_cWnd)-(18.205)-(7.947)-(44.657)-(28.4)-(93.834)-(segmentsAcked))/(71.76+(32.881)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (83.71+(15.327)+(tcb->m_cWnd)+(segmentsAcked)+(segmentsAcked)+(45.771)+(80.147));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((((73.901*(27.161)*(12.779)*(5.481)*(40.469)))+(67.215)+(0.1)+(0.1)+(0.1))/((56.622)+(0.1)+(97.064)+(86.344)));
