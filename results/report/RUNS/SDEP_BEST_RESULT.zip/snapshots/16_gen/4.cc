int poqRTGIbWrNsTFdq = (int) (-20.103-(99.407)-(23.251));
float pqRxFVkyCGktjZXA = (float) (-94.006+(-76.152)+(-42.085)+(-85.224));
tcb->m_cWnd = (int) (72.34*(-74.79));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-79.68*(-36.094)*(-35.42)*(-32.855)*(96.126));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
