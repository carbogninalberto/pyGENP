tcb->m_segmentSize = (int) (45.079+(tcb->m_segmentSize)+(57.356)+(39.496)+(56.448)+(52.794)+(69.774)+(86.331));
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) ((((67.264-(56.724)))+(0.1)+(0.1)+((38.381-(66.458)-(89.255)-(14.128)))+(0.1))/((0.1)));

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (0.1/0.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (90.675-(19.432)-(segmentsAcked)-(94.275)-(70.778)-(14.718)-(37.866)-(2.916)-(19.906));
segmentsAcked = (int) (0.1/0.1);
segmentsAcked = (int) (74.913*(25.322));
