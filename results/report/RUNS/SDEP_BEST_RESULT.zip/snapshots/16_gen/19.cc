ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (51.259-(0.336)-(85.139)-(86.08)-(83.614)-(41.303));
float unWRawGNkBjjoqQu = (float) (34.156+(tcb->m_segmentSize)+(65.564)+(tcb->m_segmentSize)+(35.496)+(tcb->m_segmentSize)+(48.068));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (0.1/0.1);
