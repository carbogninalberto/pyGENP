ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-32.485-(-44.438)-(-65.686)-(-43.216)-(39.347)-(36.432));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-56.784-(36.601)-(-40.974)-(17.912)-(-25.975)-(-82.057));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
