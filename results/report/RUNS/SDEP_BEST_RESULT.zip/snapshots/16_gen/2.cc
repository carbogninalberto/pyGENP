float vbmUbIOLgmhpfsRH = (float) (-48.629+(19.146)+(95.733)+(-2.858)+(-50.965)+(96.006)+(10.859)+(-42.094));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (94.523+(tcb->m_segmentSize)+(90.7)+(12.857)+(85.321)+(-9.246)+(16.222)+(38.203));
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(78.486)-(89.254)-(75.456));

} else {
	tcb->m_segmentSize = (int) (16.116*(84.87)*(22.009)*(7.145)*(98.885));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
