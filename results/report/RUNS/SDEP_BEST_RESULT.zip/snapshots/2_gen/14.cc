if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (80.461+(73.015)+(92.34)+(50.066)+(26.178)+(97.697)+(98.101)+(57.938));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (99.427-(24.499)-(42.792)-(tcb->m_segmentSize)-(5.332)-(26.477));

}
