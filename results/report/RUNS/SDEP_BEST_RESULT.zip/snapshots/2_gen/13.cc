float ikrgsavKrCHuKSzv = (float) 41.469;
ikrgsavKrCHuKSzv = (float) (55.47*(48.745));
