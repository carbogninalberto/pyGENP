int htbxPdOnJELnVLhB = (int) (-21.747*(-12.599));
float xnIeFTbpMteeRalB = (float) (6.334+(-7.86)+(27.211)+(-70.566)+(-2.403)+(47.014)+(11.521)+(-16.529)+(13.262));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (75.231+(97.826)+(tcb->m_segmentSize)+(-55.11)+(72.237)+(43.613)+(7.523));

} else {
	tcb->m_cWnd = (int) (1.378/90.65);
	htbxPdOnJELnVLhB = (int) (0.1/(99.312*(xnIeFTbpMteeRalB)*(97.005)*(53.818)*(tcb->m_segmentSize)));

}
tcb->m_cWnd = (int) (-15.398-(-99.729)-(60.194)-(-19.962)-(-81.938)-(60.641)-(-59.019)-(-44.566)-(-51.85));
