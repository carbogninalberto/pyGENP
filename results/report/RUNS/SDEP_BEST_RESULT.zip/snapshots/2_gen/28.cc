tcb->m_cWnd = (int) (-91.552/48.789);
segmentsAcked = (int) (-20.677/82.739);
tcb->m_cWnd = (int) (-84.609/2.104);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-54.164/-30.56);
CongestionAvoidance (tcb, segmentsAcked);
