tcb->m_cWnd = (int) (0.222/25.961);
