int iOHcLZrofxbblFoV = (int) (-93.558+(48.061)+(-75.368)+(34.386));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
