float cLHZXlfaXtFALXRX = (float) (60.423-(-69.247)-(82.525)-(10.211)-(-76.366)-(53.574)-(19.624)-(61.098));
tcb->m_segmentSize = (int) (-0.128*(1.054)*(-61.826)*(-67.695));
tcb->m_cWnd = (int) (-64.923-(-68.108)-(-83.11)-(25.587)-(77.161)-(-28.305)-(-67.114));
segmentsAcked = SlowStart (tcb, segmentsAcked);
