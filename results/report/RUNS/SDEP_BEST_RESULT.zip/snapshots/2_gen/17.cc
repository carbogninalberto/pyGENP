float cLHZXlfaXtFALXRX = (float) (40.266-(-8.195)-(10.302)-(12.006)-(-43.616)-(67.893)-(86.829)-(-90.087));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (40.984*(23.24)*(63.205)*(65.527));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (0.1/86.453);
	segmentsAcked = (int) (21.269-(27.675)-(28.065)-(91.675)-(segmentsAcked));

}
tcb->m_cWnd = (int) (91.598-(18.385)-(25.057)-(39.193)-(-4.623)-(-79.471)-(6.667));
segmentsAcked = SlowStart (tcb, segmentsAcked);
