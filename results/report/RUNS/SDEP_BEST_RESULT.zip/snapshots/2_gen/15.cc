float XkXWQMqEPdQFFccz = (float) 67.493;
tcb->m_segmentSize = (int) (90.143*(78.133)*(-95.432));
segmentsAcked = (int) (((44.15)+(6.259)+(-60.245)+(-40.691))/((22.268)+(53.892)+(-80.451)+(-2.504)+(-44.249)));
XkXWQMqEPdQFFccz = (float) ((78.216-(2.036)-(segmentsAcked)-(segmentsAcked))/-35.511);
