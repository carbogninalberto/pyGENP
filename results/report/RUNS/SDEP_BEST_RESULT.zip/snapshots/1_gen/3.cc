tcb->m_ssThresh = (int) (tcb->m_segmentSize*(16.326)*(26.963)*(57.307));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((((7.323*(73.464)*(tcb->m_segmentSize)*(22.593)*(tcb->m_ssThresh)*(28.166)*(71.238)))+((67.075+(44.651)))+(32.315)+(69.987)+(0.1))/((41.989)));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(69.669))/((0.1)));
	tcb->m_ssThresh = (int) (77.398*(68.582)*(37.163)*(1.251));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (98.878*(74.99)*(14.449)*(84.29)*(72.767)*(40.937)*(19.743)*(55.951)*(93.688));
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (54.96+(77.956)+(16.42));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (99.421-(46.439)-(34.995)-(1.372)-(78.041)-(20.858)-(18.54));

}
