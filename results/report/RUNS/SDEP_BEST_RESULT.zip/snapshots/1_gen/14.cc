ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (7.042/0.1);
	tcb->m_ssThresh = (int) (54.408+(66.184)+(50.555));

} else {
	tcb->m_ssThresh = (int) (11.283*(42.378)*(83.386)*(79.669)*(54.31)*(87.351)*(62.562)*(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (87.481*(92.615));

}
tcb->m_cWnd = (int) (0.1/0.1);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (75.769+(77.857)+(36.645)+(89.111)+(99.65));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (46.248+(95.765));

} else {
	tcb->m_ssThresh = (int) (70.134-(13.329)-(39.735)-(tcb->m_ssThresh)-(tcb->m_ssThresh));
	segmentsAcked = (int) (36.902-(2.969)-(segmentsAcked)-(3.805));
	tcb->m_cWnd = (int) (40.137-(segmentsAcked)-(segmentsAcked)-(62.659)-(45.087)-(8.56)-(85.797)-(79.92));

}
segmentsAcked = (int) (0.1/0.1);
tcb->m_cWnd = (int) (19.503/0.1);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (35.717+(58.815)+(segmentsAcked)+(36.692)+(40.049)+(81.561)+(94.845)+(47.749));
	tcb->m_ssThresh = (int) (93.42-(84.258)-(42.954)-(30.281)-(87.677)-(72.06)-(29.501)-(46.189));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
