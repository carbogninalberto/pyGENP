segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (segmentsAcked-(5.773)-(28.603)-(72.555)-(45.198)-(56.356));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (78.647+(tcb->m_segmentSize)+(96.335)+(38.226)+(tcb->m_ssThresh)+(52.905)+(96.268)+(96.862)+(51.756));
