tcb->m_cWnd = (int) ((((29.165+(39.407)))+(0.1)+(0.1)+(0.1)+(0.1)+(0.1)+(86.921))/((9.11)+(0.1)));
tcb->m_ssThresh = (int) (((0.1)+((87.937+(19.745)+(74.1)))+(92.16)+(0.1)+(0.1))/((0.1)+(33.671)+(0.1)+(60.621)));
if (segmentsAcked == tcb->m_segmentSize) {
	segmentsAcked = (int) (72.439+(37.78)+(2.476)+(72.703));

} else {
	segmentsAcked = (int) (91.256-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(37.83)-(39.919)-(95.202)-(30.805));
	segmentsAcked = (int) (96.178-(96.365)-(85.239)-(82.291)-(84.122)-(24.442)-(74.153)-(85.626)-(58.153));
	tcb->m_cWnd = (int) (0.1/39.576);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
