ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (64.3*(55.418));
tcb->m_ssThresh = (int) (84.759/0.1);
tcb->m_segmentSize = (int) (14.783*(tcb->m_segmentSize)*(4.254));
tcb->m_ssThresh = (int) (40.137*(97.061)*(23.099)*(38.863)*(65.496)*(1.719)*(58.374)*(12.265)*(tcb->m_cWnd));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (22.377*(66.897)*(95.681)*(62.638));
	tcb->m_ssThresh = (int) (81.242*(tcb->m_ssThresh)*(48.05)*(tcb->m_cWnd)*(tcb->m_cWnd)*(segmentsAcked)*(13.203));
	segmentsAcked = (int) (85.62+(tcb->m_cWnd)+(72.268)+(40.491));

} else {
	tcb->m_ssThresh = (int) (1.522-(69.211)-(87.303)-(18.01)-(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (64.427/0.1);
	tcb->m_cWnd = (int) (46.859+(27.985)+(38.133)+(48.057)+(tcb->m_segmentSize));

}
tcb->m_ssThresh = (int) (segmentsAcked+(23.876)+(43.706)+(90.01)+(46.616)+(16.265)+(88.695)+(tcb->m_segmentSize)+(27.675));
ReduceCwnd (tcb);
