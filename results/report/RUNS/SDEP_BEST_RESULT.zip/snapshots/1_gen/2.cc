CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (59.499-(43.445)-(tcb->m_segmentSize)-(2.081)-(25.249)-(tcb->m_cWnd));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked >= segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(1.332)+(tcb->m_cWnd)+(46.882)+(tcb->m_cWnd)+(22.915)+(48.895)+(segmentsAcked)+(19.379));

} else {
	tcb->m_ssThresh = (int) (22.23-(33.684)-(85.388)-(26.673)-(93.289)-(43.795)-(93.018)-(95.702)-(79.419));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (((38.971)+(3.888)+(69.128)+((27.169-(21.182)-(59.327)-(76.334)-(89.89)-(12.904)))+(0.1)+(28.351))/((14.604)+(0.1)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
