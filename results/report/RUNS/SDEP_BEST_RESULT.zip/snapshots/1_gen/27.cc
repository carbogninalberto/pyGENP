segmentsAcked = (int) ((21.9*(43.6)*(48.85)*(19.35)*(39.326))/57.941);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (12.658+(28.405));
	segmentsAcked = (int) (tcb->m_cWnd*(21.775)*(94.924)*(56.632)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(61.446)*(85.321));
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(58.596))/((15.743)+(55.409)+(69.694)+(7.093)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (64.978+(21.833)+(26.45)+(tcb->m_ssThresh)+(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (0.1/75.212);

}
ReduceCwnd (tcb);
