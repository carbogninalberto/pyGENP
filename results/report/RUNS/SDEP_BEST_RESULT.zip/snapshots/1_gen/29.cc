tcb->m_cWnd = (int) (tcb->m_ssThresh-(94.338)-(41.924));
tcb->m_cWnd = (int) (0.1/0.1);
tcb->m_segmentSize = (int) (tcb->m_cWnd+(34.338)+(83.541)+(67.42)+(18.063)+(55.145)+(13.306));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (29.973*(43.185)*(16.695)*(1.053)*(37.646)*(40.647)*(52.885));

} else {
	tcb->m_cWnd = (int) (87.095-(84.042)-(73.989)-(91.099)-(6.435)-(98.633)-(10.305)-(20.716));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(4.117)+(14.261)+(tcb->m_segmentSize)+(tcb->m_cWnd));

}
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (10.667*(0.56)*(64.363)*(53.366)*(tcb->m_cWnd)*(segmentsAcked));
	tcb->m_ssThresh = (int) (99.272/35.315);
	tcb->m_cWnd = (int) (13.177+(46.975)+(tcb->m_ssThresh)+(segmentsAcked)+(37.87)+(39.662)+(54.839)+(19.7));

} else {
	tcb->m_ssThresh = (int) (78.76+(13.133)+(tcb->m_ssThresh)+(65.777)+(26.316)+(tcb->m_segmentSize)+(14.52)+(tcb->m_segmentSize)+(74.262));
	tcb->m_ssThresh = (int) (42.736-(19.8)-(42.993)-(57.537)-(10.899));
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(6.142)+(97.152)+(37.582)+(72.961)+(45.652)+(tcb->m_segmentSize)+(84.908)+(segmentsAcked));

}
segmentsAcked = (int) (segmentsAcked-(91.732)-(5.111)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(tcb->m_cWnd)-(segmentsAcked)-(tcb->m_cWnd)-(92.995));
