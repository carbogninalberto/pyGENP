tcb->m_ssThresh = (int) (((10.938)+(0.1)+(0.1)+(90.757)+((tcb->m_segmentSize+(60.204)+(53.845)+(84.197)+(37.813)+(8.952)+(96.252)+(tcb->m_segmentSize)))+(0.1)+(17.689)+(0.1))/((71.835)));
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (38.748+(57.463));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(47.523)*(99.398)*(52.189)*(57.731)*(25.714));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(17.298)-(63.856)-(44.05));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(67.739)*(60.394)*(tcb->m_cWnd)*(tcb->m_cWnd));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(33.234));
	tcb->m_cWnd = (int) (segmentsAcked-(tcb->m_segmentSize)-(27.161)-(86.96)-(25.577));

} else {
	tcb->m_ssThresh = (int) (37.911-(81.611)-(58.561)-(96.598)-(76.021)-(93.55)-(4.419));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
