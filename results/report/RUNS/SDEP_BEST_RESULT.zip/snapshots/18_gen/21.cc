if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+(61.664)+(12.528)+(98.82))/((99.6)+(0.1)+(43.329)+(71.664)+(0.1)));
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(98.543)-(60.884)-(8.988)-(tcb->m_cWnd)-(69.794)-(79.96)-(91.279)-(15.906));

} else {
	tcb->m_segmentSize = (int) ((49.836*(51.341)*(96.504)*(26.054)*(64.446)*(tcb->m_segmentSize)*(92.892))/(6.334+(38.672)));
	tcb->m_ssThresh = (int) (69.252-(50.04)-(tcb->m_segmentSize)-(23.608)-(tcb->m_segmentSize)-(32.767)-(64.55)-(57.981)-(14.545));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_segmentSize = (int) (96.685*(20.374)*(90.693)*(tcb->m_cWnd)*(24.363)*(80.591)*(57.03)*(62.056)*(22.717));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (67.282+(tcb->m_ssThresh)+(8.051)+(96.896)+(tcb->m_cWnd));
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(44.711)+(tcb->m_cWnd)+(92.221)+(48.727)+(55.968)+(79.554));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(9.711)+(segmentsAcked)+(segmentsAcked)+(95.435)+(79.29));
segmentsAcked = (int) (33.751+(85.91)+(36.545));
tcb->m_ssThresh = (int) (5.762+(34.637)+(55.15)+(39.967)+(68.305)+(99.164)+(38.056));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_ssThresh) {
	segmentsAcked = (int) (86.384*(tcb->m_ssThresh)*(36.116)*(96.402)*(81.655)*(9.137)*(16.804));

} else {
	segmentsAcked = (int) (70.436+(67.321)+(21.543)+(63.73)+(39.73)+(41.082)+(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (42.437*(tcb->m_ssThresh));

}
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (75.383-(tcb->m_segmentSize)-(75.567)-(35.548)-(2.628));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (80.639+(38.029)+(3.358));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (4.002+(58.935)+(63.125)+(tcb->m_cWnd)+(4.244)+(99.206));

}
