ReduceCwnd (tcb);
tcb->m_cWnd = (int) (12.973-(41.594)-(-53.427)-(96.854)-(47.499)-(19.561));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (97.097-(-84.458)-(-19.146)-(-94.906)-(52.664)-(-8.0));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
