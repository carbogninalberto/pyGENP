tcb->m_cWnd = (int) (tcb->m_cWnd+(13.819)+(94.324)+(tcb->m_segmentSize)+(75.549)+(8.962)+(tcb->m_ssThresh)+(2.87)+(12.758));
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_cWnd = (int) (0.1/0.1);
	segmentsAcked = (int) (segmentsAcked+(63.684)+(84.705)+(19.508)+(14.787)+(tcb->m_cWnd)+(38.407)+(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (97.541-(74.348)-(tcb->m_cWnd)-(17.986)-(tcb->m_segmentSize)-(19.345)-(11.486));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (27.439+(22.778)+(4.497)+(tcb->m_ssThresh)+(25.807));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (14.824/(11.362*(1.876)*(36.223)));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (68.749+(77.485)+(91.716)+(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (55.226+(93.449));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (49.303-(69.205)-(35.559)-(55.742)-(61.166));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
