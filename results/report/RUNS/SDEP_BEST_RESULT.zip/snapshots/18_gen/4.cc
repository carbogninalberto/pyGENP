float QhuHcKafFDITyXYr = (float) 74.204;
segmentsAcked = (int) (-47.337+(-27.383)+(-27.493)+(10.349)+(7.955)+(58.087)+(-50.584));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-61.002-(-56.204)-(-97.524)-(55.56)-(86.561)-(22.5));
ReduceCwnd (tcb);
