float OrzfqKSUJiTMGrfH = (float) (62.501*(-27.789)*(73.323)*(-63.284)*(66.371)*(-72.912));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (OrzfqKSUJiTMGrfH <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(31.39)-(tcb->m_segmentSize)-(22.584)-(62.436)-(53.66));
	segmentsAcked = (int) (3.66+(85.177));
	tcb->m_segmentSize = (int) (45.537*(1.221)*(48.602)*(29.089)*(42.419)*(segmentsAcked)*(3.342));

} else {
	tcb->m_cWnd = (int) (23.02+(OrzfqKSUJiTMGrfH)+(11.798)+(2.451)+(27.229)+(98.452)+(81.985)+(53.725));

}
