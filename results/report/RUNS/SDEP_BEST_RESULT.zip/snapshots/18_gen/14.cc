segmentsAcked = (int) (0.1/62.279);
if (segmentsAcked >= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(60.903)-(15.411));
	segmentsAcked = (int) (63.07+(37.258)+(tcb->m_segmentSize)+(segmentsAcked)+(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (26.347+(8.505)+(35.825)+(segmentsAcked));

}
segmentsAcked = (int) (49.239+(33.893)+(52.151)+(49.26)+(90.66));
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (14.708*(67.044)*(35.502)*(85.796)*(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (0.1/71.772);
	tcb->m_segmentSize = (int) (((56.108)+(0.1)+(0.1)+((tcb->m_ssThresh+(52.148)+(95.344)))+(0.1))/((0.1)+(19.769)+(97.065)+(18.887)));

}
ReduceCwnd (tcb);
