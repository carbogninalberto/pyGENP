ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(segmentsAcked)*(26.241)*(tcb->m_ssThresh)*(97.972));
	tcb->m_cWnd = (int) (48.843+(tcb->m_cWnd)+(43.444)+(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (0.1/59.786);
	tcb->m_segmentSize = (int) (0.1/0.1);

}
tcb->m_ssThresh = (int) (98.147+(31.63)+(88.517)+(60.407)+(6.129)+(92.793)+(34.792));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (((49.616)+((tcb->m_ssThresh*(68.109)*(2.066)*(93.166)*(17.652)*(58.039)*(tcb->m_cWnd)))+(57.213)+(0.1)+(0.1))/((5.746)+(0.1)));
tcb->m_segmentSize = (int) (68.158+(tcb->m_segmentSize));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) ((95.974-(11.387)-(tcb->m_cWnd)-(83.673)-(segmentsAcked))/49.58);
