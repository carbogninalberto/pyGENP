ReduceCwnd (tcb);
tcb->m_cWnd = (int) (20.613-(50.205)-(58.499)-(22.629)-(84.648)-(-92.463));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (63.977-(71.0)-(16.402)-(72.712)-(60.893)-(82.459));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-44.212-(40.739)-(3.617)-(44.308)-(24.31)-(40.585));
CongestionAvoidance (tcb, segmentsAcked);
