ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-71.656-(81.59)-(81.59)-(22.415)-(-8.229)-(56.003));
tcb->m_cWnd = (int) (74.086-(-26.899)-(37.632)-(-55.775)-(-35.623)-(0.527));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
