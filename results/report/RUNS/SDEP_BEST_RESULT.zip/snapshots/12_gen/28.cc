ReduceCwnd (tcb);
float auYevtPiWLppwCYO = (float) (((61.975)+((tcb->m_ssThresh*(93.78)*(40.078)*(27.145)))+((0.348*(tcb->m_segmentSize)*(1.82)))+(34.767)+(0.1)+(0.1)+(0.1))/((76.078)));
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(59.076)-(21.478)-(49.975)-(40.434)-(98.928)-(67.08));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (auYevtPiWLppwCYO >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	auYevtPiWLppwCYO = (float) ((((63.095-(10.932)-(21.5)))+(0.1)+(44.77)+(0.1)+(0.1))/((94.287)));

} else {
	tcb->m_cWnd = (int) (2.873+(40.135)+(tcb->m_cWnd));
	segmentsAcked = (int) (6.653+(30.763)+(15.632));
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (31.039-(auYevtPiWLppwCYO)-(89.445)-(79.84)-(40.145)-(46.654)-(25.968)-(75.015));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (73.925-(22.698)-(9.755)-(61.746));
segmentsAcked = SlowStart (tcb, segmentsAcked);
