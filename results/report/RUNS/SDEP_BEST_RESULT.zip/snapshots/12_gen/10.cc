ReduceCwnd (tcb);
tcb->m_cWnd = (int) (17.741-(-29.124)-(35.443)-(4.638)-(79.157)-(69.244));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-20.371-(-88.501)-(89.053)-(7.0)-(41.859)-(-64.076));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-77.71-(-38.649)-(-29.261)-(-88.385)-(28.525)-(-87.783));
CongestionAvoidance (tcb, segmentsAcked);
