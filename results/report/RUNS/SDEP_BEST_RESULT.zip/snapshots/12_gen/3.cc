ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (36.541-(21.92)-(67.462)-(-84.128)-(29.509)-(-3.359));
tcb->m_cWnd = (int) (83.838-(60.161)-(90.1)-(94.147)-(-7.766)-(-60.597));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
