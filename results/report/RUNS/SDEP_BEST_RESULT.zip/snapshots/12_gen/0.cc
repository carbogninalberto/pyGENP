ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-22.552-(83.733)-(36.921)-(-13.536)-(89.749)-(41.798));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
