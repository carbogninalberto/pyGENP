ReduceCwnd (tcb);
tcb->m_cWnd = (int) (94.024-(-58.361)-(49.124)-(20.179)-(88.364)-(-94.222));
tcb->m_cWnd = (int) (-58.638-(51.245)-(-33.85)-(8.039)-(-2.835)-(76.732));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
