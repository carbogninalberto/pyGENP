ReduceCwnd (tcb);
tcb->m_cWnd = (int) (30.746-(-99.196)-(-3.287)-(55.683)-(-72.269)-(-28.449));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (28.221-(62.092)-(13.072)-(45.27)-(95.039)-(-56.93));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
