ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-27.588-(-11.058)-(87.98)-(51.526)-(-37.192)-(-65.535));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (14.483-(82.821)-(33.158)-(-17.995)-(45.247)-(-78.362));
CongestionAvoidance (tcb, segmentsAcked);
