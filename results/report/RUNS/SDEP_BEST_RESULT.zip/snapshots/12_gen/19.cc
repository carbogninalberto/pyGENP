ReduceCwnd (tcb);
tcb->m_cWnd = (int) (46.176-(-3.872)-(59.11)-(92.143)-(61.364)-(4.575));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-53.85-(-63.328)-(-61.728)-(9.973)-(-40.607)-(-31.757));
CongestionAvoidance (tcb, segmentsAcked);
