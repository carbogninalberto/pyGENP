ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-81.89-(-44.124)-(77.469)-(-98.701)-(-33.142)-(-53.852));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
