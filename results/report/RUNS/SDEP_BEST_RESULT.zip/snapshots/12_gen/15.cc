ReduceCwnd (tcb);
tcb->m_cWnd = (int) (47.064-(-75.415)-(49.65)-(29.889)-(33.836)-(25.109));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
