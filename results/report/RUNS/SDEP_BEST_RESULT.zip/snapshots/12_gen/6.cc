ReduceCwnd (tcb);
tcb->m_cWnd = (int) (6.859-(-60.764)-(3.074)-(-35.063)-(-45.824)-(38.866));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-45.108-(-80.942)-(71.781)-(-73.196)-(-77.769)-(-43.542));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
