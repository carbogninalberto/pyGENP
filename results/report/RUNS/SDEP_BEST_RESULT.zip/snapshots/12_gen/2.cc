ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-55.51-(35.431)-(52.706)-(81.312)-(32.076)-(5.616));
tcb->m_cWnd = (int) (11.987-(-95.289)-(75.232)-(-27.691)-(-73.794)-(94.278));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
