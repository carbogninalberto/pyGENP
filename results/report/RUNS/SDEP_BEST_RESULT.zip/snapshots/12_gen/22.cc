ReduceCwnd (tcb);
tcb->m_cWnd = (int) (78.169-(38.984)-(-25.696)-(42.624)-(-88.335)-(-11.654));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (3.812-(-26.183)-(97.964)-(92.151)-(70.226)-(-7.745));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
