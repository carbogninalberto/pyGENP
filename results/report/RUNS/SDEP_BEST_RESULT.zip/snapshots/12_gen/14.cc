ReduceCwnd (tcb);
tcb->m_cWnd = (int) (29.014-(28.008)-(27.421)-(-59.731)-(9.394)-(-10.294));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-12.248-(-11.068)-(-37.718)-(-47.136)-(-4.379)-(-73.4));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-39.567-(-13.68)-(-37.079)-(-31.221)-(-83.974)-(88.086));
CongestionAvoidance (tcb, segmentsAcked);
