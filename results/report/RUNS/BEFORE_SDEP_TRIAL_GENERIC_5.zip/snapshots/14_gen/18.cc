if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-5+(1));
tcb->m_cWnd = (int) (-4+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-10+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-9+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (13-(-13)-(-14));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-14-(5)-(9));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (15-(-3)-(4));
segmentsAcked = (int) (-3-(-13)-(17));
tcb->m_cWnd = (int) (-15+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (-3+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (4-(-1)-(7));
segmentsAcked = (int) (-8-(15)-(-13));
segmentsAcked = (int) (16-(-5)-(18));
segmentsAcked = (int) (6-(-17)-(5));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (9-(2)-(2));
segmentsAcked = (int) (-9-(1)-(12));
segmentsAcked = (int) (16-(19)-(-4));
segmentsAcked = (int) (-4-(-9)-(17));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-12-(-5)-(19));
segmentsAcked = (int) (7-(-13)-(-2));
segmentsAcked = (int) (-10-(14)-(-5));
segmentsAcked = (int) (-14-(-17)-(-4));
segmentsAcked = (int) (-5-(-18)-(10));
segmentsAcked = (int) (-3-(10)-(18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-8-(-5)-(9));
segmentsAcked = (int) (-19-(3)-(-2));
