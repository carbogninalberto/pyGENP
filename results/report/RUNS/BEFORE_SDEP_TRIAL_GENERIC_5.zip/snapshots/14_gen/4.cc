segmentsAcked = (int) (-12/-1);
tcb->m_cWnd = (int) (tcb->m_segmentSize+(-11)+(-15));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((14.69-(15.02)-(3.35)-(6.06))/18.43);
	tcb->m_segmentSize = (int) (8.25*(6.83));
	tcb->m_cWnd = (int) (13.1+(10.07)+(5.34));

} else {
	tcb->m_segmentSize = (int) (15.75*(11.17)*(segmentsAcked)*(10.62));

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
tcb->m_cWnd = (int) (17-(-11)-(tcb->m_segmentSize)-(4));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
tcb->m_cWnd = (int) (segmentsAcked*(7)*(-11)*(segmentsAcked));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_segmentSize+(-5)+(8));
segmentsAcked = (int) (-16/3);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
segmentsAcked = (int) (12/-5);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-17/10);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((14.69-(15.02)-(3.35)-(6.06))/18.43);
	tcb->m_segmentSize = (int) (8.25*(6.83));
	tcb->m_cWnd = (int) (13.1+(10.07)+(5.34));

} else {
	tcb->m_segmentSize = (int) (15.75*(11.17)*(segmentsAcked)*(10.62));

}
segmentsAcked = (int) (16/-4);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
tcb->m_cWnd = (int) (16-(5)-(tcb->m_segmentSize)-(-9));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
tcb->m_cWnd = (int) (segmentsAcked*(-14)*(-16)*(segmentsAcked));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_segmentSize+(-4)+(-3));
segmentsAcked = (int) (-15/1);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((14.69-(15.02)-(3.35)-(6.06))/18.43);
	tcb->m_segmentSize = (int) (8.25*(6.83));
	tcb->m_cWnd = (int) (13.1+(10.07)+(5.34));

} else {
	tcb->m_segmentSize = (int) (15.75*(11.17)*(segmentsAcked)*(10.62));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
segmentsAcked = (int) (1/11);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
segmentsAcked = (int) (-4/10);
tcb->m_cWnd = (int) (-6-(18)-(tcb->m_segmentSize)-(12));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
segmentsAcked = (int) (4/-18);
tcb->m_cWnd = (int) (segmentsAcked*(9)*(7)*(segmentsAcked));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (7/-8);
tcb->m_cWnd = (int) (tcb->m_segmentSize+(-15)+(-16));
segmentsAcked = (int) (-12/-12);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
segmentsAcked = (int) (-19/6);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-6/10);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
segmentsAcked = (int) (-12/-12);
