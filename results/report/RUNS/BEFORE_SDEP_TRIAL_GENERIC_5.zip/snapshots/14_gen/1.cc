if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-11+(16));
tcb->m_cWnd = (int) (-1+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-1+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (17+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (19+(tcb->m_segmentSize));
segmentsAcked = (int) (-18-(3)-(-19));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-14-(-9)-(14));
segmentsAcked = (int) (11-(7)-(-15));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (1-(6)-(4));
segmentsAcked = (int) (19-(-5)-(-2));
segmentsAcked = (int) (-19-(11)-(-9));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (17-(-4)-(14));
