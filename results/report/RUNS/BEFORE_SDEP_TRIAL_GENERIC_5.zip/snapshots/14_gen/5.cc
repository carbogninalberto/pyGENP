if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (14+(-13));
tcb->m_cWnd = (int) (-9+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-17+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (-9+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-15+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (-9+(tcb->m_segmentSize));
segmentsAcked = (int) (19-(-20)-(-3));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-13+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-19+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-14-(-12)-(13));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (8-(11)-(10));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-12+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (1-(10)-(1));
segmentsAcked = (int) (1-(-9)-(-15));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-2-(14)-(15));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (16-(8)-(3));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-8-(-12)-(-19));
segmentsAcked = (int) (-12-(3)-(-20));
segmentsAcked = (int) (4-(6)-(-4));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-14-(18)-(3));
segmentsAcked = (int) (2-(-8)-(1));
segmentsAcked = (int) (-2-(-1)-(-9));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (11-(-18)-(-15));
