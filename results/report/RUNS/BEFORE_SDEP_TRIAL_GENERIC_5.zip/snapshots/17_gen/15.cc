if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (1+(17));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (15+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (12+(tcb->m_segmentSize));
segmentsAcked = (int) (-2-(-4)-(-17));
tcb->m_cWnd = (int) (1+(tcb->m_segmentSize));
segmentsAcked = (int) (7-(16)-(-20));
tcb->m_cWnd = (int) (-19+(tcb->m_segmentSize));
segmentsAcked = (int) (5-(19)-(18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-8-(-18)-(5));
segmentsAcked = (int) (-4-(9)-(-8));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-13+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (12-(8)-(10));
segmentsAcked = (int) (-8-(-15)-(18));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-2-(4)-(18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (19-(-10)-(9));
segmentsAcked = (int) (4-(-18)-(-8));
segmentsAcked = (int) (3-(9)-(7));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (2-(-1)-(-5));
