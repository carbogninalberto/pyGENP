if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-17+(-19));
tcb->m_cWnd = (int) (-19+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (8+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (-19+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-7+(tcb->m_segmentSize));
segmentsAcked = (int) (4-(-1)-(-8));
segmentsAcked = (int) (-20-(7)-(-19));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-12-(13)-(-19));
segmentsAcked = (int) (10-(6)-(-7));
segmentsAcked = (int) (-17-(15)-(14));
segmentsAcked = (int) (-18-(-20)-(-19));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-8-(-17)-(2));
segmentsAcked = (int) (-14-(-20)-(4));
