if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-4+(5));
tcb->m_cWnd = (int) (-1+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (1+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-6+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-15-(12)-(-10));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-3-(11)-(14));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (14-(19)-(2));
tcb->m_cWnd = (int) (8+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (3-(-1)-(-4));
segmentsAcked = (int) (-16-(1)-(-11));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (15-(-9)-(14));
segmentsAcked = (int) (-17-(-6)-(9));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-1-(10)-(-3));
segmentsAcked = (int) (-10-(18)-(14));
segmentsAcked = (int) (15-(-9)-(2));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (4-(-4)-(-11));
segmentsAcked = (int) (-19-(4)-(-8));
