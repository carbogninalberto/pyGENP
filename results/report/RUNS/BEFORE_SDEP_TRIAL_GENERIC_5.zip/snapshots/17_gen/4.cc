if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-8+(5));
tcb->m_cWnd = (int) (-15+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-11+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (15+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (14-(1)-(18));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (7-(-6)-(-6));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-4-(-16)-(10));
segmentsAcked = (int) (-4-(-18)-(-18));
tcb->m_cWnd = (int) (-12+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (-16+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-14-(-3)-(-14));
segmentsAcked = (int) (1-(-19)-(9));
segmentsAcked = (int) (-8-(-18)-(-19));
segmentsAcked = (int) (10-(-13)-(15));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-3-(4)-(10));
segmentsAcked = (int) (-4-(-12)-(14));
segmentsAcked = (int) (-19-(7)-(-11));
segmentsAcked = (int) (-10-(-14)-(-6));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-1-(-19)-(14));
segmentsAcked = (int) (15-(-15)-(-3));
segmentsAcked = (int) (7-(2)-(18));
segmentsAcked = (int) (8-(3)-(-5));
segmentsAcked = (int) (1-(-9)-(16));
segmentsAcked = (int) (6-(-16)-(-13));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (4-(3)-(6));
segmentsAcked = (int) (-10-(-13)-(7));
