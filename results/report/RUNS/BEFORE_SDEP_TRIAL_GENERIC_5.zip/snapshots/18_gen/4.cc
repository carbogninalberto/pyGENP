if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (5+(15));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-16+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-2+(tcb->m_segmentSize));
segmentsAcked = (int) (10-(-1)-(12));
tcb->m_cWnd = (int) (-5+(tcb->m_segmentSize));
segmentsAcked = (int) (15-(13)-(-14));
tcb->m_cWnd = (int) (-3+(tcb->m_segmentSize));
segmentsAcked = (int) (15-(6)-(-3));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (7-(9)-(18));
segmentsAcked = (int) (10-(1)-(-9));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (9+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (1-(-9)-(3));
segmentsAcked = (int) (-9-(-10)-(19));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-10-(9)-(16));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (1-(13)-(-10));
segmentsAcked = (int) (-1-(-8)-(8));
segmentsAcked = (int) (1-(-17)-(-17));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-15-(-17)-(-15));
