if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-20+(-20));
tcb->m_cWnd = (int) (-9+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-12+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-11+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-14-(-16)-(7));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-15-(-2)-(9));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-1-(-13)-(14));
segmentsAcked = (int) (-16-(3)-(-7));
tcb->m_cWnd = (int) (-16+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (11+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-14-(-7)-(12));
segmentsAcked = (int) (-16-(-14)-(19));
segmentsAcked = (int) (-12-(-16)-(10));
segmentsAcked = (int) (-2-(-17)-(18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-16-(6)-(-1));
segmentsAcked = (int) (-5-(-6)-(-15));
segmentsAcked = (int) (-15-(19)-(6));
segmentsAcked = (int) (-7-(-1)-(7));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-13-(18)-(-13));
segmentsAcked = (int) (-12-(13)-(14));
segmentsAcked = (int) (-1-(16)-(5));
segmentsAcked = (int) (-13-(16)-(5));
segmentsAcked = (int) (11-(9)-(-11));
segmentsAcked = (int) (-15-(17)-(8));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-18-(1)-(-20));
segmentsAcked = (int) (1-(-8)-(18));
