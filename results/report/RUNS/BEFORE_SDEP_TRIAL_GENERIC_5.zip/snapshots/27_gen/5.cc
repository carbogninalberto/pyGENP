if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-9+(18));
tcb->m_cWnd = (int) (-18+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (5+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-2+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (15-(-7)-(-19));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (9-(-4)-(-16));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-3-(-19)-(3));
tcb->m_cWnd = (int) (12+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (3-(12)-(-3));
segmentsAcked = (int) (2-(11)-(-11));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-17-(1)-(-15));
segmentsAcked = (int) (2-(15)-(17));
segmentsAcked = (int) (14-(-20)-(19));
segmentsAcked = (int) (-1-(-8)-(-15));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (8-(16)-(15));
segmentsAcked = (int) (-6-(6)-(-17));
segmentsAcked = (int) (17-(-16)-(11));
segmentsAcked = (int) (3-(-19)-(11));
segmentsAcked = (int) (-3-(18)-(-19));
segmentsAcked = (int) (1-(7)-(-2));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (11-(-1)-(4));
segmentsAcked = (int) (-14-(-5)-(16));
segmentsAcked = (int) (14-(8)-(12));
segmentsAcked = (int) (13-(-13)-(-16));
