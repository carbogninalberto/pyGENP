if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (2+(-20));
tcb->m_cWnd = (int) (-16+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (15+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-9+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (8-(10)-(10));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-9-(-4)-(5));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (15-(-7)-(-13));
tcb->m_cWnd = (int) (1+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (10-(-11)-(5));
segmentsAcked = (int) (5-(8)-(13));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-18-(15)-(-19));
segmentsAcked = (int) (-1-(11)-(12));
segmentsAcked = (int) (-1-(-17)-(16));
segmentsAcked = (int) (5-(-1)-(-20));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (9-(-4)-(14));
segmentsAcked = (int) (-5-(-20)-(-7));
segmentsAcked = (int) (-4-(-2)-(12));
segmentsAcked = (int) (-20-(1)-(16));
segmentsAcked = (int) (1-(-10)-(-6));
segmentsAcked = (int) (-6-(13)-(-7));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-10-(8)-(-10));
segmentsAcked = (int) (1-(8)-(-8));
segmentsAcked = (int) (-11-(18)-(-14));
segmentsAcked = (int) (-2-(-19)-(-6));
