if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-20+(1));
tcb->m_cWnd = (int) (-10+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-11+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (-9+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-17+(tcb->m_segmentSize));
segmentsAcked = (int) (13-(-8)-(-6));
segmentsAcked = (int) (5-(-20)-(9));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (18-(-15)-(-4));
segmentsAcked = (int) (-14-(14)-(16));
segmentsAcked = (int) (1-(4)-(14));
segmentsAcked = (int) (-3-(-5)-(-20));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-13-(1)-(-16));
segmentsAcked = (int) (7-(-13)-(17));
segmentsAcked = (int) (-2-(-1)-(-13));
segmentsAcked = (int) (14-(-2)-(6));
segmentsAcked = (int) (-6-(-10)-(-6));
segmentsAcked = (int) (-4-(1)-(11));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-3-(-11)-(10));
segmentsAcked = (int) (2-(-5)-(-14));
