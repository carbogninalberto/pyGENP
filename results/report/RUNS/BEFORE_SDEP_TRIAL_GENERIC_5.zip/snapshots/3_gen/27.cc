float BosCQVZYWQgnWwXQ = (float) (14-(4)-(-7)-(-2));
int jNRVIpencHzGUfBn = (int) (6-(14));
