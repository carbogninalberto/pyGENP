segmentsAcked = SlowStart (tcb, segmentsAcked);
float naHHpdiwtSxhNaVF = (float) (19/-18);
tcb->m_segmentSize = (int) (-13-(-2)-(-6)-(tcb->m_cWnd));
tcb->m_segmentSize = (int) (8-(-18)-(-17)-(tcb->m_cWnd));
tcb->m_cWnd = (int) (-9/-1);
tcb->m_cWnd = (int) (6/-9);
if (tcb->m_segmentSize >= naHHpdiwtSxhNaVF) {
	segmentsAcked = (int) (11.88/13.74);
	tcb->m_segmentSize = (int) (8.4+(2.06)+(19.51));

} else {
	segmentsAcked = (int) (8.46*(segmentsAcked)*(7.01)*(8.97));

}
if (tcb->m_segmentSize >= naHHpdiwtSxhNaVF) {
	segmentsAcked = (int) (11.88/13.74);
	tcb->m_segmentSize = (int) (8.4+(2.06)+(19.51));

} else {
	segmentsAcked = (int) (8.46*(segmentsAcked)*(7.01)*(8.97));

}
tcb->m_cWnd = (int) (1-(tcb->m_segmentSize)-(-15));
tcb->m_cWnd = (int) (9-(tcb->m_segmentSize)-(-5));
tcb->m_segmentSize = (int) (11+(tcb->m_cWnd)+(13));
tcb->m_segmentSize = (int) (6+(tcb->m_cWnd)+(14));
tcb->m_cWnd = (int) (5-(tcb->m_segmentSize)-(-11));
naHHpdiwtSxhNaVF = (float) ((12.58-(5.14))/15);
tcb->m_cWnd = (int) (-2-(tcb->m_segmentSize)-(-18));
naHHpdiwtSxhNaVF = (float) ((12.58-(5.14))/-5);
tcb->m_segmentSize = (int) (1+(tcb->m_cWnd)+(-7));
tcb->m_segmentSize = (int) (14+(tcb->m_cWnd)+(16));
naHHpdiwtSxhNaVF = (float) ((12.58-(5.14))/12);
naHHpdiwtSxhNaVF = (float) ((12.58-(5.14))/14);
