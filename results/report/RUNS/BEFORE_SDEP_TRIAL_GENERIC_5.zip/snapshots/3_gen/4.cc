if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-11+(12));
tcb->m_cWnd = (int) (-16+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-11+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-12-(11)-(1));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-19-(1)-(-6));
