float naHHpdiwtSxhNaVF = (float) (15/-20);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-8-(10)-(15)-(tcb->m_cWnd));
tcb->m_cWnd = (int) (6/-8);
if (tcb->m_segmentSize >= naHHpdiwtSxhNaVF) {
	segmentsAcked = (int) (11.88/13.74);
	tcb->m_segmentSize = (int) (8.4+(2.06)+(19.51));

} else {
	segmentsAcked = (int) (8.46*(segmentsAcked)*(7.01)*(8.97));

}
tcb->m_cWnd = (int) (-17-(tcb->m_segmentSize)-(5));
tcb->m_segmentSize = (int) (7+(tcb->m_cWnd)+(-1));
naHHpdiwtSxhNaVF = (float) ((12.58-(5.14))/4);
tcb->m_cWnd = (int) (-14/3);
if (tcb->m_segmentSize >= naHHpdiwtSxhNaVF) {
	segmentsAcked = (int) (11.88/13.74);
	tcb->m_segmentSize = (int) (8.4+(2.06)+(19.51));

} else {
	segmentsAcked = (int) (8.46*(segmentsAcked)*(7.01)*(8.97));

}
tcb->m_cWnd = (int) (-11-(tcb->m_segmentSize)-(-14));
tcb->m_segmentSize = (int) (-2+(tcb->m_cWnd)+(-18));
naHHpdiwtSxhNaVF = (float) ((12.58-(5.14))/12);
