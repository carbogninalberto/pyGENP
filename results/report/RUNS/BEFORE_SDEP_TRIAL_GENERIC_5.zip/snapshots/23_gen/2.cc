if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-11+(-16));
tcb->m_cWnd = (int) (16+(tcb->m_segmentSize));
segmentsAcked = (int) (-5-(-8)-(-13));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (1-(11)-(-3));
tcb->m_cWnd = (int) (7+(tcb->m_segmentSize));
segmentsAcked = (int) (-8-(-9)-(1));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-8+(tcb->m_segmentSize));
segmentsAcked = (int) (-20-(14)-(4));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (1-(-7)-(2));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-7-(-10)-(11));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (11-(6)-(17));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (1-(-19)-(12));
tcb->m_cWnd = (int) (-3+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-19-(10)-(19));
segmentsAcked = (int) (-9-(2)-(-7));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-9-(-9)-(-7));
segmentsAcked = (int) (8-(12)-(6));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-19-(-9)-(-16));
segmentsAcked = (int) (14-(5)-(-17));
segmentsAcked = (int) (18-(18)-(11));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (8-(3)-(-11));
segmentsAcked = (int) (17-(11)-(-20));
