if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-6+(-7));
tcb->m_cWnd = (int) (-16+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (17+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (15+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (19+(tcb->m_segmentSize));
segmentsAcked = (int) (-2-(-18)-(6));
segmentsAcked = (int) (4-(-1)-(-14));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-18-(7)-(-6));
segmentsAcked = (int) (17-(-8)-(-7));
segmentsAcked = (int) (3-(-15)-(15));
segmentsAcked = (int) (-10-(-9)-(14));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (6-(-9)-(13));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (10-(2)-(-13));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-7+(tcb->m_segmentSize));
segmentsAcked = (int) (16-(11)-(-3));
segmentsAcked = (int) (8-(-19)-(18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (12-(14)-(16));
segmentsAcked = (int) (16-(3)-(-1));
segmentsAcked = (int) (-12-(18)-(-8));
segmentsAcked = (int) (12-(14)-(18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (2-(19)-(-19));
segmentsAcked = (int) (-1-(-19)-(14));
