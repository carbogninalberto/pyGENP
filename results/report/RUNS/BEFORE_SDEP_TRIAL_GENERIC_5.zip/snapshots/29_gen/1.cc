if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-20+(-5));
tcb->m_cWnd = (int) (7+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (5+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (-9+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-5+(tcb->m_segmentSize));
segmentsAcked = (int) (2-(-12)-(2));
segmentsAcked = (int) (-15-(4)-(12));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (17-(6)-(-11));
segmentsAcked = (int) (9-(14)-(-8));
segmentsAcked = (int) (-13-(-19)-(17));
segmentsAcked = (int) (1-(1)-(16));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-15-(-13)-(12));
segmentsAcked = (int) (-12-(-9)-(12));
