if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (2+(-12));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (8+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-3+(tcb->m_segmentSize));
segmentsAcked = (int) (-4-(-19)-(18));
tcb->m_cWnd = (int) (-15+(tcb->m_segmentSize));
segmentsAcked = (int) (-18-(-10)-(-3));
tcb->m_cWnd = (int) (7+(tcb->m_segmentSize));
segmentsAcked = (int) (7-(-9)-(17));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-10-(-9)-(-10));
segmentsAcked = (int) (-2-(1)-(-7));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-18+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-11-(9)-(-13));
segmentsAcked = (int) (18-(-10)-(-6));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (2-(18)-(1));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (19-(11)-(-2));
segmentsAcked = (int) (10-(-13)-(8));
segmentsAcked = (int) (19-(-8)-(18));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-11-(9)-(12));
