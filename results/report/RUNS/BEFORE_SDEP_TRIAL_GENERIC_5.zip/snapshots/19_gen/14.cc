if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-16+(-6));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-15+(tcb->m_segmentSize));
segmentsAcked = (int) (4-(-19)-(-19));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (14-(5)-(-18));
tcb->m_cWnd = (int) (14+(tcb->m_segmentSize));
segmentsAcked = (int) (-4-(-19)-(3));
tcb->m_cWnd = (int) (-7+(tcb->m_segmentSize));
segmentsAcked = (int) (-15-(-2)-(-11));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-2-(-11)-(15));
tcb->m_cWnd = (int) (-7+(tcb->m_segmentSize));
segmentsAcked = (int) (6-(15)-(4));
segmentsAcked = (int) (6-(4)-(-16));
segmentsAcked = (int) (14-(-1)-(-4));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (18-(3)-(-17));
segmentsAcked = (int) (19-(-13)-(-15));
segmentsAcked = (int) (-4-(-13)-(17));
segmentsAcked = (int) (3-(-1)-(7));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (4-(6)-(-16));
segmentsAcked = (int) (6-(-1)-(-5));
