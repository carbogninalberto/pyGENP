if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-20+(-1));
tcb->m_cWnd = (int) (9+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-14+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (18+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (2-(-9)-(-6));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-17-(8)-(15));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-8-(14)-(13));
tcb->m_cWnd = (int) (-4+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-13-(-16)-(17));
segmentsAcked = (int) (-14-(-19)-(-20));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (11-(5)-(6));
segmentsAcked = (int) (1-(-14)-(-13));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-18-(3)-(-6));
segmentsAcked = (int) (10-(8)-(7));
segmentsAcked = (int) (3-(12)-(13));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-4-(-13)-(14));
segmentsAcked = (int) (16-(1)-(-16));
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-14+(13));
tcb->m_cWnd = (int) (-13+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (3+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (12+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-6-(-18)-(-6));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-5-(1)-(5));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-11-(-13)-(12));
tcb->m_cWnd = (int) (-20+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-18-(-2)-(6));
segmentsAcked = (int) (19-(13)-(-2));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (1-(-14)-(3));
segmentsAcked = (int) (-6-(-16)-(11));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (15-(1)-(8));
segmentsAcked = (int) (-2-(17)-(8));
segmentsAcked = (int) (-15-(7)-(-8));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (16-(-5)-(11));
segmentsAcked = (int) (-5-(-3)-(9));
