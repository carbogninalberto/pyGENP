if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-1+(17));
tcb->m_cWnd = (int) (-4+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (17+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (18+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-18-(2)-(15));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (4-(-8)-(-7));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-16-(5)-(16));
tcb->m_cWnd = (int) (3+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (5-(4)-(18));
segmentsAcked = (int) (18-(-18)-(-12));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-3-(6)-(-19));
segmentsAcked = (int) (-7-(-9)-(14));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (3-(-11)-(-6));
segmentsAcked = (int) (-6-(-11)-(11));
segmentsAcked = (int) (15-(4)-(-1));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (3-(5)-(-15));
segmentsAcked = (int) (1-(18)-(1));
