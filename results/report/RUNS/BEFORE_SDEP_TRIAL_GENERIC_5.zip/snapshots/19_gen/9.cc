if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-12+(1));
tcb->m_cWnd = (int) (-8+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-8+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (16+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (8+(tcb->m_segmentSize));
segmentsAcked = (int) (14-(4)-(-13));
segmentsAcked = (int) (-4-(2)-(-15));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (14-(-7)-(-14));
segmentsAcked = (int) (1-(-8)-(-3));
segmentsAcked = (int) (8-(-4)-(15));
segmentsAcked = (int) (1-(-10)-(-19));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (1-(-2)-(-9));
segmentsAcked = (int) (16-(-7)-(7));
