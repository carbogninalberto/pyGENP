if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-3+(-17));
tcb->m_cWnd = (int) (17+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (9+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (-15+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (-19+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-20-(-17)-(-7));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-10+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-2-(14)-(17));
segmentsAcked = (int) (-16-(13)-(-5));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (14-(1)-(12));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (11-(-12)-(-18));
tcb->m_cWnd = (int) (-12+(tcb->m_segmentSize));
segmentsAcked = (int) (15-(-12)-(13));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (5-(5)-(12));
segmentsAcked = (int) (-12-(14)-(10));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (18-(10)-(-10));
segmentsAcked = (int) (-6-(-20)-(-10));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-10-(12)-(9));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-13-(9)-(7));
segmentsAcked = (int) (-16-(-17)-(-17));
segmentsAcked = (int) (14-(-11)-(-20));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (13-(-14)-(-15));
