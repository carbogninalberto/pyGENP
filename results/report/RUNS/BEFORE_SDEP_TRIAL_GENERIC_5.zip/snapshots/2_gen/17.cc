float OzRIkbYSgVfzungD = (float) (2/14);
int uycjubBjlyzVcSZD = (int) (-18*(11));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	uycjubBjlyzVcSZD = (int) (tcb->m_segmentSize-(segmentsAcked));

} else {
	uycjubBjlyzVcSZD = (int) (17.32/5.86);

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (4.66/6.47);
	tcb->m_segmentSize = (int) (18.01+(16.63)+(14.84)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (2.02/1);
	segmentsAcked = (int) (0.52-(15.52)-(17.68)-(17.61));
	tcb->m_segmentSize = (int) (16.84*(3.51));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (OzRIkbYSgVfzungD == uycjubBjlyzVcSZD) {
	segmentsAcked = (int) (tcb->m_cWnd*(13.25)*(10.71)*(5.96));

} else {
	segmentsAcked = (int) (4.56/1.47);
	tcb->m_cWnd = (int) (17.27-(OzRIkbYSgVfzungD)-(13.91)-(uycjubBjlyzVcSZD));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (OzRIkbYSgVfzungD == uycjubBjlyzVcSZD) {
	segmentsAcked = (int) (tcb->m_cWnd*(13.25)*(10.71)*(5.96));

} else {
	segmentsAcked = (int) (4.56/1.47);
	tcb->m_cWnd = (int) (17.27-(OzRIkbYSgVfzungD)-(13.91)-(uycjubBjlyzVcSZD));

}
if (OzRIkbYSgVfzungD > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (8.9-(18.19)-(2.45));

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(14.43)-(16.76)-(15.39));
	tcb->m_cWnd = (int) (18.0/18.22);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
OzRIkbYSgVfzungD = (float) (-2-(-16)-(16)-(-10));
if (OzRIkbYSgVfzungD > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (8.9-(18.19)-(2.45));

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(14.43)-(16.76)-(15.39));
	tcb->m_cWnd = (int) (18.0/18.22);

}
OzRIkbYSgVfzungD = (float) (4-(-15)-(-20)-(11));
