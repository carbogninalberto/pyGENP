float naHHpdiwtSxhNaVF = (float) (-2/-20);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-1-(2)-(-15)-(tcb->m_cWnd));
if (tcb->m_segmentSize >= naHHpdiwtSxhNaVF) {
	segmentsAcked = (int) (11.88/13.74);
	tcb->m_segmentSize = (int) (8.4+(2.06)+(19.51));

} else {
	segmentsAcked = (int) (8.46*(segmentsAcked)*(7.01)*(8.97));

}
tcb->m_cWnd = (int) (-8/18);
tcb->m_cWnd = (int) (-4-(tcb->m_segmentSize)-(5));
if (tcb->m_segmentSize >= naHHpdiwtSxhNaVF) {
	segmentsAcked = (int) (11.88/13.74);
	tcb->m_segmentSize = (int) (8.4+(2.06)+(19.51));

} else {
	segmentsAcked = (int) (8.46*(segmentsAcked)*(7.01)*(8.97));

}
tcb->m_segmentSize = (int) (15+(tcb->m_cWnd)+(-10));
tcb->m_cWnd = (int) (7-(tcb->m_segmentSize)-(9));
naHHpdiwtSxhNaVF = (float) ((12.58-(5.14))/-8);
tcb->m_segmentSize = (int) (-12+(tcb->m_cWnd)+(11));
naHHpdiwtSxhNaVF = (float) ((12.58-(5.14))/-16);
