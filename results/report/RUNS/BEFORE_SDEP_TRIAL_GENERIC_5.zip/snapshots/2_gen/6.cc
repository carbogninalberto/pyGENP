int feOsqdSgITZuknCH = (int) (17/-8);
float jFyjFUZXVyHfvwqJ = (float) (-3*(-14));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (17*(-14)*(-8));
tcb->m_segmentSize = (int) (14-(-11)-(-5)-(-20));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
