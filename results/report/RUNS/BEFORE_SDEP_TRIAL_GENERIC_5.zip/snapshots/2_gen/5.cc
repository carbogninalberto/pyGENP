float GzVKYZlAimQhcLce = (float) (17*(-16)*(-14));
tcb->m_segmentSize = (int) ((10.26+(segmentsAcked))/-3);
if (tcb->m_cWnd <= GzVKYZlAimQhcLce) {
	segmentsAcked = (int) (17.35-(15.3));
	tcb->m_segmentSize = (int) (7.59+(2.23)+(17.0));

} else {
	segmentsAcked = (int) (0.32*(8.26));
	segmentsAcked = (int) (1.06*(8.44)*(9.51));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
