if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(16.44));

} else {
	tcb->m_segmentSize = (int) (13.0/10.17);

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (4.66/6.47);
	tcb->m_segmentSize = (int) (18.01+(16.63)+(14.84)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (2.02/1);
	segmentsAcked = (int) (0.52-(15.52)-(17.68)-(17.61));
	tcb->m_segmentSize = (int) (16.84*(3.51));

}
