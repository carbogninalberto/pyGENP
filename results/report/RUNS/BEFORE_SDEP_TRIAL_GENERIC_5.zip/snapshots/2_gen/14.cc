if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (2.62/(16.02*(12.69)*(1.9)*(tcb->m_segmentSize)));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(tcb->m_segmentSize));

}
segmentsAcked = (int) (13*(-17));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
