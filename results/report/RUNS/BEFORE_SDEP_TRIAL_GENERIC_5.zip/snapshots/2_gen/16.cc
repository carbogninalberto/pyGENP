if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (1.72-(19.8));

} else {
	tcb->m_segmentSize = (int) (12.61/13.18);

}
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (1.15*(5.22)*(2.24));

} else {
	tcb->m_segmentSize = (int) (19.7*(14.23));

}
segmentsAcked = (int) (12*(15));
segmentsAcked = (int) (-12*(-17));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (1+(-19)+(-2)+(-3));
segmentsAcked = (int) (14+(-8)+(-15)+(12));
