segmentsAcked = (int) (-15/14);
tcb->m_cWnd = (int) (tcb->m_segmentSize+(3)+(2));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((14.69-(15.02)-(3.35)-(6.06))/18.43);
	tcb->m_segmentSize = (int) (8.25*(6.83));
	tcb->m_cWnd = (int) (13.1+(10.07)+(5.34));

} else {
	tcb->m_segmentSize = (int) (15.75*(11.17)*(segmentsAcked)*(10.62));

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
tcb->m_cWnd = (int) (-18-(-3)-(tcb->m_segmentSize)-(18));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
segmentsAcked = (int) (-13/-18);
tcb->m_cWnd = (int) (segmentsAcked*(-3)*(-17)*(segmentsAcked));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-6/4);
tcb->m_cWnd = (int) (tcb->m_segmentSize+(-6)+(4));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
segmentsAcked = (int) (-10/-16);
segmentsAcked = (int) (5/-4);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
segmentsAcked = (int) (-2/17);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (15/4);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((14.69-(15.02)-(3.35)-(6.06))/18.43);
	tcb->m_segmentSize = (int) (8.25*(6.83));
	tcb->m_cWnd = (int) (13.1+(10.07)+(5.34));

} else {
	tcb->m_segmentSize = (int) (15.75*(11.17)*(segmentsAcked)*(10.62));

}
segmentsAcked = (int) (-6/-6);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
tcb->m_cWnd = (int) (2-(-18)-(tcb->m_segmentSize)-(-12));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
tcb->m_cWnd = (int) (segmentsAcked*(-11)*(-13)*(segmentsAcked));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_segmentSize+(-20)+(-10));
segmentsAcked = (int) (10/-17);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
segmentsAcked = (int) (19/14);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (16/-1);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
segmentsAcked = (int) (3/15);
