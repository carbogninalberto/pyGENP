if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-12+(18));
tcb->m_cWnd = (int) (5+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-5+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (17+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (8-(-10)-(9));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (17+(tcb->m_segmentSize));
segmentsAcked = (int) (-1-(-20)-(6));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-5-(-6)-(-18));
segmentsAcked = (int) (11-(1)-(-5));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-17-(14)-(-10));
segmentsAcked = (int) (3-(-18)-(12));
segmentsAcked = (int) (-15-(-20)-(5));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (12-(-11)-(-12));
