if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (1+(2));
tcb->m_cWnd = (int) (14+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (16+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (12+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-6+(tcb->m_segmentSize));
segmentsAcked = (int) (-19-(-20)-(11));
segmentsAcked = (int) (-7-(19)-(-3));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (10-(-10)-(-6));
segmentsAcked = (int) (-14-(16)-(16));
segmentsAcked = (int) (-15-(-12)-(-10));
segmentsAcked = (int) (11-(11)-(-14));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-1-(-17)-(5));
segmentsAcked = (int) (15-(19)-(2));
segmentsAcked = (int) (15-(-14)-(-15));
segmentsAcked = (int) (-19-(1)-(1));
segmentsAcked = (int) (16-(-20)-(-13));
segmentsAcked = (int) (19-(13)-(16));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-14-(-20)-(-1));
segmentsAcked = (int) (-13-(-14)-(-2));
