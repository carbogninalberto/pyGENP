if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-7+(-12));
tcb->m_cWnd = (int) (-18+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (1+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (-12+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-18+(tcb->m_segmentSize));
segmentsAcked = (int) (18-(11)-(1));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-13-(8)-(-6));
segmentsAcked = (int) (-13-(12)-(-15));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-20-(-7)-(-17));
