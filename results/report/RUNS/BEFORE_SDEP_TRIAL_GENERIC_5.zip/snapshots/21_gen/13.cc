if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-15+(-4));
tcb->m_cWnd = (int) (-9+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (18+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (19+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-5-(-3)-(14));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (19-(16)-(-3));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (13-(19)-(15));
tcb->m_cWnd = (int) (-15+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-15-(-20)-(-20));
segmentsAcked = (int) (-9-(6)-(-5));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (13-(-18)-(1));
segmentsAcked = (int) (7-(-15)-(7));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (5-(18)-(-10));
segmentsAcked = (int) (18-(-4)-(-18));
segmentsAcked = (int) (11-(19)-(-19));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-5-(-12)-(-6));
segmentsAcked = (int) (-19-(16)-(-2));
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (2+(-17));
tcb->m_cWnd = (int) (-2+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (16+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (13+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (5-(-4)-(10));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (1-(19)-(-9));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-16-(13)-(-18));
tcb->m_cWnd = (int) (10+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-6-(1)-(-14));
segmentsAcked = (int) (-12-(15)-(-18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-7-(-6)-(-14));
segmentsAcked = (int) (18-(18)-(-2));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (1-(-18)-(-9));
segmentsAcked = (int) (-3-(-15)-(-18));
segmentsAcked = (int) (-5-(-19)-(-16));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-19-(19)-(-9));
segmentsAcked = (int) (16-(1)-(-12));
