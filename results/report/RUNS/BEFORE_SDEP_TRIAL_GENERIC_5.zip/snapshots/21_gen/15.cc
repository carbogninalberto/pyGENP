if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-13+(6));
tcb->m_cWnd = (int) (14+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (18+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (12+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (6-(9)-(-12));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-1-(-11)-(3));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-17-(17)-(10));
tcb->m_cWnd = (int) (-3+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (1-(-19)-(-12));
segmentsAcked = (int) (-14-(-15)-(-18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-8-(5)-(18));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-8-(-3)-(-2));
segmentsAcked = (int) (8-(-5)-(-7));
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
segmentsAcked = (int) (10-(-1)-(-20));
tcb->m_cWnd = (int) (2+(-8));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (6+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (17-(-3)-(-8));
tcb->m_cWnd = (int) (-17+(tcb->m_segmentSize));
segmentsAcked = (int) (5-(-5)-(14));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (9-(-11)-(-9));
tcb->m_cWnd = (int) (-11+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (2-(12)-(-4));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-15-(2)-(-13));
segmentsAcked = (int) (-17-(8)-(1));
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-11+(15));
segmentsAcked = (int) (-5-(19)-(-6));
tcb->m_cWnd = (int) (-17+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-7-(-4)-(18));
tcb->m_cWnd = (int) (-15+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (8+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-6+(tcb->m_segmentSize));
segmentsAcked = (int) (-15-(-13)-(-10));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-5-(15)-(17));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (9-(-18)-(-16));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-6-(-3)-(11));
segmentsAcked = (int) (-8-(-7)-(-11));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (12-(-1)-(10));
segmentsAcked = (int) (1-(-15)-(-15));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-19+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (16-(-15)-(13));
segmentsAcked = (int) (-1-(-17)-(-10));
segmentsAcked = (int) (9-(13)-(16));
segmentsAcked = (int) (5-(14)-(3));
segmentsAcked = (int) (-10-(-18)-(8));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-3-(-15)-(-16));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-6-(-16)-(11));
segmentsAcked = (int) (1-(5)-(10));
segmentsAcked = (int) (1-(-15)-(-19));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (16-(14)-(-14));
segmentsAcked = (int) (-2-(-3)-(8));
segmentsAcked = (int) (-19-(-17)-(-12));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-9-(1)-(-18));
segmentsAcked = (int) (16-(-5)-(9));
