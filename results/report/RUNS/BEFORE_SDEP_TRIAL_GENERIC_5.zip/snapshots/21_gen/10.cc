if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-15+(11));
tcb->m_cWnd = (int) (-8+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (12+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (2+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (1-(15)-(19));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-15-(-6)-(7));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-9-(15)-(-16));
tcb->m_cWnd = (int) (9+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (2-(-14)-(-13));
segmentsAcked = (int) (12-(-18)-(8));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-18-(9)-(12));
segmentsAcked = (int) (-10-(-20)-(17));
segmentsAcked = (int) (4-(-18)-(-17));
segmentsAcked = (int) (14-(1)-(-14));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-11-(-14)-(11));
segmentsAcked = (int) (1-(-20)-(-8));
segmentsAcked = (int) (19-(-7)-(-9));
segmentsAcked = (int) (-9-(12)-(-3));
segmentsAcked = (int) (-14-(-19)-(4));
segmentsAcked = (int) (13-(6)-(4));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (16-(-16)-(10));
segmentsAcked = (int) (12-(7)-(-2));
segmentsAcked = (int) (-4-(17)-(19));
segmentsAcked = (int) (14-(-6)-(-11));
