if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-18+(17));
tcb->m_cWnd = (int) (-17+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-1+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-7+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-20-(10)-(-11));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-16-(-2)-(12));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (6-(13)-(11));
tcb->m_cWnd = (int) (19+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-20-(-14)-(-12));
segmentsAcked = (int) (3-(-6)-(5));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (14-(1)-(-9));
segmentsAcked = (int) (9-(-7)-(12));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-3-(19)-(-15));
segmentsAcked = (int) (-18-(2)-(8));
segmentsAcked = (int) (15-(-19)-(-11));
segmentsAcked = (int) (-13-(1)-(16));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (14-(-16)-(-9));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (9-(19)-(14));
segmentsAcked = (int) (-19-(13)-(-20));
segmentsAcked = (int) (2-(-10)-(5));
segmentsAcked = (int) (-10-(-2)-(-1));
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (9+(-7));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (16+(tcb->m_segmentSize));
segmentsAcked = (int) (1-(11)-(12));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-13-(-15)-(3));
tcb->m_cWnd = (int) (-14+(tcb->m_segmentSize));
segmentsAcked = (int) (-8-(-4)-(12));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (9+(tcb->m_segmentSize));
segmentsAcked = (int) (10-(2)-(6));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (13-(-8)-(8));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (15-(4)-(-9));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-4-(-5)-(7));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (16-(8)-(-10));
tcb->m_cWnd = (int) (-2+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-5-(-19)-(12));
segmentsAcked = (int) (-1-(-14)-(2));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (12-(-3)-(1));
segmentsAcked = (int) (-1-(12)-(9));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-6-(15)-(4));
segmentsAcked = (int) (17-(16)-(-2));
segmentsAcked = (int) (-10-(-11)-(-11));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (1-(-17)-(2));
segmentsAcked = (int) (2-(5)-(-1));
