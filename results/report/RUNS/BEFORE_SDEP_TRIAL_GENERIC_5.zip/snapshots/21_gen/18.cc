if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (17+(-4));
tcb->m_cWnd = (int) (-17+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-7+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (2+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-2-(11)-(-9));
segmentsAcked = (int) (1-(-12)-(8));
segmentsAcked = (int) (3-(1)-(12));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (4-(-9)-(-14));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (13-(15)-(-14));
tcb->m_cWnd = (int) (13+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-6-(-19)-(1));
segmentsAcked = (int) (-15-(-17)-(-8));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (5-(8)-(-2));
segmentsAcked = (int) (-19-(-5)-(16));
segmentsAcked = (int) (14-(6)-(-1));
segmentsAcked = (int) (5-(8)-(19));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-6-(-11)-(-7));
segmentsAcked = (int) (-17-(19)-(-18));
segmentsAcked = (int) (-7-(-9)-(17));
segmentsAcked = (int) (9-(-5)-(14));
segmentsAcked = (int) (-17-(9)-(-13));
segmentsAcked = (int) (-13-(-14)-(1));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (11-(-6)-(-7));
segmentsAcked = (int) (-13-(-3)-(2));
segmentsAcked = (int) (10-(-10)-(-1));
segmentsAcked = (int) (7-(18)-(-3));
