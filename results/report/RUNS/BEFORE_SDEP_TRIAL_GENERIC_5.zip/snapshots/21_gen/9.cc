if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (9+(-13));
tcb->m_cWnd = (int) (-12+(tcb->m_segmentSize));
segmentsAcked = (int) (-7-(8)-(-5));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-20-(-13)-(1));
tcb->m_cWnd = (int) (2+(tcb->m_segmentSize));
segmentsAcked = (int) (-12-(-12)-(13));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (3+(tcb->m_segmentSize));
segmentsAcked = (int) (2-(8)-(1));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (13-(-16)-(-14));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (4-(-11)-(-6));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-15-(-17)-(14));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (10-(8)-(15));
tcb->m_cWnd = (int) (-8+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-18-(11)-(6));
segmentsAcked = (int) (17-(-10)-(19));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-9-(-5)-(18));
segmentsAcked = (int) (1-(-18)-(-13));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (5-(-12)-(-1));
segmentsAcked = (int) (-1-(-19)-(-17));
segmentsAcked = (int) (1-(-7)-(-8));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-13-(-6)-(1));
segmentsAcked = (int) (-6-(-3)-(-12));
