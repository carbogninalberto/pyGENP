if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (12+(15));
tcb->m_cWnd = (int) (-20+(tcb->m_segmentSize));
segmentsAcked = (int) (-14-(19)-(-2));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (15-(18)-(6));
tcb->m_cWnd = (int) (15+(tcb->m_segmentSize));
segmentsAcked = (int) (-20-(1)-(-13));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-18+(tcb->m_segmentSize));
segmentsAcked = (int) (-17-(-15)-(9));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-12-(17)-(-1));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (12-(-4)-(13));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-3-(-8)-(-8));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (5-(1)-(-15));
tcb->m_cWnd = (int) (14+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-18-(-8)-(13));
segmentsAcked = (int) (-1-(-12)-(13));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-15-(17)-(12));
segmentsAcked = (int) (2-(11)-(-9));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-5-(1)-(-20));
segmentsAcked = (int) (-13-(-7)-(19));
segmentsAcked = (int) (-4-(-14)-(11));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (11-(9)-(16));
segmentsAcked = (int) (1-(-1)-(-15));
