if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (10+(-14));
tcb->m_cWnd = (int) (-19+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-5+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (-5+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (14+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (18-(-14)-(-4));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-19+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (12-(-15)-(10));
segmentsAcked = (int) (12-(2)-(-8));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (3-(-4)-(9));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (5-(-2)-(-16));
tcb->m_cWnd = (int) (15+(tcb->m_segmentSize));
segmentsAcked = (int) (-19-(-7)-(6));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-5-(-10)-(11));
segmentsAcked = (int) (-17-(-2)-(11));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-8-(5)-(-15));
segmentsAcked = (int) (-1-(-7)-(1));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-5-(6)-(-4));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-18-(-19)-(-12));
segmentsAcked = (int) (6-(15)-(-5));
segmentsAcked = (int) (-10-(19)-(-13));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-3-(12)-(-9));
