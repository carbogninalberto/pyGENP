if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-11+(-3));
tcb->m_cWnd = (int) (10+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-3+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (8+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-19-(-20)-(5));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-20-(13)-(-17));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (10-(8)-(8));
tcb->m_cWnd = (int) (16+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (1-(10)-(6));
segmentsAcked = (int) (5-(11)-(1));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (18-(8)-(-19));
segmentsAcked = (int) (18-(-3)-(-1));
segmentsAcked = (int) (2-(-11)-(-15));
segmentsAcked = (int) (1-(-16)-(-10));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (17-(9)-(11));
segmentsAcked = (int) (2-(-4)-(-18));
segmentsAcked = (int) (-10-(-14)-(19));
segmentsAcked = (int) (6-(1)-(6));
segmentsAcked = (int) (6-(12)-(-18));
segmentsAcked = (int) (5-(-14)-(11));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (15-(18)-(-6));
segmentsAcked = (int) (-8-(1)-(-15));
segmentsAcked = (int) (3-(16)-(4));
segmentsAcked = (int) (15-(17)-(-20));
