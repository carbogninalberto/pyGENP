if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (15+(19));
tcb->m_cWnd = (int) (-10+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (9+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-16+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-1-(12)-(1));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (16-(-11)-(18));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (14-(2)-(-10));
tcb->m_cWnd = (int) (15+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (17-(8)-(-10));
segmentsAcked = (int) (-6-(-12)-(9));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-12-(-15)-(3));
segmentsAcked = (int) (-20-(-13)-(-15));
segmentsAcked = (int) (6-(-14)-(-9));
segmentsAcked = (int) (-5-(18)-(11));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-20-(-7)-(16));
segmentsAcked = (int) (17-(4)-(17));
segmentsAcked = (int) (15-(-4)-(-16));
segmentsAcked = (int) (13-(15)-(12));
segmentsAcked = (int) (19-(19)-(3));
segmentsAcked = (int) (-6-(1)-(-3));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-9-(-13)-(-12));
segmentsAcked = (int) (18-(16)-(-4));
segmentsAcked = (int) (-2-(3)-(-17));
segmentsAcked = (int) (-3-(8)-(-18));
