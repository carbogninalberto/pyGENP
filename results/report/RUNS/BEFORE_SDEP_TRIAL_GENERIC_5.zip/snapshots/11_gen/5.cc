segmentsAcked = (int) (-15/-18);
tcb->m_cWnd = (int) (tcb->m_segmentSize+(-15)+(15));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((14.69-(15.02)-(3.35)-(6.06))/18.43);
	tcb->m_segmentSize = (int) (8.25*(6.83));
	tcb->m_cWnd = (int) (13.1+(10.07)+(5.34));

} else {
	tcb->m_segmentSize = (int) (15.75*(11.17)*(segmentsAcked)*(10.62));

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
tcb->m_cWnd = (int) (-12-(-12)-(tcb->m_segmentSize)-(-16));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
tcb->m_cWnd = (int) (segmentsAcked*(-9)*(1)*(segmentsAcked));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_segmentSize+(-17)+(5));
segmentsAcked = (int) (5/1);
segmentsAcked = (int) (1/7);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
segmentsAcked = (int) (7/-8);
segmentsAcked = (int) (-8/1);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (15/-15);
segmentsAcked = (int) (-2/-18);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((14.69-(15.02)-(3.35)-(6.06))/18.43);
	tcb->m_segmentSize = (int) (8.25*(6.83));
	tcb->m_cWnd = (int) (13.1+(10.07)+(5.34));

} else {
	tcb->m_segmentSize = (int) (15.75*(11.17)*(segmentsAcked)*(10.62));

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((14.69-(15.02)-(3.35)-(6.06))/18.43);
	tcb->m_segmentSize = (int) (8.25*(6.83));
	tcb->m_cWnd = (int) (13.1+(10.07)+(5.34));

} else {
	tcb->m_segmentSize = (int) (15.75*(11.17)*(segmentsAcked)*(10.62));

}
segmentsAcked = (int) (-17/-19);
segmentsAcked = (int) (15/-10);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
tcb->m_cWnd = (int) (5-(8)-(tcb->m_segmentSize)-(17));
tcb->m_cWnd = (int) (-16-(-4)-(tcb->m_segmentSize)-(5));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
tcb->m_cWnd = (int) (segmentsAcked*(5)*(15)*(segmentsAcked));
tcb->m_cWnd = (int) (segmentsAcked*(-5)*(-5)*(segmentsAcked));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_segmentSize+(11)+(-14));
tcb->m_cWnd = (int) (tcb->m_segmentSize+(-18)+(-2));
segmentsAcked = (int) (8/-19);
segmentsAcked = (int) (-7/-13);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (3.0-(10.23)-(6.74)-(0.61));
	tcb->m_segmentSize = (int) (5.52+(19.65)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (15.16+(14.42)+(8.49)+(9.32));
	segmentsAcked = (int) (2.51/15.23);
	tcb->m_cWnd = (int) (8.49-(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
segmentsAcked = (int) (-14/-1);
segmentsAcked = (int) (11/-19);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (7/-18);
segmentsAcked = (int) (1/-16);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (8.23-(1.53));

} else {
	segmentsAcked = (int) (10.6*(tcb->m_cWnd)*(5.76)*(2.7));
	segmentsAcked = (int) (7.16/8.03);
	segmentsAcked = (int) (14.16+(7.3)+(1.27)+(segmentsAcked));

}
segmentsAcked = (int) (16/13);
segmentsAcked = (int) (13/-2);
