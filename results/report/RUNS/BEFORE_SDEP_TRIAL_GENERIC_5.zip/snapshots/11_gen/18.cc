if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (17+(-9));
tcb->m_cWnd = (int) (14+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-4+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-3+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-15-(16)-(-5));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-1-(-11)-(-17));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-20-(1)-(1));
tcb->m_cWnd = (int) (-3+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-10-(-12)-(-6));
segmentsAcked = (int) (-3-(1)-(-5));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (5-(-16)-(-1));
segmentsAcked = (int) (17-(-2)-(-5));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-10-(-19)-(17));
segmentsAcked = (int) (-20-(13)-(-17));
segmentsAcked = (int) (-1-(7)-(-11));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (4-(-5)-(-19));
