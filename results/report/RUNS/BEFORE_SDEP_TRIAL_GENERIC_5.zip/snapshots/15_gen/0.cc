if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-7+(-15));
tcb->m_cWnd = (int) (-15+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (9+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (7+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-1-(-4)-(-8));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-3-(-5)-(1));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-18-(13)-(-5));
segmentsAcked = (int) (-18-(-1)-(7));
tcb->m_cWnd = (int) (-10+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (9+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-3-(10)-(-5));
segmentsAcked = (int) (-13-(-15)-(-18));
segmentsAcked = (int) (1-(10)-(4));
segmentsAcked = (int) (19-(5)-(10));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-13-(-16)-(18));
segmentsAcked = (int) (-16-(-3)-(3));
segmentsAcked = (int) (-10-(12)-(-6));
segmentsAcked = (int) (-18-(-3)-(-18));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (1-(5)-(12));
segmentsAcked = (int) (1-(-5)-(10));
segmentsAcked = (int) (19-(-3)-(17));
segmentsAcked = (int) (-12-(-12)-(-12));
segmentsAcked = (int) (-3-(-13)-(1));
segmentsAcked = (int) (-12-(-7)-(18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (1-(18)-(-1));
segmentsAcked = (int) (-10-(-15)-(4));
