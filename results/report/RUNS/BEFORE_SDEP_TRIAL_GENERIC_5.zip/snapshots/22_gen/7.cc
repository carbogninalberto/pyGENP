if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-3+(-17));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (13+(tcb->m_segmentSize));
segmentsAcked = (int) (5-(-16)-(-5));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (12-(15)-(19));
tcb->m_cWnd = (int) (-2+(tcb->m_segmentSize));
segmentsAcked = (int) (13-(-16)-(-1));
tcb->m_cWnd = (int) (-20+(tcb->m_segmentSize));
segmentsAcked = (int) (4-(-20)-(-18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (10-(2)-(-17));
tcb->m_cWnd = (int) (19+(tcb->m_segmentSize));
segmentsAcked = (int) (3-(17)-(-7));
segmentsAcked = (int) (1-(-3)-(10));
segmentsAcked = (int) (-19-(-6)-(6));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-12-(-4)-(9));
segmentsAcked = (int) (4-(18)-(-3));
segmentsAcked = (int) (-6-(-10)-(-12));
segmentsAcked = (int) (14-(-13)-(16));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (5-(11)-(-11));
segmentsAcked = (int) (-20-(-7)-(-18));
