if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-12+(-13));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (3+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-2+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-3-(3)-(-13));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (13+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (7-(-6)-(15));
segmentsAcked = (int) (10-(14)-(5));
tcb->m_cWnd = (int) (11+(tcb->m_segmentSize));
segmentsAcked = (int) (17-(18)-(-18));
segmentsAcked = (int) (-12-(-15)-(-9));
segmentsAcked = (int) (12-(-17)-(-6));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-6-(9)-(-19));
segmentsAcked = (int) (-6-(-1)-(18));
segmentsAcked = (int) (15-(18)-(-8));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-7+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (12-(-13)-(19));
segmentsAcked = (int) (-20-(-6)-(8));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (14-(8)-(2));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (13-(-19)-(7));
segmentsAcked = (int) (19-(9)-(-14));
segmentsAcked = (int) (16-(-12)-(14));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-7-(-15)-(-1));
