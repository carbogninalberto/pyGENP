tcb->m_segmentSize = (int) ((16.37+(7.62)+(13.57)+(tcb->m_cWnd))/5.48);
float GzVKYZlAimQhcLce = (float) (19.24*(3.43)*(14.32));
if (tcb->m_cWnd <= GzVKYZlAimQhcLce) {
	segmentsAcked = (int) (17.35-(15.3));
	tcb->m_segmentSize = (int) (7.59+(2.23)+(17.0));

} else {
	segmentsAcked = (int) (0.32*(8.26));
	segmentsAcked = (int) (1.06*(8.44)*(9.51));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
