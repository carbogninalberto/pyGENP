CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (17.08/18.23);
int vwcOBLsguOgViclu = (int) (14.71/2.49);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
vwcOBLsguOgViclu = (int) (16.4-(14.37));
vwcOBLsguOgViclu = (int) (12.72/19.56);
tcb->m_cWnd = (int) (0.29+(2.6)+(2.28)+(15.54));
segmentsAcked = (int) (15.81-(14.92)-(3.07));
