if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(13.73)-(3.92)-(7.35));
	segmentsAcked = (int) (12.63*(3.04)*(6.83));

} else {
	tcb->m_cWnd = (int) (11.46+(12.99)+(13.5));
	segmentsAcked = (int) (15.61-(13.45)-(11.31)-(9.05));
	tcb->m_segmentSize = (int) (segmentsAcked*(19.78)*(13.92));

}
tcb->m_segmentSize = (int) (17.64+(0.27));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (segmentsAcked+(11.68)+(5.62));
segmentsAcked = (int) (2.83-(19.06)-(5.36));
segmentsAcked = SlowStart (tcb, segmentsAcked);
int ZgzJSKAAwqoNsrFY = (int) (7.15+(5.93));
segmentsAcked = (int) (3.78-(10.02)-(tcb->m_cWnd)-(segmentsAcked));
