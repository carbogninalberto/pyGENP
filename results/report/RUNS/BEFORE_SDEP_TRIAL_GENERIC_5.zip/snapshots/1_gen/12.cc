CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (15.41+(12.5));

} else {
	tcb->m_cWnd = (int) (14.22-(17.04));
	tcb->m_cWnd = (int) (6.83*(15.63)*(segmentsAcked));
	tcb->m_segmentSize = (int) (19.08*(9.0)*(segmentsAcked));

}
segmentsAcked = (int) (3.07+(tcb->m_segmentSize));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (7.34-(segmentsAcked)-(14.12)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (14.54*(5.38)*(segmentsAcked)*(segmentsAcked));
	segmentsAcked = (int) (14.16+(11.56)+(8.24));

}
