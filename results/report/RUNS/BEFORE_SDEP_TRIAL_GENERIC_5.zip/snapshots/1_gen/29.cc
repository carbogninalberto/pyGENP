tcb->m_cWnd = (int) (12.79*(9.14)*(0.57)*(4.96));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
float hsxTjqWszuLscuJh = (float) (10.33*(6.86)*(2.43));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
