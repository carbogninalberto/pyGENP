tcb->m_segmentSize = (int) (5.86/15.17);
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(1.14));
float coRDmWjPHYQwYRGy = (float) (5.79*(7.06)*(4.64));
tcb->m_cWnd = (int) (11.46-(3.24));
tcb->m_segmentSize = (int) (tcb->m_cWnd-(7.47)-(9.01)-(tcb->m_segmentSize));
