if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (1.15*(5.22)*(2.24));

} else {
	tcb->m_segmentSize = (int) (19.7*(14.23));

}
segmentsAcked = (int) (17.38*(6.72));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (12.55+(15.8)+(9.5)+(8.11));
