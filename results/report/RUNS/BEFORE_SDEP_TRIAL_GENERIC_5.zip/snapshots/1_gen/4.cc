CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (7.46/4.99);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((0.27*(tcb->m_cWnd)*(6.25))/8.88);
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (2.2+(9.02)+(tcb->m_segmentSize)+(6.37));
	tcb->m_segmentSize = (int) (2.2*(6.83)*(15.15)*(5.23));
	tcb->m_segmentSize = (int) (segmentsAcked+(19.8)+(5.77));

} else {
	segmentsAcked = (int) (19.09*(7.97)*(14.63)*(tcb->m_cWnd));
	segmentsAcked = (int) (19.67*(6.87));
	tcb->m_segmentSize = (int) (15.31/18.39);

}
