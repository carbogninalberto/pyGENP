if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (13.73/1.34);

} else {
	segmentsAcked = (int) (6.16+(15.85)+(9.48)+(12.55));
	tcb->m_cWnd = (int) (11.39+(14.76)+(16.02));
	tcb->m_cWnd = (int) ((7.94-(4.01)-(7.5))/1.8);

}
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(18.2)-(segmentsAcked));
	segmentsAcked = (int) (1.64+(18.72)+(10.49)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (segmentsAcked*(segmentsAcked)*(8.01));

} else {
	tcb->m_segmentSize = (int) (2.31+(4.74)+(17.92)+(11.05));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_cWnd+(6.37));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (14.26*(tcb->m_segmentSize));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	segmentsAcked = (int) (8.8-(14.64)-(13.9)-(13.67));
	tcb->m_cWnd = (int) (17.35-(7.19));

} else {
	segmentsAcked = (int) (7.82-(11.49));

}
CongestionAvoidance (tcb, segmentsAcked);
