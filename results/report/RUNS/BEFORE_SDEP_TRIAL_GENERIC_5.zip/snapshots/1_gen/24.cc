tcb->m_segmentSize = (int) (tcb->m_cWnd-(19.54));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (14.22*(19.46));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (15.37*(18.45));
if (segmentsAcked == segmentsAcked) {
	tcb->m_cWnd = (int) ((12.86*(tcb->m_segmentSize))/9.01);
	segmentsAcked = (int) (15.38-(0.13)-(7.23));
	segmentsAcked = (int) ((13.19-(4.41))/3.36);

} else {
	tcb->m_cWnd = (int) (8.42*(17.03)*(7.9));
	tcb->m_segmentSize = (int) (2.67+(8.1)+(8.89));

}
