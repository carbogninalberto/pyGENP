CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (18.75*(2.17)*(13.19));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (5.79-(5.19)-(16.24)-(7.26));
tcb->m_cWnd = (int) (15.64*(16.25)*(12.51));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) (1.32*(8.15)*(8.94)*(3.13));
	segmentsAcked = (int) (13.81*(15.29)*(16.68));

} else {
	segmentsAcked = (int) (12.95/4.01);

}
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (6.94+(10.11));

} else {
	tcb->m_segmentSize = (int) (5.87*(tcb->m_segmentSize)*(0.75));
	tcb->m_cWnd = (int) (9.72/18.97);
	tcb->m_segmentSize = (int) (5.34+(5.93));

}
CongestionAvoidance (tcb, segmentsAcked);
