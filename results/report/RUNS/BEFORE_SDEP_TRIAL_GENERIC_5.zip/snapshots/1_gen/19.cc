TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (11.79-(4.37)-(12.47)-(19.05));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int ZdcCdafxFoeTsera = (int) (16.71-(6.01));
tcb->m_cWnd = (int) (12.42/18.18);
