TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_cWnd = (int) (14.47*(18.14)*(7.0));
	tcb->m_cWnd = (int) (6.02/4.53);
	segmentsAcked = (int) ((6.08-(6.74))/8.39);

} else {
	tcb->m_cWnd = (int) ((7.94+(18.43)+(3.91))/10.19);
	tcb->m_segmentSize = (int) (18.14*(3.85)*(12.1)*(15.83));
	tcb->m_cWnd = (int) (9.87+(15.21));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int ePERGdoVsuCzmIdN = (int) (1.81-(tcb->m_segmentSize)-(18.63)-(6.75));
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) (19.55+(12.66));

} else {
	segmentsAcked = (int) (18.31-(4.9)-(5.54)-(3.07));
	ePERGdoVsuCzmIdN = (int) (ePERGdoVsuCzmIdN*(ePERGdoVsuCzmIdN)*(10.04));

}
segmentsAcked = (int) ((14.4*(7.3))/18.98);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
