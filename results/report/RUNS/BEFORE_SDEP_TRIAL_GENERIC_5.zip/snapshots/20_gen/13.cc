if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-19+(14));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (18+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (1+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (9-(-10)-(-8));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-1+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (14-(8)-(5));
segmentsAcked = (int) (-7-(17)-(11));
tcb->m_cWnd = (int) (3+(tcb->m_segmentSize));
segmentsAcked = (int) (13-(-8)-(-11));
segmentsAcked = (int) (14-(-9)-(10));
segmentsAcked = (int) (16-(4)-(1));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-8-(5)-(5));
segmentsAcked = (int) (1-(-13)-(-13));
segmentsAcked = (int) (1-(12)-(-4));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (19+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (14-(17)-(4));
segmentsAcked = (int) (-12-(5)-(1));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (10-(-1)-(-10));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (6-(-7)-(-19));
segmentsAcked = (int) (-8-(16)-(-9));
segmentsAcked = (int) (12-(14)-(-16));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (9-(-11)-(13));
