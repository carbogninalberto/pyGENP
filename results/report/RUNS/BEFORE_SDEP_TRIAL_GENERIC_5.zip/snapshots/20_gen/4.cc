if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-2+(-12));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-16+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-3+(tcb->m_segmentSize));
segmentsAcked = (int) (9-(-5)-(18));
tcb->m_cWnd = (int) (8+(tcb->m_segmentSize));
segmentsAcked = (int) (-20-(16)-(-13));
tcb->m_cWnd = (int) (-8+(tcb->m_segmentSize));
segmentsAcked = (int) (-4-(2)-(14));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (18-(-9)-(-20));
segmentsAcked = (int) (-5-(11)-(-4));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (4+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-4-(-16)-(-4));
segmentsAcked = (int) (-4-(-1)-(-1));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (8-(-17)-(-19));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-19-(8)-(-15));
segmentsAcked = (int) (-7-(-5)-(-11));
segmentsAcked = (int) (-20-(-18)-(-7));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-7-(-14)-(16));
