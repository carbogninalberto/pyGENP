if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (-2+(12));
tcb->m_cWnd = (int) (18+(tcb->m_segmentSize));
segmentsAcked = (int) (-18-(-19)-(-6));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (10-(4)-(-18));
tcb->m_cWnd = (int) (-19+(tcb->m_segmentSize));
segmentsAcked = (int) (1-(10)-(-14));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-5+(tcb->m_segmentSize));
segmentsAcked = (int) (6-(-17)-(-14));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-17-(-15)-(-7));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (1-(3)-(-13));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (15-(-8)-(8));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (16-(-6)-(4));
tcb->m_cWnd = (int) (-10+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (14-(-15)-(-10));
segmentsAcked = (int) (3-(11)-(-13));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (2-(-13)-(-6));
segmentsAcked = (int) (14-(2)-(3));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (2-(5)-(-5));
segmentsAcked = (int) (-20-(-9)-(-13));
segmentsAcked = (int) (18-(-7)-(17));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-9-(-1)-(-14));
segmentsAcked = (int) (-15-(-3)-(14));
