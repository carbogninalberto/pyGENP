if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (19+(-2));
tcb->m_cWnd = (int) (-10+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-17+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-12+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-20-(5)-(19));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-8-(-14)-(1));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (10-(14)-(-18));
tcb->m_cWnd = (int) (-12+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (14-(6)-(7));
segmentsAcked = (int) (12-(1)-(18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-13-(-18)-(13));
segmentsAcked = (int) (18-(12)-(-8));
segmentsAcked = (int) (9-(-11)-(-18));
segmentsAcked = (int) (16-(16)-(-13));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (16-(10)-(-2));
segmentsAcked = (int) (-10-(18)-(-12));
segmentsAcked = (int) (6-(-8)-(6));
segmentsAcked = (int) (5-(-4)-(13));
segmentsAcked = (int) (-8-(4)-(1));
segmentsAcked = (int) (19-(15)-(-2));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (18-(-12)-(17));
segmentsAcked = (int) (-14-(-1)-(-14));
segmentsAcked = (int) (-4-(-16)-(-7));
segmentsAcked = (int) (-15-(6)-(-3));
