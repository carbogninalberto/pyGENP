if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (17.86-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (10.21/15.59);

} else {
	tcb->m_segmentSize = (int) (9.91/18.61);
	segmentsAcked = (int) (3.14/7.41);

}
tcb->m_cWnd = (int) (17+(8));
tcb->m_cWnd = (int) (-4+(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (6+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (-11+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (12+(tcb->m_segmentSize));
segmentsAcked = (int) (5-(-3)-(18));
segmentsAcked = (int) (-18-(11)-(6));
segmentsAcked = (int) (-8-(18)-(2));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (14-(-11)-(-18));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (16-(9)-(-15));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-12-(-15)-(10));
segmentsAcked = (int) (-9-(-17)-(-20));
segmentsAcked = (int) (-1-(-17)-(13));
segmentsAcked = (int) (2-(-13)-(2));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (6-(-6)-(-10));
segmentsAcked = (int) (-13-(18)-(8));
