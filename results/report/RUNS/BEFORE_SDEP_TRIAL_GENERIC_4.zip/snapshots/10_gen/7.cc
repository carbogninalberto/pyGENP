int JfgOnMmlbgpyQCCB = (int) (80.78453911205384-(-24.40262163693177)-(-72.63078842731633));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
