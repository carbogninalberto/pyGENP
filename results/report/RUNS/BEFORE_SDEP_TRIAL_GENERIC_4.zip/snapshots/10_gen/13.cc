int JfgOnMmlbgpyQCCB = (int) (-68.83687974809934*(52.48878622097959)*(34.400955468963645)*(17.113515203709767));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
