TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int JfgOnMmlbgpyQCCB = (int) (49.45074242643034*(-32.00922531587497));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
