TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int JfgOnMmlbgpyQCCB = (int) ((8.24*(16.87)*(JfgOnMmlbgpyQCCB)*(tcb->m_segmentSize))/78.68077669048418);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
