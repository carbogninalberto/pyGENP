int JfgOnMmlbgpyQCCB = (int) (-57.59531691103648/28.78138495059335);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
