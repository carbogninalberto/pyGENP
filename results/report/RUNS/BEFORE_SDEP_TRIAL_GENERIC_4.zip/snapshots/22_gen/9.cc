int JfgOnMmlbgpyQCCB = (int) (12.03370644782133*(-86.60615130083598)*(87.62664490337937)*(-1.5477634483714695));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd == JfgOnMmlbgpyQCCB) {
	JfgOnMmlbgpyQCCB = (int) (17.02-(14.0)-(17.53)-(18.52));
	tcb->m_segmentSize = (int) (1.71/8.32);

} else {
	JfgOnMmlbgpyQCCB = (int) ((3.71-(segmentsAcked)-(6.56)-(segmentsAcked))/6.26);
	segmentsAcked = (int) (segmentsAcked+(1.66));

}
tcb->m_cWnd = (int) (-71.06476874108199+(79.09749004987029));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-34.4311997617603*(-75.74861968679774));
tcb->m_cWnd = (int) (68.8674343241805+(81.55253857659119));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (36.26181983968473*(5.703528135091702));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
if (tcb->m_cWnd == JfgOnMmlbgpyQCCB) {
	JfgOnMmlbgpyQCCB = (int) (17.02-(14.0)-(17.53)-(18.52));
	tcb->m_segmentSize = (int) (1.71/8.32);

} else {
	JfgOnMmlbgpyQCCB = (int) ((3.71-(segmentsAcked)-(6.56)-(segmentsAcked))/6.26);
	segmentsAcked = (int) (segmentsAcked+(1.66));

}
tcb->m_segmentSize = (int) (-78.44712303923033*(98.93863143438125));
tcb->m_segmentSize = (int) (94.50171179337539*(16.311087657821005));
tcb->m_cWnd = (int) (-41.67520785796375+(-94.64741090879394));
tcb->m_segmentSize = (int) (-32.0308700872682*(7.6817183842358645));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
tcb->m_segmentSize = (int) (21.202516245736902*(-96.25303509532182));
