TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int JfgOnMmlbgpyQCCB = (int) (-50.440624148659154*(82.62367926665908)*(-27.36085235161714)*(19.737143142789165));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd == JfgOnMmlbgpyQCCB) {
	JfgOnMmlbgpyQCCB = (int) (17.02-(14.0)-(17.53)-(18.52));
	tcb->m_segmentSize = (int) (1.71/8.32);

} else {
	JfgOnMmlbgpyQCCB = (int) ((3.71-(segmentsAcked)-(6.56)-(segmentsAcked))/6.26);
	segmentsAcked = (int) (segmentsAcked+(1.66));

}
tcb->m_cWnd = (int) (56.31142211755767+(-64.09710387429782));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-41.44373007067532*(14.692665717707314));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
if (tcb->m_cWnd == JfgOnMmlbgpyQCCB) {
	JfgOnMmlbgpyQCCB = (int) (17.02-(14.0)-(17.53)-(18.52));
	tcb->m_segmentSize = (int) (1.71/8.32);

} else {
	JfgOnMmlbgpyQCCB = (int) ((3.71-(segmentsAcked)-(6.56)-(segmentsAcked))/6.26);
	segmentsAcked = (int) (segmentsAcked+(1.66));

}
tcb->m_segmentSize = (int) (80.20248100262995*(52.71525434119957));
tcb->m_cWnd = (int) (-34.41352979032885+(44.302864948173976));
tcb->m_segmentSize = (int) (-24.067903004246816*(-32.46375662964853));
tcb->m_segmentSize = (int) (50.80597322877523*(-17.96657952955168));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
tcb->m_segmentSize = (int) (-60.938221361461295*(-37.198570454840606));
if (tcb->m_cWnd == JfgOnMmlbgpyQCCB) {
	JfgOnMmlbgpyQCCB = (int) (17.02-(14.0)-(17.53)-(18.52));
	tcb->m_segmentSize = (int) (1.71/8.32);

} else {
	JfgOnMmlbgpyQCCB = (int) ((3.71-(segmentsAcked)-(6.56)-(segmentsAcked))/6.26);
	segmentsAcked = (int) (segmentsAcked+(1.66));

}
tcb->m_segmentSize = (int) (5.3051538152241875*(23.891011561287613));
tcb->m_cWnd = (int) (-69.88552619762858+(28.07775942381832));
tcb->m_segmentSize = (int) (80.70695047965498*(71.64389029952753));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
tcb->m_segmentSize = (int) (14.423568971501922*(1.064606686021989));
