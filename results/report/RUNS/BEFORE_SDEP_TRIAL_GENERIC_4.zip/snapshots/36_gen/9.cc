TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int JfgOnMmlbgpyQCCB = (int) (65.74486902462033*(-28.16190165288262)*(13.36987600556931)*(-94.19546497071767));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd == JfgOnMmlbgpyQCCB) {
	JfgOnMmlbgpyQCCB = (int) (17.02-(14.0)-(17.53)-(18.52));
	tcb->m_segmentSize = (int) (1.71/8.32);

} else {
	JfgOnMmlbgpyQCCB = (int) ((3.71-(segmentsAcked)-(6.56)-(segmentsAcked))/6.26);
	segmentsAcked = (int) (segmentsAcked+(1.66));

}
tcb->m_cWnd = (int) (-36.481700768676426+(-94.0608046122731));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-72.81348171342401*(35.7982543127313));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
if (tcb->m_cWnd == JfgOnMmlbgpyQCCB) {
	JfgOnMmlbgpyQCCB = (int) (17.02-(14.0)-(17.53)-(18.52));
	tcb->m_segmentSize = (int) (1.71/8.32);

} else {
	JfgOnMmlbgpyQCCB = (int) ((3.71-(segmentsAcked)-(6.56)-(segmentsAcked))/6.26);
	segmentsAcked = (int) (segmentsAcked+(1.66));

}
tcb->m_segmentSize = (int) (-20.67510119267982*(-29.970768883923697));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (81.40134670282825+(87.69228019174724));
if (tcb->m_cWnd == JfgOnMmlbgpyQCCB) {
	JfgOnMmlbgpyQCCB = (int) (17.02-(14.0)-(17.53)-(18.52));
	tcb->m_segmentSize = (int) (1.71/8.32);

} else {
	JfgOnMmlbgpyQCCB = (int) ((3.71-(segmentsAcked)-(6.56)-(segmentsAcked))/6.26);
	segmentsAcked = (int) (segmentsAcked+(1.66));

}
tcb->m_segmentSize = (int) (54.895984260296416*(-90.21865887592051));
tcb->m_cWnd = (int) (-89.13749401168982+(85.8239675015661));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-67.53376739870929*(-89.62910855181023));
tcb->m_segmentSize = (int) (33.74925635015714*(-32.78551054848499));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (6.348173249512172*(62.667193450968966));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
tcb->m_cWnd = (int) (-6.149863074650725+(84.17677254038071));
if (tcb->m_cWnd == JfgOnMmlbgpyQCCB) {
	JfgOnMmlbgpyQCCB = (int) (17.02-(14.0)-(17.53)-(18.52));
	tcb->m_segmentSize = (int) (1.71/8.32);

} else {
	JfgOnMmlbgpyQCCB = (int) ((3.71-(segmentsAcked)-(6.56)-(segmentsAcked))/6.26);
	segmentsAcked = (int) (segmentsAcked+(1.66));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
tcb->m_segmentSize = (int) (-39.69482184402029*(11.757706468318418));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-29.284412925526482+(42.71592407240837));
tcb->m_segmentSize = (int) (-27.178270813956317*(-19.97299630196727));
tcb->m_segmentSize = (int) (-40.095346215998084*(90.99497872220331));
tcb->m_segmentSize = (int) (66.96020273886427*(73.44565586261683));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (6.666366438218645*(26.297621766019248));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
if (tcb->m_cWnd == JfgOnMmlbgpyQCCB) {
	JfgOnMmlbgpyQCCB = (int) (17.02-(14.0)-(17.53)-(18.52));
	tcb->m_segmentSize = (int) (1.71/8.32);

} else {
	JfgOnMmlbgpyQCCB = (int) ((3.71-(segmentsAcked)-(6.56)-(segmentsAcked))/6.26);
	segmentsAcked = (int) (segmentsAcked+(1.66));

}
tcb->m_segmentSize = (int) (95.59603419722399*(28.71900927100492));
tcb->m_cWnd = (int) (54.94236536675618+(42.39276763445969));
tcb->m_segmentSize = (int) (-86.59248626226312*(-73.70828308266464));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
tcb->m_segmentSize = (int) (-91.24132103164344*(-54.47957990101746));
