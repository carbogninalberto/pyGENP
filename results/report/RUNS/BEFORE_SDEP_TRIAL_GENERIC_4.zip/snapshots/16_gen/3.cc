int JfgOnMmlbgpyQCCB = (int) (78.14938813476789*(82.63762504647454)*(74.94764015215196)*(8.728453950387902));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
