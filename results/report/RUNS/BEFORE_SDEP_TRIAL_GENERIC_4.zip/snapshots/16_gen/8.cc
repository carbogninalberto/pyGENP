int JfgOnMmlbgpyQCCB = (int) (51.80852552017464*(77.65952590918133)*(-2.1321456263928127)*(65.18895659735361));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
