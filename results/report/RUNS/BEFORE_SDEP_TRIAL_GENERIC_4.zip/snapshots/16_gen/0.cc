TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int JfgOnMmlbgpyQCCB = (int) (-87.08993594596461*(99.77757541338082)*(-6.735214576775192)*(-22.82325679456261));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
