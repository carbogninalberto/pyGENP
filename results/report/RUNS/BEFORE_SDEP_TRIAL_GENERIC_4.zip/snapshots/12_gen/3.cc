TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int JfgOnMmlbgpyQCCB = (int) (71.64135750946048*(-98.16569364142649));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
