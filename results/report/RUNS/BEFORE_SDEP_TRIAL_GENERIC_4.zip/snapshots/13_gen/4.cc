int JfgOnMmlbgpyQCCB = (int) (-12.353272007404954*(-99.547801706792)*(84.42122796435717)*(-53.44687452775618));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd == JfgOnMmlbgpyQCCB) {
	JfgOnMmlbgpyQCCB = (int) (17.02-(14.0)-(17.53)-(18.52));
	tcb->m_segmentSize = (int) (1.71/8.32);

} else {
	JfgOnMmlbgpyQCCB = (int) ((3.71-(segmentsAcked)-(6.56)-(segmentsAcked))/6.26);
	segmentsAcked = (int) (segmentsAcked+(1.66));

}
tcb->m_cWnd = (int) (23.928138401566756+(-83.76820842855892));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-33.26277915189104*(8.42929570505379));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
if (tcb->m_cWnd == JfgOnMmlbgpyQCCB) {
	JfgOnMmlbgpyQCCB = (int) (17.02-(14.0)-(17.53)-(18.52));
	tcb->m_segmentSize = (int) (1.71/8.32);

} else {
	JfgOnMmlbgpyQCCB = (int) ((3.71-(segmentsAcked)-(6.56)-(segmentsAcked))/6.26);
	segmentsAcked = (int) (segmentsAcked+(1.66));

}
tcb->m_segmentSize = (int) (42.714488687146854*(62.63307169355778));
tcb->m_cWnd = (int) (-19.097383433025115+(23.299705570009735));
tcb->m_segmentSize = (int) (-38.14963378507228*(16.433766562440155));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
tcb->m_segmentSize = (int) (72.50130668262358*(72.65082977885854));
