TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int JfgOnMmlbgpyQCCB = (int) (24.86071768283618*(22.60546905063869)*(58.647620209628144)*(-96.29432168116185));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
