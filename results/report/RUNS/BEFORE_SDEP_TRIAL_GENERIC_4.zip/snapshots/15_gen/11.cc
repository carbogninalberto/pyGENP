int JfgOnMmlbgpyQCCB = (int) (18.438961650256914*(49.479336044814545)*(87.47458945136404)*(16.89113242003056));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
