int JfgOnMmlbgpyQCCB = (int) (-25.94173742004206*(40.05170801916711)*(49.36684886032319)*(-3.289670371658076));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
