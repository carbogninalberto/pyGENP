int JfgOnMmlbgpyQCCB = (int) (-22.43267188720462*(92.94173934453187)*(-4.0774744204690165)*(-83.57655417251944));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
