int JfgOnMmlbgpyQCCB = (int) (10.638971975207596*(67.48297669996842));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
