int JfgOnMmlbgpyQCCB = (int) (6.535929563351473*(-62.962371049929345)*(-14.181932121746655)*(43.302802476506685));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
