int JfgOnMmlbgpyQCCB = (int) (-45.951280075540794-(69.61705577165739)-(-14.299466922557741)-(84.69093047933475));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
