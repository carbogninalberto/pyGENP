int JfgOnMmlbgpyQCCB = (int) (-58.248649343395286/(tcb->m_segmentSize+(11.11)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
