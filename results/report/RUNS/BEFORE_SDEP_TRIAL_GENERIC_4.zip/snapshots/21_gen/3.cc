int JfgOnMmlbgpyQCCB = (int) (70.53933988731166-(42.3388816461686));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
