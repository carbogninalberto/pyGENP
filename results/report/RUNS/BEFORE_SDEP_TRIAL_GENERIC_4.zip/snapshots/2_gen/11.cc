float duySybTitQoJAWzn = (float) (89.87675115691786-(-94.6735375680273)-(72.22456453355045));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (4.96+(15.55)+(11.39)+(12.57));
	tcb->m_segmentSize = (int) (9.01*(11.61));
	tcb->m_segmentSize = (int) (12.83/1);

} else {
	tcb->m_cWnd = (int) (1.03+(tcb->m_cWnd));

}
