int JfgOnMmlbgpyQCCB = (int) (-21.30334034043196+(-89.07173426316317)+(-36.37302450167261));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd == JfgOnMmlbgpyQCCB) {
	JfgOnMmlbgpyQCCB = (int) (17.02-(14.0)-(17.53)-(18.52));
	tcb->m_segmentSize = (int) (1.71/8.32);

} else {
	JfgOnMmlbgpyQCCB = (int) ((3.71-(segmentsAcked)-(6.56)-(segmentsAcked))/6.26);
	segmentsAcked = (int) (segmentsAcked+(1.66));

}
tcb->m_cWnd = (int) (-74.27122875323457+(-87.44958822855318));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
if (tcb->m_cWnd == JfgOnMmlbgpyQCCB) {
	JfgOnMmlbgpyQCCB = (int) (17.02-(14.0)-(17.53)-(18.52));
	tcb->m_segmentSize = (int) (1.71/8.32);

} else {
	JfgOnMmlbgpyQCCB = (int) ((3.71-(segmentsAcked)-(6.56)-(segmentsAcked))/6.26);
	segmentsAcked = (int) (segmentsAcked+(1.66));

}
tcb->m_segmentSize = (int) (-9.858361150756068*(-44.42693163745861));
tcb->m_cWnd = (int) (44.33584535712521+(-27.551562831405604));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((16.06*(tcb->m_cWnd)*(9.92)*(tcb->m_cWnd))/10.98);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(15.35));
	tcb->m_segmentSize = (int) (9.22+(0.62)+(12.09));

}
tcb->m_segmentSize = (int) (-6.001478981941361*(-66.1986217820623));
