float duySybTitQoJAWzn = (float) (42.05358025953555-(-30.90057383674973)-(96.95785804808187));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (4.96+(15.55)+(11.39)+(12.57));
	tcb->m_segmentSize = (int) (9.01*(11.61));
	tcb->m_segmentSize = (int) (12.83/1);

} else {
	tcb->m_cWnd = (int) (1.03+(tcb->m_cWnd));

}
if (tcb->m_segmentSize != duySybTitQoJAWzn) {
	segmentsAcked = (int) ((14.21-(3.34)-(segmentsAcked))/5.2);
	tcb->m_segmentSize = (int) (0.87*(14.85)*(17.15));

} else {
	segmentsAcked = (int) (4.2-(2.24));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	duySybTitQoJAWzn = (float) (13.56/11.85);
	segmentsAcked = (int) (13.78/10.72);
	duySybTitQoJAWzn = (float) (3.31/15.42);

} else {
	duySybTitQoJAWzn = (float) (9.81+(18.74)+(4.93)+(2.53));
	tcb->m_cWnd = (int) (11.6*(7.28)*(5.66)*(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (10.52+(6.08)+(6.29));

}
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (4.96+(15.55)+(11.39)+(12.57));
	tcb->m_segmentSize = (int) (9.01*(11.61));
	tcb->m_segmentSize = (int) (12.83/1);

} else {
	tcb->m_cWnd = (int) (1.03+(tcb->m_cWnd));

}
tcb->m_segmentSize = (int) (78.94178463152153-(-22.1875628224724)-(-22.29035771416588));
if (tcb->m_segmentSize != duySybTitQoJAWzn) {
	segmentsAcked = (int) ((14.21-(3.34)-(segmentsAcked))/5.2);
	tcb->m_segmentSize = (int) (0.87*(14.85)*(17.15));

} else {
	segmentsAcked = (int) (4.2-(2.24));

}
if (segmentsAcked <= tcb->m_cWnd) {
	duySybTitQoJAWzn = (float) (13.56/11.85);
	segmentsAcked = (int) (13.78/10.72);
	duySybTitQoJAWzn = (float) (3.31/15.42);

} else {
	duySybTitQoJAWzn = (float) (9.81+(18.74)+(4.93)+(2.53));
	tcb->m_cWnd = (int) (11.6*(7.28)*(5.66)*(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (10.52+(6.08)+(6.29));

}
tcb->m_segmentSize = (int) (-3.7858716441888873-(64.80202771081366)-(-38.56227397752667));
