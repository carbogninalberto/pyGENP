int JfgOnMmlbgpyQCCB = (int) (73.49598641195627*(-29.830123505700485)*(-95.90138493885347)*(2.365542755533994));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
