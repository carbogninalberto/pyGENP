int JfgOnMmlbgpyQCCB = (int) (52.10589562984157*(77.92586616666043)*(0.8036882349952208)*(-97.97038017767088));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
