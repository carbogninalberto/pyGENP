int JfgOnMmlbgpyQCCB = (int) (54.50848612634317+(-98.96274400640561)+(68.92393369435811));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
