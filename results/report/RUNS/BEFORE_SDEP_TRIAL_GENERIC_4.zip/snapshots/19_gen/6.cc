int JfgOnMmlbgpyQCCB = (int) (79.37547283844111*(26.73123926903122)*(-40.77864426164799)*(71.12646737386163));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
