int JfgOnMmlbgpyQCCB = (int) ((8.24*(16.87)*(JfgOnMmlbgpyQCCB)*(tcb->m_segmentSize))/-4.122635319568573);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
