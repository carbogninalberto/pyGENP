int JfgOnMmlbgpyQCCB = (int) (-56.2946499948187*(-37.02268942704829)*(-29.26418839152973)*(40.20584761772784));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
