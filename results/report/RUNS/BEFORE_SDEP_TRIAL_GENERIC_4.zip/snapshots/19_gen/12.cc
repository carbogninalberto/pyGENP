int JfgOnMmlbgpyQCCB = (int) (-96.41800363078244*(65.60780699135123)*(-45.14562851867652)*(6.801853981400143));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
