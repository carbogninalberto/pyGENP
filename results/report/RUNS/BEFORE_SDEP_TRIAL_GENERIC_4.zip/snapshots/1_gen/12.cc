if (tcb->m_segmentSize != tcb->m_segmentSize) {
	segmentsAcked = (int) ((1.47+(16.78))/19.24);
	tcb->m_segmentSize = (int) (6.98/1.49);
	tcb->m_cWnd = (int) (6.34-(segmentsAcked));

} else {
	segmentsAcked = (int) (19.11/4.61);

}
tcb->m_segmentSize = (int) (15.02-(18.35));
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_cWnd = (int) (3.8/5.47);
	tcb->m_cWnd = (int) (4.43+(14.58)+(18.55));
	tcb->m_segmentSize = (int) (13.07/17.74);

} else {
	tcb->m_cWnd = (int) (0.31+(15.55)+(13.33));

}
tcb->m_segmentSize = (int) (5.05+(17.49)+(17.95));
tcb->m_segmentSize = (int) (6.42*(7.3));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
