if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) ((tcb->m_cWnd*(10.88))/10.16);

} else {
	tcb->m_cWnd = (int) (5.38*(segmentsAcked)*(0.65));
	tcb->m_segmentSize = (int) (12.17/9.38);
	tcb->m_segmentSize = (int) (1/3.32);

}
tcb->m_segmentSize = (int) (3.09+(tcb->m_segmentSize)+(7.7)+(12.92));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (3.24/8.52);
	segmentsAcked = (int) (segmentsAcked*(6.83)*(19.17)*(18.53));

} else {
	tcb->m_segmentSize = (int) (16.5/12.77);
	tcb->m_cWnd = (int) (8.34/(19.15+(10.91)));
	segmentsAcked = (int) (segmentsAcked*(3.06)*(13.55)*(17.27));

}
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (8.36*(16.24));
	tcb->m_cWnd = (int) (17.97*(12.84)*(17.2)*(tcb->m_cWnd));
	segmentsAcked = (int) ((14.2-(3.89)-(16.39))/17.06);

} else {
	tcb->m_segmentSize = (int) (8.47/8.01);
	segmentsAcked = (int) (1/8.66);

}
tcb->m_segmentSize = (int) (5.83/18.59);
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (1.83*(tcb->m_segmentSize)*(3.75));
	segmentsAcked = (int) ((8.6-(11.35))/17.14);
	segmentsAcked = (int) (4.6-(tcb->m_segmentSize)-(16.75)-(12.97));

} else {
	tcb->m_segmentSize = (int) (7.22-(segmentsAcked)-(0.52)-(16.71));
	tcb->m_segmentSize = (int) (0.69+(12.43));
	segmentsAcked = (int) (10.44/2.8);

}
