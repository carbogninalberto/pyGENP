int gezpSwtfzQndFUik = (int) (15.13*(6.67));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_cWnd+(14.21)+(19.58)+(8.53));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
gezpSwtfzQndFUik = (int) (16.35/6.07);
segmentsAcked = SlowStart (tcb, segmentsAcked);
