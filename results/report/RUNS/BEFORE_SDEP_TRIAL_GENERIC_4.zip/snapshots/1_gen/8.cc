int uPiMGcEJqJADTeLX = (int) (tcb->m_segmentSize+(4.59)+(2.19)+(18.67));
if (tcb->m_segmentSize < segmentsAcked) {
	uPiMGcEJqJADTeLX = (int) (18.55*(0.54)*(1.99)*(12.85));
	uPiMGcEJqJADTeLX = (int) (8.26+(0.4));

} else {
	uPiMGcEJqJADTeLX = (int) (1.42*(tcb->m_cWnd)*(10.33));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (2.59/12.51);
	tcb->m_cWnd = (int) (uPiMGcEJqJADTeLX+(17.12)+(5.52));
	tcb->m_segmentSize = (int) (11.07+(tcb->m_cWnd)+(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (4.01*(7.88)*(3.42)*(7.95));
	tcb->m_cWnd = (int) ((8.7*(tcb->m_segmentSize)*(6.97))/1.1);
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(15.94)-(uPiMGcEJqJADTeLX)-(tcb->m_cWnd));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (11.64*(segmentsAcked)*(16.23));
