if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (19.94+(19.14));
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(tcb->m_segmentSize));
	segmentsAcked = (int) (19.5/13.91);

} else {
	tcb->m_cWnd = (int) (1.0-(18.74)-(17.04)-(2.11));
	segmentsAcked = (int) (16.46+(11.65)+(4.9)+(11.75));

}
tcb->m_cWnd = (int) (13.04-(18.48));
tcb->m_cWnd = (int) (segmentsAcked+(9.1)+(segmentsAcked));
float trdOckvGnBQtVteC = (float) (3.61+(18.94)+(tcb->m_segmentSize)+(7.89));
trdOckvGnBQtVteC = (float) (tcb->m_segmentSize-(14.7)-(15.07));
tcb->m_cWnd = (int) (7.08/1.77);
trdOckvGnBQtVteC = (float) (7.82-(4.7)-(0.66));
