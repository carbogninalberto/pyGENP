if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/78.85);

} else {
	tcb->m_cWnd = (int) (2.996*(55.955)*(23.316)*(55.687));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
