tcb->m_segmentSize = (int) ((((14.871*(tcb->m_cWnd)*(30.265)*(tcb->m_segmentSize)*(23.232)*(53.509)*(75.905)*(22.165)))+(86.119)+(0.1)+(25.373)+(14.004))/((54.077)+(9.128)+(77.848)));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((15.683)+(26.731)+(0.1)+((70.509+(45.863)+(48.2)+(4.273)+(12.165)+(75.843)+(tcb->m_segmentSize)+(2.037)+(73.131)))+(0.1))/((15.378)));
	tcb->m_cWnd = (int) ((((4.015+(91.17)+(7.041)))+(0.1)+(64.584)+(15.678)+(0.1)+(13.919))/((85.775)+(36.588)+(97.63)));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (9.306-(71.142)-(43.415)-(tcb->m_cWnd)-(44.611)-(segmentsAcked)-(43.5));
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(37.717)+(tcb->m_segmentSize)+(41.889));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (4.719+(10.978)+(83.09)+(90.052)+(segmentsAcked));
