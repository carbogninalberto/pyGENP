int TQKoTgSQggyOWiJR = (int) (37.39*(-65.296)*(-82.878)*(-87.882)*(-21.684)*(24.277));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-40.148+(6.352)+(66.025)+(-21.626)+(-97.416)+(71.905)+(-5.402));
CongestionAvoidance (tcb, segmentsAcked);
