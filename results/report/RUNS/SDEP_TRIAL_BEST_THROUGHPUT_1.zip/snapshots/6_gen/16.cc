float JTglLznbYVZSaNEU = (float) (0.1/0.1);
segmentsAcked = (int) (0.1/36.493);
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	segmentsAcked = (int) ((74.324*(53.724)*(9.499)*(tcb->m_segmentSize)*(59.764)*(64.458)*(59.101)*(30.455)*(36.405))/54.002);
	tcb->m_cWnd = (int) (1.042-(14.265)-(tcb->m_segmentSize)-(16.941));

} else {
	segmentsAcked = (int) (64.649*(57.041)*(27.516)*(11.377));

}
CongestionAvoidance (tcb, segmentsAcked);
int CqSTWaOCxNCmDATU = (int) (27.493-(59.553));
ReduceCwnd (tcb);
