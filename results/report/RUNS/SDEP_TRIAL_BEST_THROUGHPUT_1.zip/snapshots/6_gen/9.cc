float hQgcTaMNGffXQSgJ = (float) 82.406;
segmentsAcked = (int) (-80.526+(-45.071)+(-13.299)+(26.519)+(-28.051)+(-64.259)+(-93.365));
int ectxVzAkQqxHtQwM = (int) 23.04;
