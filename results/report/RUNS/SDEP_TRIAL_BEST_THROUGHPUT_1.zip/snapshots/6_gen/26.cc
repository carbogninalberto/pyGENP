CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (2.018+(tcb->m_cWnd)+(45.439));

} else {
	tcb->m_ssThresh = (int) (86.903*(56.707)*(51.035)*(96.111)*(95.411));

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (73.012-(9.156)-(59.279)-(44.735)-(94.639));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (94.086-(37.714)-(59.02)-(37.137)-(89.596)-(32.044)-(45.53));
	tcb->m_segmentSize = (int) (26.807*(59.874)*(60.975)*(tcb->m_cWnd));

}
