if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_segmentSize = (int) (65.921*(56.013));

} else {
	tcb->m_segmentSize = (int) (54.978+(64.957));

}
tcb->m_cWnd = (int) (0.282-(34.127)-(63.823)-(tcb->m_cWnd)-(79.284));
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/37.952);

} else {
	tcb->m_cWnd = (int) (73.176+(17.34)+(16.114)+(86.793)+(60.688)+(46.805)+(35.89)+(60.927)+(tcb->m_cWnd));

}
tcb->m_ssThresh = (int) (93.957+(56.007)+(tcb->m_cWnd)+(15.622)+(45.106));
tcb->m_segmentSize = (int) (43.828+(62.123));
