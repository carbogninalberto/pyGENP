if (tcb->m_ssThresh <= tcb->m_cWnd) {
	segmentsAcked = (int) (64.321*(82.534)*(99.18)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (79.691-(tcb->m_cWnd)-(36.309)-(97.377)-(84.569)-(tcb->m_segmentSize)-(98.187)-(33.19)-(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (((0.1)+(45.568)+(93.379)+(38.405))/((52.186)+(0.1)+(0.1)+(15.414)));

}
tcb->m_segmentSize = (int) (segmentsAcked+(tcb->m_segmentSize)+(36.414)+(51.371)+(16.683)+(tcb->m_segmentSize)+(6.932));
tcb->m_ssThresh = (int) (57.136*(tcb->m_cWnd)*(5.314)*(18.825)*(94.144)*(57.468));
ReduceCwnd (tcb);
int FAniMHZvmgDaMyix = (int) (56.75+(84.79)+(21.333)+(76.901)+(62.468)+(tcb->m_segmentSize)+(tcb->m_ssThresh));
