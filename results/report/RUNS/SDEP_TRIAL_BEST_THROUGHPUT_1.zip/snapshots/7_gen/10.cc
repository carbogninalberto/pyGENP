int TQKoTgSQggyOWiJR = (int) (67.453*(79.69)*(30.396)*(-85.143)*(11.544)*(54.47));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (73.787+(71.739)+(3.949)+(1.357)+(-69.026)+(44.022)+(-88.387));
CongestionAvoidance (tcb, segmentsAcked);
