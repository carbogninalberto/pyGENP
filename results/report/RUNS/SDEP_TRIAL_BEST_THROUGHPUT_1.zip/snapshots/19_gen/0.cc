if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (97.39/0.1);

} else {
	segmentsAcked = (int) (30.681*(8.729)*(2.673)*(64.489)*(tcb->m_cWnd)*(71.602)*(95.801)*(27.915)*(28.441));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
float FXCKdeQQuqgiINHy = (float) (1.865+(70.617)+(-74.999)+(-54.288)+(-14.924)+(83.57));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (91.62-(-80.305)-(-70.632)-(-61.934)-(-34.482)-(26.043));
