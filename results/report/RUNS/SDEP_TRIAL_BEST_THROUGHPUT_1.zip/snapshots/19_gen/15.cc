CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
float iMZncosKJDrnnspp = (float) (29.579*(94.721)*(tcb->m_segmentSize)*(64.638)*(29.122)*(95.313)*(91.125)*(88.871));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(87.948)*(98.4));
	tcb->m_segmentSize = (int) (iMZncosKJDrnnspp*(52.302)*(tcb->m_cWnd)*(95.851)*(36.417));

} else {
	tcb->m_ssThresh = (int) (63.23+(88.096)+(35.365)+(76.57));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	iMZncosKJDrnnspp = (float) (iMZncosKJDrnnspp-(93.453)-(47.518)-(99.976));

} else {
	iMZncosKJDrnnspp = (float) (((92.843)+(0.1)+((tcb->m_cWnd+(61.363)+(13.922)+(tcb->m_segmentSize)+(98.297)+(51.321)+(segmentsAcked)+(22.981)+(iMZncosKJDrnnspp)))+(20.916))/((0.1)+(52.619)+(0.1)+(0.1)+(0.1)));
	tcb->m_ssThresh = (int) (segmentsAcked*(5.301)*(tcb->m_segmentSize)*(51.018)*(1.256)*(59.408));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (21.792-(36.186)-(69.589)-(tcb->m_cWnd)-(54.079)-(29.652));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (11.265*(15.771)*(34.67)*(5.637)*(68.599)*(21.399)*(67.796));

}
ReduceCwnd (tcb);
