if (tcb->m_cWnd <= tcb->m_ssThresh) {
	segmentsAcked = (int) (29.775*(43.25)*(28.812)*(31.531)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(48.003));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) ((34.732-(41.358)-(60.257)-(31.515)-(7.986)-(89.287))/23.325);
	tcb->m_ssThresh = (int) (47.386-(32.136)-(tcb->m_ssThresh));

}
tcb->m_segmentSize = (int) (57.091/0.1);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (5.192-(23.854));

} else {
	tcb->m_ssThresh = (int) (48.134-(5.224)-(segmentsAcked)-(39.539)-(40.232)-(40.26)-(53.942)-(segmentsAcked));

}
