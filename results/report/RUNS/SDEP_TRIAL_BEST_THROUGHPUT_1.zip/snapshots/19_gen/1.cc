int tfXsrECyqkqMBgOX = (int) 61.957;
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (87.416-(86.108)-(28.72)-(90.752)-(58.966)-(49.261));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (21.008*(72.992));
	tcb->m_segmentSize = (int) (17.145-(94.719)-(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
