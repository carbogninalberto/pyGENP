tcb->m_segmentSize = (int) (77.61-(26.916)-(tcb->m_segmentSize)-(15.564)-(1.312));
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((0.1)+(37.476)+(0.1)+(37.246))/((28.603)+(0.1)));
	tcb->m_ssThresh = (int) (14.083+(40.08)+(33.331)+(41.949)+(88.652)+(85.351));

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(88.402)-(42.324)-(segmentsAcked)-(segmentsAcked));

}
tcb->m_ssThresh = (int) (45.213*(40.245)*(29.401));
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked-(76.894)-(90.891)-(47.001)-(57.82)-(6.296)-(11.513)-(68.67));

} else {
	tcb->m_segmentSize = (int) (18.965-(27.45)-(6.397)-(77.911)-(tcb->m_ssThresh)-(90.129)-(64.965)-(tcb->m_segmentSize)-(76.35));

}
segmentsAcked = (int) (95.181/0.1);
