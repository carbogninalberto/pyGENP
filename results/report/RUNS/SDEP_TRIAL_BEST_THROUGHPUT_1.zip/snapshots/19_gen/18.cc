if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (44.477-(91.353)-(18.46)-(82.813)-(31.769)-(85.711)-(32.727)-(26.722));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (71.71+(87.824)+(26.931)+(86.316));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(41.099)-(segmentsAcked)-(12.578)-(88.16)-(83.299)-(51.972)-(10.874)-(tcb->m_ssThresh));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
float DqQULcsGCUcOCQIl = (float) (((0.1)+(59.565)+(75.151)+((tcb->m_cWnd*(33.794)))+(0.1))/((0.1)+(0.1)+(85.765)+(0.1)));
float JBdEJgqqQoGhhMED = (float) (22.064+(22.049)+(22.993)+(tcb->m_cWnd)+(72.636)+(79.094)+(94.042));
segmentsAcked = SlowStart (tcb, segmentsAcked);
DqQULcsGCUcOCQIl = (float) (6.974-(30.597)-(35.799)-(66.699)-(92.757)-(34.183)-(segmentsAcked)-(62.363));
if (JBdEJgqqQoGhhMED == JBdEJgqqQoGhhMED) {
	DqQULcsGCUcOCQIl = (float) (96.535*(39.567));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	DqQULcsGCUcOCQIl = (float) (tcb->m_cWnd+(33.091)+(95.176)+(89.092)+(28.64)+(14.103)+(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (0.1/0.1);

}
if (tcb->m_cWnd <= segmentsAcked) {
	segmentsAcked = (int) (47.612*(18.754)*(21.892)*(17.98));

} else {
	segmentsAcked = (int) (63.039*(75.352));

}
JBdEJgqqQoGhhMED = (float) (DqQULcsGCUcOCQIl*(71.524)*(segmentsAcked)*(42.066)*(53.765)*(95.093)*(43.994)*(79.709)*(11.626));
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (40.966+(30.324));
	tcb->m_segmentSize = (int) (95.72/67.591);

} else {
	tcb->m_cWnd = (int) (60.174*(23.785)*(25.511)*(segmentsAcked)*(DqQULcsGCUcOCQIl)*(30.015)*(69.52)*(50.815)*(52.039));

}
