CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-74.365-(-25.825)-(28.649)-(10.402));
segmentsAcked = (int) (64.001-(6.177)-(-13.996)-(17.209)-(37.037)-(-86.849)-(81.831)-(-1.645));
