segmentsAcked = (int) (5.312/-29.766);
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (30.681*(8.729)*(2.673)*(64.489)*(tcb->m_cWnd)*(71.602)*(95.801)*(27.915)*(28.441));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (97.39/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-35.309-(95.079)-(22.069)-(19.649)-(92.59)-(31.791));
segmentsAcked = (int) (-42.12-(3.762)-(85.524)-(67.268)-(49.12)-(95.533));
