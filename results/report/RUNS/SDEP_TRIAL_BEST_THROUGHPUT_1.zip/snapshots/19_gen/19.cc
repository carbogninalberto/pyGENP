if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (8.445/0.1);

} else {
	segmentsAcked = (int) ((97.759*(58.642)*(41.717)*(78.004)*(52.606)*(45.777))/82.058);
	segmentsAcked = (int) (49.444-(88.873)-(28.974)-(91.264)-(segmentsAcked)-(46.264)-(87.05)-(27.495)-(29.424));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (((0.1)+(3.094)+(0.1)+((11.291*(26.685)*(tcb->m_cWnd)))+(0.1)+(34.515)+(0.1))/((73.387)+(14.222)));
tcb->m_segmentSize = (int) (80.311*(90.786));
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(16.583)*(67.99)*(tcb->m_ssThresh)*(68.45)*(15.521)*(48.688));
	tcb->m_segmentSize = (int) (47.105+(91.844));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (92.139+(tcb->m_segmentSize)+(82.315)+(49.856)+(6.658)+(74.304)+(58.198)+(91.797));

}
ReduceCwnd (tcb);
