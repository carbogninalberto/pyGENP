TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int EKrJYsQvZRzYZZnq = (int) (segmentsAcked+(tcb->m_ssThresh)+(tcb->m_cWnd));
if (EKrJYsQvZRzYZZnq < tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((((32.868+(35.235)+(93.825)+(39.696)+(38.399)+(2.89)+(11.482)+(42.032)))+(97.203)+(49.681)+(0.1))/((0.1)+(94.91)+(0.1)));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(53.437)+(8.582)+(32.59)+(tcb->m_segmentSize));

}
segmentsAcked = (int) (6.434+(35.357)+(tcb->m_cWnd)+(96.876));
if (EKrJYsQvZRzYZZnq < segmentsAcked) {
	segmentsAcked = (int) (58.372-(94.819)-(tcb->m_segmentSize)-(94.773));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((62.77)+(0.1)+(93.734)+(0.1)+(23.06))/((0.1)+(40.197)+(91.069)+(0.1)));

}
