if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(99.125)-(30.734));
	tcb->m_segmentSize = (int) (91.057-(7.553)-(38.108)-(29.357)-(45.552)-(11.798)-(15.995));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-0.071)+(11.881)+(71.726)+(segmentsAcked)+(segmentsAcked)+(70.45));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = (int) (64.51/(92.133+(67.176)+(0.427)+(77.697)+(60.215)+(50.0)+(8.575)+(86.732)+(24.004)));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (50.362+(61.276));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
