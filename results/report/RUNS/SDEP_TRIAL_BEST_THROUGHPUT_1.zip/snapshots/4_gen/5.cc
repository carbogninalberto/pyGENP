int IJpweFrIDDAeKVqE = (int) (-41.057/91.042);
tcb->m_segmentSize = (int) (-97.992/42.49);
