tcb->m_segmentSize = (int) (24.115*(47.03)*(54.212)*(55.197)*(segmentsAcked)*(89.771)*(86.501)*(12.13));
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_ssThresh = (int) (95.846-(80.54)-(48.456)-(22.464)-(48.64)-(74.741)-(47.649));
	segmentsAcked = (int) (23.008+(96.464)+(25.803)+(61.111));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (39.231/0.1);

}
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (4.297-(9.872)-(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked+(82.77)+(96.812)+(48.811)+(60.243)+(78.506));
	segmentsAcked = (int) (26.833*(79.757)*(54.552));
	tcb->m_cWnd = (int) (0.1/0.1);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_cWnd*(87.778)*(95.93)*(tcb->m_segmentSize));
ReduceCwnd (tcb);
