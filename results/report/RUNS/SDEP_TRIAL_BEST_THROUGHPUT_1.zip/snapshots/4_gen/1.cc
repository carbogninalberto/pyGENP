segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-37.95-(-89.153)-(-66.91)-(-33.654)-(53.816)-(-37.204)-(12.577)-(34.842));
CongestionAvoidance (tcb, segmentsAcked);
