tcb->m_ssThresh = (int) (58.705/8.173);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (50.35+(35.627)+(68.033)+(82.112)+(11.998)+(31.55)+(85.09)+(34.769)+(tcb->m_ssThresh));
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_cWnd = (int) (30.814+(24.444)+(segmentsAcked));
	tcb->m_cWnd = (int) (42.687-(61.036)-(89.161)-(69.556)-(4.724)-(26.793)-(79.542)-(50.617)-(12.701));

} else {
	tcb->m_cWnd = (int) (57.656-(33.054)-(30.139)-(39.782)-(21.685)-(67.946)-(25.527));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (1.287+(72.107)+(10.74));
if (tcb->m_ssThresh > segmentsAcked) {
	segmentsAcked = (int) (63.637-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(97.813)-(72.132));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (22.753+(tcb->m_segmentSize)+(34.088)+(12.765)+(segmentsAcked)+(85.535));
	segmentsAcked = (int) (84.382+(90.165));
	segmentsAcked = (int) (62.748*(86.379)*(tcb->m_ssThresh)*(1.995));

}
