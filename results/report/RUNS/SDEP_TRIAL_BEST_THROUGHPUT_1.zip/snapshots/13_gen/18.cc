tcb->m_ssThresh = (int) (((54.675)+((75.035-(tcb->m_ssThresh)-(68.253)-(5.802)))+(0.1)+(44.404)+(0.1))/((0.1)+(62.925)));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (5.548*(46.62)*(5.938)*(segmentsAcked)*(35.937));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_ssThresh) {
	segmentsAcked = (int) (70.034/0.1);

} else {
	segmentsAcked = (int) (69.238/3.783);

}
