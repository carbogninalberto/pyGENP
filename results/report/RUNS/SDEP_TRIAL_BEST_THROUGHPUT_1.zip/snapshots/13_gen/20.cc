CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	segmentsAcked = (int) (40.064+(tcb->m_segmentSize)+(22.185));

} else {
	segmentsAcked = (int) (68.558-(44.794)-(5.48)-(41.994)-(84.809)-(12.813));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (83.868-(tcb->m_ssThresh)-(19.006)-(76.177)-(99.581)-(99.992)-(90.035)-(47.275)-(70.296));
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (4.398+(28.187)+(tcb->m_ssThresh)+(44.014));
	tcb->m_cWnd = (int) (72.773*(84.932)*(40.639)*(85.074)*(tcb->m_cWnd)*(56.699)*(60.343)*(64.805));
	segmentsAcked = (int) (10.457+(78.623)+(47.983)+(97.324)+(30.469)+(11.866)+(12.679));

} else {
	tcb->m_cWnd = (int) (63.129*(88.799)*(tcb->m_ssThresh)*(91.421)*(10.85));
	tcb->m_cWnd = (int) (20.512-(83.763)-(tcb->m_ssThresh)-(93.636)-(13.656)-(70.902));
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(74.958)-(94.775)-(41.352)-(44.681)-(55.87)-(79.584)-(tcb->m_segmentSize)-(tcb->m_ssThresh));

}
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (37.413-(78.87)-(76.156)-(82.536)-(tcb->m_ssThresh)-(96.068));

} else {
	tcb->m_segmentSize = (int) (17.602-(34.715)-(37.134)-(89.572)-(45.281)-(48.761));
	tcb->m_ssThresh = (int) (0.1/90.052);
	tcb->m_ssThresh = (int) (78.855*(86.669)*(60.949)*(45.377));

}
