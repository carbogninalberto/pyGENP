tcb->m_ssThresh = (int) (91.383+(34.752)+(16.152)+(69.248)+(55.437)+(63.235));
ReduceCwnd (tcb);
if (tcb->m_cWnd != segmentsAcked) {
	segmentsAcked = (int) (51.151+(52.381)+(33.388)+(13.513));

} else {
	segmentsAcked = (int) (9.192*(47.25)*(26.54)*(63.667));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(tcb->m_segmentSize)*(55.606)*(14.522));
	segmentsAcked = (int) (21.303/0.1);

}
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_segmentSize = (int) (0.1/10.441);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (10.212/10.84);
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(4.37)+(0.1)+((40.317-(80.511)-(86.827)-(tcb->m_ssThresh)))+(0.1))/((42.029)));

}
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (96.664+(tcb->m_segmentSize)+(72.444));

} else {
	tcb->m_cWnd = (int) (57.525/67.384);

}
