tcb->m_cWnd = (int) ((14.383*(69.199))/0.1);
tcb->m_cWnd = (int) (0.1/73.691);
tcb->m_ssThresh = (int) (88.387+(35.02)+(segmentsAcked)+(tcb->m_cWnd));
segmentsAcked = (int) (34.6-(51.45)-(50.073)-(24.063)-(segmentsAcked)-(41.327)-(86.908)-(44.583)-(31.683));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
