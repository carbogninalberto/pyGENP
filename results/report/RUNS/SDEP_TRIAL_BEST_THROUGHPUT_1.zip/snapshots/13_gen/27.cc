int DUIMhealjcVlthsg = (int) (96.231+(23.026)+(25.921)+(95.104)+(57.306)+(56.265)+(15.378));
tcb->m_ssThresh = (int) (12.689/0.1);
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (75.004*(66.635)*(17.31)*(86.777)*(tcb->m_ssThresh)*(segmentsAcked)*(40.355));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (41.907-(52.849)-(48.789));
	tcb->m_ssThresh = (int) (83.411+(74.427)+(99.444)+(11.887)+(6.282)+(40.383)+(tcb->m_ssThresh)+(14.947));

}
tcb->m_cWnd = (int) (54.004*(17.983));
CongestionAvoidance (tcb, segmentsAcked);
