int ILnsvDyOotoSRXCn = (int) (-27.336*(39.528)*(-22.763)*(-36.416)*(59.693)*(-72.059)*(88.68)*(96.159));
float VWMpDYyCzYIdVUFb = (float) (0.231-(66.65));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
