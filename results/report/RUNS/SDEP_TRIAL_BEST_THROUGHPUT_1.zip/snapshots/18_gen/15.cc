tcb->m_ssThresh = (int) (96.958-(6.266)-(segmentsAcked)-(39.024));
tcb->m_cWnd = (int) (38.825-(19.534)-(74.412)-(89.074));
segmentsAcked = (int) (10.884+(26.827)+(segmentsAcked)+(69.103)+(34.672));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (tcb->m_ssThresh-(16.44)-(94.88));
