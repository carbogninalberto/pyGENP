TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (50.74-(40.162)-(1.953)-(79.785)-(84.177)-(11.857));
	tcb->m_segmentSize = (int) (15.028*(13.366)*(28.329));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(49.002)*(95.433)*(67.261));
	tcb->m_segmentSize = (int) (1.879*(27.203)*(66.975));

}
int SsKwtOjRiGfRNaxO = (int) (54.706*(27.829)*(tcb->m_ssThresh)*(24.373)*(45.483));
if (segmentsAcked == tcb->m_ssThresh) {
	segmentsAcked = (int) (39.215+(11.37)+(79.461)+(85.965)+(64.384));

} else {
	segmentsAcked = (int) (97.503+(0.597)+(SsKwtOjRiGfRNaxO)+(26.058));
	SsKwtOjRiGfRNaxO = (int) (SsKwtOjRiGfRNaxO+(3.839)+(58.46)+(tcb->m_segmentSize)+(56.128)+(98.451));

}
segmentsAcked = (int) (segmentsAcked+(33.82)+(62.825)+(61.982)+(29.108)+(75.301));
if (segmentsAcked >= SsKwtOjRiGfRNaxO) {
	tcb->m_segmentSize = (int) (((0.1)+(41.407)+(0.1)+(27.182)+((24.327+(79.054)+(tcb->m_cWnd)+(76.895)+(84.955)+(90.458)+(44.952)))+(0.1))/((55.104)));

} else {
	tcb->m_segmentSize = (int) (3.347*(2.418)*(73.422)*(10.742)*(12.795)*(9.65)*(37.919)*(1.699));
	tcb->m_segmentSize = (int) (16.803-(5.058)-(67.652));
	tcb->m_segmentSize = (int) (84.967+(52.974)+(38.181));

}
