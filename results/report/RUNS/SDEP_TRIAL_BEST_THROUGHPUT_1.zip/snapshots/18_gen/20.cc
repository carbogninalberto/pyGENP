tcb->m_ssThresh = (int) (27.515*(tcb->m_ssThresh)*(52.286)*(6.94)*(31.125)*(9.07)*(tcb->m_ssThresh));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(45.071)*(66.166)*(28.414)*(tcb->m_cWnd)*(68.124)*(34.181)*(40.761)*(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (69.462-(45.495)-(67.62));
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(79.691)-(34.881)-(14.537)-(83.625)-(8.536)-(42.656));

}
tcb->m_ssThresh = (int) (75.039+(tcb->m_cWnd)+(29.827)+(13.578)+(93.852)+(53.475)+(97.896)+(tcb->m_cWnd));
tcb->m_ssThresh = (int) (94.718/86.492);
float fMjwmHYbSpIhBQsM = (float) (0.1/60.096);
