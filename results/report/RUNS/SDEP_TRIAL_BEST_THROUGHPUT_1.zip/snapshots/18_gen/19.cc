if (tcb->m_segmentSize != tcb->m_segmentSize) {
	segmentsAcked = (int) (67.599-(56.845)-(74.632)-(42.837)-(segmentsAcked)-(70.808));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (47.363-(87.14)-(23.359)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(13.612)-(tcb->m_ssThresh)-(54.388));

}
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (8.181*(87.277)*(40.784)*(30.205)*(52.503)*(14.501)*(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (95.772/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (22.074*(tcb->m_ssThresh));
tcb->m_cWnd = (int) (19.461+(40.628)+(tcb->m_cWnd)+(10.377)+(9.762)+(16.505)+(segmentsAcked)+(59.694));
CongestionAvoidance (tcb, segmentsAcked);
