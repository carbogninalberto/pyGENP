ReduceCwnd (tcb);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
int AGdYwDPVIdQLOpBB = (int) (69.248*(tcb->m_segmentSize)*(segmentsAcked)*(13.665)*(85.331)*(41.196));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int PYhNsGeZOvYyPHDb = (int) ((((75.001-(48.301)-(6.167)-(76.584)-(42.271)-(61.683)-(AGdYwDPVIdQLOpBB)))+((49.368*(85.004)))+(0.1)+((20.46*(8.17)*(75.433)*(54.05)*(tcb->m_segmentSize)*(30.497)*(tcb->m_cWnd)*(41.803)))+(36.474))/((0.1)+(0.1)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
