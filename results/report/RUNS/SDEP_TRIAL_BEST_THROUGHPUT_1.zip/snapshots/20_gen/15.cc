int vageKGpFacXWRZkZ = (int) (66.571*(70.889)*(tcb->m_cWnd)*(53.504)*(26.713));
vageKGpFacXWRZkZ = (int) (23.319+(34.947)+(45.476)+(43.343));
if (segmentsAcked < tcb->m_ssThresh) {
	segmentsAcked = (int) (94.763-(94.053)-(45.805));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (28.456+(12.021));

}
tcb->m_cWnd = (int) (28.178-(68.275)-(16.511));
ReduceCwnd (tcb);
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_ssThresh = (int) (3.565+(57.28)+(tcb->m_segmentSize)+(29.32)+(12.906)+(tcb->m_ssThresh)+(18.054)+(4.665));
	tcb->m_segmentSize = (int) (37.455+(72.667)+(13.594)+(tcb->m_cWnd)+(2.119)+(16.061));
	segmentsAcked = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(vageKGpFacXWRZkZ)+(tcb->m_cWnd)+(89.107)+(tcb->m_ssThresh)+(32.612));
	tcb->m_segmentSize = (int) (((0.1)+((24.543-(65.527)-(tcb->m_ssThresh)-(19.979)-(tcb->m_cWnd)))+(29.746)+((tcb->m_segmentSize+(49.334)+(53.604)+(59.372)+(7.898)+(77.021)))+(0.1))/((12.644)+(63.206)+(0.1)));

}
