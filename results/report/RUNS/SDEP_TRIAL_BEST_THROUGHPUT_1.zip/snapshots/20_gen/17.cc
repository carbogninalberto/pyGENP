ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (37.23*(tcb->m_ssThresh)*(76.573)*(88.103)*(42.161)*(34.222));
segmentsAcked = (int) (17.274-(59.641)-(32.864)-(58.173)-(18.71));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float VLxAFPEkrPNSSqtm = (float) (70.327*(45.872)*(24.909)*(63.478)*(3.624)*(4.993));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (37.497-(29.138)-(tcb->m_ssThresh)-(90.051)-(2.678)-(57.407)-(48.579)-(42.319)-(25.431));
	tcb->m_cWnd = (int) (27.567-(76.375));
	tcb->m_ssThresh = (int) ((57.336+(70.321)+(79.906)+(VLxAFPEkrPNSSqtm)+(60.225)+(26.418)+(58.915))/0.1);

} else {
	tcb->m_ssThresh = (int) (36.121*(79.197)*(tcb->m_cWnd)*(50.883)*(66.843)*(7.849)*(96.341)*(tcb->m_cWnd)*(19.952));

}
