tcb->m_cWnd = (int) (-43.116-(-15.383)-(67.443)-(-91.156)-(66.115)-(-0.472)-(62.368));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (21.008*(72.992));
	tcb->m_segmentSize = (int) (17.145-(94.719)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (87.416-(86.108)-(28.72)-(90.752)-(58.966)-(49.261));
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
