int EjZigAqVGMNzkvQd = (int) (-51.367*(60.313)*(34.368)*(-16.381)*(92.245)*(42.009)*(20.195)*(44.641)*(34.318));
int FuwDXWVrMpgGhOyV = (int) (-53.717*(-46.651)*(72.275)*(-9.37)*(49.982)*(94.768)*(-64.627)*(-24.301)*(-31.241));
if (EjZigAqVGMNzkvQd == segmentsAcked) {
	segmentsAcked = (int) (80.12-(92.816)-(96.432)-(segmentsAcked)-(79.419)-(25.182)-(tcb->m_cWnd)-(10.893)-(32.588));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (27.987+(9.344)+(3.508)+(57.303)+(54.288)+(71.542)+(32.878)+(99.141));

} else {
	segmentsAcked = (int) (0.1/51.562);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (-81.45-(-2.225)-(33.108)-(45.343));
tcb->m_segmentSize = (int) (47.896+(-67.548)+(6.999));
int ZxkUXHXqnqMTcUsO = (int) 31.45;
