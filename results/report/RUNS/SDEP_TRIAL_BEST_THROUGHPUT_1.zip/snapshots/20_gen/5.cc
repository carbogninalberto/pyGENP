if (segmentsAcked < segmentsAcked) {
	tcb->m_cWnd = (int) (95.122-(tcb->m_segmentSize)-(76.132)-(30.717)-(25.977));
	tcb->m_segmentSize = (int) (5.76/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (13.916*(tcb->m_segmentSize)*(-97.374));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (tcb->m_cWnd*(47.757)*(43.854));

}
segmentsAcked = (int) (96.64-(12.477)-(2.343)-(-55.162)-(-98.521)-(77.08)-(-79.259)-(52.9));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
