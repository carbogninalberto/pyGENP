segmentsAcked = (int) (48.289+(28.173)+(-0.515)+(63.329)+(80.595)+(75.783));
segmentsAcked = SlowStart (tcb, segmentsAcked);
