segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (3.669+(86.212)+(69.365));
tcb->m_cWnd = (int) (14.595+(31.512)+(68.063)+(95.824)+(96.453)+(77.623)+(tcb->m_segmentSize));
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (43.781/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(97.081)+(8.289)+(80.291)+(77.156)+(42.406));

}
float gSQmqCMukcIaoKFZ = (float) (60.736*(11.702)*(58.37));
