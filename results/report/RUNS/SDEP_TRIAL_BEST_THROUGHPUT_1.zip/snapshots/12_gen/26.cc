if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((0.1)+(80.366)+(0.1)+(0.1)+(38.443)+(0.1))/((9.2)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (9.911*(91.317)*(68.641));
	tcb->m_segmentSize = (int) ((26.95-(68.795))/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (8.662-(53.621)-(57.549)-(49.23)-(30.429)-(99.197)-(46.152));
	tcb->m_ssThresh = (int) (((78.609)+(0.1)+((4.89-(tcb->m_ssThresh)))+(68.673))/((92.733)));

} else {
	tcb->m_segmentSize = (int) (((0.1)+((43.613+(tcb->m_ssThresh)+(segmentsAcked)+(76.703)+(37.22)+(30.101)))+(0.1)+(46.391))/((14.594)+(37.12)+(0.1)));

}
if (segmentsAcked == tcb->m_ssThresh) {
	segmentsAcked = (int) (11.758*(37.521)*(99.114));
	tcb->m_cWnd = (int) (69.97*(38.889)*(12.625));

} else {
	segmentsAcked = (int) (71.253/19.655);
	tcb->m_segmentSize = (int) (0.1/0.1);

}
if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (85.917/98.275);
	segmentsAcked = (int) (64.529*(23.265)*(tcb->m_segmentSize)*(29.949)*(73.023)*(94.216));
	tcb->m_cWnd = (int) (38.325+(56.986));

} else {
	tcb->m_cWnd = (int) (74.535-(26.852)-(segmentsAcked)-(4.727)-(tcb->m_ssThresh)-(13.438)-(tcb->m_cWnd)-(32.965)-(35.332));

}
tcb->m_cWnd = (int) (87.345*(61.53)*(90.76)*(39.747)*(15.93)*(67.559)*(60.052)*(31.442)*(0.639));
tcb->m_cWnd = (int) (0.1/0.1);
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (90.445-(29.139));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (0.1/70.876);

}
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_ssThresh = (int) (((37.895)+(87.452)+(0.1)+(0.1)+(13.58)+(37.64)+(0.1)+(0.1))/((41.597)));
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(90.559)*(95.512)*(57.424)*(52.337)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(33.695));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(12.664)-(tcb->m_segmentSize));
	segmentsAcked = (int) (tcb->m_ssThresh*(73.672)*(segmentsAcked)*(16.295)*(tcb->m_cWnd)*(70.176)*(49.862));
	tcb->m_ssThresh = (int) (41.967+(75.738));

}
tcb->m_ssThresh = (int) (1.791-(6.93)-(88.546)-(68.213));
