int gdCHMpUKiYqgSIDR = (int) (34.908-(63.905)-(75.21)-(-16.32)-(-13.032));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-50.153/-27.648);
gdCHMpUKiYqgSIDR = (int) (-97.3+(-29.302)+(19.145));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
