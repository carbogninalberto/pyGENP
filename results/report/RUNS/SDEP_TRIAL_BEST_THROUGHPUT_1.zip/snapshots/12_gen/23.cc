int nFSPTKUaVTBMmypV = (int) (5.292-(76.788)-(48.175)-(6.809)-(50.58)-(67.425));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (84.325+(64.347)+(23.211)+(12.53)+(25.235));
ReduceCwnd (tcb);
