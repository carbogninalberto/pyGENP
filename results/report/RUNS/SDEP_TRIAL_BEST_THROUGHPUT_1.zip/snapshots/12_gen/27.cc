tcb->m_segmentSize = (int) (93.407*(49.439)*(82.088)*(28.08)*(0.808));
ReduceCwnd (tcb);
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_cWnd = (int) (62.68+(37.717)+(6.027)+(16.091)+(97.893)+(51.744)+(segmentsAcked)+(12.507)+(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (44.682*(59.725)*(57.966)*(segmentsAcked)*(66.668));

}
tcb->m_cWnd = (int) (95.263+(25.118)+(49.279));
if (tcb->m_ssThresh < tcb->m_cWnd) {
	segmentsAcked = (int) (72.849*(74.39)*(tcb->m_ssThresh)*(56.547)*(75.156)*(59.514)*(56.826)*(34.471));
	tcb->m_ssThresh = (int) (11.627*(56.547)*(24.516)*(59.342));

} else {
	segmentsAcked = (int) (40.016-(tcb->m_ssThresh)-(16.209)-(45.363)-(2.133));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(74.607)-(53.158)-(91.169)-(segmentsAcked)-(1.092)-(79.084)-(33.744)-(3.518));

}
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_segmentSize+(63.057)+(89.649)+(25.291)+(48.488)+(61.273)+(29.022));
