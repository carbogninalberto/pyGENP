float TmRLewKbgvvMpHhX = (float) (18.121*(-49.794));
int WKLdNCfjihMIuxmW = (int) (90.052*(-65.011));
int qVELNetFxovPoRcc = (int) (97.867+(-92.999));
tcb->m_cWnd = (int) (74.48-(45.553)-(-81.686));
ReduceCwnd (tcb);
