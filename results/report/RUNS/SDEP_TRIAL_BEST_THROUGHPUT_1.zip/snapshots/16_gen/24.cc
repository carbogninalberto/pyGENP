tcb->m_segmentSize = (int) (55.172-(88.47)-(25.56)-(12.735)-(31.263)-(97.657)-(31.139));
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	segmentsAcked = (int) (30.159/0.1);

} else {
	segmentsAcked = (int) ((((12.563*(tcb->m_ssThresh)*(tcb->m_cWnd)*(62.8)*(tcb->m_cWnd)*(93.502)))+(62.73)+((tcb->m_segmentSize-(92.809)-(13.747)-(71.905)-(94.515)-(86.48)))+(0.1)+(30.674))/((94.041)));
	tcb->m_cWnd = (int) (27.26-(94.887)-(13.255)-(66.067));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/33.618);
	segmentsAcked = (int) (18.393+(65.423));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(47.999)*(34.512)*(67.134)*(segmentsAcked)*(73.412));

}
if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) (60.891-(63.457));

} else {
	segmentsAcked = (int) (71.87*(92.977)*(64.728)*(tcb->m_ssThresh)*(19.281)*(36.855));

}
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(23.874)*(1.743)*(37.797)*(86.918)*(tcb->m_cWnd)*(79.026));
	tcb->m_segmentSize = (int) (0.1/(tcb->m_cWnd*(6.036)*(segmentsAcked)));

} else {
	tcb->m_cWnd = (int) (((97.285)+(0.1)+((48.753+(84.378)))+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)));
	tcb->m_segmentSize = (int) (5.823-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(49.025)-(80.983));
	tcb->m_ssThresh = (int) (14.751*(4.171)*(tcb->m_ssThresh)*(1.332)*(tcb->m_cWnd)*(64.278)*(48.06));

}
tcb->m_ssThresh = (int) (21.85/3.584);
tcb->m_cWnd = (int) (((6.026)+(36.834)+(66.758)+(0.1))/((55.746)+(0.1)+(16.446)));
tcb->m_cWnd = (int) (77.284-(10.2)-(54.032)-(81.867)-(tcb->m_ssThresh)-(2.399)-(tcb->m_cWnd)-(34.369)-(tcb->m_cWnd));
