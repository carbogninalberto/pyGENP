ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (42.847*(58.598)*(tcb->m_cWnd)*(51.973));
segmentsAcked = (int) (segmentsAcked-(tcb->m_segmentSize)-(81.9)-(27.167)-(94.983)-(93.901)-(93.485)-(73.045)-(51.966));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
