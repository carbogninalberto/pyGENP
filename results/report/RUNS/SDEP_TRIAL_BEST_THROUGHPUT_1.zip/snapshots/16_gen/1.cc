float gnfdYkeRRNWMMYMx = (float) (22.11/-25.167);
