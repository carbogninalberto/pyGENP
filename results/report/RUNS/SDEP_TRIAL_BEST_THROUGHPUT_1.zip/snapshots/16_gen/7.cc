float jMEJfcrSvTcxVwsZ = (float) (66.114+(-71.257)+(-35.794)+(-88.13)+(-32.94));
