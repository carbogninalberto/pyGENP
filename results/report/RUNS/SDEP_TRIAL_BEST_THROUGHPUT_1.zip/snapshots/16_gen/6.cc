int FgtjOeGAktHQqPEg = (int) (-36.383+(46.217));
CongestionAvoidance (tcb, segmentsAcked);
int oqTDFjqyFYyEQBjy = (int) (-35.607/14.176);
segmentsAcked = (int) (45.095-(-5.434)-(35.772));
