if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_ssThresh = (int) (segmentsAcked*(69.737)*(90.592)*(39.898)*(tcb->m_ssThresh)*(segmentsAcked));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (93.257*(3.126)*(54.913)*(24.842)*(40.648)*(1.19));

} else {
	tcb->m_ssThresh = (int) (57.875+(52.592)+(78.401));
	tcb->m_ssThresh = (int) (37.98+(5.198)+(91.081)+(17.447)+(14.357)+(50.028));
	tcb->m_cWnd = (int) (11.77*(85.673)*(37.96));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (32.42+(tcb->m_cWnd)+(segmentsAcked));
	tcb->m_segmentSize = (int) ((11.685*(88.815)*(27.761)*(0.63)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(tcb->m_cWnd))/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) ((34.876*(segmentsAcked)*(93.306)*(39.685)*(72.565))/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != segmentsAcked) {
	segmentsAcked = (int) (71.91*(75.733)*(96.828)*(45.799));

} else {
	segmentsAcked = (int) (28.485-(96.774)-(43.609));

}
tcb->m_segmentSize = (int) (33.644+(47.221)+(83.951)+(97.867));
tcb->m_cWnd = (int) (86.248-(24.789)-(2.231)-(94.184)-(99.451)-(64.025)-(88.71)-(27.873));
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (22.572*(39.175));

} else {
	tcb->m_cWnd = (int) (8.96-(94.246));
	tcb->m_segmentSize = (int) (24.46-(80.35));
	ReduceCwnd (tcb);

}
