float hrWETmKyLXdoTLqD = (float) (16.59-(50.533)-(tcb->m_segmentSize));
tcb->m_ssThresh = (int) (46.873*(tcb->m_ssThresh)*(99.867));
int POtzcvzckMXzYsrd = (int) (25.735*(tcb->m_ssThresh)*(67.083)*(96.847)*(93.324)*(hrWETmKyLXdoTLqD)*(92.517));
if (hrWETmKyLXdoTLqD > segmentsAcked) {
	POtzcvzckMXzYsrd = (int) (4.064*(20.28)*(19.571)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(50.708)*(tcb->m_cWnd)*(14.55)*(23.363));
	POtzcvzckMXzYsrd = (int) (5.039*(tcb->m_segmentSize)*(POtzcvzckMXzYsrd)*(43.538));
	hrWETmKyLXdoTLqD = (float) (POtzcvzckMXzYsrd*(tcb->m_segmentSize)*(4.089)*(20.575)*(24.45)*(tcb->m_segmentSize)*(tcb->m_cWnd));

} else {
	POtzcvzckMXzYsrd = (int) (29.169-(3.964)-(tcb->m_ssThresh));
	POtzcvzckMXzYsrd = (int) (16.334+(26.022)+(92.887)+(42.572)+(60.902)+(tcb->m_cWnd)+(hrWETmKyLXdoTLqD)+(32.938)+(68.545));

}
float WiosQrvHlDLlbUmb = (float) (58.25*(31.724)*(57.938)*(0.949)*(70.664)*(44.485)*(89.923));
