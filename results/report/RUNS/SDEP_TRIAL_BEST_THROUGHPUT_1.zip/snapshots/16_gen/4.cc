TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-12.115-(11.91)-(-36.116)-(-1.934));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (1.067*(60.338)*(47.185));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (49.748*(87.296)*(-61.121));
ReduceCwnd (tcb);
