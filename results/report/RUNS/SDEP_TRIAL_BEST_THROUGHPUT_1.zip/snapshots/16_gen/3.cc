TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (80.101-(-43.636)-(-54.17)-(-6.669));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-80.327*(-0.585)*(88.828));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (29.144*(82.273)*(65.276));
ReduceCwnd (tcb);
