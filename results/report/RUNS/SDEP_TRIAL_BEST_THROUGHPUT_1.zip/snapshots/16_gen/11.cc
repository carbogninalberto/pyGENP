segmentsAcked = (int) (-61.315+(29.58)+(-25.097)+(-24.132)+(-65.489));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
