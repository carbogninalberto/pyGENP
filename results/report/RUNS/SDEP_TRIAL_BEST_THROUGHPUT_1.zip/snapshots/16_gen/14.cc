float LqDAxjRogGPXcTOl = (float) (tcb->m_ssThresh+(99.032));
LqDAxjRogGPXcTOl = (float) (15.193-(80.529)-(80.459)-(segmentsAcked));
tcb->m_segmentSize = (int) (82.682*(47.775)*(15.141)*(6.934)*(97.371)*(55.797));
LqDAxjRogGPXcTOl = (float) (76.884-(32.892)-(1.293)-(58.24));
if (LqDAxjRogGPXcTOl > tcb->m_ssThresh) {
	LqDAxjRogGPXcTOl = (float) (42.494-(91.766)-(18.493)-(50.683)-(43.418)-(tcb->m_cWnd)-(tcb->m_segmentSize)-(57.884)-(20.6));
	tcb->m_ssThresh = (int) (33.544*(tcb->m_segmentSize));

} else {
	LqDAxjRogGPXcTOl = (float) (((24.6)+(0.1)+(60.711)+(0.1))/((0.1)+(0.1)+(0.1)+(66.329)));

}
if (LqDAxjRogGPXcTOl > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(LqDAxjRogGPXcTOl)-(85.75)-(tcb->m_segmentSize)-(88.191)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(LqDAxjRogGPXcTOl)-(21.975));
	segmentsAcked = (int) (18.094+(11.157)+(LqDAxjRogGPXcTOl)+(98.655)+(42.336));

} else {
	tcb->m_ssThresh = (int) (93.332+(70.051));

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
