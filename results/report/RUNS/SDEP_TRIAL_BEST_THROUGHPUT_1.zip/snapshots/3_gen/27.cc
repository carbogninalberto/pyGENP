tcb->m_segmentSize = (int) (-47.551/-99.879);
int KFZYbVPDIROriIuP = (int) 4.574;
KFZYbVPDIROriIuP = (int) (-81.641/92.897);
