TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int KFZYbVPDIROriIuP = (int) 30.953;
KFZYbVPDIROriIuP = (int) (-89.452/-1.27);
tcb->m_cWnd = (int) (((18.177)+((-15.679-(-47.106)-(-10.702)-(-53.603)-(45.241)-(-73.218)-(-53.445)))+(0.14)+(17.15)+(52.892))/((-42.149)+(-62.983)));
segmentsAcked = (int) (-1.543/(-65.789*(-0.365)*(-6.01)));
