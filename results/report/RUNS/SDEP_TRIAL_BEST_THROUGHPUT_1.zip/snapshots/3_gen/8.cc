ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	segmentsAcked = (int) (65.242*(8.633)*(91.539));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (89.183/0.1);

} else {
	segmentsAcked = (int) (39.094-(79.995)-(23.976)-(segmentsAcked)-(83.814)-(tcb->m_segmentSize)-(53.159));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (50.558*(10.967)*(tcb->m_cWnd)*(79.725)*(59.694)*(53.259)*(20.696));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (54.83*(7.81)*(8.131)*(52.419)*(58.496)*(15.019)*(75.484));

} else {
	tcb->m_segmentSize = (int) (24.422-(98.372)-(61.421)-(16.475));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (78.84/56.068);

}
