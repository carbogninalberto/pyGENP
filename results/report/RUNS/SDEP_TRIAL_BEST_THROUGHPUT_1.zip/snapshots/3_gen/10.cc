int nEyvnciVFKZnvzfJ = (int) 75.888;
int IJpweFrIDDAeKVqE = (int) (-94.74/95.768);
float sCHwTSUjeJQXNvwH = (float) (31.986+(-0.558)+(-84.839)+(-29.876));
tcb->m_cWnd = (int) (62.41+(-3.26)+(-8.572)+(-8.419)+(79.425)+(54.87)+(-62.695)+(-29.887));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (13.452+(45.256)+(-37.25)+(9.52)+(39.853)+(63.126)+(-25.567));
if (nEyvnciVFKZnvzfJ <= tcb->m_cWnd) {
	IJpweFrIDDAeKVqE = (int) (5.833+(41.733)+(93.137)+(80.143)+(92.283)+(42.097));
	ReduceCwnd (tcb);
	nEyvnciVFKZnvzfJ = (int) ((93.35+(56.116)+(56.066)+(1.444))/0.1);

} else {
	IJpweFrIDDAeKVqE = (int) (sCHwTSUjeJQXNvwH-(94.063)-(20.061));

}
