int DsYTWXdTWVRboAkg = (int) 44.437;
tcb->m_segmentSize = (int) (37.006*(-12.415)*(-41.692)*(-43.593)*(-50.164));
