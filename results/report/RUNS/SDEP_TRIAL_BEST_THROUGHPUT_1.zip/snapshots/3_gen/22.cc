int nEyvnciVFKZnvzfJ = (int) (68.654*(-54.121)*(28.368)*(-95.469)*(82.157)*(-39.989)*(95.044));
int IJpweFrIDDAeKVqE = (int) (-21.009/96.168);
float sCHwTSUjeJQXNvwH = (float) (-1.761+(10.369)+(31.145)+(-46.978));
tcb->m_cWnd = (int) (-38.082+(-15.185)+(-77.42)+(-42.177)+(97.558)+(64.463)+(83.838));
tcb->m_cWnd = (int) (14.283+(-72.171)+(-66.637)+(-9.652)+(-73.853)+(91.491)+(-34.86));
if (nEyvnciVFKZnvzfJ <= tcb->m_cWnd) {
	IJpweFrIDDAeKVqE = (int) (sCHwTSUjeJQXNvwH-(94.063)-(20.061));

} else {
	IJpweFrIDDAeKVqE = (int) (5.833+(-23.728)+(93.137)+(80.143)+(92.283)+(42.097));
	ReduceCwnd (tcb);
	nEyvnciVFKZnvzfJ = (int) ((93.35+(56.116)+(56.066)+(1.444))/0.1);

}
