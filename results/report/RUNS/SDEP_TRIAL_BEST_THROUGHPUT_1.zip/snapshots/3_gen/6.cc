int IJpweFrIDDAeKVqE = (int) (58.49/32.087);
float sCHwTSUjeJQXNvwH = (float) (-91.137+(-48.716)+(37.341)+(-66.998));
sCHwTSUjeJQXNvwH = (float) (-5.706+(63.073)+(79.547)+(21.839)+(0.248));
