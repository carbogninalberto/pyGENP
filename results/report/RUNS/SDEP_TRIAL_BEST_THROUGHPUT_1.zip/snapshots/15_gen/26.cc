tcb->m_segmentSize = (int) (11.252-(tcb->m_segmentSize));
segmentsAcked = (int) (0.1/(31.492+(segmentsAcked)));
segmentsAcked = (int) (23.479/0.1);
ReduceCwnd (tcb);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (49.974*(8.18)*(87.923));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(tcb->m_segmentSize)*(55.978));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (49.008+(tcb->m_segmentSize)+(16.326)+(11.075)+(91.242)+(24.682)+(46.829)+(51.264));
	tcb->m_segmentSize = (int) (17.792-(25.491)-(6.09)-(79.33)-(94.793)-(81.229));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
