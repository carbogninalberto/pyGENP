int qgoAnlDhecztWQbS = (int) (86.922+(30.962)+(5.462)+(-25.755)+(42.112)+(54.543)+(-39.816)+(-57.746));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
