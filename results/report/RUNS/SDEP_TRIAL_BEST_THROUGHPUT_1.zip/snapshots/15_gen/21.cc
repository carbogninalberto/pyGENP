float pPWwJaobmYuaaZxb = (float) (77.53+(tcb->m_cWnd)+(0.137)+(27.328));
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	pPWwJaobmYuaaZxb = (float) (91.438*(segmentsAcked)*(82.739)*(22.356)*(pPWwJaobmYuaaZxb));

} else {
	pPWwJaobmYuaaZxb = (float) (83.705+(tcb->m_cWnd)+(19.366)+(tcb->m_segmentSize)+(17.996));
	pPWwJaobmYuaaZxb = (float) (tcb->m_ssThresh*(0.712)*(57.847));

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	segmentsAcked = (int) (77.222/25.602);
	pPWwJaobmYuaaZxb = (float) (tcb->m_segmentSize+(15.879)+(36.49)+(11.753)+(31.956)+(98.355));

} else {
	segmentsAcked = (int) (((83.878)+(0.1)+(0.1)+(1.363))/((0.1)));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (66.651*(66.769)*(73.323)*(44.479));
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(36.963)+(23.55)+(35.166)+(pPWwJaobmYuaaZxb)+(24.087));

} else {
	tcb->m_cWnd = (int) (67.97-(tcb->m_ssThresh)-(38.287)-(34.944));
	tcb->m_ssThresh = (int) (66.982-(segmentsAcked)-(3.289)-(85.266)-(79.711)-(0.611)-(56.072));

}
tcb->m_cWnd = (int) (22.403*(48.978)*(50.124)*(99.79)*(16.166)*(85.574)*(67.823)*(51.445)*(tcb->m_ssThresh));
tcb->m_ssThresh = (int) (43.76-(88.686)-(66.584)-(73.529)-(46.664));
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (71.266*(83.453)*(65.757));
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(8.456)*(15.96)*(13.992));

} else {
	tcb->m_ssThresh = (int) (20.76*(71.377)*(tcb->m_ssThresh)*(21.468));
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(45.042)*(16.958)*(83.491)*(70.004)*(36.978)*(52.06)*(92.89));
	tcb->m_ssThresh = (int) (50.323+(70.933)+(tcb->m_ssThresh));

}
