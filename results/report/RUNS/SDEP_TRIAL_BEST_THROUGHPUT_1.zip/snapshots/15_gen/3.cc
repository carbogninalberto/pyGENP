float GkjjiaUddauPZsvU = (float) (-29.919/-10.499);
segmentsAcked = (int) (-56.413*(90.603)*(72.796)*(31.009)*(10.224));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
