CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-64.0*(70.084)*(6.353)*(9.623)*(79.533));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (40.974*(52.981)*(-54.733)*(-29.328)*(72.561));
CongestionAvoidance (tcb, segmentsAcked);
