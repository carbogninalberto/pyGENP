int qgoAnlDhecztWQbS = (int) (81.882+(31.089)+(-7.934)+(-23.617)+(-83.829)+(94.889)+(79.257)+(-39.507));
CongestionAvoidance (tcb, segmentsAcked);
