ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (25.778*(16.453)*(88.325)*(94.631)*(tcb->m_ssThresh)*(tcb->m_ssThresh));
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (87.771*(70.177)*(39.662)*(76.647)*(3.147)*(10.597)*(5.276)*(24.797)*(43.364));
	tcb->m_ssThresh = (int) (53.633*(74.533));

} else {
	tcb->m_segmentSize = (int) (37.135+(94.88)+(tcb->m_segmentSize)+(5.408)+(19.832)+(6.617)+(57.042));
	tcb->m_cWnd = (int) (24.953+(65.177)+(71.523));

}
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_segmentSize = (int) (26.712*(9.062));

} else {
	tcb->m_segmentSize = (int) (76.711+(segmentsAcked)+(41.091)+(tcb->m_ssThresh)+(83.889)+(8.722)+(86.29));

}
if (segmentsAcked > tcb->m_ssThresh) {
	segmentsAcked = (int) (70.433+(segmentsAcked)+(23.965));
	tcb->m_segmentSize = (int) (segmentsAcked*(97.071));
	tcb->m_ssThresh = (int) (0.1/56.246);

} else {
	segmentsAcked = (int) (tcb->m_cWnd+(tcb->m_segmentSize)+(30.374)+(85.266)+(79.247)+(91.055)+(33.376)+(95.419)+(72.652));
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(29.73)-(74.785)-(53.913)-(95.632)-(29.988)-(42.018));

}
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((55.369-(89.74)-(57.688))/95.327);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (8.529-(39.414)-(83.966)-(3.715)-(45.047)-(87.607)-(62.309)-(67.511));
	segmentsAcked = (int) (((0.1)+(0.1)+((35.947-(18.46)-(77.474)-(35.831)-(98.054)-(53.253)-(36.439)-(30.502)-(48.259)))+(0.1)+(46.063))/((67.029)+(0.1)));

}
