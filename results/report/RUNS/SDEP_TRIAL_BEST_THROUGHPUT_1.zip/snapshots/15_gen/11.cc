TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-77.718-(-9.01)-(26.348)-(35.421));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (35.188*(27.746)*(95.15));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (51.704*(-49.605)*(-92.62));
ReduceCwnd (tcb);
