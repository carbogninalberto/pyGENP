int XRfrFNQsNNhKahje = (int) (-30.686*(-95.143)*(78.782)*(-39.712));
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_cWnd = (int) ((XRfrFNQsNNhKahje+(26.804)+(73.782)+(55.162))/0.1);
	tcb->m_cWnd = (int) (3.64+(XRfrFNQsNNhKahje)+(2.142)+(42.608)+(83.202)+(62.283));

} else {
	tcb->m_cWnd = (int) (((95.609)+(52.583)+(97.872)+(0.1)+((tcb->m_segmentSize+(tcb->m_ssThresh)+(18.902)+(72.453)))+(87.7))/((52.25)+(99.215)+(0.1)));
	segmentsAcked = (int) (70.312-(17.875)-(tcb->m_segmentSize)-(81.024)-(66.777));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) ((44.851+(tcb->m_ssThresh)+(20.191)+(77.491)+(87.518)+(tcb->m_ssThresh))/-6.862);
