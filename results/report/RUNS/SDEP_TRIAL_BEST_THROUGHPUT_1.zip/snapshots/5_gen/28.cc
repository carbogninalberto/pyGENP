tcb->m_cWnd = (int) (86.861*(tcb->m_cWnd)*(tcb->m_ssThresh)*(2.467)*(38.025)*(77.015)*(23.4)*(12.469));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (12.078+(tcb->m_ssThresh)+(38.921)+(75.267)+(10.79));

} else {
	tcb->m_cWnd = (int) (80.988*(tcb->m_cWnd)*(tcb->m_ssThresh)*(39.211)*(47.759)*(4.67)*(80.127)*(10.31)*(18.251));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/2.796);
	tcb->m_ssThresh = (int) (4.697*(66.829)*(tcb->m_cWnd)*(95.417)*(tcb->m_segmentSize)*(80.467)*(93.383)*(65.159)*(76.943));
	tcb->m_segmentSize = (int) (48.929*(20.281)*(36.485)*(25.915)*(96.763)*(32.349)*(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) (59.895-(23.505)-(70.465));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
