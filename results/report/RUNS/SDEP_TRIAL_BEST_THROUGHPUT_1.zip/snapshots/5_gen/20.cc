tcb->m_cWnd = (int) (((0.1)+(43.798)+(82.415)+(0.1)+(0.1))/((0.1)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
int IwVKzavZnPSHKiPv = (int) (97.982*(segmentsAcked)*(22.778)*(6.418)*(tcb->m_ssThresh)*(35.504)*(18.267)*(33.077)*(27.352));
tcb->m_segmentSize = (int) (0.1/30.336);
