segmentsAcked = (int) (45.314*(62.847)*(-52.834)*(50.858)*(99.004)*(-74.823)*(-38.893)*(36.859));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (99.196+(5.825)+(22.892)+(-85.686)+(27.382)+(45.305)+(90.196)+(43.749)+(71.091));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-12.05+(-93.84)+(65.03));
tcb->m_segmentSize = (int) (11.748+(-32.684)+(60.997)+(-93.89)+(29.257)+(-28.748)+(14.096)+(-31.376)+(-45.851));
segmentsAcked = (int) (-30.441+(-86.988)+(-5.254));
