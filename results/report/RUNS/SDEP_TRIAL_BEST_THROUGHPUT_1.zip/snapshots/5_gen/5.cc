TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-17.872*(-19.807)*(-27.171)*(84.511)*(30.957)*(94.263)*(-58.755));
ReduceCwnd (tcb);
segmentsAcked = (int) (40.805*(20.13)*(-79.049)*(35.973)*(21.923)*(18.768));
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (26.324*(48.205)*(3.867)*(44.551)*(66.181));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (tcb->m_cWnd*(47.641)*(5.789)*(82.485));

} else {
	tcb->m_cWnd = (int) (30.051-(62.229)-(segmentsAcked)-(34.75)-(17.599)-(22.917)-(70.162)-(30.836)-(56.35));
	segmentsAcked = (int) (11.25+(95.209)+(tcb->m_cWnd)+(96.316)+(98.462)+(92.859)+(84.539)+(92.945)+(60.661));
	tcb->m_cWnd = (int) (54.7/0.1);

}
