CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (96.279*(85.162));
tcb->m_ssThresh = (int) (88.738+(51.776)+(84.867)+(29.63)+(26.222)+(31.501)+(54.069)+(89.271)+(64.356));
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	segmentsAcked = (int) (11.475-(tcb->m_segmentSize)-(16.499));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (31.291*(98.141)*(92.028)*(49.155));
	CongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (tcb->m_segmentSize*(66.463)*(35.114)*(55.873));
