ReduceCwnd (tcb);
segmentsAcked = (int) (66.93+(29.084)+(1.297)+(16.546)+(88.444)+(53.938)+(51.162));
int ectxVzAkQqxHtQwM = (int) (51.403-(21.552)-(51.034));
float hQgcTaMNGffXQSgJ = (float) (83.137/0.1);
CongestionAvoidance (tcb, segmentsAcked);
