if (segmentsAcked == segmentsAcked) {
	tcb->m_cWnd = (int) (18.992+(18.826)+(43.458)+(tcb->m_cWnd)+(38.918));
	segmentsAcked = (int) ((82.969+(47.348)+(37.7))/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (25.081/(81.13*(80.917)*(62.315)*(82.695)*(tcb->m_ssThresh)));

}
int TQKoTgSQggyOWiJR = (int) (-61.7*(-12.224)*(-43.079)*(-97.423)*(23.619)*(89.045));
segmentsAcked = (int) (59.347+(-61.062)+(4.253)+(86.48)+(20.983)+(77.865)+(94.07));
CongestionAvoidance (tcb, segmentsAcked);
