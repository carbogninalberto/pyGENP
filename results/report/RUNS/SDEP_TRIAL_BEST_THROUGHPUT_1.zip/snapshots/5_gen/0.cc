float rrhjVRlrWBYNKWFv = (float) (34.185+(-69.424)+(32.831)+(-5.094)+(-44.114)+(-24.492)+(-92.251));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-71.73-(-39.554)-(-45.858)-(44.693));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-5.159+(-39.956)+(-27.215));
tcb->m_segmentSize = (int) (-96.771*(42.783));
segmentsAcked = SlowStart (tcb, segmentsAcked);
