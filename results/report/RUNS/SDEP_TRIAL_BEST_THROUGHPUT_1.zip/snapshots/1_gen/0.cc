ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (11.301/0.1);
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (32.115*(tcb->m_cWnd)*(13.943));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (4.256+(64.157)+(73.399)+(21.212)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(segmentsAcked)+(segmentsAcked));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (58.435+(tcb->m_segmentSize)+(26.288)+(95.643));

}
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (50.573-(69.2)-(13.397)-(30.204)-(segmentsAcked)-(35.028)-(83.396)-(90.248)-(31.552));
	segmentsAcked = (int) (27.176-(12.072)-(74.652)-(tcb->m_cWnd)-(30.373));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (19.69/63.583);

}
tcb->m_ssThresh = (int) (tcb->m_cWnd-(62.299)-(6.36)-(50.066)-(95.493)-(4.861)-(7.572)-(76.69)-(70.275));
CongestionAvoidance (tcb, segmentsAcked);
