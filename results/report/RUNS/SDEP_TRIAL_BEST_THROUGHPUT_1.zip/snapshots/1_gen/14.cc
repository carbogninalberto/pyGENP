int DDMZtxmLMdyLEyJR = (int) (((0.1)+(0.1)+(87.082)+(66.096)+(93.615)+(20.8))/((55.722)));
if (tcb->m_segmentSize <= DDMZtxmLMdyLEyJR) {
	tcb->m_cWnd = (int) (26.987*(64.775)*(20.634)*(99.209)*(38.038));

} else {
	tcb->m_cWnd = (int) (60.652-(94.168)-(7.845)-(38.947)-(DDMZtxmLMdyLEyJR)-(88.461));

}
segmentsAcked = (int) (71.257*(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (DDMZtxmLMdyLEyJR < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (45.061*(86.399)*(0.281));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (((12.108)+(0.1)+(35.362)+(26.63))/((0.1)+(0.1)));

}
if (tcb->m_ssThresh <= DDMZtxmLMdyLEyJR) {
	segmentsAcked = (int) (3.512-(88.627)-(52.357)-(93.266)-(tcb->m_segmentSize)-(6.832)-(28.213)-(93.421));

} else {
	segmentsAcked = (int) (64.712*(58.703)*(32.24)*(56.418)*(69.341)*(tcb->m_segmentSize));

}
