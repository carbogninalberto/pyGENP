int iZtMKyGQdYwmpVbi = (int) (tcb->m_cWnd-(21.833)-(97.573)-(tcb->m_segmentSize));
if (tcb->m_ssThresh != iZtMKyGQdYwmpVbi) {
	tcb->m_segmentSize = (int) (17.654-(0.909)-(11.663)-(tcb->m_ssThresh)-(81.034)-(25.596));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(25.158)*(64.105));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
iZtMKyGQdYwmpVbi = (int) (88.405+(21.06)+(34.34)+(66.792)+(67.608));
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	iZtMKyGQdYwmpVbi = (int) (53.387+(14.459)+(tcb->m_cWnd)+(77.08)+(tcb->m_cWnd)+(58.168)+(47.46)+(78.075)+(66.857));

} else {
	iZtMKyGQdYwmpVbi = (int) (8.579+(39.165)+(7.713)+(32.031)+(45.532));
	segmentsAcked = (int) (0.1/92.174);
	ReduceCwnd (tcb);

}
if (segmentsAcked < tcb->m_segmentSize) {
	iZtMKyGQdYwmpVbi = (int) (((26.327)+((30.559+(14.604)+(15.139)+(6.436)+(0.519)))+(71.213)+(52.737))/((0.1)+(0.1)+(0.1)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	iZtMKyGQdYwmpVbi = (int) (((0.1)+((69.54+(iZtMKyGQdYwmpVbi)+(46.821)+(6.893)+(11.185)))+(99.635)+((53.048+(tcb->m_segmentSize)+(43.191)+(50.117)+(84.281)))+(0.1)+(0.1)+(40.773)+(0.1))/((0.1)));

}
