tcb->m_segmentSize = (int) (70.961+(44.19));
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	segmentsAcked = (int) (88.398-(tcb->m_segmentSize)-(14.052)-(69.297)-(84.469)-(45.996)-(22.181)-(82.036));
	segmentsAcked = (int) (39.631*(56.738));
	tcb->m_cWnd = (int) (74.659+(tcb->m_segmentSize)+(65.818)+(65.43)+(43.298));

} else {
	segmentsAcked = (int) ((tcb->m_ssThresh-(tcb->m_ssThresh)-(18.569)-(36.504)-(61.51)-(46.719)-(67.024)-(tcb->m_segmentSize)-(77.288))/0.1);
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (84.252+(91.813)+(71.818)+(99.967)+(tcb->m_ssThresh)+(46.319)+(99.099)+(28.06));

}
tcb->m_ssThresh = (int) (80.93-(64.379)-(52.011)-(20.086)-(83.209)-(76.347)-(43.418)-(83.722)-(32.694));
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (62.801*(43.445)*(72.885)*(28.296)*(tcb->m_segmentSize)*(55.704)*(49.655)*(86.389));
	tcb->m_cWnd = (int) (14.308+(40.936)+(16.062)+(49.755)+(7.403)+(81.763));

} else {
	tcb->m_ssThresh = (int) (66.383-(67.356)-(26.855)-(94.109)-(tcb->m_cWnd)-(19.221));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (35.813+(8.534));

}
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
