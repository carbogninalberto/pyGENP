float BcIdXVqqOAoKBydo = (float) (((0.1)+(0.1)+(0.1)+(0.1))/((10.237)+(0.1)+(79.254)));
tcb->m_cWnd = (int) (((0.1)+(0.1)+((segmentsAcked*(89.857)*(47.67)*(17.656)*(33.11)*(58.03)*(76.819)))+(0.1)+(0.1)+(4.056)+(55.344)+(0.1))/((71.465)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (25.186*(tcb->m_ssThresh));
segmentsAcked = (int) (59.039*(40.035)*(40.104)*(tcb->m_cWnd)*(BcIdXVqqOAoKBydo)*(68.368)*(78.854)*(59.537));
tcb->m_segmentSize = (int) (30.274*(48.539)*(BcIdXVqqOAoKBydo)*(59.431)*(84.086)*(48.649));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (50.409*(segmentsAcked)*(9.607)*(31.397)*(segmentsAcked));
