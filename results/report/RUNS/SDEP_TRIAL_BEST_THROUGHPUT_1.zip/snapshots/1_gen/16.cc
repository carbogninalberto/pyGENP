ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_cWnd) {
	segmentsAcked = (int) (90.186*(tcb->m_cWnd)*(5.641)*(20.994));
	tcb->m_segmentSize = (int) (segmentsAcked*(59.747)*(tcb->m_segmentSize)*(28.107)*(98.014));
	tcb->m_ssThresh = (int) (58.26*(74.71)*(86.037)*(12.011));

} else {
	segmentsAcked = (int) (22.581-(58.492));
	tcb->m_segmentSize = (int) (((21.128)+(0.1)+(0.1)+(0.1))/((80.617)+(0.1)));
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(4.144)+(45.926)+(0.1)+(13.151))/((98.02)+(0.1)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/28.996);
	segmentsAcked = (int) (85.524-(72.086)-(6.778)-(14.772)-(58.548)-(17.524)-(4.578)-(92.531)-(83.388));

} else {
	tcb->m_segmentSize = (int) (36.411-(88.91)-(97.358));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
