int XfVBCleMHpOZrUkW = (int) (55.313-(tcb->m_cWnd)-(66.377)-(18.212)-(56.332)-(52.859)-(46.101)-(tcb->m_ssThresh)-(99.628));
ReduceCwnd (tcb);
float RdkrTLTiCUFGTIhz = (float) (52.62*(40.929)*(60.495));
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	segmentsAcked = (int) (93.351+(52.62)+(35.274)+(7.68)+(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (RdkrTLTiCUFGTIhz-(46.699)-(13.48)-(37.025));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == segmentsAcked) {
	RdkrTLTiCUFGTIhz = (float) (tcb->m_cWnd*(9.856)*(49.343)*(27.591)*(24.976)*(84.915));

} else {
	RdkrTLTiCUFGTIhz = (float) (45.3-(67.982)-(37.535)-(RdkrTLTiCUFGTIhz)-(22.299)-(XfVBCleMHpOZrUkW)-(94.943)-(30.348)-(21.921));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((65.461)));
if (segmentsAcked >= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(18.398)+(48.466));
	ReduceCwnd (tcb);
	XfVBCleMHpOZrUkW = (int) (89.515+(10.658)+(99.234)+(47.673)+(10.33)+(0.817));

} else {
	tcb->m_cWnd = (int) (81.438*(tcb->m_cWnd)*(57.667)*(36.646)*(60.182));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (7.718/15.469);

}
