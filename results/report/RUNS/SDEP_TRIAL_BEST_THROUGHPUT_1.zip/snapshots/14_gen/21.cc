float ZbedrFkgCxTvCwwd = (float) (0.1/0.1);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (93.432+(46.412)+(64.036)+(ZbedrFkgCxTvCwwd));
segmentsAcked = (int) (97.475-(segmentsAcked)-(9.132)-(85.867)-(55.033)-(31.732)-(90.976)-(58.722)-(84.572));
tcb->m_segmentSize = (int) (16.458-(ZbedrFkgCxTvCwwd)-(64.083));
