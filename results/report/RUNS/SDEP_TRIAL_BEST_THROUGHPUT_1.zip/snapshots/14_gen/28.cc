segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_cWnd = (int) (41.261+(16.865)+(34.888)+(97.913)+(90.181)+(74.403)+(39.647)+(4.713)+(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (36.523-(58.563)-(5.811));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_cWnd = (int) (54.322-(tcb->m_cWnd)-(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (35.854-(88.792)-(23.514)-(2.531)-(0.396)-(99.181)-(66.09)-(23.37));

} else {
	tcb->m_cWnd = (int) (73.222*(12.376)*(57.927)*(2.929)*(22.894)*(65.792)*(38.264));

}
