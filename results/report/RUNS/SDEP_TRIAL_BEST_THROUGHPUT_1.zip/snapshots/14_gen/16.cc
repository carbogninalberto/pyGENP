if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	segmentsAcked = (int) (((0.1)+(0.1)+((15.249-(39.867)-(15.858)-(22.819)-(18.839)-(44.379)))+(77.383)+(0.1)+(99.44)+(0.1))/((0.1)+(0.1)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (84.3*(16.678)*(90.626)*(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(tcb->m_cWnd)+(19.795));
	tcb->m_segmentSize = (int) (47.001-(1.735)-(7.503)-(tcb->m_segmentSize)-(tcb->m_segmentSize));

}
segmentsAcked = (int) (12.018+(70.128)+(tcb->m_segmentSize)+(87.192)+(62.773)+(tcb->m_cWnd));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (75.169+(6.14));
ReduceCwnd (tcb);
