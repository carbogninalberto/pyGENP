tcb->m_ssThresh = (int) (88.846+(61.077)+(92.684)+(65.586));
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_cWnd-(68.634));

} else {
	segmentsAcked = (int) (44.103/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_ssThresh) {
	segmentsAcked = (int) (segmentsAcked-(64.615)-(7.281)-(18.289)-(65.869)-(28.994)-(99.457)-(16.96)-(7.592));
	tcb->m_cWnd = (int) (52.27-(80.056)-(segmentsAcked)-(94.13)-(35.924));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(71.806));

} else {
	segmentsAcked = (int) (77.01*(tcb->m_segmentSize)*(segmentsAcked)*(53.828)*(90.717));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (21.344+(6.239)+(tcb->m_ssThresh));
