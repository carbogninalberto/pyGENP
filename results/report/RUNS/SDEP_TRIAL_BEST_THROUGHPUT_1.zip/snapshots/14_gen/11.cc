CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (16.787*(69.368)*(71.735)*(-65.965)*(-50.705));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (37.899*(-67.865)*(-94.251)*(64.906)*(63.448));
CongestionAvoidance (tcb, segmentsAcked);
