segmentsAcked = (int) (tcb->m_segmentSize-(98.8));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_segmentSize-(tcb->m_ssThresh)-(94.469)-(96.619)-(17.879)-(62.055)-(13.057));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (tcb->m_ssThresh*(84.985)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(16.629)*(83.425));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked == segmentsAcked) {
	tcb->m_ssThresh = (int) (67.876-(38.675)-(tcb->m_segmentSize)-(12.241)-(segmentsAcked)-(39.729)-(37.044)-(14.295));
	tcb->m_cWnd = (int) (96.655+(92.964)+(89.749)+(tcb->m_cWnd)+(38.477)+(53.332));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
