float idpyhCkBnCuIHWvN = (float) (-11.135*(34.755)*(87.494)*(-35.832)*(-0.977));
