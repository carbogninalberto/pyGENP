CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((79.819-(3.487)-(15.234)-(51.079)-(72.317)-(86.895)-(tcb->m_cWnd))/5.836);

} else {
	tcb->m_ssThresh = (int) ((49.933+(76.112)+(70.461)+(79.102)+(2.623))/1.575);

}
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (89.151-(segmentsAcked)-(84.217));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (83.493-(86.675)-(12.47)-(16.864));
	segmentsAcked = (int) ((((93.104-(4.689)-(69.34)-(35.639)-(24.533)-(71.748)-(50.693)-(62.842)))+(62.18)+(91.161)+(0.1)+(70.455))/((39.077)+(0.1)));

}
ReduceCwnd (tcb);
float vcwCoGATaUIcfhSp = (float) (((62.493)+(0.1)+((36.936+(40.107)))+(15.812)+(31.216))/((0.1)));
