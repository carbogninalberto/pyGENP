if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_ssThresh = (int) (segmentsAcked*(26.279)*(67.729)*(tcb->m_segmentSize)*(75.236)*(36.927)*(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (85.746/0.1);

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(0.1))/((78.244)+(0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (0.1/5.149);

} else {
	tcb->m_ssThresh = (int) (29.456-(60.14)-(91.488)-(9.545)-(4.835));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (37.795/10.877);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
