float idpyhCkBnCuIHWvN = (float) (7.005*(66.705)*(-72.209)*(76.091)*(95.186));
