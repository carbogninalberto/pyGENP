int nEyvnciVFKZnvzfJ = (int) (-42.632*(-26.335)*(-38.772)*(52.193)*(68.083)*(70.923)*(83.975));
int owOLhdjACusurkVt = (int) (63.599+(90.453)+(-82.251)+(48.192));
float sCHwTSUjeJQXNvwH = (float) (-36.13+(74.832)+(-6.906)+(54.039));
int IJpweFrIDDAeKVqE = (int) (61.325/10.227);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-29.305+(-28.145)+(-76.924)+(-41.104)+(56.904)+(20.814)+(46.742));
if (nEyvnciVFKZnvzfJ <= tcb->m_cWnd) {
	IJpweFrIDDAeKVqE = (int) (sCHwTSUjeJQXNvwH-(94.063)-(20.061));

} else {
	IJpweFrIDDAeKVqE = (int) (5.833+(-55.676)+(93.137)+(80.143)+(92.283)+(42.097));
	ReduceCwnd (tcb);
	nEyvnciVFKZnvzfJ = (int) ((93.35+(56.116)+(56.066)+(1.444))/0.1);

}
tcb->m_cWnd = (int) (96.002+(-42.589)+(99.434)+(-87.141)+(92.241)+(35.49)+(-99.87));
