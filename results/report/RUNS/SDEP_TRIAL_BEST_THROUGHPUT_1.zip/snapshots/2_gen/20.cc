int owOLhdjACusurkVt = (int) (18.405+(-27.145)+(38.383)+(-16.159));
float sCHwTSUjeJQXNvwH = (float) (33.568+(28.916)+(-12.243)+(-89.591));
int IJpweFrIDDAeKVqE = (int) (-32.231/1.831);
segmentsAcked = SlowStart (tcb, segmentsAcked);
int nEyvnciVFKZnvzfJ = (int) 75.888;
tcb->m_cWnd = (int) (-53.524+(59.834)+(-10.759)+(-14.531)+(-82.266)+(-42.018)+(-30.304));
if (nEyvnciVFKZnvzfJ <= tcb->m_cWnd) {
	IJpweFrIDDAeKVqE = (int) (sCHwTSUjeJQXNvwH-(94.063)-(20.061));

} else {
	IJpweFrIDDAeKVqE = (int) (5.833+(41.733)+(93.137)+(80.143)+(92.283)+(42.097));
	ReduceCwnd (tcb);
	nEyvnciVFKZnvzfJ = (int) ((93.35+(56.116)+(56.066)+(1.444))/0.1);

}
