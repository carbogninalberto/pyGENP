CongestionAvoidance (tcb, segmentsAcked);
int FJFjYUZnWzvlzjsb = (int) 87.85;
segmentsAcked = (int) (-27.432-(56.342)-(-63.805)-(66.778)-(51.481)-(45.788)-(-56.424)-(42.979));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-70.113-(63.44)-(-25.243)-(69.96)-(-74.558)-(25.575)-(-8.411)-(-16.004));
