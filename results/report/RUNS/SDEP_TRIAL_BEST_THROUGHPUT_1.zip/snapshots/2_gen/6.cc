segmentsAcked = (int) (70.807+(-36.58)+(-23.081)+(-88.726)+(-31.548)+(99.442)+(-96.193)+(-73.057));
tcb->m_segmentSize = (int) (-30.047*(-36.833)*(17.3)*(-26.594)*(50.694));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
