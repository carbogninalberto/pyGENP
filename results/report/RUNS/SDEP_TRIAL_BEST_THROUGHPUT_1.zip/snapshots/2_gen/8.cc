int owOLhdjACusurkVt = (int) (18.534+(-62.918)+(49.012)+(-79.942));
float sCHwTSUjeJQXNvwH = (float) (89.397+(-90.873)+(33.441)+(32.419));
int IJpweFrIDDAeKVqE = (int) (38.19/-54.044);
tcb->m_cWnd = (int) (96.752+(4.803)+(-80.065)+(-71.594)+(19.455)+(-9.859)+(-15.757));
int nEyvnciVFKZnvzfJ = (int) (-53.654*(-24.938)*(-61.938)*(32.862)*(-50.056)*(-23.727)*(-11.023));
if (nEyvnciVFKZnvzfJ <= tcb->m_cWnd) {
	IJpweFrIDDAeKVqE = (int) (sCHwTSUjeJQXNvwH-(94.063)-(20.061));

} else {
	IJpweFrIDDAeKVqE = (int) (5.833+(-23.728)+(93.137)+(80.143)+(92.283)+(42.097));
	ReduceCwnd (tcb);
	nEyvnciVFKZnvzfJ = (int) ((93.35+(56.116)+(56.066)+(1.444))/0.1);

}
