int RmPmkdyBAKZGrCdz = (int) ((29.734+(37.448)+(-99.077)+(80.017))/-45.09);
tcb->m_cWnd = (int) (-85.829-(55.782)-(14.554)-(-24.701)-(50.506));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (3.024/(43.697+(tcb->m_ssThresh)+(53.628)+(75.853)+(60.673)+(98.18)+(38.031)+(41.064)+(64.275)));

} else {
	tcb->m_segmentSize = (int) (61.638-(62.564)-(segmentsAcked)-(38.248)-(41.918));
	tcb->m_cWnd = (int) (48.392*(82.29)*(30.047));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (3.024/(43.697+(tcb->m_ssThresh)+(53.628)+(75.853)+(60.673)+(98.18)+(38.031)+(41.064)+(64.275)));

} else {
	tcb->m_segmentSize = (int) (61.638-(62.564)-(segmentsAcked)-(38.248)-(41.918));
	tcb->m_cWnd = (int) (48.392*(82.29)*(30.047));

}
