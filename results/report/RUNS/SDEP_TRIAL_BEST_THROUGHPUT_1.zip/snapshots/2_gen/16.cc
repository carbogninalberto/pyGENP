if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (((44.805)+(31.76)+(0.1)+((97.73+(40.151)+(62.001)))+(0.1))/((0.1)+(43.366)+(0.1)));
	tcb->m_segmentSize = (int) (13.682+(15.216)+(84.968)+(82.848)+(88.286)+(11.587)+(11.842));
	tcb->m_cWnd = (int) (26.074+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (26.998*(67.138)*(tcb->m_segmentSize)*(31.819));

}
int DsYTWXdTWVRboAkg = (int) 44.437;
tcb->m_segmentSize = (int) (-26.707*(7.992)*(81.84)*(7.673)*(44.896));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
