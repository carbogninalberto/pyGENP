segmentsAcked = (int) (-57.541*(16.667)*(21.554)*(78.348)*(17.696)*(-54.383));
tcb->m_cWnd = (int) (43.627-(84.716)-(-15.179)-(-16.673)-(33.331));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (3.024/(43.697+(tcb->m_ssThresh)+(53.628)+(75.853)+(60.673)+(98.18)+(38.031)+(41.064)+(64.275)));

} else {
	tcb->m_segmentSize = (int) (61.638-(62.564)-(segmentsAcked)-(38.248)-(41.918));
	tcb->m_cWnd = (int) (48.392*(82.29)*(30.047));

}
tcb->m_cWnd = (int) (22.742-(-47.279)-(-41.962)-(90.976)-(54.737));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (3.024/(43.697+(tcb->m_ssThresh)+(53.628)+(75.853)+(60.673)+(98.18)+(38.031)+(41.064)+(64.275)));

} else {
	tcb->m_segmentSize = (int) (61.638-(62.564)-(segmentsAcked)-(38.248)-(41.918));
	tcb->m_cWnd = (int) (48.392*(82.29)*(30.047));

}
