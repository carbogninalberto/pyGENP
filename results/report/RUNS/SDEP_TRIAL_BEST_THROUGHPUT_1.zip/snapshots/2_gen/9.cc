int wNbCqpwnpdVdgATP = (int) (4.898*(46.308)*(18.382));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	segmentsAcked = (int) (65.242*(8.633)*(91.539));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (89.183/0.1);

} else {
	segmentsAcked = (int) (-68.031-(79.995)-(23.976)-(segmentsAcked)-(83.814)-(tcb->m_segmentSize)-(53.159));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (50.558*(10.967)*(tcb->m_cWnd)*(79.725)*(59.694)*(53.259)*(20.696));

}
