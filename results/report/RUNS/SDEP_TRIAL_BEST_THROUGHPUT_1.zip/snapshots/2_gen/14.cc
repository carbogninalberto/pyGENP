int owOLhdjACusurkVt = (int) (-83.83+(62.74)+(-73.223)+(78.601));
float sCHwTSUjeJQXNvwH = (float) (-80.317+(-89.264)+(-63.103)+(13.717));
int IJpweFrIDDAeKVqE = (int) (-76.891/-96.99);
tcb->m_cWnd = (int) (-77.479*(-41.163));
int nEyvnciVFKZnvzfJ = (int) 57.44;
tcb->m_cWnd = (int) (-38.827+(-89.002)+(-17.915)+(35.733)+(61.02)+(68.443)+(-26.719));
if (nEyvnciVFKZnvzfJ <= tcb->m_cWnd) {
	IJpweFrIDDAeKVqE = (int) (sCHwTSUjeJQXNvwH-(94.063)-(20.061));

} else {
	IJpweFrIDDAeKVqE = (int) (5.833+(-2.522)+(93.137)+(80.143)+(92.283)+(42.097));
	ReduceCwnd (tcb);
	nEyvnciVFKZnvzfJ = (int) ((93.35+(56.116)+(56.066)+(1.444))/0.1);

}
