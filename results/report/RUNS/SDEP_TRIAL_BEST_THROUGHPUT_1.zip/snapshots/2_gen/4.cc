float CbBpDpQluCNHMOkY = (float) (-96.1*(-1.004)*(-85.259)*(51.31)*(71.519)*(-51.232)*(-38.541)*(12.254)*(-39.513));
int BllUOwVySEBdyAjz = (int) (82.445*(77.999));
tcb->m_cWnd = (int) (-98.154-(-36.42)-(37.663)-(-33.773)-(-76.398));
segmentsAcked = (int) (2.381/82.252);
CbBpDpQluCNHMOkY = (float) (-57.095*(-1.467)*(-72.619)*(-42.424)*(0.47));
BllUOwVySEBdyAjz = (int) (1.426+(39.819));
