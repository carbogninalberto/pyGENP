TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-42.062-(-11.424)-(11.881)-(44.137));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-84.592*(-11.52)*(88.412));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (42.354*(35.292)*(-92.958));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
