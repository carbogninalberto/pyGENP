float LqDAxjRogGPXcTOl = (float) 58.744;
LqDAxjRogGPXcTOl = (float) (98.481-(66.693)-(-79.222)-(15.028));
tcb->m_segmentSize = (int) (-88.551*(-1.079)*(-66.926)*(-93.231)*(-75.438)*(-98.59));
LqDAxjRogGPXcTOl = (float) (6.143-(-78.559)-(20.582)-(28.381));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
LqDAxjRogGPXcTOl = (float) (59.214-(25.088)-(15.301)-(-86.641));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
