tcb->m_ssThresh = (int) (0.1/13.844);
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (8.114/57.61);

} else {
	tcb->m_segmentSize = (int) ((((27.977*(77.271)*(15.323)*(57.972)*(98.693)*(8.714)*(14.586)*(51.864)))+(45.963)+((71.491+(74.005)+(segmentsAcked)+(23.459)+(2.909)+(tcb->m_ssThresh)))+(38.442)+(41.458)+(0.1))/((0.1)));
	tcb->m_ssThresh = (int) (5.831*(16.113)*(84.23)*(78.612)*(2.156));
	segmentsAcked = (int) (95.273*(24.662)*(92.228)*(23.412)*(29.1));

}
tcb->m_cWnd = (int) (4.509/0.1);
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (77.74+(segmentsAcked)+(9.819));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (((36.831)+(0.1)+((96.788+(25.286)+(12.588)))+(0.1)+(54.398)+(32.257))/((97.97)+(0.1)+(34.638)));

}
tcb->m_ssThresh = (int) ((77.787+(72.678)+(71.035)+(tcb->m_ssThresh))/0.1);
