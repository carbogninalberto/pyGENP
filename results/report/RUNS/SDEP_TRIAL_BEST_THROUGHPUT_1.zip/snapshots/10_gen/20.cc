float TRFbpQyjJCSMSItu = (float) 65.006;
