float OWdqyPSEMluFtEHs = (float) (89.919-(45.067)-(65.617)-(13.533)-(-53.78)-(-89.667)-(-5.744)-(-13.147)-(-85.415));
CongestionAvoidance (tcb, segmentsAcked);
