tcb->m_cWnd = (int) (53.477-(tcb->m_ssThresh));
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (17.594*(58.487)*(57.642)*(95.629)*(69.892)*(91.901)*(62.888));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(26.465)*(98.867));

} else {
	tcb->m_cWnd = (int) (8.465-(tcb->m_segmentSize)-(43.155)-(16.947)-(28.49)-(76.036)-(15.192)-(75.018));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(8.382)-(32.547)-(32.407)-(67.675)-(12.344));

}
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (5.942+(49.878));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (42.311*(90.666)*(tcb->m_cWnd)*(65.172)*(86.784)*(0.258)*(66.089)*(tcb->m_segmentSize));

}
segmentsAcked = (int) (((0.1)+(0.1)+(31.77)+(0.1)+(0.1)+(0.1)+(9.369))/((0.1)));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
