if (tcb->m_ssThresh < tcb->m_ssThresh) {
	segmentsAcked = (int) (0.1/12.331);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) ((74.252*(60.324)*(95.761)*(66.598))/35.226);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (80.108-(59.36)-(97.159)-(34.77));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (52.537-(segmentsAcked)-(tcb->m_cWnd)-(3.549)-(35.236)-(24.64)-(tcb->m_segmentSize)-(30.536)-(65.893));
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) (83.357/57.907);

} else {
	segmentsAcked = (int) (10.403*(tcb->m_segmentSize)*(tcb->m_cWnd)*(34.582)*(43.055)*(tcb->m_ssThresh)*(segmentsAcked));
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(44.369));
	tcb->m_cWnd = (int) (85.087+(94.688)+(62.863)+(42.622)+(14.599)+(tcb->m_ssThresh)+(14.87)+(25.265)+(91.277));

}
tcb->m_cWnd = (int) (50.462*(20.364)*(78.314));
ReduceCwnd (tcb);
