int kqWHawcDYsPdAIaJ = (int) (99.681+(90.977)+(95.268)+(segmentsAcked)+(tcb->m_segmentSize)+(92.846));
ReduceCwnd (tcb);
kqWHawcDYsPdAIaJ = (int) (kqWHawcDYsPdAIaJ-(kqWHawcDYsPdAIaJ)-(32.506)-(58.79)-(92.009)-(46.889));
kqWHawcDYsPdAIaJ = (int) (46.33-(4.089)-(75.079)-(23.939)-(9.043)-(tcb->m_cWnd)-(7.07));
kqWHawcDYsPdAIaJ = (int) (1.936+(8.151)+(segmentsAcked)+(56.636)+(14.126));
