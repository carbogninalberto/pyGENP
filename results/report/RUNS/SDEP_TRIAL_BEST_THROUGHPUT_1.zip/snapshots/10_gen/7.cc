TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (32.009*(-43.844)*(-99.466));
tcb->m_cWnd = (int) (27.428-(-54.188)-(7.532)-(-30.003));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (7.484*(43.012)*(70.117));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-99.59*(-36.06)*(-53.105));
ReduceCwnd (tcb);
