int ZxvBGXPJUbGxgDMU = (int) (-76.661*(8.863)*(15.424)*(-23.35)*(12.297));
float idpyhCkBnCuIHWvN = (float) (-68.639*(90.947)*(-62.471)*(56.909)*(24.626));
float OWdqyPSEMluFtEHs = (float) (75.446-(-18.611)-(-32.789)-(-8.248)-(72.342)-(-70.901)-(-7.888)-(20.588)-(-91.832));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
