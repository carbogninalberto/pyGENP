float PZpTeTDFpnUhlhTn = (float) (tcb->m_cWnd-(28.081)-(79.316)-(11.536));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float OveUUEnRbsiPzOuM = (float) (57.151*(79.801)*(2.406)*(tcb->m_segmentSize)*(42.486));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
