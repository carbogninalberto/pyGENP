int gxhbhMkXFbsIAbxl = (int) (-94.939/(8.0-(71.891)));
int fDimxEsRTUlxGHDM = (int) (27.509+(79.757)+(-33.498)+(-89.789)+(-70.494)+(-87.685));
segmentsAcked = (int) (-61.794*(-24.566)*(-8.941)*(-48.527)*(-77.46));
float vZwoTOrBWlARvgaE = (float) (22.367/21.717);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (47.993*(55.26)*(26.11)*(-76.821)*(-17.045));
CongestionAvoidance (tcb, segmentsAcked);
