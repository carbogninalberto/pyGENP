int PhSxOfCjvhLcfMOQ = (int) (tcb->m_ssThresh+(tcb->m_cWnd)+(21.388)+(37.38));
int awQAteeZcuKbJPFN = (int) (84.691*(2.147)*(24.555)*(tcb->m_segmentSize)*(23.036)*(tcb->m_cWnd)*(35.903)*(29.071)*(16.815));
if (PhSxOfCjvhLcfMOQ <= tcb->m_ssThresh) {
	PhSxOfCjvhLcfMOQ = (int) (82.262-(16.191));

} else {
	PhSxOfCjvhLcfMOQ = (int) (((0.1)+(0.1)+(0.1)+(39.529)+(0.1))/((0.1)+(48.641)));

}
int tAotHjSlSZZZAfVp = (int) (tcb->m_ssThresh*(19.092));
if (segmentsAcked < awQAteeZcuKbJPFN) {
	awQAteeZcuKbJPFN = (int) (11.189*(22.094)*(69.02));
	tcb->m_segmentSize = (int) (2.93*(44.024)*(segmentsAcked)*(awQAteeZcuKbJPFN)*(29.457));

} else {
	awQAteeZcuKbJPFN = (int) (55.804+(segmentsAcked)+(PhSxOfCjvhLcfMOQ)+(25.038)+(25.392));
	PhSxOfCjvhLcfMOQ = (int) (((0.1)+(62.027)+(97.903)+(0.1)+(3.175)+(1.208))/((66.568)));
	PhSxOfCjvhLcfMOQ = (int) (30.178-(segmentsAcked));
	tcb->m_ssThresh = (int) (42.072-(tcb->m_segmentSize)-(30.302)-(5.959)-(51.119)-(64.139));

}
int appKaWHdWtWgOjlo = (int) (72.727*(1.138));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (89.492*(tcb->m_segmentSize)*(60.692)*(31.143)*(appKaWHdWtWgOjlo)*(23.505)*(0.542)*(2.727));
	tcb->m_ssThresh = (int) (awQAteeZcuKbJPFN*(tcb->m_ssThresh)*(93.442)*(30.282)*(64.179)*(31.028)*(22.082)*(71.867)*(8.067));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (49.917+(45.836)+(9.386)+(26.687)+(29.127)+(41.045)+(57.786));
	tcb->m_ssThresh = (int) (7.853*(13.785)*(5.185));

}
