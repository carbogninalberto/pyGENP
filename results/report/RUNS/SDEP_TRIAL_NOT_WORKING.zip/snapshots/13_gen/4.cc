int GzFAMKzPcLRBXYEA = (int) (1.24+(2.937)+(-95.185)+(77.968));
