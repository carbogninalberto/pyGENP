int cpysYANsLNIgaYpb = (int) (62.173*(58.746));
int OfaEMgYcnKuciorV = (int) (52.701-(42.624)-(-15.831));
float zztlJwmmVukwepoP = (float) (98.95-(-24.154)-(-64.907)-(-19.404)-(-56.923)-(4.59));
float LAwboduikMuTNMUJ = (float) (81.394/-96.81);
