int cpysYANsLNIgaYpb = (int) (-47.844*(-43.601));
int OfaEMgYcnKuciorV = (int) (22.999-(36.802)-(81.581));
float zztlJwmmVukwepoP = (float) (4.671-(-86.3)-(-68.168)-(-30.44)-(64.065)-(-94.552));
OfaEMgYcnKuciorV = (int) (-55.269/-20.484);
