int bjTOBeuWtOTqYDMy = (int) (-11.959-(-50.099)-(-7.724)-(42.184)-(91.631)-(-31.073));
int FVrorhLXPyLyQJgc = (int) (11.849/-81.439);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
