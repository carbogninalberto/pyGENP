int FVrorhLXPyLyQJgc = (int) (-21.222/57.67);
int bjTOBeuWtOTqYDMy = (int) (-10.819-(-87.449)-(88.408)-(98.774)-(25.558)-(67.066));
CongestionAvoidance (tcb, segmentsAcked);
float daulzrsGPNFCmMus = (float) (-36.737-(-93.837)-(36.968)-(48.468)-(36.468)-(-74.324));
segmentsAcked = SlowStart (tcb, segmentsAcked);
int rNMHgddneZCflCED = (int) (-5.978+(47.21)+(-89.765)+(70.751)+(-58.391)+(54.207));
