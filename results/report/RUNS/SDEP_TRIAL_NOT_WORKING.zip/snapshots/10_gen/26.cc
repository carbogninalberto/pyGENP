int gxhbhMkXFbsIAbxl = (int) (9.152/(99.959-(-56.417)));
int fDimxEsRTUlxGHDM = (int) (16.374+(-96.257)+(-94.304)+(-43.584)+(-4.271)+(17.238));
segmentsAcked = (int) (-95.006*(-95.001)*(-48.049)*(61.408)*(63.374));
float vZwoTOrBWlARvgaE = (float) (94.55/-24.515);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-24.119*(-94.966)*(21.555)*(-44.959)*(-89.335));
CongestionAvoidance (tcb, segmentsAcked);
