float vUrePazgRQzNAsFZ = (float) (((46.846)+((67.172+(segmentsAcked)+(84.73)+(9.958)+(31.625)))+(19.121)+(0.1))/((0.1)));
int AghzqnQWpoRKdAmd = (int) (20.436+(37.05)+(94.554));
if (segmentsAcked <= vUrePazgRQzNAsFZ) {
	tcb->m_cWnd = (int) (85.258+(39.114));

} else {
	tcb->m_cWnd = (int) (49.913-(29.817)-(92.742)-(63.126)-(10.064)-(60.487)-(81.283));

}
CongestionAvoidance (tcb, segmentsAcked);
if (AghzqnQWpoRKdAmd >= tcb->m_segmentSize) {
	vUrePazgRQzNAsFZ = (float) (93.203*(AghzqnQWpoRKdAmd)*(86.373)*(84.408)*(78.99)*(23.751)*(AghzqnQWpoRKdAmd)*(18.256));
	tcb->m_ssThresh = (int) (0.1/(67.31*(tcb->m_ssThresh)*(80.64)*(tcb->m_ssThresh)*(23.254)*(54.68)*(95.763)*(47.459)));
	tcb->m_cWnd = (int) (0.1/50.066);
	tcb->m_ssThresh = (int) (2.524/0.1);
	AghzqnQWpoRKdAmd = (int) (21.056*(7.796));

} else {
	vUrePazgRQzNAsFZ = (float) (99.375*(8.434)*(75.939)*(segmentsAcked)*(85.277)*(AghzqnQWpoRKdAmd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
int ZbFDhGFKfmAghuJj = (int) (82.931-(71.381)-(59.599)-(98.353)-(73.209)-(47.912)-(39.487)-(13.672));
float yQVshYGHutsRVHKa = (float) (21.826-(54.656)-(32.726)-(49.322));
