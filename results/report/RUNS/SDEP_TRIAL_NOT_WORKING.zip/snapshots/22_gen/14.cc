tcb->m_segmentSize = (int) (((0.1)+((12.339*(71.606)*(14.484)*(81.353)*(21.99)*(46.456)*(50.305)*(5.573)))+((24.548-(37.857)-(0.058)-(97.65)-(tcb->m_segmentSize)))+(15.594))/((24.698)+(0.1)));
float VCOphkVJiOBsbalJ = (float) (55.244*(11.923)*(7.068));
VCOphkVJiOBsbalJ = (float) (49.135-(tcb->m_ssThresh));
int AoBQfgyjXnTpZCxV = (int) (69.042/0.1);
int mVxVyfQLkpweFzYA = (int) (56.03/0.1);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
float eyrpYazfnIicaZMQ = (float) (38.8*(36.25)*(77.181)*(65.807)*(AoBQfgyjXnTpZCxV)*(17.482)*(3.722)*(37.604)*(VCOphkVJiOBsbalJ));
