float ObkqGxKgITqoxyMb = (float) (tcb->m_segmentSize+(22.206)+(9.048)+(tcb->m_ssThresh)+(20.339));
int qBeKfPKajeRGrCyz = (int) (56.306/42.591);
float cjaIJgFlaUbSdFYz = (float) (tcb->m_segmentSize-(66.726)-(71.576)-(18.382)-(34.62));
int FRYEOLqFABpIWDFK = (int) (64.694-(8.798));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
