CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
int aLMxPCAwGQDUxstn = (int) (41.824-(72.97)-(86.635)-(83.653)-(39.531)-(tcb->m_segmentSize)-(57.395)-(85.42));
int nOyNApAzhxalGoTY = (int) (segmentsAcked+(41.334)+(tcb->m_segmentSize)+(9.056)+(25.817)+(tcb->m_cWnd)+(96.449)+(93.185)+(82.705));
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(57.505)-(22.928)-(63.491)-(99.807)-(21.003));
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (26.162*(40.045)*(98.027)*(36.434)*(0.246)*(tcb->m_cWnd)*(10.669)*(aLMxPCAwGQDUxstn)*(38.239));

} else {
	tcb->m_ssThresh = (int) (0.1/47.54);
	segmentsAcked = (int) (tcb->m_cWnd-(7.875)-(segmentsAcked)-(52.856)-(tcb->m_cWnd));

}
float JTEunlHmHVvrekci = (float) (98.594+(tcb->m_cWnd)+(41.141)+(22.273)+(nOyNApAzhxalGoTY)+(aLMxPCAwGQDUxstn)+(57.458));
if (JTEunlHmHVvrekci == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(92.041)+(33.528)+(78.636)+(39.03));
	segmentsAcked = (int) (tcb->m_cWnd+(83.328)+(42.963)+(27.191)+(66.805));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(7.257)*(2.851)*(10.066)*(24.375)*(87.914)*(95.413)*(50.029)*(95.559));
	JTEunlHmHVvrekci = (float) (((23.161)+(0.1)+(0.1)+(0.1)+(0.1))/((74.23)));
	nOyNApAzhxalGoTY = (int) (42.386*(40.403)*(95.743)*(89.851)*(JTEunlHmHVvrekci)*(15.993));

}
int sgSLWJNvQvsmXcfl = (int) (((0.1)+(0.1)+(0.1)+(27.961)+(38.999)+(93.767)+((0.904*(12.17)*(tcb->m_segmentSize)*(33.456)*(37.435)*(97.065)*(22.698)))+(48.042))/((85.779)));
