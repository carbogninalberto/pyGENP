int XkWqRPuiLhbVDyjp = (int) (((0.1)+(0.1)+((tcb->m_ssThresh*(19.681)*(12.343)*(tcb->m_segmentSize)))+(46.438)+((5.693-(7.879)-(55.641)-(9.357)-(19.147)-(6.387)-(55.816)))+(47.061))/((90.552)));
float yepPviIMFCMnAceA = (float) (0.1/74.367);
tcb->m_cWnd = (int) (46.311+(yepPviIMFCMnAceA));
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	XkWqRPuiLhbVDyjp = (int) (((0.1)+(0.1)+(78.473)+(0.1)+(17.557))/((20.341)+(42.423)+(0.1)));
	tcb->m_segmentSize = (int) (64.879+(47.511)+(67.889));

} else {
	XkWqRPuiLhbVDyjp = (int) (((45.894)+(83.669)+(55.25)+((63.888-(88.481)-(10.445)-(23.673)))+(0.1))/((45.054)+(14.174)+(60.747)));
	tcb->m_segmentSize = (int) (9.332-(82.093)-(16.496));
	segmentsAcked = (int) (73.23+(81.465)+(98.44)+(16.644)+(95.384)+(97.066)+(27.468)+(59.211));

}
float iooXdIKbTSxcOTBy = (float) (94.642+(82.949));
