int wmnshezwouXFeAYN = (int) (segmentsAcked*(18.818));
float fUvigrBqZKftFrjP = (float) (((0.1)+(0.1)+(0.1)+(67.428))/((96.321)));
if (tcb->m_cWnd >= fUvigrBqZKftFrjP) {
	fUvigrBqZKftFrjP = (float) (58.275*(wmnshezwouXFeAYN));
	segmentsAcked = (int) (53.167-(80.761)-(98.34)-(37.628)-(83.708)-(73.15)-(37.261));

} else {
	fUvigrBqZKftFrjP = (float) (0.1/1.693);

}
float ENILjkTIyiMdhOUP = (float) (((65.686)+((55.128-(64.726)-(tcb->m_ssThresh)-(42.943)-(89.475)-(5.217)-(tcb->m_ssThresh)-(17.96)-(88.384)))+((40.03-(58.548)-(80.812)-(84.405)-(58.566)))+(30.368)+((7.097-(18.629)-(62.61)-(87.306)-(70.734)-(93.759)-(tcb->m_segmentSize)))+(0.1))/((46.311)+(0.1)));
if (tcb->m_cWnd != wmnshezwouXFeAYN) {
	fUvigrBqZKftFrjP = (float) (((0.1)+(0.1)+((71.742*(63.003)*(98.676)*(35.142)*(73.65)*(33.184)*(ENILjkTIyiMdhOUP)*(wmnshezwouXFeAYN)))+(40.753))/((70.356)+(26.576)+(0.1)));
	tcb->m_ssThresh = (int) (21.09-(99.657)-(tcb->m_cWnd)-(fUvigrBqZKftFrjP));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(82.444)+(72.704));

} else {
	fUvigrBqZKftFrjP = (float) (83.679*(43.152)*(14.092));
	ENILjkTIyiMdhOUP = (float) (0.1/71.911);

}
