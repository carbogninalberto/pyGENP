float UYrpVkclatbNozxV = (float) (55.2-(tcb->m_segmentSize)-(42.435));
int cNXQvHMllBHpJvyk = (int) (84.243+(UYrpVkclatbNozxV)+(34.475)+(92.835)+(16.143)+(55.281)+(86.061)+(tcb->m_cWnd)+(50.462));
tcb->m_ssThresh = (int) (86.708-(95.645)-(42.1)-(33.644)-(83.115)-(79.533)-(69.312));
tcb->m_ssThresh = (int) (59.866-(45.848)-(cNXQvHMllBHpJvyk));
float BAnWFFqAOJqiyXCI = (float) (9.366/0.1);
tcb->m_ssThresh = (int) (UYrpVkclatbNozxV-(12.184)-(13.441)-(2.041)-(47.972)-(tcb->m_ssThresh)-(tcb->m_segmentSize));
UYrpVkclatbNozxV = (float) (((1.271)+(0.1)+(65.55)+(0.1)+(0.1))/((0.1)));
float LGSccmejgpIwlBNR = (float) (11.728+(29.451));
