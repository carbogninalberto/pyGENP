if (tcb->m_segmentSize != tcb->m_cWnd) {
	segmentsAcked = (int) (19.689+(22.449));
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(55.505)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(62.127));
	tcb->m_cWnd = (int) (segmentsAcked+(tcb->m_ssThresh)+(79.543)+(38.55)+(2.184));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(segmentsAcked)+(99.735));

} else {
	segmentsAcked = (int) (56.211-(tcb->m_ssThresh));

}
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((segmentsAcked+(tcb->m_segmentSize)+(38.868)+(31.844)+(43.7)+(92.222)+(38.673)+(51.972))/(8.732+(segmentsAcked)+(67.021)+(78.239)+(31.45)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (19.968*(42.63));

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (28.725-(53.885)-(28.611)-(11.05)-(tcb->m_segmentSize)-(45.789));

} else {
	tcb->m_cWnd = (int) (13.156-(66.995));
	tcb->m_segmentSize = (int) (98.308+(18.766)+(35.584)+(97.731));
	segmentsAcked = (int) (tcb->m_cWnd-(90.549)-(19.849)-(41.159)-(33.378)-(61.109)-(tcb->m_segmentSize));

}
float QArsIVXFcIlGHOVb = (float) (92.128*(38.09)*(44.248));
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(6.008)+(0.1))/((74.072)+(0.1)+(39.909)));
	segmentsAcked = (int) (92.02*(86.11)*(16.356)*(74.226)*(76.968)*(segmentsAcked)*(49.969));
	tcb->m_cWnd = (int) (0.1/10.642);
	tcb->m_cWnd = (int) (25.951*(tcb->m_ssThresh)*(14.774)*(62.252)*(86.23)*(65.635)*(82.543)*(24.314)*(10.894));
	segmentsAcked = (int) (20.193-(QArsIVXFcIlGHOVb)-(45.519));

} else {
	tcb->m_segmentSize = (int) (16.683-(59.269)-(78.764)-(15.027)-(15.85)-(QArsIVXFcIlGHOVb)-(8.219)-(98.587)-(tcb->m_ssThresh));
	QArsIVXFcIlGHOVb = (float) (tcb->m_cWnd-(22.084)-(71.504)-(27.712));
	tcb->m_cWnd = (int) (41.767+(73.648)+(0.267)+(73.793));
	tcb->m_ssThresh = (int) (77.976+(87.076)+(30.208));

}
float lRjNtbRYCAikrXyJ = (float) ((84.702-(91.251)-(64.485))/0.1);
