if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (42.755+(95.13)+(tcb->m_cWnd)+(59.011)+(65.822)+(4.386)+(71.247));
	tcb->m_cWnd = (int) ((tcb->m_segmentSize*(tcb->m_cWnd)*(tcb->m_segmentSize))/0.1);

} else {
	tcb->m_cWnd = (int) (9.919-(84.325)-(39.738));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
