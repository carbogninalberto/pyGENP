float KpSMyrpouJsPgCxf = (float) (3.985-(32.831)-(-37.145)-(99.756)-(-40.497)-(-45.293));
int nVpTROslbMORUAZI = (int) (-41.211*(34.554)*(-49.542));
int xLaTkdbYrfzngzWA = (int) (((-77.873)+(-56.512)+(48.162)+(55.023))/((42.73)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (15.968+(-2.548)+(-6.095));
