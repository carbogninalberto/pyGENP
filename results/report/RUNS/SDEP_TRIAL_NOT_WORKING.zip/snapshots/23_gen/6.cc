int QsTgzbhMhyvcXNIE = (int) (26.612*(0.569));
float sZWSVOdJwfZMXBma = (float) (-69.857-(-20.631)-(-84.21)-(1.395)-(-87.584)-(-42.317)-(-76.043)-(-36.571));
CongestionAvoidance (tcb, segmentsAcked);
float RWRSehadEwTjQUqL = (float) 67.046;
CongestionAvoidance (tcb, segmentsAcked);
