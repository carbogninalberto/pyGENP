int RIkyMuniaEYEBqzw = (int) (0.477*(64.408)*(90.46)*(-55.13)*(-41.659)*(-66.699)*(-50.499));
int QREKBwtAFkZPcRls = (int) (60.153/13.115);
float OizzhEkqTPXtNsGc = (float) (-50.321-(45.138)-(-8.789)-(-37.662)-(33.069)-(-72.998)-(-51.044));
int ILVuoxYfBTfIkOOD = (int) (-60.496*(43.623)*(-31.441)*(70.053));
