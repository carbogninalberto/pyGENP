int XBAVdkxAbqzZLpMV = (int) (19.344-(segmentsAcked)-(51.561));
int ZqBHWUsNCWCJZDZd = (int) (((0.1)+(0.1)+(0.1)+((64.852*(40.756)*(39.651)*(53.489)*(tcb->m_ssThresh)*(59.052)*(71.399)*(XBAVdkxAbqzZLpMV)*(42.104)))+(0.1))/((0.1)+(0.1)));
if (ZqBHWUsNCWCJZDZd == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (56.433+(segmentsAcked)+(13.011)+(tcb->m_ssThresh)+(84.679)+(94.401)+(59.546)+(40.954)+(16.485));

} else {
	tcb->m_segmentSize = (int) (46.138-(16.676)-(71.947)-(2.177)-(82.31)-(XBAVdkxAbqzZLpMV)-(13.62));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (66.538-(12.701)-(31.268));

}
int ovcmeQHNGKlrxkvq = (int) (0.1/59.866);
float CasFWPfGJxJbZWyT = (float) (82.27/0.1);
float IkbqlTPmVRTgoFKI = (float) (77.581-(76.342)-(27.427)-(29.449)-(53.909)-(64.23)-(tcb->m_cWnd)-(ovcmeQHNGKlrxkvq)-(ovcmeQHNGKlrxkvq));
if (segmentsAcked <= tcb->m_cWnd) {
	ZqBHWUsNCWCJZDZd = (int) (tcb->m_segmentSize*(81.843)*(CasFWPfGJxJbZWyT)*(17.433)*(45.3)*(75.089));
	tcb->m_ssThresh = (int) (ZqBHWUsNCWCJZDZd+(61.439)+(96.392));

} else {
	ZqBHWUsNCWCJZDZd = (int) ((tcb->m_ssThresh*(48.512)*(5.129)*(64.28)*(48.915)*(30.742)*(60.212)*(68.331)*(83.935))/0.1);
	ZqBHWUsNCWCJZDZd = (int) ((((90.105+(segmentsAcked)+(94.768)+(72.242)+(24.497)+(76.815)+(25.804)+(15.551)))+(36.684)+(65.762)+(0.1))/((32.572)+(81.13)+(0.1)+(0.1)+(0.1)));
	XBAVdkxAbqzZLpMV = (int) (29.981-(67.659)-(80.118)-(51.573)-(40.896));
	tcb->m_segmentSize = (int) (67.616+(66.279)+(27.952));

}
ovcmeQHNGKlrxkvq = (int) (23.261-(tcb->m_segmentSize));
ZqBHWUsNCWCJZDZd = (int) ((94.258*(tcb->m_ssThresh)*(9.269)*(tcb->m_cWnd)*(91.446)*(tcb->m_segmentSize)*(69.109)*(33.959)*(IkbqlTPmVRTgoFKI))/61.743);
