int kKCAkFfuaxsIRRXX = (int) (52.094-(14.119)-(21.675)-(56.357)-(9.492)-(87.844)-(43.795)-(54.544)-(tcb->m_cWnd));
int MbaGGrLYEaLlZBHT = (int) (tcb->m_ssThresh-(30.56)-(53.483)-(28.755)-(32.141)-(17.434)-(19.847));
int FNPMKzaebCTikDdp = (int) (0.1/0.1);
float ABJJFqVaRJZkBOIO = (float) (0.1/0.1);
float cSAofBNankpREaoc = (float) (tcb->m_segmentSize+(28.701)+(tcb->m_ssThresh)+(58.672)+(9.307)+(2.059)+(74.789)+(45.236)+(76.96));
if (ABJJFqVaRJZkBOIO <= segmentsAcked) {
	tcb->m_cWnd = (int) (53.201*(34.455)*(FNPMKzaebCTikDdp)*(tcb->m_segmentSize));
	FNPMKzaebCTikDdp = (int) (92.358+(tcb->m_cWnd)+(22.844)+(25.144)+(72.376));

} else {
	tcb->m_cWnd = (int) (61.691+(1.19)+(92.126)+(92.378)+(82.888)+(41.994)+(15.406)+(32.349));
	MbaGGrLYEaLlZBHT = (int) (kKCAkFfuaxsIRRXX+(tcb->m_ssThresh)+(98.573)+(41.849)+(79.99)+(tcb->m_segmentSize)+(34.634)+(88.023)+(17.357));

}
float QTXluuiDzNcSzjbt = (float) (((0.1)+(60.821)+(61.935)+(40.276)+(0.1))/((0.1)+(88.345)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (FNPMKzaebCTikDdp+(16.357)+(89.863)+(70.964)+(segmentsAcked)+(9.245));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ABJJFqVaRJZkBOIO = (float) (42.146*(18.561)*(49.786)*(76.539)*(tcb->m_segmentSize)*(54.418)*(tcb->m_segmentSize)*(72.018));
	segmentsAcked = (int) (19.842*(48.938)*(7.932)*(kKCAkFfuaxsIRRXX)*(64.514));

} else {
	tcb->m_ssThresh = (int) (91.609-(7.347)-(70.083)-(segmentsAcked));
	ABJJFqVaRJZkBOIO = (float) (((0.1)+(9.801)+(0.1)+(0.1))/((87.831)+(62.775)+(0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (27.441-(tcb->m_segmentSize)-(93.28)-(tcb->m_segmentSize)-(21.275)-(27.085)-(segmentsAcked)-(85.585));

}
