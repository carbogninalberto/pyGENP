int RIkyMuniaEYEBqzw = (int) (-97.148*(-63.52)*(-21.706)*(15.02)*(-36.086)*(-52.93)*(-61.462));
int QREKBwtAFkZPcRls = (int) (40.426/-90.801);
float OizzhEkqTPXtNsGc = (float) (-61.708-(48.003)-(25.127)-(-20.12)-(80.89)-(28.529)-(-55.124));
int ILVuoxYfBTfIkOOD = (int) (-74.22*(-76.742)*(26.886)*(-84.419));
