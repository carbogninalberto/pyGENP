TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int FVrorhLXPyLyQJgc = (int) (-30.777/9.994);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int bjTOBeuWtOTqYDMy = (int) (-98.458-(-39.407)-(13.263)-(-85.313)-(1.011)-(-59.024));
CongestionAvoidance (tcb, segmentsAcked);
int gWfeZFYjqKfLKuOg = (int) (77.836+(34.475)+(-73.879)+(32.259)+(82.715));
