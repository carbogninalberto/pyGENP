int RIkyMuniaEYEBqzw = (int) (74.904*(-51.435)*(-67.042)*(-36.948)*(20.195)*(71.545)*(-9.282));
int QREKBwtAFkZPcRls = (int) (-58.191/7.438);
if (QREKBwtAFkZPcRls <= tcb->m_cWnd) {
	segmentsAcked = (int) (30.175-(74.217)-(19.455));
	tcb->m_cWnd = (int) (50.049*(84.725)*(2.634)*(5.139));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(54.776)+(36.876)+(35.292)+(42.707));
	ReduceCwnd (tcb);

}
float OizzhEkqTPXtNsGc = (float) (-90.414-(82.735)-(-97.833)-(92.678)-(-23.841)-(-16.483)-(57.167));
if (QREKBwtAFkZPcRls <= tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_segmentSize+(54.776)+(36.876)+(35.292)+(42.707));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (30.175-(74.217)-(19.455));
	tcb->m_cWnd = (int) (50.049*(84.725)*(2.634)*(5.139));

}
int ILVuoxYfBTfIkOOD = (int) (-40.705*(71.688)*(46.459)*(58.502));
