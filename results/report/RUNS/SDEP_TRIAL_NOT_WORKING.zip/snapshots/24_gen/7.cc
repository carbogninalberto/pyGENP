float jZaMfCBvJaOzvEGI = (float) (62.681+(-16.565)+(-48.882)+(25.04)+(-42.865)+(-49.195));
int mdhfDrxpmslmQUgc = (int) (60.818/-52.865);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
