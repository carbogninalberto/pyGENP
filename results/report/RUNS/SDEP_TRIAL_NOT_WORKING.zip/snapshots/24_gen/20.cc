tcb->m_segmentSize = (int) (segmentsAcked-(26.852)-(15.223)-(segmentsAcked)-(2.21)-(63.921)-(tcb->m_ssThresh)-(44.628));
int GoXbWWcetUqMsgEq = (int) (26.645*(1.797)*(43.156)*(27.764)*(24.189)*(30.467)*(87.197));
float bVmddosgIZvMOKSZ = (float) (91.708-(27.262)-(73.386));
float jQRPZPJIuaAocgrt = (float) (tcb->m_cWnd-(63.215)-(34.889)-(2.676)-(tcb->m_cWnd));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
