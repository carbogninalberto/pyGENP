float mYoDHLYvhdExuHjm = (float) (8.722-(43.285)-(-42.957)-(-69.304)-(-43.275)-(0.164)-(-4.191)-(88.492)-(-57.896));
float VFnlQInGPxNyIyns = (float) (14.716+(68.032));
segmentsAcked = (int) (-30.308-(71.873));
