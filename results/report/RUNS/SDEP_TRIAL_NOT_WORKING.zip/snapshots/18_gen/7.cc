int rfPmUgjQwHZrrSXI = (int) (27.343*(77.231)*(87.106)*(19.112)*(-13.059)*(34.739)*(67.183)*(81.315)*(46.601));
int UFoJOahyacsslxDf = (int) (75.801+(35.72)+(-37.685)+(18.607)+(58.565)+(86.144)+(-3.567)+(-95.86)+(-88.648));
float lASvBkWvChJbvFlc = (float) ((98.624+(37.572))/-40.898);
int SblgjDZylCVEqXUk = (int) ((5.127*(46.678)*(-3.348)*(-41.588)*(-94.517)*(-92.632))/-10.892);
SblgjDZylCVEqXUk = (int) (16.481-(-13.944)-(31.668)-(58.378));
if (SblgjDZylCVEqXUk < tcb->m_segmentSize) {
	segmentsAcked = (int) (61.885*(SblgjDZylCVEqXUk));
	SblgjDZylCVEqXUk = (int) (4.844+(27.634)+(segmentsAcked)+(SblgjDZylCVEqXUk)+(93.384)+(34.974)+(24.887));

} else {
	segmentsAcked = (int) (0.1/0.1);
	segmentsAcked = (int) (SblgjDZylCVEqXUk*(92.956)*(57.418)*(55.631)*(56.338)*(84.459));
	lASvBkWvChJbvFlc = (float) (14.129*(SblgjDZylCVEqXUk)*(62.587)*(54.614));

}
UFoJOahyacsslxDf = (int) (93.352+(-78.629)+(44.864));
