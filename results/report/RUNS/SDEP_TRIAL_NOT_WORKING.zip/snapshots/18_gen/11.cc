int NdWfTbwWmlcpKuKH = (int) (0.1/80.018);
tcb->m_cWnd = (int) (tcb->m_cWnd-(65.365)-(97.456)-(43.07)-(47.338)-(3.103)-(87.749)-(83.046));
float sdgKthYVIUpMHkGy = (float) ((55.604-(tcb->m_ssThresh)-(1.957)-(75.577)-(25.645)-(67.567))/77.546);
int VyjNCWybwpOoTJeV = (int) (0.1/65.369);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
