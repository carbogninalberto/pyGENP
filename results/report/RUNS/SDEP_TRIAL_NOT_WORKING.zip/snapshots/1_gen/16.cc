tcb->m_ssThresh = (int) (24.679-(tcb->m_segmentSize)-(53.326)-(39.151)-(72.066)-(56.623));
float EpbvnWThklgUTVPv = (float) (tcb->m_segmentSize-(60.811)-(25.134)-(4.943));
tcb->m_cWnd = (int) (0.1/86.951);
int gxQZLjpaIJAUirsn = (int) (79.136+(74.856)+(tcb->m_ssThresh)+(49.248)+(EpbvnWThklgUTVPv)+(tcb->m_ssThresh)+(48.709));
tcb->m_ssThresh = (int) (75.343+(64.864));
int CByAjFAaHlYgdyeT = (int) (0.1/0.1);
int JAhRcNumVBkoAFZi = (int) (82.645/0.1);
JAhRcNumVBkoAFZi = (int) (77.649+(44.56)+(89.767)+(8.137)+(CByAjFAaHlYgdyeT)+(58.436)+(tcb->m_segmentSize));
