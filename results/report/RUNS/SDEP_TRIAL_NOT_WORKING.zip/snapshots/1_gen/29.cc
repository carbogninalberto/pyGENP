float rNswZKGLFGZZNbQh = (float) (3.952-(23.825)-(6.21)-(71.056)-(12.742)-(tcb->m_ssThresh));
int xxwzHfOAdIzkitez = (int) (38.49+(segmentsAcked)+(8.273));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (rNswZKGLFGZZNbQh+(14.804)+(74.065)+(20.144)+(11.551)+(57.579)+(13.475)+(rNswZKGLFGZZNbQh)+(70.562));
if (tcb->m_ssThresh == rNswZKGLFGZZNbQh) {
	tcb->m_ssThresh = (int) (53.952/0.1);
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (rNswZKGLFGZZNbQh-(93.405)-(23.227));

} else {
	tcb->m_ssThresh = (int) (96.292+(99.103)+(79.473)+(49.484)+(76.988)+(11.49)+(99.598));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
float dlSsVmXLkVmJeTbH = (float) (66.22-(tcb->m_segmentSize)-(83.813)-(27.134)-(50.444)-(2.118));
if (tcb->m_ssThresh > rNswZKGLFGZZNbQh) {
	segmentsAcked = (int) ((tcb->m_ssThresh+(50.559)+(31.615)+(52.875)+(23.848)+(77.78)+(93.8)+(33.846))/0.1);
	tcb->m_segmentSize = (int) (31.791+(76.164)+(48.88)+(54.804)+(60.434)+(dlSsVmXLkVmJeTbH)+(26.952)+(36.39)+(rNswZKGLFGZZNbQh));
	dlSsVmXLkVmJeTbH = (float) (76.18*(34.264)*(84.651)*(7.832));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (dlSsVmXLkVmJeTbH+(22.47)+(xxwzHfOAdIzkitez)+(12.282)+(34.158)+(18.323));
	tcb->m_cWnd = (int) (tcb->m_cWnd*(33.267));
	tcb->m_ssThresh = (int) (99.088+(18.571)+(87.809)+(83.101)+(99.561)+(45.915)+(97.54)+(96.173));
	tcb->m_ssThresh = (int) (70.346-(36.431)-(97.339)-(28.128)-(4.512)-(14.528)-(11.391)-(tcb->m_cWnd)-(rNswZKGLFGZZNbQh));
	tcb->m_ssThresh = (int) ((55.196-(37.302)-(95.236)-(39.207)-(38.29)-(89.58)-(segmentsAcked)-(90.735)-(57.815))/39.855);

}
if (segmentsAcked != dlSsVmXLkVmJeTbH) {
	tcb->m_ssThresh = (int) (75.742-(20.531)-(61.437));

} else {
	tcb->m_ssThresh = (int) (29.401+(52.93)+(91.597)+(8.728)+(4.891)+(rNswZKGLFGZZNbQh)+(xxwzHfOAdIzkitez)+(xxwzHfOAdIzkitez));

}
tcb->m_cWnd = (int) (11.086-(65.391)-(65.114)-(82.217)-(27.09)-(89.479));
