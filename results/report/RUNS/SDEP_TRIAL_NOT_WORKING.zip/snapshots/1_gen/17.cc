float oCjzfEfQVLOEJAul = (float) (tcb->m_cWnd-(17.085)-(27.934)-(10.514)-(31.458)-(94.272));
float VwJUZajaAHGxohHQ = (float) (57.468/0.1);
int BBuayfMNxWcRvLOX = (int) (22.25+(2.242)+(1.375)+(97.337)+(VwJUZajaAHGxohHQ)+(60.391));
float SBrURduJzDaYtCyF = (float) (59.18+(21.773)+(49.574)+(3.476)+(91.202)+(oCjzfEfQVLOEJAul));
float QnxVClbYmXcJYFtt = (float) (5.797-(tcb->m_cWnd)-(20.801)-(36.614)-(78.747)-(59.709)-(47.18));
if (tcb->m_ssThresh == VwJUZajaAHGxohHQ) {
	tcb->m_cWnd = (int) (4.111+(81.423)+(8.791));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) ((29.761+(19.702)+(39.509))/(38.106-(71.999)-(77.978)-(89.535)-(BBuayfMNxWcRvLOX)-(76.996)-(27.073)));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) ((44.605+(65.955)+(76.61)+(88.517)+(51.569))/26.211);

}
