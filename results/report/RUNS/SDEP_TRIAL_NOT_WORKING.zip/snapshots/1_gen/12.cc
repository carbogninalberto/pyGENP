float ZkkOXxTGZQzJlWez = (float) (51.536*(tcb->m_segmentSize));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > ZkkOXxTGZQzJlWez) {
	tcb->m_segmentSize = (int) (69.418+(62.436)+(70.105)+(0.934));
	tcb->m_segmentSize = (int) (segmentsAcked*(tcb->m_cWnd)*(11.532)*(18.045)*(53.151)*(segmentsAcked)*(52.668)*(ZkkOXxTGZQzJlWez)*(17.413));

} else {
	tcb->m_segmentSize = (int) (48.81+(tcb->m_ssThresh)+(19.493)+(38.27)+(segmentsAcked)+(21.36)+(48.682)+(58.546));
	segmentsAcked = (int) ((((segmentsAcked*(44.22)))+((29.098-(56.986)-(tcb->m_segmentSize)-(81.083)-(67.69)-(55.703)-(tcb->m_segmentSize)-(62.767)-(segmentsAcked)))+((92.278*(40.621)*(tcb->m_cWnd)*(16.398)*(92.139)*(91.726)))+(96.787)+((1.912-(19.535)-(11.743)))+(10.183)+(0.1))/((77.297)));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(41.709)+(50.776)+(13.276)+(tcb->m_cWnd)+(50.136)+(12.557));

}
int piGyCvKUyWRyYSCQ = (int) (tcb->m_cWnd*(tcb->m_cWnd)*(67.069)*(34.109)*(tcb->m_ssThresh)*(99.435)*(22.562));
float MFTBZjWYfEFdOPne = (float) (60.266+(4.106)+(51.422)+(ZkkOXxTGZQzJlWez)+(36.302)+(68.337)+(tcb->m_ssThresh));
int nRmRYPUNbRPiTEFP = (int) (58.696-(30.518));
if (ZkkOXxTGZQzJlWez > MFTBZjWYfEFdOPne) {
	MFTBZjWYfEFdOPne = (float) (54.094*(21.324)*(42.888)*(69.227));
	piGyCvKUyWRyYSCQ = (int) (22.755+(62.969)+(50.343)+(96.732)+(nRmRYPUNbRPiTEFP)+(44.87)+(tcb->m_segmentSize)+(44.589)+(10.389));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (8.651+(tcb->m_ssThresh)+(5.773)+(42.723));

} else {
	MFTBZjWYfEFdOPne = (float) (7.49/63.812);

}
if (tcb->m_segmentSize != nRmRYPUNbRPiTEFP) {
	ZkkOXxTGZQzJlWez = (float) (31.096*(27.368)*(65.12));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	ZkkOXxTGZQzJlWez = (float) (0.1/40.54);
	ZkkOXxTGZQzJlWez = (float) (18.599/91.247);
	tcb->m_cWnd = (int) (nRmRYPUNbRPiTEFP*(ZkkOXxTGZQzJlWez)*(88.872)*(piGyCvKUyWRyYSCQ)*(66.251)*(7.336));
	nRmRYPUNbRPiTEFP = (int) (36.447*(tcb->m_segmentSize)*(78.04)*(16.047)*(27.867));

}
if (piGyCvKUyWRyYSCQ != nRmRYPUNbRPiTEFP) {
	segmentsAcked = (int) (34.977*(tcb->m_ssThresh)*(79.238)*(53.233)*(83.451));

} else {
	segmentsAcked = (int) (72.746+(75.773)+(15.241)+(segmentsAcked)+(MFTBZjWYfEFdOPne)+(54.083)+(segmentsAcked)+(64.438)+(nRmRYPUNbRPiTEFP));
	piGyCvKUyWRyYSCQ = (int) (17.134*(3.817)*(75.188)*(95.366));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (((22.828)+(0.1)+((80.721*(67.787)*(93.055)*(40.808)*(98.588)*(56.332)*(71.745)))+((61.739+(tcb->m_segmentSize)+(59.062)+(23.812)+(95.659)+(84.008)+(61.52)))+(15.369)+(0.1))/((56.972)));
	ReduceCwnd (tcb);

}
