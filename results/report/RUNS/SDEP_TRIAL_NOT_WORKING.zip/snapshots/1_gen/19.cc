CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float bJIxQxZfBakqqkBN = (float) (43.176-(22.345));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(19.975)*(tcb->m_segmentSize)*(95.533)*(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (21.1*(17.173)*(94.421)*(14.447)*(61.868)*(82.876)*(46.139)*(15.953));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (((0.1)+((tcb->m_ssThresh-(76.714)-(tcb->m_segmentSize)-(51.374)-(97.84)-(bJIxQxZfBakqqkBN)-(78.588)-(82.358)-(57.825)))+(60.617)+(0.1)+(64.295)+(0.1))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (71.379+(11.26)+(23.723));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
