int gmxirjdUGcXuQoWF = (int) (30.634*(73.089)*(38.885)*(18.502)*(68.71)*(20.101)*(78.308)*(75.679));
int rvMYltOqLIihupSv = (int) (tcb->m_segmentSize+(47.691));
float AYOsgwWLVuVdcKfw = (float) ((((93.282+(74.856)+(23.994)+(10.406)+(57.935)+(19.314)+(88.647)))+(53.221)+(0.1)+(5.222)+(0.1))/((34.825)+(0.1)));
segmentsAcked = (int) (((0.1)+(7.905)+(35.861)+(89.501)+((4.974-(40.534)))+(0.1))/((92.928)+(23.072)+(0.1)));
if (gmxirjdUGcXuQoWF >= tcb->m_cWnd) {
	AYOsgwWLVuVdcKfw = (float) (51.445-(81.974)-(11.46)-(gmxirjdUGcXuQoWF)-(rvMYltOqLIihupSv)-(tcb->m_cWnd)-(25.053));
	tcb->m_cWnd = (int) (((72.918)+(47.302)+(20.385)+(92.408)+(37.793)+(1.74)+(15.873))/((69.279)+(0.1)));

} else {
	AYOsgwWLVuVdcKfw = (float) (84.117-(99.471)-(48.037)-(79.017)-(0.547)-(79.496)-(tcb->m_cWnd));
	rvMYltOqLIihupSv = (int) (6.657/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (gmxirjdUGcXuQoWF-(rvMYltOqLIihupSv)-(41.194)-(6.676)-(58.791)-(8.613)-(94.938)-(38.138)-(84.323));
	CongestionAvoidance (tcb, segmentsAcked);

}
float lhqDTPZHGMAOZAjC = (float) (47.673*(71.313)*(52.002)*(tcb->m_segmentSize)*(23.425)*(38.354)*(9.473)*(64.525));
int YwuJkkIPfHSJHrbp = (int) (24.743*(79.248)*(34.489)*(9.437)*(lhqDTPZHGMAOZAjC));
int wHLInCIsjVUTTkAM = (int) (22.234+(87.063));
