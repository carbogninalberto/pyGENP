float fQYbkYIchFFNYtVP = (float) (((0.1)+((47.947-(52.135)-(47.326)-(4.902)-(48.977)-(tcb->m_ssThresh)-(14.498)-(segmentsAcked)-(tcb->m_cWnd)))+((13.235-(segmentsAcked)-(97.767)-(tcb->m_segmentSize)-(53.727)-(19.583)-(78.448)-(tcb->m_cWnd)))+(11.403))/((0.1)));
float fgjDllDiRyHzUQru = (float) (fQYbkYIchFFNYtVP-(83.373));
ReduceCwnd (tcb);
int ZHTehHdmsXsWzJPz = (int) (tcb->m_segmentSize+(tcb->m_cWnd)+(97.042)+(2.413));
int ecQCqZHCcjpeHMkY = (int) (47.256*(36.748));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
int JDLzIXFcTEzOPzXs = (int) (57.979+(20.865)+(42.42)+(64.634)+(69.813));
tcb->m_cWnd = (int) (15.434-(61.383)-(55.308)-(52.547)-(8.701));
