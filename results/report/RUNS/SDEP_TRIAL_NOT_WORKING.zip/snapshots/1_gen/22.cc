int JrZkopCLltwgNwWG = (int) (66.016-(tcb->m_cWnd)-(2.23)-(47.381)-(1.873)-(84.101)-(37.169)-(78.449));
int BUvxsdgTgJvZeAkI = (int) (tcb->m_ssThresh-(20.785)-(92.71)-(28.78)-(32.1)-(69.962)-(83.399)-(71.697)-(JrZkopCLltwgNwWG));
float GathzZaxvbaFwfgH = (float) (tcb->m_segmentSize+(JrZkopCLltwgNwWG)+(37.316)+(38.455)+(1.66)+(46.389)+(12.925)+(23.627)+(13.932));
int yHsJnAyVEskwnPfk = (int) (64.458+(29.571)+(48.772)+(segmentsAcked)+(23.73));
GathzZaxvbaFwfgH = (float) (33.6+(77.037)+(18.059)+(45.535)+(GathzZaxvbaFwfgH)+(tcb->m_cWnd)+(44.188)+(tcb->m_ssThresh));
segmentsAcked = (int) (BUvxsdgTgJvZeAkI-(26.75)-(segmentsAcked)-(33.416)-(66.933)-(80.351)-(36.735));
