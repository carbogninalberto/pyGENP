ReduceCwnd (tcb);
float IxUNnhAYVUlQqDYU = (float) (tcb->m_ssThresh+(60.259)+(30.017));
float mhLeAQHchSPjkxyf = (float) (98.782+(88.825)+(59.37)+(95.225)+(25.086));
if (mhLeAQHchSPjkxyf != segmentsAcked) {
	tcb->m_cWnd = (int) (89.103*(97.76)*(IxUNnhAYVUlQqDYU)*(mhLeAQHchSPjkxyf)*(tcb->m_segmentSize)*(tcb->m_cWnd));
	mhLeAQHchSPjkxyf = (float) (52.395+(7.961)+(tcb->m_segmentSize)+(29.236)+(9.696)+(62.227));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (48.985*(IxUNnhAYVUlQqDYU));

} else {
	tcb->m_cWnd = (int) (((0.1)+(53.849)+(0.1)+(46.692)+(0.1)+(39.057))/((0.1)));
	tcb->m_segmentSize = (int) (86.954+(0.028)+(12.924)+(tcb->m_ssThresh)+(94.456)+(44.978)+(62.498));

}
int kgkSAFmwFMpnyAOt = (int) (IxUNnhAYVUlQqDYU+(60.14)+(IxUNnhAYVUlQqDYU)+(13.488)+(13.668));
int IPlLrcvnZxAugBOa = (int) (((0.1)+(0.1)+(21.563)+(56.573)+(0.1)+((9.515*(31.259)*(mhLeAQHchSPjkxyf)))+(89.104))/((30.772)));
float driQrGYzHBELbopQ = (float) (19.268/0.1);
