int RIkyMuniaEYEBqzw = (int) (-35.572*(-38.419)*(29.428)*(-30.202)*(-82.523)*(36.195)*(76.666));
int QREKBwtAFkZPcRls = (int) (-98.368/86.459);
float OizzhEkqTPXtNsGc = (float) (38.806-(97.332)-(53.756)-(-73.624)-(52.989)-(-18.416)-(-21.421));
int ILVuoxYfBTfIkOOD = (int) (93.528*(37.942)*(5.022)*(34.332));
if (QREKBwtAFkZPcRls <= tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_segmentSize+(54.776)+(36.876)+(35.292)+(42.707));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (30.175-(74.217)-(19.455));
	tcb->m_cWnd = (int) (50.049*(84.725)*(2.634)*(5.139));

}
if (QREKBwtAFkZPcRls <= tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_segmentSize+(54.776)+(36.876)+(35.292)+(42.707));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (30.175-(74.217)-(19.455));
	tcb->m_cWnd = (int) (50.049*(84.725)*(2.634)*(5.139));

}
