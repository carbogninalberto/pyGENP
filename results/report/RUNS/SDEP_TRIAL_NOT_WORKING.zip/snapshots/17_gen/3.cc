float DsXaGneWcWfklWrv = (float) (83.012+(-85.133)+(-93.267));
