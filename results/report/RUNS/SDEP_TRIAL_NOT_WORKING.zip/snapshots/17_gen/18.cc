float xRDEtnXZpnyUtzph = (float) (tcb->m_segmentSize-(85.665));
float unNsFnVxEmOqOHSl = (float) (((0.1)+((20.812*(3.887)*(88.804)*(55.798)*(81.22)))+(13.037)+(0.1))/((0.1)));
int VHWwyxUQWUgPlgVB = (int) (4.716-(38.709)-(12.086)-(92.658));
float WpQtzwrAeicMBVsa = (float) (19.979+(88.988)+(10.158));
tcb->m_segmentSize = (int) (tcb->m_ssThresh*(VHWwyxUQWUgPlgVB)*(0.403)*(33.176)*(84.101)*(9.138)*(64.735)*(tcb->m_ssThresh)*(53.648));
