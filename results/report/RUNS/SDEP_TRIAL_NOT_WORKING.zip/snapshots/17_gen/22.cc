int vMJCttsAiXsVAhtI = (int) (44.949-(3.104)-(tcb->m_segmentSize)-(86.222)-(71.922)-(58.634));
int pqZmUtIRYsFLAXYc = (int) (12.282+(segmentsAcked));
float CFuJqEFUHBundaVP = (float) (88.59+(53.338));
float ZbgwmTtxYbByHqmg = (float) (((0.1)+(0.1)+(0.1)+(72.465)+(37.396))/((99.792)));
int rCHlUTSXAGMSGRQR = (int) (69.809+(1.573)+(23.102));
int jftBxJhVxEzqYUXf = (int) (segmentsAcked-(27.66)-(CFuJqEFUHBundaVP)-(4.012));
float GnPmOVezDGGUPFbG = (float) (98.055-(tcb->m_ssThresh)-(4.806)-(71.386));
float BKnGyHlUlxWsDaye = (float) (1.269+(88.754));
if (jftBxJhVxEzqYUXf == ZbgwmTtxYbByHqmg) {
	tcb->m_cWnd = (int) (74.788+(69.333)+(33.545)+(71.774)+(37.77)+(4.089)+(vMJCttsAiXsVAhtI)+(27.47)+(GnPmOVezDGGUPFbG));

} else {
	tcb->m_cWnd = (int) (60.309+(79.238)+(36.307)+(60.218)+(37.358)+(tcb->m_cWnd));
	pqZmUtIRYsFLAXYc = (int) (tcb->m_segmentSize-(35.672)-(76.963)-(16.138)-(pqZmUtIRYsFLAXYc)-(tcb->m_segmentSize)-(53.562));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	GnPmOVezDGGUPFbG = (float) (48.606*(37.835)*(31.193)*(BKnGyHlUlxWsDaye)*(54.418));
	segmentsAcked = (int) (((30.77)+((rCHlUTSXAGMSGRQR*(43.533)*(33.834)*(12.719)*(4.946)*(72.243)))+((81.774+(12.216)))+(29.982)+(96.397)+(51.786)+(0.1))/((0.1)+(0.1)));

}
