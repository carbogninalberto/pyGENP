int yxAvTFzqyRCrVCSX = (int) (30.1-(49.528)-(tcb->m_cWnd)-(tcb->m_cWnd)-(22.294)-(92.358));
tcb->m_segmentSize = (int) (86.599*(4.474)*(76.314)*(8.794)*(18.648)*(94.115)*(17.49)*(38.037));
int uYptRinxPOBJoWKR = (int) (((0.1)+((84.83-(66.772)-(28.359)-(29.617)-(59.924)-(74.5)-(7.683)))+(77.35)+(66.694)+(57.679))/((0.1)+(0.1)+(60.865)+(32.426)));
int QBgMKdHHAlxnYlkQ = (int) (0.1/0.1);
int MtAMNXIxkvqtZbpg = (int) (tcb->m_segmentSize+(51.536)+(75.615)+(77.131)+(67.98)+(QBgMKdHHAlxnYlkQ)+(19.946)+(41.276)+(52.918));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
