int BoCaFruhrNcUgKJG = (int) 72.942;
int mjGsEtxGdbirKfyo = (int) 45.562;
int DQgiIEnfiBonmiud = (int) 58.048;
float vdBqMkFTsoHKUvIm = (float) 57.946;
