float tHrmvmaKmFZSprJJ = (float) (33.694-(88.452)-(36.345)-(17.698));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
int fxMFzJTLSAthUgkw = (int) (segmentsAcked+(80.656));
float qWWVgTaOBeUOksAk = (float) (tHrmvmaKmFZSprJJ-(69.775)-(65.23));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
