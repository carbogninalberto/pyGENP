int aIkSKVngaYnopMjs = (int) (92.356-(-24.931)-(-39.257));
float NvgBqYUAmJAWQKhk = (float) (-63.414/30.054);
int KEVBxIWgDptaXepp = (int) (-82.985-(43.438)-(48.397)-(72.956)-(-84.844)-(82.85)-(7.464)-(16.346));
float pxcshOkQRXNatZVd = (float) (-78.109-(-35.165)-(47.47));
int VUDQOLavzxLVWHcj = (int) (-95.032-(-60.303)-(-5.518)-(-6.658)-(-0.335)-(73.953)-(97.88)-(-25.161)-(56.786));
