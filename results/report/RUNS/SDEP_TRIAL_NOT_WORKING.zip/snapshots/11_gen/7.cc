int rNMHgddneZCflCED = (int) 34.463;
float daulzrsGPNFCmMus = (float) (55.038-(67.549)-(-95.164)-(-95.858)-(-91.289)-(-35.417));
int bjTOBeuWtOTqYDMy = (int) (-11.369-(-8.153)-(25.475)-(-56.264)-(52.743)-(44.83));
int FVrorhLXPyLyQJgc = (int) (26.465/-49.939);
if (tcb->m_cWnd == tcb->m_segmentSize) {
	rNMHgddneZCflCED = (int) (rNMHgddneZCflCED-(tcb->m_segmentSize)-(tcb->m_cWnd)-(26.311)-(72.12)-(8.444)-(4.859)-(12.082)-(76.48));
	segmentsAcked = (int) (37.664-(66.048)-(95.464)-(67.476)-(tcb->m_segmentSize)-(92.541));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (39.753-(92.348)-(64.885)-(rNMHgddneZCflCED)-(44.901)-(84.906)-(55.145));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	rNMHgddneZCflCED = (int) (((0.1)+(0.1)+(15.938)+((77.174-(48.901)-(rNMHgddneZCflCED)-(89.664)-(98.389)-(8.549)))+(37.387))/((58.657)));
	tcb->m_segmentSize = (int) (17.718-(78.286)-(45.231)-(tcb->m_cWnd)-(51.855));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (-7.446-(36.321)-(44.503)-(44.707)-(56.185)-(53.758)-(91.038)-(54.145)-(90.32));
	segmentsAcked = (int) (70.296+(13.046)+(tcb->m_segmentSize)+(rNMHgddneZCflCED)+(rNMHgddneZCflCED)+(40.381)+(70.141)+(0.052));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
rNMHgddneZCflCED = (int) (-59.594-(-3.0)-(-43.492)-(-6.148)-(84.974)-(-58.182));
rNMHgddneZCflCED = (int) (-94.2-(-62.882)-(-62.914)-(-36.118)-(-42.018)-(-78.117));
rNMHgddneZCflCED = (int) (43.329-(-44.248)-(-91.189)-(-13.475)-(-15.977)-(50.626));
