int rNMHgddneZCflCED = (int) (34.432+(52.687)+(-61.884)+(-16.311)+(60.518)+(45.945));
float daulzrsGPNFCmMus = (float) (77.499-(-79.372)-(-78.884)-(-64.633)-(37.226)-(18.045));
int bjTOBeuWtOTqYDMy = (int) (89.432-(29.616)-(85.624)-(20.741)-(-71.563)-(-42.525));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
