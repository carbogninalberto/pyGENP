int ILVuoxYfBTfIkOOD = (int) (-46.136*(-39.873)*(-24.968)*(-44.593));
float OizzhEkqTPXtNsGc = (float) (87.875-(-92.746)-(-77.231)-(49.697)-(-96.068)-(8.943)-(50.595));
int QREKBwtAFkZPcRls = (int) (62.037/44.574);
if (QREKBwtAFkZPcRls <= tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_segmentSize+(54.776)+(36.876)+(35.292)+(42.707));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (30.175-(74.217)-(19.455));
	tcb->m_cWnd = (int) (50.049*(84.725)*(2.634)*(5.139));

}
if (QREKBwtAFkZPcRls <= tcb->m_cWnd) {
	segmentsAcked = (int) (30.175-(74.217)-(19.455));
	tcb->m_cWnd = (int) (50.049*(84.725)*(2.634)*(5.139));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(54.776)+(36.876)+(35.292)+(42.707));
	ReduceCwnd (tcb);

}
int RIkyMuniaEYEBqzw = (int) (-6.857*(26.237)*(-34.508)*(-58.275)*(-98.534)*(28.637)*(33.913));
if (QREKBwtAFkZPcRls <= tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_segmentSize+(54.776)+(36.876)+(35.292)+(42.707));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (30.175-(74.217)-(19.455));
	tcb->m_cWnd = (int) (50.049*(84.725)*(2.634)*(5.139));

}
