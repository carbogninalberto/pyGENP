int gxhbhMkXFbsIAbxl = (int) (93.04/(56.713-(-22.41)));
int fDimxEsRTUlxGHDM = (int) (-50.17+(39.327)+(-73.389)+(54.123)+(-9.307)+(-25.881));
segmentsAcked = (int) (-55.978*(95.988)*(49.081)*(-13.663)*(-8.834));
float vZwoTOrBWlARvgaE = (float) (29.446/-50.542);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (24.007*(86.798)*(38.395)*(-73.064)*(-10.987));
CongestionAvoidance (tcb, segmentsAcked);
