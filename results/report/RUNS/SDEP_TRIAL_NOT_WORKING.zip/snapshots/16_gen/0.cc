int BpLGhFWliwKIHmpm = (int) (-71.567*(-19.512));
int oThFUpCJZhbSROmL = (int) 86.736;
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
