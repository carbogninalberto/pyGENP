tcb->m_ssThresh = (int) (segmentsAcked*(tcb->m_segmentSize)*(48.357)*(13.735)*(25.913)*(97.592)*(9.512));
tcb->m_cWnd = (int) (tcb->m_cWnd*(35.515)*(7.524)*(78.204)*(27.211)*(18.911)*(48.62)*(tcb->m_ssThresh)*(13.792));
tcb->m_ssThresh = (int) (79.023+(65.045)+(2.541)+(49.433)+(53.677));
float FXhwjsQMakLmqoAX = (float) (0.1/0.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
