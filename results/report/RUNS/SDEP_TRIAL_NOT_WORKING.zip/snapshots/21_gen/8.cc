float qWWVgTaOBeUOksAk = (float) (-16.854-(14.691)-(13.361));
int fxMFzJTLSAthUgkw = (int) (36.969+(91.972));
ReduceCwnd (tcb);
int yAPfaDqMfjvSkspT = (int) (45.669-(12.009)-(42.026)-(42.728)-(99.831)-(79.64)-(-29.26)-(-91.566));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
