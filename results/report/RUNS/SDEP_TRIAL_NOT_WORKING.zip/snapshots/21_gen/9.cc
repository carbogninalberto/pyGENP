int FweuqUGVAhrFelYg = (int) (-77.09*(-98.665)*(72.82));
int WLVMMWxjwZnSTSGt = (int) (58.082+(8.469)+(46.927)+(5.927)+(-7.054)+(-44.611)+(94.625));
float EAHyicAWNZsiaqIQ = (float) (-98.608-(-22.024)-(-29.731)-(94.848)-(-50.382)-(39.681)-(-74.422)-(-56.286));
int qUFMFftSrMQlwagZ = (int) (-19.522-(64.128)-(-61.724)-(-52.783)-(-25.506)-(-40.322));
tcb->m_cWnd = (int) (-68.175+(6.7)+(70.239)+(-36.974));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
