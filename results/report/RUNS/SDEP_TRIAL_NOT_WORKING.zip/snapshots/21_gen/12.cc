ReduceCwnd (tcb);
int yoRPGxjdJkuHBMfj = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((31.381)));
float hqTsSCnoIhExhqAG = (float) (15.449/8.604);
ReduceCwnd (tcb);
int NBNntehmkxyuHlSZ = (int) (yoRPGxjdJkuHBMfj-(tcb->m_segmentSize)-(22.206)-(37.033));
int vtRDkhcUubqVzMYC = (int) (((0.1)+((NBNntehmkxyuHlSZ+(tcb->m_cWnd)))+(22.253)+(5.342))/((72.936)));
