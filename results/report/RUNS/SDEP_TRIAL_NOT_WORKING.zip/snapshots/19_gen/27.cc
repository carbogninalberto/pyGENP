tcb->m_cWnd = (int) (10.902*(54.727));
int aEXbtIXJgqvbqoGq = (int) (56.195*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(68.718));
float FSmgYLqwBlEHHxMI = (float) (0.1/83.439);
float EKghJVATRKRfdLhW = (float) (0.1/39.228);
tcb->m_segmentSize = (int) (0.1/5.111);
FSmgYLqwBlEHHxMI = (float) (38.841-(11.79)-(94.394));
if (tcb->m_cWnd < aEXbtIXJgqvbqoGq) {
	tcb->m_cWnd = (int) (31.062-(1.408)-(12.953)-(7.761)-(49.375)-(EKghJVATRKRfdLhW)-(7.075)-(16.941)-(76.036));
	ReduceCwnd (tcb);
	aEXbtIXJgqvbqoGq = (int) (47.815-(FSmgYLqwBlEHHxMI)-(83.732)-(28.258)-(2.864)-(tcb->m_segmentSize));
	FSmgYLqwBlEHHxMI = (float) (11.296*(41.264)*(26.418)*(75.546)*(89.496)*(tcb->m_cWnd)*(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (22.676*(95.693)*(57.694)*(76.77)*(87.903)*(95.869)*(0.646));
	tcb->m_segmentSize = (int) (27.72*(segmentsAcked)*(10.614)*(13.727)*(aEXbtIXJgqvbqoGq)*(88.126));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
