segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (97.187+(70.945)+(63.682)+(16.438)+(tcb->m_cWnd)+(47.532)+(29.589)+(43.975));
int gzLimhcvcZnGfesv = (int) (0.1/68.132);
int ySGIYqzmnBdZoATK = (int) (((0.1)+(0.1)+(0.1)+(47.712))/((0.1)+(0.1)));
if (ySGIYqzmnBdZoATK == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (22.969-(gzLimhcvcZnGfesv)-(tcb->m_ssThresh)-(68.822)-(54.964));
	ySGIYqzmnBdZoATK = (int) (75.918-(74.83)-(24.259));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (34.488+(tcb->m_ssThresh)+(70.604)+(gzLimhcvcZnGfesv)+(49.763));
	gzLimhcvcZnGfesv = (int) (0.1/46.536);

}
if (gzLimhcvcZnGfesv < tcb->m_ssThresh) {
	ySGIYqzmnBdZoATK = (int) (0.1/35.023);

} else {
	ySGIYqzmnBdZoATK = (int) (85.782*(87.707)*(32.211)*(30.697)*(55.395)*(tcb->m_cWnd)*(92.393)*(62.727)*(44.534));

}
