int ILzZOggyGUCNCuiO = (int) (92.383/34.24);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float yOJeLWkBlrTpKgRG = (float) (0.1/0.1);
tcb->m_ssThresh = (int) ((((segmentsAcked+(18.312)+(44.085)+(ILzZOggyGUCNCuiO)))+(0.1)+(0.1)+(0.1)+(95.902))/((0.1)+(0.1)+(26.048)+(0.1)));
float VjVMLkSRMGwMZdHI = (float) ((((ILzZOggyGUCNCuiO-(segmentsAcked)))+(0.1)+((segmentsAcked+(ILzZOggyGUCNCuiO)+(60.054)+(segmentsAcked)+(74.293)+(2.162)+(75.379)+(ILzZOggyGUCNCuiO)+(ILzZOggyGUCNCuiO)))+(0.1))/((0.1)));
if (tcb->m_ssThresh <= yOJeLWkBlrTpKgRG) {
	segmentsAcked = (int) (0.1/26.539);
	ILzZOggyGUCNCuiO = (int) (65.576/0.1);

} else {
	segmentsAcked = (int) (59.224*(ILzZOggyGUCNCuiO)*(12.487)*(71.867)*(33.772)*(74.17)*(tcb->m_segmentSize));
	VjVMLkSRMGwMZdHI = (float) (((0.1)+(22.088)+((73.349-(VjVMLkSRMGwMZdHI)-(73.421)-(63.459)-(13.405)-(66.949)))+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(44.397)));
	tcb->m_ssThresh = (int) ((((30.253*(45.466)*(35.818)*(yOJeLWkBlrTpKgRG)*(yOJeLWkBlrTpKgRG)))+(42.721)+(64.352)+((41.083-(93.387)))+(7.448)+(0.1)+(93.05))/((0.1)+(0.1)));

}
tcb->m_segmentSize = (int) (0.1/(56.542+(VjVMLkSRMGwMZdHI)));
