int UBhxoNoNWrmqCmgo = (int) (33.54+(80.706)+(15.75)+(50.184)+(49.731)+(93.514)+(65.302)+(53.52));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (UBhxoNoNWrmqCmgo == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (74.276+(73.043)+(9.104)+(tcb->m_ssThresh)+(68.622)+(50.009));
	tcb->m_ssThresh = (int) (44.619-(tcb->m_segmentSize)-(UBhxoNoNWrmqCmgo)-(86.083)-(48.057)-(17.94)-(tcb->m_segmentSize)-(9.654)-(88.422));
	tcb->m_segmentSize = (int) (62.967*(tcb->m_ssThresh)*(80.049)*(tcb->m_segmentSize)*(85.921));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	UBhxoNoNWrmqCmgo = (int) (64.694-(30.649)-(12.971)-(tcb->m_cWnd)-(23.991)-(5.655));

} else {
	tcb->m_ssThresh = (int) (44.643-(77.038)-(6.437));
	tcb->m_segmentSize = (int) (64.664+(91.909)+(20.48)+(tcb->m_cWnd)+(31.104)+(1.666)+(0.321));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (UBhxoNoNWrmqCmgo != UBhxoNoNWrmqCmgo) {
	tcb->m_ssThresh = (int) (78.877+(64.722)+(58.283)+(34.954)+(71.932));

} else {
	tcb->m_ssThresh = (int) (93.262+(47.581)+(42.968)+(76.866));
	tcb->m_ssThresh = (int) (66.181*(38.101)*(tcb->m_segmentSize));

}
int tuxRQkThIPIXSGuc = (int) (38.367-(tcb->m_ssThresh)-(65.716)-(40.603));
segmentsAcked = (int) (2.43-(90.65)-(79.026)-(51.822)-(51.946)-(89.691)-(87.45)-(86.595));
int JCEXbVazyGZFRXzD = (int) (((69.451)+(0.1)+((tcb->m_segmentSize-(81.628)-(UBhxoNoNWrmqCmgo)-(18.123)))+(0.1)+(0.1))/((0.1)+(0.1)));
