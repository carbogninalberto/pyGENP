float gcRpWtbaFkIxSSeV = (float) (-51.49-(45.621)-(-51.029)-(-18.559));
int VUDQOLavzxLVWHcj = (int) (70.762-(-11.769)-(68.8)-(-86.061)-(25.287)-(71.618)-(-81.17)-(10.796)-(53.408));
float pxcshOkQRXNatZVd = (float) (35.552-(-69.13)-(-58.102));
int KEVBxIWgDptaXepp = (int) (-49.643-(-58.494)-(29.321)-(-3.772)-(76.573)-(2.278)-(-39.392)-(82.95));
float NvgBqYUAmJAWQKhk = (float) (-23.801/48.238);
int aIkSKVngaYnopMjs = (int) (30.441-(-19.442)-(-39.276));
