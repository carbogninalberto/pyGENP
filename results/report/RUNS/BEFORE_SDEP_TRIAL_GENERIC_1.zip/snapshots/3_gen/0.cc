float yECqnvaPPBdTEOZA = (float) (-75.129-(59.607)-(58.862)-(96.105)-(-52.365));
if (segmentsAcked <= segmentsAcked) {
	tcb->m_cWnd = (int) (41.538-(76.447)-(79.572)-(89.008)-(25.613)-(87.709)-(57.794));
	tcb->m_cWnd = (int) (95.168-(35.201)-(72.297)-(22.199)-(43.777)-(tcb->m_segmentSize)-(87.967)-(tcb->m_segmentSize)-(26.976));

} else {
	tcb->m_cWnd = (int) (89.933/86.635);

}
