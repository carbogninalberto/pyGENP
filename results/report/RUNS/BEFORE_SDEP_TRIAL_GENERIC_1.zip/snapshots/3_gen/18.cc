float eIrwWKfiToHlhlxp = (float) (94.572+(77.819)+(-72.099)+(39.837)+(53.737)+(69.063)+(25.08)+(7.875)+(-68.089));
if (tcb->m_segmentSize <= eIrwWKfiToHlhlxp) {
	eIrwWKfiToHlhlxp = (float) (0.1/0.1);
	tcb->m_segmentSize = (int) (-82.432+(92.495));

} else {
	eIrwWKfiToHlhlxp = (float) (81.762/0.1);
	eIrwWKfiToHlhlxp = (float) (75.497*(71.206)*(49.096)*(38.706)*(tcb->m_segmentSize)*(59.357)*(46.579));
	segmentsAcked = (int) (76.137/0.1);

}
segmentsAcked = (int) (39.444-(88.791));
if (tcb->m_segmentSize <= eIrwWKfiToHlhlxp) {
	eIrwWKfiToHlhlxp = (float) (0.1/0.1);
	tcb->m_segmentSize = (int) (-82.432+(92.495));

} else {
	eIrwWKfiToHlhlxp = (float) (81.762/0.1);
	eIrwWKfiToHlhlxp = (float) (75.497*(71.206)*(49.096)*(38.706)*(tcb->m_segmentSize)*(59.357)*(46.579));
	segmentsAcked = (int) (76.137/0.1);

}
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (20.781-(80.759)-(tcb->m_cWnd)-(62.692));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (45.235-(54.056)-(29.146)-(12.452)-(14.262)-(63.507));

}
segmentsAcked = (int) (-81.783-(-81.792));
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (27.231*(segmentsAcked)*(22.383)*(eIrwWKfiToHlhlxp)*(52.235)*(tcb->m_segmentSize)*(70.723));
	segmentsAcked = (int) (((29.919)+(87.914)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (66.762+(63.327)+(segmentsAcked)+(11.862)+(tcb->m_cWnd)+(segmentsAcked)+(19.313)+(99.956)+(2.666));

}
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (20.781-(80.759)-(tcb->m_cWnd)-(62.692));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (45.235-(54.056)-(29.146)-(12.452)-(14.262)-(63.507));

}
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (27.231*(segmentsAcked)*(22.383)*(eIrwWKfiToHlhlxp)*(52.235)*(tcb->m_segmentSize)*(70.723));
	segmentsAcked = (int) (((29.919)+(87.914)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (66.762+(63.327)+(segmentsAcked)+(11.862)+(tcb->m_cWnd)+(segmentsAcked)+(19.313)+(99.956)+(2.666));

}
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (27.231*(segmentsAcked)*(22.383)*(eIrwWKfiToHlhlxp)*(52.235)*(tcb->m_segmentSize)*(70.723));
	segmentsAcked = (int) (((29.919)+(87.914)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (66.762+(63.327)+(segmentsAcked)+(11.862)+(tcb->m_cWnd)+(segmentsAcked)+(19.313)+(99.956)+(2.666));

}
eIrwWKfiToHlhlxp = (float) ((((-2.442*(-5.097)*(segmentsAcked)*(-21.256)*(-86.042)*(97.815)))+(49.317)+(-96.123)+(-77.267)+(79.416)+(-96.738)+(92.313))/((-42.847)));
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (27.231*(segmentsAcked)*(22.383)*(eIrwWKfiToHlhlxp)*(52.235)*(tcb->m_segmentSize)*(70.723));
	segmentsAcked = (int) (((29.919)+(87.914)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (66.762+(63.327)+(segmentsAcked)+(11.862)+(tcb->m_cWnd)+(segmentsAcked)+(19.313)+(99.956)+(2.666));

}
eIrwWKfiToHlhlxp = (float) ((((53.797*(-57.712)*(segmentsAcked)*(-21.578)*(-61.282)*(99.643)))+(47.003)+(-63.109)+(23.114)+(-79.471)+(33.831)+(96.069))/((-45.147)));
eIrwWKfiToHlhlxp = (float) ((((-66.164*(-74.62)*(segmentsAcked)*(27.632)*(-11.331)*(-31.28)))+(73.886)+(65.458)+(88.929)+(-90.926)+(-13.256)+(-53.384))/((-68.237)));
eIrwWKfiToHlhlxp = (float) ((((59.975*(-84.898)*(segmentsAcked)*(-88.489)*(-0.129)*(73.316)))+(-95.793)+(-47.417)+(-33.193)+(-94.455)+(-59.823)+(-77.305))/((66.806)));
