tcb->m_cWnd = (int) (-43.083-(93.502)-(-55.829)-(-27.733)-(-33.209)-(-92.208)-(-42.682));
int vjOTPClFwVfRUNhU = (int) (17.727*(-19.48)*(-4.953)*(-60.297)*(-13.572)*(-40.024));
segmentsAcked = (int) (-3.157-(-12.426));
segmentsAcked = (int) (-39.621-(-89.227));
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (45.235-(54.056)-(29.146)-(12.452)-(14.262)-(63.507));

} else {
	tcb->m_segmentSize = (int) (20.781-(80.759)-(tcb->m_cWnd)-(62.692));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (27.231*(segmentsAcked)*(22.383)*(-26.814)*(52.235)*(tcb->m_segmentSize)*(70.723));
	segmentsAcked = (int) (((29.919)+(87.914)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (66.762+(63.327)+(segmentsAcked)+(11.862)+(tcb->m_cWnd)+(segmentsAcked)+(19.313)+(99.956)+(2.666));

}
segmentsAcked = (int) (-78.882-(-24.502));
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (20.781-(80.759)-(tcb->m_cWnd)-(62.692));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (45.235-(54.056)-(29.146)-(12.452)-(14.262)-(63.507));

}
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (27.231*(segmentsAcked)*(22.383)*(24.275)*(52.235)*(tcb->m_segmentSize)*(70.723));
	segmentsAcked = (int) (((29.919)+(87.914)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (66.762+(63.327)+(segmentsAcked)+(11.862)+(tcb->m_cWnd)+(segmentsAcked)+(19.313)+(99.956)+(2.666));

}
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (20.781-(80.759)-(tcb->m_cWnd)-(62.692));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (45.235-(54.056)-(29.146)-(12.452)-(14.262)-(63.507));

}
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (27.231*(segmentsAcked)*(22.383)*(77.161)*(52.235)*(tcb->m_segmentSize)*(70.723));
	segmentsAcked = (int) (((29.919)+(87.914)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (66.762+(63.327)+(segmentsAcked)+(11.862)+(tcb->m_cWnd)+(segmentsAcked)+(19.313)+(99.956)+(2.666));

}
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (27.231*(segmentsAcked)*(22.383)*(-39.05)*(52.235)*(tcb->m_segmentSize)*(70.723));
	segmentsAcked = (int) (((29.919)+(87.914)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (66.762+(63.327)+(segmentsAcked)+(11.862)+(tcb->m_cWnd)+(segmentsAcked)+(19.313)+(99.956)+(2.666));

}
