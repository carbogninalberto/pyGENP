TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-64.442+(61.403)+(-17.558)+(96.06)+(63.317)+(18.061));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
