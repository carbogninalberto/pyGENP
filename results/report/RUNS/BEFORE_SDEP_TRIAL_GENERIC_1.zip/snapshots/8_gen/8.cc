TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-43.196*(84.213)*(38.488)*(21.727)*(-92.124));
tcb->m_cWnd = (int) (22.913*(20.051)*(66.909)*(59.95)*(-63.978));
tcb->m_cWnd = (int) (33.059*(72.148)*(-77.876)*(-94.697)*(-0.779));
tcb->m_cWnd = (int) (15.574*(-25.089)*(-75.876)*(12.391)*(30.271));
