int HIQwzIhphUEWjLJV = (int) ((51.586*(14.964)*(-81.35)*(-53.97))/18.079);
float clIoeOOMUYZmnVAR = (float) (-56.355+(-64.151)+(-42.124));
tcb->m_cWnd = (int) (28.201-(-29.397)-(-36.186));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-21.18-(0.769)-(-5.291)-(-20.019)-(-80.125)-(86.968));
clIoeOOMUYZmnVAR = (float) (77.25-(-50.304)-(-64.93)-(-96.034)-(-22.519)-(-9.514));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (31.879-(-51.516)-(-92.16));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (46.017-(17.528)-(-21.711)-(15.343)-(-77.631)-(69.422));
clIoeOOMUYZmnVAR = (float) (-12.978-(-44.261)-(-89.977)-(99.416)-(-76.024)-(-31.016));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (95.432-(31.847)-(22.351)-(79.944)-(29.739)-(-19.004));
clIoeOOMUYZmnVAR = (float) (-79.51-(-47.698)-(-23.708)-(-1.558)-(-36.876)-(53.906));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-45.619-(-81.6)-(-24.453)-(70.561)-(-69.234)-(58.132));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (22.147-(80.596)-(-0.971)-(52.944)-(68.085)-(-46.213));
clIoeOOMUYZmnVAR = (float) (98.495-(-36.92)-(-2.926)-(-73.306)-(-90.799)-(78.021));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-25.501-(-70.443)-(3.887)-(-15.171)-(-0.183)-(-1.429));
clIoeOOMUYZmnVAR = (float) (-21.223-(46.304)-(-65.39)-(9.445)-(20.173)-(-28.233));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (69.135-(-20.332)-(-87.97)-(86.775)-(-83.127)-(19.044));
clIoeOOMUYZmnVAR = (float) (75.667-(-88.72)-(-51.624)-(58.346)-(90.371)-(-5.082));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-52.48-(83.869)-(81.332)-(55.763)-(64.499)-(-32.984));
