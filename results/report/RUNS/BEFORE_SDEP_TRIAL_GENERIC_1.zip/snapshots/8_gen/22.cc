int HIQwzIhphUEWjLJV = (int) ((67.568*(93.676)*(15.659)*(65.941))/-0.831);
tcb->m_cWnd = (int) (26.168-(85.698)-(-26.849));
float clIoeOOMUYZmnVAR = (float) (13.125+(73.48)+(-22.308));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (64.754-(91.134)-(-53.101)-(57.899)-(-7.902)-(87.725));
tcb->m_cWnd = (int) (33.763-(95.449)-(34.873));
clIoeOOMUYZmnVAR = (float) (93.668-(-13.542)-(93.294)-(-8.102)-(82.13)-(62.122));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-20.688-(-47.438)-(-94.267));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-55.551-(-21.138)-(-81.73)-(5.524)-(-17.579)-(87.328));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (44.549-(-76.483)-(-2.007)-(30.373)-(-31.56)-(97.503));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-83.821-(70.081)-(-86.719)-(-46.187)-(-33.644)-(96.056));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-34.831-(-13.778)-(87.102));
clIoeOOMUYZmnVAR = (float) (8.379-(-23.378)-(14.201)-(44.823)-(50.077)-(6.572));
clIoeOOMUYZmnVAR = (float) (29.878-(96.32)-(9.408)-(-71.05)-(-41.573)-(-41.014));
clIoeOOMUYZmnVAR = (float) (96.515-(26.203)-(-98.883)-(62.545)-(-16.096)-(-2.357));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-17.419-(9.548)-(86.396));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-71.143-(-68.85)-(29.053)-(-61.784)-(-64.841)-(-49.633));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-12.618-(-52.027)-(94.993)-(60.412)-(-37.481)-(29.772));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-14.677-(81.419)-(50.96)-(-63.675)-(-13.787)-(69.049));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-48.081-(6.116)-(-54.259));
clIoeOOMUYZmnVAR = (float) (7.404-(-98.669)-(80.077)-(-57.541)-(-62.008)-(-86.875));
clIoeOOMUYZmnVAR = (float) (81.953-(87.821)-(49.636)-(-72.187)-(-72.306)-(-30.945));
clIoeOOMUYZmnVAR = (float) (17.962-(-78.377)-(89.782)-(54.083)-(40.065)-(65.241));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (31.693-(-40.924)-(87.205)-(-74.761)-(-61.673)-(59.616));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (71.925-(-77.932)-(-5.374)-(1.953)-(-21.42)-(-30.426));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-44.882-(90.365)-(16.254)-(-47.758)-(61.655)-(-22.154));
clIoeOOMUYZmnVAR = (float) (84.781-(96.639)-(-16.812)-(-88.595)-(73.621)-(-1.507));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-86.242-(64.967)-(-54.865)-(-55.873)-(-84.119)-(-82.994));
clIoeOOMUYZmnVAR = (float) (-94.823-(84.607)-(-9.842)-(-42.724)-(-22.519)-(23.084));
clIoeOOMUYZmnVAR = (float) (-45.151-(50.908)-(-84.594)-(-64.393)-(-64.433)-(88.252));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (42.118-(31.57)-(-16.111));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (14.849-(-72.244)-(56.17)-(-72.952)-(-95.209)-(92.394));
clIoeOOMUYZmnVAR = (float) (59.643-(-23.537)-(-33.275)-(44.435)-(15.15)-(-21.03));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (82.0-(35.392)-(18.121)-(41.996)-(35.535)-(78.761));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (78.77-(34.8)-(-95.564)-(95.11)-(-5.24)-(-48.701));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (77.225-(27.411)-(-70.627));
clIoeOOMUYZmnVAR = (float) (-85.412-(78.446)-(67.519)-(99.029)-(39.778)-(-30.811));
clIoeOOMUYZmnVAR = (float) (44.414-(14.755)-(60.21)-(-94.674)-(67.292)-(72.464));
clIoeOOMUYZmnVAR = (float) (15.824-(15.445)-(-37.963)-(90.803)-(-83.218)-(73.223));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (57.083-(95.463)-(2.488)-(-40.837)-(3.22)-(-65.737));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-8.325-(-12.655)-(-39.598)-(-45.469)-(-81.677)-(-63.438));
clIoeOOMUYZmnVAR = (float) (-30.331-(-50.509)-(40.702)-(89.097)-(91.36)-(-48.337));
clIoeOOMUYZmnVAR = (float) (72.943-(15.522)-(-36.126)-(-75.075)-(78.113)-(28.354));
clIoeOOMUYZmnVAR = (float) (-79.265-(86.691)-(64.896)-(-27.357)-(-29.146)-(-63.075));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (60.969-(-80.336)-(-5.643)-(-79.974)-(51.258)-(-50.842));
