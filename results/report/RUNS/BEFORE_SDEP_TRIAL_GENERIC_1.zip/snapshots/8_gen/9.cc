float clIoeOOMUYZmnVAR = (float) (-39.366+(-73.11)+(-36.523));
tcb->m_cWnd = (int) (-77.438-(60.38)-(-72.423));
int HIQwzIhphUEWjLJV = (int) ((69.817*(-71.052)*(-56.654)*(-95.139))/-59.832);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (3.842-(-79.791)-(96.52));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-19.427-(-59.912)-(97.611)-(-1.606)-(-75.933)-(-82.386));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-3.339-(-16.588)-(19.716)-(53.115)-(66.498)-(24.938));
tcb->m_cWnd = (int) (46.275-(-42.993)-(-1.673));
clIoeOOMUYZmnVAR = (float) (71.752-(46.386)-(84.189)-(-78.637)-(70.142)-(-56.057));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-55.102-(85.407)-(-78.016)-(37.449)-(76.094)-(-86.727));
clIoeOOMUYZmnVAR = (float) (-24.906-(-28.158)-(37.412)-(62.313)-(-90.112)-(75.037));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (35.488-(-61.707)-(82.708)-(-11.817)-(88.829)-(27.533));
clIoeOOMUYZmnVAR = (float) (-77.644-(-7.886)-(80.036)-(-42.486)-(9.011)-(-26.054));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (55.407-(-78.541)-(-77.891)-(-36.217)-(-14.292)-(-59.762));
