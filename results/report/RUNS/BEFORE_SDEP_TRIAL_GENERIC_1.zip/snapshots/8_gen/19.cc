float clIoeOOMUYZmnVAR = (float) (-54.108+(84.946)+(-40.013));
tcb->m_cWnd = (int) (84.709-(-84.83)-(68.178));
int HIQwzIhphUEWjLJV = (int) ((6.859*(-65.119)*(40.322)*(97.59))/-22.064);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-93.314-(86.959)-(-97.836));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-53.089-(97.36)-(64.451)-(68.068)-(-69.371)-(63.229));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-9.324-(-36.841)-(-96.627)-(23.454)-(-34.319)-(21.352));
tcb->m_cWnd = (int) (-22.055-(-80.767)-(9.696));
clIoeOOMUYZmnVAR = (float) (-49.743-(-37.247)-(70.18)-(-67.435)-(57.562)-(-45.673));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-11.282-(14.329)-(76.019)-(53.742)-(62.988)-(77.473));
clIoeOOMUYZmnVAR = (float) (86.252-(-51.349)-(-47.351)-(0.696)-(-54.344)-(-58.851));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (71.499-(49.021)-(-5.414));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (15.202-(-49.271)-(49.499)-(-75.755)-(13.04)-(79.928));
tcb->m_cWnd = (int) (-6.353-(-55.821)-(-36.561));
clIoeOOMUYZmnVAR = (float) (16.953-(18.302)-(-26.096)-(47.241)-(42.521)-(98.744));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-30.37-(-24.023)-(-97.199)-(62.753)-(-38.016)-(-91.872));
clIoeOOMUYZmnVAR = (float) (-37.62-(84.6)-(-17.317)-(55.604)-(17.419)-(-50.885));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-53.899-(5.374)-(89.475)-(18.386)-(78.116)-(99.357));
tcb->m_cWnd = (int) (51.087-(84.376)-(7.029));
clIoeOOMUYZmnVAR = (float) (-47.044-(-78.123)-(64.959)-(-55.687)-(3.209)-(64.445));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-87.905-(-55.034)-(99.469)-(12.37)-(-55.672)-(-94.423));
clIoeOOMUYZmnVAR = (float) (97.598-(-50.219)-(98.441)-(37.533)-(16.767)-(-46.037));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (76.516-(-13.982)-(6.296)-(73.668)-(-49.722)-(61.23));
clIoeOOMUYZmnVAR = (float) (-99.74-(-3.238)-(-49.329)-(-17.843)-(80.587)-(-61.161));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (37.341-(-29.994)-(-37.071)-(28.178)-(61.11)-(-85.699));
