tcb->m_cWnd = (int) (-84.121-(47.912)-(3.825));
int HIQwzIhphUEWjLJV = (int) ((31.724*(-66.1)*(-36.504)*(-90.001))/33.533);
float clIoeOOMUYZmnVAR = (float) (-64.637+(-16.914)+(78.742));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-74.737-(97.579)-(50.94)-(52.931)-(99.688)-(68.892));
clIoeOOMUYZmnVAR = (float) (-64.688-(64.956)-(-76.595)-(-9.233)-(88.91)-(-31.363));
tcb->m_cWnd = (int) (-36.655-(21.116)-(78.403));
clIoeOOMUYZmnVAR = (float) (-24.342-(1.782)-(73.188)-(86.868)-(35.833)-(96.403));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (34.851-(-18.189)-(-94.641)-(62.084)-(27.564)-(14.06));
clIoeOOMUYZmnVAR = (float) (13.139-(98.469)-(-11.668)-(40.533)-(-70.098)-(35.847));
tcb->m_cWnd = (int) (-55.855-(98.105)-(-89.728));
clIoeOOMUYZmnVAR = (float) (-20.198-(4.681)-(81.696)-(-13.486)-(48.915)-(6.099));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (89.454-(-76.199)-(-64.652));
clIoeOOMUYZmnVAR = (float) (-45.301-(-87.167)-(-91.898)-(39.254)-(-48.555)-(-96.226));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-94.178-(22.973)-(-35.909)-(-39.662)-(-60.452)-(-50.501));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (38.076-(-86.182)-(-56.754)-(93.681)-(-26.286)-(63.641));
clIoeOOMUYZmnVAR = (float) (14.733-(-51.138)-(85.284)-(-84.882)-(6.737)-(54.428));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (97.933-(69.275)-(-54.709)-(-43.775)-(89.697)-(58.921));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-28.144-(49.814)-(-88.68));
clIoeOOMUYZmnVAR = (float) (49.249-(12.801)-(-30.272)-(21.151)-(84.942)-(-89.342));
clIoeOOMUYZmnVAR = (float) (-90.212-(18.841)-(39.776)-(-94.346)-(-18.928)-(-5.068));
clIoeOOMUYZmnVAR = (float) (0.258-(-72.175)-(6.774)-(12.223)-(-57.707)-(70.271));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (87.211-(62.596)-(-81.365)-(97.788)-(-73.156)-(47.642));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (15.918-(45.653)-(11.347));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-12.118-(64.248)-(44.01)-(33.5)-(72.844)-(-98.348));
clIoeOOMUYZmnVAR = (float) (-62.776-(-46.159)-(-17.108)-(-4.566)-(24.011)-(42.8));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (73.621-(-7.67)-(-69.313)-(-72.48)-(-8.665)-(-72.249));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-4.975-(58.813)-(-80.381));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (70.05-(-25.903)-(-55.888)-(-80.108)-(-40.96)-(-6.509));
clIoeOOMUYZmnVAR = (float) (-16.323-(-7.663)-(33.659)-(-63.433)-(-76.002)-(4.336));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-28.202-(57.954)-(60.873)-(-47.098)-(-97.937)-(74.398));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-77.159-(60.306)-(-76.357)-(23.342)-(19.842)-(-18.885));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (33.516-(74.413)-(85.266)-(-60.162)-(93.839)-(-64.94));
clIoeOOMUYZmnVAR = (float) (56.239-(59.206)-(1.901)-(-8.023)-(75.903)-(47.043));
clIoeOOMUYZmnVAR = (float) (-82.318-(-87.419)-(-50.777)-(52.699)-(36.166)-(31.1));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-4.751-(-80.06)-(13.35)-(44.767)-(51.927)-(79.743));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-60.437-(53.99)-(12.697)-(10.601)-(5.298)-(74.761));
clIoeOOMUYZmnVAR = (float) (-41.426-(91.33)-(70.453)-(-97.099)-(-16.284)-(-5.401));
clIoeOOMUYZmnVAR = (float) (-86.386-(59.315)-(46.88)-(-54.334)-(44.435)-(19.221));
tcb->m_cWnd = (int) (-60.732-(45.465)-(-37.573));
clIoeOOMUYZmnVAR = (float) (0.663-(-59.238)-(34.456)-(-93.367)-(-31.942)-(36.903));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (30.61-(-52.172)-(76.159)-(8.983)-(-16.33)-(-23.869));
clIoeOOMUYZmnVAR = (float) (-43.955-(-95.815)-(-60.885)-(4.542)-(-3.344)-(-40.217));
clIoeOOMUYZmnVAR = (float) (68.926-(60.394)-(54.614)-(54.156)-(-57.961)-(50.341));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (45.42-(-60.119)-(85.4)-(30.279)-(-18.66)-(-83.431));
