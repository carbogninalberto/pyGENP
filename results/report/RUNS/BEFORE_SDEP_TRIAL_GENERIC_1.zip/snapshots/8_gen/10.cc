float clIoeOOMUYZmnVAR = (float) (31.878+(50.406)+(86.087));
tcb->m_cWnd = (int) (-87.163-(12.016)-(69.766));
int HIQwzIhphUEWjLJV = (int) ((28.469*(-17.457)*(24.773)*(29.125))/7.626);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-34.583-(70.733)-(-72.009));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-8.215-(99.799)-(-37.725)-(-49.145)-(94.699)-(-13.538));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (70.993-(-68.495)-(16.961)-(-52.593)-(-72.767)-(-54.744));
clIoeOOMUYZmnVAR = (float) (-22.844-(-34.443)-(57.241)-(26.583)-(-79.965)-(94.883));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-16.498-(74.597)-(57.005)-(-48.007)-(-32.433)-(-89.437));
