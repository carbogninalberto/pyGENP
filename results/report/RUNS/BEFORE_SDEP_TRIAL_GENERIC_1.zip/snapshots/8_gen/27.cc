tcb->m_cWnd = (int) (-79.708-(69.709)-(95.35));
int HIQwzIhphUEWjLJV = (int) ((73.964*(-32.925)*(78.722)*(-1.881))/48.086);
float clIoeOOMUYZmnVAR = (float) (42.435+(47.057)+(17.926));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (62.673-(-37.838)-(-84.434)-(-99.966)-(-57.777)-(-27.57));
clIoeOOMUYZmnVAR = (float) (83.032-(-73.809)-(32.587)-(51.822)-(81.466)-(44.68));
tcb->m_cWnd = (int) (67.089-(-25.616)-(55.288));
clIoeOOMUYZmnVAR = (float) (48.023-(-47.634)-(11.368)-(-77.146)-(-51.962)-(82.627));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-6.591-(-0.991)-(-9.307)-(94.768)-(54.207)-(30.772));
clIoeOOMUYZmnVAR = (float) (-57.46-(62.372)-(44.777)-(-50.928)-(-54.735)-(81.14));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (40.805-(15.578)-(-74.36));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (99.684-(59.002)-(18.897)-(62.195)-(33.542)-(-91.923));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-61.025-(97.646)-(15.679)-(-85.626)-(-64.174)-(31.309));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (69.38-(-30.005)-(-35.747)-(-58.965)-(-17.436)-(-69.121));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (36.517-(-22.55)-(45.533));
clIoeOOMUYZmnVAR = (float) (88.829-(83.061)-(76.378)-(25.767)-(-76.997)-(-4.739));
clIoeOOMUYZmnVAR = (float) (-18.79-(-67.062)-(88.295)-(-70.781)-(-8.989)-(-77.099));
clIoeOOMUYZmnVAR = (float) (33.084-(-46.779)-(-35.813)-(45.208)-(-26.304)-(-0.879));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (19.502-(39.946)-(-73.704)-(48.66)-(42.775)-(70.831));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-53.078-(17.902)-(-65.807)-(57.883)-(-69.275)-(79.71));
clIoeOOMUYZmnVAR = (float) (54.07-(-7.712)-(-79.002)-(-21.887)-(87.817)-(-92.077));
clIoeOOMUYZmnVAR = (float) (-55.257-(40.587)-(61.314)-(28.299)-(-55.902)-(96.371));
clIoeOOMUYZmnVAR = (float) (25.832-(84.32)-(-62.216)-(56.304)-(-32.971)-(-46.621));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (5.25-(-71.296)-(-48.209)-(-9.623)-(6.59)-(-68.568));
