if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(72.769)-(18.526)-(74.669));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (28.734+(90.218)+(tcb->m_segmentSize)+(88.753)+(40.968)+(54.472)+(63.206));
	segmentsAcked = (int) (38.496+(52.83));

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
