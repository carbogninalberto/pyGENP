tcb->m_segmentSize = (int) (81.106+(28.277)+(tcb->m_cWnd)+(25.674)+(99.692)+(89.664)+(72.516)+(69.372));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	segmentsAcked = (int) (44.84-(54.62)-(95.61));
	tcb->m_cWnd = (int) (24.751*(12.233)*(6.33)*(68.12)*(3.547)*(28.137)*(59.19)*(87.585)*(71.843));
	tcb->m_cWnd = (int) ((44.742-(18.602)-(tcb->m_segmentSize)-(92.58)-(56.334)-(49.953))/14.588);

} else {
	segmentsAcked = (int) (15.06-(14.681)-(segmentsAcked)-(76.998)-(73.642)-(75.041)-(11.979)-(segmentsAcked));
	tcb->m_segmentSize = (int) (68.772*(71.302));

}
segmentsAcked = (int) (89.159+(3.304)+(81.347)+(72.522)+(22.918)+(31.36)+(tcb->m_cWnd));
tcb->m_cWnd = (int) (24.104/44.233);
