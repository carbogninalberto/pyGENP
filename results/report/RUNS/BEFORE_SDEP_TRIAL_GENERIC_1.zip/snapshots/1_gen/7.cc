ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float zGdGKRdbPfceIDua = (float) (((0.1)+((37.176*(segmentsAcked)*(tcb->m_segmentSize)*(36.716)*(92.465)*(segmentsAcked)*(64.276)*(63.056)))+((89.497+(tcb->m_cWnd)+(54.906)+(21.523)+(13.986)+(70.171)+(tcb->m_segmentSize)))+((74.65*(80.905)))+(17.626))/((50.314)+(89.5)+(2.019)));
