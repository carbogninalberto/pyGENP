tcb->m_cWnd = (int) (98.01/33.627);
tcb->m_segmentSize = (int) (tcb->m_cWnd*(55.552)*(segmentsAcked)*(61.059));
segmentsAcked = (int) (67.539*(78.717)*(24.342)*(tcb->m_segmentSize)*(76.502)*(97.851)*(86.458));
segmentsAcked = (int) (tcb->m_segmentSize*(71.354)*(39.345)*(96.597)*(89.602)*(71.064)*(49.759)*(9.984));
ReduceCwnd (tcb);
if (segmentsAcked > segmentsAcked) {
	tcb->m_cWnd = (int) (segmentsAcked-(57.611)-(47.877)-(48.187)-(tcb->m_cWnd)-(4.036)-(44.475));
	tcb->m_cWnd = (int) (74.229+(71.628)+(6.567)+(73.307)+(15.82));
	segmentsAcked = (int) (20.266-(36.378)-(13.501)-(34.628)-(52.203)-(34.795)-(99.621)-(91.569));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(98.724));
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(5.049)+(54.28))/((21.956)+(0.1)));

}
