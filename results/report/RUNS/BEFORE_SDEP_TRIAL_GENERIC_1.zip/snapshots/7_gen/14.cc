float uEBKNMkAeKsSJcXA = (float) (78.204*(53.046)*(94.618)*(-8.454)*(-5.506)*(-29.799));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-26.074*(0.548)*(-29.433)*(-62.061)*(78.076));
tcb->m_cWnd = (int) (83.924*(-9.64)*(74.724)*(47.442)*(81.638));
