float clIoeOOMUYZmnVAR = (float) (-45.608+(-34.145)+(-87.93));
int HIQwzIhphUEWjLJV = (int) ((23.963*(-65.133)*(-23.974)*(-58.998))/26.915);
tcb->m_cWnd = (int) (18.203-(67.041)-(16.911));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (47.189-(66.242)-(-19.936)-(-74.19)-(49.618)-(12.149));
clIoeOOMUYZmnVAR = (float) (-73.507-(-60.971)-(44.847)-(-67.594)-(62.774)-(93.975));
tcb->m_cWnd = (int) (-24.32-(42.324)-(-17.86));
clIoeOOMUYZmnVAR = (float) (-76.997-(-49.266)-(8.826)-(61.079)-(7.304)-(96.068));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-51.238-(45.909)-(-49.782)-(40.73)-(60.436)-(-79.879));
clIoeOOMUYZmnVAR = (float) (96.776-(55.514)-(-23.386)-(88.486)-(40.517)-(-6.395));
tcb->m_cWnd = (int) (88.747-(76.982)-(30.63));
clIoeOOMUYZmnVAR = (float) (40.055-(-67.522)-(-46.49)-(90.331)-(90.938)-(-23.005));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (97.325-(-76.555)-(-90.507)-(73.069)-(78.599)-(31.774));
clIoeOOMUYZmnVAR = (float) (16.673-(-61.323)-(-4.049)-(-97.029)-(-73.958)-(-15.878));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-21.734-(-48.174)-(23.284)-(69.231)-(-10.5)-(78.209));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (18.674-(83.347)-(31.427)-(83.897)-(-72.584)-(-56.252));
clIoeOOMUYZmnVAR = (float) (90.867-(-32.413)-(-37.864)-(99.419)-(18.033)-(-47.777));
clIoeOOMUYZmnVAR = (float) (-36.759-(74.582)-(3.53)-(31.347)-(7.912)-(95.422));
tcb->m_cWnd = (int) (29.612-(33.762)-(16.12));
clIoeOOMUYZmnVAR = (float) (76.655-(26.429)-(-61.533)-(-56.291)-(12.967)-(26.53));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-64.102-(66.891)-(-95.096)-(-36.765)-(-50.594)-(21.435));
clIoeOOMUYZmnVAR = (float) (-66.16-(16.399)-(-22.079)-(2.43)-(56.498)-(52.153));
clIoeOOMUYZmnVAR = (float) (-42.412-(-55.85)-(78.272)-(-9.88)-(18.008)-(-82.317));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-75.92-(-80.592)-(-88.123)-(72.443)-(50.64)-(7.726));
