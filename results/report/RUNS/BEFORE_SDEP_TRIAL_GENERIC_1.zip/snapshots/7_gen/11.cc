tcb->m_cWnd = (int) (-59.597-(13.581)-(17.628));
float clIoeOOMUYZmnVAR = (float) (59.024+(12.245)+(51.725));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
int HIQwzIhphUEWjLJV = (int) ((2.878*(-62.512)*(-66.092)*(14.461))/20.735);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (67.255-(-45.069)-(-73.84)-(-20.523)-(95.522)-(28.717));
clIoeOOMUYZmnVAR = (float) (39.955-(5.297)-(-45.907)-(-46.226)-(-55.273)-(59.985));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-32.604-(-55.166)-(33.815));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (45.401-(24.396)-(33.017)-(66.653)-(-19.424)-(-43.813));
clIoeOOMUYZmnVAR = (float) (-59.057-(40.414)-(-62.527)-(75.601)-(-94.677)-(-14.717));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (30.054-(-67.277)-(49.789)-(84.956)-(-37.726)-(5.746));
clIoeOOMUYZmnVAR = (float) (-23.283-(-37.115)-(-95.57)-(0.289)-(-64.755)-(-43.31));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-6.487-(52.679)-(11.853)-(5.936)-(-74.583)-(99.653));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (93.648-(56.217)-(34.769)-(-95.053)-(25.392)-(-91.943));
clIoeOOMUYZmnVAR = (float) (-70.659-(-43.355)-(-91.578)-(-93.104)-(-25.6)-(-18.764));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (62.774-(57.925)-(21.449)-(21.137)-(-2.057)-(90.833));
clIoeOOMUYZmnVAR = (float) (74.681-(-95.916)-(43.953)-(16.715)-(-70.354)-(-32.505));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (30.387-(-91.626)-(24.622)-(22.075)-(53.442)-(64.651));
clIoeOOMUYZmnVAR = (float) (-95.236-(79.902)-(-79.692)-(-29.854)-(51.035)-(12.418));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-0.156-(-20.382)-(-55.395)-(44.281)-(54.689)-(73.577));
