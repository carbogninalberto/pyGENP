float clIoeOOMUYZmnVAR = (float) (11.204+(75.802)+(99.388));
tcb->m_cWnd = (int) (-54.259-(-36.59)-(29.563));
int HIQwzIhphUEWjLJV = (int) ((-29.663*(19.724)*(-70.733)*(58.607))/71.532);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (97.393-(-30.515)-(18.51));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (36.527-(25.828)-(51.421)-(46.393)-(63.631)-(-20.312));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-3.971-(39.344)-(47.248)-(-64.426)-(41.106)-(-88.12));
clIoeOOMUYZmnVAR = (float) (-60.426-(84.604)-(12.861)-(12.558)-(-83.066)-(49.033));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (28.426-(-58.772)-(97.716)-(-47.642)-(24.325)-(-95.633));
tcb->m_cWnd = (int) (60.123-(2.863)-(-28.683));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-65.724-(47.361)-(-60.678)-(-18.706)-(-3.865)-(89.828));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-60.077-(-83.778)-(-38.871)-(75.784)-(-89.309)-(-7.858));
clIoeOOMUYZmnVAR = (float) (94.458-(-34.308)-(8.889)-(-8.41)-(38.237)-(-18.973));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-42.228-(-16.3)-(45.408)-(-62.957)-(-46.208)-(-81.584));
