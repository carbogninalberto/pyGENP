float clIoeOOMUYZmnVAR = (float) (-0.143+(34.045)+(-76.722));
tcb->m_cWnd = (int) (-96.258-(46.161)-(-5.27));
int HIQwzIhphUEWjLJV = (int) ((-48.894*(-55.131)*(-24.497)*(-67.674))/-6.184);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-17.367-(80.019)-(-40.45));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (17.082-(-64.256)-(63.58)-(-39.121)-(37.865)-(-27.907));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-24.882-(-95.271)-(75.113)-(-24.374)-(-34.309)-(2.454));
clIoeOOMUYZmnVAR = (float) (40.874-(-35.609)-(24.983)-(-78.404)-(-59.566)-(74.519));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-12.131-(-5.764)-(-1.968)-(31.794)-(-72.034)-(-67.367));
