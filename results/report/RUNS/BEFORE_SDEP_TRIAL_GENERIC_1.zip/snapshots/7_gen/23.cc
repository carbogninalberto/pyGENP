float clIoeOOMUYZmnVAR = (float) (-2.409+(53.722)+(21.87));
tcb->m_cWnd = (int) (74.399-(-61.038)-(-29.92));
int HIQwzIhphUEWjLJV = (int) ((58.89*(87.067)*(-66.205)*(-19.268))/-40.385);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (39.694-(70.312)-(-22.199));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-21.821-(-14.345)-(24.559)-(68.764)-(25.882)-(-88.515));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-33.987-(-49.318)-(41.734)-(-47.21)-(46.253)-(-54.427));
clIoeOOMUYZmnVAR = (float) (-75.23-(68.095)-(-21.323)-(-25.913)-(94.823)-(-89.247));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-63.417-(-19.675)-(37.911)-(67.903)-(68.994)-(-46.305));
tcb->m_cWnd = (int) (47.776-(52.705)-(22.212));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-71.24-(72.095)-(75.566)-(56.178)-(-25.392)-(-79.514));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-32.329-(4.255)-(-31.87)-(-35.313)-(45.715)-(67.099));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (56.87-(52.894)-(-86.64)-(27.668)-(40.481)-(32.474));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-26.86-(-82.853)-(57.564)-(-85.408)-(-5.127)-(-19.663));
clIoeOOMUYZmnVAR = (float) (57.142-(64.505)-(17.735)-(96.136)-(-93.688)-(-30.033));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-95.415-(99.332)-(35.113)-(75.363)-(73.365)-(4.919));
clIoeOOMUYZmnVAR = (float) (39.796-(92.707)-(-70.361)-(21.536)-(24.232)-(15.697));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-79.203-(9.127)-(-59.223));
clIoeOOMUYZmnVAR = (float) (-39.62-(-97.133)-(-58.813)-(32.437)-(95.021)-(28.13));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (6.43-(13.411)-(43.101)-(-4.028)-(95.435)-(-9.168));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (65.386-(71.212)-(6.072)-(-78.748)-(-89.499)-(-15.599));
clIoeOOMUYZmnVAR = (float) (-98.776-(50.101)-(30.779)-(-26.124)-(-43.745)-(35.775));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (36.285-(90.881)-(-71.333)-(30.621)-(68.477)-(12.186));
