if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (segmentsAcked*(42.008));

} else {
	tcb->m_cWnd = (int) (47.651+(9.654)+(tcb->m_segmentSize)+(tcb->m_segmentSize));

}
float uEBKNMkAeKsSJcXA = (float) (-30.579*(59.409)*(27.813)*(32.512)*(-6.55)*(-77.898));
ReduceCwnd (tcb);
float byOfPVYxdLwibRXb = (float) (-72.372/-7.492);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (80.709*(52.898)*(-91.651)*(10.64)*(-40.4));
tcb->m_cWnd = (int) (-52.972*(14.365)*(-91.211)*(-42.893)*(-85.731));
