int HIQwzIhphUEWjLJV = (int) ((-34.251*(-20.344)*(-36.925)*(-73.52))/-8.464);
tcb->m_cWnd = (int) (91.039-(-45.874)-(-75.692));
float clIoeOOMUYZmnVAR = (float) (-97.238+(-33.664)+(40.659));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-15.667-(-45.512)-(11.812));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (21.943-(-26.855)-(17.801)-(43.716)-(-74.346)-(2.504));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (50.229-(72.393)-(-60.212)-(-44.997)-(42.08)-(67.265));
tcb->m_cWnd = (int) (26.345-(8.613)-(66.341));
clIoeOOMUYZmnVAR = (float) (-18.585-(-19.882)-(-16.028)-(61.871)-(11.381)-(-88.607));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-20.601-(69.478)-(60.252)-(86.836)-(91.792)-(-17.444));
clIoeOOMUYZmnVAR = (float) (-69.162-(-9.444)-(7.39)-(-52.236)-(73.363)-(-36.42));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-60.533-(-5.827)-(17.884)-(1.915)-(48.254)-(-18.959));
clIoeOOMUYZmnVAR = (float) (80.599-(39.444)-(-30.385)-(-39.936)-(-89.591)-(68.651));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-58.617-(-2.224)-(69.299)-(78.13)-(-36.812)-(93.424));
