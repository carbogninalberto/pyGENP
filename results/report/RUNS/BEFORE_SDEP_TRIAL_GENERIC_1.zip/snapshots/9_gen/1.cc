int HIQwzIhphUEWjLJV = (int) ((91.819*(-7.427)*(34.109)*(26.949))/65.802);
tcb->m_cWnd = (int) (76.851-(56.267)-(-1.28));
float clIoeOOMUYZmnVAR = (float) (7.32+(-72.012)+(-70.695));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-39.271-(-83.455)-(-83.392));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-75.055-(82.719)-(-24.814)-(-30.524)-(37.523)-(-20.174));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (83.291-(-25.007)-(56.033)-(-66.652)-(-39.147)-(99.705));
tcb->m_cWnd = (int) (-81.844-(19.198)-(96.102));
clIoeOOMUYZmnVAR = (float) (-64.95-(68.383)-(65.247)-(-40.439)-(-81.18)-(75.985));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (91.814-(56.652)-(-81.837)-(-75.552)-(-56.894)-(62.008));
clIoeOOMUYZmnVAR = (float) (27.84-(-49.323)-(22.207)-(-39.786)-(-10.525)-(-8.937));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (97.358-(38.942)-(-85.806));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-70.127-(66.57)-(-3.048)-(-11.924)-(-58.033)-(-25.707));
tcb->m_cWnd = (int) (20.914-(5.269)-(0.201));
clIoeOOMUYZmnVAR = (float) (32.687-(-4.218)-(-31.86)-(48.613)-(58.184)-(-61.041));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-1.355-(-61.425)-(-85.783)-(-62.031)-(-52.594)-(64.704));
clIoeOOMUYZmnVAR = (float) (73.422-(-45.24)-(-27.884)-(-57.996)-(70.422)-(90.451));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-17.292-(-79.117)-(-66.842)-(-84.252)-(-62.172)-(-45.825));
tcb->m_cWnd = (int) (-39.276-(43.28)-(42.804));
clIoeOOMUYZmnVAR = (float) (-53.554-(27.861)-(-67.412)-(81.943)-(72.555)-(9.243));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-89.881-(-20.407)-(-87.66)-(60.234)-(-85.713)-(-95.197));
clIoeOOMUYZmnVAR = (float) (-70.01-(-79.684)-(-58.789)-(-5.72)-(93.25)-(85.084));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (17.114-(15.816)-(-27.498)-(61.051)-(-15.226)-(-77.675));
clIoeOOMUYZmnVAR = (float) (-63.807-(76.145)-(54.899)-(22.037)-(29.049)-(-61.402));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-91.459-(31.216)-(-95.151)-(1.228)-(-37.96)-(-11.917));
