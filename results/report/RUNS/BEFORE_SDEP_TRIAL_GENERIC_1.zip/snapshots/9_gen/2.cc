float clIoeOOMUYZmnVAR = (float) (35.595+(35.121)+(-6.229));
int HIQwzIhphUEWjLJV = (int) ((-27.741*(37.131)*(-85.295)*(85.82))/52.588);
tcb->m_cWnd = (int) (53.504-(-31.175)-(47.504));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-36.259-(91.9)-(-4.638)-(-61.144)-(-46.799)-(-4.551));
clIoeOOMUYZmnVAR = (float) (69.416-(74.404)-(-72.787)-(-92.156)-(-66.146)-(1.877));
tcb->m_cWnd = (int) (-79.755-(88.999)-(42.342));
clIoeOOMUYZmnVAR = (float) (-9.269-(43.694)-(93.857)-(-30.763)-(-87.372)-(-44.172));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (77.192-(-41.814)-(-18.895)-(-7.875)-(14.794)-(64.198));
clIoeOOMUYZmnVAR = (float) (26.651-(49.682)-(-3.792)-(84.575)-(-3.396)-(-18.092));
tcb->m_cWnd = (int) (78.319-(22.669)-(58.708));
clIoeOOMUYZmnVAR = (float) (55.573-(14.514)-(89.423)-(-59.467)-(72.031)-(54.962));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (61.525-(68.742)-(-80.125)-(-13.595)-(94.495)-(-21.771));
clIoeOOMUYZmnVAR = (float) (11.621-(80.525)-(23.228)-(61.747)-(16.977)-(26.022));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-95.294-(-7.036)-(44.181)-(35.745)-(-85.438)-(-91.733));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-40.924-(-11.489)-(-3.085)-(-41.225)-(-14.479)-(4.081));
clIoeOOMUYZmnVAR = (float) (0.704-(-74.123)-(57.376)-(58.99)-(-30.689)-(-88.98));
clIoeOOMUYZmnVAR = (float) (17.351-(7.016)-(86.359)-(93.737)-(-73.513)-(-89.38));
tcb->m_cWnd = (int) (-27.711-(28.805)-(84.969));
clIoeOOMUYZmnVAR = (float) (91.798-(-70.181)-(-85.562)-(-24.977)-(-17.06)-(-76.335));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (32.287-(15.056)-(1.886)-(7.338)-(-48.386)-(26.783));
clIoeOOMUYZmnVAR = (float) (-17.239-(56.66)-(-46.289)-(-44.15)-(-78.046)-(-67.088));
clIoeOOMUYZmnVAR = (float) (-65.17-(42.514)-(8.755)-(50.758)-(-34.911)-(86.028));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (31.266-(-8.111)-(31.458)-(72.337)-(48.231)-(-24.245));
