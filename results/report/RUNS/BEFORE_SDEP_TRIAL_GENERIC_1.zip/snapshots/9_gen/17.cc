float clIoeOOMUYZmnVAR = (float) (-68.188+(-16.598)+(98.864));
int HIQwzIhphUEWjLJV = (int) ((43.759*(-28.524)*(22.709)*(88.038))/-15.206);
tcb->m_cWnd = (int) (-93.063-(61.466)-(27.291));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-24.198-(-6.632)-(30.625)-(76.211)-(57.209)-(22.399));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-40.998-(-50.756)-(-67.211)-(25.089)-(34.843)-(67.171));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-24.258-(-2.334)-(-1.658));
clIoeOOMUYZmnVAR = (float) (43.417-(39.413)-(-9.135)-(66.498)-(-67.321)-(-60.135));
clIoeOOMUYZmnVAR = (float) (-60.418-(-17.972)-(-34.912)-(-68.575)-(70.967)-(-73.999));
clIoeOOMUYZmnVAR = (float) (-63.802-(63.361)-(23.326)-(-94.306)-(19.177)-(58.038));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-32.648-(-64.307)-(77.235));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (62.936-(54.268)-(-44.067)-(-37.768)-(86.994)-(-82.333));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-19.869-(-73.595)-(-91.209)-(60.814)-(61.552)-(-33.09));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (10.068-(74.008)-(56.55)-(27.269)-(89.087)-(63.25));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (71.176-(69.268)-(-11.151)-(83.548)-(-19.377)-(-54.84));
clIoeOOMUYZmnVAR = (float) (57.284-(-36.343)-(-79.025)-(-39.279)-(73.239)-(-97.233));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-70.059-(-25.256)-(-22.581)-(12.108)-(-62.542)-(-35.58));
clIoeOOMUYZmnVAR = (float) (9.06-(27.918)-(-12.596)-(-33.509)-(-34.645)-(-82.406));
tcb->m_cWnd = (int) (-17.591-(56.669)-(-96.036));
clIoeOOMUYZmnVAR = (float) (-18.781-(-25.548)-(-93.017)-(-50.726)-(91.957)-(16.754));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (69.561-(6.741)-(-48.123)-(23.68)-(-34.614)-(-25.834));
clIoeOOMUYZmnVAR = (float) (9.758-(31.871)-(94.534)-(-56.084)-(79.061)-(81.964));
clIoeOOMUYZmnVAR = (float) (-19.004-(56.968)-(74.889)-(-28.492)-(-89.296)-(-92.013));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-8.315-(6.773)-(-26.583)-(57.474)-(-96.294)-(-63.639));
