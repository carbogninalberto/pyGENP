int HIQwzIhphUEWjLJV = (int) ((-72.305*(22.8)*(73.896)*(31.681))/-69.92);
tcb->m_cWnd = (int) (-29.602-(-40.298)-(-71.359));
float clIoeOOMUYZmnVAR = (float) (-84.085+(-2.262)+(35.556));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-40.058-(90.855)-(-93.332));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-98.033-(88.219)-(-3.891)-(-33.207)-(-51.115)-(-57.82));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (48.888-(76.422)-(-39.056)-(3.801)-(-20.505)-(25.822));
tcb->m_cWnd = (int) (-13.136-(-17.803)-(-10.18));
clIoeOOMUYZmnVAR = (float) (-41.591-(91.144)-(82.529)-(64.182)-(99.465)-(18.911));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-78.633-(-51.215)-(80.024)-(92.182)-(1.349)-(-84.49));
clIoeOOMUYZmnVAR = (float) (59.08-(50.108)-(-29.116)-(-72.623)-(-0.966)-(-8.341));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (47.221-(-18.422)-(10.159));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (50.885-(40.827)-(92.831)-(64.128)-(-88.393)-(-9.216));
tcb->m_cWnd = (int) (42.391-(-5.95)-(25.679));
clIoeOOMUYZmnVAR = (float) (54.853-(-91.112)-(79.073)-(-60.143)-(78.389)-(-42.726));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-28.905-(44.002)-(10.182)-(-10.916)-(67.525)-(-85.862));
clIoeOOMUYZmnVAR = (float) (-65.039-(66.347)-(90.005)-(-86.429)-(26.276)-(-11.576));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-11.037-(-94.893)-(73.917)-(-81.495)-(-92.332)-(38.331));
tcb->m_cWnd = (int) (-0.213-(87.652)-(19.366));
clIoeOOMUYZmnVAR = (float) (-75.971-(-94.245)-(34.621)-(-37.83)-(93.747)-(-77.519));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-59.697-(-34.604)-(-82.596)-(13.929)-(11.768)-(-88.838));
clIoeOOMUYZmnVAR = (float) (-54.751-(-0.88)-(-84.096)-(13.349)-(81.643)-(-67.429));
clIoeOOMUYZmnVAR = (float) (26.934-(-32.94)-(96.621)-(-80.795)-(14.904)-(7.398));
clIoeOOMUYZmnVAR = (float) (85.034-(-70.171)-(-86.444)-(-21.175)-(-67.178)-(70.619));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (72.942-(-98.043)-(-18.454)-(37.399)-(-88.379)-(-55.516));
clIoeOOMUYZmnVAR = (float) (-14.341-(13.253)-(55.354)-(78.381)-(-50.242)-(57.321));
clIoeOOMUYZmnVAR = (float) (77.65-(-78.441)-(84.349)-(-20.356)-(50.542)-(-30.914));
tcb->m_cWnd = (int) (-61.579-(-99.132)-(-16.479));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-49.322-(53.058)-(-55.676)-(39.255)-(43.14)-(80.687));
clIoeOOMUYZmnVAR = (float) (25.641-(27.654)-(38.461)-(-93.883)-(76.001)-(-51.12));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-31.435-(-78.395)-(-39.962)-(57.044)-(1.916)-(-67.873));
clIoeOOMUYZmnVAR = (float) (-16.015-(-36.027)-(-33.413)-(-43.78)-(84.604)-(9.722));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (8.391-(-44.333)-(-46.096)-(-42.298)-(53.683)-(-28.068));
clIoeOOMUYZmnVAR = (float) (-16.622-(-7.213)-(-58.839)-(-88.698)-(38.863)-(87.726));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (8.452-(97.829)-(97.574)-(7.166)-(-4.327)-(83.589));
