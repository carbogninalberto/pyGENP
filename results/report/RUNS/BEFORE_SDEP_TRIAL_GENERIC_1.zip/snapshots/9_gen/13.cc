float clIoeOOMUYZmnVAR = (float) (-58.608+(43.286)+(-19.82));
tcb->m_cWnd = (int) (-35.436-(73.38)-(-12.314));
int HIQwzIhphUEWjLJV = (int) ((-8.821*(91.902)*(15.942)*(-79.415))/78.412);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-25.065-(73.816)-(58.017));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-4.577-(29.344)-(47.584)-(94.485)-(13.727)-(-33.28));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (7.903-(64.058)-(26.456)-(-7.232)-(81.142)-(-93.428));
clIoeOOMUYZmnVAR = (float) (-67.205-(52.076)-(23.265)-(-48.742)-(3.934)-(-43.163));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-20.846-(-98.943)-(60.981)-(-56.341)-(-96.761)-(-15.835));
tcb->m_cWnd = (int) (-75.564-(85.325)-(-8.438));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (38.446-(93.728)-(-97.588)-(57.112)-(-82.596)-(-70.664));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-67.721-(-48.927)-(-51.594)-(-80.186)-(70.186)-(50.14));
clIoeOOMUYZmnVAR = (float) (12.287-(-86.814)-(19.905)-(-93.041)-(-28.107)-(-73.104));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (94.498-(-3.842)-(-51.023)-(99.994)-(43.278)-(-63.434));
