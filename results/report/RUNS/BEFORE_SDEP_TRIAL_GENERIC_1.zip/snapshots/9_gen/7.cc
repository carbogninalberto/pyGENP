tcb->m_cWnd = (int) (2.378-(-15.305)-(-41.09));
float clIoeOOMUYZmnVAR = (float) (-56.159+(-66.555)+(-90.781));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
int HIQwzIhphUEWjLJV = (int) ((-8.79*(-51.872)*(79.479)*(-28.39))/-56.496);
clIoeOOMUYZmnVAR = (float) (-44.844-(-50.943)-(92.914)-(-64.278)-(52.87)-(-63.8));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-82.913-(-53.309)-(32.728)-(62.668)-(72.266)-(21.01));
clIoeOOMUYZmnVAR = (float) (66.966-(-67.831)-(55.533)-(2.429)-(-37.153)-(36.462));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-87.08-(50.769)-(10.236)-(-6.872)-(16.637)-(99.711));
clIoeOOMUYZmnVAR = (float) (-67.608-(33.678)-(-41.963)-(-65.585)-(-74.025)-(49.416));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (71.586-(-27.484)-(-81.339)-(10.367)-(-88.684)-(-25.723));
clIoeOOMUYZmnVAR = (float) (6.662-(64.644)-(-81.528)-(97.307)-(70.242)-(84.539));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (54.88-(-84.711)-(72.822)-(-34.815)-(19.033)-(64.357));
clIoeOOMUYZmnVAR = (float) (55.001-(96.204)-(-18.169)-(18.863)-(-11.064)-(56.771));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-32.573-(-63.164)-(-40.378)-(-34.419)-(95.359)-(47.647));
clIoeOOMUYZmnVAR = (float) (2.984-(58.34)-(84.236)-(-72.021)-(-26.403)-(15.97));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-48.476-(50.775)-(-81.72)-(-20.361)-(-28.49)-(68.518));
