float clIoeOOMUYZmnVAR = (float) (-71.437+(55.566)+(34.181));
int HIQwzIhphUEWjLJV = (int) ((-9.869*(-11.42)*(29.92)*(-97.856))/-34.156);
tcb->m_cWnd = (int) (69.738-(82.224)-(64.77));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (22.12-(-57.0)-(27.086)-(-92.231)-(-80.447)-(58.807));
clIoeOOMUYZmnVAR = (float) (-92.34-(81.62)-(56.615)-(73.486)-(-81.699)-(71.489));
tcb->m_cWnd = (int) (-33.85-(-16.438)-(31.483));
clIoeOOMUYZmnVAR = (float) (-24.938-(-64.318)-(-51.995)-(85.3)-(-4.722)-(-29.346));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-68.763-(-98.671)-(80.769)-(50.454)-(-82.16)-(30.064));
clIoeOOMUYZmnVAR = (float) (-82.45-(-76.915)-(58.881)-(-57.03)-(13.676)-(26.3));
tcb->m_cWnd = (int) (-36.47-(30.306)-(81.391));
clIoeOOMUYZmnVAR = (float) (28.704-(25.021)-(37.434)-(16.17)-(-51.687)-(-40.534));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (12.543-(-7.195)-(36.516)-(-18.716)-(-79.673)-(-74.528));
clIoeOOMUYZmnVAR = (float) (-14.385-(-78.653)-(73.091)-(53.522)-(-98.99)-(-77.574));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (81.78-(74.222)-(-56.639)-(62.06)-(-56.819)-(-10.819));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-91.39-(85.281)-(-13.225)-(-53.718)-(-10.68)-(11.329));
clIoeOOMUYZmnVAR = (float) (44.697-(74.026)-(87.67)-(74.912)-(-33.213)-(-43.391));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (4.576-(-25.955)-(29.052)-(-31.97)-(46.842)-(-87.509));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-40.945-(-57.177)-(79.049)-(-83.136)-(-48.309)-(-49.606));
clIoeOOMUYZmnVAR = (float) (-95.601-(-48.112)-(54.507)-(72.163)-(10.653)-(47.703));
clIoeOOMUYZmnVAR = (float) (-88.045-(83.699)-(67.482)-(-77.56)-(-22.307)-(3.283));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (94.685-(77.533)-(74.135)-(-41.355)-(-15.187)-(28.242));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (94.851-(68.275)-(52.095));
clIoeOOMUYZmnVAR = (float) (43.313-(59.564)-(74.649)-(33.429)-(59.881)-(58.277));
clIoeOOMUYZmnVAR = (float) (-50.462-(19.956)-(-10.649)-(-15.435)-(50.646)-(-80.716));
clIoeOOMUYZmnVAR = (float) (-56.305-(-3.896)-(64.115)-(49.257)-(-72.646)-(-5.0));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (50.277-(66.921)-(-73.545)-(70.421)-(0.904)-(-94.739));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-80.552-(98.955)-(-86.083));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-6.409-(-92.179)-(-82.412)-(-13.233)-(-47.476)-(20.436));
clIoeOOMUYZmnVAR = (float) (-5.557-(99.983)-(77.904)-(72.663)-(-58.219)-(0.123));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (37.729-(82.547)-(46.784)-(-81.234)-(60.285)-(42.721));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-52.597-(-3.835)-(41.983)-(90.543)-(18.878)-(13.631));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-92.218-(82.498)-(-91.65)-(-74.71)-(60.824)-(82.275));
clIoeOOMUYZmnVAR = (float) (96.464-(23.759)-(15.923)-(-62.804)-(-40.161)-(32.181));
clIoeOOMUYZmnVAR = (float) (69.953-(31.694)-(19.953)-(61.298)-(-37.858)-(34.624));
clIoeOOMUYZmnVAR = (float) (44.896-(-98.496)-(70.405)-(-96.243)-(67.56)-(-80.88));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (60.52-(16.204)-(-1.777)-(78.17)-(-43.45)-(-30.455));
