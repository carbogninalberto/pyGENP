float clIoeOOMUYZmnVAR = (float) (-6.165+(80.198)+(-72.618));
int HIQwzIhphUEWjLJV = (int) ((61.029*(-25.014)*(11.664)*(-34.396))/90.429);
tcb->m_cWnd = (int) (-22.693-(-16.041)-(35.127));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-23.794-(10.595)-(16.072)-(20.484)-(86.667)-(57.006));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-75.761-(6.537)-(-44.158)-(-46.29)-(97.737)-(-22.938));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (19.559-(-31.492)-(-63.932));
clIoeOOMUYZmnVAR = (float) (87.692-(18.909)-(51.249)-(-18.521)-(-96.876)-(-26.448));
clIoeOOMUYZmnVAR = (float) (44.694-(-61.048)-(-31.258)-(13.098)-(-63.833)-(-29.509));
clIoeOOMUYZmnVAR = (float) (-90.857-(-69.637)-(-75.255)-(6.643)-(-95.763)-(87.343));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-86.537-(-63.869)-(68.061));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (11.414-(-36.869)-(-6.751)-(58.536)-(52.039)-(-25.421));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (78.708-(-61.118)-(-49.664)-(-45.8)-(84.717)-(40.153));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (92.034-(-60.98)-(94.893)-(11.423)-(-49.583)-(21.642));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-27.08-(-17.1)-(10.17)-(-59.48)-(-21.433)-(8.284));
clIoeOOMUYZmnVAR = (float) (57.22-(-4.976)-(-40.686)-(-63.831)-(32.309)-(-6.374));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (76.278-(-45.085)-(-16.307)-(-47.711)-(-84.503)-(-84.43));
clIoeOOMUYZmnVAR = (float) (8.334-(76.172)-(36.282)-(66.961)-(-41.527)-(82.361));
clIoeOOMUYZmnVAR = (float) (-58.908-(47.515)-(11.153)-(-7.606)-(37.35)-(-66.213));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-43.371-(-40.612)-(-17.627));
clIoeOOMUYZmnVAR = (float) (53.818-(-99.828)-(98.218)-(-46.772)-(-35.459)-(13.185));
clIoeOOMUYZmnVAR = (float) (-17.143-(-34.377)-(89.251)-(39.809)-(5.7)-(-57.493));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (80.995-(65.402)-(53.771)-(-35.849)-(-3.44)-(52.77));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (24.187-(-16.079)-(41.49)-(77.607)-(-57.944)-(96.505));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-75.162-(82.86)-(-93.207)-(-15.771)-(88.871)-(66.77));
clIoeOOMUYZmnVAR = (float) (24.0-(21.607)-(0.575)-(-10.365)-(-73.785)-(-78.152));
clIoeOOMUYZmnVAR = (float) (67.42-(66.325)-(13.783)-(-20.512)-(-97.352)-(41.39));
clIoeOOMUYZmnVAR = (float) (-73.267-(17.906)-(19.918)-(47.094)-(-42.341)-(32.639));
clIoeOOMUYZmnVAR = (float) (-99.238-(-60.622)-(41.943)-(-94.013)-(84.255)-(82.606));
tcb->m_cWnd = (int) (-22.946-(-56.759)-(45.459));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (93.756-(-64.294)-(-13.606)-(76.287)-(-36.181)-(59.168));
clIoeOOMUYZmnVAR = (float) (51.407-(-91.004)-(14.449)-(-39.586)-(-65.224)-(90.896));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-90.024-(89.436)-(-9.2)-(-78.491)-(80.764)-(10.568));
clIoeOOMUYZmnVAR = (float) (-33.806-(22.738)-(22.771)-(-60.206)-(-65.442)-(-67.448));
clIoeOOMUYZmnVAR = (float) (-39.143-(75.546)-(25.873)-(-55.583)-(-50.781)-(-17.441));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-10.773-(-82.627)-(61.112)-(45.593)-(87.243)-(-54.387));
