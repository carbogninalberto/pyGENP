float clIoeOOMUYZmnVAR = (float) (56.44+(-28.134)+(-1.334));
int HIQwzIhphUEWjLJV = (int) ((97.457*(95.451)*(17.96)*(-58.182))/-63.579);
tcb->m_cWnd = (int) (-24.28-(22.373)-(-53.043));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (42.285-(-98.437)-(-90.588)-(31.815)-(-23.151)-(-68.011));
clIoeOOMUYZmnVAR = (float) (9.413-(14.044)-(82.266)-(93.951)-(-76.331)-(-40.574));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-33.589-(66.916)-(37.433)-(-21.591)-(-62.833)-(-67.046));
clIoeOOMUYZmnVAR = (float) (-54.836-(-71.613)-(-11.116)-(-92.709)-(-29.388)-(94.476));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (47.839-(92.089)-(59.797));
tcb->m_cWnd = (int) (-54.643-(-82.343)-(69.386));
clIoeOOMUYZmnVAR = (float) (-79.98-(46.527)-(31.427)-(1.65)-(78.761)-(-15.586));
clIoeOOMUYZmnVAR = (float) (-45.839-(46.858)-(84.773)-(-87.267)-(-46.382)-(38.177));
clIoeOOMUYZmnVAR = (float) (-47.521-(91.041)-(40.82)-(-15.545)-(-52.358)-(23.502));
clIoeOOMUYZmnVAR = (float) (48.613-(77.797)-(-64.668)-(-63.052)-(8.387)-(-80.275));
clIoeOOMUYZmnVAR = (float) (-50.864-(97.261)-(13.912)-(40.47)-(63.149)-(-11.568));
clIoeOOMUYZmnVAR = (float) (-45.036-(-67.824)-(99.855)-(39.579)-(62.455)-(76.418));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (12.388-(-82.485)-(67.52));
tcb->m_cWnd = (int) (-53.125-(-50.542)-(-57.144));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (99.051-(-16.371)-(22.145)-(7.799)-(47.737)-(-66.448));
clIoeOOMUYZmnVAR = (float) (-91.223-(53.626)-(-62.683)-(40.525)-(-99.474)-(48.809));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (32.733-(-76.965)-(-10.498)-(-53.954)-(-14.525)-(62.298));
clIoeOOMUYZmnVAR = (float) (-76.901-(21.059)-(-59.163)-(11.012)-(64.327)-(40.423));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-1.994-(82.9)-(-63.165)-(-27.804)-(89.901)-(-2.622));
clIoeOOMUYZmnVAR = (float) (97.025-(64.311)-(-94.304)-(-81.048)-(-57.123)-(-33.174));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-31.201-(-29.127)-(56.024)-(-27.809)-(-28.747)-(-94.241));
clIoeOOMUYZmnVAR = (float) (-94.169-(26.584)-(95.623)-(-62.375)-(30.244)-(-47.907));
clIoeOOMUYZmnVAR = (float) (1.314-(-90.471)-(-60.11)-(-78.421)-(51.451)-(-53.778));
clIoeOOMUYZmnVAR = (float) (-76.109-(-89.763)-(-51.685)-(33.704)-(-11.08)-(11.033));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (23.744-(93.203)-(55.782)-(79.97)-(-12.442)-(-38.298));
clIoeOOMUYZmnVAR = (float) (76.321-(-59.241)-(9.966)-(62.821)-(31.236)-(13.276));
clIoeOOMUYZmnVAR = (float) (-58.84-(-50.282)-(16.31)-(81.73)-(-91.599)-(37.88));
clIoeOOMUYZmnVAR = (float) (-19.79-(-83.587)-(79.4)-(-89.243)-(72.97)-(-93.645));
tcb->m_cWnd = (int) (-93.845-(-65.662)-(41.601));
tcb->m_cWnd = (int) (-55.434-(-33.919)-(-27.32));
clIoeOOMUYZmnVAR = (float) (20.151-(-67.808)-(-76.846)-(-97.332)-(-89.848)-(15.566));
clIoeOOMUYZmnVAR = (float) (14.042-(-50.579)-(75.482)-(35.572)-(-6.399)-(-18.461));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-89.061-(-4.268)-(-22.074)-(11.284)-(96.582)-(-84.813));
clIoeOOMUYZmnVAR = (float) (-91.255-(-43.554)-(-12.994)-(-7.353)-(41.095)-(-39.581));
clIoeOOMUYZmnVAR = (float) (-80.375-(-39.845)-(79.199)-(3.152)-(-48.285)-(-14.68));
clIoeOOMUYZmnVAR = (float) (-22.531-(48.674)-(-39.65)-(-90.665)-(84.815)-(52.799));
clIoeOOMUYZmnVAR = (float) (-2.798-(-21.039)-(-53.276)-(59.997)-(52.524)-(-50.732));
clIoeOOMUYZmnVAR = (float) (-66.049-(49.31)-(-79.282)-(-80.198)-(8.024)-(39.103));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (91.227-(1.765)-(1.499)-(84.755)-(-4.255)-(-59.615));
clIoeOOMUYZmnVAR = (float) (8.416-(-11.607)-(-44.733)-(75.034)-(-24.033)-(-89.556));
