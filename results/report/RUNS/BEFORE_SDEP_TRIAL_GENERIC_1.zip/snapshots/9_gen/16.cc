int HIQwzIhphUEWjLJV = (int) ((42.451*(-70.519)*(77.879)*(81.347))/39.533);
tcb->m_cWnd = (int) (10.066-(-58.801)-(97.839));
float clIoeOOMUYZmnVAR = (float) (-65.446+(49.438)+(-47.257));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-4.748-(-71.017)-(86.646));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-5.389-(-50.176)-(-97.311)-(-59.405)-(-64.083)-(81.488));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-33.795-(34.673)-(3.938)-(-9.372)-(58.086)-(-20.797));
tcb->m_cWnd = (int) (-97.751-(73.919)-(27.787));
clIoeOOMUYZmnVAR = (float) (91.442-(-29.2)-(-83.128)-(-70.899)-(85.833)-(32.845));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (35.404-(-1.761)-(4.023)-(-82.599)-(88.596)-(81.215));
clIoeOOMUYZmnVAR = (float) (-43.264-(15.572)-(41.027)-(-51.313)-(57.653)-(-71.553));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-27.95-(60.754)-(-7.694)-(82.595)-(-44.165)-(12.388));
clIoeOOMUYZmnVAR = (float) (93.705-(-10.514)-(-17.53)-(89.226)-(-77.867)-(-43.78));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-50.518-(-92.852)-(8.106)-(-6.386)-(11.991)-(-41.573));
