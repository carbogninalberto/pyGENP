tcb->m_cWnd = (int) (-93.834-(36.898)-(-3.876));
float clIoeOOMUYZmnVAR = (float) (35.424+(38.242)+(-13.366));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
int HIQwzIhphUEWjLJV = (int) ((-23.327*(-86.937)*(-42.87)*(95.335))/34.067);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (14.124-(-11.079)-(-9.217)-(47.997)-(40.448)-(-70.087));
clIoeOOMUYZmnVAR = (float) (-85.705-(-91.043)-(82.479)-(48.232)-(17.838)-(-54.771));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (30.749-(23.082)-(-94.421)-(-54.343)-(96.882)-(-23.24));
