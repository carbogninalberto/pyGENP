int HIQwzIhphUEWjLJV = (int) ((-35.944*(-51.261)*(84.123)*(-67.672))/-71.782);
tcb->m_cWnd = (int) (-52.703-(78.768)-(-10.786));
float clIoeOOMUYZmnVAR = (float) (13.755+(87.288)+(-94.062));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-63.036-(93.332)-(-34.819));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (50.692-(3.315)-(-86.166)-(-61.577)-(-75.543)-(32.055));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-30.57-(-20.297)-(91.355)-(45.27)-(-11.074)-(-4.819));
clIoeOOMUYZmnVAR = (float) (-13.227-(90.775)-(11.062)-(-33.407)-(62.224)-(85.267));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (40.661-(69.023)-(-88.245)-(-92.542)-(-17.827)-(96.409));
tcb->m_cWnd = (int) (-97.453-(65.318)-(-43.869));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (42.378-(88.772)-(23.923)-(42.208)-(46.063)-(-56.947));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (39.333-(88.598)-(62.322)-(-92.062)-(16.615)-(70.529));
clIoeOOMUYZmnVAR = (float) (-86.783-(-73.787)-(86.287)-(56.452)-(-25.536)-(-40.746));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (2.935-(8.074)-(-23.786)-(63.396)-(6.733)-(51.41));
