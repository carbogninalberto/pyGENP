int HIQwzIhphUEWjLJV = (int) ((-56.154*(-82.52)*(41.488)*(-56.283))/21.895);
float clIoeOOMUYZmnVAR = (float) (34.775+(-32.993)+(70.132));
tcb->m_cWnd = (int) (94.664-(-81.187)-(-53.052));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (49.992-(-57.494)-(-76.735)-(30.377)-(-42.101)-(96.949));
clIoeOOMUYZmnVAR = (float) (72.821-(-36.828)-(-6.185)-(-91.225)-(-4.013)-(-70.187));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-10.806-(85.719)-(-10.122));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-8.029-(-57.741)-(35.181)-(14.028)-(-35.608)-(76.546));
clIoeOOMUYZmnVAR = (float) (-84.345-(65.285)-(-2.366)-(68.653)-(-52.249)-(-27.713));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (36.304-(22.833)-(63.42)-(-89.5)-(25.918)-(-17.194));
clIoeOOMUYZmnVAR = (float) (-66.084-(-42.511)-(16.815)-(68.737)-(44.476)-(-76.021));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (59.503-(-3.482)-(74.86)-(44.845)-(35.629)-(99.684));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-45.987-(-57.743)-(55.003)-(-72.198)-(-1.854)-(-70.615));
clIoeOOMUYZmnVAR = (float) (95.431-(-79.892)-(27.34)-(-65.19)-(98.176)-(29.411));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-77.192-(-17.213)-(53.597)-(-93.839)-(69.429)-(25.304));
clIoeOOMUYZmnVAR = (float) (76.613-(-56.589)-(-62.616)-(48.231)-(-61.421)-(41.678));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (57.322-(63.07)-(14.71)-(26.549)-(-38.519)-(-13.512));
clIoeOOMUYZmnVAR = (float) (51.158-(-68.342)-(8.978)-(-42.485)-(-53.935)-(-11.482));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-69.668-(10.774)-(43.213)-(-41.926)-(75.729)-(90.894));
