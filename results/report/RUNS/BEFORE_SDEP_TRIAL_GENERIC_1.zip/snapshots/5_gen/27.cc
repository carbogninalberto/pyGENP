tcb->m_cWnd = (int) (-19.839-(-69.276)-(-84.498));
float clIoeOOMUYZmnVAR = (float) (-6.007+(84.523)+(63.301));
clIoeOOMUYZmnVAR = (float) (-33.513-(-10.76)-(-14.19)-(83.489)-(4.415)-(-38.078));
int HIQwzIhphUEWjLJV = (int) ((-61.264*(-66.113)*(61.871)*(-53.57))/-91.516);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-31.944-(-55.314)-(-10.79)-(12.323)-(-48.554)-(-76.414));
clIoeOOMUYZmnVAR = (float) (8.75-(-57.175)-(94.51)-(-11.756)-(51.303)-(-17.191));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-2.753-(-29.299)-(-27.701)-(99.823)-(-37.299)-(-13.743));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (75.723-(-28.495)-(42.483)-(46.297)-(83.458)-(95.212));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-49.248-(68.136)-(79.431)-(58.545)-(0.775)-(-15.235));
