int HIQwzIhphUEWjLJV = (int) ((-45.493*(-46.003)*(14.998)*(-31.062))/-72.978);
tcb->m_cWnd = (int) (36.987-(-53.299)-(-48.281));
float clIoeOOMUYZmnVAR = (float) (-78.677+(29.764)+(-85.755));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-62.765-(-89.101)-(-45.124));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (69.271-(-24.687)-(-81.911)-(34.536)-(-47.174)-(84.9));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-50.185-(-93.524)-(-65.465)-(68.053)-(1.591)-(80.319));
clIoeOOMUYZmnVAR = (float) (46.403-(4.234)-(-51.49)-(50.1)-(-10.253)-(14.249));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (99.539-(-37.222)-(-56.15)-(72.026)-(-43.927)-(-33.228));
