TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((((68.136+(45.285)+(-71.43)+(-35.524)+(44.208)+(-34.922)+(72.684)))+(-41.571)+((-32.609*(30.391)*(-7.353)*(-60.127)*(7.747)))+(77.372))/((39.062)+(31.715)+(85.192)+(-4.557)));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-45.14*(81.92)*(79.961)*(99.882)*(-80.277));
