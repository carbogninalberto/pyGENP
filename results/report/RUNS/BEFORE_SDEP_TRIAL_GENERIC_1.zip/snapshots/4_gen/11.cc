segmentsAcked = (int) (-79.797-(-47.767));
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (20.781-(80.759)-(tcb->m_cWnd)-(62.692));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (45.235-(54.056)-(29.146)-(12.452)-(14.262)-(63.507));

}
