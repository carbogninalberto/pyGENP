float clIoeOOMUYZmnVAR = (float) (-61.349+(-13.066)+(72.327));
tcb->m_cWnd = (int) (-25.109-(-23.607)-(45.226));
int HIQwzIhphUEWjLJV = (int) ((35.797*(-23.106)*(41.509)*(83.338))/60.086);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-48.678-(-47.716)-(-91.278));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-56.214-(70.699)-(-24.076)-(-40.855)-(85.616)-(-30.644));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-52.772-(88.937)-(33.305)-(11.749)-(-33.042)-(-94.144));
tcb->m_cWnd = (int) (-37.977-(26.857)-(-85.647));
clIoeOOMUYZmnVAR = (float) (-30.638-(-45.564)-(40.94)-(59.885)-(-65.012)-(6.93));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (14.098-(92.672)-(-57.05)-(-93.329)-(-39.326)-(57.487));
clIoeOOMUYZmnVAR = (float) (19.523-(-62.067)-(-21.013)-(-27.187)-(-30.792)-(-43.464));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (39.515-(-87.807)-(-25.059));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-77.642-(13.473)-(-4.029)-(20.502)-(-6.451)-(-4.058));
tcb->m_cWnd = (int) (-98.905-(-21.398)-(-79.271));
clIoeOOMUYZmnVAR = (float) (-71.118-(75.974)-(27.486)-(11.386)-(-76.802)-(-10.349));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-95.048-(-90.108)-(0.925)-(-32.504)-(45.685)-(52.288));
clIoeOOMUYZmnVAR = (float) (33.764-(40.936)-(47.709)-(12.312)-(-39.293)-(-59.415));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (17.514-(-84.709)-(34.546)-(-60.593)-(-72.528)-(43.014));
tcb->m_cWnd = (int) (68.54-(-52.648)-(23.955));
clIoeOOMUYZmnVAR = (float) (73.805-(62.067)-(-62.98)-(84.284)-(-3.865)-(-4.14));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (49.182-(-64.774)-(-38.412)-(37.735)-(67.073)-(86.016));
clIoeOOMUYZmnVAR = (float) (-10.955-(-19.261)-(-15.903)-(69.942)-(27.468)-(71.995));
clIoeOOMUYZmnVAR = (float) (-80.804-(-17.021)-(58.374)-(-33.91)-(93.283)-(68.017));
clIoeOOMUYZmnVAR = (float) (-11.565-(49.691)-(78.528)-(37.746)-(66.346)-(75.51));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (83.079-(24.746)-(95.702)-(-36.777)-(53.217)-(44.968));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (91.866-(5.679)-(73.819)-(-68.034)-(79.701)-(7.089));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (76.006-(66.096)-(50.044)-(92.355)-(12.948)-(-96.493));
clIoeOOMUYZmnVAR = (float) (-39.665-(11.991)-(-87.042)-(-42.351)-(20.245)-(46.545));
clIoeOOMUYZmnVAR = (float) (-27.194-(59.068)-(42.22)-(-54.383)-(39.149)-(-65.204));
clIoeOOMUYZmnVAR = (float) (7.223-(-59.779)-(-51.714)-(57.095)-(93.742)-(47.881));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-23.197-(82.941)-(-69.743)-(-76.901)-(-40.411)-(-86.526));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (49.24-(-90.64)-(-28.608));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (74.768-(-77.959)-(-57.684)-(82.467)-(-20.921)-(-39.366));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (20.36-(75.974)-(-41.836)-(93.798)-(-95.92)-(84.057));
clIoeOOMUYZmnVAR = (float) (-89.196-(-20.659)-(6.529)-(3.736)-(55.899)-(84.163));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (97.528-(-80.343)-(93.28)-(-20.854)-(65.283)-(13.446));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-16.357-(28.767)-(-16.524)-(62.562)-(-86.987)-(-35.089));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-71.711-(-78.702)-(82.095));
clIoeOOMUYZmnVAR = (float) (93.385-(82.81)-(-95.843)-(-89.673)-(48.172)-(-42.021));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (24.328-(10.314)-(-92.803)-(14.558)-(88.914)-(0.099));
clIoeOOMUYZmnVAR = (float) (-1.204-(-13.16)-(31.481)-(0.173)-(-21.1)-(52.718));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (7.834-(69.83)-(-16.501)-(-30.106)-(-44.918)-(85.599));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-66.951-(31.518)-(-66.522)-(-82.418)-(22.481)-(-25.687));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-61.94-(7.223)-(56.235)-(35.177)-(-1.505)-(4.97));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (5.251-(-82.101)-(89.901)-(87.719)-(-71.676)-(-12.152));
clIoeOOMUYZmnVAR = (float) (59.572-(46.672)-(-46.78)-(33.156)-(20.731)-(-97.609));
clIoeOOMUYZmnVAR = (float) (24.178-(43.787)-(-80.976)-(2.487)-(5.976)-(-15.081));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-32.726-(58.196)-(-91.551)-(80.091)-(6.959)-(-98.572));
clIoeOOMUYZmnVAR = (float) (18.163-(-12.196)-(33.973)-(-57.473)-(-99.044)-(-50.626));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (11.831-(80.459)-(72.645)-(-22.979)-(-95.9)-(36.472));
