tcb->m_cWnd = (int) (35.366-(88.807)-(-61.022));
int HIQwzIhphUEWjLJV = (int) ((46.412*(48.867)*(14.539)*(7.591))/94.312);
CongestionAvoidance (tcb, segmentsAcked);
float clIoeOOMUYZmnVAR = (float) (39.597+(-12.712)+(-12.954));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (13.226-(-53.2)-(50.665)-(87.099)-(-84.928)-(-84.826));
clIoeOOMUYZmnVAR = (float) (23.04-(-41.182)-(-80.336)-(-47.941)-(43.084)-(-93.288));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-52.019-(78.443)-(-35.965)-(-70.924)-(28.72)-(-43.817));
clIoeOOMUYZmnVAR = (float) (-89.184-(86.532)-(-90.801)-(-62.672)-(4.01)-(33.376));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (42.423-(-67.555)-(-91.228));
tcb->m_cWnd = (int) (90.386-(24.887)-(82.031));
clIoeOOMUYZmnVAR = (float) (16.216-(92.554)-(98.034)-(94.964)-(6.652)-(-33.677));
clIoeOOMUYZmnVAR = (float) (-88.896-(-61.239)-(-47.712)-(37.906)-(-68.469)-(53.582));
clIoeOOMUYZmnVAR = (float) (31.272-(81.111)-(84.467)-(45.403)-(-78.461)-(44.822));
clIoeOOMUYZmnVAR = (float) (77.558-(20.68)-(18.039)-(34.408)-(-10.231)-(-76.873));
clIoeOOMUYZmnVAR = (float) (-56.273-(-95.802)-(-62.701)-(-86.56)-(78.114)-(83.444));
clIoeOOMUYZmnVAR = (float) (5.326-(-78.385)-(-99.629)-(-85.128)-(-24.683)-(-72.472));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-41.424-(-22.956)-(-58.197));
tcb->m_cWnd = (int) (-47.345-(75.346)-(-65.266));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (32.811-(-8.079)-(45.855)-(-75.084)-(-93.04)-(-60.533));
clIoeOOMUYZmnVAR = (float) (-80.053-(-12.717)-(-37.948)-(20.675)-(5.692)-(23.526));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (53.627-(-36.853)-(-72.338)-(-10.374)-(97.827)-(39.794));
clIoeOOMUYZmnVAR = (float) (-77.357-(79.504)-(-26.85)-(54.103)-(19.099)-(-28.95));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (53.11-(20.412)-(17.775)-(42.34)-(-84.437)-(-17.836));
clIoeOOMUYZmnVAR = (float) (-22.07-(96.117)-(59.397)-(37.633)-(-19.148)-(20.892));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (40.594-(48.938)-(-42.074)-(76.181)-(80.694)-(-37.529));
clIoeOOMUYZmnVAR = (float) (73.221-(12.397)-(97.213)-(27.678)-(-82.065)-(72.618));
clIoeOOMUYZmnVAR = (float) (3.413-(89.812)-(-88.068)-(-16.47)-(0.94)-(97.292));
clIoeOOMUYZmnVAR = (float) (99.423-(47.815)-(18.917)-(-33.365)-(21.315)-(-52.806));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-30.975-(62.058)-(-87.39)-(46.861)-(2.046)-(24.868));
clIoeOOMUYZmnVAR = (float) (46.423-(-81.997)-(67.951)-(-72.67)-(-69.952)-(68.2));
clIoeOOMUYZmnVAR = (float) (66.374-(-46.034)-(52.338)-(-36.797)-(46.308)-(85.639));
clIoeOOMUYZmnVAR = (float) (-90.774-(26.189)-(53.218)-(-92.919)-(-23.454)-(20.064));
tcb->m_cWnd = (int) (26.703-(-5.561)-(-28.791));
tcb->m_cWnd = (int) (27.726-(-89.837)-(23.525));
clIoeOOMUYZmnVAR = (float) (31.473-(72.796)-(13.087)-(89.528)-(33.009)-(-93.061));
clIoeOOMUYZmnVAR = (float) (-12.254-(91.135)-(73.6)-(78.058)-(84.56)-(68.7));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-92.572-(71.058)-(-72.599)-(-23.049)-(21.874)-(-12.092));
clIoeOOMUYZmnVAR = (float) (47.936-(72.222)-(74.592)-(-92.168)-(31.6)-(4.736));
clIoeOOMUYZmnVAR = (float) (85.181-(-66.806)-(-26.038)-(60.523)-(-48.754)-(-72.124));
clIoeOOMUYZmnVAR = (float) (-95.629-(-82.543)-(29.273)-(90.663)-(-61.091)-(43.933));
clIoeOOMUYZmnVAR = (float) (54.886-(71.306)-(62.799)-(-86.867)-(-92.017)-(95.846));
clIoeOOMUYZmnVAR = (float) (-69.16-(-83.069)-(-56.752)-(87.135)-(-59.622)-(-44.434));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (33.502-(69.552)-(51.417)-(-31.683)-(3.653)-(-66.416));
clIoeOOMUYZmnVAR = (float) (57.389-(-25.207)-(41.184)-(23.985)-(-0.528)-(46.555));
