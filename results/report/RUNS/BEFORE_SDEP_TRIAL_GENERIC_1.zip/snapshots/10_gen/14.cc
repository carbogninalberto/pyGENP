float clIoeOOMUYZmnVAR = (float) (-47.718+(-67.455)+(-75.676));
tcb->m_cWnd = (int) (98.101-(-55.379)-(-20.07));
int HIQwzIhphUEWjLJV = (int) ((7.073*(-50.878)*(57.03)*(31.424))/18.248);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (55.712-(24.073)-(-45.097));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-52.322-(-88.801)-(24.216)-(-54.74)-(-1.117)-(-69.093));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-39.353-(88.78)-(-57.247)-(64.055)-(68.835)-(66.834));
tcb->m_cWnd = (int) (-30.125-(80.248)-(57.279));
clIoeOOMUYZmnVAR = (float) (-48.98-(-9.036)-(11.663)-(62.523)-(22.891)-(-89.578));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-30.522-(75.199)-(-82.235)-(-9.782)-(79.176)-(-84.123));
clIoeOOMUYZmnVAR = (float) (3.307-(-52.849)-(81.65)-(-28.058)-(-44.46)-(-42.191));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (15.266-(62.87)-(-23.873));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (49.104-(-23.208)-(87.149)-(-79.099)-(48.003)-(67.448));
tcb->m_cWnd = (int) (24.766-(41.876)-(-93.421));
clIoeOOMUYZmnVAR = (float) (34.705-(-76.685)-(79.926)-(-15.825)-(76.063)-(-29.043));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (21.899-(-61.238)-(-63.092)-(-69.003)-(-79.31)-(35.473));
clIoeOOMUYZmnVAR = (float) (-60.348-(-8.505)-(-46.84)-(-56.851)-(99.714)-(1.656));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-71.946-(42.801)-(89.53)-(77.838)-(-21.204)-(-34.7));
tcb->m_cWnd = (int) (-34.14-(26.595)-(81.808));
clIoeOOMUYZmnVAR = (float) (-74.433-(56.392)-(90.997)-(47.926)-(51.255)-(61.831));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (49.186-(6.765)-(84.815)-(-66.155)-(27.54)-(66.324));
clIoeOOMUYZmnVAR = (float) (-95.598-(-0.401)-(62.149)-(95.441)-(-1.95)-(-61.356));
clIoeOOMUYZmnVAR = (float) (-82.489-(-64.868)-(90.186)-(60.835)-(86.149)-(24.844));
clIoeOOMUYZmnVAR = (float) (-80.168-(44.33)-(-34.156)-(17.394)-(-76.377)-(85.471));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (99.761-(91.499)-(-33.653)-(-19.776)-(26.485)-(-22.662));
clIoeOOMUYZmnVAR = (float) (-39.556-(82.068)-(78.48)-(-83.575)-(-27.702)-(-37.002));
clIoeOOMUYZmnVAR = (float) (-45.526-(79.737)-(-35.137)-(-10.316)-(60.39)-(75.945));
tcb->m_cWnd = (int) (-50.152-(-92.379)-(90.02));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (27.199-(-67.018)-(40.555)-(-62.31)-(22.827)-(5.005));
clIoeOOMUYZmnVAR = (float) (50.577-(-78.554)-(72.565)-(-48.226)-(91.798)-(80.979));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (25.703-(-44.291)-(38.133)-(35.501)-(92.008)-(9.709));
clIoeOOMUYZmnVAR = (float) (67.311-(43.176)-(18.273)-(5.421)-(-77.353)-(-58.175));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-62.421-(-70.82)-(67.404)-(44.747)-(37.679)-(-88.237));
clIoeOOMUYZmnVAR = (float) (-53.816-(-90.576)-(14.163)-(19.032)-(-74.575)-(37.787));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (91.472-(-76.657)-(37.674)-(-19.764)-(-23.377)-(43.655));
