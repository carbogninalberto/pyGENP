float clIoeOOMUYZmnVAR = (float) (85.18+(84.885)+(98.678));
tcb->m_cWnd = (int) (-57.256-(85.191)-(-47.149));
int HIQwzIhphUEWjLJV = (int) ((88.662*(53.47)*(74.075)*(63.775))/53.892);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (10.334-(-44.556)-(61.664));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (78.58-(94.806)-(-49.191)-(-13.195)-(-1.97)-(-13.626));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (89.298-(88.01)-(-1.47)-(35.085)-(55.659)-(-20.647));
tcb->m_cWnd = (int) (-70.351-(40.606)-(69.433));
clIoeOOMUYZmnVAR = (float) (-79.353-(74.194)-(75.984)-(51.315)-(-41.938)-(8.825));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (30.736-(58.487)-(-7.468)-(82.169)-(-41.427)-(-76.589));
clIoeOOMUYZmnVAR = (float) (-38.554-(61.88)-(84.164)-(25.975)-(-89.357)-(48.209));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-26.976-(52.137)-(67.466));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (31.975-(80.463)-(-7.271)-(22.886)-(5.32)-(-94.623));
tcb->m_cWnd = (int) (26.439-(20.953)-(-82.445));
clIoeOOMUYZmnVAR = (float) (-83.088-(12.149)-(-96.708)-(92.717)-(55.886)-(-96.323));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (29.356-(-51.168)-(-64.998)-(-32.093)-(-7.889)-(70.511));
clIoeOOMUYZmnVAR = (float) (-8.605-(-96.254)-(-41.684)-(-46.737)-(-6.162)-(-9.198));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (18.339-(12.248)-(-91.256)-(82.072)-(-9.025)-(47.729));
tcb->m_cWnd = (int) (-86.135-(-9.192)-(94.622));
clIoeOOMUYZmnVAR = (float) (84.428-(11.923)-(49.685)-(-3.203)-(8.521)-(-62.568));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-23.32-(99.814)-(6.17)-(18.697)-(-68.823)-(1.778));
clIoeOOMUYZmnVAR = (float) (41.403-(68.046)-(76.692)-(-27.057)-(22.845)-(18.398));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (14.742-(-39.039)-(-78.036)-(50.399)-(88.555)-(15.442));
clIoeOOMUYZmnVAR = (float) (-89.728-(95.258)-(36.456)-(64.794)-(-34.631)-(-20.453));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-91.475-(-66.306)-(40.491)-(80.232)-(20.509)-(34.296));
