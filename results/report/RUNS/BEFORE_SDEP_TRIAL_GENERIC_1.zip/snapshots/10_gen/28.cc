tcb->m_cWnd = (int) (-40.616-(46.488)-(89.756));
int HIQwzIhphUEWjLJV = (int) ((59.283*(24.365)*(64.852)*(-28.007))/51.892);
CongestionAvoidance (tcb, segmentsAcked);
float clIoeOOMUYZmnVAR = (float) (94.9+(26.649)+(74.832));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-40.54-(-52.61)-(-76.214)-(-80.256)-(68.533)-(-43.021));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-27.252-(4.944)-(-77.499)-(36.772)-(-22.424)-(-38.907));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (55.51-(17.737)-(-86.875));
clIoeOOMUYZmnVAR = (float) (45.617-(26.561)-(28.585)-(-46.869)-(-36.121)-(-83.508));
clIoeOOMUYZmnVAR = (float) (-80.529-(-61.768)-(67.946)-(-99.132)-(1.07)-(-34.055));
clIoeOOMUYZmnVAR = (float) (43.856-(-40.062)-(-81.902)-(36.335)-(-73.369)-(-82.508));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (20.612-(-67.429)-(29.303));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-69.789-(-71.924)-(-14.359)-(40.8)-(70.174)-(-2.887));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-92.511-(78.107)-(-57.801)-(-36.324)-(74.86)-(-78.365));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-98.352-(38.587)-(93.036)-(-12.434)-(-65.725)-(-60.022));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (81.159-(-9.95)-(98.298)-(-47.182)-(44.22)-(90.494));
clIoeOOMUYZmnVAR = (float) (-83.326-(36.424)-(-23.147)-(12.902)-(-79.676)-(-99.408));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-37.544-(92.609)-(78.784)-(62.329)-(98.703)-(5.234));
clIoeOOMUYZmnVAR = (float) (99.989-(21.499)-(32.013)-(77.825)-(-87.424)-(-66.039));
clIoeOOMUYZmnVAR = (float) (-49.896-(-16.962)-(-86.216)-(8.734)-(-12.874)-(-73.65));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-19.999-(-15.535)-(-0.523));
clIoeOOMUYZmnVAR = (float) (63.908-(45.961)-(-91.207)-(23.108)-(39.013)-(4.52));
clIoeOOMUYZmnVAR = (float) (-36.166-(-62.905)-(-44.934)-(62.955)-(2.996)-(-65.037));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (44.991-(-59.095)-(-7.349)-(-77.632)-(-16.526)-(72.071));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-26.169-(44.8)-(39.188)-(64.516)-(23.089)-(-3.085));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-69.232-(65.928)-(-81.974)-(65.437)-(57.567)-(-73.933));
clIoeOOMUYZmnVAR = (float) (-30.588-(48.348)-(-36.079)-(54.817)-(24.354)-(-55.435));
clIoeOOMUYZmnVAR = (float) (-31.881-(32.644)-(-81.035)-(57.629)-(-19.672)-(-32.934));
clIoeOOMUYZmnVAR = (float) (94.522-(-9.041)-(-23.755)-(-90.311)-(27.22)-(87.28));
clIoeOOMUYZmnVAR = (float) (-42.231-(-10.33)-(36.185)-(-71.526)-(48.68)-(74.578));
clIoeOOMUYZmnVAR = (float) (88.54-(71.57)-(46.266)-(-51.296)-(-42.368)-(-20.72));
tcb->m_cWnd = (int) (-4.748-(18.344)-(34.644));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-99.779-(94.94)-(-1.311)-(-32.05)-(-42.903)-(56.633));
clIoeOOMUYZmnVAR = (float) (-37.504-(37.581)-(95.27)-(-49.83)-(74.418)-(46.917));
clIoeOOMUYZmnVAR = (float) (-24.554-(-1.192)-(20.908)-(33.015)-(40.429)-(-43.035));
clIoeOOMUYZmnVAR = (float) (-55.42-(94.288)-(-57.332)-(-71.554)-(84.399)-(-13.098));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-92.356-(-62.826)-(38.497)-(70.373)-(19.699)-(44.858));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (2.828-(-55.586)-(-29.328));
clIoeOOMUYZmnVAR = (float) (-30.433-(-91.347)-(76.53)-(89.778)-(-5.592)-(72.634));
clIoeOOMUYZmnVAR = (float) (33.149-(-65.226)-(-34.132)-(15.396)-(46.881)-(79.902));
clIoeOOMUYZmnVAR = (float) (-97.95-(23.462)-(-34.676)-(-77.776)-(12.519)-(-80.694));
clIoeOOMUYZmnVAR = (float) (37.696-(14.13)-(-26.24)-(-26.029)-(20.406)-(36.697));
clIoeOOMUYZmnVAR = (float) (5.785-(94.499)-(-19.395)-(46.37)-(-93.478)-(-12.34));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-85.675-(68.442)-(4.094)-(32.618)-(61.767)-(1.947));
clIoeOOMUYZmnVAR = (float) (34.846-(17.185)-(60.385)-(40.691)-(65.5)-(38.421));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-75.95-(57.896)-(38.123)-(-45.35)-(-93.395)-(-17.443));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-22.717-(-60.327)-(65.276)-(71.89)-(-2.071)-(82.805));
clIoeOOMUYZmnVAR = (float) (-74.525-(56.525)-(-22.751)-(-42.861)-(19.269)-(-96.011));
clIoeOOMUYZmnVAR = (float) (-29.405-(-58.901)-(90.481)-(-79.173)-(-62.978)-(-61.348));
clIoeOOMUYZmnVAR = (float) (4.7-(-86.543)-(-4.615)-(-27.982)-(71.103)-(-45.228));
clIoeOOMUYZmnVAR = (float) (67.321-(-45.998)-(-40.417)-(-77.548)-(2.056)-(94.038));
tcb->m_cWnd = (int) (-47.796-(-69.005)-(-41.048));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-24.033-(-20.824)-(33.421)-(17.243)-(84.435)-(-48.057));
clIoeOOMUYZmnVAR = (float) (-32.519-(-18.589)-(90.154)-(-50.413)-(13.428)-(-15.898));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-38.587-(-79.624)-(19.254)-(-86.257)-(70.883)-(-15.972));
clIoeOOMUYZmnVAR = (float) (-18.867-(-49.596)-(-61.668)-(80.543)-(79.066)-(80.379));
clIoeOOMUYZmnVAR = (float) (-39.482-(-30.87)-(-73.233)-(66.502)-(53.488)-(4.838));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-15.902-(11.217)-(30.716)-(-23.83)-(47.291)-(32.064));
