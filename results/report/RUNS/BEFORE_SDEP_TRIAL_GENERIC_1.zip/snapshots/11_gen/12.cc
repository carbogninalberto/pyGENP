float clIoeOOMUYZmnVAR = (float) (2.498+(-17.974)+(-33.778));
int HIQwzIhphUEWjLJV = (int) ((82.437*(31.167)*(30.722)*(-21.275))/-34.875);
tcb->m_cWnd = (int) (-3.306-(-97.914)-(-23.451));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-80.514-(19.373)-(-92.858)-(-52.925)-(7.104)-(15.652));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (85.229-(-54.535)-(-99.229)-(-74.423)-(-76.319)-(-42.578));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (82.895-(67.438)-(70.041));
clIoeOOMUYZmnVAR = (float) (99.92-(83.417)-(-10.918)-(57.945)-(11.826)-(7.169));
clIoeOOMUYZmnVAR = (float) (-76.198-(98.752)-(-26.233)-(47.425)-(56.203)-(95.957));
clIoeOOMUYZmnVAR = (float) (-86.853-(21.177)-(46.366)-(33.967)-(97.685)-(37.207));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (56.103-(74.784)-(19.657));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (29.903-(-57.036)-(-23.963)-(98.329)-(87.404)-(-14.79));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (73.324-(10.356)-(-85.73)-(5.051)-(90.464)-(-31.013));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-9.758-(5.555)-(-4.191)-(45.446)-(26.233)-(-30.513));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (30.594-(-49.723)-(82.704)-(39.751)-(-69.601)-(-88.755));
clIoeOOMUYZmnVAR = (float) (5.192-(16.477)-(72.4)-(-51.941)-(0.038)-(-69.722));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-68.52-(32.632)-(-7.611)-(-84.83)-(-83.03)-(92.671));
clIoeOOMUYZmnVAR = (float) (-14.435-(-22.3)-(79.495)-(-97.477)-(41.194)-(-58.603));
tcb->m_cWnd = (int) (-23.043-(-99.329)-(85.105));
clIoeOOMUYZmnVAR = (float) (34.781-(16.824)-(-54.49)-(-44.23)-(-54.282)-(31.04));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-54.529-(37.389)-(18.603)-(-15.96)-(-35.896)-(62.862));
clIoeOOMUYZmnVAR = (float) (35.721-(-66.285)-(74.499)-(-39.094)-(89.113)-(18.26));
clIoeOOMUYZmnVAR = (float) (-70.488-(-85.704)-(46.768)-(-73.184)-(-94.585)-(-35.123));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (62.356-(-25.647)-(-48.514)-(40.259)-(-18.851)-(-83.524));
