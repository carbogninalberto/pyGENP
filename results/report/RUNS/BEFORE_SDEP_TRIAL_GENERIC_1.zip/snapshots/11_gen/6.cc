float clIoeOOMUYZmnVAR = (float) (32.238+(38.356)+(26.555));
int HIQwzIhphUEWjLJV = (int) ((-14.62*(-64.698)*(-89.357)*(48.986))/-57.181);
tcb->m_cWnd = (int) (84.524-(63.823)-(84.33));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-84.406-(0.622)-(-15.058)-(53.648)-(-51.673)-(16.867));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (71.298-(14.375)-(-93.989)-(91.08)-(35.053)-(-10.204));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-10.598-(21.367)-(90.264));
clIoeOOMUYZmnVAR = (float) (25.42-(-5.547)-(49.18)-(-82.761)-(-38.756)-(-51.834));
clIoeOOMUYZmnVAR = (float) (74.453-(40.408)-(-48.991)-(2.956)-(-72.752)-(-74.089));
clIoeOOMUYZmnVAR = (float) (26.997-(31.088)-(41.257)-(74.246)-(6.057)-(-95.165));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-24.532-(-19.677)-(-83.761));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (96.003-(7.4)-(28.428)-(10.43)-(-27.089)-(-69.043));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-25.822-(-88.538)-(35.465)-(23.502)-(12.303)-(15.796));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-45.207-(47.93)-(-42.296)-(89.321)-(-60.908)-(-12.398));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (53.033-(90.12)-(11.162)-(39.515)-(-58.84)-(94.299));
clIoeOOMUYZmnVAR = (float) (-22.194-(0.247)-(-96.979)-(-95.394)-(8.412)-(-15.523));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-45.217-(-97.687)-(73.563)-(-41.8)-(3.508)-(21.744));
clIoeOOMUYZmnVAR = (float) (19.848-(93.932)-(-6.88)-(16.917)-(3.404)-(-26.495));
clIoeOOMUYZmnVAR = (float) (-89.997-(-25.464)-(8.703)-(78.178)-(7.177)-(-76.092));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (12.019-(77.507)-(-72.46));
clIoeOOMUYZmnVAR = (float) (-57.434-(-29.057)-(-37.0)-(-67.992)-(-11.946)-(-70.057));
clIoeOOMUYZmnVAR = (float) (-60.697-(17.665)-(-45.444)-(29.191)-(70.884)-(-71.853));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (88.861-(-91.411)-(51.765)-(-0.392)-(21.772)-(-43.641));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (17.495-(-83.864)-(-19.045)-(-92.748)-(1.117)-(18.299));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (51.894-(-97.609)-(5.693)-(10.46)-(48.658)-(-18.329));
clIoeOOMUYZmnVAR = (float) (-45.209-(48.871)-(10.088)-(13.795)-(25.661)-(-14.0));
clIoeOOMUYZmnVAR = (float) (42.849-(-7.772)-(-44.382)-(-60.305)-(-60.792)-(-75.935));
clIoeOOMUYZmnVAR = (float) (27.832-(-85.212)-(-79.382)-(37.746)-(-13.849)-(-64.305));
clIoeOOMUYZmnVAR = (float) (64.938-(98.142)-(-99.962)-(-79.896)-(-19.545)-(-16.437));
clIoeOOMUYZmnVAR = (float) (90.779-(-48.445)-(-84.792)-(76.033)-(-38.347)-(54.034));
tcb->m_cWnd = (int) (92.212-(-79.068)-(25.333));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (40.307-(-48.0)-(-75.004)-(-2.343)-(-47.747)-(-23.339));
clIoeOOMUYZmnVAR = (float) (-94.198-(-9.998)-(6.258)-(-22.782)-(-41.734)-(47.621));
clIoeOOMUYZmnVAR = (float) (-65.981-(-79.38)-(62.113)-(64.332)-(96.482)-(34.711));
clIoeOOMUYZmnVAR = (float) (-2.678-(-61.567)-(22.963)-(-71.15)-(-50.545)-(46.952));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (39.718-(45.417)-(-44.921)-(-93.515)-(-71.888)-(-52.905));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-31.101-(-39.623)-(-95.674));
clIoeOOMUYZmnVAR = (float) (72.072-(-69.806)-(61.507)-(88.349)-(66.123)-(-50.807));
clIoeOOMUYZmnVAR = (float) (54.811-(41.932)-(-20.276)-(61.838)-(91.499)-(86.647));
clIoeOOMUYZmnVAR = (float) (-99.131-(-97.855)-(-26.57)-(-68.405)-(95.504)-(58.202));
clIoeOOMUYZmnVAR = (float) (-13.186-(68.995)-(8.51)-(89.789)-(-39.744)-(16.291));
clIoeOOMUYZmnVAR = (float) (-88.824-(-90.083)-(86.519)-(37.727)-(99.426)-(63.992));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-8.627-(7.615)-(52.086)-(31.012)-(-3.492)-(40.186));
clIoeOOMUYZmnVAR = (float) (-44.833-(-56.301)-(-89.776)-(14.631)-(-52.953)-(95.716));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (31.909-(-61.188)-(2.112)-(-24.591)-(-78.713)-(64.307));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (74.319-(-94.361)-(73.09)-(-15.187)-(45.787)-(-32.748));
clIoeOOMUYZmnVAR = (float) (18.879-(-9.998)-(-33.717)-(-94.128)-(-90.942)-(45.705));
clIoeOOMUYZmnVAR = (float) (77.778-(87.849)-(42.279)-(8.696)-(-84.128)-(14.13));
clIoeOOMUYZmnVAR = (float) (-47.683-(-20.675)-(-76.078)-(-88.158)-(-90.272)-(-87.635));
clIoeOOMUYZmnVAR = (float) (45.444-(4.623)-(50.73)-(40.237)-(80.718)-(15.772));
tcb->m_cWnd = (int) (25.125-(-95.698)-(-29.262));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-92.626-(45.437)-(69.647)-(-1.949)-(15.141)-(-95.964));
clIoeOOMUYZmnVAR = (float) (-10.964-(-71.596)-(78.668)-(13.732)-(53.249)-(-64.977));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-30.296-(24.096)-(3.808)-(-29.867)-(65.609)-(-75.558));
clIoeOOMUYZmnVAR = (float) (-36.957-(-94.552)-(-1.398)-(-50.559)-(-0.956)-(-52.278));
clIoeOOMUYZmnVAR = (float) (98.828-(-27.744)-(-81.432)-(-82.287)-(56.737)-(0.521));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-43.195-(-13.298)-(-80.573)-(-95.816)-(64.107)-(-16.145));
