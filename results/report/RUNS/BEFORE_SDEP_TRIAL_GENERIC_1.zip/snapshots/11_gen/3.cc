float clIoeOOMUYZmnVAR = (float) (32.004+(80.105)+(-40.523));
int HIQwzIhphUEWjLJV = (int) ((-44.719*(73.896)*(-67.302)*(62.867))/-82.131);
tcb->m_cWnd = (int) (-87.181-(-44.138)-(82.637));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-91.253-(-28.654)-(-59.533)-(48.131)-(25.096)-(59.813));
clIoeOOMUYZmnVAR = (float) (-25.352-(-87.877)-(-78.182)-(-21.282)-(-0.149)-(43.201));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-38.199-(-78.53)-(16.627)-(-85.256)-(-2.798)-(-11.562));
clIoeOOMUYZmnVAR = (float) (90.345-(-86.813)-(-28.736)-(34.781)-(-9.622)-(38.545));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (92.936-(-86.825)-(-62.864));
tcb->m_cWnd = (int) (-28.089-(-66.029)-(-3.949));
clIoeOOMUYZmnVAR = (float) (-14.426-(-67.835)-(-10.26)-(-47.166)-(57.895)-(-36.678));
clIoeOOMUYZmnVAR = (float) (48.041-(84.04)-(-27.558)-(-61.404)-(86.971)-(38.019));
clIoeOOMUYZmnVAR = (float) (-30.126-(65.552)-(60.046)-(-58.028)-(40.821)-(-15.042));
clIoeOOMUYZmnVAR = (float) (-7.47-(-90.85)-(-62.923)-(95.47)-(59.862)-(-50.83));
clIoeOOMUYZmnVAR = (float) (-97.143-(-13.84)-(-62.687)-(-28.171)-(-25.246)-(22.823));
clIoeOOMUYZmnVAR = (float) (-61.522-(-94.38)-(17.316)-(82.612)-(-39.16)-(5.943));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-69.64-(67.315)-(-88.325));
tcb->m_cWnd = (int) (50.678-(30.902)-(27.849));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-36.485-(50.881)-(74.036)-(76.934)-(-95.252)-(-49.716));
clIoeOOMUYZmnVAR = (float) (-89.645-(-21.757)-(-8.602)-(-12.463)-(49.855)-(41.503));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-35.662-(-69.031)-(-48.759)-(-80.813)-(70.812)-(-10.271));
clIoeOOMUYZmnVAR = (float) (84.408-(16.492)-(6.02)-(-32.926)-(70.499)-(29.662));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-97.367-(92.937)-(91.344)-(-58.45)-(-8.25)-(-76.878));
clIoeOOMUYZmnVAR = (float) (-6.313-(-12.924)-(44.403)-(32.918)-(76.244)-(27.149));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (26.987-(-15.056)-(90.657)-(-93.751)-(18.966)-(81.368));
clIoeOOMUYZmnVAR = (float) (41.206-(0.86)-(82.583)-(83.354)-(-84.219)-(-67.576));
clIoeOOMUYZmnVAR = (float) (18.595-(-0.354)-(48.024)-(-91.753)-(12.329)-(-2.209));
clIoeOOMUYZmnVAR = (float) (41.055-(-2.323)-(14.287)-(-23.859)-(-25.764)-(9.738));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-89.965-(10.383)-(58.25)-(-63.224)-(-0.002)-(-37.865));
clIoeOOMUYZmnVAR = (float) (51.488-(-5.645)-(-88.137)-(36.745)-(-16.732)-(11.473));
clIoeOOMUYZmnVAR = (float) (-40.021-(-95.187)-(-38.066)-(-19.611)-(-51.649)-(-40.276));
clIoeOOMUYZmnVAR = (float) (17.288-(-51.808)-(63.3)-(-90.365)-(41.787)-(-99.907));
tcb->m_cWnd = (int) (44.415-(-60.537)-(61.223));
tcb->m_cWnd = (int) (60.894-(-32.312)-(80.197));
clIoeOOMUYZmnVAR = (float) (-12.648-(38.118)-(37.834)-(-42.499)-(55.101)-(12.174));
clIoeOOMUYZmnVAR = (float) (-92.119-(97.596)-(-77.656)-(65.865)-(62.792)-(-65.221));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (87.928-(-87.838)-(29.727)-(65.708)-(-71.898)-(-13.745));
clIoeOOMUYZmnVAR = (float) (-73.345-(47.768)-(-46.581)-(-38.084)-(66.214)-(18.445));
clIoeOOMUYZmnVAR = (float) (-48.139-(94.571)-(6.974)-(-3.478)-(14.313)-(-44.285));
clIoeOOMUYZmnVAR = (float) (-85.347-(-19.409)-(98.348)-(-75.244)-(-5.744)-(-8.468));
clIoeOOMUYZmnVAR = (float) (-37.336-(48.074)-(-19.326)-(-84.3)-(72.228)-(11.81));
clIoeOOMUYZmnVAR = (float) (73.54-(-89.602)-(-26.807)-(-67.451)-(67.601)-(11.04));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-42.809-(-31.21)-(98.302)-(66.314)-(52.469)-(90.163));
clIoeOOMUYZmnVAR = (float) (21.224-(66.551)-(56.504)-(49.439)-(-77.91)-(70.832));
