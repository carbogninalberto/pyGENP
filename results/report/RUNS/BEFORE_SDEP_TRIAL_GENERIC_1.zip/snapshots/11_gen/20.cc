int HIQwzIhphUEWjLJV = (int) ((7.727*(6.94)*(97.406)*(94.302))/-14.856);
tcb->m_cWnd = (int) (-6.843-(52.174)-(14.85));
float clIoeOOMUYZmnVAR = (float) (53.515+(60.064)+(-45.842));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (96.694-(20.27)-(-81.81));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-7.621-(92.15)-(-63.832)-(-86.399)-(-43.79)-(64.686));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (8.348-(-69.714)-(11.85)-(-7.804)-(20.472)-(99.212));
tcb->m_cWnd = (int) (-90.964-(95.407)-(64.594));
clIoeOOMUYZmnVAR = (float) (-47.012-(24.378)-(-57.552)-(59.323)-(-66.564)-(4.697));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-27.076-(41.631)-(58.256)-(-0.672)-(-20.797)-(-72.9));
clIoeOOMUYZmnVAR = (float) (41.821-(-76.299)-(3.755)-(-81.994)-(-74.568)-(24.104));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-97.973-(59.08)-(68.305));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (81.661-(-34.357)-(-72.453)-(29.835)-(82.608)-(54.116));
tcb->m_cWnd = (int) (63.356-(-32.363)-(-51.049));
clIoeOOMUYZmnVAR = (float) (-26.086-(89.799)-(-53.399)-(-98.636)-(5.252)-(-68.812));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-58.213-(7.29)-(-38.007)-(-71.571)-(84.062)-(-80.94));
clIoeOOMUYZmnVAR = (float) (67.92-(-51.181)-(-17.236)-(3.169)-(-92.138)-(95.532));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (57.867-(46.777)-(-49.96)-(-72.558)-(82.261)-(-81.167));
tcb->m_cWnd = (int) (-67.998-(17.031)-(-55.066));
clIoeOOMUYZmnVAR = (float) (-71.972-(-82.615)-(-62.559)-(35.136)-(99.968)-(-80.39));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-98.223-(6.264)-(-72.881)-(-56.804)-(-81.194)-(-52.711));
clIoeOOMUYZmnVAR = (float) (-56.67-(48.886)-(51.074)-(85.037)-(-14.122)-(-38.513));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-81.526-(57.37)-(28.733)-(-84.32)-(-54.571)-(11.395));
clIoeOOMUYZmnVAR = (float) (-64.141-(45.264)-(74.861)-(68.029)-(84.189)-(65.657));
tcb->m_cWnd = (int) (32.064-(-37.579)-(7.756));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-88.39-(85.607)-(26.72)-(-17.522)-(-25.905)-(59.314));
tcb->m_cWnd = (int) (31.293-(-56.399)-(-75.384));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (84.495-(-56.102)-(-54.257)-(64.068)-(0.964)-(-9.369));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-26.904-(17.598)-(89.765)-(-13.396)-(-51.982)-(-87.714));
tcb->m_cWnd = (int) (-40.336-(-64.706)-(43.909));
clIoeOOMUYZmnVAR = (float) (-59.999-(14.333)-(-89.925)-(-20.964)-(25.213)-(53.355));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-51.076-(-56.477)-(-1.155)-(63.192)-(-0.737)-(-3.127));
clIoeOOMUYZmnVAR = (float) (-43.273-(43.841)-(49.349)-(-74.374)-(2.119)-(74.386));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-48.055-(6.534)-(71.166));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (83.114-(30.616)-(-48.296)-(-78.642)-(56.321)-(-15.001));
tcb->m_cWnd = (int) (-68.667-(7.108)-(-58.313));
clIoeOOMUYZmnVAR = (float) (-24.54-(-77.981)-(-88.675)-(-41.869)-(-2.387)-(71.002));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (41.752-(-43.357)-(41.519)-(79.94)-(-62.047)-(52.779));
clIoeOOMUYZmnVAR = (float) (54.017-(16.811)-(-4.499)-(-58.192)-(-5.172)-(-84.175));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (79.61-(83.81)-(30.348)-(-49.368)-(18.797)-(-99.124));
tcb->m_cWnd = (int) (-20.987-(72.665)-(58.953));
clIoeOOMUYZmnVAR = (float) (-0.797-(-99.987)-(45.408)-(46.968)-(72.515)-(-89.244));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-48.181-(-27.864)-(76.069)-(38.721)-(70.735)-(51.698));
clIoeOOMUYZmnVAR = (float) (74.075-(68.514)-(50.892)-(-39.105)-(85.17)-(-76.665));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-11.282-(-55.536)-(-84.536)-(19.939)-(-13.994)-(41.082));
clIoeOOMUYZmnVAR = (float) (47.102-(-77.832)-(-57.568)-(93.864)-(56.08)-(13.396));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-91.914-(-22.682)-(-3.492)-(29.791)-(38.043)-(82.241));
