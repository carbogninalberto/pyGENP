float clIoeOOMUYZmnVAR = (float) (54.563+(-64.894)+(87.564));
int HIQwzIhphUEWjLJV = (int) ((49.185*(16.618)*(90.732)*(3.296))/63.289);
tcb->m_cWnd = (int) (38.255-(-14.041)-(1.886));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-26.565-(-92.372)-(-4.951)-(-87.298)-(67.241)-(95.412));
clIoeOOMUYZmnVAR = (float) (-79.148-(69.06)-(-67.948)-(-17.928)-(72.354)-(-91.064));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-85.079-(-73.266)-(-6.189)-(-0.106)-(16.997)-(-60.711));
clIoeOOMUYZmnVAR = (float) (46.17-(-67.963)-(43.67)-(-20.71)-(72.832)-(50.335));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-49.092-(22.535)-(-37.642));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (90.681-(61.337)-(83.211));
clIoeOOMUYZmnVAR = (float) (-2.894-(-24.078)-(-95.873)-(8.139)-(72.698)-(95.073));
clIoeOOMUYZmnVAR = (float) (-69.643-(18.952)-(-69.334)-(-84.969)-(-44.729)-(21.045));
clIoeOOMUYZmnVAR = (float) (-90.819-(76.971)-(90.805)-(-82.451)-(-86.671)-(84.312));
clIoeOOMUYZmnVAR = (float) (-67.639-(8.872)-(53.504)-(-95.628)-(70.907)-(2.791));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-41.457-(39.71)-(79.107)-(80.342)-(-84.821)-(-39.815));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-71.346-(-52.945)-(42.596)-(-21.982)-(22.957)-(37.342));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-56.816-(27.457)-(-28.829)-(2.743)-(21.486)-(-85.186));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-21.16-(-34.482)-(35.767)-(-84.648)-(-92.582)-(45.339));
clIoeOOMUYZmnVAR = (float) (6.419-(-99.161)-(-84.267)-(4.649)-(-67.486)-(14.704));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (91.958-(7.923)-(-48.293)-(34.689)-(31.334)-(-5.524));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (86.07-(-49.653)-(-97.63));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (77.026-(-87.52)-(3.333));
clIoeOOMUYZmnVAR = (float) (-4.901-(98.03)-(-38.926)-(12.889)-(-82.48)-(-30.89));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-92.176-(-57.849)-(-81.198)-(80.76)-(-81.48)-(45.775));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-66.167-(-63.03)-(9.028)-(-25.41)-(-83.368)-(-98.881));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (84.758-(55.585)-(57.688)-(54.875)-(-21.705)-(-3.791));
clIoeOOMUYZmnVAR = (float) (35.969-(-18.586)-(47.864)-(65.095)-(-74.787)-(2.665));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (69.939-(12.168)-(63.134)-(-87.699)-(-98.81)-(-67.253));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (47.036-(81.261)-(85.734)-(-56.058)-(33.986)-(-23.536));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (29.521-(36.311)-(21.086)-(30.198)-(38.797)-(84.844));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (88.703-(-83.443)-(-63.571)-(7.543)-(9.797)-(72.885));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (67.821-(-68.678)-(49.595)-(41.32)-(79.76)-(-57.137));
clIoeOOMUYZmnVAR = (float) (93.188-(-33.499)-(95.128)-(-0.802)-(-70.738)-(-14.388));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (92.198-(90.182)-(21.482)-(77.511)-(66.801)-(2.087));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-71.011-(13.823)-(-20.398)-(52.256)-(-45.649)-(-22.32));
clIoeOOMUYZmnVAR = (float) (77.456-(47.162)-(-24.505)-(16.088)-(27.56)-(29.17));
clIoeOOMUYZmnVAR = (float) (-2.59-(95.545)-(47.249)-(8.556)-(48.031)-(-91.323));
clIoeOOMUYZmnVAR = (float) (-78.796-(49.486)-(-1.742)-(-16.818)-(28.296)-(35.774));
tcb->m_cWnd = (int) (-86.948-(-35.472)-(59.977));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-62.849-(-65.124)-(-20.815));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (19.295-(84.582)-(-7.097)-(-49.022)-(-11.039)-(7.276));
clIoeOOMUYZmnVAR = (float) (-91.156-(-97.507)-(12.905)-(-94.666)-(-9.247)-(20.617));
clIoeOOMUYZmnVAR = (float) (45.781-(-12.773)-(-59.059)-(41.213)-(55.534)-(47.978));
clIoeOOMUYZmnVAR = (float) (49.371-(20.231)-(-30.174)-(85.79)-(-48.865)-(-1.489));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (1.515-(-81.741)-(-14.847)-(59.168)-(1.501)-(58.181));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-88.859-(-90.729)-(61.083)-(-69.26)-(1.731)-(-98.643));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-8.756-(18.934)-(67.481)-(94.518)-(89.07)-(69.783));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (1.113-(-32.562)-(84.984)-(24.01)-(-68.959)-(86.099));
clIoeOOMUYZmnVAR = (float) (26.835-(9.282)-(-95.35)-(-39.672)-(-11.453)-(-69.408));
clIoeOOMUYZmnVAR = (float) (7.812-(50.569)-(8.178)-(-47.23)-(67.743)-(-28.955));
clIoeOOMUYZmnVAR = (float) (-30.518-(52.077)-(89.292)-(38.09)-(20.792)-(-90.023));
clIoeOOMUYZmnVAR = (float) (61.329-(-12.347)-(-13.095)-(-78.834)-(-96.853)-(73.886));
clIoeOOMUYZmnVAR = (float) (-8.324-(-69.591)-(-73.549)-(84.422)-(53.304)-(-70.486));
tcb->m_cWnd = (int) (99.351-(34.965)-(35.263));
clIoeOOMUYZmnVAR = (float) (-51.804-(78.005)-(96.572)-(-79.497)-(-28.639)-(-18.631));
tcb->m_cWnd = (int) (80.097-(-6.656)-(-71.865));
clIoeOOMUYZmnVAR = (float) (-69.445-(-83.062)-(-41.98)-(-28.582)-(26.892)-(34.421));
clIoeOOMUYZmnVAR = (float) (40.355-(-82.719)-(-92.338)-(-75.273)-(-43.421)-(23.013));
clIoeOOMUYZmnVAR = (float) (-4.42-(-71.104)-(-83.013)-(-10.453)-(96.361)-(17.994));
clIoeOOMUYZmnVAR = (float) (42.181-(47.183)-(14.072)-(56.748)-(76.96)-(-9.993));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-17.838-(76.069)-(-37.47)-(-83.578)-(-55.466)-(65.111));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-15.852-(-15.687)-(-49.715)-(-26.186)-(97.556)-(-47.536));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-35.603-(83.38)-(-74.594)-(-94.327)-(20.674)-(32.48));
clIoeOOMUYZmnVAR = (float) (-11.319-(-55.715)-(-32.5)-(-13.197)-(-8.01)-(32.873));
clIoeOOMUYZmnVAR = (float) (37.345-(59.406)-(-46.19)-(-15.38)-(-70.871)-(-24.153));
clIoeOOMUYZmnVAR = (float) (80.597-(5.764)-(93.398)-(14.292)-(4.851)-(-21.791));
clIoeOOMUYZmnVAR = (float) (-52.174-(30.073)-(72.748)-(17.708)-(-87.346)-(-11.809));
clIoeOOMUYZmnVAR = (float) (-47.907-(16.733)-(-0.416)-(59.995)-(-94.132)-(-99.391));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-86.144-(67.564)-(8.183)-(15.665)-(-7.56)-(35.697));
clIoeOOMUYZmnVAR = (float) (-56.645-(50.825)-(-14.648)-(49.464)-(-76.089)-(79.453));
