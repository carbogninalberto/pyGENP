float clIoeOOMUYZmnVAR = (float) (-71.768+(-77.377)+(-53.716));
int HIQwzIhphUEWjLJV = (int) ((-33.19*(14.941)*(94.804)*(66.69))/21.028);
tcb->m_cWnd = (int) (1.995-(-62.755)-(-33.908));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (12.886-(62.891)-(-45.071)-(33.554)-(-60.648)-(-10.203));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (79.874-(-14.363)-(-64.44)-(42.438)-(11.624)-(29.485));
clIoeOOMUYZmnVAR = (float) (-5.774-(-58.121)-(-42.203)-(36.496)-(-87.668)-(16.413));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (74.27-(-7.524)-(32.791)-(-12.904)-(-51.06)-(55.889));
clIoeOOMUYZmnVAR = (float) (97.993-(43.085)-(91.869)-(75.579)-(-49.898)-(1.334));
clIoeOOMUYZmnVAR = (float) (-80.21-(26.577)-(-6.835)-(-96.738)-(12.935)-(-1.325));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (95.535-(91.71)-(-19.195));
tcb->m_cWnd = (int) (-47.46-(-49.098)-(-50.475));
clIoeOOMUYZmnVAR = (float) (-23.571-(-82.022)-(94.559)-(-79.443)-(-93.518)-(-98.369));
clIoeOOMUYZmnVAR = (float) (62.405-(-49.665)-(21.11)-(-37.33)-(-88.587)-(-56.684));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-69.008-(68.219)-(27.228)-(-63.265)-(18.72)-(-36.525));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-98.251-(-94.977)-(-28.039)-(-14.628)-(-51.632)-(-86.401));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (67.256-(-66.171)-(-49.864)-(-6.471)-(1.697)-(54.462));
tcb->m_cWnd = (int) (-65.167-(60.367)-(-92.801));
clIoeOOMUYZmnVAR = (float) (2.035-(44.629)-(50.666)-(-38.806)-(70.186)-(-50.372));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-57.554-(-67.608)-(38.437)-(-65.906)-(-68.664)-(15.882));
clIoeOOMUYZmnVAR = (float) (-8.32-(32.256)-(12.635)-(-97.176)-(64.138)-(-35.028));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (50.867-(67.344)-(54.5)-(59.072)-(-58.853)-(-71.69));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-36.163-(9.606)-(75.765)-(-31.863)-(-78.825)-(93.419));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-31.865-(79.392)-(-39.496)-(73.453)-(18.732)-(36.534));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-23.408-(-43.92)-(0.613)-(38.056)-(-85.603)-(-50.388));
clIoeOOMUYZmnVAR = (float) (99.497-(4.818)-(-23.114)-(-84.064)-(16.722)-(23.321));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-25.166-(-15.212)-(59.152)-(-91.855)-(-57.709)-(-60.051));
clIoeOOMUYZmnVAR = (float) (50.43-(2.595)-(-59.482)-(50.446)-(-76.164)-(33.149));
tcb->m_cWnd = (int) (-84.191-(-38.684)-(87.554));
clIoeOOMUYZmnVAR = (float) (-14.251-(53.741)-(-77.653)-(43.117)-(74.013)-(25.404));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (62.056-(-21.363)-(51.586)-(32.007)-(-17.353)-(87.503));
clIoeOOMUYZmnVAR = (float) (-28.414-(-16.019)-(-24.9)-(66.835)-(29.94)-(67.922));
clIoeOOMUYZmnVAR = (float) (-52.299-(-10.23)-(-26.84)-(-54.878)-(-44.33)-(-6.438));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-21.536-(-5.454)-(57.259)-(-81.353)-(81.075)-(32.364));
