int HIQwzIhphUEWjLJV = (int) ((-41.52*(87.991)*(48.698)*(-97.727))/18.892);
tcb->m_cWnd = (int) (88.06-(77.312)-(-77.92));
float clIoeOOMUYZmnVAR = (float) (-60.283+(14.17)+(99.377));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-30.851-(1.016)-(-78.725));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (87.956-(55.546)-(58.013)-(-75.356)-(89.109)-(-66.548));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (23.53-(96.635)-(-43.036)-(80.122)-(65.384)-(90.851));
tcb->m_cWnd = (int) (80.127-(-57.441)-(-8.918));
clIoeOOMUYZmnVAR = (float) (-22.353-(13.45)-(-50.577)-(-17.073)-(-67.326)-(72.934));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (10.696-(0.251)-(-89.399)-(-7.158)-(-29.886)-(-10.364));
clIoeOOMUYZmnVAR = (float) (-37.53-(-40.027)-(-44.425)-(9.597)-(-36.448)-(43.861));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (21.244-(71.002)-(-33.388));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (47.481-(51.081)-(87.692)-(93.096)-(-75.671)-(69.826));
tcb->m_cWnd = (int) (-51.26-(8.774)-(-45.213));
clIoeOOMUYZmnVAR = (float) (18.907-(62.848)-(-37.501)-(22.83)-(45.92)-(-18.037));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-73.489-(-84.686)-(88.345)-(3.373)-(-9.939)-(89.969));
clIoeOOMUYZmnVAR = (float) (-93.625-(-22.514)-(-23.99)-(15.526)-(90.46)-(38.723));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-87.39-(-62.03)-(35.103)-(45.319)-(-48.881)-(53.188));
tcb->m_cWnd = (int) (-67.306-(-95.198)-(-21.113));
clIoeOOMUYZmnVAR = (float) (-66.957-(28.179)-(68.629)-(23.23)-(-47.012)-(75.12));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-95.544-(14.94)-(1.744)-(20.599)-(33.508)-(-0.399));
clIoeOOMUYZmnVAR = (float) (4.715-(-30.856)-(92.809)-(-63.426)-(99.578)-(21.419));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-30.291-(69.779)-(1.269)-(-31.147)-(-47.137)-(26.759));
clIoeOOMUYZmnVAR = (float) (-57.441-(-82.614)-(72.874)-(23.154)-(33.19)-(58.725));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (81.082-(-2.532)-(-17.984)-(-97.402)-(88.741)-(7.95));
