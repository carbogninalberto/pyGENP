int HIQwzIhphUEWjLJV = (int) ((-50.616*(-28.497)*(38.887)*(62.383))/71.646);
float clIoeOOMUYZmnVAR = (float) (-62.348+(87.662)+(-31.938));
tcb->m_cWnd = (int) (27.816-(-41.437)-(-31.403));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-46.916-(12.72)-(-45.878)-(-39.049)-(-80.548)-(-97.195));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (32.055-(69.975)-(91.734)-(-88.679)-(38.404)-(-87.57));
clIoeOOMUYZmnVAR = (float) (-52.169-(45.59)-(-45.459)-(8.38)-(57.561)-(53.312));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-94.905-(-57.675)-(57.458)-(69.792)-(29.345)-(96.635));
clIoeOOMUYZmnVAR = (float) (68.655-(-83.42)-(-62.733)-(60.254)-(-39.152)-(-6.962));
clIoeOOMUYZmnVAR = (float) (-49.458-(-92.203)-(-6.261)-(-21.673)-(-84.435)-(-2.096));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (69.096-(-75.092)-(-59.482)-(-96.437)-(27.887)-(13.883));
clIoeOOMUYZmnVAR = (float) (-96.832-(76.62)-(81.757)-(-95.644)-(-55.863)-(-47.594));
clIoeOOMUYZmnVAR = (float) (-28.196-(82.387)-(-3.359)-(-86.055)-(42.918)-(-74.77));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (67.998-(-9.57)-(-8.204)-(-46.947)-(64.171)-(2.849));
clIoeOOMUYZmnVAR = (float) (-29.93-(13.385)-(49.968)-(-6.157)-(49.949)-(-85.149));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-72.423-(51.036)-(76.758));
clIoeOOMUYZmnVAR = (float) (-3.599-(-64.871)-(-44.79)-(20.122)-(74.433)-(-52.553));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-33.957-(7.324)-(-11.624)-(-46.538)-(-28.483)-(91.967));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (86.405-(-82.324)-(74.269)-(-84.217)-(37.853)-(36.051));
clIoeOOMUYZmnVAR = (float) (97.359-(20.188)-(-29.379)-(-61.873)-(83.294)-(-35.55));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (15.405-(45.89)-(-52.488)-(-84.245)-(-68.712)-(24.142));
clIoeOOMUYZmnVAR = (float) (-50.481-(1.084)-(35.82)-(-26.339)-(20.015)-(12.468));
clIoeOOMUYZmnVAR = (float) (55.936-(8.384)-(-61.34)-(43.975)-(45.439)-(44.123));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (71.414-(87.252)-(-14.976)-(63.406)-(-37.546)-(-86.283));
clIoeOOMUYZmnVAR = (float) (-27.923-(44.633)-(-61.118)-(-23.149)-(-99.335)-(57.705));
clIoeOOMUYZmnVAR = (float) (3.68-(43.858)-(-91.659)-(42.161)-(90.666)-(58.678));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (83.333-(-52.821)-(-31.62)-(33.388)-(-51.378)-(74.563));
clIoeOOMUYZmnVAR = (float) (-64.411-(-44.801)-(-81.436)-(65.851)-(-68.265)-(47.586));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-89.899-(34.257)-(-21.756)-(67.775)-(-45.669)-(-62.561));
