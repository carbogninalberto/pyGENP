int HIQwzIhphUEWjLJV = (int) ((-61.115*(99.617)*(73.529)*(-15.28))/3.643);
float clIoeOOMUYZmnVAR = (float) (80.47+(-54.862)+(47.017));
tcb->m_cWnd = (int) (-85.319-(-25.665)-(59.924));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-2.458-(-40.33)-(-72.029)-(94.26)-(-69.596)-(32.886));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (26.836-(-46.999)-(-28.576)-(17.728)-(-16.612)-(50.755));
clIoeOOMUYZmnVAR = (float) (-8.06-(-86.474)-(81.773)-(55.428)-(-90.66)-(-15.468));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (46.025-(-94.128)-(85.271)-(-48.517)-(-80.017)-(46.002));
clIoeOOMUYZmnVAR = (float) (93.49-(-66.716)-(-73.995)-(-14.33)-(-93.619)-(-59.956));
clIoeOOMUYZmnVAR = (float) (4.401-(48.131)-(3.328)-(-28.665)-(21.652)-(-3.206));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (25.246-(42.504)-(-73.159)-(-13.567)-(-54.416)-(73.313));
clIoeOOMUYZmnVAR = (float) (-14.325-(20.377)-(14.1)-(-75.81)-(25.372)-(7.721));
clIoeOOMUYZmnVAR = (float) (-47.078-(70.341)-(-90.81)-(-53.92)-(-10.901)-(-7.843));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-94.636-(-2.946)-(10.107)-(-5.658)-(-4.312)-(-7.418));
clIoeOOMUYZmnVAR = (float) (-11.452-(42.879)-(-19.139)-(-76.112)-(57.434)-(-99.247));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (5.429-(-9.004)-(18.815)-(-98.283)-(91.881)-(-24.868));
