tcb->m_cWnd = (int) (87.405-(-76.862)-(13.013));
float clIoeOOMUYZmnVAR = (float) (62.348+(-47.066)+(-56.385));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
int HIQwzIhphUEWjLJV = (int) ((-39.497*(-22.058)*(-13.33)*(-26.021))/-39.575);
clIoeOOMUYZmnVAR = (float) (37.764-(-82.307)-(-21.984)-(-91.21)-(72.299)-(-87.717));
clIoeOOMUYZmnVAR = (float) (41.473-(-59.153)-(97.785)-(28.333)-(-83.05)-(-94.641));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (81.286-(3.418)-(30.671)-(-27.259)-(57.925)-(30.452));
clIoeOOMUYZmnVAR = (float) (-80.98-(71.323)-(-93.626)-(-90.853)-(90.52)-(-63.802));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (58.43-(-41.775)-(-58.847)-(52.748)-(-3.473)-(87.796));
clIoeOOMUYZmnVAR = (float) (-45.64-(-57.521)-(48.004)-(44.904)-(-0.69)-(81.716));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-96.269-(78.336)-(-48.694)-(-13.636)-(-28.848)-(-82.957));
