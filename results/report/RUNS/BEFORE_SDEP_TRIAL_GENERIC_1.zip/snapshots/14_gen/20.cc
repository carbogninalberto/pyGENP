float clIoeOOMUYZmnVAR = (float) (-13.874+(45.704)+(-9.067));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-27.151-(56.595)-(11.38));
clIoeOOMUYZmnVAR = (float) (16.844-(-97.086)-(-94.234)-(0.987)-(-0.072)-(61.104));
int HIQwzIhphUEWjLJV = (int) ((-56.603*(-36.946)*(-93.256)*(89.157))/-84.474);
clIoeOOMUYZmnVAR = (float) (10.798-(54.723)-(49.279)-(47.239)-(73.39)-(42.444));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-35.068-(-23.853)-(-81.977));
clIoeOOMUYZmnVAR = (float) (-19.604-(56.796)-(-97.579)-(-3.926)-(27.723)-(88.172));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-54.107-(-1.902)-(3.067)-(-94.248)-(-86.699)-(45.011));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (70.266-(-52.084)-(0.604)-(33.633)-(-5.649)-(23.587));
clIoeOOMUYZmnVAR = (float) (-4.533-(-88.71)-(9.653)-(-18.751)-(-29.186)-(36.528));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (11.031-(-68.631)-(-16.915)-(-68.225)-(70.749)-(38.223));
