tcb->m_cWnd = (int) (-89.946-(-65.375)-(81.829));
int HIQwzIhphUEWjLJV = (int) ((-56.89*(-73.484)*(6.38)*(63.77))/-3.334);
CongestionAvoidance (tcb, segmentsAcked);
float clIoeOOMUYZmnVAR = (float) (-59.593+(-79.252)+(60.458));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-63.934-(86.549)-(30.77)-(-70.181)-(-53.104)-(3.499));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (95.097-(-49.672)-(-69.293)-(61.94)-(-71.579)-(35.765));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-87.704-(-93.881)-(83.186));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (61.14-(-21.988)-(-71.499)-(73.228)-(40.875)-(-25.582));
clIoeOOMUYZmnVAR = (float) (-43.256-(41.983)-(-52.941)-(51.472)-(81.129)-(14.314));
clIoeOOMUYZmnVAR = (float) (44.117-(62.743)-(-62.472)-(69.011)-(27.583)-(-67.253));
clIoeOOMUYZmnVAR = (float) (-7.728-(93.303)-(-12.939)-(27.622)-(-94.219)-(60.124));
clIoeOOMUYZmnVAR = (float) (-68.129-(-55.041)-(34.278)-(40.227)-(7.794)-(65.334));
clIoeOOMUYZmnVAR = (float) (29.916-(-63.606)-(55.686)-(-70.426)-(-63.696)-(-1.674));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (6.338-(-46.397)-(-17.344));
clIoeOOMUYZmnVAR = (float) (61.743-(38.713)-(71.163)-(30.403)-(65.8)-(-38.432));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (0.02-(-59.303)-(-13.802)-(50.388)-(69.872)-(2.396));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-73.394-(66.718)-(-82.751)-(-56.195)-(79.349)-(88.562));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (37.636-(32.045)-(82.405)-(93.818)-(-86.894)-(28.483));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (32.194-(-46.008)-(81.758)-(-95.44)-(-66.838)-(-46.299));
clIoeOOMUYZmnVAR = (float) (85.963-(93.824)-(70.114)-(58.276)-(-64.766)-(-95.024));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-85.998-(-0.843)-(-41.247)-(62.194)-(-40.075)-(69.254));
clIoeOOMUYZmnVAR = (float) (-38.617-(-45.263)-(61.1)-(-45.563)-(-5.354)-(-93.748));
tcb->m_cWnd = (int) (36.706-(-74.882)-(-90.398));
clIoeOOMUYZmnVAR = (float) (-0.826-(-82.863)-(69.057)-(80.732)-(26.772)-(78.37));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (84.097-(-62.766)-(6.657)-(2.313)-(30.082)-(24.672));
clIoeOOMUYZmnVAR = (float) (-14.455-(-68.671)-(27.458)-(-97.872)-(-16.568)-(89.234));
clIoeOOMUYZmnVAR = (float) (-86.133-(8.183)-(-4.145)-(-87.29)-(-23.01)-(-80.558));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (86.508-(-91.281)-(-7.82)-(41.787)-(50.233)-(-26.114));
