tcb->m_cWnd = (int) (-14.864-(-56.583)-(20.163));
int HIQwzIhphUEWjLJV = (int) ((38.775*(-29.125)*(-69.82)*(-70.376))/-62.673);
CongestionAvoidance (tcb, segmentsAcked);
float clIoeOOMUYZmnVAR = (float) (96.829+(7.215)+(-4.536));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-76.038-(96.686)-(-82.923)-(67.307)-(-35.449)-(42.292));
clIoeOOMUYZmnVAR = (float) (96.25-(29.647)-(38.742)-(38.266)-(9.632)-(91.846));
tcb->m_cWnd = (int) (-37.285-(-65.961)-(25.543));
clIoeOOMUYZmnVAR = (float) (-41.869-(-33.211)-(34.168)-(34.069)-(-70.262)-(-39.66));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (10.069-(-63.471)-(-87.162)-(-41.127)-(-94.845)-(38.146));
clIoeOOMUYZmnVAR = (float) (53.951-(-1.016)-(64.76)-(-52.968)-(-29.743)-(53.837));
tcb->m_cWnd = (int) (-57.287-(18.481)-(-86.043));
clIoeOOMUYZmnVAR = (float) (90.973-(-0.34)-(-65.257)-(17.181)-(54.868)-(93.899));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-22.522-(70.236)-(-10.674)-(89.073)-(-96.523)-(77.004));
clIoeOOMUYZmnVAR = (float) (-60.177-(-73.622)-(71.475)-(-1.942)-(44.055)-(-58.98));
clIoeOOMUYZmnVAR = (float) (-72.412-(-52.114)-(99.778)-(59.555)-(-77.907)-(-2.284));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (3.807-(9.921)-(-25.649)-(-92.118)-(15.782)-(73.641));
