float clIoeOOMUYZmnVAR = (float) (-62.537+(-18.236)+(-19.719));
tcb->m_cWnd = (int) (75.9-(91.8)-(-90.971));
int HIQwzIhphUEWjLJV = (int) ((-3.753*(-33.957)*(70.939)*(-81.318))/-50.976);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (10.997-(-22.504)-(42.195));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-31.464-(4.75)-(-10.008)-(-36.673)-(77.487)-(-41.86));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (61.375-(-83.185)-(-84.351)-(-43.803)-(77.982)-(-27.162));
tcb->m_cWnd = (int) (19.18-(-27.855)-(64.064));
clIoeOOMUYZmnVAR = (float) (22.216-(66.308)-(-74.492)-(39.515)-(49.001)-(50.339));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (58.343-(-74.07)-(-98.46)-(-10.751)-(-17.52)-(-20.598));
clIoeOOMUYZmnVAR = (float) (-63.204-(10.981)-(67.7)-(30.209)-(-27.689)-(70.201));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (23.829-(-56.314)-(94.047));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (3.63-(-34.171)-(-19.174)-(-80.128)-(-74.285)-(-81.178));
tcb->m_cWnd = (int) (-53.642-(67.239)-(-64.185));
clIoeOOMUYZmnVAR = (float) (66.918-(61.176)-(-84.624)-(75.927)-(74.783)-(48.667));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-40.295-(-32.26)-(-7.627)-(42.603)-(66.993)-(-81.477));
clIoeOOMUYZmnVAR = (float) (-15.284-(61.636)-(22.732)-(-61.404)-(-52.055)-(93.291));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-39.72-(81.607)-(-46.25)-(-14.099)-(-5.566)-(87.3));
tcb->m_cWnd = (int) (-11.022-(-68.774)-(37.581));
clIoeOOMUYZmnVAR = (float) (39.142-(-67.378)-(-98.088)-(-83.233)-(79.434)-(-77.59));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-2.04-(40.13)-(-46.118)-(75.504)-(4.356)-(5.923));
clIoeOOMUYZmnVAR = (float) (78.626-(-45.215)-(-71.023)-(-44.3)-(-99.987)-(-90.286));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (47.689-(-3.92)-(65.007)-(44.921)-(-14.265)-(-79.037));
clIoeOOMUYZmnVAR = (float) (21.126-(6.584)-(25.462)-(-17.039)-(-0.024)-(41.502));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-78.872-(-10.838)-(-87.036)-(-72.87)-(60.919)-(-72.241));
