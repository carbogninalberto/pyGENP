tcb->m_cWnd = (int) (77.347-(-82.655)-(3.655));
int HIQwzIhphUEWjLJV = (int) ((-53.246*(49.456)*(66.852)*(76.33))/43.89);
CongestionAvoidance (tcb, segmentsAcked);
float clIoeOOMUYZmnVAR = (float) (-97.256+(43.111)+(-64.548));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (7.867-(-36.446)-(-70.157)-(11.05)-(57.938)-(5.257));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (90.066-(48.342)-(-47.835)-(20.617)-(60.289)-(-60.46));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-53.216-(-77.733)-(60.83));
clIoeOOMUYZmnVAR = (float) (-95.4-(27.865)-(51.625)-(-83.104)-(-46.359)-(4.945));
clIoeOOMUYZmnVAR = (float) (26.233-(12.733)-(-22.17)-(52.024)-(-87.485)-(38.801));
clIoeOOMUYZmnVAR = (float) (-93.929-(60.866)-(35.686)-(44.357)-(-7.9)-(-25.976));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-68.047-(-53.435)-(71.001));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (26.398-(2.291)-(-47.098)-(-44.081)-(16.334)-(31.725));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-82.047-(-42.793)-(23.607)-(-8.988)-(3.09)-(75.998));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (99.391-(-24.244)-(-30.463)-(-39.653)-(-33.581)-(-77.669));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-22.344-(-48.202)-(-80.027)-(-17.817)-(-37.148)-(48.291));
clIoeOOMUYZmnVAR = (float) (-34.77-(-92.373)-(22.628)-(86.765)-(-37.55)-(-94.529));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-99.35-(82.008)-(-18.903)-(94.28)-(41.436)-(-16.232));
clIoeOOMUYZmnVAR = (float) (-43.317-(88.494)-(34.433)-(-19.109)-(18.108)-(-93.75));
clIoeOOMUYZmnVAR = (float) (-47.834-(-6.462)-(-50.484)-(38.329)-(-72.839)-(-53.867));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-18.043-(-42.223)-(29.79));
clIoeOOMUYZmnVAR = (float) (72.998-(40.861)-(47.549)-(-13.839)-(-52.455)-(30.14));
clIoeOOMUYZmnVAR = (float) (-33.28-(5.227)-(81.496)-(-34.532)-(38.613)-(-71.665));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (39.99-(-89.373)-(97.801)-(-67.833)-(-22.649)-(-13.819));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (42.994-(-70.832)-(42.194)-(31.882)-(94.949)-(39.84));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-84.941-(6.252)-(-50.324)-(72.879)-(71.019)-(12.542));
clIoeOOMUYZmnVAR = (float) (98.83-(-43.557)-(76.433)-(-77.925)-(73.794)-(58.117));
clIoeOOMUYZmnVAR = (float) (-47.667-(50.916)-(91.022)-(73.294)-(98.278)-(76.228));
clIoeOOMUYZmnVAR = (float) (-90.184-(-86.188)-(7.274)-(-49.469)-(-2.813)-(59.852));
clIoeOOMUYZmnVAR = (float) (-9.736-(-37.418)-(-82.748)-(-19.586)-(3.474)-(-95.738));
clIoeOOMUYZmnVAR = (float) (-69.815-(93.777)-(-85.016)-(56.971)-(-98.646)-(-44.821));
tcb->m_cWnd = (int) (-34.208-(-1.188)-(57.737));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-77.527-(-94.248)-(-61.573)-(-2.69)-(65.4)-(-42.524));
clIoeOOMUYZmnVAR = (float) (-29.921-(2.466)-(-67.503)-(-75.59)-(42.407)-(49.082));
clIoeOOMUYZmnVAR = (float) (-64.627-(-69.249)-(-32.671)-(24.705)-(58.713)-(-12.026));
clIoeOOMUYZmnVAR = (float) (-17.32-(65.57)-(-97.3)-(-46.195)-(-78.662)-(-5.949));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (59.176-(-43.367)-(-4.875)-(-83.358)-(-72.258)-(70.122));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (5.003-(-87.773)-(70.376));
clIoeOOMUYZmnVAR = (float) (-0.175-(-60.102)-(-35.036)-(49.602)-(-96.992)-(-78.255));
clIoeOOMUYZmnVAR = (float) (-50.954-(55.507)-(-40.772)-(13.054)-(55.748)-(7.675));
clIoeOOMUYZmnVAR = (float) (-32.221-(-7.018)-(2.606)-(43.536)-(-19.263)-(29.724));
clIoeOOMUYZmnVAR = (float) (91.578-(51.904)-(17.769)-(-45.321)-(1.986)-(35.741));
clIoeOOMUYZmnVAR = (float) (90.059-(-93.779)-(11.321)-(-51.856)-(27.427)-(15.247));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (71.846-(96.46)-(35.602)-(24.632)-(3.871)-(-98.583));
clIoeOOMUYZmnVAR = (float) (89.086-(-52.878)-(81.694)-(24.703)-(-85.299)-(8.49));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (4.621-(-80.782)-(-21.173)-(42.923)-(37.937)-(-5.448));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-31.536-(-26.026)-(-2.4)-(-78.339)-(8.875)-(-60.25));
clIoeOOMUYZmnVAR = (float) (42.468-(45.487)-(67.477)-(55.163)-(-51.146)-(-37.753));
clIoeOOMUYZmnVAR = (float) (95.278-(-53.794)-(-5.32)-(24.548)-(-71.892)-(-14.555));
clIoeOOMUYZmnVAR = (float) (-50.786-(-59.084)-(68.629)-(-69.271)-(48.328)-(57.047));
clIoeOOMUYZmnVAR = (float) (68.839-(-37.458)-(-22.958)-(82.881)-(20.45)-(-63.233));
tcb->m_cWnd = (int) (-26.02-(69.521)-(89.457));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-39.732-(70.951)-(-41.935)-(-33.051)-(58.074)-(24.843));
clIoeOOMUYZmnVAR = (float) (91.625-(-22.499)-(-43.991)-(24.363)-(-52.06)-(30.999));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-56.764-(40.411)-(18.72)-(-86.696)-(60.713)-(-42.221));
clIoeOOMUYZmnVAR = (float) (-46.241-(35.311)-(-28.162)-(-47.069)-(12.28)-(11.803));
clIoeOOMUYZmnVAR = (float) (18.437-(39.162)-(40.16)-(-81.938)-(-71.433)-(16.458));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-51.808-(81.382)-(-63.118)-(33.269)-(-41.557)-(70.853));
