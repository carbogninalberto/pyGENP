tcb->m_cWnd = (int) (-10.414-(-99.098)-(-54.627));
float clIoeOOMUYZmnVAR = (float) (39.013+(-16.353)+(82.556));
CongestionAvoidance (tcb, segmentsAcked);
int HIQwzIhphUEWjLJV = (int) ((58.331*(-47.006)*(-37.221)*(25.12))/5.781);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (50.589-(60.632)-(27.883)-(21.23)-(14.452)-(57.577));
clIoeOOMUYZmnVAR = (float) (-56.732-(-40.989)-(27.309)-(16.406)-(-60.429)-(-66.673));
clIoeOOMUYZmnVAR = (float) (70.538-(64.811)-(50.935)-(-71.598)-(67.739)-(15.377));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (55.783-(-90.572)-(24.453)-(23.588)-(-9.055)-(73.051));
clIoeOOMUYZmnVAR = (float) (-26.317-(56.662)-(-75.784)-(28.853)-(0.265)-(75.635));
clIoeOOMUYZmnVAR = (float) (-20.663-(7.117)-(67.634)-(83.025)-(57.522)-(-34.917));
clIoeOOMUYZmnVAR = (float) (93.333-(-26.415)-(-47.105)-(10.658)-(22.663)-(-16.663));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (41.34-(49.37)-(20.831)-(19.137)-(-45.138)-(-48.895));
clIoeOOMUYZmnVAR = (float) (46.591-(-11.537)-(40.167)-(-16.698)-(-43.753)-(-85.308));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (22.08-(-26.921)-(-21.691)-(22.212)-(-99.148)-(-90.884));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (45.795-(-21.984)-(15.121)-(76.614)-(-50.89)-(-80.334));
clIoeOOMUYZmnVAR = (float) (45.008-(13.358)-(41.676)-(72.365)-(68.707)-(-50.767));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (98.612-(-73.741)-(-46.505)-(-16.733)-(97.659)-(97.245));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-4.042-(-19.783)-(45.156)-(-15.04)-(80.18)-(-6.989));
clIoeOOMUYZmnVAR = (float) (-50.409-(75.938)-(-99.912)-(-4.143)-(-0.978)-(23.211));
clIoeOOMUYZmnVAR = (float) (93.556-(29.758)-(-53.94)-(-85.377)-(-98.197)-(-96.988));
clIoeOOMUYZmnVAR = (float) (-94.328-(-74.191)-(-50.058)-(-83.577)-(-8.423)-(61.078));
clIoeOOMUYZmnVAR = (float) (18.285-(53.431)-(87.621)-(-44.648)-(22.146)-(62.891));
clIoeOOMUYZmnVAR = (float) (-87.984-(34.864)-(35.052)-(-69.9)-(-71.779)-(-86.308));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-53.667-(-71.186)-(-24.443)-(-18.58)-(63.412)-(-45.582));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (68.295-(-98.823)-(55.186)-(99.497)-(-86.99)-(72.117));
clIoeOOMUYZmnVAR = (float) (30.013-(19.411)-(63.49)-(42.042)-(58.185)-(91.679));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (21.477-(79.769)-(62.721)-(45.373)-(33.133)-(27.647));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-22.768-(59.737)-(-86.018)-(29.027)-(18.306)-(-80.451));
clIoeOOMUYZmnVAR = (float) (80.114-(72.767)-(-49.541)-(-77.679)-(53.19)-(82.917));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (27.139-(67.528)-(77.698)-(-75.212)-(-80.279)-(69.783));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-65.027-(-92.226)-(-83.728)-(76.604)-(-56.863)-(-17.495));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (46.318-(-11.031)-(32.159)-(47.458)-(-11.494)-(82.755));
clIoeOOMUYZmnVAR = (float) (-67.126-(-85.634)-(52.301)-(37.748)-(-81.141)-(-88.043));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-8.853-(-65.501)-(-6.783)-(-89.998)-(-16.854)-(-74.096));
clIoeOOMUYZmnVAR = (float) (-3.774-(-43.944)-(-94.015)-(-12.626)-(-3.235)-(-45.183));
clIoeOOMUYZmnVAR = (float) (-99.749-(-97.624)-(79.522)-(-24.956)-(-34.406)-(-63.312));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-38.627-(78.486)-(24.816)-(34.467)-(-5.693)-(66.243));
clIoeOOMUYZmnVAR = (float) (93.611-(9.967)-(-45.011)-(0.375)-(-50.998)-(-79.541));
clIoeOOMUYZmnVAR = (float) (-68.485-(-38.462)-(-76.397)-(-88.009)-(-58.39)-(97.531));
clIoeOOMUYZmnVAR = (float) (90.088-(-68.926)-(-73.359)-(-79.005)-(49.682)-(39.011));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (37.714-(84.472)-(-58.116)-(-2.917)-(63.561)-(-5.791));
clIoeOOMUYZmnVAR = (float) (-50.8-(10.32)-(54.781)-(66.703)-(78.05)-(6.236));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (90.185-(50.758)-(-25.72)-(39.297)-(77.356)-(67.494));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-88.826-(-36.884)-(72.226)-(21.037)-(-79.569)-(29.333));
clIoeOOMUYZmnVAR = (float) (-89.025-(-69.208)-(15.27)-(-29.085)-(92.097)-(-94.648));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (57.899-(75.981)-(-64.462)-(46.625)-(22.902)-(-42.912));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-39.935-(-45.142)-(-22.476)-(97.696)-(42.675)-(-6.071));
clIoeOOMUYZmnVAR = (float) (-29.001-(24.444)-(36.115)-(42.583)-(33.115)-(-18.638));
clIoeOOMUYZmnVAR = (float) (-68.096-(67.404)-(-5.5)-(-72.39)-(-92.66)-(67.729));
clIoeOOMUYZmnVAR = (float) (-85.832-(-75.539)-(-58.947)-(-37.602)-(-98.65)-(-95.975));
clIoeOOMUYZmnVAR = (float) (57.602-(60.266)-(-3.9)-(51.37)-(94.679)-(13.771));
clIoeOOMUYZmnVAR = (float) (3.143-(93.521)-(-43.527)-(-37.823)-(65.267)-(63.738));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (85.368-(18.339)-(26.218)-(-95.363)-(-76.43)-(95.602));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-73.4-(92.281)-(10.82)-(-21.896)-(45.088)-(-61.096));
clIoeOOMUYZmnVAR = (float) (-1.826-(-39.205)-(84.853)-(60.654)-(57.132)-(-4.075));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (83.447-(50.67)-(87.801)-(61.635)-(19.674)-(99.375));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-3.913-(50.888)-(-93.685)-(-46.62)-(80.461)-(76.263));
clIoeOOMUYZmnVAR = (float) (35.755-(-99.712)-(-0.301)-(-53.399)-(71.446)-(-2.989));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (59.882-(-6.754)-(25.829)-(-68.381)-(43.971)-(76.773));
clIoeOOMUYZmnVAR = (float) (-17.506-(97.166)-(34.613)-(-6.177)-(-64.533)-(12.849));
clIoeOOMUYZmnVAR = (float) (9.081-(2.039)-(64.765)-(73.809)-(-85.821)-(-30.222));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (97.244-(60.431)-(-83.62)-(-81.485)-(-49.206)-(-24.917));
