tcb->m_cWnd = (int) (-0.126-(-56.118)-(42.286));
float clIoeOOMUYZmnVAR = (float) (-2.714+(-16.116)+(52.932));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
int HIQwzIhphUEWjLJV = (int) ((-19.341*(-48.11)*(92.915)*(-83.037))/34.064);
clIoeOOMUYZmnVAR = (float) (-94.477-(-38.568)-(-43.568)-(-16.412)-(-26.712)-(-82.685));
clIoeOOMUYZmnVAR = (float) (-8.285-(-85.685)-(-98.817)-(51.732)-(27.656)-(-27.146));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-16.349-(90.433)-(-14.328)-(-94.74)-(55.036)-(-4.758));
clIoeOOMUYZmnVAR = (float) (4.817-(-67.114)-(77.373)-(68.861)-(-31.745)-(93.182));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (25.561-(2.051)-(-23.717)-(-93.719)-(-25.005)-(90.085));
clIoeOOMUYZmnVAR = (float) (7.414-(49.995)-(-42.763)-(-43.87)-(-69.477)-(46.156));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-98.63-(-87.354)-(95.609)-(63.61)-(-0.215)-(44.83));
