float clIoeOOMUYZmnVAR = (float) (79.459+(31.974)+(72.646));
int HIQwzIhphUEWjLJV = (int) ((-37.202*(-40.109)*(-0.327)*(93.727))/8.187);
tcb->m_cWnd = (int) (-20.045-(64.826)-(-58.431));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (33.088-(41.339)-(26.682)-(-33.037)-(97.278)-(14.289));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-50.152-(-25.777)-(-14.864)-(48.394)-(-19.051)-(-3.09));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (83.106-(-78.266)-(39.115));
clIoeOOMUYZmnVAR = (float) (-52.076-(-53.984)-(-53.24)-(-8.464)-(-85.752)-(-5.064));
clIoeOOMUYZmnVAR = (float) (47.689-(96.634)-(-98.701)-(70.121)-(95.441)-(-22.577));
clIoeOOMUYZmnVAR = (float) (-6.53-(-55.282)-(5.993)-(-58.184)-(95.014)-(-32.321));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (-9.232-(29.187)-(82.606));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (68.552-(-82.568)-(3.17)-(94.675)-(-54.501)-(82.358));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
clIoeOOMUYZmnVAR = (float) (-11.414-(64.933)-(-88.621)-(88.59)-(29.798)-(78.182));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (14.844-(46.576)-(77.761)-(72.235)-(31.832)-(53.955));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-20.413-(-36.242)-(50.455)-(-20.07)-(-99.515)-(-39.325));
clIoeOOMUYZmnVAR = (float) (-10.776-(-24.079)-(-75.295)-(-94.079)-(-58.68)-(-41.699));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-82.313-(91.759)-(-90.579)-(-82.293)-(12.997)-(-24.755));
clIoeOOMUYZmnVAR = (float) (76.189-(-35.012)-(-36.544)-(90.742)-(-80.165)-(81.334));
tcb->m_cWnd = (int) (32.99-(-80.756)-(3.163));
clIoeOOMUYZmnVAR = (float) (-64.884-(-99.919)-(63.149)-(97.833)-(23.661)-(9.077));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-22.38-(37.047)-(14.254)-(70.421)-(45.196)-(-77.24));
clIoeOOMUYZmnVAR = (float) (92.91-(-17.664)-(12.551)-(31.025)-(97.319)-(34.312));
clIoeOOMUYZmnVAR = (float) (74.948-(39.72)-(68.728)-(92.025)-(-11.928)-(30.241));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-42.276-(79.179)-(57.775)-(-22.366)-(-21.214)-(-36.678));
