tcb->m_cWnd = (int) (-91.104-(-45.337)-(-13.302));
float clIoeOOMUYZmnVAR = (float) (-75.263+(-5.166)+(75.518));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
int HIQwzIhphUEWjLJV = (int) ((-74.632*(-76.361)*(-19.315)*(-56.728))/-78.151);
clIoeOOMUYZmnVAR = (float) (-67.344-(-52.342)-(-36.937)-(-48.725)-(-91.193)-(72.844));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-30.546-(-55.406)-(68.721)-(-85.675)-(-51.183)-(24.305));
clIoeOOMUYZmnVAR = (float) (14.784-(-7.769)-(91.83)-(-36.643)-(-20.386)-(36.129));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-71.664-(31.399)-(-96.939)-(-19.808)-(-53.789)-(-55.62));
clIoeOOMUYZmnVAR = (float) (73.958-(44.497)-(-66.801)-(29.152)-(-44.873)-(83.917));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (67.332-(-12.543)-(67.039)-(-90.739)-(59.95)-(-8.978));
clIoeOOMUYZmnVAR = (float) (-28.363-(98.877)-(33.172)-(83.324)-(5.378)-(-53.209));
clIoeOOMUYZmnVAR = (float) (57.001-(-59.049)-(-58.602)-(-86.738)-(-77.816)-(-79.505));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-46.558-(-68.5)-(-75.772)-(20.796)-(-16.667)-(-1.796));
clIoeOOMUYZmnVAR = (float) (7.993-(-97.618)-(-28.473)-(69.801)-(-16.011)-(-33.709));
clIoeOOMUYZmnVAR = (float) (32.591-(39.969)-(-53.852)-(40.655)-(63.121)-(82.702));
clIoeOOMUYZmnVAR = (float) (9.342-(-12.772)-(-35.847)-(47.278)-(61.04)-(-96.233));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (20.83-(31.677)-(51.419)-(28.868)-(87.925)-(-72.824));
clIoeOOMUYZmnVAR = (float) (-44.676-(59.149)-(16.469)-(29.21)-(59.632)-(-25.81));
clIoeOOMUYZmnVAR = (float) (-62.468-(21.938)-(-6.901)-(-42.586)-(87.404)-(-71.809));
clIoeOOMUYZmnVAR = (float) (-55.367-(4.845)-(-33.262)-(8.193)-(-51.886)-(46.981));
clIoeOOMUYZmnVAR = (float) (52.298-(-74.648)-(-41.702)-(-7.35)-(-43.617)-(-60.334));
clIoeOOMUYZmnVAR = (float) (-8.212-(30.073)-(-2.351)-(-11.659)-(75.056)-(-71.466));
clIoeOOMUYZmnVAR = (float) (-60.429-(-43.081)-(-50.343)-(-71.843)-(-81.534)-(-97.434));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-26.322-(-70.455)-(-99.208)-(-19.271)-(50.513)-(-19.555));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-92.721-(90.455)-(78.634)-(-83.713)-(36.113)-(-66.704));
clIoeOOMUYZmnVAR = (float) (59.652-(-12.402)-(78.842)-(82.051)-(42.778)-(6.883));
clIoeOOMUYZmnVAR = (float) (-46.105-(90.027)-(-86.966)-(99.765)-(-12.471)-(57.896));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (49.087-(69.458)-(-75.875)-(85.447)-(48.202)-(7.09));
