int fSLHSPBIufPXihmI = (int) (-4.373+(-32.094)+(-80.715)+(-80.639)+(1.008)+(99.845)+(-80.157)+(-89.015)+(25.224));
float yECqnvaPPBdTEOZA = (float) (11.672-(77.167)-(96.274)-(81.055)-(-71.054));
tcb->m_segmentSize = (int) (-7.239+(46.144)+(-58.09)+(29.137)+(-22.907)+(-5.661)+(60.639)+(0.304));
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (segmentsAcked+(20.306)+(92.471)+(43.184)+(92.833)+(9.329)+(46.151)+(49.518)+(80.21));

} else {
	segmentsAcked = (int) ((((tcb->m_cWnd+(98.404)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(92.977)+(50.173)+(60.044)+(60.906)))+(72.987)+(0.1)+(87.706))/((0.1)+(43.688)+(67.569)+(19.614)));
	tcb->m_segmentSize = (int) (19.644+(33.035)+(96.35));
	tcb->m_segmentSize = (int) (0.1/71.348);

}
if (tcb->m_segmentSize <= yECqnvaPPBdTEOZA) {
	segmentsAcked = (int) (91.453*(yECqnvaPPBdTEOZA)*(49.505)*(yECqnvaPPBdTEOZA));

} else {
	segmentsAcked = (int) (68.125+(43.789)+(11.13)+(29.886)+(53.401)+(segmentsAcked)+(70.455)+(36.501)+(46.027));
	segmentsAcked = (int) (21.907-(69.535)-(49.949)-(10.609));

}
segmentsAcked = (int) (-81.004+(3.277)+(95.333)+(27.098));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (5.378/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (71.956+(4.301)+(32.291)+(tcb->m_cWnd)+(45.116)+(55.766)+(tcb->m_cWnd)+(40.988));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	fSLHSPBIufPXihmI = (int) (44.881-(26.334)-(tcb->m_segmentSize)-(11.349)-(92.979)-(30.066));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (22.84-(46.798)-(43.127)-(18.458)-(-51.375)-(1.892)-(1.16)-(-54.595)-(-28.223));
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (5.378/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (71.956+(4.301)+(32.291)+(tcb->m_cWnd)+(45.116)+(55.766)+(tcb->m_cWnd)+(40.988));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	fSLHSPBIufPXihmI = (int) (44.881-(26.334)-(tcb->m_segmentSize)-(11.349)-(92.979)-(30.066));

}
tcb->m_segmentSize = (int) (99.983-(-72.195)-(-21.941)-(94.025)-(-94.043)-(10.644)-(-64.933)-(64.208)-(-0.975));
