int fSLHSPBIufPXihmI = (int) (39.158+(86.096)+(25.399)+(-92.233)+(4.397)+(78.45)+(-73.619)+(-17.418)+(20.863));
float yECqnvaPPBdTEOZA = (float) (-50.901-(17.071)-(64.381)-(28.711)-(0.039));
if (segmentsAcked <= segmentsAcked) {
	tcb->m_cWnd = (int) (41.538-(76.447)-(79.572)-(89.008)-(25.613)-(87.709)-(57.794));
	tcb->m_cWnd = (int) (95.168-(35.201)-(72.297)-(22.199)-(43.777)-(tcb->m_segmentSize)-(87.967)-(tcb->m_segmentSize)-(26.976));

} else {
	tcb->m_cWnd = (int) (89.933/86.635);

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (segmentsAcked+(20.306)+(92.471)+(43.184)+(92.833)+(9.329)+(46.151)+(49.518)+(80.21));

} else {
	segmentsAcked = (int) ((((tcb->m_cWnd+(98.404)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(92.977)+(50.173)+(60.044)+(60.906)))+(72.987)+(0.1)+(87.706))/((0.1)+(43.688)+(67.569)+(19.614)));
	tcb->m_segmentSize = (int) (19.644+(33.035)+(96.35));
	tcb->m_segmentSize = (int) (0.1/71.348);

}
if (tcb->m_segmentSize <= yECqnvaPPBdTEOZA) {
	segmentsAcked = (int) (91.453*(yECqnvaPPBdTEOZA)*(49.505)*(yECqnvaPPBdTEOZA));

} else {
	segmentsAcked = (int) (68.125+(43.789)+(11.13)+(29.886)+(53.401)+(segmentsAcked)+(70.455)+(36.501)+(46.027));
	segmentsAcked = (int) (21.907-(69.535)-(49.949)-(10.609));

}
segmentsAcked = (int) (1.159+(23.254)+(-59.218)+(19.539));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (5.378/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (71.956+(4.301)+(32.291)+(tcb->m_cWnd)+(45.116)+(55.766)+(tcb->m_cWnd)+(40.988));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	fSLHSPBIufPXihmI = (int) (44.881-(26.334)-(tcb->m_segmentSize)-(11.349)-(92.979)-(30.066));

}
if (tcb->m_segmentSize <= yECqnvaPPBdTEOZA) {
	segmentsAcked = (int) (91.453*(yECqnvaPPBdTEOZA)*(49.505)*(yECqnvaPPBdTEOZA));

} else {
	segmentsAcked = (int) (68.125+(43.789)+(11.13)+(29.886)+(53.401)+(segmentsAcked)+(70.455)+(36.501)+(46.027));
	segmentsAcked = (int) (21.907-(69.535)-(49.949)-(10.609));

}
tcb->m_segmentSize = (int) (-19.216-(-85.545)-(-42.038)-(92.38)-(-88.772)-(-96.481)-(-2.113)-(-1.64)-(86.184));
segmentsAcked = (int) (54.075+(-82.588)+(75.646)+(66.717));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (5.378/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (71.956+(4.301)+(32.291)+(tcb->m_cWnd)+(45.116)+(55.766)+(tcb->m_cWnd)+(40.988));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	fSLHSPBIufPXihmI = (int) (44.881-(26.334)-(tcb->m_segmentSize)-(11.349)-(92.979)-(30.066));

}
tcb->m_segmentSize = (int) (-68.344-(-76.824)-(80.702)-(-1.451)-(19.209)-(-79.376)-(59.198)-(-17.619)-(36.721));
