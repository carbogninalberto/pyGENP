int HIQwzIhphUEWjLJV = (int) ((-39.118*(-10.026)*(31.129)*(-16.322))/-78.581);
float clIoeOOMUYZmnVAR = (float) (-53.628+(31.051)+(67.749));
tcb->m_cWnd = (int) (-26.976-(98.967)-(9.916));
if (tcb->m_segmentSize >= clIoeOOMUYZmnVAR) {
	tcb->m_segmentSize = (int) (clIoeOOMUYZmnVAR+(76.3)+(78.915)+(tcb->m_segmentSize)+(56.968)+(3.175)+(70.948));
	tcb->m_segmentSize = (int) ((93.724*(40.296)*(32.908))/12.047);

} else {
	tcb->m_segmentSize = (int) (27.116/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-46.969-(96.461)-(71.336)-(-52.206)-(23.592)-(74.741));
CongestionAvoidance (tcb, segmentsAcked);
clIoeOOMUYZmnVAR = (float) (-11.889-(33.692)-(58.219)-(-72.046)-(-35.374)-(-15.281));
