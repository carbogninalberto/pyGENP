if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_segmentSize = (int) (54.75/0.1);
	segmentsAcked = (int) (73.758/0.1);

} else {
	tcb->m_segmentSize = (int) (28.828/0.1);

}
if (tcb->m_cWnd != segmentsAcked) {
	segmentsAcked = (int) (29.111/0.1);

} else {
	segmentsAcked = (int) (tcb->m_cWnd-(70.055)-(48.662));
	tcb->m_cWnd = (int) (61.169-(36.714)-(68.704)-(74.971));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-76.448+(96.442)+(-3.455)+(89.731)+(-14.849)+(-3.603));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
