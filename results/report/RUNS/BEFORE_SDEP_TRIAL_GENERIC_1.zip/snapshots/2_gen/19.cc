float eIrwWKfiToHlhlxp = (float) (-37.094+(-26.04)+(-70.425)+(8.128)+(81.733)+(-7.789)+(-33.217)+(-88.266)+(73.762));
tcb->m_cWnd = (int) (2.902-(68.366)-(-81.402)-(-49.496)-(68.215)-(86.309)-(-14.786));
segmentsAcked = (int) (90.29-(26.533));
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (20.781-(80.759)-(tcb->m_cWnd)-(62.692));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (45.235-(54.056)-(29.146)-(12.452)-(14.262)-(63.507));

}
segmentsAcked = (int) (-36.386-(43.799));
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (27.231*(segmentsAcked)*(22.383)*(eIrwWKfiToHlhlxp)*(52.235)*(tcb->m_segmentSize)*(70.723));
	segmentsAcked = (int) (((29.919)+(87.914)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (66.762+(63.327)+(segmentsAcked)+(11.862)+(tcb->m_cWnd)+(segmentsAcked)+(19.313)+(99.956)+(2.666));

}
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (20.781-(80.759)-(tcb->m_cWnd)-(62.692));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (45.235-(54.056)-(29.146)-(12.452)-(14.262)-(63.507));

}
eIrwWKfiToHlhlxp = (float) ((((-94.808*(56.24)*(segmentsAcked)*(75.208)*(57.744)*(-60.514)))+(-26.867)+(80.993)+(-29.936)+(-70.416)+(20.489)+(-96.994))/((-98.595)));
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (27.231*(segmentsAcked)*(22.383)*(eIrwWKfiToHlhlxp)*(52.235)*(tcb->m_segmentSize)*(70.723));
	segmentsAcked = (int) (((29.919)+(87.914)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (66.762+(63.327)+(segmentsAcked)+(11.862)+(tcb->m_cWnd)+(segmentsAcked)+(19.313)+(99.956)+(2.666));

}
eIrwWKfiToHlhlxp = (float) ((((-56.296*(63.456)*(segmentsAcked)*(60.781)*(-42.382)*(87.196)))+(-55.808)+(38.53)+(59.501)+(98.811)+(14.561)+(-78.753))/((22.551)));
