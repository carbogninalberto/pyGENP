if (tcb->m_cWnd != segmentsAcked) {
	segmentsAcked = (int) (tcb->m_cWnd-(70.055)-(48.662));
	tcb->m_cWnd = (int) (61.169-(36.714)-(68.704)-(74.971));

} else {
	segmentsAcked = (int) (29.111/0.1);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (79.387+(74.305)+(43.206)+(86.928)+(-44.944)+(-1.77));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
