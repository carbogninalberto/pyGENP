int fSLHSPBIufPXihmI = (int) (34.513+(29.175)+(-15.985)+(38.639)+(-2.627)+(-45.708)+(-39.835)+(62.931)+(-10.174));
float yECqnvaPPBdTEOZA = (float) (10.437-(-47.919)-(43.878)-(-36.393)-(65.82));
if (segmentsAcked <= segmentsAcked) {
	tcb->m_cWnd = (int) (41.538-(76.447)-(79.572)-(89.008)-(25.613)-(87.709)-(57.794));
	tcb->m_cWnd = (int) (95.168-(35.201)-(72.297)-(22.199)-(43.777)-(tcb->m_segmentSize)-(87.967)-(tcb->m_segmentSize)-(26.976));

} else {
	tcb->m_cWnd = (int) (89.933/86.635);

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (segmentsAcked+(20.306)+(92.471)+(43.184)+(92.833)+(9.329)+(46.151)+(49.518)+(80.21));

} else {
	segmentsAcked = (int) ((((tcb->m_cWnd+(98.404)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(92.977)+(50.173)+(60.044)+(60.906)))+(72.987)+(0.1)+(87.706))/((0.1)+(43.688)+(67.569)+(19.614)));
	tcb->m_segmentSize = (int) (19.644+(33.035)+(96.35));
	tcb->m_segmentSize = (int) (0.1/71.348);

}
if (tcb->m_segmentSize <= yECqnvaPPBdTEOZA) {
	segmentsAcked = (int) (91.453*(yECqnvaPPBdTEOZA)*(49.505)*(yECqnvaPPBdTEOZA));

} else {
	segmentsAcked = (int) (68.125+(43.789)+(11.13)+(29.886)+(53.401)+(segmentsAcked)+(70.455)+(36.501)+(46.027));
	segmentsAcked = (int) (21.907-(69.535)-(49.949)-(10.609));

}
segmentsAcked = (int) (-99.712+(-12.133)+(77.186)+(-56.009));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (5.378/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (71.956+(4.301)+(32.291)+(tcb->m_cWnd)+(45.116)+(55.766)+(tcb->m_cWnd)+(40.988));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	fSLHSPBIufPXihmI = (int) (44.881-(26.334)-(tcb->m_segmentSize)-(11.349)-(92.979)-(30.066));

}
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (5.378/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (71.956+(4.301)+(32.291)+(tcb->m_cWnd)+(45.116)+(55.766)+(tcb->m_cWnd)+(40.988));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	fSLHSPBIufPXihmI = (int) (44.881-(26.334)-(tcb->m_segmentSize)-(11.349)-(92.979)-(30.066));

}
tcb->m_segmentSize = (int) (13.615-(74.897)-(-6.099)-(-71.995)-(-91.221)-(-12.162)-(54.605)-(28.421)-(-16.923));
tcb->m_segmentSize = (int) (28.444-(-68.616)-(-52.757)-(-75.097)-(-62.361)-(-28.061)-(-54.75)-(-41.076)-(-25.626));
