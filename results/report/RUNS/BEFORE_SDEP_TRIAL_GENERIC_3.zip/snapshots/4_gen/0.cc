if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((segmentsAcked+(17.263)+(1.904)+(0.597))/(23.173-(60.731)-(tcb->m_segmentSize)-(5.439)));

} else {
	tcb->m_segmentSize = (int) (1.626*(98.406)*(27.002));

}
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (24.036+(tcb->m_cWnd)+(62.191));
	segmentsAcked = (int) (tcb->m_segmentSize-(55.315)-(58.592)-(6.086));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (93.604-(segmentsAcked)-(2.792)-(41.949));
	tcb->m_cWnd = (int) (93.51-(44.07)-(14.938)-(14.337));

}
