float DhLzDdbzACFCLctC = (float) (-52.153*(-36.169));
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (27.94+(79.534)+(tcb->m_segmentSize)+(18.995));

} else {
	tcb->m_segmentSize = (int) (45.361+(tcb->m_cWnd)+(26.965)+(98.143));

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
