float qeVwLaxPEOYPIOxP = (float) (-45.824+(75.997)+(-29.387)+(47.863));
int IrovkEcFBEdEXCQX = (int) (92.088/-36.883);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (25.674*(-89.923)*(80.284));
ReduceCwnd (tcb);
IrovkEcFBEdEXCQX = (int) (-21.62+(-28.378));
IrovkEcFBEdEXCQX = (int) (-68.414*(-51.949)*(96.232));
tcb->m_cWnd = (int) (-82.933*(-71.663)*(86.803));
IrovkEcFBEdEXCQX = (int) (-69.622*(-20.336)*(45.068));
