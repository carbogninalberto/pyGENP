float qeVwLaxPEOYPIOxP = (float) (53.762/-61.655);
