if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (76.784-(segmentsAcked)-(56.215));

} else {
	tcb->m_cWnd = (int) ((segmentsAcked*(74.678)*(98.411))/19.31);

}
