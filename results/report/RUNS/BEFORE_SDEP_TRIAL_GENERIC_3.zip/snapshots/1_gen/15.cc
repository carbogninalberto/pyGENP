if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (5.132*(64.835)*(tcb->m_cWnd)*(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(71.9)*(30.699));

}
segmentsAcked = (int) (45.771*(28.252)*(51.577));
tcb->m_cWnd = (int) ((46.923-(55.237))/7.32);
tcb->m_cWnd = (int) (93.592-(60.782)-(4.59)-(55.056));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (45.834-(tcb->m_cWnd));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (81.609*(41.18));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (14.0/10.33);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
