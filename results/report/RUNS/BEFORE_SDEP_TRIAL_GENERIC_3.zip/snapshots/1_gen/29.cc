segmentsAcked = (int) (9.06/11.96);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (86.994+(69.555)+(66.479)+(39.124));
	tcb->m_segmentSize = (int) (28.954+(17.189));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) ((28.438-(35.534)-(20.655)-(13.124))/6.97);

}
segmentsAcked = (int) (48.489+(tcb->m_segmentSize));
tcb->m_cWnd = (int) (85.604*(7.032)*(39.296));
