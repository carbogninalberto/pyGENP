if (tcb->m_cWnd != segmentsAcked) {
	segmentsAcked = (int) (66.49*(17.083));

} else {
	segmentsAcked = (int) (44.867+(78.929)+(0.174)+(tcb->m_cWnd));
	tcb->m_cWnd = (int) (74.28-(74.594)-(90.35));
	tcb->m_cWnd = (int) (segmentsAcked*(34.239)*(45.525)*(37.098));

}
if (segmentsAcked > tcb->m_cWnd) {
	segmentsAcked = (int) (39.432+(71.221)+(51.438));

} else {
	segmentsAcked = (int) (78.407-(95.817)-(85.414)-(34.221));
	segmentsAcked = (int) (36.151+(92.277)+(42.776)+(segmentsAcked));
	segmentsAcked = (int) (tcb->m_cWnd*(53.385)*(13.194));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (2.243-(42.339));
CongestionAvoidance (tcb, segmentsAcked);
