if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (11.27/5.85);

} else {
	segmentsAcked = (int) (10.472+(28.411)+(1.545)+(30.645));

}
float HhdtbrIMMuKxhjBD = (float) (79.489-(5.951)-(3.333));
tcb->m_cWnd = (int) (4.34/15.41);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(34.469)+(7.159));

} else {
	tcb->m_segmentSize = (int) (97.535-(80.762)-(44.735)-(76.265));
	tcb->m_segmentSize = (int) ((35.71+(tcb->m_segmentSize))/14.85);
	tcb->m_segmentSize = (int) (67.705+(85.987)+(tcb->m_segmentSize)+(6.825));

}
CongestionAvoidance (tcb, segmentsAcked);
