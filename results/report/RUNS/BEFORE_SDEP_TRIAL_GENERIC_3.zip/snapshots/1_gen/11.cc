if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((41.191*(segmentsAcked)*(24.76)*(28.866))/7.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (1.89/3.62);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (3.949*(48.286)*(39.737));
int rjVevCVvpFEsIzpV = (int) (72.875*(39.219));
segmentsAcked = (int) (segmentsAcked+(94.476));
if (rjVevCVvpFEsIzpV <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (72.684*(59.975));

} else {
	tcb->m_segmentSize = (int) (44.219-(35.489));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (95.291*(51.1));

}
