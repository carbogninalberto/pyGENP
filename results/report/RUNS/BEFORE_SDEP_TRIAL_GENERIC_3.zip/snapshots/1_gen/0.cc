ReduceCwnd (tcb);
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(34.125));
	tcb->m_cWnd = (int) (33.457+(84.787));

} else {
	tcb->m_cWnd = (int) (16.78/19.05);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_segmentSize = (int) (11.39/4.71);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (48.148+(54.391));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (8.079*(tcb->m_segmentSize)*(tcb->m_segmentSize));

}
if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (10.15/14.8);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (98.293+(tcb->m_segmentSize)+(62.957)+(11.102));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(55.389)*(66.754));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (61.142-(tcb->m_cWnd)-(tcb->m_cWnd)-(73.318));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (99.414-(80.406)-(52.945));
	segmentsAcked = (int) (64.251-(87.845)-(45.959));
	segmentsAcked = (int) (91.968*(30.464)*(74.824)*(28.348));

} else {
	segmentsAcked = (int) (23.943*(77.437)*(segmentsAcked)*(tcb->m_cWnd));

}
