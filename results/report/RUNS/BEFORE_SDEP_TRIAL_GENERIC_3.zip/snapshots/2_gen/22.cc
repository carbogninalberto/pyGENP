if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (19.863+(tcb->m_cWnd)+(69.377));

} else {
	tcb->m_segmentSize = (int) ((28.449*(16.009)*(segmentsAcked))/4.07);

}
if (segmentsAcked > tcb->m_cWnd) {
	segmentsAcked = (int) (39.432+(71.221)+(51.438));

} else {
	segmentsAcked = (int) (78.407-(95.817)-(85.414)-(34.221));
	segmentsAcked = (int) (36.151+(92.277)+(42.776)+(segmentsAcked));
	segmentsAcked = (int) (tcb->m_cWnd*(53.385)*(13.194));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-2.499-(30.468));
