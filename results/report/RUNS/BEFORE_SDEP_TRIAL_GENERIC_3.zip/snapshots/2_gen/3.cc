tcb->m_cWnd = (int) (28.482*(85.259)*(0.871));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (24.424+(65.076));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (1.37/17.51);

}
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_cWnd = (int) (65.881+(77.717));

} else {
	tcb->m_cWnd = (int) (10.71/17.79);
	segmentsAcked = (int) (57.477+(22.352)+(54.257));

}
ReduceCwnd (tcb);
segmentsAcked = (int) ((74.607-(segmentsAcked)-(47.514))/41.853);
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_segmentSize = (int) (44.2+(39.752)+(59.297)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(segmentsAcked)+(86.715));

} else {
	tcb->m_segmentSize = (int) (41.079+(36.93)+(70.638));
	tcb->m_cWnd = (int) (21.861*(80.797)*(tcb->m_cWnd)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (28.234+(32.141)+(85.326));

}
tcb->m_segmentSize = (int) (86.267/-96.83);
tcb->m_segmentSize = (int) (37.855-(-39.835)-(-19.127));
