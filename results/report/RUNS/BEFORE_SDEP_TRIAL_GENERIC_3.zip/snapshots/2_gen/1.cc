if (tcb->m_cWnd != segmentsAcked) {
	segmentsAcked = (int) (tcb->m_cWnd-(16.584)-(87.114)-(37.641));

} else {
	segmentsAcked = (int) (19.5/4.37);

}
if (segmentsAcked > tcb->m_cWnd) {
	segmentsAcked = (int) (39.432+(71.221)+(51.438));

} else {
	segmentsAcked = (int) (78.407-(95.817)-(85.414)-(34.221));
	segmentsAcked = (int) (36.151+(92.277)+(42.776)+(segmentsAcked));
	segmentsAcked = (int) (tcb->m_cWnd*(53.385)*(13.194));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-24.328-(-2.838));
CongestionAvoidance (tcb, segmentsAcked);
