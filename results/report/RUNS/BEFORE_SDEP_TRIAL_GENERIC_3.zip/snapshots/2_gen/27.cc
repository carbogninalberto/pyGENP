if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (79.998*(28.227));

} else {
	tcb->m_cWnd = (int) (10.64/2.91);

}
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (24.036+(tcb->m_cWnd)+(62.191));
	segmentsAcked = (int) (tcb->m_segmentSize-(55.315)-(58.592)-(6.086));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (93.604-(segmentsAcked)-(2.792)-(41.949));
	tcb->m_cWnd = (int) (93.51-(44.07)-(14.938)-(14.337));

}
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (55.375*(25.373)*(58.51));
	tcb->m_cWnd = (int) (29.435*(81.272)*(40.121)*(28.464));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(40.974)-(6.256));

} else {
	tcb->m_segmentSize = (int) (59.961*(81.058)*(tcb->m_cWnd));

}
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (55.375*(25.373)*(58.51));
	tcb->m_cWnd = (int) (29.435*(81.272)*(40.121)*(28.464));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(40.974)-(6.256));

} else {
	tcb->m_segmentSize = (int) (59.961*(81.058)*(tcb->m_cWnd));

}
if (segmentsAcked > tcb->m_cWnd) {
	segmentsAcked = (int) (10.1/5.86);

} else {
	segmentsAcked = (int) (90.174-(28.971)-(66.76));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (segmentsAcked > tcb->m_cWnd) {
	segmentsAcked = (int) (10.1/5.86);

} else {
	segmentsAcked = (int) (90.174-(28.971)-(66.76));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = (int) (-97.579-(-76.599)-(-72.022));
segmentsAcked = (int) (48.377-(-72.0)-(-44.449));
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((segmentsAcked+(47.566)+(segmentsAcked)+(27.247))/4.64);

} else {
	tcb->m_segmentSize = (int) (95.796*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(79.732));
	tcb->m_cWnd = (int) (segmentsAcked-(segmentsAcked)-(24.436)-(55.66));

}
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((segmentsAcked+(47.566)+(segmentsAcked)+(27.247))/4.64);

} else {
	tcb->m_segmentSize = (int) (95.796*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(79.732));
	tcb->m_cWnd = (int) (segmentsAcked-(segmentsAcked)-(24.436)-(55.66));

}
