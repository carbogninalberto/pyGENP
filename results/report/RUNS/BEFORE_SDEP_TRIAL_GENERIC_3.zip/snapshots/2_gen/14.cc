if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (68.944+(7.609)+(59.228));

} else {
	tcb->m_cWnd = (int) (66.915*(segmentsAcked));

}
if (segmentsAcked > tcb->m_cWnd) {
	segmentsAcked = (int) (39.432+(71.221)+(51.438));

} else {
	segmentsAcked = (int) (78.407-(95.817)-(85.414)-(34.221));
	segmentsAcked = (int) (36.151+(92.277)+(42.776)+(segmentsAcked));
	segmentsAcked = (int) (tcb->m_cWnd*(53.385)*(13.194));

}
if (segmentsAcked > tcb->m_cWnd) {
	segmentsAcked = (int) (39.432+(71.221)+(51.438));

} else {
	segmentsAcked = (int) (78.407-(95.817)-(85.414)-(34.221));
	segmentsAcked = (int) (36.151+(92.277)+(42.776)+(segmentsAcked));
	segmentsAcked = (int) (tcb->m_cWnd*(53.385)*(13.194));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-1.586-(-96.063));
tcb->m_segmentSize = (int) (-90.409-(-26.781));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
