if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (18.156+(65.309)+(66.922));

} else {
	tcb->m_segmentSize = (int) (38.116*(81.556));

}
if (segmentsAcked > tcb->m_cWnd) {
	segmentsAcked = (int) (39.432+(71.221)+(51.438));

} else {
	segmentsAcked = (int) (78.407-(95.817)-(85.414)-(34.221));
	segmentsAcked = (int) (36.151+(92.277)+(42.776)+(segmentsAcked));
	segmentsAcked = (int) (tcb->m_cWnd*(53.385)*(13.194));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-28.406-(95.344));
tcb->m_segmentSize = (int) (-90.04-(-90.099));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
