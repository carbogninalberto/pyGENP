float qeVwLaxPEOYPIOxP = (float) (6.737*(40.815)*(-48.378)*(-48.203));
int IrovkEcFBEdEXCQX = (int) (-85.958/60.319);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
IrovkEcFBEdEXCQX = (int) (-90.997+(11.646));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-13.256*(-93.288)*(-6.694));
ReduceCwnd (tcb);
IrovkEcFBEdEXCQX = (int) (98.414*(-47.202)*(-97.228));
