if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (64.397*(95.026)*(23.992)*(97.039));

} else {
	tcb->m_cWnd = (int) (57.237+(43.034)+(14.241));

}
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (24.036+(tcb->m_cWnd)+(62.191));
	segmentsAcked = (int) (tcb->m_segmentSize-(55.315)-(58.592)-(6.086));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (93.604-(segmentsAcked)-(2.792)-(41.949));
	tcb->m_cWnd = (int) (93.51-(44.07)-(14.938)-(14.337));

}
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (55.375*(25.373)*(58.51));
	tcb->m_cWnd = (int) (29.435*(81.272)*(40.121)*(28.464));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(40.974)-(6.256));

} else {
	tcb->m_segmentSize = (int) (59.961*(81.058)*(tcb->m_cWnd));

}
if (segmentsAcked > tcb->m_cWnd) {
	segmentsAcked = (int) (10.1/5.86);

} else {
	segmentsAcked = (int) (90.174-(28.971)-(66.76));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (55.375*(25.373)*(58.51));
	tcb->m_cWnd = (int) (29.435*(81.272)*(40.121)*(28.464));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(40.974)-(6.256));

} else {
	tcb->m_segmentSize = (int) (59.961*(81.058)*(tcb->m_cWnd));

}
segmentsAcked = (int) (2.915-(6.263)-(72.339));
if (segmentsAcked > tcb->m_cWnd) {
	segmentsAcked = (int) (10.1/5.86);

} else {
	segmentsAcked = (int) (90.174-(28.971)-(66.76));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((segmentsAcked+(47.566)+(segmentsAcked)+(27.247))/4.64);

} else {
	tcb->m_segmentSize = (int) (95.796*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(79.732));
	tcb->m_cWnd = (int) (segmentsAcked-(segmentsAcked)-(24.436)-(55.66));

}
segmentsAcked = (int) (-73.071-(-43.557)-(87.909));
segmentsAcked = (int) (96.318-(-84.824)-(85.34));
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((segmentsAcked+(47.566)+(segmentsAcked)+(27.247))/4.64);

} else {
	tcb->m_segmentSize = (int) (95.796*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(79.732));
	tcb->m_cWnd = (int) (segmentsAcked-(segmentsAcked)-(24.436)-(55.66));

}
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((segmentsAcked+(47.566)+(segmentsAcked)+(27.247))/4.64);

} else {
	tcb->m_segmentSize = (int) (95.796*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(79.732));
	tcb->m_cWnd = (int) (segmentsAcked-(segmentsAcked)-(24.436)-(55.66));

}
