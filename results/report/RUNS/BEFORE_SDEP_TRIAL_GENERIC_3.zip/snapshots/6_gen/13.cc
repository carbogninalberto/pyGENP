float qeVwLaxPEOYPIOxP = (float) (-12.524+(-11.554)+(-90.56)+(97.755));
int IrovkEcFBEdEXCQX = (int) (-25.971/-17.016);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-61.347*(-91.184)*(34.98));
ReduceCwnd (tcb);
IrovkEcFBEdEXCQX = (int) (77.438+(6.998));
IrovkEcFBEdEXCQX = (int) (-57.009*(89.736)*(-93.175));
tcb->m_cWnd = (int) (12.814*(89.762)*(43.57));
IrovkEcFBEdEXCQX = (int) (25.547*(56.924)*(44.156));
