float hJnVzfXXjadwJsNl = (float) (-47.583/(-58.348*(94.531)*(-70.969)*(48.259)*(-3.691)));
float HTIBoTNgkKVDUUxz = (float) (-98.451/(93.768*(98.323)*(-5.934)*(69.919)));
tcb->m_cWnd = (int) (-15.129/89.626);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
