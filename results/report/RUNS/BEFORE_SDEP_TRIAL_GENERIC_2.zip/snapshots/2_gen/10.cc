int hgZVAQpAEmSZcXQw = (int) (73.506-(-99.418)-(99.664)-(-77.524));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
float krGeZcWNThNOYPYu = (float) (44.811-(53.598));
float pGXVBaIfCWexSiXV = (float) (24.078-(74.98)-(73.478)-(-15.378)-(59.26));
