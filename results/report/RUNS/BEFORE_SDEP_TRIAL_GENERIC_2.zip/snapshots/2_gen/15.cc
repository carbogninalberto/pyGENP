int hgZVAQpAEmSZcXQw = (int) (23.905-(-21.619)-(-58.575)-(10.099));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
float krGeZcWNThNOYPYu = (float) (-4.866-(36.834));
float pGXVBaIfCWexSiXV = (float) (-66.279-(87.369)-(-79.087)-(-43.455)-(-25.962));
