int hgZVAQpAEmSZcXQw = (int) (-77.959-(7.801)-(-57.288)-(-55.894));
CongestionAvoidance (tcb, segmentsAcked);
float krGeZcWNThNOYPYu = (float) (49.675-(-21.248));
float pGXVBaIfCWexSiXV = (float) (12.021-(-67.406)-(-40.802)-(-41.112)-(-94.102));
