float hJnVzfXXjadwJsNl = (float) (97.577/(81.561*(-15.107)*(26.74)*(-89.463)*(52.231)));
float HTIBoTNgkKVDUUxz = (float) (-67.975/(13.686*(1.62)*(-49.193)*(18.25)));
HTIBoTNgkKVDUUxz = (float) (-40.29+(62.877)+(79.517)+(-56.321));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
