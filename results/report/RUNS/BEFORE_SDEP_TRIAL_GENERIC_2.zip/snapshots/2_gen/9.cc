float hJnVzfXXjadwJsNl = (float) (55.684/(59.265*(-99.806)*(-80.096)*(-23.166)*(47.112)));
float HTIBoTNgkKVDUUxz = (float) (65.076/(58.231*(-32.134)*(-28.183)*(85.459)));
tcb->m_cWnd = (int) (-39.696/33.263);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
