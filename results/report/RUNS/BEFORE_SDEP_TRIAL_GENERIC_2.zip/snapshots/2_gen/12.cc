int hgZVAQpAEmSZcXQw = (int) (63.536-(35.981)-(36.705)-(-88.738));
float krGeZcWNThNOYPYu = (float) (-66.956-(6.965));
float pGXVBaIfCWexSiXV = (float) (-20.601-(-84.146)-(-66.337)-(2.448)-(73.235));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
pGXVBaIfCWexSiXV = (float) (14.534+(-96.61)+(-91.648));
pGXVBaIfCWexSiXV = (float) (-38.536+(66.196)+(-42.154));
