int hgZVAQpAEmSZcXQw = (int) (-24.389-(41.596)-(-87.721)-(22.456));
float krGeZcWNThNOYPYu = (float) (-75.555-(97.983));
float pGXVBaIfCWexSiXV = (float) (15.44-(14.42)-(-58.68)-(91.692)-(25.823));
CongestionAvoidance (tcb, segmentsAcked);
pGXVBaIfCWexSiXV = (float) (98.543+(-8.222)+(6.262));
CongestionAvoidance (tcb, segmentsAcked);
pGXVBaIfCWexSiXV = (float) (-63.203+(39.513)+(8.83));
