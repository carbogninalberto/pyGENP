int hgZVAQpAEmSZcXQw = (int) (3.265-(-20.799)-(-57.562)-(68.282));
CongestionAvoidance (tcb, segmentsAcked);
float krGeZcWNThNOYPYu = (float) (-6.267-(-87.053));
float pGXVBaIfCWexSiXV = (float) (34.624-(-18.489)-(99.904)-(53.644)-(5.567));
pGXVBaIfCWexSiXV = (float) (-45.768+(-23.046)+(-9.671));
