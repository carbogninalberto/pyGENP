int hgZVAQpAEmSZcXQw = (int) (87.018-(64.553)-(-72.814)-(-97.799));
CongestionAvoidance (tcb, segmentsAcked);
float krGeZcWNThNOYPYu = (float) (11.408-(85.379));
float pGXVBaIfCWexSiXV = (float) (-50.303-(-99.461)-(1.28)-(-25.842)-(66.448));
pGXVBaIfCWexSiXV = (float) (-64.545+(-97.856)+(81.048));
