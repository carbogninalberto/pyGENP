float hJnVzfXXjadwJsNl = (float) (-65.868/(22.052*(-97.522)*(-51.557)*(-75.825)*(52.319)));
float HTIBoTNgkKVDUUxz = (float) (-65.454/(38.9*(-90.019)*(-66.005)*(65.156)));
tcb->m_cWnd = (int) (9.078/14.596);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
