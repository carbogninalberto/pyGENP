float hJnVzfXXjadwJsNl = (float) (-76.713/(56.821*(58.115)*(-23.748)*(-81.519)*(68.334)));
float HTIBoTNgkKVDUUxz = (float) (-9.941/(38.822*(88.808)*(-9.117)*(66.506)));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
