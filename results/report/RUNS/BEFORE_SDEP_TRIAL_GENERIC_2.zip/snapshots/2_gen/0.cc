float HTIBoTNgkKVDUUxz = (float) (-26.805/(12.229*(23.198)*(75.71)*(81.068)));
tcb->m_cWnd = (int) (44.871/-45.855);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
