float hJnVzfXXjadwJsNl = (float) (36.6/(23.203*(92.883)*(15.728)*(-33.015)*(-11.103)));
float HTIBoTNgkKVDUUxz = (float) (97.077/(19.109*(52.63)*(-92.499)*(-74.557)));
tcb->m_cWnd = (int) (-42.208/33.671);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
