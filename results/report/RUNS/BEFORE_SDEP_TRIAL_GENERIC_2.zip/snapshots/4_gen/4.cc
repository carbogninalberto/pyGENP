CongestionAvoidance (tcb, segmentsAcked);
float HTIBoTNgkKVDUUxz = (float) (-92.106/(31.898*(97.062)*(14.454)*(-42.435)));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
