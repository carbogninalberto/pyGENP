int hgZVAQpAEmSZcXQw = (int) (68.028-(46.628)-(79.544)-(-72.479));
CongestionAvoidance (tcb, segmentsAcked);
float krGeZcWNThNOYPYu = (float) (-13.031-(-69.902));
CongestionAvoidance (tcb, segmentsAcked);
float pGXVBaIfCWexSiXV = (float) (-95.633-(-48.306)-(33.803)-(33.932)-(-82.861));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
