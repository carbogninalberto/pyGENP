int hgZVAQpAEmSZcXQw = (int) (78.438-(-12.5)-(-76.204)-(-48.124));
CongestionAvoidance (tcb, segmentsAcked);
float krGeZcWNThNOYPYu = (float) (47.585-(-37.096));
float pGXVBaIfCWexSiXV = (float) (-23.622-(50.775)-(-59.268)-(1.974)-(-81.093));
