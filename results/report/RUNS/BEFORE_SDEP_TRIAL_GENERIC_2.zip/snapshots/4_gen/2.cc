int hgZVAQpAEmSZcXQw = (int) (5.79-(-61.843)-(-91.117)-(-78.916));
CongestionAvoidance (tcb, segmentsAcked);
float krGeZcWNThNOYPYu = (float) (32.024-(40.588));
float pGXVBaIfCWexSiXV = (float) (36.942-(67.103)-(-53.762)-(84.147)-(-38.174));
pGXVBaIfCWexSiXV = (float) (22.383+(-0.609)+(-4.262));
