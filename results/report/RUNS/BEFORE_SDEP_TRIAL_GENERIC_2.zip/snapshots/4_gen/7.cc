float hJnVzfXXjadwJsNl = (float) (-94.553/(-78.566*(9.902)*(81.413)*(15.241)*(-41.58)));
float HTIBoTNgkKVDUUxz = (float) (-30.738/(-16.013*(-2.458)*(-60.064)*(84.88)));
tcb->m_cWnd = (int) (61.065/63.024);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
