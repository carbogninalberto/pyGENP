int hgZVAQpAEmSZcXQw = (int) (19.462-(65.678)-(-55.181)-(-25.335));
CongestionAvoidance (tcb, segmentsAcked);
float krGeZcWNThNOYPYu = (float) (-96.636-(55.751));
CongestionAvoidance (tcb, segmentsAcked);
float pGXVBaIfCWexSiXV = (float) (-78.32-(-97.175)-(71.318)-(42.166)-(-14.61));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
