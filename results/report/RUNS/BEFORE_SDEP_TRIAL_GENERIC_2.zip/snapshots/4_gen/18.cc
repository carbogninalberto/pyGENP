float hJnVzfXXjadwJsNl = (float) (-59.738/(-4.028*(-72.173)*(54.796)*(-32.149)*(59.851)));
float HTIBoTNgkKVDUUxz = (float) (61.902/(-83.654*(72.499)*(-78.432)*(38.864)));
tcb->m_cWnd = (int) (-51.983/-89.522);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
