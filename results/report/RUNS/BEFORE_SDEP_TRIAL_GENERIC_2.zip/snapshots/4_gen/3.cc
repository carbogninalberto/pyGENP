float HTIBoTNgkKVDUUxz = (float) (62.473/(72.945*(-47.735)*(24.504)*(56.662)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float hJnVzfXXjadwJsNl = (float) (25.111/(7.961*(69.61)*(26.792)*(51.382)*(-65.454)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
