int hgZVAQpAEmSZcXQw = (int) (-71.833-(-24.418)-(82.507)-(-89.89));
CongestionAvoidance (tcb, segmentsAcked);
float krGeZcWNThNOYPYu = (float) (86.27-(-7.8));
CongestionAvoidance (tcb, segmentsAcked);
float pGXVBaIfCWexSiXV = (float) (40.614-(-50.727)-(-58.627)-(11.748)-(-43.946));
