CongestionAvoidance (tcb, segmentsAcked);
float HTIBoTNgkKVDUUxz = (float) (68.267/(93.29*(98.183)*(71.337)*(-38.785)));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
