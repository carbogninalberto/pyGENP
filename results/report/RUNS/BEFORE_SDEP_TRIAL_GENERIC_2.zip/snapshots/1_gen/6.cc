int jqXwRCijRDVrZUHD = (int) (58.254*(93.276)*(79.547)*(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd > tcb->m_cWnd) {
	jqXwRCijRDVrZUHD = (int) (0.1/0.1);

} else {
	jqXwRCijRDVrZUHD = (int) (82.069*(69.248)*(66.322)*(95.718));

}
jqXwRCijRDVrZUHD = (int) (81.548/0.1);
int RyINzhhSSPSKsiod = (int) (11.332*(4.001)*(66.018));
