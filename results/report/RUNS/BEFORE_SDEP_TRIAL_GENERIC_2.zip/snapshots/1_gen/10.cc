TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
int ohaDCPPzchUxmeCl = (int) (98.143/0.1);
tcb->m_segmentSize = (int) (32.958+(24.691)+(23.135));
segmentsAcked = (int) (83.225+(tcb->m_cWnd));
