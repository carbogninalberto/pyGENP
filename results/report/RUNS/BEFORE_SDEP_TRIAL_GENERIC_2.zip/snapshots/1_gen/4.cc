segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (5.079-(0.872)-(93.565));
int LHRTYHWvLLyDFYAd = (int) (0.1/0.1);
segmentsAcked = (int) (92.813+(2.129));
tcb->m_segmentSize = (int) (62.76/9.568);
