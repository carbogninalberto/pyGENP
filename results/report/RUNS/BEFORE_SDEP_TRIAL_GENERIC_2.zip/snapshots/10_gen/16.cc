float HTIBoTNgkKVDUUxz = (float) (-41.977/(-89.222*(38.457)*(-28.174)*(-88.865)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float hJnVzfXXjadwJsNl = (float) (80.224/(-93.57*(-24.814)*(-47.744)*(-70.545)*(84.443)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (hJnVzfXXjadwJsNl != tcb->m_cWnd) {
	segmentsAcked = (int) (15.837+(segmentsAcked)+(45.017));

} else {
	segmentsAcked = (int) (50.979-(11.645)-(76.437)-(56.109));
	CongestionAvoidance (tcb, segmentsAcked);
	HTIBoTNgkKVDUUxz = (float) (75.046+(1.584)+(23.872));

}
if (hJnVzfXXjadwJsNl != tcb->m_cWnd) {
	segmentsAcked = (int) (15.837+(segmentsAcked)+(45.017));

} else {
	segmentsAcked = (int) (50.979-(11.645)-(76.437)-(56.109));
	CongestionAvoidance (tcb, segmentsAcked);
	HTIBoTNgkKVDUUxz = (float) (75.046+(1.584)+(23.872));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
