float HTIBoTNgkKVDUUxz = (float) (-25.873/(63.487*(-70.149)*(-78.631)*(92.705)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float hJnVzfXXjadwJsNl = (float) (71.729/(-50.227*(2.673)*(88.324)*(-23.02)*(46.54)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (hJnVzfXXjadwJsNl != tcb->m_cWnd) {
	segmentsAcked = (int) (15.837+(segmentsAcked)+(45.017));

} else {
	segmentsAcked = (int) (50.979-(11.645)-(76.437)-(56.109));
	CongestionAvoidance (tcb, segmentsAcked);
	HTIBoTNgkKVDUUxz = (float) (75.046+(1.584)+(23.872));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
