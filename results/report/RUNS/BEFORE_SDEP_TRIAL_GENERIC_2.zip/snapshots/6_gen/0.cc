int hgZVAQpAEmSZcXQw = (int) (22.659-(-69.093)-(46.053)-(66.745));
CongestionAvoidance (tcb, segmentsAcked);
float krGeZcWNThNOYPYu = (float) (78.601-(60.801));
CongestionAvoidance (tcb, segmentsAcked);
float pGXVBaIfCWexSiXV = (float) (-52.098-(92.067)-(47.123)-(93.533)-(-20.604));
