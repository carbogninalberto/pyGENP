float pGXVBaIfCWexSiXV = (float) (80.683-(-46.353)-(31.051)-(-4.53)-(-20.664));
float krGeZcWNThNOYPYu = (float) (-58.304-(19.269));
CongestionAvoidance (tcb, segmentsAcked);
int hgZVAQpAEmSZcXQw = (int) (-42.7-(-64.967)-(-61.035)-(91.887));
pGXVBaIfCWexSiXV = (float) (-76.065+(44.147)+(-44.739));
