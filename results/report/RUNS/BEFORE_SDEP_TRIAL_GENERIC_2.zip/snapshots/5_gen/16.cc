float pGXVBaIfCWexSiXV = (float) (75.356-(41.307)-(25.117)-(11.693)-(-15.767));
float krGeZcWNThNOYPYu = (float) (26.944-(46.337));
CongestionAvoidance (tcb, segmentsAcked);
int hgZVAQpAEmSZcXQw = (int) (18.151-(1.05)-(-13.603)-(-9.912));
pGXVBaIfCWexSiXV = (float) (-32.747+(85.477)+(-28.518));
pGXVBaIfCWexSiXV = (float) (5.536+(71.976)+(-81.532));
