float HTIBoTNgkKVDUUxz = (float) (33.532/(68.561*(88.447)*(10.123)*(-83.722)));
float hJnVzfXXjadwJsNl = (float) (-19.898/(34.692*(-59.437)*(22.237)*(-86.115)*(81.197)));
