float hJnVzfXXjadwJsNl = (float) (-80.182/(-16.996*(49.097)*(-27.117)*(0.109)*(48.016)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float HTIBoTNgkKVDUUxz = (float) (-49.85/(-21.366*(-85.024)*(68.211)*(-95.54)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (hJnVzfXXjadwJsNl != tcb->m_cWnd) {
	segmentsAcked = (int) (15.837+(segmentsAcked)+(45.017));

} else {
	segmentsAcked = (int) (50.979-(11.645)-(76.437)-(56.109));
	CongestionAvoidance (tcb, segmentsAcked);
	HTIBoTNgkKVDUUxz = (float) (75.046+(1.584)+(23.872));

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
