float pGXVBaIfCWexSiXV = (float) (-51.018-(-30.115)-(-8.693)-(-86.982)-(31.536));
float krGeZcWNThNOYPYu = (float) (-80.562-(24.149));
CongestionAvoidance (tcb, segmentsAcked);
int hgZVAQpAEmSZcXQw = (int) (-9.737-(71.935)-(42.484)-(-97.838));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
