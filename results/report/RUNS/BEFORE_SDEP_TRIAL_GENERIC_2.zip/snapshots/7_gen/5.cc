float hJnVzfXXjadwJsNl = (float) (81.412/(7.043*(80.967)*(36.02)*(-21.093)*(-38.115)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float HTIBoTNgkKVDUUxz = (float) (-50.055/(-80.178*(-66.162)*(85.366)*(9.43)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (hJnVzfXXjadwJsNl != tcb->m_cWnd) {
	segmentsAcked = (int) (15.837+(segmentsAcked)+(45.017));

} else {
	segmentsAcked = (int) (50.979-(11.645)-(76.437)-(56.109));
	CongestionAvoidance (tcb, segmentsAcked);
	HTIBoTNgkKVDUUxz = (float) (75.046+(1.584)+(23.872));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
