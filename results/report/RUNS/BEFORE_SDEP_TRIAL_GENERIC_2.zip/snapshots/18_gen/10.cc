float hJnVzfXXjadwJsNl = (float) (-1.171/(33.246*(-88.081)*(97.991)*(-55.519)*(48.92)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float HTIBoTNgkKVDUUxz = (float) (-31.075/(-19.161*(-26.841)*(76.333)*(68.163)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (hJnVzfXXjadwJsNl != tcb->m_cWnd) {
	segmentsAcked = (int) (15.837+(segmentsAcked)+(45.017));

} else {
	segmentsAcked = (int) (50.979-(11.645)-(76.437)-(56.109));
	CongestionAvoidance (tcb, segmentsAcked);
	HTIBoTNgkKVDUUxz = (float) (75.046+(1.584)+(23.872));

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (hJnVzfXXjadwJsNl != tcb->m_cWnd) {
	segmentsAcked = (int) (15.837+(segmentsAcked)+(45.017));

} else {
	segmentsAcked = (int) (50.979-(11.645)-(76.437)-(56.109));
	CongestionAvoidance (tcb, segmentsAcked);
	HTIBoTNgkKVDUUxz = (float) (75.046+(1.584)+(23.872));

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (hJnVzfXXjadwJsNl != tcb->m_cWnd) {
	segmentsAcked = (int) (15.837+(segmentsAcked)+(45.017));

} else {
	segmentsAcked = (int) (50.979-(11.645)-(76.437)-(56.109));
	CongestionAvoidance (tcb, segmentsAcked);
	HTIBoTNgkKVDUUxz = (float) (75.046+(1.584)+(23.872));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (hJnVzfXXjadwJsNl != tcb->m_cWnd) {
	segmentsAcked = (int) (15.837+(segmentsAcked)+(45.017));

} else {
	segmentsAcked = (int) (50.979-(11.645)-(76.437)-(56.109));
	CongestionAvoidance (tcb, segmentsAcked);
	HTIBoTNgkKVDUUxz = (float) (75.046+(1.584)+(23.872));

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
