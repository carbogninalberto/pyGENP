float pGXVBaIfCWexSiXV = (float) (49.964-(-20.744)-(31.037)-(-86.399)-(-11.822));
float krGeZcWNThNOYPYu = (float) (-19.923-(-4.574));
CongestionAvoidance (tcb, segmentsAcked);
int hgZVAQpAEmSZcXQw = (int) (-13.616-(-66.187)-(-41.624)-(59.629));
pGXVBaIfCWexSiXV = (float) (-69.964+(-36.174)+(69.056));
pGXVBaIfCWexSiXV = (float) (77.458+(65.398)+(-31.853));
