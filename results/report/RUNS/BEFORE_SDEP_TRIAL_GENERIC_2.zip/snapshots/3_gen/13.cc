float pGXVBaIfCWexSiXV = (float) (82.154-(87.941)-(-48.193)-(9.995)-(77.258));
float krGeZcWNThNOYPYu = (float) (67.37-(-22.025));
int hgZVAQpAEmSZcXQw = (int) (-43.438-(-73.062)-(51.467)-(55.596));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
