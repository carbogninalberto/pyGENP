tcb->m_cWnd = (int) (75.979/-48.809);
float HTIBoTNgkKVDUUxz = (float) (40.915/(-74.904*(-83.21)*(-7.874)*(19.748)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float hJnVzfXXjadwJsNl = (float) (50.194/(-22.533*(-68.143)*(-24.37)*(56.31)*(3.723)));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
