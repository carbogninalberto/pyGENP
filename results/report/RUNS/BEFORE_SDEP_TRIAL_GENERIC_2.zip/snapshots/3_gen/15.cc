float pGXVBaIfCWexSiXV = (float) (37.904-(98.204)-(60.435)-(-59.054)-(-12.007));
float krGeZcWNThNOYPYu = (float) (-49.37-(56.002));
CongestionAvoidance (tcb, segmentsAcked);
int hgZVAQpAEmSZcXQw = (int) (94.893-(37.962)-(-50.651)-(-42.19));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
