float pGXVBaIfCWexSiXV = (float) (-25.802-(83.047)-(72.884)-(-95.341)-(-99.091));
float krGeZcWNThNOYPYu = (float) (98.83-(31.244));
CongestionAvoidance (tcb, segmentsAcked);
int hgZVAQpAEmSZcXQw = (int) (-5.87-(-91.076)-(-55.016)-(92.794));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
