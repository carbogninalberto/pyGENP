ReduceCwnd (tcb);
float HTIBoTNgkKVDUUxz = (float) (11.14/(57.963*(-10.498)*(62.557)*(-11.371)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float hJnVzfXXjadwJsNl = (float) (70.162/(-48.12*(80.539)*(-2.662)*(62.279)*(0.81)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
