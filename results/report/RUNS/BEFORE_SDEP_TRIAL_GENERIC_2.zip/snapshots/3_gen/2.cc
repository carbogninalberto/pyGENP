float HTIBoTNgkKVDUUxz = (float) (-17.748/(-29.466*(24.532)*(-1.042)*(42.976)));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
