float pGXVBaIfCWexSiXV = (float) (21.898-(21.919)-(-50.126)-(3.122)-(-97.778));
float krGeZcWNThNOYPYu = (float) (-96.738-(49.014));
int hgZVAQpAEmSZcXQw = (int) (-35.329-(-31.268)-(93.404)-(-81.046));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
