float pGXVBaIfCWexSiXV = (float) (95.575-(-11.412)-(55.598)-(-21.961)-(-80.473));
float krGeZcWNThNOYPYu = (float) (3.138-(-0.533));
CongestionAvoidance (tcb, segmentsAcked);
int hgZVAQpAEmSZcXQw = (int) (-99.004-(-88.992)-(-18.124)-(-64.951));
pGXVBaIfCWexSiXV = (float) (-63.304+(-56.216)+(9.201));
