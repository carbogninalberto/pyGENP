tcb->m_cWnd = (int) (-7.088/39.405);
float HTIBoTNgkKVDUUxz = (float) (-23.691/(-66.181*(-93.543)*(-51.354)*(64.727)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float hJnVzfXXjadwJsNl = (float) (0.997/(48.529*(-62.265)*(25.544)*(-8.447)*(-76.444)));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
