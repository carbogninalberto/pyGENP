tcb->m_cWnd = (int) (88.292/36.147);
float HTIBoTNgkKVDUUxz = (float) (64.1/(35.626*(-67.509)*(-89.569)*(-91.685)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float hJnVzfXXjadwJsNl = (float) (35.228/(-79.899*(89.604)*(-56.74)*(-50.539)*(78.668)));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
