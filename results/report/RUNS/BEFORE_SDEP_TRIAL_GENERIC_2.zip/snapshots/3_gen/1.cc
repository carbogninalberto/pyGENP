float pGXVBaIfCWexSiXV = (float) (-74.56-(-65.938)-(-19.91)-(61.716)-(25.758));
float krGeZcWNThNOYPYu = (float) (12.461-(-43.801));
CongestionAvoidance (tcb, segmentsAcked);
int hgZVAQpAEmSZcXQw = (int) (0.21-(86.343)-(-48.752)-(24.657));
CongestionAvoidance (tcb, segmentsAcked);
