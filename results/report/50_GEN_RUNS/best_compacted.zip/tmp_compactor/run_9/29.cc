tcb->m_cWnd = (int) (-40.233-(-71.071));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-69.353*(99.62)*(-87.254)*(-27.193)*(8.785)*(78.915));
