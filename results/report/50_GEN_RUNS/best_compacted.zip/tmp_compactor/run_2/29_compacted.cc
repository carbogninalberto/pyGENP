ReduceCwnd(tcb);
tcb->m_cWnd = (int)-143.684;

for (int i = 0; i < 5; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}

tcb->m_cWnd = (int)213.366;

for (int i = 0; i < 2; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}

ReduceCwnd(tcb);
tcb->m_cWnd = (int)8.89;

for (int i = 0; i < 2; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}

ReduceCwnd(tcb);
CongestionAvoidance(tcb, segmentsAcked);
ReduceCwnd(tcb);
CongestionAvoidance(tcb, segmentsAcked);
tcb->m_cWnd = (int)-119.466;
CongestionAvoidance(tcb, segmentsAcked);
ReduceCwnd(tcb);
CongestionAvoidance(tcb, segmentsAcked);
tcb->m_cWnd = (int)-6.656;
CongestionAvoidance(tcb, segmentsAcked);
tcb->m_cWnd = (int)136.828;

for (int i = 0; i < 3; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}

ReduceCwnd(tcb);
tcb->m_cWnd = (int)119.42;
tcb->m_cWnd = (int)-45.392;
CongestionAvoidance(tcb, segmentsAcked);
ReduceCwnd(tcb);

for (int i = 0; i < 3; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}

tcb->m_cWnd = (int)-138.632;

for (int i = 0; i < 3; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}

tcb->m_cWnd = (int)34.951;

for (int i = 0; i < 4; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}

ReduceCwnd(tcb);
CongestionAvoidance(tcb, segmentsAcked);
ReduceCwnd(tcb);
CongestionAvoidance(tcb, segmentsAcked);
tcb->m_cWnd = (int)23.469;
CongestionAvoidance(tcb, segmentsAcked);
tcb->m_cWnd = (int)53.657;

for (int i = 0; i < 4; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}

ReduceCwnd(tcb);
ReduceCwnd(tcb);
tcb->m_cWnd = (int)-31.973;
tcb->m_cWnd = (int)55.57;

for (int i = 0; i < 2; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}
