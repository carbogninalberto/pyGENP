tcb->m_cWnd = (int)-81.23500000000001;
CongestionAvoidance(tcb, segmentsAcked);
tcb->m_cWnd = (int)-145.60100000000003;
tcb->m_cWnd = (int)58.627999999999986;

for (int i = 0; i < 10; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}
