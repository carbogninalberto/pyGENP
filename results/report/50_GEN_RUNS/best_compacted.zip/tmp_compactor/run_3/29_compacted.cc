tcb->m_cWnd = (int)-81.235;
CongestionAvoidance(tcb, segmentsAcked);
tcb->m_cWnd = (int)-145.601;
tcb->m_cWnd = (int)58.628;

for (int i = 0; i < 10; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}
