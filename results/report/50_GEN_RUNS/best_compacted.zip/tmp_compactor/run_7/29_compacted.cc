ReduceCwnd(tcb);
tcb->m_cWnd = (int)148.972287288;

for (int i = 0; i < 2; i++) {
    ReduceCwnd(tcb);
}

tcb->m_cWnd = (int)59655.58792731199;
tcb->m_cWnd = (int)-24937.009668044997;
ReduceCwnd(tcb);
tcb->m_cWnd = (int)40932.64322651;
