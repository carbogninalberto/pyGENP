ReduceCwnd(tcb);
tcb->m_cWnd = (int)148.972;

for (int i = 0; i < 2; i++) {
    ReduceCwnd(tcb);
}

tcb->m_cWnd = (int)59655.588;
tcb->m_cWnd = (int)-24937.01;
ReduceCwnd(tcb);
tcb->m_cWnd = (int)40932.643;
