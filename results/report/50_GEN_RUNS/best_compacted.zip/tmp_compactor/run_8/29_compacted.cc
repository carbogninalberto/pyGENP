if (tcb->m_segmentSize > tcb->m_ssThresh) {
    tcb->m_ssThresh = (int)1.0;
    ReduceCwnd(tcb);
} else {
    tcb->m_ssThresh = (int)35.63;
    tcb->m_ssThresh = (int)2706.001992;
}
tcb->m_segmentSize = (int)(85.733 - (56.436) - (tcb->m_ssThresh) - (92.142) - (70.956) - (6.654));
float hnPsxuBCtPVMMYBm = (float)(36.2 - (8.073) - (16.935) - (78.417) - (21.996) - (tcb->m_segmentSize));
if (tcb->m_segmentSize >= segmentsAcked) {
    segmentsAcked = (int)(hnPsxuBCtPVMMYBm * (68.195) * (tcb->m_cWnd) * (tcb->m_ssThresh) * (9.219) * (96.226) * (85.611) * (31.971) * (18.886));
    ReduceCwnd(tcb);
} else {
    segmentsAcked = (int)(72.07 - (tcb->m_ssThresh) - (segmentsAcked));
}
TcpLinuxCongestionAvoidance(tcb, segmentsAcked);
if (tcb->m_cWnd <= hnPsxuBCtPVMMYBm) {
    hnPsxuBCtPVMMYBm = (float)(92.554 - (74.251) - (81.969) - (27.667) - (segmentsAcked) - (54.344) - (64.616) - (12.799));
    segmentsAcked = SlowStart(tcb, segmentsAcked);
    tcb->m_cWnd = (int)(41.965 + (69.396) + (26.746) + (30.182) + (tcb->m_ssThresh) + (12.114) + (tcb->m_ssThresh));
} else {
    hnPsxuBCtPVMMYBm = (float)(tcb->m_segmentSize * 3643.109423);
    tcb->m_cWnd = (int)-34.452999999999996;
}

for (int i = 0; i < 2; i++) {
    TcpLinuxCongestionAvoidance(tcb, segmentsAcked);
}
