int tfgvYhmLLXZbeLLs = (int) (95.963*(-85.897)*(-70.142)*(-82.157)*(63.3));
segmentsAcked = (int) (-51.516-(-18.364)-(-59.395)-(-87.876)-(5.042)-(-66.194));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
