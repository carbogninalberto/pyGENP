tcb->m_cWnd = (int)62.777;
CongestionAvoidance(tcb, segmentsAcked);
segmentsAcked = SlowStart(tcb, segmentsAcked);

for (int i = 0; i < 2; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}

segmentsAcked = SlowStart(tcb, segmentsAcked);
segmentsAcked = SlowStart(tcb, segmentsAcked);
CongestionAvoidance(tcb, segmentsAcked);
