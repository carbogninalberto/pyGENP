tcb->m_cWnd = (int)(-39.406 - (-80.702) - (-66.878) - (0.17) - (16.673) - (-75.966) - (91.987) - (-52.287) - (64.82));
CongestionAvoidance(tcb, segmentsAcked);
segmentsAcked = SlowStart(tcb, segmentsAcked);
CongestionAvoidance(tcb, segmentsAcked);
CongestionAvoidance(tcb, segmentsAcked);
segmentsAcked = SlowStart(tcb, segmentsAcked);
segmentsAcked = SlowStart(tcb, segmentsAcked);
CongestionAvoidance(tcb, segmentsAcked);
