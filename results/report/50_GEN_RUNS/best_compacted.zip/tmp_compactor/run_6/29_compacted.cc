tcb->m_cWnd = (int)1.0949999999999989;
tcb->m_cWnd = (int)-78.928;
tcb->m_cWnd = (int)-119.97399999999999;
tcb->m_cWnd = (int)-99.755;
tcb->m_cWnd = (int)55.819;
tcb->m_cWnd = (int)58.471000000000004;

for (int i = 0; i < 18; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}
