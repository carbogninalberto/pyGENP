tcb->m_cWnd = (int)1.095;
tcb->m_cWnd = (int)-78.928;
tcb->m_cWnd = (int)-119.974;
tcb->m_cWnd = (int)-99.755;
tcb->m_cWnd = (int)55.819;
tcb->m_cWnd = (int)58.471;

for (int i = 0; i < 18; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}
