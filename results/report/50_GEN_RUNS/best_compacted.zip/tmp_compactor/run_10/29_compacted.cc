tcb->m_cWnd = (int)1.712;
CongestionAvoidance(tcb, segmentsAcked);
tcb->m_cWnd = (int)-33.446;
segmentsAcked = (int)143.941;

for (int i = 0; i < 2; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}

tcb->m_cWnd = (int)-154.343;
segmentsAcked = (int)-88.614;

for (int i = 0; i < 3; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}

tcb->m_cWnd = (int)55.225;
segmentsAcked = (int)-182.114;
CongestionAvoidance(tcb, segmentsAcked);
