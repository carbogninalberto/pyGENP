tcb->m_cWnd = (int)(((20.466) + (-80.968) + (19.101) + (-97.306)) / ((-75.757) + (79.193) + (-84.461)));
CongestionAvoidance(tcb, segmentsAcked);
tcb->m_cWnd = (int)-33.44599999999999;
segmentsAcked = (int)143.94099999999997;

for (int i = 0; i < 2; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}

tcb->m_cWnd = (int)-154.34300000000002;
segmentsAcked = (int)-88.61399999999998;

for (int i = 0; i < 3; i++) {
    CongestionAvoidance(tcb, segmentsAcked);
}

tcb->m_cWnd = (int)55.225;
segmentsAcked = (int)-182.11399999999998;
CongestionAvoidance(tcb, segmentsAcked);
