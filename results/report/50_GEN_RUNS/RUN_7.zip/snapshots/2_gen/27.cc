float lVqLxKfjymUBnqZd = (float) (31.784*(-36.589)*(-47.913)*(-89.594));
float uIakZQwfMrdAtzWF = (float) (49.439+(20.283)+(0.57)+(-50.568));
float uEuYqAkcmFoXLHrL = (float) (-57.999-(30.173)-(5.447)-(-28.694)-(95.732));
segmentsAcked = (int) (-2.521+(52.636)+(46.644)+(93.454)+(66.744)+(94.474)+(-72.305)+(32.192));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
