CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-97.412+(-68.378)+(-18.198)+(-90.655)+(9.083)+(84.609)+(84.818));
segmentsAcked = (int) (-13.669+(-14.556)+(81.548)+(-55.298)+(35.47)+(33.113)+(68.162));
segmentsAcked = (int) (6.052+(-44.249)+(-32.539)+(-72.527)+(-72.943)+(-5.754)+(-87.227));
segmentsAcked = (int) (44.184+(-53.679)+(-66.681)+(-69.036)+(17.36)+(80.264)+(-33.616));
