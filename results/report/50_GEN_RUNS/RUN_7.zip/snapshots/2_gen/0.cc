segmentsAcked = (int) (-62.893-(56.965)-(14.974)-(36.027));
int aDpMtodwIchEycMr = (int) (63.931*(-62.179)*(-14.043)*(59.372)*(-44.892)*(-5.09)*(-50.931)*(-16.865));
CongestionAvoidance (tcb, segmentsAcked);
float lyFGAfkDCcmyRxaW = (float) (-66.156-(18.441)-(-76.943)-(95.861)-(-39.154));
