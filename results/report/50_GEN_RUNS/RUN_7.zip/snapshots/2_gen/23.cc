int qlNZNDtQGxNfrjwG = (int) 87.39;
float rHkqwdERcOuQnHtS = (float) 56.258;
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (50.243+(17.337)+(61.435)+(66.762)+(55.171)+(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (1.447-(89.652)-(94.854)-(24.082)-(-19.742));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (1.447-(89.652)-(94.854)-(24.082)-(-19.742));

} else {
	tcb->m_cWnd = (int) (50.243+(17.337)+(61.435)+(66.762)+(55.171)+(tcb->m_cWnd));

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
qlNZNDtQGxNfrjwG = (int) (((-32.381)+(56.582)+((5.26*(95.333)*(88.288)*(38.707)))+((-57.107-(80.313)-(77.676)-(40.772)-(tcb->m_ssThresh)-(-35.335)-(-59.063)-(segmentsAcked)))+(-16.191))/((-45.888)+(-30.897)+(-97.281)+(16.694)));
ReduceCwnd (tcb);
qlNZNDtQGxNfrjwG = (int) (((-96.789)+(66.531)+((55.076*(-25.634)*(74.1)*(-6.398)))+((-47.106-(-77.186)-(14.13)-(-47.606)-(tcb->m_ssThresh)-(-96.741)-(95.567)-(segmentsAcked)))+(-23.062))/((-95.264)+(71.439)+(36.992)+(90.457)));
