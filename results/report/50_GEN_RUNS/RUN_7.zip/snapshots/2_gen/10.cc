float rHkqwdERcOuQnHtS = (float) 32.7;
