float rHkqwdERcOuQnHtS = (float) 56.258;
