segmentsAcked = (int) (99.682/25.933);
int QXykfgSZsoVVlLmE = (int) 42.287;
if (QXykfgSZsoVVlLmE < QXykfgSZsoVVlLmE) {
	tcb->m_segmentSize = (int) (44.433-(30.886)-(tcb->m_cWnd)-(18.919)-(43.998)-(29.97)-(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (64.248*(53.178)*(77.516)*(9.736)*(45.216)*(QXykfgSZsoVVlLmE));
	tcb->m_segmentSize = (int) (57.996+(1.983)+(QXykfgSZsoVVlLmE)+(QXykfgSZsoVVlLmE));

}
