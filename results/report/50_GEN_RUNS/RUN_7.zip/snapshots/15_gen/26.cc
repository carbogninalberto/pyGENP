ReduceCwnd (tcb);
int zSKvQtPPvLYcFSWO = (int) (76.364*(74.023)*(98.723)*(19.507)*(68.749)*(12.033)*(segmentsAcked)*(80.238)*(29.22));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
zSKvQtPPvLYcFSWO = (int) (32.021*(45.616)*(77.485));
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (35.801+(94.008)+(tcb->m_ssThresh)+(96.659)+(86.532)+(tcb->m_cWnd)+(18.665));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (64.124-(15.08));

}
ReduceCwnd (tcb);
