TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int JEFopnQsUajIYcSG = (int) (0.1/11.481);
int XQwFmeJVsdkDIfUh = (int) (tcb->m_segmentSize-(93.522)-(93.064));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (49.344*(67.109)*(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (XQwFmeJVsdkDIfUh+(8.217)+(tcb->m_ssThresh)+(50.042)+(81.713));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
