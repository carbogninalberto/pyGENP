float lLZrSPXhZaZMFCtK = (float) (-33.548/-17.245);
float pPKBJPBSqDJqIkOg = (float) (-21.14+(-81.202)+(-60.357)+(40.294)+(-61.478));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (lLZrSPXhZaZMFCtK-(98.384)-(13.713)-(21.464)-(60.882));
	ReduceCwnd (tcb);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (90.618-(65.471)-(25.291)-(53.165));
	segmentsAcked = (int) (90.419-(13.181));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-77.77*(48.746)*(8.0)*(-18.086)*(-56.531)*(83.549)*(1.845)*(50.767));
