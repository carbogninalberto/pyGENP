TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (55.622-(64.096)-(-23.432)-(63.455)-(25.256)-(-7.219));
tcb->m_cWnd = (int) (92.336-(10.121)-(-24.518)-(-8.765)-(-83.505)-(-82.179));
float uPjeBikGPduoFGGk = (float) (33.191-(-69.669)-(-18.073)-(-0.931)-(-96.554));
int IBqPRFEUobXHLmoG = (int) (-92.354/-40.592);
