CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (39.856/91.321);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(71.363)*(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (((33.415)+(0.1)+(0.1)+((12.498+(50.76)+(43.997)+(tcb->m_cWnd)))+(0.1)+(66.664))/((0.1)));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
