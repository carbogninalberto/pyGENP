segmentsAcked = (int) (-47.273+(-50.092)+(-53.383)+(33.795)+(-51.91)+(58.864)+(63.099)+(-27.511)+(-80.784));
int VyPxaCBDSOFABnMs = (int) (45.533+(52.881)+(-49.98)+(-28.852));
tcb->m_segmentSize = (int) (80.796-(-90.96));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (VyPxaCBDSOFABnMs <= VyPxaCBDSOFABnMs) {
	segmentsAcked = (int) (0.403-(0.261)-(97.327)-(27.757)-(46.643));
	VyPxaCBDSOFABnMs = (int) (15.138-(VyPxaCBDSOFABnMs)-(36.659)-(10.253));

} else {
	segmentsAcked = (int) (46.134+(94.027)+(38.265)+(94.712)+(20.727)+(VyPxaCBDSOFABnMs));
	tcb->m_segmentSize = (int) (90.825+(45.056)+(77.962)+(21.062)+(84.977)+(39.311));
	tcb->m_cWnd = (int) ((segmentsAcked-(segmentsAcked)-(tcb->m_ssThresh)-(56.246)-(tcb->m_cWnd)-(29.788)-(66.779)-(43.395))/0.1);

}
if (tcb->m_cWnd == segmentsAcked) {
	VyPxaCBDSOFABnMs = (int) (63.667*(27.884)*(6.058)*(38.107)*(80.421)*(23.456)*(97.397)*(54.339)*(23.189));
	VyPxaCBDSOFABnMs = (int) (56.341*(73.677)*(8.815)*(75.149)*(42.926)*(40.359));

} else {
	VyPxaCBDSOFABnMs = (int) (9.963*(tcb->m_cWnd)*(72.504)*(73.543)*(44.54)*(29.51)*(10.148)*(0.446));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
