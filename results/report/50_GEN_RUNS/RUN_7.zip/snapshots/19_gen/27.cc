tcb->m_cWnd = (int) (59.321-(56.891)-(26.685));
tcb->m_segmentSize = (int) (60.493*(65.056)*(25.759)*(47.564)*(29.401));
segmentsAcked = (int) (91.752+(segmentsAcked)+(78.968)+(segmentsAcked)+(52.232)+(16.122)+(67.138));
tcb->m_ssThresh = (int) (60.777*(93.875)*(83.795)*(tcb->m_ssThresh)*(23.323)*(tcb->m_cWnd)*(54.23)*(50.563));
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(33.015)-(90.036)-(33.642)-(tcb->m_segmentSize)-(29.08)-(43.177)-(95.497));
