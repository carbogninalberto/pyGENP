if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(66.638)*(tcb->m_ssThresh)*(38.812)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(18.22));

} else {
	tcb->m_cWnd = (int) (98.985+(61.373)+(28.212)+(90.6)+(50.059)+(36.173));
	segmentsAcked = (int) (36.572-(91.362)-(60.245)-(65.746)-(42.958)-(81.977));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (34.867-(3.77)-(26.907)-(tcb->m_ssThresh)-(70.97));
tcb->m_cWnd = (int) (tcb->m_cWnd-(97.037));
tcb->m_segmentSize = (int) (50.934-(23.0)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(40.884)-(82.655)-(tcb->m_ssThresh));
