segmentsAcked = (int) (-40.322/-85.371);
segmentsAcked = (int) (44.672+(-98.403)+(29.107)+(42.323)+(-24.274));
segmentsAcked = (int) (-30.688*(85.485));
segmentsAcked = (int) (-64.266*(-85.894));
segmentsAcked = (int) (58.244*(-12.54)*(42.701)*(15.362)*(38.419)*(-55.872));
