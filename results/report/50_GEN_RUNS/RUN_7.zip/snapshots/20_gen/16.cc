if (segmentsAcked >= tcb->m_segmentSize) {
	segmentsAcked = (int) (29.411+(64.002)+(8.543)+(80.09)+(42.191)+(tcb->m_cWnd)+(10.154)+(1.369));

} else {
	segmentsAcked = (int) (44.846-(2.168)-(60.938)-(tcb->m_segmentSize));

}
if (segmentsAcked <= segmentsAcked) {
	tcb->m_cWnd = (int) (70.555+(20.098)+(35.795)+(95.685)+(72.561)+(segmentsAcked)+(5.45)+(segmentsAcked)+(31.083));
	tcb->m_segmentSize = (int) (81.922+(42.719)+(91.477)+(61.21));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(51.764));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(tcb->m_segmentSize)*(15.432)*(tcb->m_segmentSize)*(49.237)*(46.01));
	tcb->m_ssThresh = (int) (21.719*(81.24)*(42.183)*(44.854));

}
tcb->m_ssThresh = (int) ((((segmentsAcked+(72.287)+(5.962)+(segmentsAcked)+(tcb->m_ssThresh)+(56.64)+(18.188)+(15.775)))+(53.575)+(0.1)+(0.1))/((70.273)+(40.74)+(1.624)+(0.1)+(35.039)));
segmentsAcked = (int) (71.514-(50.096)-(42.325)-(20.9)-(35.143)-(50.392));
segmentsAcked = (int) (7.166*(tcb->m_segmentSize)*(89.771)*(84.797)*(21.188)*(5.962)*(78.009));
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(85.458)*(tcb->m_segmentSize)*(5.741)*(96.357)*(74.846)*(12.31));
