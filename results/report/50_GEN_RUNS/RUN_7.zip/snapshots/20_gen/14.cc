if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (segmentsAcked+(81.507)+(16.47)+(9.032));
	segmentsAcked = (int) (73.138-(18.454)-(18.356)-(64.179)-(tcb->m_segmentSize)-(96.067)-(23.911));
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(36.964)-(31.719)-(44.751)-(67.252)-(8.494)-(tcb->m_ssThresh)-(91.788));

} else {
	tcb->m_cWnd = (int) (46.606*(tcb->m_ssThresh));
	segmentsAcked = (int) (72.182*(13.001)*(90.255)*(segmentsAcked)*(22.389)*(27.544)*(20.617));

}
ReduceCwnd (tcb);
int XqJPmCCgyYDrJvHs = (int) (7.54*(24.323));
int bTOAjSQrdwZEwBtn = (int) (82.689+(76.377)+(41.87));
if (tcb->m_segmentSize > segmentsAcked) {
	bTOAjSQrdwZEwBtn = (int) (77.189*(44.756)*(tcb->m_segmentSize)*(25.183)*(5.788)*(XqJPmCCgyYDrJvHs)*(tcb->m_ssThresh));
	segmentsAcked = (int) (74.537-(4.655)-(38.168)-(36.807)-(96.798));

} else {
	bTOAjSQrdwZEwBtn = (int) (73.724*(90.481)*(46.545)*(bTOAjSQrdwZEwBtn)*(28.51)*(42.532)*(74.875)*(48.965));
	tcb->m_ssThresh = (int) (71.222+(17.377)+(32.587)+(7.445)+(16.419));
	bTOAjSQrdwZEwBtn = (int) (64.117-(24.14)-(63.26)-(80.206)-(12.076)-(84.944)-(bTOAjSQrdwZEwBtn));

}
