CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (59.745*(15.266)*(34.331)*(34.019)*(68.398)*(tcb->m_segmentSize)*(32.303)*(tcb->m_ssThresh)*(tcb->m_cWnd));
tcb->m_ssThresh = (int) (54.674-(61.213)-(60.337)-(94.494)-(29.545));
CongestionAvoidance (tcb, segmentsAcked);
