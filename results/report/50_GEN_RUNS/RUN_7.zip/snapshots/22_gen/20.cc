if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (10.058+(5.007)+(62.574)+(tcb->m_cWnd)+(75.771)+(47.189));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (28.418-(28.563)-(7.498)-(3.081));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(segmentsAcked)-(3.461)-(71.326));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (54.369-(11.152));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (46.906*(83.311)*(69.796)*(12.62)*(35.232));
segmentsAcked = (int) (tcb->m_cWnd+(tcb->m_cWnd)+(tcb->m_ssThresh));
segmentsAcked = SlowStart (tcb, segmentsAcked);
