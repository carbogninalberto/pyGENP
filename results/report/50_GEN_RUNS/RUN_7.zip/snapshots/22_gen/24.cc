segmentsAcked = (int) (15.675/12.317);
segmentsAcked = (int) (95.852*(53.455)*(11.829)*(20.756)*(72.89)*(14.763)*(79.55)*(tcb->m_cWnd));
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (4.933/0.1);
	tcb->m_ssThresh = (int) (22.469+(23.505)+(93.304)+(20.34)+(55.704)+(17.841));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (22.229-(58.17)-(tcb->m_ssThresh)-(96.667)-(tcb->m_ssThresh)-(76.277)-(30.664)-(12.337));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (89.349/0.1);

} else {
	tcb->m_ssThresh = (int) (58.803-(81.304)-(67.917));

}
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (57.092*(95.742));
	tcb->m_segmentSize = (int) (27.431*(tcb->m_cWnd)*(52.311));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (30.635*(8.158)*(1.795)*(57.594)*(68.873)*(18.963)*(10.112));

}
