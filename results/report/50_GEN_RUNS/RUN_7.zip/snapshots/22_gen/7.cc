CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (4.618-(41.677)-(44.03)-(38.572)-(80.156)-(tcb->m_segmentSize));
tcb->m_ssThresh = (int) (75.702-(69.946));
tcb->m_cWnd = (int) (81.281/5.156);
float SghINnXaXqlqRFps = (float) (72.92*(tcb->m_ssThresh)*(64.864)*(5.695));
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	SghINnXaXqlqRFps = (float) ((((38.262+(38.62)+(2.904)+(96.511)))+(73.585)+(0.1)+(34.073))/((96.074)+(0.1)+(74.63)+(0.1)));
	tcb->m_cWnd = (int) (80.215+(94.683)+(SghINnXaXqlqRFps));
	segmentsAcked = (int) (30.59+(89.541)+(16.822)+(SghINnXaXqlqRFps)+(30.836)+(60.666)+(93.277)+(20.644));

} else {
	SghINnXaXqlqRFps = (float) (12.292-(52.689)-(91.228)-(89.99));
	SghINnXaXqlqRFps = (float) (23.127-(27.015)-(30.132));
	segmentsAcked = (int) ((((24.51*(4.724)*(97.421)))+(88.402)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

}
