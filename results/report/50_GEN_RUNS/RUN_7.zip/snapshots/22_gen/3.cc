tcb->m_cWnd = (int) (-40.883/-81.629);
if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(10.369)*(tcb->m_cWnd)*(92.256)*(12.456)*(55.578));

} else {
	segmentsAcked = (int) (0.1/0.1);

}
tcb->m_cWnd = (int) (47.91*(-13.136)*(60.648)*(96.457)*(-59.64)*(-7.286)*(-70.726)*(6.877));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (0.081+(-49.385)+(-62.27)+(47.239)+(-58.635)+(97.921));
