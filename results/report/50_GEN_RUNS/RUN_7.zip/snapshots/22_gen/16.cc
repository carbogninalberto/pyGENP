int PSJXTEpFHcbaVuRl = (int) (16.303*(40.343)*(tcb->m_ssThresh)*(64.688)*(26.076)*(69.096)*(68.085)*(12.278));
int syzdqiCqraQcmvvM = (int) (45.449+(64.491));
if (PSJXTEpFHcbaVuRl < tcb->m_segmentSize) {
	segmentsAcked = (int) (12.929-(1.117)-(37.554)-(97.338)-(39.092));
	syzdqiCqraQcmvvM = (int) (16.912-(76.916)-(13.056)-(21.534)-(PSJXTEpFHcbaVuRl)-(95.834)-(63.244)-(11.316)-(68.773));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (93.017-(36.198)-(6.316)-(tcb->m_cWnd)-(24.443)-(65.006)-(27.498)-(77.423)-(23.465));
	PSJXTEpFHcbaVuRl = (int) (54.712-(3.75)-(82.206)-(53.555)-(syzdqiCqraQcmvvM));

}
PSJXTEpFHcbaVuRl = (int) (49.635+(95.38)+(segmentsAcked)+(70.169)+(59.91));
tcb->m_ssThresh = (int) (6.764-(44.651)-(75.073)-(39.273)-(21.221)-(99.759)-(26.595)-(syzdqiCqraQcmvvM)-(PSJXTEpFHcbaVuRl));
