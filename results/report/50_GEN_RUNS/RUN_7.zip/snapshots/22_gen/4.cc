if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (((0.1)+(99.594)+((93.869-(31.979)-(36.713)-(57.821)-(75.368)-(43.427)))+((44.375+(5.637)+(tcb->m_cWnd)+(tcb->m_ssThresh)))+(50.548)+(1.827)+(77.212))/((21.973)));

} else {
	segmentsAcked = (int) (32.016*(70.111)*(98.012)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(tcb->m_cWnd));
	segmentsAcked = (int) (6.132*(tcb->m_cWnd)*(76.465)*(5.405)*(44.224)*(4.354)*(98.018));

}
