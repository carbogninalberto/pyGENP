tcb->m_cWnd = (int) (14.021+(tcb->m_segmentSize)+(76.995)+(91.454)+(79.371));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	segmentsAcked = (int) (8.894+(segmentsAcked)+(72.427));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) ((((79.058-(23.29)-(23.638)-(23.749)))+(0.1)+(62.376)+(77.018)+(3.554)+(0.1)+((44.959-(36.808)))+(31.515))/((50.748)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (43.075+(18.14)+(75.199)+(23.693)+(16.388)+(60.032));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (((59.947)+(0.1)+(0.1)+(0.1)+(21.031))/((0.1)));
tcb->m_segmentSize = (int) (94.389-(26.649)-(6.656)-(71.814)-(82.323)-(45.802));
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(89.654));
	tcb->m_cWnd = (int) (38.264/77.924);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (21.929*(0.326)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(segmentsAcked)*(46.066)*(12.645));

}
