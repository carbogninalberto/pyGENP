if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/93.139);
	tcb->m_segmentSize = (int) (70.738+(74.874)+(segmentsAcked)+(71.268)+(40.296)+(62.834)+(14.798));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (8.453/0.1);

}
float nSISNfoVQRJtKucD = (float) (29.72/63.473);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
