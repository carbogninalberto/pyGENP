segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_cWnd-(93.15)-(41.815)-(41.572)-(61.442));
tcb->m_ssThresh = (int) (37.507+(tcb->m_ssThresh)+(80.524)+(81.149)+(46.608)+(44.932)+(24.856)+(segmentsAcked));
tcb->m_cWnd = (int) (((79.887)+(0.1)+((tcb->m_ssThresh+(tcb->m_segmentSize)))+(0.1)+(35.919))/((98.615)+(55.822)+(40.823)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((54.143+(6.015)+(55.7)+(93.839)+(67.18)+(26.881)+(tcb->m_segmentSize)+(73.474))/0.1);
