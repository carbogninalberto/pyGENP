if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (1.17-(76.571)-(34.989)-(tcb->m_ssThresh)-(66.399));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (0.4*(3.894)*(90.061)*(35.339)*(65.732)*(14.137));

}
tcb->m_segmentSize = (int) (5.857*(55.869)*(segmentsAcked)*(84.671));
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (54.375/0.1);
	segmentsAcked = (int) (83.447-(51.041)-(28.553)-(59.818)-(94.758)-(16.801)-(54.481)-(segmentsAcked));
	tcb->m_segmentSize = (int) (32.919*(56.799)*(78.3)*(76.509)*(89.455)*(88.439)*(tcb->m_ssThresh)*(segmentsAcked)*(88.417));

} else {
	tcb->m_segmentSize = (int) (51.35-(23.893)-(33.114)-(57.545)-(65.812)-(48.92)-(65.039)-(62.156));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (31.132+(19.203)+(7.021)+(49.264)+(23.54)+(81.412)+(72.997));
