if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(60.021)+(5.218)+(tcb->m_ssThresh)+(59.362)+(88.715)+(2.555));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(55.823)-(0.416)-(94.078)-(34.37)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(17.41));
	segmentsAcked = (int) (tcb->m_cWnd-(76.608)-(51.901)-(82.437)-(60.86)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(25.867));
	tcb->m_cWnd = (int) (74.389+(82.943)+(83.001)+(tcb->m_cWnd)+(90.874)+(22.056)+(25.627));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (97.714*(28.15));
	tcb->m_cWnd = (int) (8.536+(tcb->m_ssThresh)+(43.108)+(49.41)+(64.559));

} else {
	tcb->m_cWnd = (int) ((76.853-(83.892)-(77.634)-(66.269)-(segmentsAcked)-(22.254)-(tcb->m_cWnd)-(68.58))/0.1);
	tcb->m_cWnd = (int) (18.572+(tcb->m_ssThresh)+(42.894)+(76.737));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
