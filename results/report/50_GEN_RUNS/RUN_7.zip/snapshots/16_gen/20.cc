if (tcb->m_segmentSize < tcb->m_segmentSize) {
	segmentsAcked = (int) (44.801/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (9.649*(84.944)*(tcb->m_segmentSize)*(76.111)*(95.592));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(48.106)*(15.86)*(22.039)*(65.342)*(tcb->m_cWnd)*(84.037));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (83.158+(36.158)+(tcb->m_ssThresh)+(57.079));
	ReduceCwnd (tcb);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int nrCeuylKZfYfPmMu = (int) (((14.13)+(0.1)+(2.583)+(31.054))/((52.567)+(3.969)+(98.391)+(6.68)+(51.748)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
