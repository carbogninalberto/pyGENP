ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_segmentSize+(32.89)+(48.623)+(33.526)+(49.471)+(4.159)+(tcb->m_cWnd)+(10.897));
	segmentsAcked = (int) (61.304/0.1);

} else {
	segmentsAcked = (int) (69.798-(28.874)-(64.549));
	CongestionAvoidance (tcb, segmentsAcked);

}
float BwpSVJpTxSflOLsy = (float) (((0.1)+(0.1)+(10.938)+(0.1)+(0.1)+((4.681*(29.419)*(35.359)*(tcb->m_cWnd)*(88.223)*(41.801)*(32.486)*(55.086)))+(0.1))/((0.1)+(0.1)));
