tcb->m_segmentSize = (int) (89.502*(52.68));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (98.285*(85.631)*(95.079)*(36.207)*(50.088)*(tcb->m_segmentSize)*(24.334));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
