TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) ((90.436*(8.958)*(40.956)*(98.82)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(79.496))/1.806);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (34.474-(tcb->m_segmentSize)-(55.247)-(18.968)-(57.795)-(43.253)-(tcb->m_cWnd));
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (18.221-(40.265)-(tcb->m_cWnd)-(segmentsAcked)-(3.73)-(tcb->m_cWnd)-(59.011)-(96.657));

} else {
	tcb->m_segmentSize = (int) (64.344*(65.335)*(6.663));

}
tcb->m_ssThresh = (int) (((49.241)+((67.048+(90.746)+(tcb->m_segmentSize)+(64.986)))+(38.68)+(13.214))/((0.1)+(0.1)+(71.217)+(54.204)));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(88.78)-(56.917)-(39.627)-(15.296)-(74.701)-(14.738)-(60.747));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (79.536+(37.752)+(19.931)+(tcb->m_segmentSize)+(94.895)+(69.082));

} else {
	tcb->m_ssThresh = (int) (10.556-(37.358)-(17.269)-(84.398)-(tcb->m_segmentSize));

}
