CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_cWnd = (int) (74.649+(87.585)+(7.074)+(92.568));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(82.245)+(26.484));
	tcb->m_segmentSize = (int) (27.45*(26.925)*(37.238)*(89.742)*(51.707)*(62.245)*(2.811));

}
segmentsAcked = (int) (66.479*(72.608)*(tcb->m_ssThresh)*(62.59)*(50.793)*(87.411)*(93.57));
tcb->m_ssThresh = (int) (46.683-(71.348)-(tcb->m_segmentSize)-(58.659)-(44.887)-(18.188)-(86.75)-(96.403));
if (segmentsAcked == segmentsAcked) {
	tcb->m_segmentSize = (int) (52.675-(82.848)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (44.879-(48.598)-(20.073)-(16.339)-(18.661)-(72.611)-(83.562));
	segmentsAcked = (int) (36.635/0.1);
	segmentsAcked = (int) (20.428*(66.319)*(48.582)*(tcb->m_segmentSize)*(23.134)*(tcb->m_segmentSize)*(82.791));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (23.664*(77.895)*(62.461)*(58.596));
