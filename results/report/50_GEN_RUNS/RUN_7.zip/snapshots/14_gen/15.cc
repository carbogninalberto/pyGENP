tcb->m_cWnd = (int) (88.509-(tcb->m_cWnd)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(19.949)-(61.064)-(70.884));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (97.557-(51.603)-(segmentsAcked)-(tcb->m_ssThresh));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (18.716*(17.339)*(96.408));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(89.425)+(39.779)+(70.304)+(94.361));
	segmentsAcked = (int) (13.744-(44.765)-(48.888)-(35.647)-(54.966)-(81.044)-(11.349)-(68.252));

}
tcb->m_ssThresh = (int) (67.095*(tcb->m_ssThresh)*(66.214)*(33.396)*(tcb->m_segmentSize)*(11.62)*(41.33));
tcb->m_cWnd = (int) (66.004+(tcb->m_cWnd)+(26.091)+(76.344)+(tcb->m_segmentSize));
tcb->m_ssThresh = (int) (25.833-(11.286)-(68.695)-(59.769)-(52.763)-(42.987)-(67.1));
