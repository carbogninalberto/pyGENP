tcb->m_ssThresh = (int) (tcb->m_segmentSize*(7.24)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(58.942)*(79.465));
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (29.575/0.1);

} else {
	tcb->m_cWnd = (int) (54.352+(91.18)+(61.499)+(24.859));
	tcb->m_segmentSize = (int) (96.809*(tcb->m_ssThresh)*(16.715)*(40.737)*(5.468)*(tcb->m_cWnd)*(24.702)*(23.088)*(50.058));
	segmentsAcked = (int) (((66.551)+(76.176)+(0.1)+(0.1)+(0.1)+(19.183))/((0.1)));

}
tcb->m_cWnd = (int) (31.743*(tcb->m_cWnd)*(96.496)*(36.895)*(27.695)*(83.972)*(55.593));
segmentsAcked = (int) (0.1/35.012);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (15.173/92.211);

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_ssThresh+(69.275)+(64.051));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (3.613*(59.757)*(22.449)*(19.024));
