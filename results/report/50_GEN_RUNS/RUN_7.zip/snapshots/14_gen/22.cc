tcb->m_segmentSize = (int) (91.265*(88.035)*(85.087));
tcb->m_cWnd = (int) (0.1/98.8);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (34.83*(tcb->m_segmentSize)*(segmentsAcked)*(tcb->m_segmentSize)*(18.478));
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (31.487-(10.981));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (85.574-(52.412)-(56.074));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (13.399+(51.949)+(37.896)+(30.687));
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (64.416+(segmentsAcked)+(22.353));

} else {
	tcb->m_cWnd = (int) ((58.75+(14.947)+(24.599))/0.1);

}
