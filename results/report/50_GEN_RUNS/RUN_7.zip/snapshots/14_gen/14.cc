ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (93.882-(92.441)-(97.481)-(3.881));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (0.1/(tcb->m_segmentSize-(13.121)-(7.613)-(tcb->m_cWnd)-(41.681)-(40.607)-(90.228)));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (83.383-(84.355)-(86.601)-(91.854)-(89.63));
	tcb->m_ssThresh = (int) (17.816-(0.468)-(80.331)-(9.131)-(83.804)-(32.157));
	tcb->m_cWnd = (int) (86.852+(72.452)+(75.896)+(81.587)+(87.131)+(92.995)+(segmentsAcked)+(35.003)+(19.017));

} else {
	tcb->m_cWnd = (int) (35.01+(87.116)+(83.029)+(6.349)+(75.108)+(63.34)+(tcb->m_ssThresh)+(87.29));

}
