tcb->m_segmentSize = (int) (1.892-(14.257)-(44.034)-(98.478)-(81.361)-(-19.422)-(88.071)-(-60.448));
tcb->m_cWnd = (int) (92.657-(95.114)-(69.892)-(-84.124)-(-13.352)-(4.084));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-88.834-(-37.198)-(77.286)-(-31.05)-(-62.366)-(-5.205));
