segmentsAcked = (int) (tcb->m_ssThresh+(82.3)+(30.3)+(45.232)+(15.16)+(49.803)+(3.29)+(38.683)+(29.105));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (76.298*(tcb->m_segmentSize)*(11.546)*(99.526)*(52.287)*(21.402));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (14.756+(5.363)+(83.352)+(73.677)+(24.272));
ReduceCwnd (tcb);
