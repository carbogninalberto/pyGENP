CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-31.434/(39.758+(-57.938)+(-6.097)+(tcb->m_ssThresh)+(-4.0)));
CongestionAvoidance (tcb, segmentsAcked);
