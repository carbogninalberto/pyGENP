CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (16.269+(18.109)+(12.4)+(59.734));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (39.142*(46.969)*(43.596));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (tcb->m_segmentSize+(58.715)+(tcb->m_ssThresh)+(tcb->m_cWnd));
