if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_cWnd = (int) (25.596-(73.534));
	segmentsAcked = (int) (33.953-(66.759));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(tcb->m_ssThresh));

}
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	segmentsAcked = (int) (90.714+(0.3)+(46.639));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (1.249-(42.658)-(segmentsAcked)-(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
segmentsAcked = (int) (13.02/0.1);
segmentsAcked = (int) (9.958-(77.0)-(88.264)-(96.821)-(11.27)-(30.164)-(22.836)-(89.038));
