float NpquKTzodSUfiZQW = (float) ((6.049*(73.933))/0.1);
segmentsAcked = (int) (2.628+(78.319)+(tcb->m_cWnd));
NpquKTzodSUfiZQW = (float) (88.459*(66.735)*(42.074)*(tcb->m_ssThresh));
if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (NpquKTzodSUfiZQW+(64.511)+(75.029));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (67.979+(20.271)+(51.737)+(20.822)+(76.782));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) ((((segmentsAcked*(21.781)*(tcb->m_segmentSize)*(32.642)))+(0.1)+(99.72)+(43.043)+(0.1)+(5.945))/((18.16)+(74.002)));
