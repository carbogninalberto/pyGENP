ReduceCwnd (tcb);
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (76.55*(tcb->m_ssThresh)*(94.727)*(21.682));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (14.973+(41.618)+(62.388));
	tcb->m_ssThresh = (int) (2.573-(73.93)-(86.97)-(44.201)-(33.368)-(95.194)-(tcb->m_ssThresh)-(7.831)-(34.449));
	segmentsAcked = (int) (73.982+(74.628)+(66.91)+(98.95)+(segmentsAcked));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_segmentSize-(12.84)-(28.343)-(tcb->m_cWnd));
tcb->m_cWnd = (int) (69.465/48.749);
tcb->m_segmentSize = (int) (56.198*(70.756));
