int iTCJAULrYNcaMmTx = (int) (-34.552-(74.67)-(-39.683)-(84.191)-(59.14)-(-33.207));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-36.872+(-39.608)+(82.421)+(-99.848));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
