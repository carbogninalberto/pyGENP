ReduceCwnd (tcb);
int nIcrZxZtmUxnvhfM = (int) (69.445-(62.898)-(46.549)-(35.885)-(99.055));
nIcrZxZtmUxnvhfM = (int) (0.1/0.1);
tcb->m_cWnd = (int) (17.178*(38.307));
tcb->m_ssThresh = (int) (83.535*(67.158));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_cWnd <= nIcrZxZtmUxnvhfM) {
	segmentsAcked = (int) (segmentsAcked+(89.151)+(tcb->m_ssThresh)+(20.743));
	tcb->m_ssThresh = (int) ((2.688*(9.633)*(0.793)*(37.123)*(segmentsAcked))/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (nIcrZxZtmUxnvhfM-(96.914)-(97.92)-(86.461)-(37.156)-(67.905)-(tcb->m_cWnd)-(99.915)-(72.603));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) ((54.603+(69.751)+(76.75))/0.1);

}
