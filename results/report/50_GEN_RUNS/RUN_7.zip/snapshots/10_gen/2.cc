if (segmentsAcked == segmentsAcked) {
	segmentsAcked = (int) (84.025*(62.549));

} else {
	segmentsAcked = (int) (78.9+(60.823)+(68.504)+(tcb->m_segmentSize)+(44.995)+(52.934)+(44.013)+(11.858));
	segmentsAcked = (int) (tcb->m_segmentSize+(80.619)+(67.645)+(tcb->m_cWnd)+(0.063)+(2.055)+(38.632)+(30.598)+(segmentsAcked));
	tcb->m_segmentSize = (int) (72.571-(segmentsAcked)-(78.028)-(23.577)-(-42.752)-(32.344));

}
tcb->m_segmentSize = (int) (-82.747-(68.214)-(-30.795)-(89.112)-(-57.235)-(25.337)-(-44.523));
tcb->m_cWnd = (int) (-49.183*(-87.117)*(-96.028));
tcb->m_segmentSize = (int) (7.972*(-39.344)*(82.343));
