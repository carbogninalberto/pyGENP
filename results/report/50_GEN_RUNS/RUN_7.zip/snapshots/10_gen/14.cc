CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	segmentsAcked = (int) (54.917/54.466);

} else {
	segmentsAcked = (int) (59.074-(1.389)-(92.882)-(79.136)-(15.615)-(94.15));
	tcb->m_segmentSize = (int) (9.757+(tcb->m_cWnd)+(13.643)+(56.272)+(26.287)+(89.399)+(tcb->m_ssThresh)+(2.156));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (segmentsAcked*(61.406)*(33.432)*(0.282));

} else {
	segmentsAcked = (int) (69.164*(segmentsAcked)*(40.604)*(71.895)*(84.795)*(41.073));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (10.849*(92.949)*(41.885)*(54.662)*(21.008)*(segmentsAcked)*(56.058));

}
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	segmentsAcked = (int) (44.782+(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) (78.7/0.1);
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (52.03*(10.194));
	ReduceCwnd (tcb);

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != segmentsAcked) {
	segmentsAcked = (int) (0.1/60.559);
	tcb->m_cWnd = (int) (50.214/0.1);

} else {
	segmentsAcked = (int) (0.1/58.008);

}
