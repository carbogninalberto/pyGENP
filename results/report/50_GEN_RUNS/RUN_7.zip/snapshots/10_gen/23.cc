segmentsAcked = (int) (tcb->m_cWnd-(5.151)-(81.597)-(78.371)-(68.294)-(38.687)-(segmentsAcked)-(42.649)-(85.339));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) ((71.539*(52.827)*(25.163))/0.1);
