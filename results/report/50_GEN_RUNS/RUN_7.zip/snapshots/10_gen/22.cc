int aVSuFSPBGeoFLtuo = (int) (19.868+(43.01)+(43.211)+(77.856)+(tcb->m_cWnd)+(49.318));
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_ssThresh = (int) (98.345-(61.553)-(41.178)-(3.43));
	aVSuFSPBGeoFLtuo = (int) (segmentsAcked*(44.243)*(tcb->m_ssThresh)*(10.69)*(87.642)*(7.944)*(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (46.067+(8.343)+(tcb->m_ssThresh)+(39.334)+(tcb->m_cWnd)+(76.901)+(92.852)+(45.947));

} else {
	tcb->m_ssThresh = (int) (38.732+(tcb->m_cWnd));

}
tcb->m_segmentSize = (int) (88.469/2.736);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (47.559-(22.664)-(34.441));
	segmentsAcked = (int) (72.492+(tcb->m_segmentSize)+(47.125)+(11.764)+(26.232)+(38.746)+(33.902)+(52.054));
	tcb->m_segmentSize = (int) (37.829-(1.298)-(34.354)-(91.003)-(47.242)-(49.818)-(1.773)-(24.453)-(aVSuFSPBGeoFLtuo));

} else {
	tcb->m_cWnd = (int) (8.39*(tcb->m_segmentSize));
	segmentsAcked = (int) (2.357+(tcb->m_cWnd));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
