if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (24.803+(89.543)+(71.689)+(19.212)+(31.66)+(tcb->m_ssThresh)+(38.217)+(83.908)+(43.671));
	tcb->m_segmentSize = (int) (29.75-(97.448)-(55.173)-(tcb->m_ssThresh)-(53.417)-(44.971)-(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(59.163));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(70.728)-(88.442)-(7.05)-(79.945)-(tcb->m_cWnd)-(42.289));

}
tcb->m_cWnd = (int) (78.575-(7.196)-(65.663)-(tcb->m_ssThresh)-(34.869));
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(segmentsAcked)*(39.252)*(95.062)*(tcb->m_cWnd)*(92.47));

} else {
	tcb->m_segmentSize = (int) (15.344+(41.005)+(0.881)+(segmentsAcked)+(74.574)+(81.97)+(50.46)+(31.41));
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (80.168-(77.401)-(86.085)-(26.605)-(88.966)-(22.119)-(38.364)-(75.267)-(17.876));

} else {
	tcb->m_cWnd = (int) (83.515+(tcb->m_segmentSize)+(52.584)+(73.576));
	tcb->m_segmentSize = (int) (0.1/0.1);
	segmentsAcked = (int) ((((85.695+(tcb->m_cWnd)+(96.523)+(95.122)+(3.431)+(81.735)+(58.251)+(67.661)+(tcb->m_segmentSize)))+(0.1)+(11.669)+(0.1)+(97.253)+((18.385+(24.977)+(14.881)+(17.238)+(14.673)+(17.773)+(67.358)))+(0.1))/((0.1)));

}
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	segmentsAcked = (int) (80.601+(85.087)+(30.341)+(13.464)+(30.92)+(24.972)+(73.925)+(tcb->m_segmentSize));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (69.433*(4.479)*(38.945)*(7.994)*(43.815)*(segmentsAcked)*(tcb->m_cWnd)*(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (80.505*(60.473)*(35.024)*(84.629)*(9.075));

}
