int BrdEzfTOOUDctDGY = (int) (3.919-(69.996)-(9.151)-(12.894)-(77.234)-(71.928));
tcb->m_cWnd = (int) (7.758*(44.502)*(94.095)*(94.951)*(BrdEzfTOOUDctDGY)*(78.101)*(55.671));
if (tcb->m_ssThresh <= BrdEzfTOOUDctDGY) {
	tcb->m_segmentSize = (int) (82.633*(38.934)*(13.632)*(tcb->m_ssThresh)*(79.573)*(44.063)*(BrdEzfTOOUDctDGY)*(tcb->m_segmentSize)*(39.871));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (41.161+(tcb->m_cWnd)+(51.443)+(48.524)+(88.336));

} else {
	tcb->m_segmentSize = (int) (0.1/34.99);
	tcb->m_ssThresh = (int) (segmentsAcked+(37.981)+(6.461)+(82.185)+(53.937)+(22.779)+(25.284));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (BrdEzfTOOUDctDGY <= segmentsAcked) {
	BrdEzfTOOUDctDGY = (int) (87.174/62.6);
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (94.546*(85.161));

} else {
	BrdEzfTOOUDctDGY = (int) (66.081-(55.325)-(45.658)-(12.46)-(97.031)-(89.062)-(62.459));
	segmentsAcked = (int) (79.919-(84.304)-(57.549)-(23.126)-(tcb->m_segmentSize)-(93.244)-(90.804)-(BrdEzfTOOUDctDGY)-(63.965));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.779-(BrdEzfTOOUDctDGY)-(35.551)-(28.162)-(64.742));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(64.316)-(5.787)-(85.135)-(46.916)-(BrdEzfTOOUDctDGY)-(93.077));
	segmentsAcked = (int) (71.107/0.1);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
