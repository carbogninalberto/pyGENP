ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (83.442+(52.493)+(3.422)+(tcb->m_ssThresh)+(38.145)+(77.941));
tcb->m_cWnd = (int) (26.704+(98.911)+(37.216)+(24.612)+(segmentsAcked)+(16.548)+(segmentsAcked)+(26.744));
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (84.384-(9.588)-(88.728)-(51.036));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (96.497*(44.566));

} else {
	tcb->m_cWnd = (int) (68.917+(8.029)+(7.302)+(80.35)+(33.177));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (29.582/0.1);
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_segmentSize = (int) (95.778-(52.231)-(tcb->m_ssThresh)-(66.866)-(17.249)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (18.701*(6.749)*(85.527)*(tcb->m_segmentSize)*(31.201)*(57.327)*(tcb->m_segmentSize)*(43.195));
	tcb->m_ssThresh = (int) (46.952*(tcb->m_segmentSize)*(50.316));

}
