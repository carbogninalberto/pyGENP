segmentsAcked = (int) (89.592/58.26);
tcb->m_segmentSize = (int) (tcb->m_ssThresh-(2.307)-(91.138)-(24.483)-(28.311)-(78.517)-(43.995)-(19.578)-(tcb->m_ssThresh));
int VpHxCmiTfhZPlSRV = (int) (1.291+(55.98)+(56.634)+(tcb->m_ssThresh));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (15.23+(99.979)+(segmentsAcked)+(93.288));
	segmentsAcked = (int) (80.587/49.303);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (((40.21)+((12.049*(tcb->m_segmentSize)*(80.378)*(40.286)*(64.878)*(83.312)*(58.918)*(tcb->m_cWnd)*(59.56)))+(0.1)+(0.1)+(0.1)+(80.309))/((23.284)+(0.1)));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(segmentsAcked)-(96.392));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (((91.225)+(0.1)+((tcb->m_segmentSize*(3.664)))+(37.746))/((47.0)+(85.186)+(0.1)));
	tcb->m_cWnd = (int) (79.519-(45.197)-(83.993));

}
if (tcb->m_cWnd <= VpHxCmiTfhZPlSRV) {
	tcb->m_segmentSize = (int) (54.171-(56.561)-(0.34)-(35.587)-(50.995)-(35.522)-(62.042)-(22.947)-(15.127));
	tcb->m_segmentSize = (int) (89.287+(62.803)+(89.967)+(tcb->m_cWnd)+(49.443)+(72.237)+(VpHxCmiTfhZPlSRV));

} else {
	tcb->m_segmentSize = (int) (41.083*(55.533)*(53.573)*(41.491)*(1.45)*(50.962)*(32.142));

}
int wBFLiuyrxoWQvUKh = (int) (0.1/79.056);
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	VpHxCmiTfhZPlSRV = (int) ((((83.283-(34.622)-(tcb->m_cWnd)-(58.658)-(65.381)-(wBFLiuyrxoWQvUKh)))+(93.434)+(72.042)+(63.217)+(14.836)+(0.1)+(0.1))/((7.498)));
	tcb->m_cWnd = (int) (39.696-(6.89)-(tcb->m_cWnd)-(93.253)-(61.823));

} else {
	VpHxCmiTfhZPlSRV = (int) (((0.1)+(95.686)+(1.522)+(0.1)+(46.824)+(0.1)+((7.796-(49.625)-(20.205)-(49.787)-(39.353)))+(0.1))/((10.081)));
	tcb->m_ssThresh = (int) (54.237+(62.042)+(44.2)+(14.344)+(63.434)+(29.263)+(92.421)+(segmentsAcked)+(1.731));

}
