if (segmentsAcked != segmentsAcked) {
	segmentsAcked = (int) (4.589-(18.567)-(70.9));
	tcb->m_ssThresh = (int) ((((tcb->m_ssThresh*(tcb->m_cWnd)*(segmentsAcked)*(94.823)*(90.392)*(45.376)*(tcb->m_cWnd)*(88.937)))+(75.305)+(0.1)+(0.1))/((99.572)+(42.629)+(84.547)+(0.1)+(83.123)));
	tcb->m_cWnd = (int) (69.799*(20.544)*(43.937)*(91.92)*(43.082)*(20.586)*(98.441)*(9.215));

} else {
	segmentsAcked = (int) (87.189+(75.972)+(39.662));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
