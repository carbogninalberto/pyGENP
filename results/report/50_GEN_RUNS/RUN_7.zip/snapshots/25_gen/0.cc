float sbQkBZaJnOSqcBPT = (float) (-11.803/-49.801);
int kjJOjvsCSiHhMtLG = (int) (20.883-(-26.346)-(-36.35)-(-80.289));
float TADZajfxYychdnlq = (float) 56.229;
TADZajfxYychdnlq = (float) ((tcb->m_segmentSize-(81.218)-(70.153)-(-95.993)-(89.828)-(-10.292))/-87.283);
segmentsAcked = SlowStart (tcb, segmentsAcked);
