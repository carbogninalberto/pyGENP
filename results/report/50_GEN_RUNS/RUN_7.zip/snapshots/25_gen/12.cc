if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((tcb->m_segmentSize*(tcb->m_ssThresh)*(59.144)*(20.388)*(42.061))/0.1);

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(24.269)+(78.863)+(74.582)+(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (95.669-(17.551));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_ssThresh = (int) (88.505*(23.89)*(31.925));

} else {
	tcb->m_ssThresh = (int) (50.142+(88.304)+(tcb->m_segmentSize)+(53.515));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
