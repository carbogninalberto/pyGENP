tcb->m_segmentSize = (int) (86.238-(89.72)-(27.47)-(tcb->m_segmentSize)-(1.779)-(52.009)-(52.588)-(86.553));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (10.228/37.662);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
