float INKrcgNhVCIYmCgQ = (float) ((-67.125-(80.268)-(62.11))/82.486);
float dTQEQAnfXSLpQImi = (float) (-39.993-(-5.15)-(25.853)-(62.359)-(-96.432)-(-60.34)-(21.958)-(54.344));
int rAlMYocrKgCaUsjT = (int) (65.107+(-87.302)+(-89.573)+(37.758));
tcb->m_cWnd = (int) ((66.037*(51.243)*(69.029)*(-53.106)*(29.093)*(-23.793)*(-36.886))/-41.047);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (73.947-(94.741)-(0.565)-(tcb->m_segmentSize)-(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (71.392-(4.052)-(75.884)-(10.109)-(32.729)-(92.562)-(32.231));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (((16.786)+((72.571*(INKrcgNhVCIYmCgQ)*(rAlMYocrKgCaUsjT)*(62.624)))+(32.569)+(40.631)+(0.1))/((0.1)));

}
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (73.947-(94.741)-(0.565)-(tcb->m_segmentSize)-(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (71.392-(4.052)-(75.884)-(10.109)-(32.729)-(92.562)-(32.231));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (((16.786)+((72.571*(INKrcgNhVCIYmCgQ)*(rAlMYocrKgCaUsjT)*(62.624)))+(32.569)+(40.631)+(0.1))/((0.1)));

}
