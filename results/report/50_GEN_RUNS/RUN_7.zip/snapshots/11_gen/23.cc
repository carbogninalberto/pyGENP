tcb->m_cWnd = (int) (69.93-(23.602)-(19.623)-(87.254)-(73.724));
tcb->m_cWnd = (int) (((72.574)+(93.143)+(0.1)+(0.1))/((0.1)+(8.125)));
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(77.326)*(3.663)*(69.189)*(88.662)*(35.841)*(46.019)*(32.47));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (88.328+(17.969)+(88.641)+(46.62)+(65.714)+(73.773));
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	segmentsAcked = (int) (79.259*(34.584)*(19.098)*(46.098));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (0.1/78.534);
	tcb->m_ssThresh = (int) (1.175+(87.051)+(43.536)+(12.878)+(62.674)+(66.19));

}
