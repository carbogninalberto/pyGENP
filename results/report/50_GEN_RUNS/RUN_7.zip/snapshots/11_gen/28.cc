TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (17.589*(48.787)*(32.375)*(segmentsAcked)*(66.26));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (10.439-(40.249)-(16.003)-(38.532)-(tcb->m_cWnd)-(24.134));

} else {
	tcb->m_ssThresh = (int) (24.431+(3.014)+(26.704)+(56.748));

}
if (segmentsAcked >= segmentsAcked) {
	tcb->m_cWnd = (int) (0.1/80.427);
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(89.069)-(79.64)-(36.293)-(20.712)-(53.739)-(24.093)-(tcb->m_cWnd)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) ((((0.804+(tcb->m_segmentSize)+(47.444)+(90.802)))+((96.02*(78.239)*(31.118)))+(79.703)+(31.026)+(53.144)+(0.1))/((0.1)));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
