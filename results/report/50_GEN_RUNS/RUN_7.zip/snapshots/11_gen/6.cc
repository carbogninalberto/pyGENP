int pzMtQeoubTuXVMtd = (int) (-69.013+(-4.829)+(63.987)+(-7.668)+(-7.248)+(-46.037));
ReduceCwnd (tcb);
segmentsAcked = (int) (-22.28*(-30.03));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (18.754/79.682);
