float VgZBgvhohoFogMrC = (float) (0.1/0.1);
segmentsAcked = (int) (tcb->m_cWnd-(VgZBgvhohoFogMrC)-(20.216)-(45.879)-(76.509)-(96.163));
if (tcb->m_segmentSize < VgZBgvhohoFogMrC) {
	tcb->m_segmentSize = (int) (55.146+(73.669));

} else {
	tcb->m_segmentSize = (int) (80.508-(29.458)-(35.537)-(tcb->m_ssThresh));
	VgZBgvhohoFogMrC = (float) (94.041+(72.904)+(28.579)+(64.586));

}
segmentsAcked = (int) (17.314*(64.698)*(tcb->m_ssThresh)*(70.56)*(98.457));
segmentsAcked = (int) (0.1/0.1);
