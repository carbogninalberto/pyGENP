tcb->m_ssThresh = (int) (91.254*(tcb->m_cWnd));
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	segmentsAcked = (int) (17.171-(44.003)-(segmentsAcked)-(85.2)-(tcb->m_ssThresh));
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (50.084+(16.635)+(42.163)+(70.487));

} else {
	segmentsAcked = (int) (segmentsAcked-(77.277)-(tcb->m_segmentSize)-(42.842)-(49.465)-(61.041)-(76.546));
	segmentsAcked = (int) (21.831-(11.189)-(53.011)-(44.896)-(24.744)-(segmentsAcked)-(34.444)-(82.807));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (87.413+(51.53)+(tcb->m_cWnd)+(segmentsAcked)+(tcb->m_segmentSize)+(5.833)+(46.358)+(57.959));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (27.97-(segmentsAcked)-(17.04)-(10.189)-(tcb->m_cWnd)-(segmentsAcked));
tcb->m_cWnd = (int) (88.218+(53.027)+(14.419));
tcb->m_ssThresh = (int) (89.374*(88.417)*(31.95)*(97.237)*(44.008));
