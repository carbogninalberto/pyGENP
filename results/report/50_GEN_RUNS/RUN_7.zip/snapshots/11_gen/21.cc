CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (88.595/29.69);
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_ssThresh+(segmentsAcked)+(80.718)+(tcb->m_cWnd)+(segmentsAcked)+(90.068)+(38.7));
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (70.726*(1.526)*(7.617)*(46.302)*(segmentsAcked));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+((tcb->m_cWnd+(35.415)+(8.347)+(58.064)+(80.269)+(tcb->m_ssThresh)))+(0.1)+(51.324))/((0.1)));

}
