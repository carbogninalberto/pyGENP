if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (18.77/0.1);
	segmentsAcked = (int) (tcb->m_ssThresh*(77.947));

} else {
	tcb->m_segmentSize = (int) (84.449-(tcb->m_cWnd)-(31.831)-(52.05)-(31.531)-(1.376)-(57.973)-(segmentsAcked)-(segmentsAcked));
	segmentsAcked = (int) (36.28+(22.488)+(98.821)+(83.345)+(segmentsAcked)+(tcb->m_segmentSize)+(12.874));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (41.242*(93.102));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float jVPTYXsaNOqVoHdo = (float) (0.1/9.566);
