if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (26.262*(tcb->m_ssThresh)*(13.783)*(23.653)*(67.045)*(9.863)*(58.829)*(63.746));
	tcb->m_cWnd = (int) (45.543+(40.181)+(tcb->m_ssThresh)+(80.108)+(55.363));
	tcb->m_segmentSize = (int) (73.934-(84.872)-(74.135)-(tcb->m_segmentSize)-(93.814)-(58.356)-(91.513));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(86.425)-(8.165)-(26.774)-(51.884)-(97.372)-(69.488)-(84.338)-(78.976));

}
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_ssThresh = (int) (51.677+(6.815)+(69.343)+(tcb->m_ssThresh)+(97.977)+(3.683)+(72.532));

} else {
	tcb->m_ssThresh = (int) (90.285*(30.532)*(9.091)*(19.74)*(87.917)*(25.827)*(51.335));
	tcb->m_ssThresh = (int) (28.919+(52.847)+(tcb->m_cWnd)+(50.068)+(6.763)+(tcb->m_ssThresh)+(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (81.067+(27.412)+(segmentsAcked)+(48.44)+(tcb->m_cWnd)+(27.818)+(52.568));
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((0.1)+(10.166)+((96.51+(17.746)+(tcb->m_ssThresh)+(1.176)+(62.017)))+(0.1))/((0.1)));
	segmentsAcked = (int) (39.398-(82.107)-(tcb->m_cWnd)-(36.2)-(10.655)-(56.451)-(47.751)-(6.497));
	tcb->m_ssThresh = (int) (88.765-(97.088)-(tcb->m_cWnd)-(84.445)-(segmentsAcked)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(segmentsAcked)-(65.437));

} else {
	tcb->m_cWnd = (int) (((42.034)+(43.922)+(13.667)+(34.104)+(0.1)+(0.1))/((0.1)+(10.739)+(27.278)));

}
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(77.702)-(92.211)-(52.765)-(8.642)-(tcb->m_ssThresh)-(15.344)-(21.121)-(61.36));

} else {
	tcb->m_cWnd = (int) (50.161*(49.534)*(73.533));

}
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(20.542)-(33.853)-(49.101)-(44.235));
	tcb->m_cWnd = (int) (97.549-(84.426)-(41.164));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (33.851+(69.012)+(41.041)+(92.352));

}
tcb->m_ssThresh = (int) (58.553+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(86.419)+(tcb->m_cWnd));
