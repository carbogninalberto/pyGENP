float aLhAoqwqHDTveBJH = (float) (66.39-(segmentsAcked)-(3.275)-(77.046)-(96.042)-(0.817)-(12.791));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (aLhAoqwqHDTveBJH*(55.67)*(tcb->m_cWnd)*(57.129)*(40.31)*(aLhAoqwqHDTveBJH)*(19.928)*(50.636)*(50.33));
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_cWnd = (int) (32.109*(62.226)*(86.044)*(73.996)*(1.513)*(21.855)*(aLhAoqwqHDTveBJH));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (71.224-(66.371)-(0.952));

}
CongestionAvoidance (tcb, segmentsAcked);
