tcb->m_cWnd = (int) (94.041*(65.986)*(67.005)*(-56.113));
float uPIWdEWEamhLIoRN = (float) (-88.964*(-33.681)*(60.456)*(-4.832)*(11.352));
tcb->m_cWnd = (int) (38.536*(-60.153)*(59.716)*(-84.276));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
