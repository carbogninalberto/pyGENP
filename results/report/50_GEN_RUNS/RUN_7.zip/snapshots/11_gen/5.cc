float vVHWtbxyHvBYvTrn = (float) (90.352*(-26.902)*(-97.64)*(-63.08)*(-26.404)*(-33.875)*(-19.416));
int KbsebrZidtHUPumx = (int) 56.794;
segmentsAcked = (int) (-67.704+(48.087)+(14.734)+(-32.768)+(-60.07)+(10.643)+(12.567));
tcb->m_segmentSize = (int) (-43.025*(-22.862)*(7.003)*(-52.462)*(38.289)*(-4.773)*(87.589)*(79.979)*(-25.127));
CongestionAvoidance (tcb, segmentsAcked);
if (vVHWtbxyHvBYvTrn > tcb->m_segmentSize) {
	KbsebrZidtHUPumx = (int) (55.059+(18.075)+(58.549)+(88.693)+(vVHWtbxyHvBYvTrn)+(8.02));

} else {
	KbsebrZidtHUPumx = (int) ((tcb->m_cWnd+(81.987)+(tcb->m_cWnd)+(29.662)+(tcb->m_ssThresh)+(23.603)+(63.857)+(67.174)+(87.011))/89.217);

}
if (tcb->m_cWnd > tcb->m_cWnd) {
	segmentsAcked = (int) (94.564/0.1);
	vVHWtbxyHvBYvTrn = (float) (86.299*(17.067)*(3.562)*(tcb->m_segmentSize)*(62.524)*(89.445)*(85.006)*(41.353)*(96.045));

} else {
	segmentsAcked = (int) (((0.1)+(8.808)+((tcb->m_ssThresh+(60.211)+(segmentsAcked)+(29.632)+(61.438)+(61.186)))+(40.368)+(0.1)+(0.1))/((0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
KbsebrZidtHUPumx = (int) (68.611/69.939);
