tcb->m_segmentSize = (int) (28.983*(32.283));
tcb->m_segmentSize = (int) (((77.184)+(56.114)+(0.1)+(0.1)+(64.131)+(96.319)+(70.87))/((0.1)+(0.1)));
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	segmentsAcked = (int) (81.633*(36.688)*(39.77)*(56.93)*(19.795)*(tcb->m_ssThresh)*(64.762)*(tcb->m_segmentSize)*(54.366));
	tcb->m_cWnd = (int) (98.674-(16.026));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (81.409/0.1);
	segmentsAcked = (int) (segmentsAcked*(21.043));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (((0.1)+(32.136)+(0.1)+(0.1))/((0.1)+(46.948)));
tcb->m_cWnd = (int) (74.481-(36.299)-(26.699)-(29.387)-(tcb->m_ssThresh));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (64.737*(98.529));
