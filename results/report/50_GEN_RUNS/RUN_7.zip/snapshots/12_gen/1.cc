float uPIWdEWEamhLIoRN = (float) (30.031*(-67.903)*(52.857)*(13.024)*(62.0));
tcb->m_cWnd = (int) (-54.405*(90.258)*(-57.791)*(79.819));
tcb->m_cWnd = (int) (-6.468*(67.412)*(-35.841)*(-31.415));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
