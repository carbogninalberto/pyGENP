segmentsAcked = (int) (26.632/0.1);
tcb->m_ssThresh = (int) (63.435*(40.221)*(70.815));
segmentsAcked = (int) (((27.67)+(0.1)+(2.454)+(57.955))/((0.1)+(0.1)));
tcb->m_ssThresh = (int) (27.057/0.1);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (85.527-(segmentsAcked)-(86.332)-(tcb->m_ssThresh)-(69.264)-(37.011)-(tcb->m_ssThresh)-(42.834)-(28.786));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (44.411*(21.154)*(25.591)*(61.795)*(45.393)*(8.407));
	ReduceCwnd (tcb);

}
