if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((17.305)+(75.218)+(0.1)+(24.378)+(49.646)+(0.1))/((18.722)+(26.471)));
	tcb->m_cWnd = (int) ((((12.623+(tcb->m_segmentSize)+(63.027)+(31.271)+(segmentsAcked)+(93.029)+(segmentsAcked)))+(0.1)+(45.228)+(0.1)+(45.227))/((55.041)));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (39.478+(95.236)+(2.584)+(70.029)+(6.054)+(23.769)+(28.093)+(65.604)+(86.986));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (segmentsAcked-(24.435)-(33.627)-(99.208)-(11.358)-(73.144)-(96.58)-(33.773));
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (45.589*(47.38));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (0.1/72.192);
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(tcb->m_segmentSize)-(7.24)-(45.791)-(14.018));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (22.203-(tcb->m_segmentSize)-(64.698)-(21.465));
tcb->m_cWnd = (int) (((0.1)+(65.045)+(65.8)+((61.194-(tcb->m_ssThresh)-(59.376)-(89.898)-(21.081)))+(57.613))/((0.1)+(0.1)+(73.616)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
