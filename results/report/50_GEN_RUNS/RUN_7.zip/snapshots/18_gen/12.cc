if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.1/(6.335-(72.213)));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(4.296)+(84.643)+(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.1/11.375);

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(76.951));
	tcb->m_cWnd = (int) (0.1/0.1);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (26.44/21.019);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (53.295/0.1);
	tcb->m_ssThresh = (int) (83.469*(tcb->m_cWnd)*(68.886)*(46.012));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (43.322+(tcb->m_cWnd)+(segmentsAcked)+(segmentsAcked)+(41.44));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
