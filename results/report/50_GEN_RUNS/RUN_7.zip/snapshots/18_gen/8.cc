int phhgQmqDpakcrNqw = (int) (-70.995*(70.866)*(40.388)*(34.526)*(-79.176)*(89.741)*(92.997)*(47.158)*(39.233));
int PDsGEsLEtBTGacFQ = (int) (56.219*(-54.732)*(67.731));
float sTfBXGmYRxKxjhou = (float) (52.346/-74.038);
PDsGEsLEtBTGacFQ = (int) (-70.14-(-49.365)-(-23.392)-(4.844));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (sTfBXGmYRxKxjhou <= phhgQmqDpakcrNqw) {
	PDsGEsLEtBTGacFQ = (int) (tcb->m_cWnd+(96.31)+(3.83)+(35.147)+(58.572)+(79.188));

} else {
	PDsGEsLEtBTGacFQ = (int) (sTfBXGmYRxKxjhou*(36.539)*(37.842)*(66.468)*(PDsGEsLEtBTGacFQ)*(tcb->m_cWnd));
	PDsGEsLEtBTGacFQ = (int) (89.343-(60.922));

}
if (sTfBXGmYRxKxjhou <= phhgQmqDpakcrNqw) {
	PDsGEsLEtBTGacFQ = (int) (tcb->m_cWnd+(96.31)+(3.83)+(35.147)+(58.572)+(79.188));

} else {
	PDsGEsLEtBTGacFQ = (int) (sTfBXGmYRxKxjhou*(36.539)*(37.842)*(66.468)*(PDsGEsLEtBTGacFQ)*(tcb->m_cWnd));
	PDsGEsLEtBTGacFQ = (int) (89.343-(60.922));

}
