if (segmentsAcked != tcb->m_ssThresh) {
	segmentsAcked = (int) (71.612-(76.971)-(tcb->m_ssThresh)-(59.094)-(92.835)-(83.986)-(tcb->m_ssThresh));
	segmentsAcked = (int) ((36.057*(15.539)*(17.349)*(80.723)*(tcb->m_segmentSize)*(tcb->m_cWnd))/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (36.066-(29.293));
	tcb->m_segmentSize = (int) (63.124+(46.828)+(45.901)+(tcb->m_segmentSize));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (77.296+(65.301)+(71.659)+(16.929)+(59.61)+(tcb->m_cWnd)+(52.902)+(93.101));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (55.374+(94.34)+(tcb->m_ssThresh));
