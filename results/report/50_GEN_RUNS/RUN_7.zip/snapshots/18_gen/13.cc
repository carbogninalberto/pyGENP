if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (73.979+(0.841)+(65.921));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(18.958)+(tcb->m_segmentSize)+(44.425)+(6.913)+(27.947));
	tcb->m_segmentSize = (int) (42.666*(tcb->m_cWnd)*(18.152)*(tcb->m_segmentSize)*(68.23)*(tcb->m_segmentSize));

}
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(20.55)+(13.361)+(35.834));

} else {
	tcb->m_ssThresh = (int) (70.247+(42.948)+(30.659));
	segmentsAcked = (int) (57.526-(87.609));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(60.003)+(37.291));
