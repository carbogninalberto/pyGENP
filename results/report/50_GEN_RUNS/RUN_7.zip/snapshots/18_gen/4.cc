int phhgQmqDpakcrNqw = (int) (78.921*(54.992)*(-27.172)*(-28.279)*(-99.378)*(-65.669)*(-2.611)*(-57.445)*(26.172));
int PDsGEsLEtBTGacFQ = (int) (77.266*(-26.203)*(90.073));
float sTfBXGmYRxKxjhou = (float) (-5.701/-67.112);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (sTfBXGmYRxKxjhou <= phhgQmqDpakcrNqw) {
	PDsGEsLEtBTGacFQ = (int) (tcb->m_cWnd+(96.31)+(3.83)+(35.147)+(58.572)+(79.188));

} else {
	PDsGEsLEtBTGacFQ = (int) (sTfBXGmYRxKxjhou*(36.539)*(37.842)*(66.468)*(PDsGEsLEtBTGacFQ)*(tcb->m_cWnd));
	PDsGEsLEtBTGacFQ = (int) (89.343-(60.922));

}
