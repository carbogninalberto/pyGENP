if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((0.1)+(2.625)+(0.1)+(69.335)+(48.527)+(11.275))/((37.359)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (3.718+(43.826)+(70.931)+(98.756)+(73.581)+(91.896)+(98.845)+(91.596)+(47.494));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (40.143*(44.527)*(56.408)*(76.143)*(14.291)*(49.277));

}
tcb->m_cWnd = (int) (59.54-(-91.097)-(-84.168)-(56.471)-(7.416));
tcb->m_cWnd = (int) (-97.555-(-16.193)-(-65.258)-(3.756)-(-69.991));
tcb->m_cWnd = (int) (((-95.653)+(-32.774)+((tcb->m_ssThresh+(tcb->m_segmentSize)))+(35.543)+(95.33))/((22.223)+(-57.945)+(87.778)));
tcb->m_cWnd = (int) (((68.699)+(43.458)+((tcb->m_ssThresh+(tcb->m_segmentSize)))+(-23.326)+(86.71))/((93.819)+(-14.469)+(-92.079)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((-98.839+(-20.752)+(46.631)+(-89.404)+(-56.141)+(75.045)+(tcb->m_segmentSize)+(-93.096))/39.723);
tcb->m_cWnd = (int) ((8.605+(-94.355)+(56.586)+(1.763)+(-49.208)+(10.293)+(tcb->m_segmentSize)+(-60.365))/-56.957);
