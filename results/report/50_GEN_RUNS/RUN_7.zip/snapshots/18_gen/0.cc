CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-77.999-(41.418)-(33.399)-(99.557)-(-73.773));
tcb->m_cWnd = (int) (((-44.586)+(-92.912)+((tcb->m_ssThresh+(tcb->m_segmentSize)))+(-19.556)+(75.032))/((30.552)+(93.078)+(91.811)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((92.17+(-5.238)+(-6.273)+(-62.568)+(-56.924)+(93.144)+(tcb->m_segmentSize)+(-66.316))/-19.535);
