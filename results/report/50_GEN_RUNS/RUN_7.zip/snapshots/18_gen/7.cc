if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (71.154-(91.231)-(34.613)-(75.071)-(60.426));

} else {
	tcb->m_segmentSize = (int) (47.761*(88.04)*(tcb->m_cWnd)*(37.071)*(82.253)*(8.757)*(23.105)*(77.147)*(2.079));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (0.1/67.325);

}
tcb->m_segmentSize = (int) (79.548*(-26.257)*(46.841)*(93.778)*(53.156)*(-12.734));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-62.258*(-76.807)*(-21.293)*(12.481)*(53.256)*(93.654));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
