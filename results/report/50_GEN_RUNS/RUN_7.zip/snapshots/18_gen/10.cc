int phhgQmqDpakcrNqw = (int) (20.478*(-7.774)*(16.898)*(-22.172)*(-48.335)*(29.948)*(75.449)*(-32.195)*(-74.061));
int PDsGEsLEtBTGacFQ = (int) (-83.505*(52.099)*(13.647));
float sTfBXGmYRxKxjhou = (float) (64.053/46.119);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (sTfBXGmYRxKxjhou <= phhgQmqDpakcrNqw) {
	PDsGEsLEtBTGacFQ = (int) (tcb->m_cWnd+(96.31)+(3.83)+(35.147)+(58.572)+(79.188));

} else {
	PDsGEsLEtBTGacFQ = (int) (sTfBXGmYRxKxjhou*(36.539)*(37.842)*(66.468)*(PDsGEsLEtBTGacFQ)*(tcb->m_cWnd));
	PDsGEsLEtBTGacFQ = (int) (89.343-(60.922));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (sTfBXGmYRxKxjhou <= phhgQmqDpakcrNqw) {
	PDsGEsLEtBTGacFQ = (int) (tcb->m_cWnd+(96.31)+(3.83)+(35.147)+(58.572)+(79.188));

} else {
	PDsGEsLEtBTGacFQ = (int) (sTfBXGmYRxKxjhou*(36.539)*(37.842)*(66.468)*(PDsGEsLEtBTGacFQ)*(tcb->m_cWnd));
	PDsGEsLEtBTGacFQ = (int) (89.343-(60.922));

}
