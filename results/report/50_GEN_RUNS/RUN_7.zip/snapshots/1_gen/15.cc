if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (24.688/91.717);
	segmentsAcked = (int) (segmentsAcked-(76.709)-(18.723)-(34.696)-(83.731)-(32.563)-(tcb->m_ssThresh));
	segmentsAcked = (int) (3.634+(45.047));

} else {
	segmentsAcked = (int) (96.566+(61.023)+(4.123)+(tcb->m_segmentSize)+(57.977));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (6.406/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (0.1/0.1);
