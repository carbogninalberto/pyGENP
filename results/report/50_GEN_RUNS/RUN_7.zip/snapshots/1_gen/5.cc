tcb->m_ssThresh = (int) (35.462-(92.424)-(48.223)-(11.176)-(75.999));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (19.661*(98.07));
float SfaOcuKgNdhSLvWk = (float) (0.1/0.1);
if (SfaOcuKgNdhSLvWk > SfaOcuKgNdhSLvWk) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (60.613-(SfaOcuKgNdhSLvWk)-(14.738)-(38.995)-(segmentsAcked)-(18.056));
	SfaOcuKgNdhSLvWk = (float) (tcb->m_cWnd*(63.934)*(81.035)*(tcb->m_segmentSize)*(50.048)*(60.96));

} else {
	tcb->m_segmentSize = (int) (30.347-(28.138)-(84.95)-(39.741)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(79.224)-(55.467));
	ReduceCwnd (tcb);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= SfaOcuKgNdhSLvWk) {
	tcb->m_cWnd = (int) (26.114*(segmentsAcked)*(75.165)*(tcb->m_cWnd)*(3.652)*(66.297)*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (97.631*(42.395)*(70.3)*(tcb->m_cWnd));
	segmentsAcked = (int) (tcb->m_cWnd+(64.927)+(92.581));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
