tcb->m_segmentSize = (int) (4.072+(2.892)+(79.498)+(76.149)+(tcb->m_ssThresh));
segmentsAcked = (int) (80.13+(20.317)+(14.251)+(46.434)+(87.644)+(42.827));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (5.502-(64.126));
	segmentsAcked = (int) (97.19+(76.606)+(73.492)+(79.216)+(77.437));

} else {
	tcb->m_cWnd = (int) (10.342-(41.366)-(12.608)-(51.684)-(27.46)-(60.403)-(0.699)-(46.024)-(83.253));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(67.831)*(53.74)*(7.84)*(18.229)*(91.639));

}
if (tcb->m_ssThresh > segmentsAcked) {
	segmentsAcked = (int) (8.121+(95.344)+(88.28)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(36.06)+(72.344)+(87.614));

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(76.132)+(0.1)+(98.166)+(0.1)+(0.1))/((0.1)));
	tcb->m_cWnd = (int) (69.431-(33.073)-(tcb->m_ssThresh)-(28.141)-(tcb->m_cWnd)-(tcb->m_cWnd));

}
tcb->m_segmentSize = (int) (62.057+(82.016)+(58.592)+(segmentsAcked)+(8.695)+(30.591));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (33.778-(93.621));

} else {
	tcb->m_cWnd = (int) (99.141*(tcb->m_cWnd)*(10.001)*(6.75)*(24.741));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
