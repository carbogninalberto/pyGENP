if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (79.211-(34.001)-(tcb->m_cWnd)-(6.773)-(75.473)-(39.671)-(53.424)-(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (((55.991)+(7.646)+(0.1)+(26.365)+(2.275)+(39.905))/((44.065)));

} else {
	tcb->m_ssThresh = (int) (76.912*(tcb->m_ssThresh)*(28.81)*(46.189)*(segmentsAcked)*(40.622)*(63.285)*(84.775));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (51.869*(51.057)*(segmentsAcked)*(82.677)*(9.924)*(71.626)*(75.762)*(30.548));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (((0.1)+(95.599)+(81.1)+(0.1))/((50.431)));

}
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (segmentsAcked*(segmentsAcked)*(73.611)*(50.015)*(38.208));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(91.466)+(15.471)+(36.722));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (25.078+(41.549)+(71.833)+(segmentsAcked));

}
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(84.284)-(segmentsAcked)-(69.347)-(41.53)-(51.412)-(45.234)-(46.868));
	segmentsAcked = (int) (23.077*(67.499));

} else {
	tcb->m_segmentSize = (int) (38.628-(82.244)-(23.401)-(tcb->m_ssThresh));

}
