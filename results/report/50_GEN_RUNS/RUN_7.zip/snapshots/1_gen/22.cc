if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (segmentsAcked-(91.929)-(38.639)-(41.103)-(tcb->m_cWnd)-(63.737)-(90.704));
	tcb->m_segmentSize = (int) (((18.936)+((tcb->m_cWnd*(53.164)*(94.231)))+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(71.096)));

} else {
	tcb->m_segmentSize = (int) (36.413-(99.816)-(segmentsAcked)-(22.477)-(tcb->m_cWnd));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (67.531*(35.696)*(30.138)*(42.377)*(57.535)*(2.493)*(53.533)*(74.668)*(tcb->m_segmentSize));
segmentsAcked = (int) (0.1/64.489);
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (90.159-(88.345)-(34.498)-(15.458)-(29.077)-(32.616));

} else {
	tcb->m_segmentSize = (int) (84.471*(segmentsAcked)*(83.77)*(92.672)*(95.431)*(86.091));
	segmentsAcked = (int) (36.928-(73.132)-(tcb->m_cWnd)-(72.692)-(tcb->m_ssThresh));

}
