ReduceCwnd (tcb);
int shWVoQTCqvmTCSZO = (int) (((0.1)+(4.787)+(60.882)+(0.1)+(0.1)+(86.295))/((0.1)));
if (tcb->m_ssThresh != shWVoQTCqvmTCSZO) {
	tcb->m_segmentSize = (int) (73.808*(48.272)*(tcb->m_ssThresh)*(76.888));
	tcb->m_ssThresh = (int) ((39.649+(51.72)+(3.794))/12.767);
	tcb->m_cWnd = (int) (24.57-(tcb->m_segmentSize)-(shWVoQTCqvmTCSZO)-(15.126)-(84.126)-(tcb->m_ssThresh)-(30.86));

} else {
	tcb->m_segmentSize = (int) (25.323+(segmentsAcked)+(tcb->m_cWnd)+(27.881)+(9.674)+(26.478)+(55.632)+(97.203)+(95.166));

}
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	shWVoQTCqvmTCSZO = (int) (((0.1)+(0.1)+(0.1)+(37.255))/((36.966)+(0.1)));
	tcb->m_ssThresh = (int) (96.766+(87.838)+(87.675));
	tcb->m_cWnd = (int) (50.197*(42.373));

} else {
	shWVoQTCqvmTCSZO = (int) (0.1/30.51);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (60.53-(7.047)-(59.303)-(11.105)-(95.64));

} else {
	tcb->m_segmentSize = (int) (((22.989)+(0.1)+(0.1)+(0.1))/((0.1)));
	tcb->m_cWnd = (int) (39.249+(shWVoQTCqvmTCSZO)+(25.485));

}
if (shWVoQTCqvmTCSZO >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (83.654*(36.173)*(82.965)*(56.295)*(98.158)*(7.803)*(96.496)*(88.55)*(76.472));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(21.583));
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
