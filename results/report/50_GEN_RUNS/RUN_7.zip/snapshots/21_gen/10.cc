segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((30.681)+(66.07)+(75.753)+(0.1)+(0.1)+(35.261))/((0.1)));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(46.473)-(30.907));
