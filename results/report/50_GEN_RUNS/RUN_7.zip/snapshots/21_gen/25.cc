ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (0.1/0.1);
tcb->m_segmentSize = (int) (89.093+(47.662)+(54.66));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd-(81.229)-(tcb->m_cWnd)-(tcb->m_segmentSize)-(38.163)-(48.691)-(54.198)-(18.974)-(35.227));
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_ssThresh = (int) (98.787+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(92.955)+(44.075)+(61.942));
	tcb->m_ssThresh = (int) (22.825*(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(88.883)*(98.033)*(92.655)*(80.061));

}
