if (segmentsAcked > tcb->m_ssThresh) {
	segmentsAcked = (int) (59.154-(87.159)-(27.649)-(5.212)-(98.227)-(79.17));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (1.249+(26.74)+(57.029)+(11.482)+(79.932)+(53.596)+(segmentsAcked)+(tcb->m_ssThresh)+(3.239));
	tcb->m_cWnd = (int) (68.883*(5.425)*(18.522)*(9.647)*(20.53)*(29.615)*(segmentsAcked)*(26.467)*(72.408));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) ((34.702*(tcb->m_segmentSize)*(17.664)*(tcb->m_segmentSize)*(64.237))/0.1);
