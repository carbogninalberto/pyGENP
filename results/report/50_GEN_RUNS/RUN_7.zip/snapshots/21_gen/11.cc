float ZNxOzoaxANEeWDqG = (float) (0.1/13.691);
ZNxOzoaxANEeWDqG = (float) (8.714*(88.214)*(tcb->m_segmentSize)*(61.691)*(21.138)*(28.962)*(90.521)*(72.702)*(95.542));
if (tcb->m_segmentSize > ZNxOzoaxANEeWDqG) {
	ZNxOzoaxANEeWDqG = (float) (((91.193)+(5.359)+((18.371+(tcb->m_cWnd)+(64.51)))+(0.1)+(0.1)+(0.1))/((22.011)+(0.1)+(4.435)));
	ZNxOzoaxANEeWDqG = (float) (0.928*(98.837)*(47.17));

} else {
	ZNxOzoaxANEeWDqG = (float) (11.979+(80.529)+(28.566)+(segmentsAcked)+(1.625)+(5.801)+(5.495)+(18.704));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
float yHuCSyzTHEPKAzii = (float) (ZNxOzoaxANEeWDqG*(1.438)*(tcb->m_ssThresh));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (ZNxOzoaxANEeWDqG <= yHuCSyzTHEPKAzii) {
	tcb->m_segmentSize = (int) (1.759+(tcb->m_segmentSize)+(44.036)+(54.318));

} else {
	tcb->m_segmentSize = (int) (85.957*(81.788)*(13.877)*(tcb->m_segmentSize)*(35.883)*(75.082)*(tcb->m_cWnd)*(82.56));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
float wjyYqhszemIsDQkk = (float) ((((80.005+(78.852)+(18.122)+(80.679)+(19.406)))+(0.1)+(5.249)+(0.1)+(63.722))/((4.391)));
