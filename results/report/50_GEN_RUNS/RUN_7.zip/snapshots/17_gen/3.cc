if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((64.48)+(39.82)+(84.389)+(0.1))/((15.035)+(0.1)+(0.1)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (2.142*(tcb->m_segmentSize)*(79.833)*(segmentsAcked)*(53.395));

}
tcb->m_cWnd = (int) (-81.369-(67.28)-(30.975)-(38.799)-(-85.026));
tcb->m_cWnd = (int) (((6.454)+(-78.854)+((tcb->m_ssThresh+(tcb->m_segmentSize)))+(11.55)+(-81.385))/((-86.233)+(57.17)+(-2.926)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((80.066+(-95.865)+(25.38)+(-4.109)+(-70.733)+(55.079)+(tcb->m_segmentSize)+(-72.672))/-61.115);
