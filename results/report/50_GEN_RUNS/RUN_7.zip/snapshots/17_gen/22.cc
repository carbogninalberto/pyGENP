tcb->m_cWnd = (int) (75.522+(53.1)+(10.196)+(23.335)+(88.978)+(79.375)+(tcb->m_ssThresh));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (segmentsAcked*(6.219)*(74.407));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (26.967-(90.47));

} else {
	tcb->m_segmentSize = (int) (91.156+(tcb->m_cWnd));
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) ((((4.571*(98.403)*(tcb->m_segmentSize)*(3.145)))+((segmentsAcked+(50.423)+(41.878)+(83.048)+(24.157)))+((segmentsAcked-(4.947)))+(2.131)+(23.183))/((39.369)));
if (segmentsAcked < tcb->m_ssThresh) {
	segmentsAcked = (int) (0.1/(46.849*(27.125)));
	tcb->m_segmentSize = (int) (65.018-(41.049)-(81.49));

} else {
	segmentsAcked = (int) (53.932*(tcb->m_segmentSize)*(70.843));
	tcb->m_cWnd = (int) (60.22-(56.485)-(48.838)-(82.449)-(66.672));

}
tcb->m_cWnd = (int) (85.149+(77.426)+(70.626)+(31.359)+(77.285)+(45.867)+(37.659)+(99.011));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (67.351-(48.073)-(47.744)-(10.686)-(40.884));
