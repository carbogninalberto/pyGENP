float mXapNHTlcUONuiPJ = (float) (53.992/0.1);
mXapNHTlcUONuiPJ = (float) (99.609/0.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((54.272)+(0.1)+(96.109)));
