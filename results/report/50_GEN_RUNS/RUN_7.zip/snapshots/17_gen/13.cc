int MhcXVUNafaaNRpCX = (int) (79.43-(49.305)-(19.357)-(34.604));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (43.184-(68.149)-(27.117)-(19.074)-(86.732)-(21.855)-(segmentsAcked)-(61.181));
segmentsAcked = (int) (91.174-(76.652)-(57.523)-(3.035)-(35.496)-(segmentsAcked)-(44.062)-(46.42)-(31.608));
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (42.575-(67.988)-(79.818)-(91.796)-(segmentsAcked)-(70.068)-(60.474)-(MhcXVUNafaaNRpCX));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(15.423)-(tcb->m_ssThresh)-(33.259));
	tcb->m_segmentSize = (int) (37.222/8.207);

} else {
	tcb->m_segmentSize = (int) (98.345+(19.999)+(27.271)+(6.66)+(72.691)+(20.42)+(67.551));

}
MhcXVUNafaaNRpCX = (int) (3.075+(segmentsAcked)+(93.821)+(75.097)+(15.316)+(tcb->m_ssThresh));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
