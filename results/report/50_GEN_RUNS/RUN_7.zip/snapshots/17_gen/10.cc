segmentsAcked = (int) (((-78.638)+(-35.142)+(2.421)+(38.998))/((-37.173)+(32.69)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-30.308*(49.426)*(-11.158)*(-0.54)*(52.364)*(-98.546)*(2.589));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
