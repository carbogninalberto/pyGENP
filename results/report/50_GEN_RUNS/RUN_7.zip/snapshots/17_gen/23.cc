int EHibMJVmzTChnInk = (int) (tcb->m_ssThresh+(32.558)+(tcb->m_ssThresh));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) ((((21.364+(55.265)+(6.225)+(tcb->m_ssThresh)+(segmentsAcked)+(84.184)+(50.885)+(segmentsAcked)+(87.516)))+(87.897)+(93.857)+(0.1))/((0.1)));
	EHibMJVmzTChnInk = (int) (25.344*(76.184)*(84.744)*(44.775)*(9.233)*(53.457)*(22.772)*(31.356));
	EHibMJVmzTChnInk = (int) (44.928+(54.615)+(37.335)+(74.35)+(30.789)+(36.255)+(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(77.553)*(3.53)*(52.09));

}
if (segmentsAcked < EHibMJVmzTChnInk) {
	tcb->m_cWnd = (int) (69.431+(3.776)+(59.329)+(44.712)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(tcb->m_ssThresh)-(3.304)-(tcb->m_segmentSize)-(60.292)-(76.965)-(16.159)-(70.703));

} else {
	tcb->m_cWnd = (int) (98.126/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
EHibMJVmzTChnInk = (int) (77.729*(23.243)*(12.093)*(10.105)*(14.221)*(96.709)*(74.381)*(66.05));
tcb->m_ssThresh = (int) (62.277-(80.876)-(tcb->m_cWnd)-(33.052)-(5.361));
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_cWnd = (int) (17.65+(94.878)+(12.796));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (27.459-(31.432)-(tcb->m_ssThresh)-(97.564)-(71.04)-(tcb->m_ssThresh)-(32.033)-(68.599)-(92.625));
	tcb->m_ssThresh = (int) (87.303+(73.396));
	segmentsAcked = (int) (33.801*(35.161)*(22.424)*(53.062)*(72.833));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
