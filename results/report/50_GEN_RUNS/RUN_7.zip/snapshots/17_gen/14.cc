if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_segmentSize = (int) (81.714+(tcb->m_ssThresh)+(37.951)+(11.736)+(84.387)+(40.621)+(49.798)+(61.633));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(50.384));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (79.449+(tcb->m_cWnd)+(72.95)+(24.32)+(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (14.414*(tcb->m_segmentSize)*(tcb->m_cWnd)*(80.32)*(39.027)*(15.172));

} else {
	segmentsAcked = (int) (10.204+(74.131)+(tcb->m_segmentSize)+(87.561)+(65.324)+(63.476));
	tcb->m_ssThresh = (int) (0.1/0.1);

}
tcb->m_segmentSize = (int) ((49.392*(98.723)*(tcb->m_ssThresh)*(76.084)*(70.087)*(57.809)*(35.692))/66.243);
segmentsAcked = SlowStart (tcb, segmentsAcked);
int ADYTuKsoAQhAxtBm = (int) (3.784*(97.872)*(91.121)*(5.449)*(1.506)*(33.932)*(12.797)*(66.168)*(15.461));
