tcb->m_ssThresh = (int) (14.154-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(35.965)-(7.273)-(19.25));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (43.578+(29.38)+(79.057)+(37.461)+(74.524)+(25.883)+(41.998)+(6.632));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (segmentsAcked-(80.758)-(94.504));
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (59.157*(39.509)*(36.189));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(tcb->m_ssThresh)-(30.469)-(1.764));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (12.033*(tcb->m_cWnd)*(tcb->m_segmentSize)*(81.258)*(7.426)*(tcb->m_cWnd)*(48.105)*(segmentsAcked));
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(70.9)*(9.157)*(32.751)*(31.246));

}
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	segmentsAcked = (int) (segmentsAcked+(96.06)+(48.951)+(80.418)+(75.658)+(51.837));

} else {
	tcb->m_segmentSize = (int) (5.356-(tcb->m_ssThresh)-(6.661)-(27.869)-(32.963)-(51.794)-(38.295));
	tcb->m_cWnd = (int) (78.024*(6.952)*(15.568)*(62.392)*(tcb->m_ssThresh)*(57.008)*(48.354)*(segmentsAcked)*(tcb->m_segmentSize));

}
CongestionAvoidance (tcb, segmentsAcked);
