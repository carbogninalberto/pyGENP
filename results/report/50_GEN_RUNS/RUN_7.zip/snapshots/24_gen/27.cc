tcb->m_cWnd = (int) (6.166-(12.104)-(85.523)-(54.328));
tcb->m_ssThresh = (int) (48.185+(43.561)+(25.792)+(77.469)+(61.685));
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (71.598*(37.507)*(57.479)*(tcb->m_cWnd)*(87.704));

} else {
	tcb->m_segmentSize = (int) ((((6.999*(82.406)*(48.675)))+((37.158*(92.443)*(27.977)*(73.955)*(54.922)*(13.876)*(37.241)*(77.562)))+(10.501)+(21.247)+(56.008)+(0.1))/((0.1)+(91.433)+(0.1)));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (12.249-(37.059)-(78.215)-(tcb->m_ssThresh)-(10.597)-(85.269)-(tcb->m_segmentSize));
	segmentsAcked = (int) (76.341+(0.206)+(94.385)+(18.104)+(50.833));
	tcb->m_segmentSize = (int) ((((95.198*(84.777)*(11.308)))+((63.137*(tcb->m_ssThresh)*(33.181)*(segmentsAcked)*(30.61)*(45.983)*(74.132)*(92.417)*(50.708)))+(31.981)+(44.877)+(0.1)+(0.1)+(0.1))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (55.585-(7.559)-(tcb->m_cWnd)-(74.453)-(3.996));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_cWnd = (int) (12.88-(48.272)-(10.571)-(31.152)-(segmentsAcked)-(49.74));

} else {
	tcb->m_cWnd = (int) (52.367+(segmentsAcked)+(29.531)+(70.436)+(87.332)+(70.251)+(13.513)+(43.201)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (segmentsAcked+(44.967));
	ReduceCwnd (tcb);

}
