tcb->m_cWnd = (int) (7.205*(41.211)*(47.987)*(98.514));
tcb->m_cWnd = (int) (tcb->m_ssThresh-(tcb->m_cWnd)-(25.153)-(16.993)-(62.733)-(70.379)-(59.026));
tcb->m_segmentSize = (int) (31.112*(87.943)*(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
float WuaFpztRESDSPstX = (float) (70.535-(tcb->m_ssThresh)-(segmentsAcked));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (64.546*(31.042)*(84.2)*(4.824)*(46.982)*(20.054)*(tcb->m_ssThresh)*(segmentsAcked));
	segmentsAcked = (int) (64.297/0.1);

} else {
	tcb->m_cWnd = (int) (51.501+(93.494)+(tcb->m_ssThresh)+(89.602)+(88.235)+(41.654)+(17.226)+(9.797));
	tcb->m_segmentSize = (int) (15.179*(91.897));

}
WuaFpztRESDSPstX = (float) (tcb->m_segmentSize*(42.326));
