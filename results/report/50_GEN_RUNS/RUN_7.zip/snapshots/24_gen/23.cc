if (segmentsAcked == tcb->m_cWnd) {
	segmentsAcked = (int) (87.539-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (79.091+(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) ((tcb->m_segmentSize+(95.594)+(81.375)+(77.569)+(2.175)+(tcb->m_ssThresh))/63.31);
	tcb->m_segmentSize = (int) (95.321-(tcb->m_segmentSize)-(segmentsAcked)-(3.303));
	tcb->m_ssThresh = (int) (14.216-(53.324)-(39.31)-(90.179)-(15.25)-(0.252));

}
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(40.668)-(4.114)-(8.254)-(48.245)-(36.901)-(35.248));
	tcb->m_ssThresh = (int) (61.842*(49.366)*(32.979)*(41.772));

} else {
	tcb->m_cWnd = (int) (((56.836)+(78.061)+(82.515)+(0.1)+(84.336))/((0.1)+(0.1)+(0.1)+(0.1)));
	tcb->m_cWnd = (int) (95.413*(85.382)*(48.008)*(67.333)*(tcb->m_segmentSize)*(11.93)*(64.663));

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	segmentsAcked = (int) (((14.631)+(0.1)+((94.644-(49.107)-(89.522)-(39.483)-(73.54)-(22.789)-(66.428)-(segmentsAcked)))+(42.877)+(6.028)+(0.1)+(2.906))/((11.098)));
	tcb->m_cWnd = (int) (75.499+(20.27)+(17.153)+(18.952)+(24.722)+(38.102));
	tcb->m_segmentSize = (int) (76.051-(1.59)-(99.825));

} else {
	segmentsAcked = (int) (((6.948)+(0.1)+(20.562)+(79.423)+(3.168)+((76.082+(26.265)+(53.209)+(52.833)+(10.681)+(56.413)+(tcb->m_segmentSize)+(97.187)))+(0.1))/((15.572)+(0.1)));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (3.763-(76.843)-(88.303)-(49.137)-(4.474)-(tcb->m_ssThresh)-(57.567)-(4.705));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
