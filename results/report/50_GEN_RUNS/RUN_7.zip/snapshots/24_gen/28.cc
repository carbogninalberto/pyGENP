tcb->m_ssThresh = (int) (99.545*(4.442));
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(48.177));
	tcb->m_ssThresh = (int) (28.577-(41.511)-(segmentsAcked)-(36.428)-(39.189)-(60.951)-(41.673)-(78.174)-(74.605));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (65.739-(15.504)-(37.326)-(40.134)-(81.921));

}
segmentsAcked = (int) (58.203+(19.995)+(91.083)+(81.972)+(77.771));
ReduceCwnd (tcb);
float oMGWeygTUFJMXgaa = (float) (45.0*(81.848)*(98.745)*(4.177));
tcb->m_cWnd = (int) (83.273*(22.989)*(45.762)*(13.332)*(11.263)*(tcb->m_segmentSize)*(79.397)*(44.429));
