TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (21.028*(86.934)*(79.598)*(79.652)*(93.43)*(13.802));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_cWnd = (int) ((tcb->m_cWnd+(8.331)+(98.929)+(tcb->m_cWnd)+(61.559)+(15.027)+(37.355)+(17.695)+(segmentsAcked))/26.273);

} else {
	tcb->m_cWnd = (int) (3.33*(63.483)*(34.378)*(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (39.294*(34.717)*(4.461)*(33.016)*(tcb->m_segmentSize)*(62.509)*(tcb->m_ssThresh)*(98.441)*(17.682));
	segmentsAcked = (int) (((0.1)+(1.071)+(0.1)+(32.605))/((84.612)+(54.02)+(74.093)));

}
tcb->m_cWnd = (int) (((70.497)+((tcb->m_ssThresh*(66.143)*(28.738)))+(0.1)+(0.1))/((0.1)+(0.1)+(39.06)+(67.378)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (((0.1)+(0.1)+((78.303+(58.646)+(51.309)+(tcb->m_ssThresh)+(96.253)))+(53.948)+(0.1)+(0.1)+(0.1))/((83.019)+(11.345)));
