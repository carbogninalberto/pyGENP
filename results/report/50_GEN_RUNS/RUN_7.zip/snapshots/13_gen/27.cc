tcb->m_cWnd = (int) (30.059-(44.256));
segmentsAcked = SlowStart (tcb, segmentsAcked);
int VdyTNdDhTEPXYIDQ = (int) (39.553/48.277);
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (VdyTNdDhTEPXYIDQ*(17.588)*(87.018)*(segmentsAcked)*(47.83)*(segmentsAcked)*(29.516));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (8.643+(36.044)+(0.675)+(16.788)+(tcb->m_cWnd)+(17.734)+(68.391)+(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (79.292*(86.499)*(0.697)*(12.132)*(42.574)*(6.447)*(72.07));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	VdyTNdDhTEPXYIDQ = (int) (tcb->m_cWnd*(35.271));
	tcb->m_cWnd = (int) ((51.642-(83.247)-(88.371)-(28.715))/0.1);

} else {
	VdyTNdDhTEPXYIDQ = (int) (97.781+(segmentsAcked)+(75.25)+(66.579)+(51.078)+(25.434)+(59.561)+(77.603));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (VdyTNdDhTEPXYIDQ == tcb->m_ssThresh) {
	VdyTNdDhTEPXYIDQ = (int) (89.781+(52.045)+(48.106)+(25.536)+(86.699)+(58.517));

} else {
	VdyTNdDhTEPXYIDQ = (int) (61.099*(70.338)*(tcb->m_cWnd)*(51.011)*(97.122)*(20.049)*(38.658));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((0.1)+(20.771)+(0.1)+(0.1)+(0.1)+(11.799)+(0.1))/((33.506)+(0.1)));
	tcb->m_cWnd = (int) (VdyTNdDhTEPXYIDQ*(95.734)*(51.171)*(99.721)*(34.428)*(99.6)*(97.982));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (0.1/58.658);
	ReduceCwnd (tcb);

}
