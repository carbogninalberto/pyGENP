tcb->m_segmentSize = (int) (49.789+(tcb->m_cWnd)+(tcb->m_ssThresh)+(27.86)+(segmentsAcked)+(66.711)+(57.449)+(54.888));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (0.483-(89.323)-(65.073)-(24.389)-(62.119)-(segmentsAcked));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	segmentsAcked = (int) (46.173*(17.151)*(26.545)*(32.81)*(88.25));
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(94.383)));

} else {
	segmentsAcked = (int) (65.474-(26.053)-(tcb->m_cWnd)-(8.752)-(65.938)-(30.447)-(95.325)-(39.986)-(tcb->m_ssThresh));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (12.478-(segmentsAcked)-(62.885)-(75.693)-(43.349));

}
ReduceCwnd (tcb);
