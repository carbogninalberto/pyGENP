CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-31.658/78.926);
ReduceCwnd (tcb);
segmentsAcked = (int) (-35.844+(41.51)+(86.079)+(79.497)+(56.096)+(-37.316)+(56.362));
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (70.726*(1.526)*(7.617)*(46.302)*(segmentsAcked));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+((tcb->m_cWnd+(35.415)+(8.347)+(58.064)+(80.269)+(tcb->m_ssThresh)))+(0.1)+(51.324))/((0.1)));

}
