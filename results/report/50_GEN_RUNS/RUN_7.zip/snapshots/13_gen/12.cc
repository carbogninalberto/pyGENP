tcb->m_segmentSize = (int) (35.07*(-0.565));
tcb->m_segmentSize = (int) (36.399*(64.873));
tcb->m_segmentSize = (int) (((-37.004)+(61.177)+(-74.014)+(98.44)+(-5.697)+(86.02)+(35.422))/((4.683)+(-5.862)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (((-38.786)+(-72.689)+(-35.516)+(14.501))/((79.825)+(8.751)));
tcb->m_cWnd = (int) (63.138-(-78.85)-(-35.558)-(-58.44)-(71.149));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (72.161*(-9.981));
