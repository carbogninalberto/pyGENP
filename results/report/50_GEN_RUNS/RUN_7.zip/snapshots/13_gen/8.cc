int VWcTVmGWUVqJADyO = (int) (53.147+(86.538)+(-73.484)+(86.314));
tcb->m_cWnd = (int) (-25.552*(-97.799)*(93.498)*(46.913)*(90.282)*(69.551));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (((-54.201)+(-18.53)+(-85.446)+(-14.88)+(12.571)+(-46.37))/((32.3)+(87.786)));
VWcTVmGWUVqJADyO = (int) (61.055+(24.123)+(-25.894)+(-32.971)+(-71.372)+(-6.35)+(27.665));
