tcb->m_segmentSize = (int) (-54.845*(-37.32));
tcb->m_segmentSize = (int) (((69.627)+(-38.09)+(41.22)+(51.181)+(-94.926)+(52.673)+(10.981))/((-35.716)+(-1.339)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (((41.294)+(70.706)+(4.364)+(53.159))/((27.101)+(30.268)));
tcb->m_cWnd = (int) (60.841-(46.437)-(27.424)-(21.316)-(76.772));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-32.112*(-68.688));
