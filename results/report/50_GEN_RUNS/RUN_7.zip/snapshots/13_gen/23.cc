tcb->m_segmentSize = (int) (52.175+(tcb->m_ssThresh));
tcb->m_segmentSize = (int) (tcb->m_ssThresh*(5.466)*(20.892)*(22.245));
tcb->m_ssThresh = (int) (93.757+(30.206));
tcb->m_cWnd = (int) (62.416+(78.384)+(73.478)+(41.949)+(95.253));
int unlKBEFuXJvqCBZf = (int) (82.707*(94.571)*(6.031)*(tcb->m_cWnd)*(74.163)*(50.756));
tcb->m_segmentSize = (int) (97.611*(tcb->m_ssThresh));
