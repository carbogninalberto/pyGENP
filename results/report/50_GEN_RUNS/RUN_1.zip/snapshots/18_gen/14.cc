segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-77.061-(62.851)-(6.219)-(-11.934)-(-59.544)-(-67.209));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
