if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (81.372*(7.558)*(17.375)*(75.119)*(32.504)*(tcb->m_ssThresh)*(7.449));

} else {
	tcb->m_cWnd = (int) (22.661*(34.426));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (segmentsAcked-(12.654));

}
int OChlDbkmShXFTajs = (int) (tcb->m_ssThresh-(7.186)-(27.067)-(tcb->m_cWnd)-(42.975)-(60.745)-(tcb->m_ssThresh));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
