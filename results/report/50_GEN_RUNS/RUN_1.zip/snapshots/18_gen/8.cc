float RFPbHEMokvgyFpMc = (float) 10.407;
tcb->m_cWnd = (int) (-85.202/-56.799);
segmentsAcked = (int) (-31.324/-35.404);
tcb->m_cWnd = (int) (2.463-(85.03)-(-54.47)-(81.024));
RFPbHEMokvgyFpMc = (float) (97.257+(76.324)+(-45.699)+(-51.937)+(25.36)+(0.87));
segmentsAcked = (int) (94.265+(31.715));
