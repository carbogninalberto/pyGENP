tcb->m_segmentSize = (int) (-68.77/(-32.043*(99.632)*(-9.806)*(-73.237)*(-54.372)*(-17.379)*(-32.043)));
if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (83.851-(tcb->m_cWnd)-(segmentsAcked)-(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (18.186*(89.36)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(61.274)*(15.89)*(17.481)*(84.864)*(52.74));

} else {
	segmentsAcked = (int) (43.492*(98.918)*(tcb->m_cWnd)*(40.673)*(21.068)*(tcb->m_segmentSize));

}
segmentsAcked = (int) (-68.962*(11.37)*(-68.794)*(-83.499)*(29.278)*(62.831)*(83.987)*(-47.011)*(95.841));
tcb->m_segmentSize = (int) (31.064*(35.678)*(-32.702)*(-58.326)*(-70.095));
