CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) ((((94.23*(22.142)))+(0.1)+(0.1)+(0.1)+(9.556)+(90.276)+(15.56))/((0.1)));
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (82.961+(tcb->m_segmentSize)+(62.829)+(40.627)+(87.575)+(94.963)+(segmentsAcked)+(49.841)+(84.364));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked+(39.699));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
