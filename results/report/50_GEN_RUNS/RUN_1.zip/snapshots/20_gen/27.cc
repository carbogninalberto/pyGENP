if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (40.491*(25.9)*(tcb->m_cWnd)*(74.068)*(91.453)*(87.322));
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (14.842+(82.517)+(tcb->m_segmentSize)+(45.793)+(60.653)+(segmentsAcked)+(39.026)+(58.165)+(segmentsAcked));

}
tcb->m_cWnd = (int) (75.464/34.966);
ReduceCwnd (tcb);
float OFKOPuyvPOjpacLT = (float) (59.207+(70.32)+(56.548)+(41.11)+(49.068)+(98.042)+(52.081)+(65.955));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (45.134*(33.575)*(59.013)*(15.079)*(80.126)*(2.402)*(55.098));
