segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (67.478-(18.257)-(-99.488)-(3.666)-(-48.473)-(60.627));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
