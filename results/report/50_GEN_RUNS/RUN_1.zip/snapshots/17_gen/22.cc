TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (40.641-(29.409)-(1.254));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (74.197+(56.202)+(90.887)+(71.328)+(38.589)+(78.15)+(51.834)+(96.568)+(9.499));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (26.415/52.939);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (40.44/97.29);
