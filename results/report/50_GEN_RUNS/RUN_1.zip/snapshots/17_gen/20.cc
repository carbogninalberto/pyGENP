tcb->m_ssThresh = (int) (57.394+(3.03)+(34.77)+(86.002)+(63.381));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (31.946+(tcb->m_cWnd)+(57.488)+(21.996)+(94.385));
	segmentsAcked = (int) (70.594+(64.525)+(13.404)+(98.81)+(0.234)+(segmentsAcked)+(35.087)+(55.431));
	tcb->m_ssThresh = (int) (49.36*(86.694)*(1.172)*(75.795)*(37.12)*(1.552)*(7.403));

} else {
	tcb->m_ssThresh = (int) (55.487*(79.29)*(tcb->m_cWnd)*(92.073));
	tcb->m_cWnd = (int) (segmentsAcked+(80.647)+(tcb->m_segmentSize)+(71.631)+(42.101)+(90.538));
	tcb->m_segmentSize = (int) (9.87+(97.591)+(79.181)+(31.687)+(tcb->m_segmentSize)+(39.332)+(86.21)+(89.202)+(91.979));

}
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (32.002/0.1);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(58.328)-(49.995)-(tcb->m_cWnd)-(39.284));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) ((32.372+(43.438)+(39.274)+(22.601)+(95.012)+(29.524))/6.343);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (0.1/0.1);
tcb->m_segmentSize = (int) (45.793*(15.529)*(12.859)*(tcb->m_cWnd)*(53.52)*(tcb->m_segmentSize));
