float RFPbHEMokvgyFpMc = (float) 91.795;
tcb->m_cWnd = (int) (59.055/54.893);
segmentsAcked = (int) (78.407/17.345);
tcb->m_cWnd = (int) (22.194-(38.855)-(-5.11)-(26.768));
RFPbHEMokvgyFpMc = (float) (35.286+(-33.064)+(-5.391)+(17.94)+(64.926)+(99.262));
segmentsAcked = (int) (33.967+(74.716));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
