int vOfBHhraSaRJjUfQ = (int) (-10.938*(82.049)*(-55.678)*(71.064));
