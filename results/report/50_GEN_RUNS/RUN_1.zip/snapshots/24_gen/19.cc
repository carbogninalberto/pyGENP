float akZckcvQifeHIxxa = (float) (61.313*(-19.754)*(-68.91)*(-88.726)*(62.446)*(30.309));
