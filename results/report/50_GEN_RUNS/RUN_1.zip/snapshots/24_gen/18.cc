float uidVhQuGHTyLisXx = (float) (-28.626*(10.103)*(86.339));
int pgQTnbaypkfjGQIf = (int) (94.492*(-34.31)*(-9.099)*(2.004)*(31.698)*(-62.739));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
