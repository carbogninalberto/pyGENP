if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (52.105*(55.667)*(tcb->m_ssThresh)*(32.632)*(53.691)*(91.062)*(8.18)*(12.518));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (28.083-(tcb->m_cWnd)-(36.199)-(95.642));

}
tcb->m_segmentSize = (int) (92.055*(9.698)*(tcb->m_cWnd)*(59.48)*(21.384)*(76.71)*(53.83)*(5.302)*(40.713));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (31.786*(15.229));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (0.1/(6.497*(segmentsAcked)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (18.529-(35.894)-(34.514)-(84.145));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (57.21-(42.459));

}
