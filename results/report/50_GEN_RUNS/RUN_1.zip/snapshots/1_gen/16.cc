segmentsAcked = (int) (((0.1)+(0.1)+(9.91)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (0.1/0.1);
tcb->m_cWnd = (int) (53.885/86.722);
