if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_segmentSize = (int) ((62.155+(49.278)+(tcb->m_segmentSize)+(75.365)+(21.239)+(56.585))/7.736);

} else {
	tcb->m_segmentSize = (int) (segmentsAcked-(55.993)-(53.97)-(70.623)-(84.281)-(42.984)-(39.094)-(67.27)-(68.396));
	tcb->m_ssThresh = (int) (90.382-(66.959)-(43.94)-(2.546)-(60.03));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (0.1/0.1);
if (segmentsAcked >= segmentsAcked) {
	tcb->m_cWnd = (int) (86.256-(73.719)-(tcb->m_cWnd)-(57.946)-(7.533)-(38.74)-(40.141)-(80.348)-(74.8));
	tcb->m_ssThresh = (int) (79.417*(4.494)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(23.708)*(tcb->m_segmentSize));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(98.554));
	tcb->m_ssThresh = (int) (52.28+(60.6)+(49.046)+(32.617)+(36.031)+(tcb->m_ssThresh)+(36.673)+(56.802)+(28.054));

}
tcb->m_cWnd = (int) (tcb->m_segmentSize+(70.99)+(segmentsAcked)+(2.157)+(11.973)+(66.863));
tcb->m_segmentSize = (int) (7.673*(77.429)*(tcb->m_segmentSize));
