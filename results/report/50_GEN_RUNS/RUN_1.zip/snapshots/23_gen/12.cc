tcb->m_cWnd = (int) (78.885*(-96.743));
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (83.733-(52.411));
	segmentsAcked = (int) ((((77.286-(tcb->m_cWnd)-(2.923)-(89.699)-(79.01)))+(0.1)+((38.333-(83.556)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(51.951)-(79.578)-(46.003)))+(67.609))/((41.163)+(37.061)));

}
tcb->m_segmentSize = (int) (-53.977-(-27.544)-(-39.281)-(62.326)-(-9.068)-(-37.364));
