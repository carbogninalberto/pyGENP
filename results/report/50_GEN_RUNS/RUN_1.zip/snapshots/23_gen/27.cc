segmentsAcked = (int) (3.821*(-33.056)*(13.585)*(-77.705));
int pgQTnbaypkfjGQIf = (int) (-6.254*(8.143)*(38.896)*(-8.144)*(80.919)*(-81.387));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float uidVhQuGHTyLisXx = (float) (-50.364*(-45.065)*(25.875));
