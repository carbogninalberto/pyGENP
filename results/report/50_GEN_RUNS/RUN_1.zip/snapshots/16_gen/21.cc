CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (61.61/13.039);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (97.106*(2.683)*(1.783)*(84.38)*(48.009)*(tcb->m_segmentSize)*(82.303)*(52.1)*(10.398));
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_segmentSize = (int) (7.855/0.1);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	ReduceCwnd (tcb);
	segmentsAcked = (int) (((3.699)+((7.813-(tcb->m_ssThresh)-(73.017)))+(39.509)+(79.599)+(0.1)+(0.1))/((0.1)));

}
segmentsAcked = (int) (76.802*(31.021));
