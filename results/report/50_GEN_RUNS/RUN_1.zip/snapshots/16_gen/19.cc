ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (39.066+(38.031)+(13.016));

} else {
	tcb->m_cWnd = (int) (24.674-(91.817)-(segmentsAcked)-(tcb->m_segmentSize)-(58.765)-(5.904)-(27.042)-(34.43)-(45.235));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(28.605));

}
