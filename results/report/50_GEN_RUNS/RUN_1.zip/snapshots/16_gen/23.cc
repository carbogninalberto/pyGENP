if (tcb->m_ssThresh <= tcb->m_cWnd) {
	segmentsAcked = (int) (3.328*(16.192)*(60.462)*(92.539)*(97.609)*(88.254));

} else {
	segmentsAcked = (int) (24.592-(32.071)-(29.551)-(36.897)-(2.562));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (segmentsAcked-(35.008)-(50.753)-(57.599)-(61.502)-(80.88)-(57.289)-(85.011)-(88.102));

}
tcb->m_segmentSize = (int) ((23.779+(42.92)+(67.546)+(tcb->m_ssThresh))/0.1);
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_ssThresh = (int) (41.872*(60.228)*(86.19)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(90.795)*(tcb->m_segmentSize)*(24.175));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (36.345+(39.159));
	segmentsAcked = (int) (0.23*(35.717)*(90.404)*(51.284)*(tcb->m_ssThresh)*(92.594)*(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (13.855+(tcb->m_segmentSize)+(53.216)+(tcb->m_segmentSize)+(37.072)+(90.515)+(70.99)+(tcb->m_cWnd));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	segmentsAcked = (int) (4.349*(6.382)*(93.432)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(9.355)*(tcb->m_cWnd)*(29.66)*(27.565));
	segmentsAcked = (int) (tcb->m_cWnd+(42.11)+(71.127)+(55.305));

} else {
	segmentsAcked = (int) (93.499*(94.496)*(63.904)*(tcb->m_segmentSize)*(59.317)*(tcb->m_ssThresh)*(48.312)*(49.021)*(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (99.432-(21.114)-(7.923)-(44.475)-(33.998));
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(5.187)+(tcb->m_segmentSize)+(37.57)+(19.381)+(40.172)+(72.422)+(26.795)+(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (92.989+(51.26)+(41.574)+(89.415)+(12.276)+(tcb->m_ssThresh)+(98.678));

} else {
	tcb->m_cWnd = (int) (93.235+(84.029)+(93.138)+(38.089)+(tcb->m_ssThresh)+(65.226)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(41.623));

}
int TtJymOIdiHMDnbrF = (int) (tcb->m_ssThresh+(81.544)+(8.042)+(77.166)+(68.357)+(25.159)+(segmentsAcked));
