float JIxHWYuuWNZLgLeg = (float) (42.79+(tcb->m_segmentSize)+(42.009)+(38.438));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (62.49-(18.205)-(73.383)-(tcb->m_segmentSize)-(71.031)-(JIxHWYuuWNZLgLeg));
tcb->m_ssThresh = (int) (40.8*(JIxHWYuuWNZLgLeg)*(tcb->m_cWnd)*(6.26)*(24.606));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
