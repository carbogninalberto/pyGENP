int YzeigrrxeMKDWxfB = (int) (4.322*(74.471));
int krvdobDvaEJNJcFF = (int) 98.62;
tcb->m_segmentSize = (int) (75.428+(88.023));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) ((-18.656+(-43.403)+(-53.952)+(-10.556)+(33.693))/-30.313);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
