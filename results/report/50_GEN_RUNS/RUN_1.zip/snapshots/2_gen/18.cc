float dGHDDOirKIBgSpWC = (float) (-73.98+(-94.412)+(9.997));
tcb->m_cWnd = (int) (-8.648-(-5.568));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (14.832/-85.609);
tcb->m_cWnd = (int) (-38.16*(96.906)*(-41.61)*(-83.601)*(11.089)*(59.232)*(46.559)*(-49.097));
tcb->m_cWnd = (int) (34.442/-12.996);
tcb->m_cWnd = (int) (-47.751*(-21.91)*(58.703)*(-23.716)*(42.974)*(51.816)*(-77.725)*(33.205));
