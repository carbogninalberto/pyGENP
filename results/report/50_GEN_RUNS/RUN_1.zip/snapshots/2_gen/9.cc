CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_cWnd <= segmentsAcked) {
	segmentsAcked = (int) (10.346-(46.582));

} else {
	segmentsAcked = (int) (93.516+(90.625)+(49.714)+(20.807)+(25.708)+(37.628)+(68.45)+(45.378)+(51.529));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) ((((-55.033*(tcb->m_ssThresh)*(2.932)*(70.175)*(-84.706)*(56.113)*(70.469)))+(-32.719)+(-59.869)+((12.176-(tcb->m_ssThresh)-(1.99)-(1.812)-(43.207)-(27.845)-(-55.884)-(68.582)-(90.943)))+(-88.503))/((27.168)+(81.945)+(-62.922)));
