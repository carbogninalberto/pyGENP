tcb->m_segmentSize = (int) (-81.383-(32.716)-(68.371)-(64.3)-(52.501)-(60.192)-(-74.737)-(-19.662)-(92.515));
segmentsAcked = (int) ((((23.379-(29.877)))+((-21.918*(-75.326)*(99.098)))+(-11.42)+(73.339)+(13.876))/((44.962)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-42.772+(64.697)+(47.995)+(-91.783)+(30.684)+(-44.598)+(71.681)+(65.887)+(48.763));
segmentsAcked = (int) ((((-10.181-(-24.276)))+((22.769*(-78.23)*(40.565)))+(35.6)+(-57.655)+(-96.499))/((-8.697)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-6.735+(-12.045)+(57.31)+(77.433)+(-82.601)+(-25.194)+(-18.948)+(-57.406)+(60.866));
