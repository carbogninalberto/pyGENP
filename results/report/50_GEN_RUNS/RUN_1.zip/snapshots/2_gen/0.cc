tcb->m_segmentSize = (int) (97.827-(-43.138)-(-51.457)-(-76.728)-(-81.694)-(11.886)-(-85.103)-(-96.014)-(-8.054));
segmentsAcked = (int) ((((25.168-(-7.041)))+((-92.64*(45.501)*(9.214)))+(-29.71)+(59.163)+(-2.335))/((-60.09)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (79.719+(48.012)+(-4.333)+(39.318)+(-66.426)+(74.772)+(78.439)+(66.762)+(-50.298));
