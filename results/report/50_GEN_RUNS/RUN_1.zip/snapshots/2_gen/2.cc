float BAUsvOvdlhUlTZoN = (float) (-55.206+(67.024));
int OXPelictCqwaUNVv = (int) (-32.105-(54.878)-(-88.125)-(22.431)-(78.2)-(-16.546));
ReduceCwnd (tcb);
segmentsAcked = (int) (-11.282+(84.299)+(52.285)+(-68.778)+(-15.371)+(27.851)+(75.951));
ReduceCwnd (tcb);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (1.226*(OXPelictCqwaUNVv)*(77.429)*(BAUsvOvdlhUlTZoN));
	tcb->m_cWnd = (int) (65.819-(69.618));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (2.456-(48.266)-(56.713)-(segmentsAcked));

}
