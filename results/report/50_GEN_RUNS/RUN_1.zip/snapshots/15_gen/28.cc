tcb->m_ssThresh = (int) (49.189*(61.352)*(66.298)*(tcb->m_ssThresh)*(94.543)*(tcb->m_cWnd)*(96.522));
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (74.394+(tcb->m_cWnd)+(tcb->m_cWnd)+(35.836)+(20.355)+(42.99));

} else {
	tcb->m_cWnd = (int) (22.073/35.597);
	tcb->m_ssThresh = (int) (29.706+(49.255));
	tcb->m_segmentSize = (int) (((37.255)+(0.1)+((tcb->m_cWnd-(58.766)-(42.942)-(tcb->m_ssThresh)-(61.7)-(12.708)-(tcb->m_segmentSize)))+(1.959)+(0.1))/((48.94)));

}
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	segmentsAcked = (int) (1.608+(tcb->m_ssThresh)+(2.342)+(0.79)+(57.806)+(33.401)+(segmentsAcked)+(segmentsAcked)+(segmentsAcked));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh*(91.668)*(1.127)*(32.907));
	tcb->m_cWnd = (int) (5.377+(46.953));

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	segmentsAcked = (int) ((27.089-(tcb->m_cWnd)-(tcb->m_segmentSize))/0.1);

} else {
	segmentsAcked = (int) (47.872*(segmentsAcked)*(99.93)*(tcb->m_segmentSize)*(87.064)*(tcb->m_ssThresh)*(71.348)*(95.688)*(tcb->m_cWnd));
	segmentsAcked = (int) (25.256*(31.738)*(14.233));

}
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (59.906-(tcb->m_ssThresh)-(27.093)-(71.784)-(segmentsAcked)-(15.501)-(47.43)-(tcb->m_segmentSize)-(tcb->m_cWnd));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (47.079*(43.908)*(10.893)*(14.328)*(40.667));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
