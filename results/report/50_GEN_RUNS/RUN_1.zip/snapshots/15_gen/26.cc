tcb->m_cWnd = (int) (63.204*(0.732)*(55.894)*(segmentsAcked));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (80.221*(49.521)*(tcb->m_segmentSize)*(11.165)*(51.285)*(8.499)*(37.341)*(53.878)*(segmentsAcked));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (12.622+(89.929)+(92.219)+(tcb->m_ssThresh)+(10.362));
	tcb->m_cWnd = (int) (60.52+(81.671)+(70.751)+(74.349));

} else {
	tcb->m_segmentSize = (int) (17.116/56.334);

}
int HNlwvbzQLclbFDSB = (int) (50.164-(18.013)-(89.495)-(50.352)-(tcb->m_segmentSize)-(56.375));
