tcb->m_segmentSize = (int) (tcb->m_segmentSize-(48.326)-(27.541)-(tcb->m_ssThresh));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) ((((tcb->m_cWnd-(22.919)-(20.333)-(tcb->m_cWnd)))+(47.956)+(88.147)+(47.629)+(0.1))/((0.1)+(74.604)+(0.1)+(43.979)));
ReduceCwnd (tcb);
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (95.217*(28.88)*(94.528)*(87.563)*(46.847)*(tcb->m_segmentSize)*(62.89)*(64.49)*(31.595));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked+(68.831)+(17.197)+(6.661)+(64.522)+(49.134)+(2.545)+(tcb->m_ssThresh));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
