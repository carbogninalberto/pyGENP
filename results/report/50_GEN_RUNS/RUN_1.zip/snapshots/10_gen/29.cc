int EcbafYukWpTggthT = (int) (0.1/37.411);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (((0.1)+(63.815)+(8.454)+(0.1))/((0.1)+(0.1)+(87.681)));
if (segmentsAcked > tcb->m_ssThresh) {
	EcbafYukWpTggthT = (int) (((76.637)+(21.419)+(13.374)+(0.1)+(0.1))/((0.1)+(0.1)+(88.923)));
	tcb->m_cWnd = (int) (34.728-(91.055)-(27.891)-(tcb->m_ssThresh)-(64.601)-(41.055));

} else {
	EcbafYukWpTggthT = (int) (36.595+(95.787));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (55.701*(34.074)*(9.827));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (91.795*(77.408)*(EcbafYukWpTggthT)*(4.282)*(segmentsAcked)*(4.546)*(96.778));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (54.859*(21.374));

}
