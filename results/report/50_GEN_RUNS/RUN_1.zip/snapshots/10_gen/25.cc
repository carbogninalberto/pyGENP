segmentsAcked = (int) (tcb->m_ssThresh*(60.186)*(29.152)*(61.712)*(8.035)*(4.716)*(6.532)*(41.938)*(63.15));
ReduceCwnd (tcb);
segmentsAcked = (int) (69.076*(99.704)*(tcb->m_cWnd));
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (29.742-(78.317)-(tcb->m_cWnd)-(74.024)-(30.657));
	tcb->m_cWnd = (int) (4.119-(tcb->m_cWnd)-(72.883)-(3.028)-(9.035));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(27.128));
	segmentsAcked = (int) (21.627*(78.988)*(47.27)*(tcb->m_cWnd)*(54.527)*(tcb->m_cWnd));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((19.898-(17.515)-(66.161)-(tcb->m_cWnd)-(tcb->m_cWnd)-(37.8))/0.1);
tcb->m_cWnd = (int) (73.316-(68.357)-(35.394)-(85.347)-(24.972)-(99.8)-(56.776)-(56.25));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
