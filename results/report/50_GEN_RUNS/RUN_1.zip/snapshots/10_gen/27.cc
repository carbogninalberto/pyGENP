segmentsAcked = (int) (61.335-(segmentsAcked)-(87.788));
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	segmentsAcked = (int) (56.877-(59.893)-(11.306)-(89.989)-(76.951));

} else {
	segmentsAcked = (int) (32.985+(tcb->m_segmentSize)+(33.651)+(50.862));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float UaVvoFxaEFlbrQoi = (float) (38.598+(90.655)+(91.998)+(75.863)+(84.615));
