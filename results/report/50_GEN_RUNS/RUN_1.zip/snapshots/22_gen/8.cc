int pgQTnbaypkfjGQIf = (int) (-57.255*(-22.016)*(67.627)*(92.464)*(95.443)*(72.67));
float uidVhQuGHTyLisXx = (float) (94.825*(-25.497)*(-81.731));
segmentsAcked = (int) (42.617*(25.936)*(-37.824)*(-79.064));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
