tcb->m_segmentSize = (int) (-64.959*(-12.934)*(-5.741)*(-19.568));
float BxMjvvtBOLTtdRmb = (float) (96.528*(76.263)*(-49.685));
CongestionAvoidance (tcb, segmentsAcked);
int ptGMwvqipxbmuTCa = (int) ((-22.748*(3.683)*(69.835)*(-99.218)*(63.476)*(38.989)*(46.068)*(99.881))/-46.939);
segmentsAcked = SlowStart (tcb, segmentsAcked);
