float CNBVGwSHAqzTJCVt = (float) 10.19;
