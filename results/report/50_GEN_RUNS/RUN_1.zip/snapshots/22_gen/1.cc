int wHGBFiepucrQTqKO = (int) (80.059+(-99.834)+(26.596)+(-61.699)+(88.032));
float zhrFzwlfqEYEovUx = (float) (-93.885*(-39.466));
