if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_cWnd = (int) (segmentsAcked*(92.108)*(77.05)*(95.353));

} else {
	tcb->m_cWnd = (int) (segmentsAcked+(2.733));

}
if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (83.851-(tcb->m_cWnd)-(segmentsAcked)-(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (18.186*(89.36)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(61.274)*(15.89)*(17.481)*(84.864)*(52.74));

} else {
	segmentsAcked = (int) (43.492*(98.918)*(tcb->m_cWnd)*(40.673)*(21.068)*(tcb->m_segmentSize));

}
segmentsAcked = (int) (-20.175*(91.066)*(-83.029)*(94.704)*(38.364)*(-85.968)*(65.603)*(-16.509)*(-9.138));
tcb->m_segmentSize = (int) (-23.719*(-93.744)*(61.406)*(-75.492)*(37.238));
