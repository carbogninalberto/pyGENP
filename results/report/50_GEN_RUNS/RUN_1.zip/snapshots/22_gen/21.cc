TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_segmentSize) {
	segmentsAcked = (int) (83.733-(52.411));
	segmentsAcked = (int) ((((77.286-(tcb->m_cWnd)-(2.923)-(89.699)-(79.01)))+(0.1)+((38.333-(83.556)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(51.951)-(79.578)-(46.003)))+(67.609))/((41.163)+(37.061)));

} else {
	segmentsAcked = (int) (0.1/0.1);

}
