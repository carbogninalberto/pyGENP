segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(51.449)*(69.078)*(23.263)*(segmentsAcked)*(81.812)*(54.173)*(segmentsAcked)*(segmentsAcked));
	tcb->m_ssThresh = (int) ((((71.725*(tcb->m_cWnd)*(27.426)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(14.945)*(0.183)))+((85.33+(74.047)+(96.032)+(tcb->m_segmentSize)+(66.331)+(7.501)))+((84.481+(5.468)+(0.454)+(67.937)))+(0.1)+(0.1)+(0.1))/((0.1)+(94.244)));
	tcb->m_segmentSize = (int) (69.822-(tcb->m_ssThresh)-(73.633)-(32.578)-(68.062));

} else {
	tcb->m_cWnd = (int) (74.889/0.1);
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (30.643+(47.535)+(18.045)+(tcb->m_ssThresh)+(51.122)+(69.552));

} else {
	tcb->m_segmentSize = (int) (86.983*(89.212)*(4.752)*(71.044));
	tcb->m_ssThresh = (int) (83.779+(11.066)+(91.056)+(segmentsAcked)+(65.82));
	segmentsAcked = (int) (69.088/0.1);

}
tcb->m_cWnd = (int) (segmentsAcked-(33.851)-(segmentsAcked)-(72.902)-(29.512)-(0.811));
if (segmentsAcked < tcb->m_ssThresh) {
	segmentsAcked = (int) (68.412*(33.762)*(35.116)*(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (99.161+(55.666)+(44.747)+(tcb->m_cWnd)+(67.532));

} else {
	segmentsAcked = (int) (10.89*(73.411)*(5.252));
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (0.1/69.369);
