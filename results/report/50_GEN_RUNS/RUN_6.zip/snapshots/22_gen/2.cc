tcb->m_segmentSize = (int) (-44.817+(-7.491)+(-26.569)+(-50.032)+(-17.948)+(27.935)+(61.204));
float sZXkCwTuHhoFIZXZ = (float) 63.843;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_segmentSize) {
	sZXkCwTuHhoFIZXZ = (float) (((0.1)+(13.469)+(4.401)+(18.434))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (((54.998)+(29.252)+(0.1)+(70.856))/((0.1)+(47.951)+(27.092)+(0.1)));

} else {
	sZXkCwTuHhoFIZXZ = (float) (13.54*(84.101)*(66.373)*(45.771)*(29.808)*(54.179)*(7.513));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize <= sZXkCwTuHhoFIZXZ) {
	tcb->m_cWnd = (int) (4.652*(38.395)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(37.771)*(15.288));

} else {
	tcb->m_cWnd = (int) (8.145+(8.727)+(19.362)+(79.121)+(91.463)+(tcb->m_segmentSize)+(63.035)+(22.363));
	sZXkCwTuHhoFIZXZ = (float) (72.568/46.657);

}
