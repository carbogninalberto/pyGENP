int JPgsmiXRYktHXlRE = (int) (-30.769-(51.601));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((61.039*(20.203)*(17.133)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(56.027)*(tcb->m_ssThresh)*(18.462))/(78.354-(24.8)-(55.867)-(46.911)-(5.181)-(59.389)));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(71.003));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) ((13.66+(34.777)+(-66.191))/60.027);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((61.039*(20.203)*(17.133)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(56.027)*(tcb->m_ssThresh)*(18.462))/(78.354-(24.8)-(55.867)-(46.911)-(5.181)-(59.389)));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(71.003));

}
tcb->m_segmentSize = (int) ((68.098+(-56.681)+(-30.01))/-59.675);
