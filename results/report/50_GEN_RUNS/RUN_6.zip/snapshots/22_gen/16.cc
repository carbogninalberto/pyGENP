tcb->m_ssThresh = (int) (54.364-(25.853)-(78.363)-(tcb->m_ssThresh)-(46.232)-(2.073));
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_ssThresh*(31.491)*(68.375)*(66.987)*(3.839));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	segmentsAcked = (int) (83.693-(8.331));
	tcb->m_ssThresh = (int) (70.333-(10.49)-(85.629)-(70.166));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (((67.359)+(12.707)+((35.396-(53.306)-(tcb->m_cWnd)-(46.64)-(45.773)-(39.417)-(14.316)-(66.066)-(34.626)))+((65.644-(tcb->m_ssThresh)))+(2.447))/((40.232)));

}
segmentsAcked = (int) (53.812-(tcb->m_segmentSize)-(45.368)-(12.335));
