float OqYPKkUOBPgjiLdn = (float) (35.888+(-1.658)+(71.212)+(32.132)+(16.071)+(86.989));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-6.312*(-10.45)*(-72.805)*(-6.01)*(0.82)*(98.755)*(-94.205)*(-34.887)*(-36.288));
CongestionAvoidance (tcb, segmentsAcked);
