tcb->m_cWnd = (int) (-42.863*(14.377)*(-65.858));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (52.482*(68.561)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(37.774)*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (58.778-(segmentsAcked)-(60.616)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(15.306)-(71.178)-(66.398)-(1.697));
	segmentsAcked = (int) (0.1/0.1);
	segmentsAcked = (int) (43.416+(83.417)+(39.521)+(7.84)+(87.683)+(-38.642)+(74.898)+(17.006));

}
tcb->m_cWnd = (int) (0.224+(-93.974)+(73.117)+(-18.383)+(47.441)+(71.347)+(-18.118));
tcb->m_segmentSize = (int) (-36.777*(81.768)*(-42.903)*(88.31)*(69.211)*(-6.166)*(50.803));
segmentsAcked = (int) (-43.912+(39.798));
