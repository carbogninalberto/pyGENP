float qyDGACdRXfJoEgio = (float) (-41.269/-53.632);
tcb->m_segmentSize = (int) (61.272*(-25.547)*(-8.591)*(61.73)*(-40.975)*(76.241)*(28.786)*(-42.981)*(32.959));
tcb->m_segmentSize = (int) (71.413+(-46.133)+(-34.412)+(-36.098)+(-52.749)+(73.408)+(-29.185)+(98.738));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-72.027*(-97.237)*(-15.634)*(-76.592)*(85.217));
