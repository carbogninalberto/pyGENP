tcb->m_ssThresh = (int) (29.884-(31.326));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked == segmentsAcked) {
	tcb->m_cWnd = (int) (2.635*(50.527)*(55.664)*(34.431));
	tcb->m_segmentSize = (int) (85.001-(39.049)-(54.225)-(39.814)-(tcb->m_cWnd)-(90.79)-(68.825));

} else {
	tcb->m_cWnd = (int) (1.802+(81.936)+(tcb->m_cWnd)+(99.676));

}
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_ssThresh = (int) (2.87/15.343);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (62.101*(tcb->m_cWnd)*(segmentsAcked)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(14.896)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(47.191));
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(96.685)+(0.1))/((91.742)+(0.1)+(44.26)+(55.546)));

}
float reMNAxjVuYmShcDX = (float) (7.076*(42.861)*(57.823)*(37.309)*(32.916)*(97.992)*(90.711));
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (((0.1)+(63.875)+(30.587)+(0.1))/((57.909)));

}
segmentsAcked = (int) (42.378-(66.095)-(40.152)-(66.195)-(3.722)-(30.629)-(30.03));
if (tcb->m_segmentSize != reMNAxjVuYmShcDX) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(29.398)*(24.517)*(6.942)*(6.032)*(21.212)*(88.929));

} else {
	tcb->m_segmentSize = (int) (53.306-(34.697)-(tcb->m_segmentSize)-(18.137));
	tcb->m_segmentSize = (int) (74.638*(40.362)*(12.812)*(52.351)*(73.58)*(78.827)*(61.263));
	ReduceCwnd (tcb);

}
