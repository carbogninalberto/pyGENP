TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (35.285*(27.701)*(segmentsAcked)*(27.825)*(71.357)*(segmentsAcked)*(21.421));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
