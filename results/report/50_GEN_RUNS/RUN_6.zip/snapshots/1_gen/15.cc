segmentsAcked = (int) ((tcb->m_segmentSize*(50.916)*(77.453)*(42.831)*(76.597))/0.1);
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (44.627-(29.848)-(80.474));
	tcb->m_ssThresh = (int) (26.968-(0.175)-(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (3.435+(81.866)+(36.647)+(75.575)+(2.13));
	tcb->m_ssThresh = (int) (46.291*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(37.175));
	segmentsAcked = (int) (51.304/0.1);

}
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(tcb->m_segmentSize)-(15.972)-(96.284)-(52.864)-(5.773)-(10.923)-(31.939)-(74.362));

} else {
	tcb->m_cWnd = (int) ((15.709*(0.678)*(80.739)*(tcb->m_ssThresh)*(30.062)*(97.887)*(22.16)*(44.976)*(41.052))/0.1);

}
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_cWnd = (int) (57.118-(tcb->m_cWnd)-(41.972)-(87.01));
	segmentsAcked = (int) (5.992+(tcb->m_segmentSize)+(50.579));

} else {
	tcb->m_cWnd = (int) (28.083-(29.978)-(51.346));

}
segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(21.157));
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(tcb->m_cWnd)-(77.501));
	segmentsAcked = (int) (48.062-(11.285)-(tcb->m_segmentSize)-(44.653));

} else {
	tcb->m_cWnd = (int) (90.182-(tcb->m_segmentSize)-(98.858)-(11.555)-(51.569)-(58.831)-(87.798));
	tcb->m_cWnd = (int) (35.026/(61.104+(25.177)+(71.787)));
	tcb->m_segmentSize = (int) (44.863-(52.17)-(73.371));

}
