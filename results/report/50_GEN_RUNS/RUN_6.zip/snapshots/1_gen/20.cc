tcb->m_segmentSize = (int) (47.839-(94.903)-(43.885)-(segmentsAcked));
segmentsAcked = (int) (34.821/92.454);
tcb->m_cWnd = (int) (tcb->m_cWnd*(13.116)*(33.5)*(tcb->m_cWnd)*(30.153)*(tcb->m_cWnd)*(20.908)*(39.871));
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(67.033)-(tcb->m_cWnd)-(3.046)-(57.54)-(8.46)-(tcb->m_ssThresh)-(68.605));
	tcb->m_segmentSize = (int) (0.1/7.44);

} else {
	tcb->m_cWnd = (int) (((35.697)+((71.162*(segmentsAcked)*(29.384)))+((46.8*(68.669)))+(24.257))/((29.163)));

}
CongestionAvoidance (tcb, segmentsAcked);
