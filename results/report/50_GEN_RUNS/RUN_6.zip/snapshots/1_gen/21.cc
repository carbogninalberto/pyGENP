ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_segmentSize-(tcb->m_cWnd)-(81.761)-(36.916)-(25.943));
tcb->m_ssThresh = (int) ((8.413-(59.692)-(segmentsAcked)-(8.875)-(34.265)-(87.946)-(tcb->m_segmentSize))/54.899);
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (2.733-(21.796)-(73.932)-(tcb->m_segmentSize)-(42.281)-(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (32.652+(36.089));

}
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_ssThresh = (int) (segmentsAcked*(tcb->m_ssThresh)*(68.309));
	segmentsAcked = (int) (26.959*(54.967)*(26.386)*(26.497)*(26.768)*(16.591)*(87.55));
	tcb->m_segmentSize = (int) (37.619*(57.627)*(3.749));

} else {
	tcb->m_ssThresh = (int) (29.67-(17.879)-(58.585)-(92.386)-(94.15)-(72.312)-(78.477)-(21.136)-(30.209));
	tcb->m_cWnd = (int) (73.929-(32.162)-(86.361)-(47.278)-(tcb->m_cWnd));

}
