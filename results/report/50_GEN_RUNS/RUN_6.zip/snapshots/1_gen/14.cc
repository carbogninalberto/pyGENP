if (tcb->m_ssThresh <= tcb->m_cWnd) {
	segmentsAcked = (int) (74.475+(14.169)+(37.144)+(50.936)+(71.693)+(84.97)+(26.601)+(tcb->m_segmentSize)+(53.193));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (53.993*(52.374)*(92.144)*(51.146)*(71.918)*(93.905)*(11.466)*(22.732)*(19.081));
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(60.856)+(0.1)+(32.077)+(0.1)+(51.253))/((0.1)));
	segmentsAcked = (int) (0.1/0.1);

}
tcb->m_cWnd = (int) (24.545+(66.02)+(53.234));
tcb->m_cWnd = (int) (tcb->m_cWnd+(53.338)+(92.672)+(47.22)+(11.925)+(29.604));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (92.423*(63.261)*(51.571)*(94.289)*(44.017)*(54.993)*(79.572));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (0.1/64.643);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) ((((tcb->m_cWnd*(37.794)*(42.37)*(89.417)*(35.878)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(96.193)*(tcb->m_cWnd)))+(0.1)+(0.1)+(94.516)+(0.1)+(0.1))/((73.524)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (58.014-(31.248)-(78.495)-(93.615)-(41.15)-(0.642));

}
