tcb->m_segmentSize = (int) (83.507*(segmentsAcked)*(14.992)*(70.75));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (54.292*(segmentsAcked)*(tcb->m_cWnd)*(0.55)*(85.399)*(42.048)*(79.676)*(39.996)*(76.487));

} else {
	tcb->m_ssThresh = (int) (66.158+(tcb->m_cWnd)+(16.786));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(20.692)*(55.801));
	tcb->m_segmentSize = (int) (55.754-(51.562)-(3.63));

}
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((67.944)+(0.1)+(0.1)+(0.1)+(76.621)+(55.51))/((0.1)+(4.232)));
	segmentsAcked = (int) (16.609-(74.49)-(43.796)-(11.866)-(78.398)-(tcb->m_cWnd)-(71.842)-(99.781)-(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (63.594*(67.986)*(96.288)*(59.156)*(57.927));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (7.164+(segmentsAcked)+(64.308)+(tcb->m_segmentSize));

}
if (segmentsAcked > tcb->m_cWnd) {
	segmentsAcked = (int) (53.949+(83.197)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(segmentsAcked));

} else {
	segmentsAcked = (int) (((11.181)+((48.096-(50.948)-(17.335)-(18.319)-(segmentsAcked)-(87.234)-(tcb->m_segmentSize)))+(47.579)+(0.1)+(0.1))/((74.104)+(0.1)+(0.1)));

}
CongestionAvoidance (tcb, segmentsAcked);
