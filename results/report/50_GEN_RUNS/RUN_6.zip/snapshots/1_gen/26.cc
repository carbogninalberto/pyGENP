segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (0.1/51.347);
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(10.149)-(tcb->m_segmentSize)-(83.772)-(11.13)-(tcb->m_segmentSize)-(29.593)-(22.134));
	tcb->m_cWnd = (int) (70.77*(5.699));

} else {
	tcb->m_cWnd = (int) (76.998-(4.164)-(77.222)-(segmentsAcked)-(tcb->m_segmentSize)-(86.543)-(77.074)-(36.141)-(segmentsAcked));

}
tcb->m_segmentSize = (int) (33.293+(93.717));
