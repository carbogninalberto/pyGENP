int JSmaZMWTdelauzhl = (int) (75.022-(98.922)-(75.367)-(35.448)-(76.793)-(91.296)-(37.548));
if (tcb->m_ssThresh > segmentsAcked) {
	JSmaZMWTdelauzhl = (int) (tcb->m_ssThresh-(16.254)-(43.638));
	segmentsAcked = (int) (45.363-(38.411)-(7.383));
	tcb->m_cWnd = (int) (14.687-(21.723)-(67.801)-(27.176)-(tcb->m_segmentSize)-(92.401)-(94.41)-(77.173));

} else {
	JSmaZMWTdelauzhl = (int) (69.969+(tcb->m_ssThresh)+(18.237)+(27.507)+(30.732)+(tcb->m_ssThresh)+(99.442)+(45.983)+(88.351));

}
segmentsAcked = (int) (tcb->m_ssThresh*(59.109)*(tcb->m_ssThresh)*(1.486)*(tcb->m_segmentSize)*(37.011)*(19.482)*(29.972)*(33.976));
segmentsAcked = (int) (50.469*(31.81)*(29.546)*(60.736)*(30.435)*(tcb->m_ssThresh));
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (61.695*(59.839)*(tcb->m_ssThresh)*(JSmaZMWTdelauzhl)*(16.107));

} else {
	tcb->m_ssThresh = (int) (48.365+(85.964)+(3.254)+(46.117)+(85.509)+(tcb->m_segmentSize)+(10.167)+(25.775));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
