segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) ((((tcb->m_segmentSize-(55.435)-(79.418)-(90.889)))+(42.41)+((19.974*(74.766)*(54.394)*(31.236)*(32.276)*(74.407)))+(0.1)+(67.165)+(0.1))/((0.1)));
segmentsAcked = (int) (11.201*(33.704)*(31.239)*(33.89)*(tcb->m_cWnd)*(75.584)*(26.416));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (47.143/0.1);
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(95.283)-(93.104));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(95.187)-(90.488)-(56.388)-(44.4)-(83.731)-(tcb->m_segmentSize));

}
