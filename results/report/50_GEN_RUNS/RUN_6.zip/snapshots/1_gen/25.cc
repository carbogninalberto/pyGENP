segmentsAcked = (int) (0.1/73.548);
tcb->m_segmentSize = (int) (51.375+(55.264)+(tcb->m_segmentSize)+(segmentsAcked)+(52.246));
tcb->m_cWnd = (int) (20.666+(0.62)+(58.871)+(11.924)+(56.118)+(49.494)+(70.892)+(61.692));
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (61.416*(33.522)*(segmentsAcked)*(2.238)*(86.662));

} else {
	tcb->m_segmentSize = (int) (95.885-(0.638)-(35.53)-(7.537)-(45.727)-(30.543)-(tcb->m_ssThresh)-(28.27)-(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (31.75-(89.496)-(90.614));
	tcb->m_segmentSize = (int) (((0.1)+((49.86-(78.137)-(41.805)-(63.086)-(62.735)-(86.379)-(76.001)))+(84.938)+(0.1))/((0.1)+(98.276)+(0.1)+(51.734)+(0.1)));

}
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_segmentSize = (int) (16.192+(42.461));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (96.917+(78.841));

} else {
	tcb->m_segmentSize = (int) (88.265+(19.332)+(96.659)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(46.823)*(segmentsAcked)*(95.145)*(13.166));

}
