if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((0.1)+((segmentsAcked+(54.991)+(43.455)+(97.773)+(50.758)+(9.534)))+(53.754)+(36.126)+(0.1))/((0.1)+(3.427)+(0.1)+(0.1)));
	tcb->m_ssThresh = (int) (61.481+(93.864)+(11.582)+(86.435)+(91.814)+(30.625)+(42.368));

} else {
	tcb->m_cWnd = (int) (79.844+(56.227)+(segmentsAcked));

}
tcb->m_cWnd = (int) (10.906-(48.953)-(76.361));
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_segmentSize = (int) (23.153*(84.876)*(61.032)*(42.398)*(25.688));
	segmentsAcked = (int) (tcb->m_ssThresh*(19.728)*(14.459)*(95.704)*(22.049)*(tcb->m_cWnd)*(16.882)*(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (93.509/0.1);

} else {
	tcb->m_segmentSize = (int) (((51.816)+(17.959)+(0.1)+(0.1))/((0.1)+(0.1)));
	tcb->m_segmentSize = (int) (82.098+(14.41)+(tcb->m_segmentSize)+(45.797));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (83.668*(2.458)*(30.091));
