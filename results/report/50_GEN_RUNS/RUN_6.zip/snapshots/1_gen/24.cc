tcb->m_ssThresh = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(35.709)*(4.067)*(97.113)*(95.482)*(87.1)*(segmentsAcked)*(41.87));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (38.845*(21.926)*(segmentsAcked)*(58.58)*(72.481)*(77.037)*(87.594)*(tcb->m_ssThresh));
segmentsAcked = (int) (64.455*(92.331)*(96.591)*(87.821)*(13.166));
segmentsAcked = (int) (0.1/0.1);
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((65.974+(54.257)+(83.753)+(56.247))/0.1);
	tcb->m_ssThresh = (int) (((74.072)+(39.164)+((75.653*(33.964)*(tcb->m_cWnd)*(7.368)*(26.044)*(34.038)*(41.008)*(57.157)*(96.114)))+(0.1))/((0.1)+(94.08)));
	segmentsAcked = (int) (9.053-(61.236)-(57.432)-(tcb->m_cWnd)-(81.809)-(13.002));

} else {
	tcb->m_cWnd = (int) (90.185+(35.456)+(20.302)+(20.427)+(14.867));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (40.965+(78.845)+(tcb->m_cWnd)+(58.642)+(tcb->m_cWnd)+(25.393)+(50.098));

}
