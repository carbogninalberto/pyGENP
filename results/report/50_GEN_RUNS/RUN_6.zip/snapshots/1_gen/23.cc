CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (23.317/0.1);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (13.126*(76.106)*(67.857)*(segmentsAcked)*(86.716)*(97.741));
