tcb->m_segmentSize = (int) ((59.304-(35.987)-(11.415)-(64.734)-(98.327)-(86.489)-(61.299)-(89.723)-(52.736))/59.067);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (45.422/39.411);
tcb->m_ssThresh = (int) (67.226*(66.651)*(21.47)*(11.887)*(segmentsAcked)*(66.776)*(98.644));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (26.438*(tcb->m_cWnd)*(29.978)*(tcb->m_segmentSize));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
