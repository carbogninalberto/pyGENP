if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (46.409*(37.194));
	tcb->m_cWnd = (int) (2.998*(18.408));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(tcb->m_cWnd)+(47.947)+(23.005)+(8.683)+(6.574));
	tcb->m_segmentSize = (int) (19.367-(35.761));

}
segmentsAcked = (int) (89.387*(56.183)*(51.911)*(-59.618));
