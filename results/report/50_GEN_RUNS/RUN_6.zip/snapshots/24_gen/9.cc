ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (93.337*(49.395)*(-65.112)*(23.896)*(94.982)*(64.758)*(43.252)*(14.852)*(-26.779));
tcb->m_segmentSize = (int) (-71.756*(34.095)*(-28.365)*(12.684)*(-87.733)*(-54.999)*(36.219)*(95.482)*(-35.299));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
