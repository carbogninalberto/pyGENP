int uzkfYoNqmffskSQa = (int) (-97.206*(16.681)*(-20.138)*(-88.181)*(17.971)*(76.712)*(-20.902));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (9.527-(49.661)-(75.421)-(40.167)-(51.745)-(96.198));

} else {
	segmentsAcked = (int) (51.969*(70.397)*(63.601)*(50.788));

}
int KQinxCjQLTqvqKIG = (int) (0.767/-29.768);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/63.855);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (39.599*(tcb->m_cWnd)*(39.731));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (34.723*(34.222)*(27.954)*(96.11));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(26.671)-(47.767)-(65.768)-(70.179)-(49.382)-(segmentsAcked)-(tcb->m_cWnd)-(98.764));

}
tcb->m_segmentSize = (int) (20.643-(-35.353)-(27.254)-(78.937)-(-87.685)-(-25.178)-(47.742)-(-58.298)-(31.472));
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (86.554+(75.51)+(uzkfYoNqmffskSQa)+(70.795)+(10.409)+(87.166)+(57.735));
	tcb->m_segmentSize = (int) (-51.833-(89.655));

} else {
	segmentsAcked = (int) (73.461+(20.335)+(tcb->m_segmentSize)+(1.922)+(14.268)+(7.449)+(tcb->m_segmentSize)+(67.636)+(92.604));

}
