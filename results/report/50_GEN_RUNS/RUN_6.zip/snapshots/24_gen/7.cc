int uzkfYoNqmffskSQa = (int) (-16.036*(-82.087)*(-41.444)*(-14.788)*(-43.635)*(91.929)*(-4.127));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (9.527-(49.661)-(75.421)-(40.167)-(51.745)-(97.387));

} else {
	segmentsAcked = (int) (51.969*(70.397)*(63.601)*(50.788));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (9.527-(49.661)-(75.421)-(40.167)-(51.745)-(-74.14));

} else {
	segmentsAcked = (int) (51.969*(70.397)*(63.601)*(50.788));

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/63.855);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (39.599*(tcb->m_cWnd)*(39.731));

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/63.855);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (39.599*(tcb->m_cWnd)*(39.731));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (34.723*(34.222)*(27.954)*(96.11));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(26.671)-(47.767)-(65.768)-(70.179)-(49.382)-(segmentsAcked)-(tcb->m_cWnd)-(98.764));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (34.723*(34.222)*(27.954)*(96.11));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(26.671)-(47.767)-(65.768)-(70.179)-(49.382)-(segmentsAcked)-(tcb->m_cWnd)-(98.764));

}
tcb->m_segmentSize = (int) (79.117-(62.159)-(79.189)-(77.803)-(4.764)-(-50.213)-(-34.006)-(67.426)-(66.443));
tcb->m_segmentSize = (int) (-50.762-(-41.59)-(-52.27)-(-9.841)-(75.183)-(88.51)-(75.812)-(37.838)-(-99.618));
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (86.554+(75.51)+(uzkfYoNqmffskSQa)+(70.795)+(10.409)+(87.166)+(57.735));
	tcb->m_segmentSize = (int) (81.75-(89.655));

} else {
	segmentsAcked = (int) (73.461+(20.335)+(tcb->m_segmentSize)+(1.922)+(14.268)+(7.449)+(tcb->m_segmentSize)+(67.636)+(92.604));

}
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (86.554+(75.51)+(uzkfYoNqmffskSQa)+(70.795)+(10.409)+(87.166)+(57.735));
	tcb->m_segmentSize = (int) (-37.678-(89.655));

} else {
	segmentsAcked = (int) (73.461+(20.335)+(tcb->m_segmentSize)+(1.922)+(14.268)+(7.449)+(tcb->m_segmentSize)+(67.636)+(92.604));

}
