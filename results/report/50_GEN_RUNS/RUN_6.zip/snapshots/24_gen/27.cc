if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (31.324-(74.742)-(3.61)-(segmentsAcked)-(52.108)-(27.131)-(34.092));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (0.1/59.668);
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (50.857-(99.685)-(23.818)-(35.801)-(20.12)-(86.132)-(segmentsAcked)-(90.835));

} else {
	tcb->m_segmentSize = (int) (68.787-(96.071)-(92.481)-(76.371)-(43.113));

}
tcb->m_ssThresh = (int) (0.1/0.1);
tcb->m_cWnd = (int) (tcb->m_ssThresh*(58.58)*(94.241));
ReduceCwnd (tcb);
int kQqfftqvYSSOYZBY = (int) (31.231+(13.164)+(27.399)+(68.539)+(83.232)+(69.539)+(43.335)+(60.429));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) (kQqfftqvYSSOYZBY+(97.523)+(33.037)+(83.193)+(22.802));
	tcb->m_segmentSize = (int) (68.579-(91.133)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (((0.1)+(80.909)+(17.352)+((15.759+(70.562)+(88.235)+(52.591)+(65.282)+(16.578)+(tcb->m_cWnd)+(47.81)))+(60.377))/((16.956)+(0.1)+(83.51)+(0.1)));
	kQqfftqvYSSOYZBY = (int) (78.352/0.1);

}
