CongestionAvoidance (tcb, segmentsAcked);
float BnbxPMwYqjJSGiam = (float) ((47.636*(tcb->m_cWnd)*(90.709)*(86.548)*(12.783)*(segmentsAcked)*(44.779))/23.11);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (8.406-(78.9)-(66.065)-(53.652));
	tcb->m_segmentSize = (int) (segmentsAcked*(segmentsAcked)*(BnbxPMwYqjJSGiam)*(18.363)*(tcb->m_ssThresh)*(6.614)*(18.671)*(1.27));

} else {
	tcb->m_cWnd = (int) (BnbxPMwYqjJSGiam*(40.394)*(39.117)*(13.57)*(tcb->m_ssThresh)*(79.762)*(96.33));

}
if (segmentsAcked > segmentsAcked) {
	tcb->m_cWnd = (int) (32.917*(segmentsAcked)*(7.12)*(14.319));

} else {
	tcb->m_cWnd = (int) (16.268-(30.066)-(77.011)-(BnbxPMwYqjJSGiam)-(35.176)-(BnbxPMwYqjJSGiam));
	ReduceCwnd (tcb);

}
