tcb->m_cWnd = (int) (((86.117)+(0.1)+(38.853)+(0.1)+(0.1))/((0.1)));
tcb->m_ssThresh = (int) (58.586+(19.412)+(35.161)+(63.25)+(85.617)+(29.888));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (19.582-(96.703)-(tcb->m_ssThresh)-(33.396)-(4.96)-(21.979));
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(40.453));

} else {
	tcb->m_ssThresh = (int) (67.705*(tcb->m_cWnd)*(79.907)*(56.895)*(35.527)*(16.679)*(5.708)*(87.207));

}
tcb->m_cWnd = (int) (99.373+(51.998)+(segmentsAcked)+(31.015)+(tcb->m_ssThresh));
