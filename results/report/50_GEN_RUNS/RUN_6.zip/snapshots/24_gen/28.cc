if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_segmentSize = (int) (40.462*(tcb->m_ssThresh)*(36.365)*(28.134)*(48.276)*(24.869)*(43.182));
	tcb->m_segmentSize = (int) (22.425/72.929);
	tcb->m_ssThresh = (int) (51.402+(58.673)+(49.524)+(88.544)+(tcb->m_cWnd)+(87.815));

} else {
	tcb->m_segmentSize = (int) (13.649-(67.971)-(58.547)-(tcb->m_segmentSize)-(46.85));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (57.41+(6.429)+(tcb->m_cWnd)+(86.015)+(29.655)+(3.532)+(segmentsAcked)+(80.154));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (33.866*(63.725)*(82.213)*(23.598));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	segmentsAcked = (int) (50.26-(82.68));
	tcb->m_ssThresh = (int) (29.979+(62.95)+(56.967)+(35.653)+(17.418)+(77.46));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (segmentsAcked*(81.321)*(tcb->m_cWnd)*(20.134)*(75.06));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (66.874/85.308);
	tcb->m_ssThresh = (int) (96.638-(31.624)-(76.393)-(tcb->m_ssThresh)-(24.33)-(16.213)-(78.317));

} else {
	tcb->m_ssThresh = (int) (24.459+(34.687));
	ReduceCwnd (tcb);

}
CongestionAvoidance (tcb, segmentsAcked);
