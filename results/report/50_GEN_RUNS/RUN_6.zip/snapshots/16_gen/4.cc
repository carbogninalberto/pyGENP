tcb->m_cWnd = (int) (86.951+(59.836));
tcb->m_cWnd = (int) (3.908+(75.65));
tcb->m_cWnd = (int) (77.957+(-7.864));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
