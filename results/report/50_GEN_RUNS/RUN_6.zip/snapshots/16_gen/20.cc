ReduceCwnd (tcb);
segmentsAcked = (int) (73.5*(-43.931)*(-90.587)*(4.319)*(78.581));
