tcb->m_segmentSize = (int) (77.573-(tcb->m_ssThresh));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (55.352*(89.434)*(20.002)*(29.262)*(54.703)*(tcb->m_cWnd)*(18.036));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (53.173-(67.734)-(tcb->m_cWnd)-(43.495));
	segmentsAcked = (int) (8.493*(92.659)*(tcb->m_cWnd)*(52.101)*(23.335)*(26.107)*(7.702)*(98.322));

} else {
	tcb->m_segmentSize = (int) (9.993+(tcb->m_ssThresh)+(tcb->m_cWnd)+(5.608)+(14.775)+(25.228)+(tcb->m_ssThresh)+(12.751)+(95.407));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (3.342*(59.769));
