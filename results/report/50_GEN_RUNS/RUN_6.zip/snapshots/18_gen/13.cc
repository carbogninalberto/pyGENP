segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (94.381-(39.06)-(64.865)-(0.477)-(0.704)-(63.429));
	tcb->m_cWnd = (int) (81.873+(9.97)+(44.001)+(27.803));
	tcb->m_cWnd = (int) (87.687+(57.231)+(26.447));

}
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	segmentsAcked = (int) (30.55*(tcb->m_cWnd)*(82.865));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (40.62-(tcb->m_segmentSize)-(83.162));

} else {
	segmentsAcked = (int) (((63.196)+(93.563)+(75.554)+(55.065)+(26.069)+(0.1)+(0.1))/((77.73)));
	tcb->m_cWnd = (int) (9.022*(24.711)*(91.697));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (33.793-(82.404)-(76.955)-(segmentsAcked));

} else {
	tcb->m_cWnd = (int) ((72.042*(70.864)*(8.344)*(98.011))/4.54);
	tcb->m_cWnd = (int) (76.218+(19.141)+(47.838)+(51.249));

}
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_cWnd = (int) (79.998+(91.882)+(46.841)+(32.801)+(41.548)+(tcb->m_cWnd));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(55.651)+(tcb->m_cWnd)+(54.828)+(24.869)+(38.051));
	tcb->m_ssThresh = (int) (66.729-(tcb->m_segmentSize));
	segmentsAcked = (int) (36.875*(11.873)*(70.862)*(93.335)*(86.786));

}
