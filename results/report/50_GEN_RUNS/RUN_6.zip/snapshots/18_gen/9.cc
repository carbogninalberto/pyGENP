tcb->m_cWnd = (int) (-49.63+(-52.446));
tcb->m_cWnd = (int) (-10.122+(-25.079));
tcb->m_cWnd = (int) (-42.843+(61.241));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
