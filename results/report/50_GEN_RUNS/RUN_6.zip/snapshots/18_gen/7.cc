float JJmNfhLjbtzcgVHl = (float) (-49.487+(88.519)+(37.436)+(-5.791)+(-33.966)+(-31.442)+(-61.555)+(53.182)+(61.391));
int UbGqWpofOuiPYsRQ = (int) (((-58.424)+((64.28-(-83.609)-(20.6)-(-67.964)-(85.436)-(6.669)-(-41.385)))+(80.329)+(-41.618))/((-90.26)+(-5.646)+(-91.81)+(83.574)+(4.724)));
if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (88.358-(69.954)-(37.417)-(53.018)-(58.488)-(68.171)-(53.776));

} else {
	segmentsAcked = (int) (30.022-(63.08)-(39.927)-(71.047)-(5.596)-(5.708)-(85.851)-(45.465)-(-23.102));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (JJmNfhLjbtzcgVHl != UbGqWpofOuiPYsRQ) {
	UbGqWpofOuiPYsRQ = (int) (17.904+(98.649)+(72.388)+(JJmNfhLjbtzcgVHl)+(97.745)+(63.289));

} else {
	UbGqWpofOuiPYsRQ = (int) ((((19.316*(segmentsAcked)*(58.803)*(71.246)*(segmentsAcked)*(71.702)))+((JJmNfhLjbtzcgVHl+(13.905)+(JJmNfhLjbtzcgVHl)+(18.853)+(60.015)+(56.795)))+((tcb->m_ssThresh*(89.73)*(0.732)))+(0.1))/((61.721)+(9.298)+(0.1)+(51.577)));
	segmentsAcked = (int) (51.099*(12.711)*(58.143)*(92.281)*(39.372)*(57.63)*(48.521)*(38.578));

}
if (JJmNfhLjbtzcgVHl != UbGqWpofOuiPYsRQ) {
	UbGqWpofOuiPYsRQ = (int) (17.904+(98.649)+(72.388)+(JJmNfhLjbtzcgVHl)+(97.745)+(63.289));

} else {
	UbGqWpofOuiPYsRQ = (int) ((((19.316*(segmentsAcked)*(58.803)*(71.246)*(segmentsAcked)*(71.702)))+((JJmNfhLjbtzcgVHl+(13.905)+(JJmNfhLjbtzcgVHl)+(18.853)+(60.015)+(56.795)))+((tcb->m_ssThresh*(89.73)*(0.732)))+(0.1))/((61.721)+(9.298)+(0.1)+(51.577)));
	segmentsAcked = (int) (51.099*(12.711)*(58.143)*(92.281)*(39.372)*(57.63)*(48.521)*(38.578));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (JJmNfhLjbtzcgVHl != UbGqWpofOuiPYsRQ) {
	UbGqWpofOuiPYsRQ = (int) (17.904+(98.649)+(72.388)+(JJmNfhLjbtzcgVHl)+(97.745)+(63.289));

} else {
	UbGqWpofOuiPYsRQ = (int) ((((19.316*(segmentsAcked)*(58.803)*(71.246)*(segmentsAcked)*(71.702)))+((JJmNfhLjbtzcgVHl+(13.905)+(JJmNfhLjbtzcgVHl)+(18.853)+(60.015)+(56.795)))+((tcb->m_ssThresh*(89.73)*(0.732)))+(0.1))/((61.721)+(9.298)+(0.1)+(51.577)));
	segmentsAcked = (int) (51.099*(12.711)*(58.143)*(92.281)*(39.372)*(57.63)*(48.521)*(38.578));

}
if (JJmNfhLjbtzcgVHl != UbGqWpofOuiPYsRQ) {
	UbGqWpofOuiPYsRQ = (int) (17.904+(98.649)+(72.388)+(JJmNfhLjbtzcgVHl)+(97.745)+(63.289));

} else {
	UbGqWpofOuiPYsRQ = (int) ((((19.316*(segmentsAcked)*(58.803)*(71.246)*(segmentsAcked)*(71.702)))+((JJmNfhLjbtzcgVHl+(13.905)+(JJmNfhLjbtzcgVHl)+(18.853)+(60.015)+(56.795)))+((tcb->m_ssThresh*(89.73)*(0.732)))+(0.1))/((61.721)+(9.298)+(0.1)+(51.577)));
	segmentsAcked = (int) (51.099*(12.711)*(58.143)*(92.281)*(39.372)*(57.63)*(48.521)*(38.578));

}
