tcb->m_ssThresh = (int) (30.111*(28.607)*(68.147)*(68.152));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(tcb->m_segmentSize)-(40.571)-(3.509)-(83.686));
	tcb->m_cWnd = (int) (79.454-(25.047)-(22.491)-(tcb->m_ssThresh)-(0.921));

} else {
	tcb->m_cWnd = (int) (46.599-(segmentsAcked)-(segmentsAcked)-(89.681)-(43.559)-(9.056)-(68.714)-(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (78.982-(14.715)-(63.953)-(82.891)-(56.151));
	tcb->m_cWnd = (int) (23.363/0.1);

}
tcb->m_segmentSize = (int) (0.1/72.929);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
