if (tcb->m_cWnd > tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_segmentSize*(98.844)*(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (42.785/(96.518+(65.603)+(61.976)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize-(segmentsAcked)-(0.566)-(7.652)-(42.618)-(6.1)-(14.629)-(37.429)-(85.71));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(23.967)-(12.734));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (10.848-(20.973)-(93.246)-(12.402)-(16.631)-(tcb->m_segmentSize)-(95.39)-(76.436));
	segmentsAcked = (int) (74.173+(5.211)+(26.513)+(70.491)+(56.891)+(63.745)+(23.14)+(10.933));

} else {
	tcb->m_cWnd = (int) (53.328-(71.734)-(56.32)-(7.412)-(59.227)-(60.153)-(36.399)-(80.608));
	tcb->m_segmentSize = (int) (14.578-(47.079)-(33.955)-(56.836)-(tcb->m_cWnd)-(19.139)-(tcb->m_ssThresh)-(94.771));

}
tcb->m_cWnd = (int) (0.957-(79.109)-(67.599)-(61.895)-(39.57)-(73.396)-(19.37)-(27.867));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	segmentsAcked = (int) (88.896*(30.632));

} else {
	segmentsAcked = (int) (7.074-(tcb->m_cWnd)-(35.808));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(78.879)+(83.621)+(34.88)+(45.975)+(tcb->m_segmentSize)+(25.626));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
