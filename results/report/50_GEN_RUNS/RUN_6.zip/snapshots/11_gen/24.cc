tcb->m_ssThresh = (int) (78.53-(tcb->m_segmentSize)-(tcb->m_cWnd)-(tcb->m_cWnd));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (27.321+(85.046)+(6.366)+(27.95)+(61.242)+(13.769)+(46.651)+(4.852));

} else {
	tcb->m_ssThresh = (int) (85.492+(51.531)+(21.728)+(tcb->m_segmentSize)+(84.29)+(35.561));

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/43.894);

} else {
	tcb->m_cWnd = (int) (8.019+(95.499)+(75.254));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (2.21+(52.625)+(30.214)+(14.986)+(67.699)+(7.752)+(6.092)+(40.841)+(4.67));

} else {
	tcb->m_ssThresh = (int) (8.529+(46.268)+(61.21)+(69.65)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(28.754));
	segmentsAcked = (int) (0.236-(61.321)-(tcb->m_segmentSize)-(86.93)-(66.252)-(61.471)-(54.211));

}
segmentsAcked = (int) (37.274-(40.379)-(16.354)-(82.496)-(23.366)-(tcb->m_segmentSize)-(40.996));
tcb->m_ssThresh = (int) (65.817-(21.084)-(57.303)-(75.443)-(5.644));
if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(78.247)*(29.5)*(48.033)*(63.816)*(44.306)*(13.723)*(96.008));

} else {
	tcb->m_ssThresh = (int) (64.521/0.1);

}
ReduceCwnd (tcb);
