tcb->m_ssThresh = (int) (59.535*(27.865)*(34.232)*(3.298)*(tcb->m_cWnd));
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (81.779+(50.39)+(38.815)+(72.795)+(93.947)+(66.15)+(27.129)+(1.397)+(15.207));
	tcb->m_segmentSize = (int) (segmentsAcked+(9.808)+(63.028)+(36.389)+(78.929)+(94.842)+(91.394)+(99.257)+(57.98));

} else {
	tcb->m_cWnd = (int) (99.33*(70.299)*(8.643)*(10.863)*(94.024));

}
float WvYOhnlwWcQFQaTr = (float) (96.238*(76.116));
segmentsAcked = (int) (40.218+(30.998)+(30.047));
segmentsAcked = (int) (18.287/(11.638-(15.673)));
tcb->m_segmentSize = (int) (91.136+(1.562)+(WvYOhnlwWcQFQaTr)+(28.533)+(91.665)+(tcb->m_cWnd)+(97.259)+(63.859)+(segmentsAcked));
ReduceCwnd (tcb);
