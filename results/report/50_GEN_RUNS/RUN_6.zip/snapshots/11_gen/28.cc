ReduceCwnd (tcb);
segmentsAcked = (int) (79.507*(63.818)*(33.219)*(39.399));
float dVBIWwRvhwqeoxrC = (float) (((28.4)+(0.1)+(0.1)+(0.1)+(79.797))/((0.1)));
float gTudGgMfrGQIFokm = (float) (56.124/0.1);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (35.396+(70.691)+(73.958)+(13.974)+(77.248)+(9.29)+(21.309)+(48.753));
