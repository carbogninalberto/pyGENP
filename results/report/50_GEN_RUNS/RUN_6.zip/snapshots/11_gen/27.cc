ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) (53.893*(4.726)*(61.839));
	segmentsAcked = (int) (11.566*(58.264)*(tcb->m_segmentSize)*(57.486)*(11.513)*(94.816)*(21.999)*(14.092));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(37.569)*(10.441)*(tcb->m_cWnd)*(98.732)*(17.167)*(47.902));
	segmentsAcked = (int) (98.012/3.943);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (60.872-(30.451)-(1.766)-(35.645)-(93.61)-(53.933)-(83.313)-(tcb->m_cWnd)-(29.972));
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((57.885)+((97.677+(96.998)+(68.238)))+(64.645)+(0.1)+(48.956))/((31.24)+(0.1)+(0.1)+(0.1)));
	tcb->m_segmentSize = (int) (((34.757)+(0.1)+(0.1)+(0.1)+(0.1)+(0.1))/((48.376)+(52.022)));
	tcb->m_ssThresh = (int) (94.542+(29.43)+(72.632)+(40.908)+(92.574)+(98.194)+(21.68)+(82.136)+(74.811));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(11.733));
	tcb->m_ssThresh = (int) (34.351-(69.054)-(96.04)-(19.298)-(16.065)-(12.903)-(19.568));
	tcb->m_cWnd = (int) (0.1/0.1);

}
