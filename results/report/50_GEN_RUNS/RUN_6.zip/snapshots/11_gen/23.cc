if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (31.201-(31.054)-(13.728)-(25.887)-(67.491)-(76.23)-(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (62.641*(32.502)*(67.909)*(38.789)*(54.251)*(97.349)*(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (((0.1)+((34.934+(79.93)+(55.314)+(tcb->m_cWnd)+(88.94)+(58.217)+(22.68)))+(96.641)+(1.674)+(0.1))/((73.837)));
	tcb->m_segmentSize = (int) (83.646*(44.187)*(93.549)*(24.884)*(tcb->m_ssThresh)*(64.929)*(12.514)*(77.532));

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked >= tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (58.196-(59.685)-(32.517)-(1.356)-(74.026)-(tcb->m_ssThresh)-(1.791)-(tcb->m_cWnd)-(37.092));

} else {
	segmentsAcked = (int) (35.787+(tcb->m_cWnd)+(tcb->m_cWnd)+(30.178));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (0.1/0.1);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
