if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (23.056+(tcb->m_cWnd)+(0.926)+(68.443)+(segmentsAcked)+(tcb->m_ssThresh));
	segmentsAcked = (int) (9.662/53.028);

} else {
	tcb->m_cWnd = (int) (64.756+(0.403)+(66.353)+(17.365)+(43.251)+(tcb->m_cWnd)+(43.301)+(0.122)+(44.404));

}
segmentsAcked = (int) ((41.389+(78.638)+(60.055)+(tcb->m_segmentSize)+(59.132)+(tcb->m_cWnd)+(21.869)+(87.323))/0.1);
segmentsAcked = (int) (58.209+(5.719)+(14.608)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(10.743)+(14.657)+(83.254)+(70.395));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (tcb->m_ssThresh*(95.096));
tcb->m_segmentSize = (int) (0.1/32.391);
