float lwWAVYlJgqUwifoL = (float) (99.298*(74.07));
int dRRCvbOxoBmHzFEj = (int) (-92.427-(93.648)-(88.803)-(66.976)-(-85.621)-(17.34)-(17.617));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (dRRCvbOxoBmHzFEj < dRRCvbOxoBmHzFEj) {
	dRRCvbOxoBmHzFEj = (int) (86.144+(94.705)+(48.913)+(87.766)+(dRRCvbOxoBmHzFEj)+(1.983)+(lwWAVYlJgqUwifoL)+(tcb->m_cWnd)+(91.889));

} else {
	dRRCvbOxoBmHzFEj = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-52.797-(-36.112)-(-92.08)-(-43.95)-(6.779));
CongestionAvoidance (tcb, segmentsAcked);
