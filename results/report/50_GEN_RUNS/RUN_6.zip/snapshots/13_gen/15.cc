float QVDNdKqjAZWUBhiH = (float) (10.59-(72.818)-(85.424));
segmentsAcked = (int) (-98.855/85.593);
ReduceCwnd (tcb);
