tcb->m_cWnd = (int) (-90.711+(-73.433));
tcb->m_cWnd = (int) (34.879+(70.162));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
