segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((49.912)+(-3.253)+(48.418)+(25.631)+(10.592))/((95.137)+(-76.37)+(-88.41)));
segmentsAcked = (int) (-94.241/75.185);
