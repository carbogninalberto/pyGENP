ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((21.301)+(75.057)+(-70.303)+(-61.729)+(-29.56))/((-43.521)+(-76.715)+(95.759)));
