tcb->m_cWnd = (int) (-22.333+(-71.911));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-30.874+(-94.691));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
