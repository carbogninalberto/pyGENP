tcb->m_cWnd = (int) (-14.663+(-18.986));
tcb->m_cWnd = (int) (-68.599+(44.365));
tcb->m_cWnd = (int) (80.455+(4.585));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
