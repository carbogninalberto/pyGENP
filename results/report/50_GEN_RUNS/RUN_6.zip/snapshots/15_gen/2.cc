tcb->m_cWnd = (int) (-67.366+(-56.147));
tcb->m_cWnd = (int) (8.942+(-71.254));
tcb->m_cWnd = (int) (-44.295+(71.692));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
