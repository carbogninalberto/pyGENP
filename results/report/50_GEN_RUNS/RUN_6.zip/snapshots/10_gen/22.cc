tcb->m_cWnd = (int) (tcb->m_segmentSize-(tcb->m_segmentSize)-(11.342)-(4.949)-(segmentsAcked)-(1.095)-(79.672)-(65.233)-(12.468));
segmentsAcked = (int) (78.373*(71.719)*(49.93)*(tcb->m_ssThresh)*(95.596)*(18.058)*(75.805)*(79.841)*(26.374));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (segmentsAcked*(58.0)*(65.952)*(24.981)*(tcb->m_ssThresh)*(segmentsAcked)*(tcb->m_ssThresh)*(16.437));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (40.776-(42.589)-(0.93)-(16.995)-(tcb->m_ssThresh)-(62.676)-(3.672)-(77.007));
	tcb->m_ssThresh = (int) (88.327+(69.246)+(36.039));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(91.966));
	tcb->m_ssThresh = (int) (5.72/0.1);

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh < segmentsAcked) {
	segmentsAcked = (int) (98.903+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(61.117)+(98.291));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (86.984*(segmentsAcked)*(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) (segmentsAcked*(82.876)*(29.098)*(87.972)*(66.042)*(3.939)*(39.066)*(39.356)*(76.158));

}
