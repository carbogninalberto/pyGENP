float lVPDWuwIDrxdoYft = (float) (52.072*(81.021)*(-79.276)*(57.016));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-25.154-(-90.462)-(-25.853)-(12.755)-(-96.12)-(-20.131)-(-7.604));
segmentsAcked = (int) (38.547-(-98.312)-(91.488)-(57.595)-(69.952)-(-20.007)-(22.519));
