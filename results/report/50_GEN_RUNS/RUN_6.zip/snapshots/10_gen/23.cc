ReduceCwnd (tcb);
tcb->m_cWnd = (int) ((27.853+(2.846))/0.1);
tcb->m_ssThresh = (int) (29.476*(61.042)*(32.539));
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (48.282*(tcb->m_segmentSize)*(62.034)*(93.415));

} else {
	tcb->m_ssThresh = (int) (7.181*(29.592)*(95.132)*(82.275)*(tcb->m_ssThresh)*(42.996)*(93.558));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (((0.1)+(71.833)+(86.745)+(78.785)+(0.1))/((62.89)+(0.1)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
