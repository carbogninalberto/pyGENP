ReduceCwnd (tcb);
if (segmentsAcked == segmentsAcked) {
	tcb->m_segmentSize = (int) (65.201+(15.097)+(57.166)+(76.549));

} else {
	tcb->m_segmentSize = (int) (64.669+(90.349)+(46.088)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(79.727)+(24.822));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (tcb->m_segmentSize+(30.354)+(75.86)+(96.032)+(18.573)+(32.744)+(44.329)+(83.357));
if (tcb->m_ssThresh != tcb->m_cWnd) {
	segmentsAcked = (int) (47.923/44.658);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (24.174*(segmentsAcked)*(84.752)*(1.941)*(13.915)*(84.631));
	tcb->m_segmentSize = (int) (77.174+(28.996)+(16.927)+(33.36)+(95.756)+(14.037));
	tcb->m_segmentSize = (int) ((2.107-(49.558)-(1.207)-(50.598)-(98.416)-(72.985)-(59.356)-(67.506)-(tcb->m_ssThresh))/0.1);

}
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(93.232));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (86.073/94.497);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(78.686)*(85.121)*(63.847)*(56.565)*(86.772));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (81.913*(0.664)*(9.313));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
