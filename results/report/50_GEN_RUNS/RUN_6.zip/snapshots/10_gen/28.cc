CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh == segmentsAcked) {
	segmentsAcked = (int) (tcb->m_segmentSize-(18.097));

} else {
	segmentsAcked = (int) (0.1/96.326);

}
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (35.234*(83.712)*(96.038)*(5.821)*(tcb->m_ssThresh)*(82.212)*(79.177));
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(27.66)*(76.902));

} else {
	tcb->m_segmentSize = (int) (((63.033)+(0.1)+(70.287)+(0.1)+(0.1))/((0.1)+(0.1)));
	tcb->m_segmentSize = (int) (39.689-(segmentsAcked)-(87.726)-(43.575)-(64.729)-(tcb->m_cWnd)-(97.009)-(63.643));

}
tcb->m_cWnd = (int) (65.999*(tcb->m_ssThresh)*(35.848)*(70.36)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(70.609)*(63.314));
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (92.491*(tcb->m_ssThresh)*(segmentsAcked)*(74.844));

} else {
	tcb->m_cWnd = (int) ((23.115*(32.417)*(43.756)*(0.605)*(66.447))/57.964);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (36.563+(tcb->m_segmentSize)+(tcb->m_ssThresh));
tcb->m_ssThresh = (int) (tcb->m_segmentSize*(22.289)*(84.473)*(tcb->m_ssThresh)*(51.029));
