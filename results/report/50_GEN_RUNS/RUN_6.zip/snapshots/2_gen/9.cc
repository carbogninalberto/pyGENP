segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) ((((4.902-(67.335)-(-28.28)-(-0.589)))+(-66.44)+((-56.426*(-18.887)*(-77.947)*(9.587)*(-25.019)*(-23.598)))+(30.409)+(94.746)+(-69.208))/((10.103)));
segmentsAcked = (int) (87.432*(82.623)*(33.337)*(17.234)*(70.217)*(57.604)*(-73.84));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-55.941/-4.486);
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(95.283)-(93.104));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(95.187)-(90.488)-(56.388)-(44.4)-(83.731)-(tcb->m_segmentSize));

}
