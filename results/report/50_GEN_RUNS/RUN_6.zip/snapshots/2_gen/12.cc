float tYtrPFfqnEkLciCM = (float) (99.868-(-75.136)-(-86.548)-(84.391)-(33.04)-(78.019)-(32.006));
segmentsAcked = (int) (14.898/47.932);
segmentsAcked = (int) (((-7.974)+(-86.737)+(1.334)+(-68.268)+(-0.476)+(-11.782)+(-66.208))/((-30.98)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (42.418/-14.483);
