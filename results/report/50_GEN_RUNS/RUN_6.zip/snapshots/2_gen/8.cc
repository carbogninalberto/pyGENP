tcb->m_cWnd = (int) (((4.235)+(-88.536)+((-99.078+(tcb->m_ssThresh)+(-27.186)+(tcb->m_segmentSize)+(-55.287)+(tcb->m_segmentSize)+(50.992)))+(-5.032))/((75.229)+(53.535)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (52.89-(74.041)-(-4.957)-(32.565)-(27.385));
