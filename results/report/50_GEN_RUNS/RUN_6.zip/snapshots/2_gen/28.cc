CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-77.513-(2.203)-(40.803)-(78.858)-(-63.505));
segmentsAcked = (int) (18.726-(-13.293)-(-45.728)-(-57.565)-(8.797));
