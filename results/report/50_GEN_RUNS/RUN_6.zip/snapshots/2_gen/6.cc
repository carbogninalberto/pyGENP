tcb->m_cWnd = (int) (3.873-(-16.823)-(-72.272));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-82.287*(31.923)*(-84.161));
