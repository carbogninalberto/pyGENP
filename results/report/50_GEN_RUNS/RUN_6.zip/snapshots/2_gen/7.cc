float zRGyjiVoSYkpNWSG = (float) (-54.062/-70.236);
int CqbWNcaWAnBvECRE = (int) (-38.652*(-34.993)*(36.757)*(40.859)*(37.026)*(-81.691)*(-65.648)*(53.708)*(82.463));
segmentsAcked = (int) (-94.785*(88.506)*(-28.764)*(-56.583)*(-71.995));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-90.013*(-87.822)*(53.385)*(-13.556)*(-64.452));
