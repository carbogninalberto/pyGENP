float ESTMQSEBpLwAwKIy = (float) (25.908+(-58.822)+(-22.036)+(-16.213)+(-53.035)+(-93.358)+(60.991)+(23.173));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ESTMQSEBpLwAwKIy = (float) (54.245*(22.366)*(42.862)*(12.01)*(-12.441)*(-20.912)*(42.852)*(82.434));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ESTMQSEBpLwAwKIy = (float) (-49.792*(-25.023)*(-23.726)*(72.322)*(96.259)*(8.295)*(-74.4)*(-45.623));
CongestionAvoidance (tcb, segmentsAcked);
