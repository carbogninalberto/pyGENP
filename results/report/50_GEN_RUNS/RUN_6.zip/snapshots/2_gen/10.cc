int MrbNkiBzdEpacsJh = (int) (-58.844+(60.573)+(-0.684)+(95.054)+(-45.3));
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (82.745-(51.975));

} else {
	tcb->m_segmentSize = (int) (61.739-(96.634));

}
