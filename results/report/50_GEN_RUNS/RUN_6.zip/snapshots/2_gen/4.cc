float vsuVnJWCObejjbVq = (float) (71.135/-16.473);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (77.137*(-57.484)*(12.905)*(74.797)*(-5.558)*(23.975)*(91.35)*(-94.724));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-1.145-(-18.687)-(91.23)-(-11.588)-(-32.156)-(4.376));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (99.187+(-67.974)+(3.019)+(9.211)+(-2.643)+(39.191)+(-3.963)+(81.83));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
