float ESTMQSEBpLwAwKIy = (float) (-33.851+(-49.076)+(99.439)+(97.155)+(77.315)+(-73.697)+(-6.692)+(14.269));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int hCxYoqPReiAdwyam = (int) (-59.932*(68.444)*(93.837)*(-98.911));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ESTMQSEBpLwAwKIy = (float) (-91.53*(-39.71)*(71.849)*(72.394)*(65.796)*(-74.031)*(48.015)*(44.47));
CongestionAvoidance (tcb, segmentsAcked);
