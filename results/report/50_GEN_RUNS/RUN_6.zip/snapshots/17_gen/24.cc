segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (10.245*(96.006)*(69.475)*(segmentsAcked)*(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (83.181-(31.533)-(51.432));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(78.913)-(48.147));

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) ((93.091-(94.088)-(segmentsAcked)-(25.755)-(69.104)-(tcb->m_ssThresh)-(80.586))/0.1);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
