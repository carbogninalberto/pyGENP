if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (82.855-(11.308)-(tcb->m_cWnd)-(99.338)-(45.799));
	tcb->m_segmentSize = (int) (96.314-(74.164)-(7.462));
	tcb->m_ssThresh = (int) (33.234+(77.353)+(tcb->m_segmentSize)+(65.637)+(64.732)+(94.24)+(72.744)+(tcb->m_segmentSize)+(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (24.741-(tcb->m_segmentSize)-(10.692)-(8.209)-(tcb->m_cWnd));
tcb->m_segmentSize = (int) (24.653+(tcb->m_segmentSize)+(87.207)+(23.674)+(93.856)+(11.615)+(4.23));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
