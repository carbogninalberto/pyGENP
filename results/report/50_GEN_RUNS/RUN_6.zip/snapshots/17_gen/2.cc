tcb->m_cWnd = (int) (68.85+(68.791));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (77.622+(-71.924));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
