tcb->m_cWnd = (int) (51.308+(-78.24));
tcb->m_cWnd = (int) (-76.892+(36.462));
tcb->m_cWnd = (int) (6.843+(-89.711));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
