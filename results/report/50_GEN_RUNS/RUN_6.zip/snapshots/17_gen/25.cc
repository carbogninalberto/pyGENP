ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
int qNmIFdMBRHsQSrfL = (int) (90.884+(tcb->m_ssThresh)+(53.928)+(31.485)+(77.662)+(tcb->m_ssThresh)+(11.662)+(13.94));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
float poueqwMrGmXsmATP = (float) (13.191+(48.653));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
