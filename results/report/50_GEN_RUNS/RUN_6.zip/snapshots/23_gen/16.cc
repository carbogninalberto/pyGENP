if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_segmentSize = (int) (76.716/(39.155-(94.142)-(98.732)-(21.039)-(segmentsAcked)-(81.696)-(52.078)-(75.669)));
	tcb->m_segmentSize = (int) (70.347*(84.149)*(14.52)*(84.75));

} else {
	tcb->m_segmentSize = (int) (79.155/95.285);

}
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (24.584-(tcb->m_ssThresh)-(62.044)-(85.442)-(17.454)-(26.331)-(tcb->m_ssThresh)-(8.706)-(31.098));

} else {
	tcb->m_segmentSize = (int) (43.91+(7.105)+(83.635)+(67.528));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (73.762+(30.896)+(tcb->m_cWnd)+(80.331));
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_ssThresh = (int) (segmentsAcked*(88.018)*(87.837)*(tcb->m_segmentSize)*(96.571)*(61.477)*(segmentsAcked)*(68.591)*(58.651));
	segmentsAcked = (int) (tcb->m_cWnd+(0.295));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (2.456-(tcb->m_segmentSize));

}
