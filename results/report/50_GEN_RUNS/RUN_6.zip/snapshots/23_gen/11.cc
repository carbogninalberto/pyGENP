ReduceCwnd (tcb);
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/79.929);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (3.017-(40.28)-(tcb->m_cWnd));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (62.054*(15.289)*(18.261)*(5.2)*(segmentsAcked)*(21.473));

}
tcb->m_cWnd = (int) (35.241*(76.562)*(39.761)*(77.38)*(18.451)*(51.98)*(42.49)*(5.63)*(25.163));
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(73.78)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (75.045+(13.441)+(tcb->m_segmentSize)+(19.773)+(18.386)+(97.351));
	tcb->m_segmentSize = (int) (29.632+(53.944));
	tcb->m_ssThresh = (int) (((69.278)+(57.166)+(0.1)+(89.722)+(79.21))/((0.1)+(0.1)+(99.907)+(25.317)));

}
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (57.534*(81.204)*(83.218)*(78.485)*(31.647));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (87.092-(23.435)-(tcb->m_segmentSize)-(99.965)-(78.775));

} else {
	tcb->m_segmentSize = (int) (44.817-(61.646)-(6.723)-(20.278)-(tcb->m_cWnd)-(75.808)-(segmentsAcked)-(32.612)-(tcb->m_segmentSize));
	segmentsAcked = (int) (43.649-(84.517));
	ReduceCwnd (tcb);

}
