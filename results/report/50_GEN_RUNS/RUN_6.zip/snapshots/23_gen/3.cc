float gUOqpiBctHnWNnSF = (float) (((79.333)+(-97.885)+(-21.047)+(71.133))/((32.811)));
