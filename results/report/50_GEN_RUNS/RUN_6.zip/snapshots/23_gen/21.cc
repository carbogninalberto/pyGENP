ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((0.1)+((53.656+(58.01)))+(0.1)+(75.071))/((44.978)));
	tcb->m_segmentSize = (int) (12.233-(88.613)-(12.636)-(32.348)-(tcb->m_ssThresh)-(29.002));

} else {
	tcb->m_cWnd = (int) (18.212*(92.874)*(94.26)*(26.538)*(77.297)*(19.682)*(54.309)*(segmentsAcked));
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (66.532-(70.066)-(65.989)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(80.511));

}
