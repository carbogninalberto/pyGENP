float UsHozJTzdhmwXcJW = (float) (0.1/55.361);
segmentsAcked = (int) (segmentsAcked*(tcb->m_ssThresh)*(UsHozJTzdhmwXcJW)*(69.791));
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(20.171)));

} else {
	tcb->m_ssThresh = (int) (88.942*(71.888));
	ReduceCwnd (tcb);

}
if (UsHozJTzdhmwXcJW == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (13.407-(21.136)-(15.87)-(15.266)-(60.565)-(tcb->m_ssThresh));
	UsHozJTzdhmwXcJW = (float) (15.449*(63.414)*(14.716)*(79.022)*(46.156));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(19.021)+(37.104)+(18.97));
	UsHozJTzdhmwXcJW = (float) (27.066-(16.822)-(37.673)-(67.505)-(36.698)-(93.78)-(41.431)-(94.551)-(tcb->m_ssThresh));

}
if (tcb->m_ssThresh >= UsHozJTzdhmwXcJW) {
	tcb->m_ssThresh = (int) (18.602+(72.756)+(69.909)+(31.634)+(segmentsAcked)+(segmentsAcked)+(68.966));
	UsHozJTzdhmwXcJW = (float) (1.293+(tcb->m_cWnd)+(73.554)+(55.979)+(tcb->m_cWnd)+(69.585));
	UsHozJTzdhmwXcJW = (float) (tcb->m_cWnd+(62.198)+(69.399)+(42.621)+(5.438)+(45.778)+(90.963));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(35.046)-(31.739));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (4.958+(9.732)+(91.028)+(23.043)+(42.137)+(91.295));

}
ReduceCwnd (tcb);
float eDZRuZRLojPNkCVo = (float) (38.966*(13.918)*(tcb->m_segmentSize)*(69.098)*(20.277)*(24.264));
if (UsHozJTzdhmwXcJW >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(22.773)+(24.378)+(0.1))/((0.1)+(99.292)));
	ReduceCwnd (tcb);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (85.546*(segmentsAcked)*(63.402)*(70.522));
	tcb->m_segmentSize = (int) ((84.52+(75.208)+(75.854)+(57.795)+(56.954))/35.014);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
UsHozJTzdhmwXcJW = (float) (88.259-(23.579)-(4.97)-(tcb->m_ssThresh)-(UsHozJTzdhmwXcJW)-(65.511)-(eDZRuZRLojPNkCVo)-(tcb->m_segmentSize));
