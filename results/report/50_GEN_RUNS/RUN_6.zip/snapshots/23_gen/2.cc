float SssylwUKvmBZyGKc = (float) (-38.171+(-5.97)+(44.305)+(-91.209)+(-99.539)+(-16.982)+(69.35)+(-98.336));
float ulqjZHFIYqTGzVef = (float) (33.974*(1.286)*(-81.764)*(13.982)*(18.728)*(67.588)*(3.184)*(-50.247));
float zGGmugGSIImESaiY = (float) (-61.516*(65.228));
int HnTmHUtEJhGYXDhx = (int) (((53.466)+((57.915*(4.589)*(-5.082)*(-32.992)*(-18.435)*(-82.026)*(81.573)*(24.08)))+((-34.707+(88.251)+(6.706)+(97.457)+(96.355)+(-65.344)+(-59.835)+(-31.042)))+((-75.769*(55.004)*(-41.428)*(70.499)*(70.118)*(35.164)*(-40.033)*(-27.681)))+((-6.147+(89.239)+(44.997)+(-79.495)+(9.178)))+(0.245))/((68.611)+(40.098)+(-71.114)));
HnTmHUtEJhGYXDhx = (int) (-51.542-(81.219)-(-11.66)-(-49.013)-(26.69));
if (tcb->m_segmentSize < HnTmHUtEJhGYXDhx) {
	segmentsAcked = (int) (0.1/78.536);
	tcb->m_cWnd = (int) (11.707+(68.575)+(tcb->m_segmentSize)+(89.999)+(68.083)+(tcb->m_segmentSize)+(23.353)+(7.451));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (89.362-(76.717)-(52.365)-(HnTmHUtEJhGYXDhx)-(segmentsAcked)-(36.851)-(HnTmHUtEJhGYXDhx)-(24.289)-(26.236));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (HnTmHUtEJhGYXDhx > segmentsAcked) {
	tcb->m_segmentSize = (int) (HnTmHUtEJhGYXDhx-(zGGmugGSIImESaiY)-(segmentsAcked)-(53.936)-(56.027)-(segmentsAcked)-(22.106)-(44.535)-(13.369));
	HnTmHUtEJhGYXDhx = (int) (89.38/0.1);
	tcb->m_segmentSize = (int) (76.802+(8.411)+(ulqjZHFIYqTGzVef)+(71.114));

} else {
	tcb->m_segmentSize = (int) (0.1/1.899);
	tcb->m_cWnd = (int) (20.773*(22.094)*(6.609)*(4.771)*(8.632)*(75.797)*(61.442)*(52.31));

}
if (ulqjZHFIYqTGzVef < HnTmHUtEJhGYXDhx) {
	tcb->m_segmentSize = (int) (97.048+(85.357)+(12.923)+(segmentsAcked)+(60.12)+(tcb->m_segmentSize)+(47.145)+(89.812)+(71.503));
	tcb->m_segmentSize = (int) (45.904*(-42.554)*(53.331)*(54.261)*(84.906)*(96.748));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) ((((tcb->m_segmentSize-(tcb->m_segmentSize)-(2.228)-(29.614)))+(17.621)+(0.1)+(52.673))/((8.62)));
	tcb->m_cWnd = (int) (99.663/18.026);
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(ulqjZHFIYqTGzVef)*(23.824)*(42.415)*(13.733)*(85.497));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
