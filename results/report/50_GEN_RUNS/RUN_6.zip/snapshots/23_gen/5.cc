segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-42.445*(-81.299)*(-98.403)*(24.692)*(17.815)*(24.682)*(-69.941)*(-97.489)*(7.197));
CongestionAvoidance (tcb, segmentsAcked);
