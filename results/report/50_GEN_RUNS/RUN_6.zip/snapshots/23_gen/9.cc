tcb->m_segmentSize = (int) (89.035-(56.369)-(11.719)-(21.61));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (37.331*(47.237)*(53.632)*(94.274)*(39.911)*(58.108)*(56.269));
tcb->m_cWnd = (int) (98.974/32.859);
tcb->m_ssThresh = (int) (0.1/0.1);
