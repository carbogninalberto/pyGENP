if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) ((((0.085-(segmentsAcked)))+(0.1)+((31.409*(35.378)*(52.939)*(70.215)*(21.189)*(31.46)))+(0.1))/((99.138)+(77.181)+(0.1)+(38.151)));

} else {
	segmentsAcked = (int) (((12.578)+(9.895)+((18.954*(69.482)*(80.067)*(51.01)*(62.88)*(26.309)*(tcb->m_segmentSize)*(96.643)*(87.443)))+(0.1)+(4.631))/((95.51)));
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(85.616)+(0.1)+(0.1)+(22.961)+(0.1))/((0.1)+(0.1)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked > tcb->m_segmentSize) {
	segmentsAcked = (int) (42.602-(91.521)-(32.277));
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (((0.1)+((29.363*(97.893)*(59.91)*(tcb->m_ssThresh)*(43.144)*(90.822)*(37.299)))+(0.1)+(45.972))/((0.1)+(50.723)));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (86.958+(44.046));
ReduceCwnd (tcb);
