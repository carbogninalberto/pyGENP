tcb->m_ssThresh = (int) ((tcb->m_segmentSize*(50.959)*(28.271)*(60.04)*(7.273)*(97.765)*(64.656)*(20.217))/(1.857*(83.093)*(44.595)*(70.072)*(39.18)*(44.482)*(68.16)));
tcb->m_ssThresh = (int) (66.118*(42.218)*(85.803)*(83.428)*(tcb->m_ssThresh));
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_cWnd-(1.615));
float QJIpwVUkHtGZkWKb = (float) (0.1/90.344);
float xDOhweqdugsOxOdP = (float) (83.311-(QJIpwVUkHtGZkWKb)-(tcb->m_ssThresh)-(89.25)-(13.494)-(13.621)-(85.276)-(tcb->m_cWnd));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	xDOhweqdugsOxOdP = (float) ((7.565*(86.125))/(xDOhweqdugsOxOdP*(32.128)*(21.668)*(7.777)));

} else {
	xDOhweqdugsOxOdP = (float) (47.907+(98.801));

}
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (3.633-(28.855)-(47.455)-(34.486)-(37.742)-(tcb->m_cWnd)-(96.64)-(77.639)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (QJIpwVUkHtGZkWKb-(95.36)-(QJIpwVUkHtGZkWKb)-(70.226));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(tcb->m_cWnd)*(6.798)*(78.19)*(71.934)*(QJIpwVUkHtGZkWKb)*(48.298));
	tcb->m_ssThresh = (int) (36.838-(28.121)-(tcb->m_cWnd)-(55.636)-(97.124)-(60.979)-(36.343)-(44.1)-(11.502));

}
