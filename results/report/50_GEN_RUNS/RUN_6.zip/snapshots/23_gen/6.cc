int AniAboRsMJllpMaR = (int) 5.729;
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_cWnd = (int) (64.497-(-59.361)-(0.055)-(78.69)-(17.772)-(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (29.968*(segmentsAcked)*(72.17)*(-49.334)*(57.856));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (82.916*(97.08)*(8.708)*(tcb->m_segmentSize)*(9.376)*(segmentsAcked)*(30.227));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (86.609/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
