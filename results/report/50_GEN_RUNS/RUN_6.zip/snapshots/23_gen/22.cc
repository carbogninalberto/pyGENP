ReduceCwnd (tcb);
int oNlMNQwXqBUykKqp = (int) (66.008-(44.631)-(45.334)-(19.754)-(tcb->m_cWnd)-(36.276)-(50.145)-(12.674));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	segmentsAcked = (int) (60.412-(15.697)-(29.678)-(40.793)-(95.326)-(53.17));

} else {
	segmentsAcked = (int) (52.769+(34.832));

}
tcb->m_segmentSize = (int) (91.724+(tcb->m_cWnd)+(5.084));
if (tcb->m_ssThresh > oNlMNQwXqBUykKqp) {
	oNlMNQwXqBUykKqp = (int) (75.162*(97.278)*(41.924)*(32.972));

} else {
	oNlMNQwXqBUykKqp = (int) (49.057-(92.213)-(14.03)-(segmentsAcked)-(34.628)-(83.968));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
oNlMNQwXqBUykKqp = (int) (tcb->m_segmentSize+(32.34)+(4.527)+(7.4)+(tcb->m_cWnd)+(52.139));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
