segmentsAcked = (int) (segmentsAcked-(87.712)-(15.372)-(tcb->m_cWnd));
tcb->m_segmentSize = (int) (84.939*(segmentsAcked)*(30.33)*(90.251)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(60.116)*(65.387));
float wYBPluyTwjcPyEUx = (float) (64.399+(segmentsAcked)+(33.243)+(segmentsAcked));
if (tcb->m_ssThresh <= wYBPluyTwjcPyEUx) {
	segmentsAcked = (int) (59.406*(15.231)*(45.595)*(60.191)*(64.33)*(53.36)*(43.955));
	tcb->m_segmentSize = (int) (55.648/0.1);
	segmentsAcked = (int) (80.127*(27.894)*(tcb->m_ssThresh)*(70.326)*(93.013)*(7.453)*(36.898)*(wYBPluyTwjcPyEUx));

} else {
	segmentsAcked = (int) (84.539*(28.719)*(17.603));
	tcb->m_segmentSize = (int) (20.291-(52.299)-(35.674)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(72.702)-(38.876));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (22.055-(27.6)-(15.718)-(14.438));
