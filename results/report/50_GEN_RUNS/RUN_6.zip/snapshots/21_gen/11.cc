CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((-52.773)+((-4.637-(-23.871)-(94.634)-(-16.38)-(-4.948)-(-43.555)-(-22.952)))+(-37.957)+((52.915+(72.405)+(-61.729)))+((-30.01+(85.537)+(92.92)+(-8.877)))+(-76.408))/((-87.664)));
tcb->m_cWnd = (int) (-25.845*(7.058)*(-64.131)*(32.078)*(50.789));
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_cWnd = (int) (84.063*(tcb->m_cWnd)*(-84.34)*(70.622)*(14.322));
	segmentsAcked = (int) (5.033-(18.351)-(71.362));

} else {
	tcb->m_cWnd = (int) (49.501-(-37.267)-(36.367)-(91.751)-(32.702)-(tcb->m_segmentSize)-(-44.065)-(-67.842));
	tcb->m_cWnd = (int) (34.293+(14.661)+(22.896)+(65.87)+(97.892)+(64.738)+(67.067)+(tcb->m_cWnd)+(15.423));

}
