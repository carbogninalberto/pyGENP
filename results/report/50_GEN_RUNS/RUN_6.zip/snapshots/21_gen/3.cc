if (segmentsAcked < segmentsAcked) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(33.315)+(80.205))/((0.1)+(52.016)+(0.1)));
	segmentsAcked = (int) (4.475+(74.094)+(88.27)+(-16.881)+(29.862)+(-21.344)+(51.076)+(49.919));
	tcb->m_segmentSize = (int) (95.97+(36.167)+(68.326)+(41.239)+(90.691)+(91.393)+(75.809)+(47.142)+(94.608));

} else {
	tcb->m_cWnd = (int) (74.247+(30.96)+(segmentsAcked)+(89.855)+(tcb->m_segmentSize)+(26.166)+(46.628)+(54.404)+(84.36));

}
segmentsAcked = (int) (-69.191*(-30.316)*(-43.25)*(-63.01)*(41.112));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (22.819*(-10.065)*(1.492)*(-68.034)*(-38.698)*(-36.825)*(-88.417));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
