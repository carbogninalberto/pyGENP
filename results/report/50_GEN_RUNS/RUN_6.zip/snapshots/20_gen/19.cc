CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((1.142)+((-0.018-(5.321)-(tcb->m_segmentSize)-(12.661)-(57.943)-(62.223)-(26.597)))+(0.1)+((20.818+(35.309)+(14.545)))+((3.067+(67.295)+(3.704)+(21.047)))+(7.125))/((62.446)));
tcb->m_cWnd = (int) (tcb->m_ssThresh*(64.957)*(28.89)*(79.519)*(10.25));
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_cWnd = (int) (84.063*(tcb->m_cWnd)*(tcb->m_ssThresh)*(70.622)*(14.322));
	segmentsAcked = (int) (5.033-(18.351)-(71.362));

} else {
	tcb->m_cWnd = (int) (49.501-(tcb->m_ssThresh)-(36.367)-(91.751)-(32.702)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (34.293+(14.661)+(22.896)+(65.87)+(97.892)+(64.738)+(67.067)+(tcb->m_cWnd)+(15.423));

}
