segmentsAcked = (int) (0.1/0.1);
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (73.744*(98.365));
	segmentsAcked = (int) (31.455/0.1);
	tcb->m_cWnd = (int) (83.204-(64.216)-(10.637)-(82.76)-(34.377));

} else {
	tcb->m_segmentSize = (int) (14.334-(31.133)-(11.851)-(19.047)-(28.603)-(13.586)-(60.099));

}
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_ssThresh = (int) (33.945+(90.315));
	ReduceCwnd (tcb);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (11.806+(15.972)+(49.824)+(53.012)+(tcb->m_cWnd)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(13.836));
	tcb->m_ssThresh = (int) (34.932-(68.463)-(5.751)-(31.798)-(tcb->m_cWnd)-(90.443));

}
tcb->m_ssThresh = (int) (((0.1)+(0.1)+((tcb->m_segmentSize+(43.945)+(tcb->m_ssThresh)+(68.639)))+(70.3)+(0.1)+(15.741)+(0.1)+(0.1))/((0.1)));
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(49.04)+(0.1))/((0.1)+(44.402)+(26.285)+(0.1)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (39.073/69.088);

}
tcb->m_cWnd = (int) (0.1/(tcb->m_segmentSize+(tcb->m_segmentSize)+(33.336)+(tcb->m_segmentSize)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
