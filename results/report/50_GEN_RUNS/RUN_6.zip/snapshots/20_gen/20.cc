tcb->m_cWnd = (int) (89.444/0.1);
tcb->m_ssThresh = (int) (tcb->m_segmentSize+(32.465)+(39.511)+(tcb->m_cWnd)+(8.534)+(20.968)+(32.514));
tcb->m_ssThresh = (int) (tcb->m_cWnd*(38.55));
tcb->m_segmentSize = (int) (61.878+(66.356)+(0.128)+(4.886)+(tcb->m_ssThresh));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
