tcb->m_segmentSize = (int) (15.033+(49.842)+(-91.621)+(78.415));
ReduceCwnd (tcb);
segmentsAcked = (int) (7.919*(22.743)*(20.696)*(29.192)*(-22.913));
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) (43.514-(63.485));

} else {
	segmentsAcked = (int) (33.812*(66.897)*(70.974)*(segmentsAcked)*(48.89)*(54.911)*(segmentsAcked));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
