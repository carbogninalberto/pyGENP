tcb->m_cWnd = (int) (90.074+(-48.029));
tcb->m_cWnd = (int) (52.617+(0.581));
tcb->m_cWnd = (int) (-57.624+(7.561));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
