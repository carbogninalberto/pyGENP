tcb->m_cWnd = (int) (30.119+(-39.37));
tcb->m_cWnd = (int) (-55.275+(75.563));
tcb->m_cWnd = (int) (97.802+(29.795));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
