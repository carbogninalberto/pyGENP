tcb->m_cWnd = (int) (30.963+(-39.58));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-24.236+(-55.033));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
