ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((-21.597)+(9.825)+(-11.562)+(-65.687)+(68.827))/((24.049)+(85.038)+(73.216)));
segmentsAcked = (int) (45.656/15.874);
