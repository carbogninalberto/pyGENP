tcb->m_cWnd = (int) (18.935+(99.693));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-43.213+(14.481));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
