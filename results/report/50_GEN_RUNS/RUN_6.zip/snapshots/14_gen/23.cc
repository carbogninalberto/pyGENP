float JJmNfhLjbtzcgVHl = (float) (64.745+(46.387)+(-10.729)+(61.377)+(-17.133)+(35.969)+(48.498)+(-54.925)+(13.873));
int UbGqWpofOuiPYsRQ = (int) (((-58.39)+((-86.77-(-74.598)-(46.091)-(-29.91)-(-4.093)-(-58.058)-(96.438)))+(-95.349)+(-90.985))/((34.68)+(66.474)+(-12.3)+(-37.077)+(50.783)));
if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (88.358-(69.954)-(37.417)-(53.018)-(58.488)-(68.171)-(53.776));

} else {
	segmentsAcked = (int) (30.022-(63.08)-(39.927)-(71.047)-(5.596)-(5.708)-(85.851)-(45.465)-(-23.102));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (JJmNfhLjbtzcgVHl != UbGqWpofOuiPYsRQ) {
	UbGqWpofOuiPYsRQ = (int) (17.904+(98.649)+(72.388)+(JJmNfhLjbtzcgVHl)+(97.745)+(63.289));

} else {
	UbGqWpofOuiPYsRQ = (int) ((((19.316*(segmentsAcked)*(58.803)*(71.246)*(segmentsAcked)*(71.702)))+((JJmNfhLjbtzcgVHl+(13.905)+(JJmNfhLjbtzcgVHl)+(18.853)+(60.015)+(56.795)))+((tcb->m_ssThresh*(89.73)*(0.732)))+(0.1))/((61.721)+(9.298)+(0.1)+(51.577)));
	segmentsAcked = (int) (51.099*(12.711)*(58.143)*(92.281)*(39.372)*(57.63)*(48.521)*(38.578));

}
if (JJmNfhLjbtzcgVHl != UbGqWpofOuiPYsRQ) {
	UbGqWpofOuiPYsRQ = (int) (17.904+(98.649)+(72.388)+(JJmNfhLjbtzcgVHl)+(97.745)+(63.289));

} else {
	UbGqWpofOuiPYsRQ = (int) ((((19.316*(segmentsAcked)*(58.803)*(71.246)*(segmentsAcked)*(71.702)))+((JJmNfhLjbtzcgVHl+(13.905)+(JJmNfhLjbtzcgVHl)+(18.853)+(60.015)+(56.795)))+((tcb->m_ssThresh*(89.73)*(0.732)))+(0.1))/((61.721)+(9.298)+(0.1)+(51.577)));
	segmentsAcked = (int) (51.099*(12.711)*(58.143)*(92.281)*(39.372)*(57.63)*(48.521)*(38.578));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (JJmNfhLjbtzcgVHl != UbGqWpofOuiPYsRQ) {
	UbGqWpofOuiPYsRQ = (int) (17.904+(98.649)+(72.388)+(JJmNfhLjbtzcgVHl)+(97.745)+(63.289));

} else {
	UbGqWpofOuiPYsRQ = (int) ((((19.316*(segmentsAcked)*(58.803)*(71.246)*(segmentsAcked)*(71.702)))+((JJmNfhLjbtzcgVHl+(13.905)+(JJmNfhLjbtzcgVHl)+(18.853)+(60.015)+(56.795)))+((tcb->m_ssThresh*(89.73)*(0.732)))+(0.1))/((61.721)+(9.298)+(0.1)+(51.577)));
	segmentsAcked = (int) (51.099*(12.711)*(58.143)*(92.281)*(39.372)*(57.63)*(48.521)*(38.578));

}
if (JJmNfhLjbtzcgVHl != UbGqWpofOuiPYsRQ) {
	UbGqWpofOuiPYsRQ = (int) (17.904+(98.649)+(72.388)+(JJmNfhLjbtzcgVHl)+(97.745)+(63.289));

} else {
	UbGqWpofOuiPYsRQ = (int) ((((19.316*(segmentsAcked)*(58.803)*(71.246)*(segmentsAcked)*(71.702)))+((JJmNfhLjbtzcgVHl+(13.905)+(JJmNfhLjbtzcgVHl)+(18.853)+(60.015)+(56.795)))+((tcb->m_ssThresh*(89.73)*(0.732)))+(0.1))/((61.721)+(9.298)+(0.1)+(51.577)));
	segmentsAcked = (int) (51.099*(12.711)*(58.143)*(92.281)*(39.372)*(57.63)*(48.521)*(38.578));

}
