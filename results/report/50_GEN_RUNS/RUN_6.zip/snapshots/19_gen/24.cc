ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_segmentSize*(29.017)*(54.829)*(65.425)*(57.579)*(segmentsAcked)*(20.205)*(22.029)*(16.493));
int zwjjhcocEKPMRMkh = (int) (22.723-(tcb->m_cWnd)-(78.239));
CongestionAvoidance (tcb, segmentsAcked);
float hGqEMIPJIsOrSyCJ = (float) (0.1/77.59);
float bKlbPhjChvSIEqet = (float) ((((11.386+(99.937)+(16.998)+(83.183)+(hGqEMIPJIsOrSyCJ)))+(0.1)+((89.872-(35.493)-(85.267)-(9.309)))+(0.1)+(0.1))/((0.1)));
tcb->m_cWnd = (int) (17.23-(7.311)-(bKlbPhjChvSIEqet)-(19.364)-(tcb->m_segmentSize)-(42.052));
