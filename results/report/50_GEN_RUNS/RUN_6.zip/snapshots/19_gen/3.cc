tcb->m_cWnd = (int) (33.247+(-57.231));
tcb->m_cWnd = (int) (-7.084+(32.817));
tcb->m_cWnd = (int) (-89.952+(59.598));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
