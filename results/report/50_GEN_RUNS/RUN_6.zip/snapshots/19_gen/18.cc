ReduceCwnd (tcb);
ReduceCwnd (tcb);
float USLSnZdqBZEnrfYQ = (float) (1.101+(55.414)+(43.764)+(69.463)+(70.507)+(1.349));
tcb->m_cWnd = (int) (25.109*(tcb->m_cWnd)*(61.333)*(18.213));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= segmentsAcked) {
	USLSnZdqBZEnrfYQ = (float) (0.1/1.323);

} else {
	USLSnZdqBZEnrfYQ = (float) (8.84*(27.648)*(tcb->m_cWnd)*(14.588)*(74.117));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (48.812-(13.119)-(90.309)-(65.364));

}
CongestionAvoidance (tcb, segmentsAcked);
