segmentsAcked = (int) (0.1/72.963);
float tSYQUSntjAGNpNxY = (float) (((24.036)+(0.1)+(54.125)+(0.1))/((0.1)));
segmentsAcked = (int) (60.663*(tcb->m_ssThresh)*(tSYQUSntjAGNpNxY)*(61.815)*(9.153));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (62.165*(59.6)*(30.307)*(98.459)*(68.5)*(24.923)*(85.391));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
