if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((tcb->m_segmentSize*(8.18)*(89.58)*(65.376))/0.1);

} else {
	tcb->m_segmentSize = (int) (23.957-(92.007)-(61.838)-(tcb->m_segmentSize)-(26.009)-(43.262)-(27.55));
	tcb->m_cWnd = (int) (79.051-(14.514)-(89.579)-(49.146)-(45.727)-(tcb->m_ssThresh)-(83.362)-(segmentsAcked));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(18.683)+(tcb->m_cWnd)+(51.884)+(87.53)+(14.17)+(segmentsAcked)+(23.427)+(60.909));

}
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) ((65.883-(59.108)-(54.109)-(3.862)-(tcb->m_ssThresh))/0.1);
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) ((((30.03+(tcb->m_segmentSize)+(98.235)+(42.859)+(tcb->m_cWnd)))+(15.438)+((tcb->m_cWnd+(tcb->m_ssThresh)+(93.071)+(segmentsAcked)+(84.573)+(tcb->m_ssThresh)+(30.991)+(79.986)+(83.438)))+(45.315))/((16.028)+(70.03)+(0.1)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(51.71)-(tcb->m_ssThresh)-(37.314)-(15.371));
	tcb->m_cWnd = (int) (13.791+(61.037)+(14.0)+(tcb->m_ssThresh));

}
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (87.639+(74.797)+(tcb->m_segmentSize)+(88.609)+(38.233)+(91.479)+(84.397)+(53.431));

} else {
	segmentsAcked = (int) (54.476+(57.862)+(98.444)+(tcb->m_segmentSize)+(64.538));
	segmentsAcked = (int) (56.775+(11.004)+(6.45)+(79.55)+(16.367)+(80.74)+(45.919)+(segmentsAcked));
	tcb->m_cWnd = (int) (96.468+(3.261)+(61.822)+(20.426)+(69.953));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (0.1/17.362);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (51.476-(47.478)-(83.624)-(65.833)-(20.634)-(tcb->m_cWnd)-(2.047));
tcb->m_ssThresh = (int) (13.441+(3.254)+(80.532)+(6.187)+(87.93)+(28.847)+(tcb->m_ssThresh));
