segmentsAcked = (int) (((46.172)+(0.1)+(88.86)+(82.798)+(0.1))/((0.1)+(0.1)+(36.6)));
float dvBSvIhLvqZyUSJu = (float) (95.966+(84.933)+(30.043)+(tcb->m_ssThresh)+(3.627));
float ijsfbJCQLCJUOAsA = (float) (26.228-(42.26)-(segmentsAcked)-(tcb->m_segmentSize)-(27.067)-(91.001));
if (dvBSvIhLvqZyUSJu == segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(38.333)+(41.663)+(68.285));
	tcb->m_cWnd = (int) (48.028+(segmentsAcked)+(41.268)+(24.733)+(41.372)+(48.227));

} else {
	tcb->m_ssThresh = (int) (30.78+(75.339)+(34.234)+(tcb->m_cWnd)+(32.439)+(45.757)+(69.833)+(22.858));

}
tcb->m_ssThresh = (int) ((segmentsAcked+(48.598)+(92.638)+(32.454)+(22.077)+(36.2))/0.1);
int vPPaWVMDebibmYWY = (int) (tcb->m_segmentSize-(62.798)-(17.881)-(43.892));
if (ijsfbJCQLCJUOAsA == ijsfbJCQLCJUOAsA) {
	tcb->m_cWnd = (int) (32.733+(tcb->m_ssThresh)+(25.916)+(12.681)+(65.416)+(26.961)+(5.896)+(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (ijsfbJCQLCJUOAsA*(vPPaWVMDebibmYWY));
	tcb->m_ssThresh = (int) (0.1/36.204);
	ijsfbJCQLCJUOAsA = (float) (0.1/78.624);

}
ijsfbJCQLCJUOAsA = (float) (83.976-(1.963)-(71.118)-(37.258));
