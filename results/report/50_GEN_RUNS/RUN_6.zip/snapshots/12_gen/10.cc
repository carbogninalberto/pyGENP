float eXxrWOCmBxiFipos = (float) ((-74.656-(-43.852)-(47.785)-(-59.565)-(17.513)-(70.078)-(-13.488))/20.182);
tcb->m_segmentSize = (int) (4.89+(-50.486)+(-46.843)+(23.077)+(49.677)+(86.752)+(-53.511)+(-47.133)+(-42.671));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-5.991+(43.097)+(-31.314)+(99.045));
