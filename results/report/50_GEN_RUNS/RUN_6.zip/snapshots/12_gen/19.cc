if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((40.651*(tcb->m_segmentSize)*(tcb->m_cWnd)*(81.666)*(34.469)*(2.325)*(tcb->m_cWnd)*(3.833)*(36.802))/0.1);
	tcb->m_ssThresh = (int) (37.301+(43.093)+(91.322)+(tcb->m_cWnd)+(46.024)+(42.012)+(27.166)+(86.192)+(99.58));

} else {
	tcb->m_ssThresh = (int) (47.329+(41.67));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((30.291)+(0.1)+(0.1)+(38.001)+(53.806))/((0.1)+(0.1)+(0.1)));
segmentsAcked = (int) (0.1/0.1);
