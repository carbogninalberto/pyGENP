TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (-66.611*(80.34)*(54.243)*(-70.04)*(60.25));
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) (43.514-(63.485));

} else {
	segmentsAcked = (int) (33.812*(66.897)*(70.974)*(segmentsAcked)*(48.89)*(54.911)*(segmentsAcked));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (94.445-(tcb->m_cWnd)-(47.35)-(55.285)-(segmentsAcked)-(86.093)-(11.269)-(segmentsAcked)-(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (48.004*(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (67.612+(segmentsAcked)+(22.967)+(20.832)+(20.146)+(2.084)+(41.861));
	segmentsAcked = (int) (0.1/3.896);

}
