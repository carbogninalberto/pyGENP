if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (2.882-(19.767)-(87.963)-(tcb->m_segmentSize)-(0.148)-(67.066)-(94.856)-(tcb->m_segmentSize));
	segmentsAcked = (int) (11.085+(tcb->m_cWnd)+(9.99)+(8.461)+(93.386)+(54.765)+(27.717)+(72.689)+(75.871));

} else {
	tcb->m_cWnd = (int) (59.397*(98.057)*(71.535)*(segmentsAcked)*(78.619)*(88.253)*(57.582));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
int dRRCvbOxoBmHzFEj = (int) (89.282-(76.214)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(5.33)-(30.216)-(tcb->m_ssThresh));
float lwWAVYlJgqUwifoL = (float) (56.232*(tcb->m_cWnd));
if (dRRCvbOxoBmHzFEj < dRRCvbOxoBmHzFEj) {
	dRRCvbOxoBmHzFEj = (int) (86.144+(94.705)+(48.913)+(87.766)+(dRRCvbOxoBmHzFEj)+(1.983)+(lwWAVYlJgqUwifoL)+(tcb->m_cWnd)+(91.889));

} else {
	dRRCvbOxoBmHzFEj = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (27.913-(70.483)-(61.265)-(47.039)-(94.858));
CongestionAvoidance (tcb, segmentsAcked);
