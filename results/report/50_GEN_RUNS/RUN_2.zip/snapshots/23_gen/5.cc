int QBvoLsqUfVDfLTMB = (int) (21.493*(78.091)*(-82.021)*(70.642)*(-42.004)*(-40.762)*(41.497));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-29.31+(-23.716)+(86.008));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (13.406+(-26.65)+(65.981));
CongestionAvoidance (tcb, segmentsAcked);
