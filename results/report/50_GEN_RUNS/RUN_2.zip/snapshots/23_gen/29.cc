tcb->m_segmentSize = (int) (43.973*(96.184));
ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((3.797*(tcb->m_ssThresh)*(21.311)*(80.137)*(12.38)*(89.933)*(85.485))/0.1);

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(86.553)*(45.302));
	tcb->m_ssThresh = (int) (25.667*(77.623)*(63.194)*(13.843));
	tcb->m_segmentSize = (int) (63.131+(37.131)+(38.523)+(12.497)+(41.42)+(91.845));

}
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (94.938+(99.501));

} else {
	tcb->m_cWnd = (int) (7.579+(89.406)+(66.192)+(tcb->m_cWnd)+(80.682)+(80.842)+(87.527)+(10.287)+(20.074));

}
tcb->m_ssThresh = (int) (0.1/94.532);
