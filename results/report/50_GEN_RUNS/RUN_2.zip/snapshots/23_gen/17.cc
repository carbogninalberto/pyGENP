tcb->m_segmentSize = (int) (36.02/65.751);
tcb->m_cWnd = (int) (tcb->m_cWnd+(segmentsAcked)+(22.561)+(86.619)+(tcb->m_ssThresh)+(15.764)+(32.939)+(49.062));
tcb->m_ssThresh = (int) (83.754+(45.766)+(57.77));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (94.835/46.979);

} else {
	tcb->m_segmentSize = (int) (39.251+(34.799));
	tcb->m_segmentSize = (int) (segmentsAcked-(24.149)-(33.315)-(24.983)-(34.759)-(88.997)-(42.3)-(14.109)-(segmentsAcked));
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
