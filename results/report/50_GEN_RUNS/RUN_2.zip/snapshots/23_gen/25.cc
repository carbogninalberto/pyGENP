if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (90.889-(2.909)-(2.876)-(22.147)-(15.913)-(17.981));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(86.37)-(0.816)-(25.396)-(45.775)-(tcb->m_segmentSize)-(14.456)-(tcb->m_segmentSize)-(82.278));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (((12.039)+(39.299)+(46.643)+(0.1))/((25.791)+(36.908)+(86.406)+(94.146)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (95.62+(92.591)+(27.886)+(75.121)+(68.337)+(86.222)+(tcb->m_ssThresh)+(70.876));
tcb->m_segmentSize = (int) ((((97.364*(90.361)*(tcb->m_segmentSize)*(81.849)*(2.905)*(64.695)*(70.802)*(86.299)))+(43.895)+(0.1)+(76.982))/((0.1)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_ssThresh-(26.601)-(41.757)-(82.469));
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_ssThresh = (int) (16.667/69.975);
	tcb->m_segmentSize = (int) (58.218-(tcb->m_cWnd)-(40.131)-(47.297));

} else {
	tcb->m_ssThresh = (int) (94.718-(12.376)-(92.13)-(segmentsAcked)-(16.443)-(5.492)-(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (42.27/0.1);

}
