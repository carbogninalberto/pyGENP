ReduceCwnd (tcb);
int QBvoLsqUfVDfLTMB = (int) (-23.917*(-31.107)*(-84.617)*(53.88)*(13.971)*(-31.674)*(-59.616));
tcb->m_cWnd = (int) (-30.563+(84.032)+(72.978));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-7.454+(55.507)+(-99.496));
CongestionAvoidance (tcb, segmentsAcked);
