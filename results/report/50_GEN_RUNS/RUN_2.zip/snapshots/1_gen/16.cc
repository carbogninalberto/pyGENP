if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(tcb->m_segmentSize)*(53.615)*(74.601));
	segmentsAcked = (int) (((0.1)+(68.28)+((34.057*(segmentsAcked)*(85.707)*(95.464)))+(45.041)+(82.083))/((93.575)+(0.1)));
	tcb->m_segmentSize = (int) ((34.98+(tcb->m_ssThresh)+(73.863)+(32.37))/0.1);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(14.314)*(68.37)*(57.362)*(37.738)*(27.41)*(segmentsAcked)*(85.684)*(tcb->m_segmentSize));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd <= segmentsAcked) {
	segmentsAcked = (int) (0.1/57.92);

} else {
	segmentsAcked = (int) (86.751-(24.949)-(5.445)-(41.295));

}
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_ssThresh = (int) (9.33-(10.926)-(31.568)-(segmentsAcked)-(74.492)-(38.961)-(78.215));
	segmentsAcked = (int) (((55.269)+(14.318)+((98.992*(52.618)*(25.622)*(62.83)*(24.976)*(28.35)*(tcb->m_segmentSize)))+(0.1)+(4.229)+(0.1))/((8.576)+(0.1)));
	tcb->m_segmentSize = (int) (6.058-(43.157));

} else {
	tcb->m_ssThresh = (int) (52.7*(99.361)*(73.435)*(67.851)*(46.846)*(9.398)*(39.562));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
