if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/(6.508+(36.943)+(70.061)+(32.621)));
	segmentsAcked = (int) (78.969-(20.742)-(37.518)-(39.403)-(87.52)-(93.839));
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(24.95)*(68.955));

} else {
	segmentsAcked = (int) (35.354*(76.175)*(79.424)*(58.522)*(18.607)*(2.989)*(58.674));

}
float fnDARaHSbfoddWOQ = (float) (0.1/0.1);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
