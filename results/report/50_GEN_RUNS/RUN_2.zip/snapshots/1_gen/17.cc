TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float bxxgAYYnJBbhrGbv = (float) (tcb->m_segmentSize-(95.268)-(36.243)-(92.531)-(15.31)-(20.741)-(96.845));
tcb->m_ssThresh = (int) (((0.1)+(80.304)+((tcb->m_segmentSize-(tcb->m_cWnd)-(8.869)-(segmentsAcked)-(50.178)-(58.849)-(51.425)))+(0.1))/((17.763)));
if (tcb->m_cWnd >= bxxgAYYnJBbhrGbv) {
	tcb->m_cWnd = (int) (1.823*(25.835)*(39.265)*(43.387)*(88.812)*(27.182)*(21.42)*(44.252));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (0.1/61.787);
	bxxgAYYnJBbhrGbv = (float) (54.036*(69.467)*(51.021)*(30.445));
	segmentsAcked = (int) (99.663+(35.061)+(34.625)+(59.445));

}
int ZtFxmNgftIIqHSUO = (int) (20.419*(bxxgAYYnJBbhrGbv)*(94.767)*(77.474)*(77.735));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (50.561*(27.11)*(74.617)*(17.909)*(55.929)*(69.292)*(40.117)*(8.626)*(0.249));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(75.937)+(ZtFxmNgftIIqHSUO)+(20.757)+(64.626)+(ZtFxmNgftIIqHSUO)+(17.709)+(56.162)+(41.716));
	ZtFxmNgftIIqHSUO = (int) (25.619-(67.869)-(83.701)-(70.183)-(85.588)-(83.445));
	tcb->m_cWnd = (int) (41.783*(75.7)*(18.573)*(81.722)*(13.601)*(71.504)*(86.744));

}
