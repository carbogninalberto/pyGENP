segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (70.092-(70.31)-(2.048)-(45.377));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (38.693+(tcb->m_segmentSize)+(58.729)+(80.036));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_segmentSize = (int) (73.987*(32.094)*(1.248)*(96.025)*(47.911));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (tcb->m_cWnd*(95.95));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(58.141)-(tcb->m_ssThresh)-(54.273)-(76.88)-(segmentsAcked));
	segmentsAcked = (int) (50.923*(segmentsAcked)*(55.012)*(65.126)*(95.508)*(60.008)*(63.82)*(37.742)*(80.243));

}
