CongestionAvoidance (tcb, segmentsAcked);
float wqwAaWMuXyJUJmAt = (float) (((78.531)+(0.1)+(0.1)+(3.236))/((0.1)+(0.1)+(0.1)));
segmentsAcked = (int) (93.388+(tcb->m_ssThresh)+(47.283)+(10.623));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	wqwAaWMuXyJUJmAt = (float) (73.933*(49.555)*(42.136)*(88.875)*(59.358)*(72.2)*(71.22));
	ReduceCwnd (tcb);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	wqwAaWMuXyJUJmAt = (float) (66.336+(12.259)+(57.091)+(90.629));
	tcb->m_segmentSize = (int) (17.943-(segmentsAcked)-(52.247)-(tcb->m_ssThresh)-(29.361)-(51.472)-(30.357));
	tcb->m_ssThresh = (int) ((38.782*(70.57)*(wqwAaWMuXyJUJmAt)*(48.348)*(49.887)*(66.789)*(81.283)*(tcb->m_segmentSize)*(42.454))/20.682);

}
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (20.619*(81.481)*(37.029)*(94.393)*(wqwAaWMuXyJUJmAt)*(38.069));

} else {
	tcb->m_ssThresh = (int) (54.416*(57.356)*(59.787)*(35.105)*(48.707)*(65.692));
	segmentsAcked = (int) (56.202/0.1);

}
float vZTxFSFNVaCExjek = (float) (21.142*(tcb->m_segmentSize)*(tcb->m_cWnd)*(35.024)*(86.307));
if (segmentsAcked != tcb->m_ssThresh) {
	wqwAaWMuXyJUJmAt = (float) (0.1/(88.105-(23.977)-(52.259)));

} else {
	wqwAaWMuXyJUJmAt = (float) (0.1/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
