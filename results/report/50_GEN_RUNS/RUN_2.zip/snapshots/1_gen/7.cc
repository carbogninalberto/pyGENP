tcb->m_cWnd = (int) (16.328*(59.439)*(segmentsAcked)*(86.221)*(96.015)*(22.87)*(10.704)*(29.942));
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_ssThresh = (int) (0.1/45.888);
	tcb->m_cWnd = (int) (81.726-(24.313)-(85.688)-(32.537));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (17.514+(tcb->m_segmentSize)+(22.887)+(55.445)+(42.303)+(37.497)+(48.0)+(67.387)+(tcb->m_ssThresh));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (45.383*(54.269));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
