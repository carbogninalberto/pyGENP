float HACnSIhiYTmHlqYk = (float) (tcb->m_ssThresh-(66.393));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (12.664+(90.587)+(98.086)+(10.939)+(78.564)+(tcb->m_segmentSize)+(69.242));
	tcb->m_cWnd = (int) (25.657*(53.414)*(69.576)*(93.981)*(46.714)*(HACnSIhiYTmHlqYk)*(30.215)*(35.625));
	segmentsAcked = (int) (((1.435)+(71.576)+(0.1)+(0.1)+(96.713))/((96.103)+(18.869)));

} else {
	tcb->m_ssThresh = (int) (((49.347)+(0.1)+(0.1)+(78.365)+(0.1))/((57.296)+(0.1)+(90.216)+(30.516)));

}
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (33.162-(37.35)-(70.54)-(segmentsAcked)-(68.936));
	segmentsAcked = (int) (96.977*(40.344)*(tcb->m_cWnd)*(26.549)*(63.991)*(65.518)*(tcb->m_cWnd)*(51.279)*(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(69.537)-(tcb->m_ssThresh)-(22.147));
	tcb->m_cWnd = (int) (21.927+(84.609));
	tcb->m_segmentSize = (int) (0.469+(60.663)+(segmentsAcked)+(36.581));

}
HACnSIhiYTmHlqYk = (float) (((20.134)+(0.1)+(18.726)+(0.1))/((95.596)+(0.1)+(64.932)+(0.1)));
ReduceCwnd (tcb);
