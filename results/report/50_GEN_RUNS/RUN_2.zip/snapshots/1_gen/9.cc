if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (67.851-(46.475)-(tcb->m_ssThresh)-(26.1)-(1.946)-(52.069)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(35.277));
	tcb->m_ssThresh = (int) (18.053/0.1);

} else {
	tcb->m_segmentSize = (int) (0.1/34.964);
	segmentsAcked = (int) (75.599-(99.284)-(55.708)-(segmentsAcked));

}
tcb->m_segmentSize = (int) (48.973+(14.815)+(80.909)+(11.147)+(65.103));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (tcb->m_cWnd*(27.73)*(81.888)*(34.359));
tcb->m_cWnd = (int) (((81.013)+(33.612)+((39.597+(29.015)+(15.19)+(30.54)+(tcb->m_ssThresh)+(16.299)+(39.499)))+(49.83)+(1.501))/((0.1)+(90.776)+(0.1)+(0.1)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
