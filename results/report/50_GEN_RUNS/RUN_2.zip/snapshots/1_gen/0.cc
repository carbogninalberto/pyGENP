CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(63.0));

}
segmentsAcked = (int) (78.183+(35.532)+(37.943)+(67.26)+(53.851)+(tcb->m_segmentSize)+(63.474));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_ssThresh = (int) (6.607-(61.045));
	tcb->m_ssThresh = (int) (87.265-(tcb->m_segmentSize)-(72.84)-(18.293)-(80.359)-(70.079)-(94.139)-(82.967)-(3.633));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (68.158+(65.174)+(37.168)+(tcb->m_ssThresh)+(49.326)+(98.615)+(64.34)+(39.801));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (segmentsAcked*(8.255)*(18.665));
