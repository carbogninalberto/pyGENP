ReduceCwnd (tcb);
int QBvoLsqUfVDfLTMB = (int) (0.854*(-17.481)*(-51.904)*(39.114)*(4.439)*(-16.085)*(73.343));
tcb->m_cWnd = (int) (-57.481+(49.796)+(45.17));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-15.036+(91.34)+(85.315));
CongestionAvoidance (tcb, segmentsAcked);
