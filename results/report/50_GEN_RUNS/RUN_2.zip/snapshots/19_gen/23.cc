float GUuLYJYywkyeYqPA = (float) (-24.521+(-27.042)+(53.11));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

} else {
	tcb->m_cWnd = (int) (0.1/38.088);

}
segmentsAcked = (int) (-64.203+(71.462)+(-56.008)+(-17.47)+(-43.408)+(-20.581)+(21.989));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

} else {
	tcb->m_cWnd = (int) (0.1/38.088);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (67.03+(-5.203)+(27.034)+(-59.139)+(-70.283)+(31.077)+(72.026));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (60.838*(84.553)*(-54.411));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
segmentsAcked = (int) (-40.483+(34.17)+(40.071)+(-34.28)+(-96.063)+(60.521)+(-23.095));
segmentsAcked = (int) (-40.472+(11.81)+(92.528)+(25.677)+(-69.759)+(-13.091)+(77.663));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (87.673*(39.391)*(-37.034));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (51.144+(-15.842)+(-44.603)+(26.75)+(-80.661)+(-72.743)+(-25.926));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
