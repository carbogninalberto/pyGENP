int QBvoLsqUfVDfLTMB = (int) (-18.225*(78.098)*(-20.119)*(95.808)*(68.141)*(-1.375)*(-25.26));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (38.372+(-14.67)+(-85.725));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-87.483+(-54.573)+(-8.094));
CongestionAvoidance (tcb, segmentsAcked);
