ReduceCwnd (tcb);
int QBvoLsqUfVDfLTMB = (int) (83.349*(74.673)*(-48.988)*(42.575)*(28.102)*(67.978)*(69.353));
tcb->m_cWnd = (int) (-17.174+(93.667)+(74.307));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-71.08+(89.735)+(-13.5));
CongestionAvoidance (tcb, segmentsAcked);
