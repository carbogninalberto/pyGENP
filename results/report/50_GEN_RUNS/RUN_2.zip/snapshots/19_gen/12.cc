float GUuLYJYywkyeYqPA = (float) (-92.435+(17.508)+(31.379));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
segmentsAcked = (int) (78.83+(-24.108)+(-19.143)+(-46.907)+(0.801)+(-93.889)+(-38.945));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

} else {
	tcb->m_cWnd = (int) (0.1/38.088);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (25.567+(21.609)+(-38.701)+(32.493)+(26.702)+(-10.796)+(23.131));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (8.858*(-48.079)*(-46.536));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
segmentsAcked = (int) (9.989+(-80.19)+(99.808)+(34.226)+(-18.567)+(29.981)+(-76.456));
tcb->m_segmentSize = (int) (49.645*(-62.759)*(-17.257));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (98.497+(-63.809)+(-60.089)+(75.457)+(-10.358)+(35.956)+(57.915));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
