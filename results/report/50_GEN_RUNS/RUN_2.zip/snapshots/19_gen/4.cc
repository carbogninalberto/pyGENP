int QBvoLsqUfVDfLTMB = (int) (12.755*(-37.733)*(-44.653)*(58.029)*(-77.66)*(-94.53)*(2.424));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-12.438+(43.664)+(-93.133));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (37.404+(34.396)+(3.307));
CongestionAvoidance (tcb, segmentsAcked);
