float EGGtJzlODKMbbgAB = (float) (82.2-(56.825)-(68.947)-(7.743)-(81.156));
int NAhHmPjxNIWURDfr = (int) (12.516-(-50.926)-(86.76)-(-4.292)-(24.516)-(58.306)-(71.383)-(21.204)-(-10.536));
int rwOmVOmgFmdixynY = (int) (89.227-(-72.202)-(99.701)-(34.559)-(-90.747)-(56.985)-(-45.388)-(64.535));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (31.185*(-46.378)*(30.397)*(-78.865));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (-24.045+(-30.026)+(-16.077)+(-37.855));
segmentsAcked = (int) (60.326+(25.654)+(78.029)+(-66.187));
segmentsAcked = (int) (88.74+(-49.368)+(93.675)+(-31.316)+(56.383)+(80.259)+(66.569));
segmentsAcked = (int) (73.377+(10.355)+(-46.3)+(-13.649)+(82.301)+(61.297)+(27.091));
if (segmentsAcked == tcb->m_segmentSize) {
	EGGtJzlODKMbbgAB = (float) (79.692+(2.159)+(16.552)+(58.13)+(53.347)+(NAhHmPjxNIWURDfr));
	EGGtJzlODKMbbgAB = (float) (36.505-(segmentsAcked)-(4.441)-(11.386));
	segmentsAcked = (int) (75.882+(72.157)+(84.029)+(tcb->m_cWnd)+(78.286)+(13.931)+(23.143));

} else {
	EGGtJzlODKMbbgAB = (float) (NAhHmPjxNIWURDfr-(39.277)-(28.328));

}
if (segmentsAcked == tcb->m_segmentSize) {
	EGGtJzlODKMbbgAB = (float) (NAhHmPjxNIWURDfr-(39.277)-(28.328));

} else {
	EGGtJzlODKMbbgAB = (float) (79.692+(2.159)+(16.552)+(58.13)+(53.347)+(NAhHmPjxNIWURDfr));
	EGGtJzlODKMbbgAB = (float) (36.505-(segmentsAcked)-(4.441)-(11.386));
	segmentsAcked = (int) (75.882+(72.157)+(84.029)+(tcb->m_cWnd)+(78.286)+(13.931)+(23.143));

}
