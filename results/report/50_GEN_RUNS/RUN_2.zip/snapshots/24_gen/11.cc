int QBvoLsqUfVDfLTMB = (int) (76.022*(50.692)*(-38.217)*(96.817)*(-74.464)*(-69.58)*(-46.685));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-42.964+(-33.509)+(-85.792));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-81.618+(-88.202)+(-25.173));
CongestionAvoidance (tcb, segmentsAcked);
