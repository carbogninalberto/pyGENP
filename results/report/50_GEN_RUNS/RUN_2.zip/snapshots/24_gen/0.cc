ReduceCwnd (tcb);
int QBvoLsqUfVDfLTMB = (int) (-98.416*(46.041)*(89.797)*(-89.025)*(-97.471)*(15.151)*(18.776));
tcb->m_cWnd = (int) (12.47+(53.147)+(47.176));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-64.513+(81.332)+(-64.1));
CongestionAvoidance (tcb, segmentsAcked);
