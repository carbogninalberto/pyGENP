tcb->m_segmentSize = (int) (38.966/-72.601);
tcb->m_cWnd = (int) (-51.937+(-94.607)+(46.616)+(99.99)+(11.498)+(29.788)+(83.632)+(-65.818));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (39.251+(34.799));
	tcb->m_segmentSize = (int) (segmentsAcked-(24.149)-(33.315)-(24.983)-(34.759)-(88.997)-(42.3)-(14.109)-(segmentsAcked));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (94.835/46.979);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
