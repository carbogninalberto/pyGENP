if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

} else {
	tcb->m_cWnd = (int) (0.1/38.088);

}
float GUuLYJYywkyeYqPA = (float) (61.753+(-37.771)+(96.834));
segmentsAcked = (int) (-68.771+(10.186)+(12.613)+(40.859)+(66.028)+(-27.582)+(71.158));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-49.433+(-55.991)+(30.262)+(-30.527)+(98.755)+(-44.78)+(-89.022));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
segmentsAcked = (int) (-25.349+(28.979)+(-98.953)+(13.964)+(37.549)+(88.982)+(-74.721));
tcb->m_segmentSize = (int) (-71.139*(-87.457)*(6.256));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (63.47*(-60.718)*(97.305));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (11.092+(16.936)+(-10.405)+(84.82)+(49.882)+(0.679)+(98.574));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (52.974*(72.345)*(12.222));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-57.963+(-76.944)+(-47.541)+(-19.096)+(46.065)+(-16.002)+(55.414));
segmentsAcked = (int) (-8.013+(68.521)+(-98.886)+(-62.662)+(75.087)+(-66.7)+(-80.127));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-41.779*(9.646)*(-32.62));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (53.273+(61.248)+(4.08)+(39.295)+(87.443)+(-40.803)+(84.54));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
segmentsAcked = (int) (45.419+(-23.856)+(-80.5)+(-76.445)+(-54.081)+(-89.979)+(-14.612));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (30.374*(38.675)*(3.058));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-37.27+(-53.146)+(-12.754)+(13.683)+(39.003)+(96.168)+(-37.02));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (39.178+(97.229)+(62.258)+(-13.363)+(33.841)+(67.765)+(-4.563));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (7.974*(0.556)*(-80.996));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
segmentsAcked = (int) (-50.422+(91.484)+(75.048)+(42.515)+(-13.735)+(5.02)+(49.239));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (6.914*(-26.253)*(-75.797));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-67.062*(90.057)*(55.337));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (99.537+(40.402)+(22.182)+(-87.441)+(-7.799)+(48.74)+(60.384));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (98.673*(-89.518)*(-48.526));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-54.496*(-24.318)*(64.116));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (26.682+(38.281)+(83.187)+(-15.569)+(53.053)+(-12.72)+(44.286));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-89.947*(57.569)*(-61.663));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-61.258+(-41.8)+(6.967)+(97.765)+(-31.771)+(12.607)+(-84.799));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (28.016*(4.187)*(79.685));
segmentsAcked = (int) (-43.585+(96.515)+(82.873)+(36.632)+(-81.84)+(-71.31)+(64.83));
segmentsAcked = (int) (-18.784+(41.818)+(-3.881)+(7.64)+(32.039)+(-18.632)+(-16.116));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (24.266*(-66.4)*(20.47));
segmentsAcked = (int) (87.294+(-81.416)+(-37.826)+(44.25)+(42.111)+(46.489)+(-78.744));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (33.157+(-94.486)+(37.586)+(-62.036)+(-71.319)+(41.958)+(33.307));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-77.842+(28.678)+(44.26)+(-82.895)+(-39.247)+(-1.693)+(21.551));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
