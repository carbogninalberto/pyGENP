if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(54.563)-(56.283)-(37.185)-(70.667)-(20.572)-(90.251)-(68.216)-(16.265));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(11.723)-(87.335)-(6.431)-(63.087));
	tcb->m_segmentSize = (int) ((((31.794+(96.643)+(86.471)+(segmentsAcked)))+(11.878)+(0.1)+(0.1))/((0.1)+(22.855)));

} else {
	tcb->m_ssThresh = (int) (19.152-(62.058)-(74.258)-(15.589)-(30.662)-(60.238)-(9.084)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (70.17*(2.969)*(86.045)*(31.255)*(47.058)*(24.502)*(54.192)*(22.172));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (27.166+(tcb->m_cWnd)+(tcb->m_segmentSize)+(43.393)+(77.765)+(tcb->m_cWnd)+(82.721)+(segmentsAcked));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (84.339+(11.021)+(81.439)+(43.969));
	tcb->m_cWnd = (int) (53.145+(tcb->m_segmentSize)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(29.991)+(tcb->m_segmentSize)+(33.148));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked != tcb->m_cWnd) {
	segmentsAcked = (int) (4.849+(47.799)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (32.377*(18.64)*(34.122));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh+(72.763)+(79.503)+(8.125)+(9.034)+(26.418)+(18.631));

}
tcb->m_ssThresh = (int) (((67.651)+(78.638)+((tcb->m_cWnd+(34.842)+(95.333)+(tcb->m_ssThresh)+(83.312)+(57.019)+(tcb->m_segmentSize)+(91.594)))+(68.113))/((63.883)));
segmentsAcked = (int) (0.371+(50.668)+(17.876)+(61.678)+(1.408)+(48.141)+(57.818));
