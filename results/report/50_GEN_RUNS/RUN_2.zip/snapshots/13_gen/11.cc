int ZcNefXeZaeucWMjV = (int) (67.24/78.0);
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (20.441*(38.482)*(28.655)*(30.506)*(91.339)*(11.846)*(62.74)*(69.753)*(12.769));
	tcb->m_segmentSize = (int) (98.537*(13.596)*(35.663)*(51.076)*(41.756)*(50.54)*(68.867));
	tcb->m_cWnd = (int) ((28.88*(69.885)*(tcb->m_segmentSize)*(50.441)*(4.418)*(4.06)*(tcb->m_segmentSize))/66.819);

} else {
	tcb->m_segmentSize = (int) (0.1/66.407);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != segmentsAcked) {
	ZcNefXeZaeucWMjV = (int) (((0.1)+((26.014+(41.536)+(39.174)+(57.223)+(50.587)+(24.61)+(37.476)))+(67.149)+(0.1))/((99.148)+(92.243)+(0.1)+(20.9)+(12.718)));

} else {
	ZcNefXeZaeucWMjV = (int) (17.378*(88.102)*(51.585));

}
tcb->m_cWnd = (int) (12.236+(31.098)+(64.29)+(0.195)+(93.26));
segmentsAcked = (int) (19.577-(41.9)-(16.572)-(70.899)-(36.269)-(97.696));
if (segmentsAcked <= segmentsAcked) {
	ZcNefXeZaeucWMjV = (int) (55.224+(9.392));

} else {
	ZcNefXeZaeucWMjV = (int) (24.462+(ZcNefXeZaeucWMjV)+(75.63));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (34.853+(tcb->m_cWnd)+(9.802)+(ZcNefXeZaeucWMjV)+(98.509)+(2.218)+(57.272)+(30.811));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_cWnd = (int) (98.368*(78.346)*(tcb->m_ssThresh)*(33.224)*(94.158)*(87.806)*(68.276)*(70.129));

} else {
	tcb->m_cWnd = (int) (88.933+(segmentsAcked)+(71.353)+(27.588)+(60.545)+(73.816)+(8.225)+(32.931));
	tcb->m_ssThresh = (int) (48.939*(70.184)*(60.697)*(33.94));

}
