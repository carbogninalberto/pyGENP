if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_ssThresh = (int) (segmentsAcked*(3.369)*(52.153)*(19.216));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (91.071+(95.96)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (88.2/56.936);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_segmentSize*(45.17)*(53.908)*(64.355)*(tcb->m_segmentSize)*(43.638));
	tcb->m_ssThresh = (int) (32.505+(41.469)+(13.04)+(61.077)+(64.937)+(27.858)+(77.526)+(segmentsAcked));

} else {
	segmentsAcked = (int) (0.1/21.928);
	segmentsAcked = (int) (89.912+(47.024)+(16.663)+(56.096)+(1.274));
	tcb->m_cWnd = (int) (4.675-(segmentsAcked)-(61.889)-(50.119)-(20.45)-(85.663)-(46.836));

}
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (70.943-(segmentsAcked)-(tcb->m_cWnd)-(88.4));
	tcb->m_segmentSize = (int) (73.418*(80.889)*(1.311)*(57.318)*(35.306)*(tcb->m_ssThresh)*(38.938)*(90.352));
	tcb->m_cWnd = (int) (0.1/16.592);

} else {
	tcb->m_cWnd = (int) (63.464/0.1);

}
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_segmentSize = (int) (40.609+(50.991)+(34.034)+(tcb->m_segmentSize)+(31.01)+(tcb->m_cWnd)+(82.061));

} else {
	tcb->m_segmentSize = (int) (97.27*(98.098)*(tcb->m_ssThresh)*(72.632)*(44.857)*(90.878)*(46.048)*(45.771));

}
