float hvnSyNemdVZbZOfT = (float) (((0.1)+((65.484-(tcb->m_ssThresh)-(37.79)-(66.054)-(segmentsAcked)-(3.379)-(72.414)-(24.978)))+(0.1)+(90.038)+(0.1))/((95.692)+(29.45)+(0.1)));
tcb->m_segmentSize = (int) (((87.806)+((48.155+(41.638)+(61.597)+(47.847)))+(74.24)+(51.892))/((0.1)+(33.213)));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/34.355);

} else {
	tcb->m_segmentSize = (int) (71.145*(8.841)*(65.317)*(67.928));
	tcb->m_ssThresh = (int) (80.707-(54.345)-(tcb->m_ssThresh)-(68.761)-(28.687));

}
ReduceCwnd (tcb);
int iqyWzWXTNDfilAgE = (int) (56.325+(38.227)+(81.276)+(15.647)+(88.522)+(segmentsAcked)+(72.327));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
hvnSyNemdVZbZOfT = (float) (iqyWzWXTNDfilAgE-(15.006)-(87.544));
