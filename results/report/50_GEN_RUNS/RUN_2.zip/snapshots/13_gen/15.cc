tcb->m_cWnd = (int) (15.239-(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (74.41+(11.674));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (27.18+(17.683)+(67.082));
	tcb->m_ssThresh = (int) (89.369+(1.872)+(19.908)+(tcb->m_ssThresh)+(49.575)+(51.532));
	segmentsAcked = (int) (16.422*(41.038)*(30.579)*(91.876)*(10.368)*(69.685)*(59.236)*(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (16.263*(53.084)*(26.564)*(segmentsAcked)*(53.967)*(segmentsAcked)*(tcb->m_ssThresh));

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (9.22*(24.805));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (5.089*(tcb->m_ssThresh)*(0.166)*(97.999)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-0.047*(85.896)*(76.509)*(60.863)*(0.041));

}
if (tcb->m_cWnd <= segmentsAcked) {
	segmentsAcked = (int) (58.632+(49.379)+(45.724)+(38.786)+(37.114));

} else {
	segmentsAcked = (int) (91.065+(tcb->m_cWnd)+(67.857)+(tcb->m_segmentSize)+(52.595)+(63.451)+(68.168));

}
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (90.02+(90.416)+(tcb->m_ssThresh)+(84.073)+(22.028)+(52.557)+(46.671));
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(62.377)+(49.215))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (59.884*(56.036)*(tcb->m_ssThresh)*(38.981)*(17.902)*(41.697)*(46.396));
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
