tcb->m_ssThresh = (int) (32.653/75.208);
int LBqekPLsQqcWSTua = (int) (95.46+(80.886)+(44.381)+(44.09)+(53.82)+(4.572)+(73.75)+(61.734));
tcb->m_cWnd = (int) ((61.744+(14.036)+(34.935)+(20.631))/0.1);
if (segmentsAcked > segmentsAcked) {
	segmentsAcked = (int) (60.925-(34.804)-(tcb->m_cWnd)-(20.325));

} else {
	segmentsAcked = (int) (27.436*(33.816)*(37.411)*(LBqekPLsQqcWSTua)*(62.984));

}
tcb->m_ssThresh = (int) (40.757-(31.334)-(94.625)-(segmentsAcked));
ReduceCwnd (tcb);
