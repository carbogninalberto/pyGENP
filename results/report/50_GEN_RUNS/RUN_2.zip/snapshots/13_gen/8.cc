tcb->m_ssThresh = (int) (0.1/1.368);
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (34.765*(41.957)*(55.462)*(9.266)*(tcb->m_segmentSize)*(40.244)*(28.045)*(2.183));
	tcb->m_cWnd = (int) (50.683*(30.435)*(segmentsAcked)*(84.696)*(74.03)*(91.346)*(55.63)*(3.978)*(49.928));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) ((59.682*(19.564)*(73.051)*(22.247)*(33.716)*(33.55)*(3.964)*(segmentsAcked))/0.1);

}
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (15.126*(29.162)*(91.635)*(81.519)*(68.118));

} else {
	tcb->m_segmentSize = (int) (0.1/38.616);

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (80.269*(18.535)*(72.897)*(34.736)*(4.667));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (85.173*(15.764)*(30.77)*(44.444));

}
CongestionAvoidance (tcb, segmentsAcked);
