int LbQEXooOBSGpYbjH = (int) (-87.185/-74.626);
segmentsAcked = (int) (49.144-(-37.543)-(-30.08));
float aCjODjGjCJoVEbpj = (float) (((48.504)+(-12.876)+((-12.792*(-85.282)))+(-48.774))/((70.884)));
