if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
float GUuLYJYywkyeYqPA = (float) (-30.649+(-21.595)+(-59.727));
segmentsAcked = (int) (91.398+(-65.283)+(88.182)+(-17.909)+(-75.985)+(10.558)+(80.797));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-93.281+(31.653)+(26.705)+(58.487)+(72.946)+(-86.549)+(-84.517));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (78.137*(13.461)*(-27.187));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (29.577*(-22.905)*(2.288));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
segmentsAcked = (int) (31.658+(-29.381)+(43.001)+(45.565)+(-62.501)+(-81.708)+(18.479));
tcb->m_segmentSize = (int) (64.434*(-2.399)*(23.195));
segmentsAcked = (int) (-18.323+(75.413)+(41.585)+(58.767)+(12.485)+(39.643)+(41.635));
tcb->m_segmentSize = (int) (-20.312*(-61.033)*(-16.454));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-52.218+(-40.578)+(4.276)+(-38.037)+(-19.511)+(-70.075)+(40.77));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-46.239+(44.913)+(61.418)+(3.235)+(35.122)+(87.65)+(-96.554));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
