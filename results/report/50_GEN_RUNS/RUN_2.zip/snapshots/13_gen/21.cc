tcb->m_ssThresh = (int) (((0.1)+(0.1)+(11.073)+((82.255+(27.674)+(96.453)+(65.0)))+(0.1))/((0.1)));
ReduceCwnd (tcb);
segmentsAcked = (int) (0.1/(4.655-(35.205)-(7.304)-(segmentsAcked)-(59.198)-(46.899)-(64.835)));
tcb->m_ssThresh = (int) (45.185-(30.954)-(tcb->m_cWnd)-(6.387)-(43.952)-(74.245)-(29.083));
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_ssThresh = (int) (83.107-(74.232)-(1.558));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(95.352));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
