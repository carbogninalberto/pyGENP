tcb->m_segmentSize = (int) (tcb->m_cWnd-(43.764));
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (61.231+(66.726)+(62.938)+(91.596)+(73.91));
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(19.357)+(segmentsAcked)+(tcb->m_ssThresh)+(38.61));
	segmentsAcked = (int) (((0.1)+(0.1)+(9.881)+(0.1)+(25.055))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (29.571*(64.647)*(5.224)*(11.492)*(segmentsAcked)*(68.36)*(80.637));
	tcb->m_segmentSize = (int) (4.93*(33.247)*(14.504)*(segmentsAcked)*(95.916)*(59.093)*(segmentsAcked));
	tcb->m_ssThresh = (int) (2.761*(13.784)*(36.474)*(1.644)*(78.886)*(97.549)*(66.647)*(77.736));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (53.304*(tcb->m_cWnd));
