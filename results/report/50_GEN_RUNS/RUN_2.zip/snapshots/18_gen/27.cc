float GUuLYJYywkyeYqPA = (float) (24.998+(99.566)+(51.813));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

} else {
	tcb->m_cWnd = (int) (0.1/38.088);

}
segmentsAcked = (int) (-85.264+(-97.733)+(-51.869)+(-97.567)+(10.474)+(-51.171)+(41.758));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
segmentsAcked = (int) (-59.521+(-39.068)+(76.086)+(-67.43)+(41.134)+(-11.391)+(-61.546));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (63.921*(-70.716)*(76.162));
tcb->m_segmentSize = (int) (31.951*(-41.076)*(-34.148));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
segmentsAcked = (int) (56.156+(-14.608)+(51.464)+(-61.636)+(8.215)+(-6.474)+(20.68));
segmentsAcked = (int) (-12.101+(-59.204)+(97.965)+(-14.905)+(-28.237)+(-91.566)+(8.776));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-82.494*(-98.82)*(-6.703));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (55.964+(39.332)+(44.139)+(4.437)+(53.327)+(0.288)+(72.179));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
