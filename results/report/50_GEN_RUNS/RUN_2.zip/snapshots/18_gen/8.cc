if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
float GUuLYJYywkyeYqPA = (float) (-24.217+(-57.151)+(53.355));
segmentsAcked = (int) (-12.079+(-67.105)+(-44.912)+(60.581)+(46.276)+(-98.035)+(-3.839));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (0.318+(-45.867)+(-83.307)+(-0.078)+(61.062)+(19.99)+(38.301));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (73.536+(-76.041)+(-82.588)+(-73.423)+(56.926)+(-96.015)+(-58.146));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (-65.805*(-86.61)*(-65.046));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (39.204*(-91.006)*(89.357));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (40.807*(68.274)*(17.738));
segmentsAcked = (int) (74.549+(50.067)+(47.303)+(86.029)+(25.514)+(-66.476)+(19.241));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (-52.238*(-4.724)*(14.597));
tcb->m_segmentSize = (int) (-48.211*(11.952)*(91.394));
segmentsAcked = (int) (34.988+(-22.328)+(-51.095)+(-81.349)+(44.297)+(-84.778)+(-2.462));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (51.93*(65.593)*(39.448));
segmentsAcked = (int) (-84.264+(54.034)+(-48.904)+(-77.914)+(-27.589)+(-36.737)+(12.245));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-99.769*(10.915)*(-38.586));
segmentsAcked = (int) (23.379+(-15.781)+(73.433)+(-17.86)+(-18.282)+(-80.534)+(-83.869));
segmentsAcked = (int) (-33.704+(30.076)+(-2.24)+(99.677)+(-8.809)+(-33.939)+(33.737));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (45.35*(25.799)*(-82.598));
segmentsAcked = (int) (34.11+(76.192)+(77.927)+(-53.445)+(36.84)+(84.69)+(66.18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-39.1+(-1.261)+(-79.386)+(-89.919)+(-46.693)+(-2.844)+(68.75));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (48.44+(5.771)+(57.08)+(41.67)+(-94.883)+(15.527)+(67.818));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
