ReduceCwnd (tcb);
int QBvoLsqUfVDfLTMB = (int) (-61.136*(65.61)*(97.601)*(-57.776)*(61.703)*(77.57)*(48.421));
tcb->m_cWnd = (int) (99.777+(-49.957)+(45.372));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (85.065+(-26.935)+(-96.406));
CongestionAvoidance (tcb, segmentsAcked);
