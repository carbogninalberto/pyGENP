int azbcpjyMHkgDdfAH = (int) 34.906;
float vgPuJFCFnULCPOzo = (float) (-29.143*(73.52)*(74.283)*(-59.064)*(-27.285));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (((-47.396)+(47.934)+(61.915)+((44.037-(67.007)-(19.136)-(15.44)-(5.643)))+(-16.99))/((-80.602)));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_segmentSize = (int) (53.995-(42.735)-(59.291)-(56.075)-(57.506)-(55.893));
	azbcpjyMHkgDdfAH = (int) (17.252-(24.92)-(tcb->m_cWnd)-(42.71));

} else {
	tcb->m_segmentSize = (int) (53.12+(10.246)+(azbcpjyMHkgDdfAH)+(57.385)+(8.542)+(91.992)+(azbcpjyMHkgDdfAH)+(67.894));
	segmentsAcked = (int) (87.925-(28.755)-(46.987)-(-38.843));

}
segmentsAcked = (int) (((-95.764)+(5.486)+(78.147)+(75.646))/((39.769)));
segmentsAcked = (int) (((29.42)+(0.54)+(-86.949)+(97.247))/((-61.589)));
segmentsAcked = (int) (84.111/64.817);
segmentsAcked = (int) (((-26.213)+(47.924)+(-66.855)+((-49.538-(24.125)-(33.888)-(60.329)-(-23.244)))+(-31.665))/((39.393)));
segmentsAcked = (int) (((-0.665)+(-8.742)+(84.772)+((-32.938-(67.564)-(-47.83)-(79.552)-(63.36)))+(37.496))/((-3.543)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-77.132-(76.001)-(-33.76)-(6.995)-(-94.82)-(28.621)-(25.045)-(-64.989)-(49.724));
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_segmentSize = (int) (53.995-(42.735)-(59.291)-(56.075)-(57.506)-(55.893));
	azbcpjyMHkgDdfAH = (int) (17.252-(24.92)-(tcb->m_cWnd)-(42.71));

} else {
	tcb->m_segmentSize = (int) (53.12+(10.246)+(azbcpjyMHkgDdfAH)+(57.385)+(8.542)+(91.992)+(azbcpjyMHkgDdfAH)+(67.894));
	segmentsAcked = (int) (87.925-(28.755)-(46.987)-(-38.843));

}
segmentsAcked = (int) (((12.137)+(-13.465)+(-31.219)+(-65.546))/((-14.126)));
segmentsAcked = (int) (31.971/-37.863);
segmentsAcked = (int) (((17.908)+(-88.943)+(-85.113)+((-2.635-(14.175)-(-89.194)-(-58.928)-(-91.282)))+(37.229))/((-82.75)));
segmentsAcked = (int) (-47.37-(-79.504)-(53.446)-(87.807)-(43.777)-(-21.722)-(37.644)-(-34.333)-(4.844));
