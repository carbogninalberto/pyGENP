if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/(6.321*(tcb->m_ssThresh)*(36.124)*(78.245)*(59.806)));

} else {
	tcb->m_segmentSize = (int) (44.134*(76.01)*(41.371));
	CongestionAvoidance (tcb, segmentsAcked);

}
