int QBvoLsqUfVDfLTMB = (int) (20.338*(80.282)*(2.759)*(85.152)*(-5.758)*(-16.24)*(-29.913));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (5.602+(-28.811)+(48.466));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (24.063+(22.777)+(-37.289));
CongestionAvoidance (tcb, segmentsAcked);
