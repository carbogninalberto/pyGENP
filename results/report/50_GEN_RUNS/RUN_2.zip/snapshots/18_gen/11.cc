ReduceCwnd (tcb);
int QBvoLsqUfVDfLTMB = (int) (-98.515*(25.601)*(46.217)*(-83.444)*(69.908)*(55.794)*(-22.198));
tcb->m_cWnd = (int) (-22.756+(-70.038)+(-40.399));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (30.581+(-36.972)+(4.153));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
