if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

} else {
	tcb->m_cWnd = (int) (0.1/38.088);

}
float GUuLYJYywkyeYqPA = (float) (-92.35+(-80.271)+(41.658));
segmentsAcked = (int) (9.089+(-23.429)+(91.546)+(38.663)+(30.929)+(25.171)+(31.505));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

} else {
	tcb->m_cWnd = (int) (0.1/38.088);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-98.105+(-20.017)+(-61.475)+(90.743)+(-72.245)+(89.158)+(24.231));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-66.567*(55.112)*(38.167));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
segmentsAcked = (int) (35.361+(-89.919)+(-98.811)+(54.552)+(-31.386)+(-98.779)+(-91.207));
tcb->m_segmentSize = (int) (-26.844*(-58.564)*(81.04));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-36.402+(2.61)+(24.602)+(70.134)+(26.826)+(-26.13)+(9.21));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
