CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
int QBvoLsqUfVDfLTMB = (int) (-37.413*(63.345)*(8.731)*(41.041)*(-22.05)*(88.83)*(-84.659));
tcb->m_cWnd = (int) (34.326+(60.741)+(14.225));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (33.975+(18.952)+(37.029));
CongestionAvoidance (tcb, segmentsAcked);
