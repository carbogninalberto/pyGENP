float eYFdvglbltJrFFoL = (float) (-29.11+(-73.484)+(-31.28)+(2.161)+(0.748));
float AqEmOIaFqRlXZtoX = (float) 48.403;
