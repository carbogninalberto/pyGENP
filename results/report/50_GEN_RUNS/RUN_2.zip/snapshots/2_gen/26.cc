float vZTxFSFNVaCExjek = (float) (-85.039*(99.022)*(-65.51)*(97.565)*(-94.274));
float wqwAaWMuXyJUJmAt = (float) (((-80.3)+(-5.084)+(-82.225)+(-74.44))/((29.771)+(76.818)+(42.217)));
if (vZTxFSFNVaCExjek == wqwAaWMuXyJUJmAt) {
	tcb->m_cWnd = (int) (8.989*(63.827)*(24.335)*(61.095)*(23.514));

} else {
	tcb->m_cWnd = (int) ((((78.679*(97.141)*(68.584)*(segmentsAcked)))+((47.356-(72.071)-(74.666)-(52.544)))+(0.1)+(1.35)+(0.1))/((62.046)+(0.1)+(40.764)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (5.049+(90.909)+(67.479)+(1.561));
CongestionAvoidance (tcb, segmentsAcked);
