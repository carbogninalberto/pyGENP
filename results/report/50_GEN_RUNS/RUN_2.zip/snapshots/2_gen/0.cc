int aUXRdSRXFConfDwE = (int) (((75.866)+(-8.399)+((12.402-(-94.494)-(47.413)-(-37.023)))+(-45.992)+(-81.746)+(56.183)+(-1.857)+(27.129))/((80.54)));
float hnMSXifgTFrrlKMD = (float) (85.723*(-66.628)*(92.075)*(42.097)*(30.75)*(-80.985)*(59.744)*(25.656)*(-81.127));
float zQeFYWkatTMPpJPa = (float) (39.677-(-44.514)-(-52.552)-(-6.11)-(-13.001)-(3.377)-(-54.515)-(-18.752)-(-78.576));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float tGdabasbgPEpnymR = (float) (-19.083+(-0.627)+(-81.158));
if (zQeFYWkatTMPpJPa < tcb->m_segmentSize) {
	zQeFYWkatTMPpJPa = (float) (57.443-(71.544)-(52.333)-(73.542)-(8.394)-(44.577)-(hnMSXifgTFrrlKMD)-(51.421)-(43.601));

} else {
	zQeFYWkatTMPpJPa = (float) (23.909-(tcb->m_segmentSize)-(96.939)-(12.948)-(60.335));
	tGdabasbgPEpnymR = (float) ((45.076*(segmentsAcked)*(58.906)*(52.351))/45.696);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
zQeFYWkatTMPpJPa = (float) (10.388+(19.379)+(56.42)+(-74.331)+(21.802)+(-31.765)+(20.44));
