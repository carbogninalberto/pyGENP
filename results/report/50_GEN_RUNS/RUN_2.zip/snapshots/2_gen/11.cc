float kAzEwrcVSTKaGLts = (float) (-50.124/1.266);
int UJCQneoHSMnWubOy = (int) (63.968-(-77.497)-(-90.621));
if (tcb->m_segmentSize >= kAzEwrcVSTKaGLts) {
	tcb->m_segmentSize = (int) (18.793+(67.252)+(UJCQneoHSMnWubOy)+(15.203)+(0.847)+(55.355)+(94.923)+(63.12));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (28.052+(38.123)+(36.177)+(49.489)+(31.394));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
UJCQneoHSMnWubOy = (int) (69.729+(57.718)+(-29.912)+(-73.657)+(-53.489));
