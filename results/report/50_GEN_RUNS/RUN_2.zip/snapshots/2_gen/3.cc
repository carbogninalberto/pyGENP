segmentsAcked = (int) (-24.284*(-23.573));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-16.412)*(63.0));

}
segmentsAcked = (int) (-65.816+(-84.369)+(21.562)+(-20.288)+(60.423)+(-62.899)+(86.228));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (32.061*(-56.717)*(87.683));
