segmentsAcked = (int) (-42.746/45.607);
