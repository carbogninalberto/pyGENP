float ASpNOLsdffcvEZkB = (float) (-18.818*(-24.381)*(-20.864)*(26.264)*(30.931)*(0.028));
tcb->m_cWnd = (int) (-80.828/-51.049);
