tcb->m_cWnd = (int) (-38.295/-13.937);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-97.583*(-42.336)*(-61.999)*(78.145)*(28.806)*(-42.888)*(49.524)*(-34.042));
if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(59.271));
	tcb->m_segmentSize = (int) (77.833-(31.634)-(33.792));

} else {
	segmentsAcked = (int) (0.83-(18.471)-(7.063));
	tcb->m_segmentSize = (int) (11.714*(45.096)*(16.164)*(22.091)*(segmentsAcked)*(17.205));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
