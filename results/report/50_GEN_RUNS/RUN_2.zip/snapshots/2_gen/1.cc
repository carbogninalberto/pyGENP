segmentsAcked = (int) (3.356/-2.511);
float PnbJqobNYbTWUlCd = (float) (75.382*(8.191)*(-27.708)*(-49.805)*(46.124)*(-45.117)*(20.919)*(77.164));
tcb->m_segmentSize = (int) (59.637-(-55.391)-(57.526)-(-51.451)-(-15.717)-(62.306));
float CFUdgDwtqCxxcRLN = (float) (93.97-(-37.475));
segmentsAcked = (int) (34.337+(-89.387)+(-70.129)+(20.101)+(-29.782)+(14.79)+(41.579)+(-27.594)+(-74.526));
int tOPeLcNnVnrtpAYD = (int) (-89.825*(-39.087)*(-28.405)*(-42.734)*(68.274)*(96.424)*(-1.636));
CongestionAvoidance (tcb, segmentsAcked);
CFUdgDwtqCxxcRLN = (float) (-23.406-(-16.667)-(-35.44)-(13.729)-(-94.76)-(-13.298)-(-53.866)-(-38.836)-(33.945));
segmentsAcked = SlowStart (tcb, segmentsAcked);
