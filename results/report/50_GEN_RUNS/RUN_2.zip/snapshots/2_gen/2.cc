CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/0.1);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (51.688+(80.954));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (62.607-(37.584)-(64.93)-(-18.756)-(35.482)-(26.318)-(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
