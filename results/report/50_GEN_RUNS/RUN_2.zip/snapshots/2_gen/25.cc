int AtcZLaNbdQkBlCBJ = (int) (-15.554-(-93.626)-(56.5)-(64.712)-(25.705)-(-24.156));
int cCyszqUHTNoeIjtt = (int) (78.466*(-62.892)*(65.491)*(-33.105));
tcb->m_segmentSize = (int) (-1.778-(26.56)-(80.436)-(-13.37)-(19.49)-(96.821)-(-5.17)-(34.473));
tcb->m_segmentSize = (int) (-55.264-(-22.465)-(-20.706)-(3.461)-(-28.385)-(-56.518)-(14.542)-(-23.942));
segmentsAcked = (int) (1.621+(92.708)+(14.02)+(20.553)+(70.949)+(78.23)+(-16.746)+(32.719));
segmentsAcked = (int) (0.265+(-26.97)+(-22.956)+(59.582)+(-6.144)+(-68.35)+(62.052)+(-99.96));
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (29.907+(70.929)+(21.602)+(segmentsAcked));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(14.664)*(tcb->m_cWnd)*(2.977)*(58.751));

} else {
	tcb->m_cWnd = (int) (54.648*(segmentsAcked));
	tcb->m_segmentSize = (int) (92.696*(58.735)*(tcb->m_segmentSize));

}
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (29.907+(70.929)+(-59.598)+(segmentsAcked));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(14.664)*(tcb->m_cWnd)*(2.977)*(58.751));

} else {
	tcb->m_cWnd = (int) (54.648*(segmentsAcked));
	tcb->m_segmentSize = (int) (92.696*(58.735)*(tcb->m_segmentSize));

}
