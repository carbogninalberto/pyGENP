TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= segmentsAcked) {
	segmentsAcked = (int) (0.1/57.92);

} else {
	segmentsAcked = (int) (86.751-(24.949)-(5.445)-(41.295));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
