int cCyszqUHTNoeIjtt = (int) 18.383;
tcb->m_segmentSize = (int) (52.534-(-38.442)-(75.343)-(52.732)-(-8.8)-(96.733)-(59.497)-(17.534));
