ReduceCwnd (tcb);
int QBvoLsqUfVDfLTMB = (int) (-94.925*(-31.225)*(34.865)*(78.228)*(38.628)*(-0.99)*(2.029));
tcb->m_cWnd = (int) (37.607+(27.635)+(84.681));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (92.727+(86.028)+(16.397));
CongestionAvoidance (tcb, segmentsAcked);
