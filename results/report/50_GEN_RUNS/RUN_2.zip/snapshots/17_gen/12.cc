if (segmentsAcked > tcb->m_cWnd) {
	segmentsAcked = (int) (((11.036)+(0.1)+((27.993+(26.523)+(16.948)+(33.139)))+(38.358)+(0.1)+(28.353)+(0.1))/((0.1)+(0.1)));
	tcb->m_segmentSize = (int) (99.405*(21.082)*(51.913)*(81.222)*(95.07)*(14.547)*(12.071)*(98.616)*(segmentsAcked));

} else {
	segmentsAcked = (int) (68.072+(0.856)+(31.671)+(78.102));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (16.304+(58.879)+(80.295)+(85.387)+(tcb->m_cWnd));

}
