float vgPuJFCFnULCPOzo = (float) (-99.378*(65.552)*(-36.259)*(35.284)*(-61.15));
int azbcpjyMHkgDdfAH = (int) 89.689;
