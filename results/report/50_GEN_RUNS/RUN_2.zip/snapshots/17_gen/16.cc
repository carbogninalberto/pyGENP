TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked != segmentsAcked) {
	tcb->m_segmentSize = (int) (0.1/46.885);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (86.085/0.1);

}
if (segmentsAcked >= segmentsAcked) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (85.177*(55.088)*(23.913)*(47.667));

}
