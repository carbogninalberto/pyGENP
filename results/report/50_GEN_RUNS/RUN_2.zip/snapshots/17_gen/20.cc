ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (77.024+(73.377));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(79.113));

}
int DgRjmRrCmhYnhwFa = (int) (52.896*(21.514)*(-86.403)*(84.121)*(-54.186)*(7.421));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (77.024+(73.377));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(79.113));

}
