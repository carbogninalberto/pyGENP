int QBvoLsqUfVDfLTMB = (int) (13.375*(53.588)*(18.678)*(70.462)*(64.105)*(63.625)*(-25.688));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (21.67+(40.596)+(-58.055));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (82.421+(15.337)+(-57.052));
CongestionAvoidance (tcb, segmentsAcked);
