float GUuLYJYywkyeYqPA = (float) (33.666+(60.2)+(69.27));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
segmentsAcked = (int) (-56.37+(-31.03)+(83.328)+(11.631)+(18.392)+(-29.611)+(-80.647));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-4.768+(-63.194)+(-10.612)+(-49.538)+(54.436)+(50.395)+(-11.704));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-60.346+(-80.251)+(3.041)+(-20.985)+(76.455)+(29.446)+(-2.193));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (14.74*(75.881)*(73.08));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (-8.042*(87.02)*(-96.098));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (33.821*(-58.953)*(34.965));
segmentsAcked = (int) (34.858+(-0.651)+(-89.029)+(97.056)+(-29.556)+(-79.461)+(-94.753));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (79.025*(-68.793)*(10.699));
tcb->m_segmentSize = (int) (-38.782*(-71.822)*(-48.971));
segmentsAcked = (int) (9.811+(86.074)+(-86.249)+(63.179)+(-25.888)+(-47.02)+(-88.579));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (-11.282*(-59.739)*(41.151));
segmentsAcked = (int) (50.552+(49.806)+(19.14)+(75.567)+(16.622)+(-35.629)+(69.584));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (96.909*(30.288)*(95.007));
segmentsAcked = (int) (-54.651+(-2.729)+(-70.497)+(67.111)+(-29.112)+(65.776)+(3.108));
segmentsAcked = (int) (48.844+(58.003)+(-61.115)+(-58.139)+(91.143)+(2.158)+(-55.706));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (52.33*(-94.452)*(-57.194));
segmentsAcked = (int) (-48.331+(-8.423)+(-26.191)+(-60.424)+(-81.221)+(8.532)+(28.233));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-69.685+(-26.351)+(34.787)+(77.591)+(-89.206)+(-84.077)+(-70.703));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-96.255+(21.038)+(81.211)+(-82.024)+(-62.815)+(-59.881)+(-60.9));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
