float GUuLYJYywkyeYqPA = (float) (-73.957+(-38.743)+(-63.24));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
segmentsAcked = (int) (-21.028+(41.906)+(-43.579)+(20.304)+(-57.88)+(-75.138)+(34.594));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

} else {
	tcb->m_cWnd = (int) (0.1/38.088);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-81.917+(-13.203)+(-70.145)+(46.772)+(74.952)+(-61.502)+(15.279));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (39.765*(63.639)*(-80.038));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
segmentsAcked = (int) (-58.023+(-70.418)+(-79.754)+(90.323)+(-37.416)+(-76.12)+(-38.097));
tcb->m_segmentSize = (int) (-76.755*(-11.155)*(-82.896));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-97.531+(52.609)+(80.135)+(-0.62)+(-1.407)+(85.664)+(12.437));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
