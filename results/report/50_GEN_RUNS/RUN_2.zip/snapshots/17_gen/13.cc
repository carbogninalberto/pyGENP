float GUuLYJYywkyeYqPA = (float) (-22.594+(-8.91)+(42.915));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

} else {
	tcb->m_cWnd = (int) (0.1/38.088);

}
segmentsAcked = (int) (-38.525+(85.947)+(-42.823)+(84.185)+(85.608)+(22.433)+(23.249));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-86.217+(-41.534)+(66.104)+(93.944)+(30.058)+(-20.257)+(-0.697));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (6.649+(37.127)+(48.345)+(-21.819)+(92.805)+(48.85)+(-96.448));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (-7.629*(-88.277)*(-61.454));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (74.301*(-61.32)*(-99.066));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (-53.782*(95.597)*(-77.559));
segmentsAcked = (int) (-5.985+(-93.754)+(-68.018)+(-83.617)+(72.882)+(-78.89)+(67.517));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (-5.482*(53.62)*(75.594));
tcb->m_segmentSize = (int) (47.817*(28.772)*(44.769));
segmentsAcked = (int) (92.616+(-56.439)+(-26.863)+(89.546)+(-40.992)+(-81.075)+(-3.312));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (9.128*(-94.568)*(-86.137));
segmentsAcked = (int) (-36.511+(-3.651)+(-50.745)+(90.065)+(9.413)+(-11.201)+(96.724));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-92.935*(-50.264)*(-20.24));
segmentsAcked = (int) (71.319+(-17.146)+(-47.404)+(67.622)+(12.566)+(38.999)+(-22.791));
segmentsAcked = (int) (77.082+(-57.887)+(51.059)+(-45.405)+(-43.087)+(63.172)+(-38.064));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (83.424*(-16.092)*(-38.55));
segmentsAcked = (int) (-62.116+(34.903)+(-53.607)+(38.283)+(8.995)+(16.59)+(40.804));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (89.475+(-80.647)+(21.447)+(-21.268)+(91.855)+(-63.444)+(26.26));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-30.145+(61.157)+(-5.057)+(-83.859)+(-56.374)+(51.819)+(-68.061));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-12.994*(-82.376)*(-82.348));
segmentsAcked = (int) (1.052+(93.965)+(-75.001)+(85.994)+(-2.483)+(6.422)+(50.465));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (67.237+(-9.644)+(64.617)+(-36.233)+(-34.428)+(-1.736)+(-72.798));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (27.561+(-57.372)+(94.891)+(41.231)+(43.894)+(72.788)+(10.827));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
