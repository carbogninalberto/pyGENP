int QBvoLsqUfVDfLTMB = (int) (-53.762*(35.271)*(83.473)*(-29.475)*(87.201)*(89.355)*(-79.643));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (7.276+(84.18)+(11.612));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-83.853+(-78.156)+(80.491));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
