ReduceCwnd (tcb);
int QBvoLsqUfVDfLTMB = (int) (-5.191*(-30.67)*(82.025)*(62.905)*(72.374)*(90.619)*(50.158));
tcb->m_cWnd = (int) (-79.177+(-43.155)+(57.651));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (18.067+(-15.739)+(-79.387));
CongestionAvoidance (tcb, segmentsAcked);
