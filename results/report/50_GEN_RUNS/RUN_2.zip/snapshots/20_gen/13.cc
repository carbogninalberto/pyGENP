int QBvoLsqUfVDfLTMB = (int) (-70.003*(26.096)*(-49.738)*(39.273)*(19.732)*(-93.118)*(88.771));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (16.073+(-94.179)+(-68.44));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-7.657+(54.687)+(-97.955));
CongestionAvoidance (tcb, segmentsAcked);
