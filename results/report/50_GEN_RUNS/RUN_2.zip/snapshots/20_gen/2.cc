ReduceCwnd (tcb);
int QBvoLsqUfVDfLTMB = (int) (-90.562*(19.131)*(-18.44)*(45.888)*(90.549)*(-11.338)*(7.169));
tcb->m_cWnd = (int) (13.461+(-77.332)+(37.626));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (82.316+(-1.287)+(-43.786));
CongestionAvoidance (tcb, segmentsAcked);
