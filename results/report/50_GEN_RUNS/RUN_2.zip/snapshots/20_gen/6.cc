CongestionAvoidance (tcb, segmentsAcked);
int QBvoLsqUfVDfLTMB = (int) (18.179*(7.395)*(46.862)*(-85.555)*(69.539)*(66.879)*(-21.139));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (37.086+(-50.301)+(4.078));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (37.275+(-31.984)+(-37.378));
CongestionAvoidance (tcb, segmentsAcked);
