int QBvoLsqUfVDfLTMB = (int) (25.834*(44.547)*(93.988)*(54.136)*(11.989)*(56.863)*(-93.726));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (94.901+(-92.201)+(-57.218));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-41.88+(-84.638)+(-26.647));
CongestionAvoidance (tcb, segmentsAcked);
