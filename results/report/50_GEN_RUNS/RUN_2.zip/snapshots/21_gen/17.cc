ReduceCwnd (tcb);
int QBvoLsqUfVDfLTMB = (int) (76.616*(37.024)*(-94.151)*(-55.608)*(85.912)*(-68.053)*(-0.535));
tcb->m_cWnd = (int) (-55.668+(-8.131)+(24.446));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-40.652+(-95.446)+(-51.668));
CongestionAvoidance (tcb, segmentsAcked);
