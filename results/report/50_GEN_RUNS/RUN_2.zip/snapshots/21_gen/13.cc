int QBvoLsqUfVDfLTMB = (int) (33.73*(13.623)*(-75.698)*(-15.072)*(85.861)*(67.045)*(30.909));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-42.953+(99.125)+(-68.514));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (62.35+(-69.411)+(30.931));
CongestionAvoidance (tcb, segmentsAcked);
