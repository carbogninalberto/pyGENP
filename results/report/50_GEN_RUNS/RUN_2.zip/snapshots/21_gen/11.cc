int QBvoLsqUfVDfLTMB = (int) (-76.397*(67.737)*(14.914)*(96.664)*(-66.711)*(-95.816)*(13.906));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-58.795+(-60.144)+(77.534));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (74.674+(59.646)+(-3.977));
CongestionAvoidance (tcb, segmentsAcked);
