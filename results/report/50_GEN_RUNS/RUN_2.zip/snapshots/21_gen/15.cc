float GUuLYJYywkyeYqPA = (float) (22.497+(-90.784)+(28.128));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

} else {
	tcb->m_cWnd = (int) (0.1/38.088);

}
segmentsAcked = (int) (-83.533+(-96.981)+(14.16)+(-53.426)+(-42.63)+(-42.615)+(-88.683));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-65.703+(82.638)+(55.686)+(31.564)+(72.851)+(70.03)+(-60.098));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-32.551*(-95.719)*(-72.648));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (39.07*(-25.483)*(29.964));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
segmentsAcked = (int) (-65.528+(40.07)+(-8.724)+(44.875)+(39.24)+(19.901)+(-64.123));
tcb->m_segmentSize = (int) (-75.522*(-15.828)*(15.419));
segmentsAcked = (int) (-83.313+(-7.322)+(56.348)+(94.027)+(40.235)+(69.322)+(-2.748));
tcb->m_segmentSize = (int) (-50.913*(-75.29)*(-98.249));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-73.151+(66.32)+(32.834)+(23.593)+(-18.704)+(-69.596)+(-18.658));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-28.271+(60.743)+(-39.111)+(-53.737)+(91.814)+(31.243)+(5.853));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
