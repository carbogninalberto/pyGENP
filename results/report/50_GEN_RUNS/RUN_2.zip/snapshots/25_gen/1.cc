segmentsAcked = SlowStart (tcb, segmentsAcked);
float xokusSqIGhzVySxT = (float) 18.681;
xokusSqIGhzVySxT = (float) (-59.333-(28.632)-(87.384)-(-10.395)-(11.402)-(2.446)-(2.085)-(57.914)-(-40.326));
