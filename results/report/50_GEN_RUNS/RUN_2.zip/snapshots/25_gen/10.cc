if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((((70.887*(58.074)*(44.565)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(61.974)*(18.345)*(21.298)*(tcb->m_cWnd)))+((4.53*(14.582)*(19.11)*(87.408)))+((22.59*(28.237)*(91.77)))+((25.361*(75.37)*(45.062)))+(27.476)+(0.1)+(78.348)+(0.1))/((0.1)));
	tcb->m_segmentSize = (int) (74.453-(90.287)-(tcb->m_segmentSize)-(48.545)-(43.327));
	tcb->m_segmentSize = (int) (51.107-(27.672)-(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (((70.826)+(77.235)+(0.1)+(0.1)+((tcb->m_ssThresh+(46.732)+(tcb->m_segmentSize)))+(33.843))/((73.286)+(0.1)));

}
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) ((((segmentsAcked-(7.777)-(73.679)-(89.418)-(36.896)))+(0.1)+(18.234)+(59.852))/((53.489)));
	tcb->m_segmentSize = (int) (79.975-(63.241)-(segmentsAcked)-(69.273)-(77.752)-(75.553)-(96.867));

} else {
	tcb->m_segmentSize = (int) (64.466+(19.489)+(85.272)+(52.51)+(74.621)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(63.253));
	segmentsAcked = (int) (10.574*(76.503)*(44.566)*(90.332)*(68.834)*(88.464)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(57.578));

}
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (17.963*(segmentsAcked)*(7.157));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)));
	segmentsAcked = (int) (7.749+(1.604)+(93.162)+(61.157)+(34.638)+(55.716)+(47.007)+(segmentsAcked));

}
tcb->m_segmentSize = (int) (34.209/16.133);
segmentsAcked = SlowStart (tcb, segmentsAcked);
