tcb->m_cWnd = (int) (0.1/0.1);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (((10.247)+((1.316+(39.465)+(12.613)+(58.595)))+(0.1)+(83.291)+(61.942)+(19.618)+(31.087)+(84.629))/((41.07)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (69.906-(81.243)-(41.451)-(85.035)-(0.666)-(16.062)-(20.568)-(3.392)-(48.784));
