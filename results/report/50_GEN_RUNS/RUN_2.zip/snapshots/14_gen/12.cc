if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (91.558-(12.749)-(tcb->m_cWnd)-(31.718)-(73.08)-(32.026)-(18.763)-(51.738));

} else {
	tcb->m_cWnd = (int) (71.871+(54.291)+(tcb->m_ssThresh)+(32.794)+(tcb->m_ssThresh)+(5.19)+(29.201)+(tcb->m_segmentSize)+(97.39));

}
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	segmentsAcked = (int) (18.043+(60.047));
	tcb->m_segmentSize = (int) (15.667-(89.719)-(99.789)-(tcb->m_cWnd)-(88.798)-(19.482));

} else {
	segmentsAcked = (int) (43.747/17.182);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) ((24.674*(34.459)*(segmentsAcked))/0.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
