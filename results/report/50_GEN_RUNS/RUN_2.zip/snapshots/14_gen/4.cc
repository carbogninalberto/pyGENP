float GUuLYJYywkyeYqPA = (float) (-44.12+(-58.536)+(87.335));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
segmentsAcked = (int) (57.516+(-24.592)+(48.855)+(-55.533)+(-66.076)+(71.255)+(10.088));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-7.864+(-22.174)+(-32.598)+(-61.907)+(-18.071)+(-78.87)+(12.136));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (23.051*(-97.059)*(-17.488));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (4.943*(-59.051)*(35.052));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-76.151+(91.764)+(15.254)+(32.865)+(2.764)+(34.843)+(78.85));
tcb->m_segmentSize = (int) (-68.157*(79.33)*(-0.826));
tcb->m_segmentSize = (int) (11.008*(13.518)*(99.401));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
segmentsAcked = (int) (57.518+(-11.235)+(39.071)+(-60.053)+(-44.233)+(-23.969)+(34.98));
tcb->m_segmentSize = (int) (30.624*(92.093)*(-62.546));
tcb->m_segmentSize = (int) (27.034*(-69.249)*(-63.286));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-29.233+(78.4)+(65.435)+(-97.806)+(78.365)+(89.875)+(5.544));
segmentsAcked = (int) (-85.161+(25.989)+(-18.431)+(43.57)+(-59.282)+(-42.642)+(-65.567));
tcb->m_segmentSize = (int) (77.518*(68.953)*(-43.819));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-27.201+(58.333)+(68.075)+(-8.361)+(-62.764)+(-67.675)+(78.498));
segmentsAcked = (int) (26.987+(-80.979)+(-88.13)+(-68.948)+(56.168)+(55.882)+(-9.709));
tcb->m_segmentSize = (int) (-51.524*(-91.53)*(-11.429));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-13.327+(18.252)+(-62.345)+(91.581)+(41.908)+(-62.989)+(-43.94));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-82.099+(-46.079)+(40.915)+(-15.124)+(-92.853)+(79.146)+(-48.987));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
