tcb->m_cWnd = (int) (19.241+(21.735)+(56.214)+(30.591)+(segmentsAcked));
tcb->m_ssThresh = (int) (88.707*(78.144)*(72.731)*(tcb->m_ssThresh)*(5.929)*(66.621)*(9.089));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	segmentsAcked = (int) (51.583*(18.163)*(tcb->m_segmentSize)*(66.363));
	tcb->m_segmentSize = (int) (30.304-(79.546)-(47.661)-(39.294)-(tcb->m_segmentSize)-(86.861)-(tcb->m_segmentSize)-(83.888));

} else {
	segmentsAcked = (int) (65.279+(60.259)+(51.066)+(16.664)+(83.997)+(32.944)+(tcb->m_segmentSize)+(58.585)+(67.11));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (segmentsAcked*(19.51)*(62.404)*(62.86)*(14.199)*(93.949));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (9.662*(77.041));

} else {
	tcb->m_segmentSize = (int) (39.367+(tcb->m_ssThresh)+(74.069)+(28.96)+(73.722)+(37.68));

}
