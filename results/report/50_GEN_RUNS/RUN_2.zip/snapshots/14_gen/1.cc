float CqUkXibiyepicfYT = (float) (((-22.685)+(21.243)+(6.32)+(-9.776))/((32.146)+(9.034)+(-45.422)+(-81.376)));
int IhEqyWUOYNlepCya = (int) 91.962;
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
