tcb->m_ssThresh = (int) (19.391-(81.783)-(24.063)-(24.995)-(46.314)-(22.854));
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(63.899)*(tcb->m_cWnd)*(tcb->m_cWnd)*(70.029)*(15.898)*(tcb->m_ssThresh)*(7.113)*(31.202));

} else {
	tcb->m_ssThresh = (int) (83.408-(15.737)-(tcb->m_segmentSize)-(28.071)-(80.427)-(tcb->m_segmentSize)-(segmentsAcked)-(22.35)-(90.886));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (27.506+(17.837)+(54.242));

}
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (12.544-(segmentsAcked)-(1.302)-(48.035)-(66.451)-(tcb->m_segmentSize)-(94.221)-(77.54)-(16.808));

} else {
	tcb->m_cWnd = (int) (97.446+(56.239)+(99.237)+(tcb->m_segmentSize)+(segmentsAcked)+(61.606)+(50.296)+(82.208)+(30.173));
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_ssThresh = (int) (99.236-(44.924)-(tcb->m_ssThresh)-(70.377)-(64.504)-(31.233));
	segmentsAcked = (int) (55.179*(18.945)*(28.366)*(69.845));

} else {
	tcb->m_ssThresh = (int) (21.149+(59.735)+(43.624)+(tcb->m_cWnd)+(67.07)+(38.62));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (((83.406)+(49.554)+((segmentsAcked+(65.903)+(29.863)))+(77.323))/((28.736)+(39.862)+(0.1)+(85.364)));

}
tcb->m_segmentSize = (int) (tcb->m_cWnd*(12.17)*(98.136)*(87.967)*(33.054)*(39.096)*(segmentsAcked)*(41.462)*(54.737));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (65.692*(71.506)*(segmentsAcked)*(34.874)*(3.087)*(65.96)*(67.938)*(70.589));
	tcb->m_ssThresh = (int) (0.1/84.721);

} else {
	tcb->m_ssThresh = (int) (24.573/(tcb->m_cWnd*(56.791)*(95.758)*(tcb->m_segmentSize)*(16.888)*(94.146)));
	tcb->m_segmentSize = (int) (24.63-(84.824));

}
ReduceCwnd (tcb);
