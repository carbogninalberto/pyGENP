ReduceCwnd (tcb);
float YdJHYieonaGaDybd = (float) (((36.144)+(0.1)+((31.706+(40.165)))+(0.1)+(46.461))/((76.129)));
CongestionAvoidance (tcb, segmentsAcked);
if (YdJHYieonaGaDybd > YdJHYieonaGaDybd) {
	tcb->m_segmentSize = (int) (80.112+(45.375)+(33.946));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (41.185-(3.413)-(54.863)-(51.747)-(38.712)-(20.027)-(12.004));

}
float FeYlrlTciTcMCZmt = (float) (50.897-(tcb->m_segmentSize));
if (FeYlrlTciTcMCZmt < FeYlrlTciTcMCZmt) {
	tcb->m_ssThresh = (int) (20.342*(50.701)*(50.363)*(80.75)*(FeYlrlTciTcMCZmt)*(22.005)*(25.795));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (40.714*(25.324)*(16.829)*(48.107)*(YdJHYieonaGaDybd)*(16.386)*(73.353));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(65.405)+(58.757)+(18.529)+(38.884)+(15.606)+(61.835));
	tcb->m_segmentSize = (int) ((((3.882-(FeYlrlTciTcMCZmt)-(58.61)-(77.958)-(tcb->m_ssThresh)-(56.186)-(FeYlrlTciTcMCZmt)-(12.077)-(85.55)))+((57.496-(45.526)-(tcb->m_ssThresh)-(4.902)-(18.373)-(14.559)))+(51.251)+((20.078*(46.674)*(12.195)*(segmentsAcked)*(51.897)*(76.907)*(60.278)*(FeYlrlTciTcMCZmt)*(82.867)))+(0.1))/((0.1)+(40.086)+(0.1)));

}
