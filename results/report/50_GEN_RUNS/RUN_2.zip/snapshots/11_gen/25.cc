CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (2.735+(80.384)+(1.287)+(30.155)+(66.863)+(76.842)+(32.869)+(tcb->m_segmentSize)+(segmentsAcked));
	segmentsAcked = (int) (29.551-(29.177)-(97.604)-(8.204));
	tcb->m_ssThresh = (int) (4.982+(80.471)+(21.265)+(91.932)+(18.085)+(59.744));

} else {
	tcb->m_cWnd = (int) (15.427*(58.36)*(43.896)*(6.037)*(72.057));
	tcb->m_segmentSize = (int) (18.676+(25.867)+(segmentsAcked)+(52.398)+(62.973)+(58.285));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (16.547-(22.683)-(98.953)-(7.16)-(tcb->m_cWnd)-(45.707)-(48.656)-(59.1)-(48.222));
int zUsKOTcaJEvtslFC = (int) (87.204+(segmentsAcked)+(10.517)+(13.23)+(60.826)+(30.321)+(tcb->m_cWnd)+(73.975));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
