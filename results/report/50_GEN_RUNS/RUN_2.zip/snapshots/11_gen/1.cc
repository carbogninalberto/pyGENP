segmentsAcked = (int) (96.96*(-35.489));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-16.412)*(63.0));

}
segmentsAcked = (int) (67.313+(-10.261)+(-12.303)+(-89.532)+(29.196)+(-23.447)+(66.611));
segmentsAcked = (int) (22.594+(-19.686)+(85.388)+(-88.403)+(76.804)+(56.883)+(0.966));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (2.512*(-99.897)*(-2.483));
tcb->m_segmentSize = (int) (-95.876*(47.076)*(-50.388));
