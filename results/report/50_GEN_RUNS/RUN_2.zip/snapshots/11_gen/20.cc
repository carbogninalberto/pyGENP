float LorpGLXNXvLsnSKb = (float) (segmentsAcked-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(49.465)-(45.124));
tcb->m_ssThresh = (int) (4.393+(77.215)+(55.164)+(8.246));
LorpGLXNXvLsnSKb = (float) (segmentsAcked*(94.731)*(42.538)*(2.339)*(65.999));
tcb->m_cWnd = (int) (0.1/93.519);
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (86.688*(segmentsAcked)*(10.942)*(3.806)*(54.896));

} else {
	segmentsAcked = (int) (95.629*(tcb->m_cWnd)*(2.758)*(12.566)*(tcb->m_segmentSize)*(47.125));

}
