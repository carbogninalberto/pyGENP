float GUuLYJYywkyeYqPA = (float) (-42.947+(-38.409)+(25.765));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
segmentsAcked = (int) (-36.402+(0.799)+(-38.146)+(15.102)+(-75.272)+(-44.971)+(-57.741));
segmentsAcked = (int) (-40.758+(37.334)+(-4.066)+(80.643)+(72.526)+(-5.271)+(-1.741));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (-44.404*(-23.802)*(83.607));
tcb->m_segmentSize = (int) (75.887*(-68.015)*(83.722));
segmentsAcked = (int) (-51.915+(39.711)+(-16.107)+(-87.629)+(-20.081)+(3.474)+(16.8));
segmentsAcked = (int) (-40.387+(-45.494)+(87.075)+(-97.189)+(49.419)+(-92.354)+(46.591));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
