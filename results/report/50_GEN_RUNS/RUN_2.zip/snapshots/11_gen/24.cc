segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(82.272)+(tcb->m_cWnd)+(61.306)+(74.563)+(tcb->m_cWnd)+(98.455));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (47.955-(55.035)-(97.244)-(tcb->m_ssThresh)-(19.737));
segmentsAcked = (int) (tcb->m_segmentSize*(8.666)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(tcb->m_cWnd));
segmentsAcked = SlowStart (tcb, segmentsAcked);
