segmentsAcked = (int) (-43.636*(-1.696));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-16.412)*(63.0));

}
segmentsAcked = (int) (-99.758+(-24.606)+(88.655)+(-75.355)+(66.35)+(74.883)+(11.649));
segmentsAcked = (int) (-55.61+(89.819)+(-44.051)+(-28.658)+(-64.06)+(36.43)+(15.322));
segmentsAcked = (int) (-4.192+(21.365)+(-8.913)+(-88.978)+(-20.704)+(42.927)+(-94.311));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (70.316*(-55.433)*(-42.359));
tcb->m_segmentSize = (int) (80.516*(87.497)*(58.774));
tcb->m_segmentSize = (int) (-16.689*(92.982)*(46.994));
tcb->m_segmentSize = (int) (70.451*(40.005)*(16.295));
