float xwaBQPnWyDXlfmrM = (float) (-62.275*(-69.178)*(28.426)*(-64.046)*(-71.91)*(1.959));
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (42.239*(59.68)*(81.999)*(12.344)*(segmentsAcked)*(tcb->m_cWnd)*(63.028)*(81.112)*(66.601));
	segmentsAcked = (int) (91.219/36.719);
	tcb->m_segmentSize = (int) (29.212+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (50.491/48.844);
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (32.899+(95.981)+(80.988)+(20.424)+(80.976)+(37.659)+(33.251));

}
tcb->m_segmentSize = (int) (-14.66*(14.571)*(-90.615)*(-94.113)*(-5.294)*(-40.767)*(-16.713));
