float jABSgBEdUyackNip = (float) (26.185+(95.908)+(2.196)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(38.979));
float BqeCEwuUXoQfsvMl = (float) (7.661+(29.853)+(66.175)+(51.589)+(0.859)+(67.102));
tcb->m_ssThresh = (int) ((tcb->m_ssThresh*(75.819)*(jABSgBEdUyackNip)*(jABSgBEdUyackNip)*(17.998)*(10.077)*(segmentsAcked)*(77.33))/41.052);
segmentsAcked = (int) (((56.693)+(99.336)+(17.658)+(52.411))/((0.1)+(0.1)+(0.1)+(0.1)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float QIfuQRzHBUJzxhNJ = (float) (BqeCEwuUXoQfsvMl*(59.285)*(1.598)*(74.579)*(96.248)*(segmentsAcked)*(63.376)*(27.859));
tcb->m_ssThresh = (int) (73.459+(38.035));
int YCcOXLDOMcdJnfXT = (int) (jABSgBEdUyackNip*(19.785)*(tcb->m_cWnd));
