float eVqjWgreckEjtFCe = (float) (35.649+(74.068)+(75.26)+(42.702)+(-54.027)+(-1.816)+(-87.175));
int xjZMlckjuxxxFYaK = (int) ((((55.513+(-65.924)+(41.679)+(-25.529)+(9.137)+(-49.263)+(-24.299)+(-36.789)))+(85.16)+(-28.414)+(-41.551)+(-75.707)+((-51.768*(-19.946)*(-32.333)*(19.254)*(3.259)))+(-58.794))/((-47.238)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (eVqjWgreckEjtFCe >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (39.871-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(2.978)-(37.61));

} else {
	tcb->m_cWnd = (int) (54.961*(93.571));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-65.276+(-42.47)+(48.572)+(31.721));
