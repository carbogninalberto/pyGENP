segmentsAcked = (int) (-5.81+(15.748)+(2.25));
