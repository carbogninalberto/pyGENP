segmentsAcked = (int) (-30.165*(-88.353));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-16.412)*(63.0));

} else {
	tcb->m_cWnd = (int) (0.1/38.088);

}
segmentsAcked = (int) (96.496+(64.855)+(-38.765)+(-67.164)+(67.449)+(-96.779)+(90.696));
segmentsAcked = (int) (24.559+(-86.089)+(-49.139)+(41.18)+(30.67)+(41.611)+(12.653));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-77.526*(47.174)*(-42.803));
tcb->m_segmentSize = (int) (-88.388*(-75.188)*(-36.594));
