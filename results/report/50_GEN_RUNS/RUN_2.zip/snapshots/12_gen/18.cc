segmentsAcked = SlowStart (tcb, segmentsAcked);
float KIuzzqyFpwFTAQON = (float) (tcb->m_segmentSize+(97.434)+(88.241)+(33.188)+(65.349)+(73.236)+(7.381));
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (64.523*(29.058)*(3.578)*(20.374)*(4.192));
	tcb->m_ssThresh = (int) (0.1/41.202);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(22.152));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (80.634*(85.344)*(5.127)*(KIuzzqyFpwFTAQON)*(8.704)*(30.661)*(KIuzzqyFpwFTAQON));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked+(15.182)+(89.245)+(96.361)+(75.065)+(tcb->m_segmentSize)+(97.226)+(20.475)+(13.359));
	tcb->m_ssThresh = (int) (19.125*(58.321)*(tcb->m_ssThresh)*(87.219)*(tcb->m_ssThresh)*(77.564)*(tcb->m_segmentSize)*(89.567));
	KIuzzqyFpwFTAQON = (float) (54.502*(63.63)*(14.641)*(segmentsAcked)*(53.774)*(32.487));

}
tcb->m_cWnd = (int) (KIuzzqyFpwFTAQON*(94.731)*(16.766)*(6.593));
segmentsAcked = (int) (tcb->m_ssThresh-(47.498)-(19.564));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (42.908-(82.108)-(55.919));

} else {
	tcb->m_ssThresh = (int) (46.525*(10.823)*(71.55)*(47.795)*(14.093)*(tcb->m_segmentSize)*(3.215)*(35.966));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(15.349)+(73.233)+(93.588)+(94.154)+(62.544));

}
tcb->m_segmentSize = (int) (28.677-(17.971)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(89.108));
ReduceCwnd (tcb);
