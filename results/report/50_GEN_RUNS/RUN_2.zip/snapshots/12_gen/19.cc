CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (segmentsAcked+(-0.063)+(67.058)+(18.311)+(13.828)+(20.13)+(tcb->m_cWnd)+(52.922));

} else {
	tcb->m_cWnd = (int) (12.551/0.1);
	tcb->m_segmentSize = (int) (54.166-(0.112)-(1.343)-(24.234)-(18.542)-(35.478)-(56.255));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (26.681+(71.47)+(85.883)+(81.484)+(48.174)+(31.684));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (82.382*(2.578)*(segmentsAcked)*(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (16.888+(75.066)+(26.683)+(96.363)+(58.55)+(92.363));

}
segmentsAcked = (int) (70.062+(53.671)+(27.104)+(36.77)+(tcb->m_ssThresh)+(53.87)+(tcb->m_ssThresh)+(44.952)+(41.532));
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(46.28)-(19.331));
	segmentsAcked = (int) (50.961-(68.729));

} else {
	tcb->m_segmentSize = (int) (10.435-(5.626)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(42.4)-(48.695)-(tcb->m_cWnd)-(5.91));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
