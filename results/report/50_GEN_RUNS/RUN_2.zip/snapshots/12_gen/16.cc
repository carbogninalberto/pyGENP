tcb->m_cWnd = (int) (27.574+(51.208)+(73.843)+(3.218)+(93.221)+(39.927)+(53.04)+(tcb->m_cWnd));
tcb->m_cWnd = (int) (tcb->m_segmentSize*(63.115)*(24.701)*(50.703)*(segmentsAcked)*(76.591)*(10.606)*(80.909)*(segmentsAcked));
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) ((32.394*(56.75)*(28.406)*(66.859)*(76.418)*(92.626)*(38.469))/78.352);
	segmentsAcked = (int) (59.176+(1.743)+(66.671)+(6.294)+(26.658));
	segmentsAcked = (int) (1.377-(97.058)-(95.421)-(30.35)-(78.424)-(80.863)-(7.098)-(44.794));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(62.141)-(6.685)-(57.256)-(tcb->m_cWnd)-(53.808));
	tcb->m_ssThresh = (int) (62.037*(tcb->m_ssThresh)*(26.71)*(84.497));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (((68.553)+(0.1)+(0.1)+(33.979)+(0.1)+((tcb->m_cWnd+(13.721)))+(19.289))/((0.1)+(0.1)));
ReduceCwnd (tcb);
