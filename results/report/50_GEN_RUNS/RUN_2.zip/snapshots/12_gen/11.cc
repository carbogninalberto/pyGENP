float EGJOzkPyrPuQxyvG = (float) (((-63.056)+(56.646)+((-11.362*(29.008)*(81.775)*(-1.662)*(8.025)*(-42.165)*(-69.176)*(-25.512)))+(94.107)+(96.312)+(-66.665))/((99.498)+(-11.732)+(-40.419)));
int kLrwmZAdJqoLmCvv = (int) (-95.113-(79.752)-(-94.996)-(58.572)-(82.73)-(-93.304)-(-13.407));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
