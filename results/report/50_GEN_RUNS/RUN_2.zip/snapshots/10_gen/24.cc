tcb->m_cWnd = (int) (89.189-(12.969)-(13.505)-(40.731)-(9.571)-(63.201)-(61.64)-(64.324));
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_segmentSize = (int) (82.756+(tcb->m_segmentSize)+(17.462)+(94.619));
	tcb->m_cWnd = (int) (35.722/0.1);
	segmentsAcked = (int) (segmentsAcked*(26.327));

} else {
	tcb->m_segmentSize = (int) (57.467+(tcb->m_segmentSize)+(22.813)+(11.534)+(78.535)+(6.659));

}
tcb->m_cWnd = (int) (25.378+(tcb->m_cWnd)+(18.386)+(23.754)+(8.773)+(59.127));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (44.685+(51.852)+(segmentsAcked)+(51.989)+(11.763)+(segmentsAcked));
segmentsAcked = (int) (23.246/0.1);
