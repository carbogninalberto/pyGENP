TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (10.147-(24.925)-(38.887)-(66.586)-(52.216)-(62.245)-(tcb->m_segmentSize)-(2.399)-(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (8.386-(19.253)-(segmentsAcked)-(65.012)-(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (39.704*(54.416)*(11.666)*(93.763)*(0.954)*(6.525)*(11.208)*(tcb->m_cWnd));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int dbgNDGKpUxaOtQLw = (int) (49.402-(83.688)-(54.456)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(63.34)-(25.424));
int PQrmoplcFMxYKatm = (int) (99.219-(45.353)-(45.558)-(8.825)-(83.068));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
