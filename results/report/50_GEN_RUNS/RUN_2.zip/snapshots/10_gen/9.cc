int aUXRdSRXFConfDwE = (int) (((-48.594)+(23.103)+((36.685-(30.046)-(-97.719)-(48.472)))+(14.768)+(-76.342)+(-58.028)+(21.252)+(31.714))/((66.437)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float hnMSXifgTFrrlKMD = (float) (-34.327*(-45.448)*(-26.89)*(74.952)*(-82.007)*(-92.648)*(-92.861)*(-22.756)*(17.727));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float zQeFYWkatTMPpJPa = (float) (27.582-(-54.874)-(56.41)-(-92.041)-(-15.306)-(-71.839)-(-38.603)-(-64.774)-(68.273));
float tGdabasbgPEpnymR = (float) (-92.261+(31.489)+(14.546));
if (zQeFYWkatTMPpJPa < tcb->m_segmentSize) {
	zQeFYWkatTMPpJPa = (float) (23.909-(tcb->m_segmentSize)-(96.939)-(12.948)-(60.335));
	tGdabasbgPEpnymR = (float) ((45.076*(segmentsAcked)*(58.906)*(52.351))/45.696);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	zQeFYWkatTMPpJPa = (float) (57.443-(71.544)-(52.333)-(73.542)-(8.394)-(44.577)-(87.392)-(51.421)-(43.601));

}
zQeFYWkatTMPpJPa = (float) (29.996+(79.022)+(-23.582)+(-59.196)+(47.41)+(37.789)+(86.869));
zQeFYWkatTMPpJPa = (float) (39.247+(-74.291)+(59.898)+(93.275)+(83.696)+(98.685)+(60.344));
