segmentsAcked = (int) (86.337*(-16.533));
tcb->m_segmentSize = (int) (97.532*(-20.935)*(-72.022));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-16.412)*(63.0));

} else {
	tcb->m_cWnd = (int) (0.1/38.088);

}
segmentsAcked = (int) (-10.483+(7.541)+(-7.695)+(-83.689)+(-35.63)+(-92.258)+(32.3));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (44.432*(-12.936)*(-45.311));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-41.316*(46.428)*(81.894));
