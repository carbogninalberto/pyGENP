CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (tcb->m_cWnd+(78.054)+(61.665)+(tcb->m_ssThresh)+(73.968)+(35.23)+(tcb->m_ssThresh)+(67.728));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(48.258)-(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(tcb->m_segmentSize)+(73.308)+(37.607)+(24.963)+(26.705)+(52.694));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked != segmentsAcked) {
	tcb->m_ssThresh = (int) (36.409+(58.811)+(40.196)+(63.409));
	tcb->m_ssThresh = (int) (1.291*(43.515)*(55.148)*(94.784)*(55.674)*(24.352)*(18.745)*(39.394)*(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(58.102)-(44.354));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
