int aUXRdSRXFConfDwE = (int) (((-82.64)+(-73.501)+((-97.137-(-10.36)-(63.515)-(51.872)))+(2.393)+(-0.524)+(-48.433)+(56.926)+(49.269))/((65.552)));
float hnMSXifgTFrrlKMD = (float) (-7.654*(81.69)*(18.149)*(-92.274)*(99.255)*(-46.326)*(7.973)*(-36.325)*(53.737));
float zQeFYWkatTMPpJPa = (float) (77.766-(33.256)-(65.505)-(-5.198)-(-54.753)-(67.701)-(46.022)-(-7.267)-(77.369));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float tGdabasbgPEpnymR = (float) (-56.118+(49.539)+(49.524));
if (zQeFYWkatTMPpJPa < tcb->m_segmentSize) {
	zQeFYWkatTMPpJPa = (float) (57.443-(71.544)-(52.333)-(73.542)-(8.394)-(44.577)-(87.392)-(51.421)-(43.601));

} else {
	zQeFYWkatTMPpJPa = (float) (23.909-(tcb->m_segmentSize)-(96.939)-(12.948)-(60.335));
	tGdabasbgPEpnymR = (float) ((45.076*(segmentsAcked)*(58.906)*(52.351))/45.696);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
zQeFYWkatTMPpJPa = (float) (-15.491+(-50.086)+(48.333)+(25.031)+(-3.9)+(85.359)+(57.379));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (zQeFYWkatTMPpJPa < tcb->m_segmentSize) {
	zQeFYWkatTMPpJPa = (float) (23.909-(tcb->m_segmentSize)-(96.939)-(12.948)-(60.335));
	tGdabasbgPEpnymR = (float) ((45.076*(segmentsAcked)*(58.906)*(52.351))/45.696);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	zQeFYWkatTMPpJPa = (float) (57.443-(71.544)-(52.333)-(73.542)-(8.394)-(44.577)-(87.392)-(51.421)-(43.601));

}
zQeFYWkatTMPpJPa = (float) (-5.307+(-45.086)+(15.7)+(-26.606)+(-17.443)+(-58.168)+(-54.948));
