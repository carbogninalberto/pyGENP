float eDFjtuGIZZnUlgSk = (float) (((86.487)+((59.865+(50.388)))+(0.1)+(0.1))/((17.891)+(0.1)+(0.1)+(3.367)));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	eDFjtuGIZZnUlgSk = (float) (eDFjtuGIZZnUlgSk+(segmentsAcked)+(36.502)+(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (35.349-(segmentsAcked)-(42.928)-(35.533)-(tcb->m_cWnd));

} else {
	eDFjtuGIZZnUlgSk = (float) (89.913*(38.88)*(tcb->m_ssThresh)*(15.951)*(99.071)*(segmentsAcked)*(94.61)*(63.478)*(88.723));
	tcb->m_cWnd = (int) (((81.259)+(36.793)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)));
	tcb->m_cWnd = (int) (44.839-(41.991)-(24.702)-(79.152)-(tcb->m_ssThresh)-(77.897)-(tcb->m_cWnd)-(tcb->m_cWnd));

}
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (31.748/94.458);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(88.561)+(0.1)+((23.109-(79.155)-(67.214)-(90.38)))+(30.125)+(74.422)+(0.1))/((0.1)));
	tcb->m_ssThresh = (int) (50.157+(49.869)+(79.14)+(25.642)+(62.761));
	CongestionAvoidance (tcb, segmentsAcked);

}
float xqWheCCKBKDNueoV = (float) (((32.005)+(94.221)+((33.924-(14.305)-(14.654)-(48.953)))+(0.1))/((83.663)+(0.1)+(0.1)+(52.511)));
int WqmNyvlzXslXuahF = (int) ((((4.707+(23.248)+(35.956)))+(99.841)+((96.431+(67.783)+(4.459)+(73.188)+(26.863)))+((24.695*(7.978)*(72.901)*(67.019)*(13.724)*(42.213)))+(0.1)+(0.1)+(24.706))/((0.1)));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (79.833-(93.154)-(6.399)-(tcb->m_segmentSize)-(78.425)-(90.855)-(54.023)-(14.84));
	tcb->m_ssThresh = (int) (62.692*(73.794)*(86.423));

} else {
	tcb->m_cWnd = (int) (((0.1)+((tcb->m_segmentSize+(eDFjtuGIZZnUlgSk)))+(0.1)+(0.1)+(36.632)+(71.695)+(0.1)+(0.1))/((0.1)));
	tcb->m_segmentSize = (int) (71.497*(95.15)*(WqmNyvlzXslXuahF)*(WqmNyvlzXslXuahF)*(20.282)*(52.817)*(xqWheCCKBKDNueoV));

}
WqmNyvlzXslXuahF = (int) (tcb->m_cWnd-(61.226)-(27.001)-(20.592));
