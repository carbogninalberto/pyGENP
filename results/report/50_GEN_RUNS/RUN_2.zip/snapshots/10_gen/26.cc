float CoHfpCvQgXAkBOyA = (float) (0.918+(6.133)+(tcb->m_ssThresh));
ReduceCwnd (tcb);
CoHfpCvQgXAkBOyA = (float) (0.1/37.595);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (96.945/0.1);
tcb->m_ssThresh = (int) ((46.26+(36.522)+(4.54)+(93.637)+(76.662)+(43.275)+(CoHfpCvQgXAkBOyA)+(59.404))/0.1);
int lBSBkfSZSEJPzFLn = (int) (83.973-(segmentsAcked));
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (63.496-(8.011)-(tcb->m_segmentSize)-(35.522)-(51.353)-(95.352)-(tcb->m_cWnd));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (49.131-(6.797)-(80.877));

} else {
	segmentsAcked = (int) (35.324-(67.565)-(tcb->m_ssThresh)-(68.892)-(tcb->m_ssThresh)-(45.805)-(42.656)-(64.367)-(76.18));
	segmentsAcked = (int) ((((tcb->m_ssThresh-(55.03)-(26.471)-(6.148)))+(59.745)+(29.458)+(0.1)+(0.1)+(0.1)+((48.423*(79.291)*(tcb->m_segmentSize)*(60.28)*(35.316)*(tcb->m_ssThresh)))+(63.171))/((84.066)));
	tcb->m_segmentSize = (int) (52.288+(95.605)+(28.144));

}
tcb->m_ssThresh = (int) (((20.401)+(0.1)+(0.1)+(57.475)+((79.287*(51.603)*(84.61)*(31.97)))+(0.1))/((92.343)));
