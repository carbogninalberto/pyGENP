if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (51.175+(45.82)+(65.639)+(43.358)+(11.765)+(11.29)+(75.788)+(69.72));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(62.417)+(tcb->m_segmentSize)+(segmentsAcked)+(3.282));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (30.01+(94.681));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (14.455+(0.049)+(54.692)+(26.915)+(53.665)+(14.707));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (36.551-(8.682)-(90.98)-(24.913)-(92.668)-(14.474)-(segmentsAcked));
