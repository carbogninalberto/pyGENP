segmentsAcked = (int) (3.393*(14.692));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-16.412)*(63.0));

} else {
	tcb->m_cWnd = (int) (0.1/38.088);

}
segmentsAcked = (int) (33.909+(51.186)+(1.14)+(5.178)+(99.729)+(-82.064)+(48.33));
segmentsAcked = (int) (-28.083+(-67.545)+(3.692)+(5.713)+(40.148)+(-50.449)+(36.657));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-93.858*(3.179)*(6.486));
tcb->m_segmentSize = (int) (-89.647*(-53.335)*(-4.845));
