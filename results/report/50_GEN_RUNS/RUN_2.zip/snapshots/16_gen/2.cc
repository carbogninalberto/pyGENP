if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) ((90.359-(segmentsAcked)-(tcb->m_cWnd)-(94.753))/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (10.594*(-81.858)*(67.556)*(92.429)*(6.304)*(-31.873)*(46.149)*(-6.2)*(49.88));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) ((-40.891+(tcb->m_cWnd)+(-69.126))/-83.528);
