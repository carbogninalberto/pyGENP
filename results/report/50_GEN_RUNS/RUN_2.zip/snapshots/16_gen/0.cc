int QBvoLsqUfVDfLTMB = (int) (85.259*(-77.731)*(51.91)*(-48.622)*(-63.646)*(46.905)*(-80.898));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-23.674+(19.626)+(-63.655));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-46.573+(96.899)+(-29.522));
CongestionAvoidance (tcb, segmentsAcked);
