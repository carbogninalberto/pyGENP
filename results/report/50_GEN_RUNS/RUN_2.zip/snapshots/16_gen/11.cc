int AEpAIZhVFIEobSkW = (int) (84.272*(-25.721)*(19.185)*(-32.023)*(63.552)*(98.009));
ReduceCwnd (tcb);
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (77.024+(73.377));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(79.113));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-57.015*(18.739)*(2.283)*(51.158));
