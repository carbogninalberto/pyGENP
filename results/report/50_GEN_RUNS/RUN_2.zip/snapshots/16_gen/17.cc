int QBvoLsqUfVDfLTMB = (int) (35.783*(-80.845)*(-73.61)*(45.279)*(-78.302)*(-51.205)*(50.73));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-95.965+(-76.761)+(-53.79));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (96.101+(-54.193)+(81.646));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
