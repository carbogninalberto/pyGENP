ReduceCwnd (tcb);
float ztdSIOIOVbLgAJLZ = (float) (58.083-(86.811)-(26.172)-(3.1)-(78.424)-(60.61)-(-40.723)-(-6.949)-(-45.93));
tcb->m_cWnd = (int) (-6.177+(99.833)+(-9.709));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-96.285/-75.736);
CongestionAvoidance (tcb, segmentsAcked);
