ReduceCwnd (tcb);
int QBvoLsqUfVDfLTMB = (int) (-89.509*(-82.866)*(-58.144)*(-80.91)*(-68.798)*(-21.519)*(78.844));
tcb->m_cWnd = (int) (63.051+(-94.131)+(-21.555));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-50.516+(87.661)+(7.829));
CongestionAvoidance (tcb, segmentsAcked);
