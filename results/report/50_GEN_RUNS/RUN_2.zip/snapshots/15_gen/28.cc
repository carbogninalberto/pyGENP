tcb->m_ssThresh = (int) (90.179*(72.614)*(75.992)*(43.575));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((64.823)+(28.332)+(0.1)+(70.202))/((0.1)+(14.836)+(0.1)+(40.539)+(0.1)));
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(21.777));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_cWnd*(65.695)*(tcb->m_ssThresh)*(segmentsAcked)*(96.651)*(8.438)*(47.199));

} else {
	segmentsAcked = (int) (66.941+(0.738)+(84.634)+(20.914)+(36.873)+(72.837)+(87.317)+(68.46)+(tcb->m_ssThresh));

}
