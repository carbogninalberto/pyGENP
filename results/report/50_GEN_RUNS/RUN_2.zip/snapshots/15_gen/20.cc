segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(93.142)*(20.555)*(33.497)*(85.668));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (44.812*(40.54)*(31.875));

}
tcb->m_cWnd = (int) (73.314+(8.411)+(62.203)+(81.783)+(76.637)+(23.098));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(tcb->m_segmentSize)-(84.939)-(60.387)-(38.456)-(76.924)-(28.09)-(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (12.649*(88.139)*(74.683)*(64.997)*(tcb->m_cWnd)*(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (43.266-(segmentsAcked)-(tcb->m_segmentSize)-(5.002)-(17.912)-(77.567));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (((26.923)+(18.178)+(0.1)+(40.109)+(0.1))/((0.1)+(22.301)+(55.246)));

}
tcb->m_cWnd = (int) (tcb->m_cWnd+(44.985)+(40.857));
tcb->m_cWnd = (int) (51.745-(44.959)-(8.336)-(55.432)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(99.325)-(2.772));
ReduceCwnd (tcb);
