CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(79.113));

} else {
	tcb->m_cWnd = (int) (77.024+(73.377));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
int AEpAIZhVFIEobSkW = (int) (34.277*(19.861)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(66.289)*(77.763));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (18.779*(68.086)*(40.007)*(59.661));
