if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((0.1)+((65.896*(tcb->m_ssThresh)*(8.968)))+(12.852)+(34.83))/((45.858)));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (20.859-(79.469)-(95.048)-(tcb->m_segmentSize)-(29.137));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (14.416/0.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((44.083)+(0.1)+(56.142)+(99.081)+(36.082)+(68.86))/((52.48)));
segmentsAcked = (int) (segmentsAcked-(99.458)-(tcb->m_segmentSize)-(96.622)-(39.668)-(24.796));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (50.587+(93.141)+(50.437));
tcb->m_ssThresh = (int) (80.926/0.1);
