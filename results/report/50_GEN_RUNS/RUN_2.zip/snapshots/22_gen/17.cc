if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
float GUuLYJYywkyeYqPA = (float) (86.326+(-40.146)+(-7.943));
segmentsAcked = (int) (10.959+(98.978)+(-44.334)+(-86.353)+(40.71)+(37.696)+(-14.188));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-50.306+(-1.129)+(-95.913)+(29.284)+(-74.643)+(19.009)+(-63.534));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (81.948+(-6.824)+(35.222)+(-17.175)+(44.392)+(14.952)+(-40.393));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (52.965*(-9.134)*(62.075));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (69.126*(5.603)*(-97.02));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (59.254*(-36.771)*(0.307));
segmentsAcked = (int) (77.997+(-84.934)+(-55.061)+(28.933)+(39.904)+(88.958)+(65.895));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (78.12*(-22.796)*(70.222));
tcb->m_segmentSize = (int) (37.912*(-26.444)*(65.628));
segmentsAcked = (int) (-35.995+(-48.387)+(-66.344)+(18.37)+(90.066)+(-96.746)+(35.702));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (-61.474*(-17.802)*(-54.271));
segmentsAcked = (int) (-88.023+(74.351)+(97.818)+(-54.64)+(96.472)+(45.324)+(-5.357));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-51.831*(-69.706)*(53.633));
segmentsAcked = (int) (68.277+(95.695)+(3.731)+(92.146)+(-65.446)+(93.421)+(-8.426));
segmentsAcked = (int) (1.35+(-81.236)+(42.862)+(-16.737)+(-23.26)+(-75.642)+(53.248));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (41.534*(58.149)*(77.881));
segmentsAcked = (int) (60.19+(-1.718)+(-49.475)+(-90.741)+(54.382)+(-51.768)+(-40.126));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-0.298+(94.902)+(20.097)+(-63.759)+(-46.435)+(-23.747)+(87.341));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-51.058+(-40.628)+(-63.734)+(-48.707)+(-43.104)+(97.177)+(65.282));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
