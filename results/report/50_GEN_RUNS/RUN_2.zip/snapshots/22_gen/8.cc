ReduceCwnd (tcb);
int QBvoLsqUfVDfLTMB = (int) (47.418*(82.302)*(37.899)*(-76.76)*(-13.069)*(2.568)*(-42.143));
tcb->m_cWnd = (int) (74.005+(-13.564)+(-24.631));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-31.084+(-63.379)+(-52.399));
CongestionAvoidance (tcb, segmentsAcked);
