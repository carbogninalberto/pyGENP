CongestionAvoidance (tcb, segmentsAcked);
int QBvoLsqUfVDfLTMB = (int) (73.647*(-33.808)*(-53.272)*(-23.544)*(92.555)*(-82.246)*(97.018));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-76.157+(-40.989)+(80.97));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (32.38+(11.375)+(-20.069));
CongestionAvoidance (tcb, segmentsAcked);
