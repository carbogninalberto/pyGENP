int QBvoLsqUfVDfLTMB = (int) (92.703*(45.186)*(-68.211)*(87.144)*(-17.97)*(-10.981)*(54.881));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-73.085+(-11.944)+(85.613));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (45.26+(4.008)+(-81.775));
CongestionAvoidance (tcb, segmentsAcked);
