if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

} else {
	tcb->m_cWnd = (int) (0.1/38.088);

}
float GUuLYJYywkyeYqPA = (float) (78.403+(-0.926)+(-95.758));
segmentsAcked = (int) (-87.197+(-39.932)+(78.317)+(-48.431)+(19.095)+(-95.306)+(-47.826));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(-19.565)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-44.349+(-87.06)+(-90.664)+(-30.007)+(66.246)+(78.611)+(32.611));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (92.609+(-32.733)+(-49.654)+(42.829)+(-53.6)+(26.632)+(-80.938));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (8.714*(89.604)*(-22.578));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (34.649*(-45.25)*(76.093));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (-28.725*(69.899)*(67.447));
segmentsAcked = (int) (32.917+(-98.069)+(22.923)+(9.13)+(-36.622)+(91.058)+(74.141));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (-16.38*(75.93)*(65.971));
tcb->m_segmentSize = (int) (18.866*(84.928)*(-95.952));
segmentsAcked = (int) (-76.28+(-17.249)+(93.904)+(23.102)+(11.237)+(5.116)+(-38.482));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/38.088);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(50.106)*(34.248)*(62.343)*(tcb->m_segmentSize)*(64.603)*(63.0));

}
tcb->m_segmentSize = (int) (94.271*(25.281)*(15.7));
segmentsAcked = (int) (3.499+(14.034)+(-39.879)+(76.777)+(50.249)+(-90.299)+(33.731));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (61.84*(-63.68)*(-27.439));
segmentsAcked = (int) (-13.742+(-12.97)+(-97.756)+(-18.135)+(68.015)+(-75.884)+(21.202));
segmentsAcked = (int) (-45.837+(71.854)+(-18.621)+(64.519)+(67.447)+(-73.902)+(-4.404));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (28.331*(2.535)*(7.799));
segmentsAcked = (int) (-22.972+(61.292)+(-94.833)+(44.107)+(-83.035)+(69.384)+(-5.316));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-92.403+(-24.753)+(-49.215)+(40.012)+(-49.066)+(73.846)+(-63.627));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (83.797+(-65.055)+(43.337)+(-14.472)+(28.989)+(60.249)+(-29.716));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
