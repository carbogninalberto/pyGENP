float MIyIxVehkQfwPLwJ = (float) (-96.107+(-30.213)+(-15.965)+(-54.019)+(30.459)+(-8.409)+(-82.033));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-35.886*(-77.406)*(0.903)*(35.187)*(31.89)*(27.813)*(94.5)*(5.611));
