float jdWrqHgGwsPAFtgG = (float) (-14.862-(4.699)-(-20.963)-(35.441)-(61.633)-(61.838));
