float WtFwNkqFPOaHCsxT = (float) (-1.648-(79.466)-(55.795));
WtFwNkqFPOaHCsxT = (float) (((-78.837)+(81.433)+((-13.084-(-60.745)-(-69.827)-(34.856)-(-57.318)-(-35.894)-(tcb->m_segmentSize)))+(62.494)+(-55.07)+(44.646)+(91.236))/((-68.908)));
ReduceCwnd (tcb);
float BXsxXGarBNyIfhrQ = (float) (-83.84+(65.893)+(94.377)+(15.708)+(-40.751));
segmentsAcked = SlowStart (tcb, segmentsAcked);
