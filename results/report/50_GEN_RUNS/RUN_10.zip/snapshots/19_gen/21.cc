ReduceCwnd (tcb);
segmentsAcked = (int) (-42.371-(87.302)-(-1.145)-(-17.183)-(4.986)-(-41.733)-(26.719)-(-93.975)-(-89.17));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (31.06-(tcb->m_cWnd)-(-5.188)-(16.273)-(97.649)-(25.193)-(28.965)-(75.193));

} else {
	tcb->m_segmentSize = (int) (74.179-(-18.676)-(58.789)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (63.215*(67.732)*(34.206)*(94.877));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-0.695-(79.101)-(77.81)-(61.832)-(-43.226)-(-4.858)-(25.63)-(-61.786)-(-5.736));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (11.686-(91.77)-(44.54)-(76.794)-(4.8)-(-46.688)-(22.425)-(72.181)-(18.025));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (6.205-(-36.372)-(24.213)-(-70.124)-(-41.902)-(46.769)-(51.091)-(59.157)-(57.539));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (34.553-(49.249)-(96.451)-(-76.455)-(37.39)-(-10.744)-(66.897)-(18.553)-(-30.497));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
