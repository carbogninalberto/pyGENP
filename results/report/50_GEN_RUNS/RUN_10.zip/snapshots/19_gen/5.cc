TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (74.179-(-18.676)-(58.789)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (63.215*(67.732)*(34.206)*(94.877));

} else {
	tcb->m_segmentSize = (int) (31.06-(tcb->m_cWnd)-(-5.188)-(16.273)-(97.649)-(25.193)-(28.965)-(75.193));

}
segmentsAcked = (int) (-51.9-(-2.823)-(-54.647)-(-18.032)-(-55.291)-(-54.512)-(-4.128)-(-23.719)-(-88.016));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-29.204-(29.663)-(0.862)-(76.867)-(-66.459)-(39.92)-(-1.223)-(29.042)-(93.495));
segmentsAcked = SlowStart (tcb, segmentsAcked);
