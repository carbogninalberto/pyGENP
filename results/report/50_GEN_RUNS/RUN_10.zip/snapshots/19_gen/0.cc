tcb->m_cWnd = (int) (((72.9)+(-73.575)+(96.398)+(10.3))/((-86.235)+(58.94)+(-4.89)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-34.746+(1.398));
segmentsAcked = (int) (3.209+(53.742)+(-23.129)+(-48.816)+(-31.215)+(-72.783)+(55.671)+(2.854)+(-60.077));
CongestionAvoidance (tcb, segmentsAcked);
