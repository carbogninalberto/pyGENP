tcb->m_cWnd = (int) (((70.588)+(73.723)+(-81.226)+(-34.12))/((7.629)+(-74.439)+(39.947)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (53.821+(55.343));
tcb->m_cWnd = (int) (81.572+(-53.336));
segmentsAcked = (int) (-31.561+(-76.183)+(17.217)+(79.711)+(-24.23)+(-8.878)+(-38.659)+(10.265)+(-32.234));
segmentsAcked = (int) (-68.165+(82.564)+(-71.363)+(34.335)+(-25.68)+(96.372)+(-91.625)+(-78.583)+(35.408));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
