tcb->m_cWnd = (int) (((79.018)+(-0.801)+(-25.851)+(-31.64))/((4.24)+(78.171)+(-14.713)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (12.511+(66.356));
tcb->m_cWnd = (int) (-9.165+(37.519));
segmentsAcked = (int) (90.004+(-82.055)+(-26.459)+(64.518)+(99.496)+(99.139)+(6.807)+(-92.116)+(-42.872));
segmentsAcked = (int) (-2.3+(67.231)+(-63.532)+(70.642)+(-65.881)+(97.314)+(53.747)+(6.672)+(-45.672));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
