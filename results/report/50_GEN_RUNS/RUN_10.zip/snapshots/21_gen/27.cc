segmentsAcked = (int) (24.84-(20.426)-(76.938));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (77.25*(49.627)*(87.811)*(81.765)*(87.63));
tcb->m_cWnd = (int) (0.1/0.1);
tcb->m_segmentSize = (int) (tcb->m_ssThresh*(29.938)*(21.401)*(38.961)*(90.712)*(55.07)*(23.144)*(66.235));
segmentsAcked = (int) (33.256*(68.096)*(13.079));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (segmentsAcked-(35.28)-(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (46.276-(39.057)-(tcb->m_cWnd)-(tcb->m_ssThresh));
	segmentsAcked = (int) (70.32*(10.519)*(81.572)*(tcb->m_segmentSize)*(70.639)*(99.167)*(23.383));

}
segmentsAcked = (int) (tcb->m_cWnd-(2.806)-(tcb->m_cWnd)-(93.855)-(64.08));
