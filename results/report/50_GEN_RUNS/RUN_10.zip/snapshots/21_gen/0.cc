tcb->m_cWnd = (int) (((72.245)+(-94.816)+(62.86)+(-50.058))/((29.097)+(-48.722)+(95.327)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-11.502+(-72.609));
segmentsAcked = (int) (95.415+(-52.722)+(57.797)+(54.774)+(81.546)+(-47.939)+(-14.819)+(-48.953)+(-29.179));
CongestionAvoidance (tcb, segmentsAcked);
