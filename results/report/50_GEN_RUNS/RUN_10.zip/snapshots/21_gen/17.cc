tcb->m_cWnd = (int) (((-84.605)+(20.601)+(-47.922)+(-45.356))/((-98.785)+(-30.657)+(64.58)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (74.035+(20.212));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (88.962+(19.489)+(24.745)+(-78.651)+(84.902)+(-61.196)+(-68.739)+(25.632)+(-58.049));
tcb->m_cWnd = (int) (60.539+(-96.227));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-57.891+(58.077)+(-97.353)+(-19.243)+(65.637)+(3.097)+(-78.279)+(27.952)+(17.943));
CongestionAvoidance (tcb, segmentsAcked);
