tcb->m_segmentSize = (int) (-90.661*(0.129)*(-40.052)*(84.274)*(82.699)*(69.267));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (74.179-(-18.676)-(58.789)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (63.215*(67.732)*(34.206)*(94.877));

} else {
	tcb->m_segmentSize = (int) (31.06-(tcb->m_cWnd)-(-5.188)-(16.273)-(97.649)-(25.193)-(28.965)-(75.193));

}
segmentsAcked = (int) (61.321-(60.084)-(-19.674)-(-87.647)-(72.756)-(-23.358)-(86.05)-(28.578)-(19.365));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (62.703-(51.699)-(-89.348)-(81.87)-(50.447)-(76.406)-(43.974)-(78.686)-(99.167));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (32.503-(-24.616)-(38.878)-(5.817)-(96.831)-(35.0)-(-3.628)-(-26.394)-(-7.15));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-18.647-(95.577)-(99.471)-(-26.204)-(-27.722)-(-34.251)-(2.722)-(83.787)-(58.322));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
