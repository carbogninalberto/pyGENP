tcb->m_cWnd = (int) (((47.539)+(85.706)+(45.212)+(-79.049))/((93.118)+(-19.849)+(-55.199)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (27.608+(37.548));
segmentsAcked = (int) (-8.677+(-27.043)+(23.35)+(-63.756)+(-20.095)+(66.583)+(-88.978)+(93.412)+(-91.242));
CongestionAvoidance (tcb, segmentsAcked);
