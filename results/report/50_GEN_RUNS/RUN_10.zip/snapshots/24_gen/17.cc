tcb->m_cWnd = (int) (((-10.664)+(-40.894)+(29.55)+(-1.434))/((12.951)+(81.733)+(-54.82)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (62.866+(44.994));
segmentsAcked = (int) (-95.488+(-70.67)+(35.806)+(-11.002)+(-19.855)+(-13.606)+(-41.984)+(-67.025)+(-65.674));
CongestionAvoidance (tcb, segmentsAcked);
