tcb->m_cWnd = (int) (((-24.75)+(91.275)+(-2.174)+(31.27))/((25.67)+(95.638)+(-95.243)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-48.123+(-46.063));
segmentsAcked = (int) (98.148+(75.25)+(-12.969)+(96.15)+(3.499)+(-98.833)+(16.944)+(43.881)+(59.709));
CongestionAvoidance (tcb, segmentsAcked);
