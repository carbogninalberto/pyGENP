tcb->m_cWnd = (int) (((51.573)+(94.938)+(-96.157)+(81.373))/((-53.488)+(91.951)+(46.751)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-80.17+(-30.009));
segmentsAcked = (int) (37.967+(24.043)+(-10.213)+(-35.294)+(93.256)+(-26.539)+(-21.009)+(47.094)+(16.922));
CongestionAvoidance (tcb, segmentsAcked);
