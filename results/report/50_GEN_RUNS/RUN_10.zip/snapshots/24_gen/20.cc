tcb->m_cWnd = (int) (((59.706)+(-3.338)+(15.053)+(66.24))/((-59.563)+(-87.935)+(52.739)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-77.225+(73.388)+(-4.601)+(-59.277)+(64.436)+(21.202)+(50.372)+(30.756)+(51.164));
tcb->m_cWnd = (int) (88.642+(-91.833));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-14.021+(-68.616)+(-53.265)+(56.434)+(66.067)+(2.153)+(24.845)+(13.409)+(61.146));
CongestionAvoidance (tcb, segmentsAcked);
