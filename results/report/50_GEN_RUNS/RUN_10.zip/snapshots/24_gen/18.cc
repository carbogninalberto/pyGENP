tcb->m_cWnd = (int) (((-53.953)+(-7.47)+(-21.565)+(56.359))/((34.566)+(-57.545)+(85.499)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-21.799+(-40.987));
segmentsAcked = (int) (70.958+(20.904)+(14.11)+(-18.055)+(22.526)+(23.126)+(84.373)+(-19.019)+(-77.026));
CongestionAvoidance (tcb, segmentsAcked);
