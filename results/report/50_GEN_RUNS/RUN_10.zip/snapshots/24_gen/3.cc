tcb->m_cWnd = (int) (((8.525)+(3.014)+(-85.027)+(-46.772))/((27.371)+(-29.556)+(0.135)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (55.079+(23.425));
segmentsAcked = (int) (-22.591+(54.079)+(-24.739)+(86.705)+(-8.122)+(-67.779)+(34.362)+(-75.828)+(68.162));
CongestionAvoidance (tcb, segmentsAcked);
