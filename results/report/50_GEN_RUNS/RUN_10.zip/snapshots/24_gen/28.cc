tcb->m_cWnd = (int) (((11.392)+(80.159)+(-90.578)+(37.155))/((89.197)+(-53.52)+(-91.928)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (7.364+(-93.196)+(23.405)+(76.431)+(84.795)+(13.711)+(42.164)+(-21.679)+(79.426));
tcb->m_cWnd = (int) (-72.184+(1.816));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-99.41+(-50.134)+(23.683)+(-56.329)+(-10.06)+(-27.033)+(20.794)+(-80.131)+(19.477));
CongestionAvoidance (tcb, segmentsAcked);
