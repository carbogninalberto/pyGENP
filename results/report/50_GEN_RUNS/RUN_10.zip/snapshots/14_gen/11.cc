if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (15.5*(65.73)*(25.619));

} else {
	tcb->m_segmentSize = (int) (66.642*(22.932)*(13.393)*(60.186));

}
tcb->m_ssThresh = (int) (99.311*(11.11)*(97.735)*(1.013)*(8.402));
float htkUNndZqIcOIXiO = (float) (1.197*(25.435)*(70.386)*(95.197));
tcb->m_ssThresh = (int) (32.644-(tcb->m_cWnd)-(85.725)-(46.722)-(65.945));
ReduceCwnd (tcb);
