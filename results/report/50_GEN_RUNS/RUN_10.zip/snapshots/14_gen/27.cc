tcb->m_ssThresh = (int) (tcb->m_ssThresh*(segmentsAcked)*(39.041)*(21.999)*(36.43)*(18.643)*(55.398));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (54.991*(tcb->m_segmentSize)*(segmentsAcked)*(tcb->m_ssThresh)*(segmentsAcked)*(41.262)*(35.884)*(43.489));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) ((((45.726+(tcb->m_ssThresh)+(58.281)+(tcb->m_segmentSize)+(15.229)+(79.141)+(37.492)+(13.593)))+(0.1)+(51.625)+(4.113))/((93.464)+(0.1)));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (18.815*(76.766));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(71.672)*(41.078));

}
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+((23.679+(89.386)+(95.885)))+(41.642)+(59.983)+(32.262))/((0.1)+(0.1)+(54.146)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (11.416*(32.643)*(1.223)*(16.668)*(87.927)*(3.88));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(6.063)+(19.72)+(41.529)+(8.758)+(93.736)+(9.047));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_cWnd*(81.571)*(47.963)*(47.573)*(41.839)*(79.799));
segmentsAcked = SlowStart (tcb, segmentsAcked);
