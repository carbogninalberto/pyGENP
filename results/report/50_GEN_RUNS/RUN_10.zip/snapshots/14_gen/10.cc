int pwChHYNNgdwGErii = (int) (10.274*(30.492)*(tcb->m_segmentSize));
pwChHYNNgdwGErii = (int) (73.776-(24.472)-(38.805)-(29.152)-(15.099)-(58.309)-(86.163));
tcb->m_cWnd = (int) (0.1/8.868);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (segmentsAcked+(12.945)+(96.857)+(tcb->m_ssThresh)+(86.062)+(72.426)+(tcb->m_ssThresh));
pwChHYNNgdwGErii = (int) (0.855*(29.059)*(segmentsAcked)*(73.125)*(tcb->m_segmentSize)*(tcb->m_cWnd));
segmentsAcked = (int) (36.095/0.1);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
