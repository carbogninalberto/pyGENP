tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(42.412)+(74.735)+(93.231))/((0.1)+(0.1)));
tcb->m_ssThresh = (int) (6.809+(30.669)+(tcb->m_cWnd)+(31.126)+(tcb->m_segmentSize));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (1.628+(tcb->m_cWnd)+(28.736)+(25.72)+(60.459));

} else {
	tcb->m_ssThresh = (int) (35.096-(13.581)-(31.901)-(tcb->m_segmentSize));
	segmentsAcked = (int) (72.289+(61.661)+(58.863)+(30.065)+(86.189)+(75.182)+(76.08)+(74.109));
	segmentsAcked = (int) (51.119-(tcb->m_segmentSize)-(31.33)-(88.804));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
