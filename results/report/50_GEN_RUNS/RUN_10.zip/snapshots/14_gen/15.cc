ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (43.687-(54.483)-(72.99)-(66.973));
	tcb->m_segmentSize = (int) (72.013+(tcb->m_cWnd)+(84.621)+(segmentsAcked));
	tcb->m_segmentSize = (int) ((70.3*(tcb->m_ssThresh))/0.1);

} else {
	tcb->m_cWnd = (int) (36.473*(segmentsAcked)*(78.448)*(55.656));
	tcb->m_cWnd = (int) (1.377-(75.514)-(91.655)-(21.399)-(65.259)-(95.451)-(tcb->m_ssThresh)-(28.818)-(10.128));

}
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked-(tcb->m_ssThresh)-(22.676)-(segmentsAcked)-(92.194)-(59.935)-(4.931)-(tcb->m_segmentSize)-(90.814));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(25.036)-(2.939)-(92.529)-(tcb->m_cWnd)-(12.329));
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(13.226))/((92.809)+(36.092)+(0.1)));
	tcb->m_segmentSize = (int) (15.866+(92.197)+(tcb->m_cWnd)+(48.773));

}
