if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (89.235+(2.648)+(38.869)+(61.306)+(77.675)+(tcb->m_segmentSize)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) ((segmentsAcked*(81.188)*(43.694))/0.1);

} else {
	tcb->m_cWnd = (int) (56.059*(40.246)*(71.723)*(32.647)*(10.107));
	tcb->m_cWnd = (int) (83.626*(30.005)*(13.27)*(3.807));
	tcb->m_ssThresh = (int) ((((52.942*(85.23)))+((3.719*(8.931)))+(0.1)+(72.228)+(97.322)+(91.06)+(0.1)+(0.1))/((0.1)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (25.254+(37.349));
