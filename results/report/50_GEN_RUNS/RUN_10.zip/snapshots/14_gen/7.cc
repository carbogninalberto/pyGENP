float MIyIxVehkQfwPLwJ = (float) (-62.394+(-70.829)+(98.641)+(64.955)+(-97.414)+(27.759)+(35.428));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (11.061*(82.017)*(-53.646)*(-5.842)*(-46.026)*(99.073)*(-75.796)*(75.553));
segmentsAcked = (int) (61.826*(6.362)*(2.98)*(-34.266)*(63.444)*(-34.024)*(-4.589)*(98.574));
