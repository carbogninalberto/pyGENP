float MIyIxVehkQfwPLwJ = (float) (-22.76+(17.518)+(60.537)+(-3.617)+(-27.399)+(-85.431)+(-59.713));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-33.446*(77.344)*(95.929)*(22.419)*(-56.033)*(-69.912)*(-88.205)*(58.317));
