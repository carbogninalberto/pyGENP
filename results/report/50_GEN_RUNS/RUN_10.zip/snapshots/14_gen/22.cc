tcb->m_segmentSize = (int) (22.475-(95.298)-(70.274));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(82.438)+(30.077)+(5.121));
	tcb->m_cWnd = (int) (54.612+(12.119)+(segmentsAcked)+(29.96)+(30.627));
	tcb->m_ssThresh = (int) (((0.1)+(23.271)+(22.493)+(0.1)+(0.1))/((42.299)+(2.217)+(59.018)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (86.209/3.711);

}
