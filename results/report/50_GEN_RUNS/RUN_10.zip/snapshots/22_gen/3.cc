tcb->m_cWnd = (int) (((18.599)+(-78.551)+(-15.161)+(-97.558))/((95.691)+(29.084)+(-26.805)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (74.457+(4.156));
tcb->m_cWnd = (int) (93.707+(59.905));
segmentsAcked = (int) (25.85+(-9.658)+(73.076)+(-26.986)+(91.292)+(-11.939)+(7.622)+(-77.618)+(-97.183));
segmentsAcked = (int) (77.424+(37.181)+(53.599)+(18.482)+(72.741)+(-66.877)+(16.723)+(-16.944)+(-49.226));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
