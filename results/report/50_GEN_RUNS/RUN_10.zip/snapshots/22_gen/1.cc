tcb->m_cWnd = (int) (((24.081)+(-43.583)+(4.629)+(-49.54))/((58.048)+(-74.386)+(-29.845)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (29.769+(49.572));
segmentsAcked = (int) (-84.805+(9.267)+(-78.075)+(-30.585)+(76.635)+(-32.073)+(71.375)+(8.716)+(56.703));
CongestionAvoidance (tcb, segmentsAcked);
