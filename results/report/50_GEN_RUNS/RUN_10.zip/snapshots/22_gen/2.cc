tcb->m_cWnd = (int) (((57.406)+(15.202)+(-66.045)+(78.923))/((55.552)+(75.785)+(-52.734)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (48.713+(10.11));
tcb->m_cWnd = (int) (74.191+(25.227));
segmentsAcked = (int) (-87.494+(3.921)+(63.331)+(-85.32)+(-4.064)+(-60.952)+(-92.354)+(57.586)+(-47.603));
segmentsAcked = (int) (-30.018+(-10.826)+(8.712)+(63.037)+(-8.089)+(-40.338)+(-91.784)+(-59.837)+(12.587));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
