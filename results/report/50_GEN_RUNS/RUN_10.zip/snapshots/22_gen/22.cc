tcb->m_cWnd = (int) (((88.083)+(-54.682)+(-57.2)+(33.413))/((68.906)+(44.167)+(1.255)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (83.499+(54.401));
segmentsAcked = (int) (82.707+(-57.722)+(4.628)+(74.406)+(-80.948)+(-86.118)+(-5.884)+(55.352)+(-81.425));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
