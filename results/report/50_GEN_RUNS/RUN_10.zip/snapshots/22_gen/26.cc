tcb->m_cWnd = (int) (((96.118)+(26.935)+(34.805)+(12.066))/((-56.133)+(-77.904)+(9.728)));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (16.383+(-67.058));
tcb->m_cWnd = (int) (-98.587+(-44.762));
segmentsAcked = (int) (14.803+(2.163)+(67.894)+(83.794)+(18.231)+(18.467)+(81.843)+(77.834)+(73.489));
segmentsAcked = (int) (23.215+(-30.066)+(51.37)+(-61.411)+(-7.87)+(9.65)+(-27.361)+(26.4)+(87.317));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
