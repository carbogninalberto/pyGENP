tcb->m_cWnd = (int) (((55.261)+(-10.635)+(40.522)+(43.059))/((-2.053)+(-32.768)+(11.662)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (45.694+(-15.002));
segmentsAcked = (int) (-8.116+(-85.001)+(80.124)+(38.876)+(-8.749)+(7.833)+(-41.224)+(89.273)+(57.701));
CongestionAvoidance (tcb, segmentsAcked);
