tcb->m_cWnd = (int) (((-31.732)+(33.479)+(12.269)+(-72.459))/((-59.352)+(-85.317)+(-31.333)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-53.528+(-89.802));
segmentsAcked = (int) (15.933+(32.814)+(-15.573)+(-78.936)+(-36.764)+(-87.15)+(-17.101)+(54.912)+(-61.038));
CongestionAvoidance (tcb, segmentsAcked);
