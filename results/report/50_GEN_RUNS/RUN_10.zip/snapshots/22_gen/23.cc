tcb->m_cWnd = (int) (((46.103)+(-6.773)+(1.181)+(22.174))/((-63.146)+(-96.485)+(25.001)));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-67.146+(92.744));
segmentsAcked = (int) (-68.559+(-66.504)+(-39.068)+(26.249)+(-10.063)+(15.14)+(19.016)+(-23.209)+(76.935));
CongestionAvoidance (tcb, segmentsAcked);
