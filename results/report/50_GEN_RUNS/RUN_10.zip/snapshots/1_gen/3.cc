ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(90.393)*(62.209)*(97.216)*(36.857)*(78.185));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (1.87*(62.483)*(33.918));

}
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	segmentsAcked = (int) ((68.82-(39.06)-(tcb->m_cWnd)-(6.143)-(33.984)-(62.137)-(2.403))/59.804);

} else {
	segmentsAcked = (int) (25.976-(35.794));

}
ReduceCwnd (tcb);
