if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (49.642+(47.801));
	tcb->m_segmentSize = (int) (69.867*(82.942)*(72.161)*(65.295)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(87.261)+(65.942)+(41.356)+(9.676));

}
int TZbxeJrUNgDNcPkR = (int) (69.318+(89.604)+(25.626)+(81.205));
TZbxeJrUNgDNcPkR = (int) (12.969+(14.68)+(76.971)+(61.388)+(tcb->m_segmentSize)+(tcb->m_cWnd));
if (TZbxeJrUNgDNcPkR == tcb->m_ssThresh) {
	segmentsAcked = (int) (45.858+(13.454)+(6.442)+(6.743)+(42.721));
	TZbxeJrUNgDNcPkR = (int) (55.478-(37.24)-(8.711)-(28.797)-(10.205)-(61.61)-(segmentsAcked));

} else {
	segmentsAcked = (int) (27.249*(tcb->m_ssThresh)*(22.182)*(tcb->m_cWnd)*(64.148)*(59.29));
	segmentsAcked = (int) (66.775+(tcb->m_ssThresh)+(94.093)+(57.589)+(tcb->m_ssThresh)+(40.354)+(81.758));
	tcb->m_segmentSize = (int) (59.164-(78.265)-(63.144)-(84.114)-(80.275)-(19.244)-(segmentsAcked)-(89.539)-(segmentsAcked));

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (0.926+(79.769)+(1.233)+(39.938)+(60.867)+(84.708)+(0.133)+(83.493)+(40.397));
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (57.481+(77.1)+(93.569)+(TZbxeJrUNgDNcPkR)+(49.919)+(2.48)+(41.526)+(TZbxeJrUNgDNcPkR)+(54.33));
	tcb->m_segmentSize = (int) (45.816+(29.339)+(tcb->m_ssThresh)+(67.918)+(48.721)+(21.6)+(11.277)+(5.91)+(25.016));
	tcb->m_ssThresh = (int) (((0.1)+(18.763)+(0.1)+(0.1)+(0.1)+(0.1)+(94.16)+(0.1))/((0.1)));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(83.883));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (TZbxeJrUNgDNcPkR-(93.105));

}
