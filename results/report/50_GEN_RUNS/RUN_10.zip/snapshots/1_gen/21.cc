ReduceCwnd (tcb);
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (68.314-(31.224)-(71.764)-(17.417));

} else {
	tcb->m_ssThresh = (int) (((98.367)+(59.318)+(91.994)+((52.836+(45.115)+(tcb->m_cWnd)+(segmentsAcked)))+(0.1))/((0.1)+(0.1)+(33.023)+(0.1)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (49.462+(86.148)+(tcb->m_cWnd)+(segmentsAcked)+(78.897));
float eKDkpcKYZAuwxVNZ = (float) (27.167+(76.702)+(segmentsAcked)+(tcb->m_ssThresh)+(89.25)+(34.473)+(54.305)+(74.353)+(49.125));
segmentsAcked = (int) (89.214/0.1);
if (eKDkpcKYZAuwxVNZ == segmentsAcked) {
	segmentsAcked = (int) (13.146*(eKDkpcKYZAuwxVNZ)*(27.021)*(14.195)*(71.182));

} else {
	segmentsAcked = (int) (71.954-(50.141)-(80.484)-(78.569)-(65.494)-(tcb->m_cWnd)-(33.705)-(18.807)-(segmentsAcked));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (43.961*(98.576));
	eKDkpcKYZAuwxVNZ = (float) (((0.1)+(44.764)+(49.809)+(72.955)+(0.1)+(53.134)+(77.597))/((12.228)));
	tcb->m_segmentSize = (int) (85.613+(tcb->m_ssThresh)+(26.045)+(30.11));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
