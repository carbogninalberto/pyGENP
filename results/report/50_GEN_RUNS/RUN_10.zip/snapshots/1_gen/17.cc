segmentsAcked = (int) (97.929+(78.976)+(55.21)+(20.904)+(94.662)+(92.524)+(58.412));
int jSOLMxxGlYLMHIVP = (int) (45.8-(segmentsAcked)-(88.932)-(53.697)-(61.978)-(6.522)-(93.697)-(tcb->m_segmentSize));
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	segmentsAcked = (int) (56.434+(segmentsAcked)+(jSOLMxxGlYLMHIVP)+(82.224)+(88.886)+(51.748)+(jSOLMxxGlYLMHIVP)+(tcb->m_segmentSize));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (0.1/71.374);
	jSOLMxxGlYLMHIVP = (int) (9.245/0.1);
	tcb->m_segmentSize = (int) (28.218+(51.449)+(22.459)+(71.306)+(69.526)+(31.047));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(66.862)*(40.119)*(segmentsAcked)*(segmentsAcked)*(29.492)*(segmentsAcked)*(23.42));

} else {
	tcb->m_segmentSize = (int) (68.755-(7.84)-(16.024));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (50.757/0.1);

} else {
	tcb->m_cWnd = (int) (77.904+(26.374)+(segmentsAcked));

}
if (jSOLMxxGlYLMHIVP > segmentsAcked) {
	segmentsAcked = (int) (83.761+(jSOLMxxGlYLMHIVP)+(55.403)+(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (70.609-(27.053)-(77.918)-(68.589)-(54.253)-(90.439)-(11.81)-(96.693));
	segmentsAcked = (int) (32.975*(tcb->m_cWnd)*(jSOLMxxGlYLMHIVP)*(45.854)*(59.135));

}
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (jSOLMxxGlYLMHIVP*(76.941)*(75.43)*(59.161)*(77.119)*(segmentsAcked)*(27.797)*(5.761)*(48.572));

} else {
	tcb->m_cWnd = (int) (87.275+(85.625)+(99.914)+(44.646)+(96.001)+(jSOLMxxGlYLMHIVP)+(91.599)+(tcb->m_segmentSize)+(74.335));
	tcb->m_ssThresh = (int) (11.457+(89.126)+(2.895)+(69.731)+(71.659));

}
jSOLMxxGlYLMHIVP = (int) (40.833+(32.502)+(49.098)+(tcb->m_cWnd)+(tcb->m_cWnd)+(61.056)+(tcb->m_segmentSize));
