segmentsAcked = (int) (18.943+(21.363));
tcb->m_ssThresh = (int) (46.079+(6.105)+(75.996)+(76.275)+(18.35)+(86.864)+(tcb->m_cWnd));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) ((35.267+(tcb->m_segmentSize)+(68.416))/18.419);
ReduceCwnd (tcb);
float GOCduMBkrwHBIrIm = (float) (tcb->m_cWnd-(segmentsAcked));
GOCduMBkrwHBIrIm = (float) (9.548+(10.318)+(3.417));
