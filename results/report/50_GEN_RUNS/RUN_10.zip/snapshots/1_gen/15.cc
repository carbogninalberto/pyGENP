ReduceCwnd (tcb);
int NYUVCEILPLZVfJcx = (int) (58.302-(88.047)-(14.41)-(tcb->m_segmentSize)-(75.532)-(21.318)-(34.207)-(tcb->m_ssThresh));
tcb->m_ssThresh = (int) (tcb->m_cWnd+(83.366)+(52.512)+(29.704)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(NYUVCEILPLZVfJcx)+(60.045));
CongestionAvoidance (tcb, segmentsAcked);
float soMHxTFUrwynuqyY = (float) (76.412/98.368);
float bNhsyqmiWxsTlPhT = (float) (77.619/78.044);
int KczkZzYljfwPIxfK = (int) (84.603+(bNhsyqmiWxsTlPhT)+(66.538)+(45.079)+(bNhsyqmiWxsTlPhT)+(bNhsyqmiWxsTlPhT)+(70.002)+(14.066)+(soMHxTFUrwynuqyY));
segmentsAcked = (int) (37.421-(segmentsAcked));
tcb->m_cWnd = (int) (bNhsyqmiWxsTlPhT+(68.465));
