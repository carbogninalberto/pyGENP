if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (96.466*(35.342)*(19.599)*(88.2)*(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (27.203*(18.336)*(78.337)*(94.196)*(0.751)*(98.45)*(9.126)*(64.159));
	segmentsAcked = (int) (tcb->m_cWnd+(83.146)+(tcb->m_cWnd)+(15.239)+(27.906));

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float lKPNhBIwuxkMkCJG = (float) (69.529*(45.546));
lKPNhBIwuxkMkCJG = (float) (54.334*(20.117)*(35.233)*(75.689)*(10.685)*(segmentsAcked)*(7.108)*(75.731));
segmentsAcked = (int) (9.927-(63.728)-(lKPNhBIwuxkMkCJG)-(39.737)-(74.637)-(43.828));
