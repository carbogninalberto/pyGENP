tcb->m_cWnd = (int) ((13.996-(tcb->m_cWnd))/(36.318*(76.745)*(80.64)*(tcb->m_cWnd)*(52.335)*(8.68)*(0.561)*(46.506)));
ReduceCwnd (tcb);
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (29.272-(72.102)-(43.519)-(66.234)-(74.678)-(35.847));

} else {
	tcb->m_cWnd = (int) (66.24-(24.694)-(65.436)-(11.355)-(97.092));
	segmentsAcked = (int) (59.961-(45.521)-(17.254)-(tcb->m_segmentSize)-(57.682)-(tcb->m_ssThresh)-(20.721));
	segmentsAcked = (int) (74.838*(tcb->m_cWnd)*(96.227)*(96.678)*(6.669));

}
segmentsAcked = (int) (66.435+(99.153)+(24.961)+(15.61)+(53.459)+(32.498)+(29.396)+(27.8)+(68.794));
tcb->m_ssThresh = (int) (60.409+(tcb->m_ssThresh)+(segmentsAcked)+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (51.11-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (78.618/0.1);
	tcb->m_ssThresh = (int) (37.225-(tcb->m_cWnd)-(51.624)-(31.485)-(54.516)-(39.198)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(26.064)+((tcb->m_segmentSize+(tcb->m_ssThresh)+(3.645)+(36.432)+(segmentsAcked)))+(0.1)+(86.785)+(0.1)+(0.1)+(0.1))/((0.1)));
	tcb->m_ssThresh = (int) (32.31*(50.299)*(31.895)*(91.392)*(99.642)*(99.684)*(tcb->m_ssThresh)*(49.18));

}
