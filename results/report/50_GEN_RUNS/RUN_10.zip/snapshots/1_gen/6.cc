ReduceCwnd (tcb);
tcb->m_cWnd = (int) (55.205+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(20.434)+(segmentsAcked));
segmentsAcked = (int) (tcb->m_ssThresh-(34.11)-(tcb->m_cWnd));
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((((segmentsAcked-(56.936)-(54.34)))+(65.448)+(0.1)+(47.503)+((16.809-(79.798)-(3.348)))+(0.1)+((tcb->m_ssThresh*(23.941)*(15.811)*(tcb->m_ssThresh)*(71.976)*(62.4)*(24.937)))+(0.1))/((42.834)));
	segmentsAcked = (int) (2.026+(59.17));

} else {
	tcb->m_ssThresh = (int) (60.915*(16.608)*(98.602)*(98.432)*(0.103)*(29.754)*(80.621)*(16.465)*(segmentsAcked));
	tcb->m_cWnd = (int) (83.678+(69.649)+(32.706)+(tcb->m_cWnd));
	segmentsAcked = (int) (segmentsAcked*(37.772)*(62.853)*(85.377)*(34.555)*(87.73)*(24.485)*(segmentsAcked));

}
ReduceCwnd (tcb);
if (segmentsAcked == segmentsAcked) {
	segmentsAcked = (int) (27.95+(44.863)+(60.826)+(95.08));
	tcb->m_segmentSize = (int) (48.385-(78.268)-(tcb->m_cWnd)-(49.475)-(2.689));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (73.275+(70.704)+(52.265)+(98.801));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
