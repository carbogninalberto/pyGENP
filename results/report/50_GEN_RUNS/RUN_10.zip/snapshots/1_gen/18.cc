if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(96.956)+(80.051)+(64.152)+(93.556)+(46.619)+(84.112)+(6.545)+(44.442));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (segmentsAcked+(91.291)+(0.384)+(88.077)+(55.454)+(72.309)+(58.038)+(24.901));

} else {
	tcb->m_cWnd = (int) (66.552-(tcb->m_ssThresh)-(24.8)-(45.405)-(tcb->m_ssThresh)-(5.377)-(88.499));
	ReduceCwnd (tcb);
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (((11.427)+((88.732-(11.374)-(38.025)-(tcb->m_segmentSize)-(22.366)-(tcb->m_ssThresh)-(74.964)))+((57.158-(38.783)-(79.098)-(tcb->m_ssThresh)-(55.297)-(35.934)))+(0.1))/((20.329)));
segmentsAcked = (int) (tcb->m_segmentSize-(37.394)-(74.064));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (segmentsAcked-(24.803)-(segmentsAcked));
