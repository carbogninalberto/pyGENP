int DKAyQnUXUvXAClbh = (int) (41.841+(27.558)+(17.084)+(5.352));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (8.475-(43.134)-(70.197)-(tcb->m_segmentSize)-(63.461)-(54.712)-(75.708)-(50.721));
tcb->m_cWnd = (int) (78.988-(64.876));
