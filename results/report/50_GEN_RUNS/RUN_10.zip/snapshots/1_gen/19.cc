tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((61.743)+(0.1)+(0.1)+(75.886)+(92.638)));
ReduceCwnd (tcb);
int dRMJkANVTpNxuEDn = (int) (94.952-(tcb->m_cWnd)-(55.968)-(52.37)-(tcb->m_ssThresh));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (67.834+(55.838)+(tcb->m_segmentSize)+(38.254)+(64.833)+(tcb->m_ssThresh)+(61.584)+(60.885));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (((0.1)+((50.395+(dRMJkANVTpNxuEDn)+(27.998)+(27.367)+(dRMJkANVTpNxuEDn)+(66.468)+(tcb->m_cWnd)))+(84.696)+(36.97)+(37.603)+(2.185))/((53.019)+(47.339)));
	tcb->m_ssThresh = (int) (((41.472)+(49.765)+(0.1)+(9.925))/((11.642)+(96.308)+(0.1)));

}
float PmkIrmoHvuqwnqXe = (float) (47.012-(17.954)-(97.139)-(94.92)-(tcb->m_segmentSize)-(86.051)-(dRMJkANVTpNxuEDn));
