int HfpsGdsysEWGgpfY = (int) (92.66+(53.255)+(tcb->m_ssThresh)+(25.528)+(57.153)+(49.812)+(tcb->m_cWnd)+(22.415)+(7.497));
if (tcb->m_cWnd >= HfpsGdsysEWGgpfY) {
	segmentsAcked = (int) (33.854-(14.888)-(36.474)-(tcb->m_cWnd)-(70.973)-(68.322)-(51.265)-(85.717)-(73.205));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (26.791+(96.134));

}
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (73.813+(18.978)+(segmentsAcked)+(tcb->m_ssThresh)+(58.765)+(22.971)+(65.966)+(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(HfpsGdsysEWGgpfY)+(73.577)+(2.555)+(43.846)+(segmentsAcked)+(95.991));
	tcb->m_cWnd = (int) (57.435*(HfpsGdsysEWGgpfY)*(23.811)*(38.377)*(47.395)*(11.129)*(36.216));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
