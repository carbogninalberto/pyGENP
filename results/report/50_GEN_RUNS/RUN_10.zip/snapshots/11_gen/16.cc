TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (((0.1)+((tcb->m_ssThresh-(22.068)-(19.064)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(19.205)-(44.266)-(94.261)))+(85.271)+(0.1)+(0.1)+(1.771)+(55.888))/((0.1)+(0.1)));
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	segmentsAcked = (int) (99.626+(tcb->m_ssThresh)+(15.767)+(77.623)+(27.274)+(89.136));

} else {
	segmentsAcked = (int) (71.92+(29.264)+(3.986)+(segmentsAcked));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (((45.017)+((71.491*(84.701)*(55.128)*(31.022)*(tcb->m_segmentSize)))+(85.25)+(1.399)+(0.1)+(94.385)+(0.1)+(0.1))/((43.945)));

}
tcb->m_segmentSize = (int) (61.128-(88.327)-(tcb->m_segmentSize));
tcb->m_cWnd = (int) (((58.204)+(0.1)+((87.873+(7.055)+(17.894)+(12.745)+(78.354)+(88.378)))+((20.884*(tcb->m_cWnd)*(88.338)*(63.708)*(24.572)))+(0.1)+(0.1)+(66.632)+(90.613))/((96.979)));
