if (tcb->m_ssThresh != tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd+(15.808)+(39.645)+(46.071)+(39.403)+(79.767)+(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (0.1/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(24.398)-(63.568));
segmentsAcked = (int) (16.007*(80.834));
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(segmentsAcked)*(tcb->m_segmentSize)*(82.258)*(49.871));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (97.715+(19.581)+(93.727)+(35.394));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (segmentsAcked-(20.602)-(89.701)-(20.893)-(34.596)-(18.779)-(segmentsAcked)-(77.775)-(segmentsAcked));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (52.994/(90.211-(50.823)-(24.921)));
