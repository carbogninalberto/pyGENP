int TtAhsWBNrGvjnWMr = (int) (tcb->m_cWnd-(8.679)-(92.403)-(tcb->m_segmentSize)-(34.934)-(tcb->m_segmentSize)-(72.098)-(50.74));
tcb->m_cWnd = (int) (TtAhsWBNrGvjnWMr-(99.29)-(52.387));
tcb->m_segmentSize = (int) (0.1/91.216);
int LcmcTGdCdAubAlJU = (int) (72.863-(67.439)-(79.902)-(16.473)-(segmentsAcked)-(57.861));
ReduceCwnd (tcb);
segmentsAcked = (int) (60.833-(37.183)-(LcmcTGdCdAubAlJU)-(82.326)-(LcmcTGdCdAubAlJU));
segmentsAcked = SlowStart (tcb, segmentsAcked);
