float MIyIxVehkQfwPLwJ = (float) (-99.83+(-3.662)+(9.304)+(52.376)+(-6.074)+(-98.67)+(61.853));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (70.098*(35.443)*(-28.229)*(-23.033)*(8.5)*(-7.38)*(-44.698)*(47.723));
