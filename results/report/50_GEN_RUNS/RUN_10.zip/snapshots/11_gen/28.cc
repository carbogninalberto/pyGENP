segmentsAcked = (int) (19.542-(95.511)-(0.697)-(tcb->m_ssThresh)-(tcb->m_cWnd));
tcb->m_ssThresh = (int) (35.596*(28.951));
tcb->m_cWnd = (int) (60.706-(43.13)-(tcb->m_segmentSize)-(98.141));
tcb->m_segmentSize = (int) (tcb->m_ssThresh+(54.884)+(tcb->m_cWnd)+(13.408)+(52.578)+(31.957)+(67.06)+(60.719));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (26.904+(tcb->m_ssThresh));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
