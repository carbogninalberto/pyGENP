float MIyIxVehkQfwPLwJ = (float) (-15.59+(-3.006)+(85.328)+(21.319)+(-2.069)+(31.093)+(11.929));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-70.685*(47.43)*(-7.103)*(-76.875)*(-59.763)*(99.243)*(-22.487)*(-75.162));
ReduceCwnd (tcb);
segmentsAcked = (int) (-76.733*(29.44)*(-39.562)*(0.519)*(79.932)*(-83.393)*(38.926)*(40.459));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-56.86*(87.354)*(31.779)*(33.858)*(39.034)*(63.196)*(-73.532)*(47.19));
