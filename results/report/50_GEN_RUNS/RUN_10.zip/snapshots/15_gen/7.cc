TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (43.687-(54.483)-(72.99)-(66.973));
	tcb->m_segmentSize = (int) (72.013+(tcb->m_cWnd)+(84.621)+(segmentsAcked));
	tcb->m_segmentSize = (int) ((70.3*(tcb->m_ssThresh))/0.1);

} else {
	tcb->m_cWnd = (int) (36.473*(segmentsAcked)*(78.448)*(55.656));
	tcb->m_cWnd = (int) (1.377-(75.514)-(91.655)-(21.399)-(65.259)-(95.451)-(-14.347)-(28.818)-(10.128));

}
