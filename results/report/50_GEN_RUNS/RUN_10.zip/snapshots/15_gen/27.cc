tcb->m_segmentSize = (int) (((-80.96)+(29.7)+(94.926)+(21.715))/((80.845)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (40.169*(-69.116)*(-87.045)*(-78.251));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (56.135*(97.968)*(-38.698)*(96.427));
