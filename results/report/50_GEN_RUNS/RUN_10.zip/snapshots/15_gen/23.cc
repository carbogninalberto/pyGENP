float MIyIxVehkQfwPLwJ = (float) (-33.833+(-40.641)+(97.868)+(64.195)+(-88.038)+(-39.11)+(48.727));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (9.514*(-82.912)*(-72.028)*(0.69)*(-14.87)*(-33.845)*(-32.379)*(94.864));
segmentsAcked = (int) (-12.884*(-57.153)*(-79.096)*(-71.992)*(97.227)*(-32.983)*(-82.305)*(-55.089));
