float DSYFBTTaZhnqeYHP = (float) (76.972/48.225);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (63.356-(80.29)-(32.837)-(-98.377)-(87.429)-(-12.841)-(59.777)-(48.735));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (79.392-(83.033)-(61.462));
