float MIyIxVehkQfwPLwJ = (float) (-54.517+(-25.78)+(9.244)+(33.079)+(-75.196)+(35.273)+(-37.173));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (68.949*(72.695)*(-86.993)*(-13.399)*(86.606)*(-79.888)*(-12.226)*(91.237));
