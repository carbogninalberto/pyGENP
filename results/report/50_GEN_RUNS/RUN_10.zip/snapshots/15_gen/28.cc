segmentsAcked = SlowStart (tcb, segmentsAcked);
float MIyIxVehkQfwPLwJ = (float) (56.753+(63.487)+(95.261)+(-14.381)+(-52.286)+(-29.102)+(-38.096));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-43.718*(85.298)*(-12.339)*(-17.347)*(-36.964)*(-92.856)*(69.919)*(-40.883));
segmentsAcked = (int) (-5.397*(66.66)*(61.755)*(-95.083)*(62.645)*(-85.718)*(17.732)*(-85.545));
