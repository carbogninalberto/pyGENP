float DSYFBTTaZhnqeYHP = (float) (-11.891/5.218);
tcb->m_segmentSize = (int) (45.349+(80.941)+(57.762)+(83.681)+(-45.031)+(-34.173)+(-68.933)+(-41.532)+(-72.281));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-14.68-(-67.287)-(-44.818));
tcb->m_segmentSize = (int) (-76.437-(-72.354)-(-28.629)-(-25.072)-(-56.172)-(61.466)-(81.049)-(94.779));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (73.014-(57.667)-(-89.647));
