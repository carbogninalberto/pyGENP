float mVsDybfzdUnGvKVZ = (float) (-51.869+(-37.014));
segmentsAcked = (int) (54.031-(52.692)-(20.91)-(-17.0)-(68.109)-(-4.671)-(94.469)-(41.754)-(23.049));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
