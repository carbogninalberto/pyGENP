tcb->m_cWnd = (int) (((-29.469)+(-10.565)+(-27.821)+(-60.483))/((64.122)+(-24.609)+(32.865)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (51.309+(-11.275));
segmentsAcked = (int) (1.185+(81.234)+(4.617)+(-30.425)+(-24.798)+(82.286)+(-54.557)+(-40.279)+(-65.808));
CongestionAvoidance (tcb, segmentsAcked);
