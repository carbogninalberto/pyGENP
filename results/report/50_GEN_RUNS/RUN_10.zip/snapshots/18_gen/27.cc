TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int eBbZgVajwnbDrgTs = (int) (29.773+(23.614)+(10.185)+(90.509)+(16.743)+(51.269)+(35.474)+(tcb->m_cWnd));
eBbZgVajwnbDrgTs = (int) (34.539-(49.972));
ReduceCwnd (tcb);
eBbZgVajwnbDrgTs = (int) (64.087-(14.37)-(0.206)-(6.894));
