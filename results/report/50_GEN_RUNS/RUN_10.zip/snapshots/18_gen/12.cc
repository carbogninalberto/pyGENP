int uZrGyACANlsZTKjO = (int) (-89.96+(-56.825)+(4.859)+(-5.991)+(3.141)+(97.961)+(48.508));
float WtFwNkqFPOaHCsxT = (float) (1.915-(48.729)-(26.144));
WtFwNkqFPOaHCsxT = (float) (((-92.516)+(24.961)+((21.962-(-9.962)-(13.601)-(46.196)-(21.656)-(54.111)-(tcb->m_segmentSize)))+(-46.887)+(-93.205)+(84.796)+(34.628))/((-0.724)));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
