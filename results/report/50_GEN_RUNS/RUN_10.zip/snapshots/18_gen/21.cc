if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(10.883)-(81.278)-(0.507)-(65.975)-(tcb->m_ssThresh)-(25.552));

} else {
	tcb->m_cWnd = (int) (33.63*(95.998)*(tcb->m_cWnd)*(78.943)*(tcb->m_segmentSize)*(76.516));
	tcb->m_cWnd = (int) (segmentsAcked-(80.248)-(segmentsAcked)-(98.196)-(41.058)-(58.84)-(84.898)-(40.242));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (0.1/6.149);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (38.292+(87.845)+(41.333)+(tcb->m_ssThresh));
