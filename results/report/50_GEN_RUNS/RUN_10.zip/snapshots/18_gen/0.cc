float KEImMmqtEiDdxdZz = (float) 88.057;
segmentsAcked = (int) (-63.981/-61.613);
