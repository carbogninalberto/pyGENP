ReduceCwnd (tcb);
segmentsAcked = (int) (74.252+(-58.893)+(52.853));
segmentsAcked = (int) (24.233-(-70.238)-(-23.666)-(-60.313)-(19.04)-(-81.012)-(-82.265)-(75.993)-(7.531));
segmentsAcked = SlowStart (tcb, segmentsAcked);
