float MIyIxVehkQfwPLwJ = (float) (64.412+(-97.157)+(84.728)+(-18.129)+(-52.131)+(-83.906)+(54.637));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-94.597*(-16.217)*(44.217)*(-69.256)*(90.119)*(6.495)*(-7.824)*(0.521));
