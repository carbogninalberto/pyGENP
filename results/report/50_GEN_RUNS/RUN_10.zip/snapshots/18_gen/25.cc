ReduceCwnd (tcb);
tcb->m_cWnd = (int) (38.397/0.1);
int mheArLjcXsLIeUhs = (int) (64.052*(64.394));
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_cWnd*(mheArLjcXsLIeUhs)*(76.539)*(89.388)*(20.367)*(24.182)*(90.783));
	tcb->m_ssThresh = (int) (2.576-(94.119)-(73.471)-(tcb->m_cWnd)-(72.533)-(33.118));
	mheArLjcXsLIeUhs = (int) (88.125+(55.914)+(23.538)+(35.129)+(33.481));

} else {
	segmentsAcked = (int) (21.763-(50.439)-(36.405)-(1.462)-(69.067)-(tcb->m_ssThresh)-(24.974)-(69.013));

}
tcb->m_ssThresh = (int) (39.142*(1.065)*(mheArLjcXsLIeUhs)*(72.292)*(7.58));
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_ssThresh = (int) (15.873-(12.644)-(53.365)-(segmentsAcked)-(68.852)-(23.389)-(4.587)-(48.444));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (70.914-(tcb->m_segmentSize)-(97.386)-(11.891)-(38.771)-(53.73));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
