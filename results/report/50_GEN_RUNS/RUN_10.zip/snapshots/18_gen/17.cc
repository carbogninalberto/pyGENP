tcb->m_segmentSize = (int) (59.378+(-31.176));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (31.06-(tcb->m_cWnd)-(-5.188)-(16.273)-(97.649)-(25.193)-(28.965)-(75.193));

} else {
	tcb->m_segmentSize = (int) (74.179-(-18.676)-(58.789)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (63.215*(67.732)*(34.206)*(94.877));

}
segmentsAcked = (int) (-54.541-(-11.857)-(-36.002)-(54.463)-(-20.944)-(50.912)-(-11.018)-(26.629)-(47.623));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-36.164-(60.382)-(25.741)-(37.751)-(-72.003)-(21.938)-(-46.98)-(-70.116)-(-65.738));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-48.572-(20.886)-(-86.354)-(-22.403)-(98.376)-(-8.239)-(-60.76)-(66.369)-(97.239));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (16.333-(50.635)-(-55.316)-(48.109)-(94.825)-(94.524)-(53.133)-(76.916)-(15.347));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
