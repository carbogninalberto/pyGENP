segmentsAcked = (int) (35.288-(-68.433)-(87.648)-(50.217)-(-51.142)-(-27.169)-(98.238)-(-66.022)-(-45.773));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (74.179-(-18.676)-(58.789)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (63.215*(67.732)*(34.206)*(94.877));

} else {
	tcb->m_segmentSize = (int) (31.06-(tcb->m_cWnd)-(-5.188)-(16.273)-(97.649)-(25.193)-(28.965)-(75.193));

}
segmentsAcked = (int) (-84.951-(-91.291)-(1.626)-(79.081)-(-76.848)-(60.878)-(8.83)-(29.402)-(63.346));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-96.97-(44.369)-(22.243)-(0.383)-(53.501)-(37.625)-(-81.199)-(29.823)-(83.504));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
