if (segmentsAcked == segmentsAcked) {
	tcb->m_cWnd = (int) (0.1/(73.274+(40.087)+(71.77)));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (17.876+(9.611));

} else {
	tcb->m_cWnd = (int) (82.588*(5.612));
	CongestionAvoidance (tcb, segmentsAcked);

}
int uKeyvfmQCRyaCZqK = (int) (16.676/-58.306);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
