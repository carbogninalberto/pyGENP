float MIyIxVehkQfwPLwJ = (float) (-0.622+(-29.465)+(13.676)+(32.505)+(23.845)+(66.137)+(7.928));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-65.619*(-13.887)*(-37.517)*(25.69)*(29.791)*(-58.572)*(-44.217)*(-30.609));
segmentsAcked = (int) (-23.736*(37.845)*(96.658)*(-37.036)*(-96.282)*(1.494)*(49.222)*(18.175));
