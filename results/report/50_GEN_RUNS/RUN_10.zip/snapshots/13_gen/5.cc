float MIyIxVehkQfwPLwJ = (float) (-73.632+(66.543)+(9.361)+(-50.46)+(-53.502)+(-52.582)+(14.922));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (-78.393*(-57.941)*(70.875)*(74.808)*(30.696)*(96.25)*(-30.842)*(-51.413));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-27.439*(92.852)*(-17.9)*(-64.159)*(-45.072)*(1.506)*(41.95)*(-1.669));
