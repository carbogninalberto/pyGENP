if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) ((((14.353+(28.917)+(74.161)+(16.728)+(52.017)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(94.64)))+(88.646)+(32.736)+(19.096))/((47.628)+(0.1)));
	tcb->m_segmentSize = (int) (32.275-(64.983)-(54.196)-(98.536)-(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (79.596/0.1);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (28.373-(52.521)-(tcb->m_cWnd)-(segmentsAcked)-(98.065)-(segmentsAcked)-(85.096)-(tcb->m_ssThresh));
tcb->m_ssThresh = (int) (tcb->m_ssThresh-(94.784)-(56.707)-(44.536));
ReduceCwnd (tcb);
