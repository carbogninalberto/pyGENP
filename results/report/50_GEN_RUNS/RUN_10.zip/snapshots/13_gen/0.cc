float MIyIxVehkQfwPLwJ = (float) (-94.776+(64.436)+(11.763)+(-41.33)+(-4.302)+(-23.606)+(49.158));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-66.783*(-9.193)*(-31.457)*(25.475)*(47.705)*(-99.117)*(14.055)*(-51.003));
