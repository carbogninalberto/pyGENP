segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (9.784*(84.645)*(4.472)*(4.986));
float SFCrndchptKuinaD = (float) (98.628+(56.181)+(72.784));
segmentsAcked = (int) (tcb->m_cWnd-(tcb->m_ssThresh)-(14.468));
if (segmentsAcked == SFCrndchptKuinaD) {
	tcb->m_segmentSize = (int) (6.794+(32.443)+(85.064)+(86.216));
	tcb->m_ssThresh = (int) (60.924*(22.366)*(93.26)*(46.19)*(47.086)*(segmentsAcked)*(31.441)*(25.72)*(97.8));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (((0.1)+(62.5)+(70.804)+(0.1)+(0.1)+(0.1)+(40.169))/((58.809)));

}
