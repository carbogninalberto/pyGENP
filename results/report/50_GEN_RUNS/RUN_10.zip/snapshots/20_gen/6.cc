tcb->m_cWnd = (int) (((83.382)+(-74.769)+(29.07)+(75.371))/((-9.68)+(-6.501)+(49.103)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-56.145+(53.732));
segmentsAcked = (int) (-94.8+(34.234)+(-33.392)+(6.82)+(89.79)+(-24.134)+(10.583)+(-72.421)+(-29.394));
CongestionAvoidance (tcb, segmentsAcked);
