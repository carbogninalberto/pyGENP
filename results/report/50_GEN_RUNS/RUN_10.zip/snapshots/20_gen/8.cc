tcb->m_segmentSize = (int) (74.957+(-18.25));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (74.179-(-18.676)-(58.789)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (63.215*(67.732)*(34.206)*(94.877));

} else {
	tcb->m_segmentSize = (int) (31.06-(tcb->m_cWnd)-(-5.188)-(16.273)-(97.649)-(25.193)-(28.965)-(75.193));

}
segmentsAcked = (int) (3.675-(19.125)-(-68.567)-(-27.354)-(91.354)-(7.905)-(-47.35)-(94.704)-(6.622));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (35.087-(-65.276)-(-38.366)-(-77.054)-(82.529)-(-96.568)-(-54.258)-(-65.999)-(-77.935));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-37.773-(-35.621)-(79.632)-(-93.619)-(-41.257)-(-50.592)-(36.585)-(16.237)-(29.856));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (22.225-(-28.176)-(-43.462)-(48.562)-(23.562)-(-11.603)-(-32.341)-(-48.278)-(-28.405));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
