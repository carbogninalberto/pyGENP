tcb->m_cWnd = (int) (((6.31)+(-4.809)+(54.452)+(-27.332))/((59.315)+(-3.649)+(34.919)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (60.456+(62.834));
segmentsAcked = (int) (-22.3+(-57.661)+(-88.44)+(-63.831)+(5.718)+(46.392)+(69.585)+(89.217)+(-50.805));
CongestionAvoidance (tcb, segmentsAcked);
