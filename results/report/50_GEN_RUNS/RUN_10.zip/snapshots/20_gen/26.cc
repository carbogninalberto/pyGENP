tcb->m_cWnd = (int) (((25.396)+(84.454)+(-47.876)+(-7.648))/((-45.103)+(-18.036)+(-48.851)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-73.576+(-94.539));
segmentsAcked = (int) (23.563+(-49.901)+(21.989)+(-40.599)+(15.733)+(97.586)+(-7.601)+(-85.694)+(82.711));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-23.814+(-30.13));
segmentsAcked = (int) (-93.497+(-88.04)+(-23.645)+(-2.485)+(50.209)+(78.756)+(-25.522)+(-84.951)+(-71.949));
CongestionAvoidance (tcb, segmentsAcked);
