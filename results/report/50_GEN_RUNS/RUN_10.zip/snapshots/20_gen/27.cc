tcb->m_cWnd = (int) (((92.886)+(-61.341)+(89.944)+(-87.088))/((17.847)+(-85.527)+(-71.913)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-24.203+(92.48));
tcb->m_cWnd = (int) (-30.632+(-55.946));
segmentsAcked = (int) (-72.428+(-47.806)+(38.947)+(-64.731)+(97.275)+(-49.154)+(35.921)+(-44.114)+(-12.743));
segmentsAcked = (int) (-4.221+(-43.15)+(-61.846)+(-30.638)+(85.598)+(70.186)+(-65.676)+(-51.613)+(23.133));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
