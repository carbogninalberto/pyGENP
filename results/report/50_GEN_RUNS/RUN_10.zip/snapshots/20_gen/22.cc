tcb->m_cWnd = (int) (((-9.914)+(97.345)+(-41.455)+(-61.823))/((-86.206)+(88.704)+(-16.075)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-64.002+(-9.953));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-41.786+(-57.725)+(1.404)+(72.206)+(-59.288)+(-66.517)+(26.137)+(62.356)+(-17.37));
tcb->m_cWnd = (int) (-34.037+(46.897));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (26.926+(77.806)+(-75.124)+(65.679)+(23.926)+(63.764)+(-51.393)+(87.546)+(-30.408));
CongestionAvoidance (tcb, segmentsAcked);
