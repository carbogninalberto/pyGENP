segmentsAcked = (int) (16.722-(segmentsAcked)-(28.928)-(6.974)-(50.962));
tcb->m_cWnd = (int) (87.231*(7.698)*(57.386)*(85.944)*(5.593)*(36.752)*(38.488)*(76.663));
segmentsAcked = (int) (0.1/0.1);
tcb->m_cWnd = (int) (6.414+(55.742));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (50.324-(39.546)-(segmentsAcked)-(41.171)-(tcb->m_segmentSize)-(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(tcb->m_ssThresh)-(76.209)-(7.137));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(segmentsAcked)+(88.055)+(25.016)+(0.243));
	tcb->m_cWnd = (int) (77.171-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(segmentsAcked)-(2.037)-(1.053)-(73.325)-(6.532));

}
