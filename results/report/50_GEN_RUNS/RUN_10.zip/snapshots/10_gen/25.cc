if (segmentsAcked > segmentsAcked) {
	tcb->m_ssThresh = (int) (34.27+(segmentsAcked)+(98.142)+(89.283)+(77.907)+(segmentsAcked)+(52.506));
	tcb->m_cWnd = (int) ((((50.836-(14.64)-(14.33)-(76.025)-(tcb->m_cWnd)-(70.55)-(38.573)))+(99.81)+(68.552)+(0.1)+(45.482)+(97.485))/((49.257)));
	tcb->m_cWnd = (int) (71.014+(41.302)+(32.375)+(31.07));

} else {
	tcb->m_ssThresh = (int) (52.344*(segmentsAcked)*(79.724)*(1.143)*(64.777));

}
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (67.225-(44.606));
	tcb->m_cWnd = (int) (31.692/0.1);

} else {
	tcb->m_segmentSize = (int) (64.235+(tcb->m_cWnd)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(90.816)+(80.106));

}
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(26.75)-(94.48)-(tcb->m_ssThresh)-(70.117)-(tcb->m_cWnd));
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	segmentsAcked = (int) (42.774-(7.425)-(27.653)-(75.758)-(21.646)-(87.343)-(99.301)-(8.773));

} else {
	segmentsAcked = (int) (21.833*(27.855)*(19.915)*(79.534)*(94.239));
	segmentsAcked = (int) (tcb->m_cWnd+(69.816)+(17.177)+(50.501)+(19.23)+(8.961)+(78.646)+(67.888));

}
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (36.3*(3.914)*(tcb->m_segmentSize)*(57.107)*(tcb->m_cWnd)*(51.252));

} else {
	tcb->m_ssThresh = (int) (3.593+(55.883)+(34.011)+(19.527));

}
tcb->m_ssThresh = (int) (83.857*(92.457));
ReduceCwnd (tcb);
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (69.906-(26.216)-(segmentsAcked)-(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(80.464)-(78.807)-(33.716)-(89.28)-(53.313)-(47.004)-(14.571)-(37.754));
	segmentsAcked = (int) (49.325/12.939);
	tcb->m_ssThresh = (int) (83.366/0.1);

}
