TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (27.135+(6.865)+(12.724)+(92.212)+(segmentsAcked));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (0.1/0.1);
int mSRfUwmjDaPDigEZ = (int) (tcb->m_cWnd*(tcb->m_ssThresh));
tcb->m_segmentSize = (int) ((49.293+(65.714))/51.898);
