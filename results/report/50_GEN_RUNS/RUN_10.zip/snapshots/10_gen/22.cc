float VtghEIUShykzjThj = (float) (0.1/43.845);
segmentsAcked = (int) (56.382-(60.097)-(48.124)-(39.883)-(tcb->m_segmentSize));
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	segmentsAcked = (int) (0.1/91.602);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (0.1/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) ((74.158+(72.116)+(82.867))/51.085);
