if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) ((((tcb->m_cWnd*(tcb->m_cWnd)*(59.952)*(2.468)*(51.415)*(48.124)*(segmentsAcked)*(segmentsAcked)))+(56.152)+(80.385)+(26.615))/((0.1)+(80.295)+(90.996)));
	tcb->m_cWnd = (int) (0.552-(6.564)-(tcb->m_segmentSize)-(25.729)-(tcb->m_ssThresh)-(3.905)-(62.083)-(tcb->m_ssThresh)-(24.186));

} else {
	segmentsAcked = (int) (segmentsAcked+(34.325)+(99.791)+(24.963)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(23.04)+(tcb->m_ssThresh)+(63.683));
	ReduceCwnd (tcb);

}
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) ((tcb->m_cWnd+(53.297)+(32.279)+(24.659))/62.159);

} else {
	tcb->m_ssThresh = (int) ((((86.352+(66.403)+(56.553)+(80.438)+(78.405)+(51.998)+(71.605)+(69.721)))+(19.044)+(61.458)+(44.117)+(82.442)+(0.1)+(45.491))/((80.408)));

}
int zKfmstlHxhwKGcvq = (int) (0.1/0.1);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	zKfmstlHxhwKGcvq = (int) (58.325+(44.185)+(65.608)+(20.5)+(segmentsAcked));

} else {
	zKfmstlHxhwKGcvq = (int) (69.535+(60.549)+(tcb->m_ssThresh)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (41.118*(15.501));
	tcb->m_ssThresh = (int) (25.343-(51.619)-(90.217)-(11.242)-(2.949)-(34.112)-(49.395)-(73.414)-(tcb->m_segmentSize));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != zKfmstlHxhwKGcvq) {
	tcb->m_segmentSize = (int) (22.582*(49.352)*(tcb->m_cWnd)*(69.519)*(40.306)*(15.011)*(94.601));
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(segmentsAcked)-(7.539)-(27.571));
	tcb->m_ssThresh = (int) (0.1/83.52);

} else {
	tcb->m_segmentSize = (int) (91.284-(48.787)-(tcb->m_ssThresh));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (93.218*(62.037)*(73.708));

}
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (36.134+(57.11));
	segmentsAcked = (int) (1.01*(segmentsAcked)*(10.005)*(21.168));

} else {
	tcb->m_ssThresh = (int) (78.769+(69.925)+(tcb->m_cWnd));
	segmentsAcked = (int) (zKfmstlHxhwKGcvq+(61.063)+(47.664)+(45.225));
	zKfmstlHxhwKGcvq = (int) ((tcb->m_segmentSize-(11.83)-(51.136))/56.857);

}
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (29.767/76.356);
	tcb->m_ssThresh = (int) (2.809-(13.7));
	zKfmstlHxhwKGcvq = (int) (tcb->m_segmentSize+(51.223));

} else {
	tcb->m_segmentSize = (int) (59.543-(72.209)-(61.325)-(63.888)-(37.451));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
