if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (37.991-(34.175)-(68.827));

} else {
	tcb->m_cWnd = (int) (49.285+(21.249)+(84.687));

}
segmentsAcked = (int) (tcb->m_segmentSize+(0.852));
if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_cWnd = (int) (((64.614)+(0.1)+(72.865)+((27.734-(44.98)-(43.499)-(44.659)-(19.654)))+(0.1))/((21.52)+(28.774)+(52.354)));
	tcb->m_cWnd = (int) (0.1/53.368);
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(21.828)+(62.356)+(0.1)+(98.169))/((17.243)+(0.1)+(0.1)));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(76.816)-(tcb->m_segmentSize));
	segmentsAcked = (int) (tcb->m_segmentSize-(55.843)-(39.773)-(21.027));

}
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (94.952/50.688);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (93.423+(3.181));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (46.894-(23.777)-(38.448)-(88.292)-(segmentsAcked));

}
