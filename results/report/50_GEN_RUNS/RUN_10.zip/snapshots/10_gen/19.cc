if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (50.656*(0.352)*(21.091)*(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) ((13.373*(60.274))/(67.166*(83.342)*(11.158)));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(13.305)+(51.954)+(92.475));
ReduceCwnd (tcb);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd-(84.511)-(99.332)-(36.173)-(55.455)-(94.338)-(tcb->m_ssThresh));
	segmentsAcked = (int) (75.245-(7.397));

} else {
	segmentsAcked = (int) (96.348+(30.94)+(67.498));
	tcb->m_segmentSize = (int) (73.992+(16.191)+(tcb->m_segmentSize));

}
