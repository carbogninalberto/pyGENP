tcb->m_cWnd = (int) (((0.711)+(76.515)+(-68.695)+(-36.389))/((37.777)+(89.015)+(82.827)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-54.385+(-66.994));
segmentsAcked = (int) (-73.751+(48.655)+(-60.055)+(3.08)+(-43.609)+(36.86)+(-20.614)+(-63.637)+(-27.013));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-18.048+(-54.906));
segmentsAcked = (int) (-48.641+(-17.567)+(77.46)+(-77.749)+(-61.885)+(84.226)+(-19.014)+(-78.095)+(-20.822));
CongestionAvoidance (tcb, segmentsAcked);
