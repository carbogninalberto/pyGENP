tcb->m_cWnd = (int) (((87.233)+(16.66)+(66.979)+(-11.816))/((-28.501)+(-12.289)+(11.665)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (33.545+(12.565));
segmentsAcked = (int) (-85.953+(-36.905)+(67.031)+(-31.092)+(-53.223)+(95.569)+(30.046)+(-58.649)+(-16.028));
CongestionAvoidance (tcb, segmentsAcked);
