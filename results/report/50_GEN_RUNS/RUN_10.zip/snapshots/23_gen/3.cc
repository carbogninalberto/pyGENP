tcb->m_cWnd = (int) (((31.386)+(-2.056)+(-96.795)+(-0.267))/((97.089)+(52.346)+(17.647)));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (66.54+(-67.769));
segmentsAcked = (int) (-49.876+(-42.587)+(-35.239)+(-81.969)+(-49.262)+(-91.646)+(75.186)+(41.827)+(-94.287));
CongestionAvoidance (tcb, segmentsAcked);
