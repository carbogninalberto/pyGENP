tcb->m_cWnd = (int) (((-61.719)+(99.997)+(-82.692)+(-93.033))/((16.885)+(53.037)+(-17.805)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-2.815+(30.921));
segmentsAcked = (int) (25.119+(9.179)+(33.934)+(-53.176)+(-25.078)+(-14.428)+(84.753)+(-67.296)+(-91.281));
CongestionAvoidance (tcb, segmentsAcked);
