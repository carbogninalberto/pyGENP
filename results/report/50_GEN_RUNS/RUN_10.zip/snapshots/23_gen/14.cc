tcb->m_cWnd = (int) (((32.322)+(68.854)+(13.863)+(-37.562))/((-87.387)+(-9.578)+(50.971)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (12.075+(-38.414));
segmentsAcked = (int) (89.698+(-90.582)+(70.649)+(-73.667)+(14.172)+(-76.063)+(-13.128)+(-67.146)+(48.757));
CongestionAvoidance (tcb, segmentsAcked);
