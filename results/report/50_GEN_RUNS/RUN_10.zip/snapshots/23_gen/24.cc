tcb->m_cWnd = (int) (((51.065)+(72.273)+(-12.808)+(-22.14))/((-86.253)+(-66.391)+(34.979)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (14.929+(92.495));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (64.404+(-27.229)+(23.949)+(-64.894)+(-14.498)+(44.95)+(-8.811)+(-27.528)+(63.247));
CongestionAvoidance (tcb, segmentsAcked);
