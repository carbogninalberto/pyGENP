tcb->m_cWnd = (int) (((81.976)+(4.293)+(-9.082)+(-85.966))/((-47.712)+(40.718)+(84.949)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-96.169+(90.444));
segmentsAcked = (int) (88.472+(97.655)+(27.001)+(-82.399)+(-91.704)+(-78.511)+(82.7)+(14.32)+(-62.869));
CongestionAvoidance (tcb, segmentsAcked);
