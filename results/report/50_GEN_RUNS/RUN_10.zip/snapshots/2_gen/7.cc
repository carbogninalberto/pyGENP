tcb->m_segmentSize = (int) (-62.483/-62.272);
tcb->m_segmentSize = (int) (5.91+(-20.376)+(65.083)+(53.002)+(77.968)+(97.361));
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (86.436/(40.155*(54.479)*(tcb->m_ssThresh)));

} else {
	tcb->m_cWnd = (int) (41.083/0.1);

}
segmentsAcked = (int) (86.682-(97.499)-(80.766)-(43.945)-(-20.987));
segmentsAcked = (int) (8.252+(-23.784)+(94.16)+(11.046)+(-36.022)+(-48.683)+(-82.65));
