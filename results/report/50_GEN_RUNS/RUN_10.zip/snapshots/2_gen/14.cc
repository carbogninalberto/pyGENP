tcb->m_cWnd = (int) (-99.118-(-64.758)-(-30.748)-(-44.133)-(74.503)-(39.683)-(-16.551)-(89.384)-(1.277));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (2.433-(45.821)-(26.47)-(48.632)-(62.836)-(94.689)-(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (9.319+(76.381)+(81.713)+(61.041)+(13.729)+(39.602)+(19.209)+(74.795));
	tcb->m_segmentSize = (int) (12.695-(5.442)-(25.653)-(93.611));

} else {
	tcb->m_cWnd = (int) ((21.857*(96.207)*(48.218)*(71.578)*(24.579)*(11.003)*(40.11))/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) ((6.058-(19.444)-(tcb->m_segmentSize))/0.1);

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-31.208-(-27.088));
