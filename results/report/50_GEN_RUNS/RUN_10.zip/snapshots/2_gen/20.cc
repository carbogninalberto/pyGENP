CongestionAvoidance (tcb, segmentsAcked);
float sOPzmgDYXJfqrKai = (float) (68.811/64.916);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
