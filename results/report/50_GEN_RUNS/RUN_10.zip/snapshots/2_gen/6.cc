segmentsAcked = SlowStart (tcb, segmentsAcked);
int gycNckcSzcMTUyJr = (int) (4.439-(35.118)-(61.453)-(-6.844));
tcb->m_cWnd = (int) (-5.626-(79.698)-(40.595)-(30.483)-(43.043)-(-24.24));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (15.689*(73.711)*(67.476)*(-3.405)*(23.734)*(-86.703)*(64.101));
CongestionAvoidance (tcb, segmentsAcked);
