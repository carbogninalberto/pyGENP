TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-1.535/96.91);
tcb->m_segmentSize = (int) (-76.249+(85.566)+(0.601)+(-48.047)+(-79.361)+(3.044));
tcb->m_segmentSize = (int) (-33.266+(-75.511)+(-69.263)+(78.166)+(70.048)+(-15.183));
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (41.083/0.1);

} else {
	tcb->m_cWnd = (int) (86.436/(40.155*(54.479)*(tcb->m_ssThresh)));

}
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (86.436/(40.155*(54.479)*(tcb->m_ssThresh)));

} else {
	tcb->m_cWnd = (int) (41.083/0.1);

}
segmentsAcked = (int) (68.024-(66.713)-(53.348)-(84.942)-(-80.295));
segmentsAcked = (int) (57.661-(41.094)-(-66.813)-(98.746)-(-73.774));
segmentsAcked = (int) (34.754+(-45.023)+(75.393)+(-42.89)+(89.422)+(68.255)+(-48.3));
segmentsAcked = (int) (99.938+(18.741)+(-56.247)+(94.608)+(6.246)+(-40.752)+(-24.29));
