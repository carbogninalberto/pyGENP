tcb->m_segmentSize = (int) (35.004/93.634);
