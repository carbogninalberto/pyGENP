float MzQHhAVUpULHUQLx = (float) (-72.453*(-55.56)*(-21.722)*(50.055)*(-16.204)*(-83.416)*(-77.79)*(28.595)*(49.4));
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(98.114));
	segmentsAcked = (int) (0.1/0.1);
	MzQHhAVUpULHUQLx = (float) (52.555/0.1);

}
tcb->m_segmentSize = (int) (-72.158*(-76.415)*(-58.673)*(-6.475)*(26.958)*(62.985)*(-66.377)*(48.352));
MzQHhAVUpULHUQLx = (float) (22.345-(38.05)-(14.041)-(-79.487)-(-64.673)-(8.641)-(-72.02)-(63.342)-(-66.306));
tcb->m_cWnd = (int) (-69.134+(34.516)+(-37.911)+(59.251)+(-80.065)+(-46.891)+(75.742)+(-80.412));
