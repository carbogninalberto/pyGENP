float YZFwyKmaTdBwOJKt = (float) (((-2.243)+(-76.593)+((29.623*(87.06)*(93.603)*(-41.317)*(7.186)*(71.943)))+(26.636)+(-0.118)+(-43.751)+(-43.832))/((-71.245)+(-59.863)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (((33.26)+((94.377-(56.278)-(29.156)))+(-4.691)+(-94.169))/((-68.989)+(-72.373)+(28.256)));
tcb->m_cWnd = (int) (-88.063+(17.847)+(82.821)+(13.341)+(-31.484));
if (tcb->m_cWnd == tcb->m_cWnd) {
	YZFwyKmaTdBwOJKt = (float) (14.669+(-91.972)+(81.939)+(segmentsAcked)+(15.417)+(32.291));
	ReduceCwnd (tcb);

} else {
	YZFwyKmaTdBwOJKt = (float) ((57.048+(36.781)+(YZFwyKmaTdBwOJKt))/44.784);
	segmentsAcked = (int) (11.504+(72.093)+(31.363)+(tcb->m_segmentSize)+(27.082)+(3.595)+(70.568));

}
