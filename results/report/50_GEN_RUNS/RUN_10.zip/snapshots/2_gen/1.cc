float lKPNhBIwuxkMkCJG = (float) (-49.825*(-57.819));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
lKPNhBIwuxkMkCJG = (float) (82.957*(10.766)*(43.175)*(-9.878)*(-55.959)*(58.869)*(69.522)*(93.415));
segmentsAcked = (int) (-71.906-(-49.274)-(-33.42)-(16.478)-(-7.91)-(16.16));
