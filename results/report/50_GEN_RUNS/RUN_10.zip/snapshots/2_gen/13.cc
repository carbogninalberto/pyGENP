float PmkIrmoHvuqwnqXe = (float) (66.237-(61.391)-(61.68)-(-50.116)-(85.826)-(-17.946)-(93.333));
int dRMJkANVTpNxuEDn = (int) (10.402-(31.784)-(-93.82)-(99.019)-(40.817));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
