float PmkIrmoHvuqwnqXe = (float) (68.596-(-57.181)-(-49.476)-(-42.757)-(44.123)-(94.069)-(-97.56));
int dRMJkANVTpNxuEDn = (int) (43.989-(38.7)-(73.087)-(-35.95)-(-35.25));
tcb->m_cWnd = (int) (((-65.053)+(79.081)+(-8.738)+(14.864))/((-88.209)+(9.331)+(-8.238)+(49.452)+(36.122)));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
