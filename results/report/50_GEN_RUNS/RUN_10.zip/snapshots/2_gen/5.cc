if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (((77.883)+(77.127)+(85.5)+(0.1))/((92.154)+(0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (83.395/69.987);

}
