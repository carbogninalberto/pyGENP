float MIyIxVehkQfwPLwJ = (float) (-3.139+(-42.25)+(-27.494)+(-90.518)+(63.381)+(-89.603)+(-49.124));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (8.657*(92.706)*(1.907)*(-0.868)*(1.152)*(-65.268)*(-69.1)*(-48.229));
