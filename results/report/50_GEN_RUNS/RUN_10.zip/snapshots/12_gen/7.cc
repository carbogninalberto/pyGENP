float MIyIxVehkQfwPLwJ = (float) (-41.329+(48.538)+(-37.35)+(-66.208)+(8.274)+(21.663)+(88.158));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-54.828*(-92.515)*(34.205)*(39.438)*(-59.453)*(-39.997)*(-78.624)*(-78.978));
segmentsAcked = (int) (20.537*(-52.329)*(-18.292)*(-92.148)*(-96.049)*(-79.566)*(-94.372)*(-46.983));
