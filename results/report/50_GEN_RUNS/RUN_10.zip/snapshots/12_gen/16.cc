float vDmobbGLdbDXRlQN = (float) (87.129/75.805);
if (tcb->m_cWnd > vDmobbGLdbDXRlQN) {
	tcb->m_segmentSize = (int) (99.955+(vDmobbGLdbDXRlQN));
	tcb->m_ssThresh = (int) (22.382+(36.954)+(71.392)+(63.949)+(42.391));

} else {
	tcb->m_segmentSize = (int) (92.248*(63.321));
	tcb->m_segmentSize = (int) (68.274+(22.671)+(tcb->m_cWnd)+(84.48));

}
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (27.497+(38.728)+(64.72)+(tcb->m_ssThresh)+(99.153));
	segmentsAcked = (int) (48.456*(99.757)*(54.031)*(tcb->m_cWnd)*(4.086)*(81.18));
	tcb->m_ssThresh = (int) (39.447+(vDmobbGLdbDXRlQN)+(segmentsAcked)+(76.356)+(86.896)+(tcb->m_segmentSize)+(75.905));

} else {
	tcb->m_ssThresh = (int) (((0.1)+((4.789+(26.097)+(89.819)))+(0.1)+(0.1))/((2.984)+(0.1)+(0.1)+(0.1)+(56.943)));
	tcb->m_cWnd = (int) (91.485*(17.019)*(81.942)*(1.157));

}
tcb->m_ssThresh = (int) (30.499+(69.536)+(90.728)+(36.773)+(59.799));
vDmobbGLdbDXRlQN = (float) (12.372+(6.772)+(83.806)+(69.937)+(68.529)+(segmentsAcked)+(32.887)+(23.273)+(83.907));
ReduceCwnd (tcb);
int QoceCqIGfMiJUrID = (int) (0.148+(27.352)+(tcb->m_ssThresh)+(90.704));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	segmentsAcked = (int) (89.799-(tcb->m_segmentSize)-(3.99)-(62.391)-(33.827)-(69.974));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (99.905*(79.677));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
