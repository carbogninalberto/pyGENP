tcb->m_ssThresh = (int) (25.326-(79.762)-(45.344));
int rPkPERNKFxcKwIgj = (int) (8.48-(84.433)-(85.932)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(16.849));
tcb->m_cWnd = (int) (24.815-(segmentsAcked)-(tcb->m_cWnd)-(tcb->m_ssThresh));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (94.56/61.193);
rPkPERNKFxcKwIgj = (int) (35.001-(92.101)-(tcb->m_cWnd)-(30.315)-(37.031)-(2.347)-(43.2));
