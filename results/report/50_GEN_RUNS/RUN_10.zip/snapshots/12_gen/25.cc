ReduceCwnd (tcb);
float xqkCytGNrfwcQGnh = (float) (21.274-(26.386)-(29.058)-(67.534)-(14.909)-(31.591)-(63.266)-(28.529));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	xqkCytGNrfwcQGnh = (float) (44.475+(29.849)+(96.049)+(74.067)+(39.598)+(23.583)+(20.671)+(98.951)+(45.687));
	segmentsAcked = (int) (5.121+(81.068)+(57.232)+(97.747)+(xqkCytGNrfwcQGnh)+(93.265));
	tcb->m_segmentSize = (int) (6.473-(tcb->m_segmentSize)-(43.98)-(5.242)-(tcb->m_segmentSize)-(segmentsAcked));

} else {
	xqkCytGNrfwcQGnh = (float) (87.122+(30.617)+(43.776)+(40.612)+(26.576)+(12.154)+(76.565)+(47.607));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (xqkCytGNrfwcQGnh > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (27.686-(segmentsAcked)-(28.665));
	tcb->m_cWnd = (int) (69.886-(75.137)-(76.49)-(20.989)-(98.247)-(34.516));

} else {
	tcb->m_ssThresh = (int) (94.19-(4.013)-(68.559));

}
