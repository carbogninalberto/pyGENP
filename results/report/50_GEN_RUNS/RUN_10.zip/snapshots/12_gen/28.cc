segmentsAcked = (int) (25.868-(tcb->m_cWnd)-(tcb->m_cWnd)-(32.057));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (57.495-(86.129)-(11.344));
	tcb->m_cWnd = (int) ((33.279-(23.158)-(58.03)-(46.323)-(59.046)-(54.951)-(85.035))/33.859);
	tcb->m_cWnd = (int) (8.403*(67.846)*(7.121)*(79.444)*(86.95));

} else {
	tcb->m_segmentSize = (int) (58.317*(29.593)*(28.966)*(tcb->m_cWnd)*(81.36)*(45.257)*(83.824));
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(87.831)*(21.26)*(tcb->m_segmentSize)*(88.157)*(87.46)*(65.932));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (7.665+(tcb->m_segmentSize));
tcb->m_ssThresh = (int) (19.164*(segmentsAcked)*(segmentsAcked)*(79.031)*(56.748)*(2.037)*(95.373));
