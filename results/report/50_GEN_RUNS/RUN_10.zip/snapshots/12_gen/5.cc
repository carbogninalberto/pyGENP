float EQRhefWGMquCWvVg = (float) (-27.947-(63.338));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	segmentsAcked = (int) (21.823-(79.726)-(37.11));
	EQRhefWGMquCWvVg = (float) (14.844-(tcb->m_segmentSize)-(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (-66.985+(EQRhefWGMquCWvVg)+(46.989)+(85.877)+(79.925));

}
tcb->m_cWnd = (int) (50.265+(93.086)+(-98.915)+(90.79)+(90.665));
