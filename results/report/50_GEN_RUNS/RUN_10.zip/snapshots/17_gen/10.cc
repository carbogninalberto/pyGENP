float MIyIxVehkQfwPLwJ = (float) (-97.79+(70.349)+(2.679)+(75.91)+(21.799)+(-14.685)+(-78.366));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-27.858*(21.26)*(32.016)*(27.301)*(-34.122)*(-41.86)*(10.664)*(-11.802));
ReduceCwnd (tcb);
segmentsAcked = (int) (11.997*(96.457)*(83.079)*(62.37)*(64.429)*(-86.821)*(-35.131)*(13.847));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (39.846*(-71.629)*(49.079)*(-25.019)*(84.086)*(12.055)*(-34.785)*(30.479));
