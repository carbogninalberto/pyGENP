tcb->m_segmentSize = (int) (24.531-(31.121)-(30.083)-(tcb->m_ssThresh)-(11.586)-(70.104)-(91.774)-(17.288)-(63.348));
if (segmentsAcked == segmentsAcked) {
	tcb->m_cWnd = (int) (82.588*(5.612));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (0.1/(73.274+(40.087)+(71.77)));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (17.876+(9.611));

}
if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(tcb->m_segmentSize)-(78.258)-(64.806)-(93.864)-(tcb->m_cWnd)-(99.193)-(72.806));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(19.725)*(79.478)*(63.918)*(57.673)*(42.7)*(94.878));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
