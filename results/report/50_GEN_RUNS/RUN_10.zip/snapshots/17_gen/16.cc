segmentsAcked = (int) (-84.801+(84.023)+(-21.408)+(-70.669)+(32.219));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (31.06-(tcb->m_cWnd)-(-5.188)-(16.273)-(97.649)-(25.193)-(28.965)-(75.193));

} else {
	tcb->m_segmentSize = (int) (74.179-(-18.676)-(58.789)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (63.215*(67.732)*(34.206)*(94.877));

}
segmentsAcked = (int) (-30.01-(-44.801)-(-94.323)-(88.502)-(19.053)-(12.612)-(91.271)-(-71.847)-(-23.12));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (14.207-(62.026)-(-70.538)-(-26.026)-(-74.169)-(-99.48)-(89.21)-(64.133)-(-68.558));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
