if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (4.968-(9.574)-(14.782)-(77.442)-(42.18)-(69.645)-(17.197)-(tcb->m_segmentSize)-(25.76));
	tcb->m_cWnd = (int) (96.704*(54.512)*(22.89)*(23.48)*(5.36)*(segmentsAcked)*(86.698)*(55.301)*(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (84.633+(59.975));
	segmentsAcked = (int) (73.535/53.824);
	tcb->m_cWnd = (int) ((53.828*(60.232)*(tcb->m_segmentSize)*(75.235)*(tcb->m_ssThresh))/31.034);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_segmentSize = (int) (0.1/8.666);
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (41.602+(tcb->m_cWnd)+(91.047)+(76.496)+(tcb->m_ssThresh)+(75.983));

} else {
	tcb->m_segmentSize = (int) (0.1/93.158);
	tcb->m_segmentSize = (int) (((67.902)+(43.507)+((segmentsAcked+(20.723)+(44.214)+(58.492)+(31.249)+(tcb->m_segmentSize)+(36.129)+(tcb->m_segmentSize)))+((tcb->m_ssThresh-(35.962)-(86.413)-(68.607)))+(0.1))/((0.1)+(0.1)+(0.1)+(66.644)));
	tcb->m_ssThresh = (int) (11.715-(tcb->m_cWnd)-(66.02)-(tcb->m_segmentSize)-(50.676)-(88.564)-(95.901)-(35.658));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (25.954/27.066);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(60.154)+(segmentsAcked)+(26.256));
	ReduceCwnd (tcb);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
