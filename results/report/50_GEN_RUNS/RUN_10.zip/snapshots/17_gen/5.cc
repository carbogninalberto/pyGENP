if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (16.726*(85.849));
	segmentsAcked = (int) (36.014*(77.615));

} else {
	tcb->m_cWnd = (int) (0.1/96.582);

}
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (74.179-(-18.676)-(58.789)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (63.215*(67.732)*(34.206)*(94.877));

} else {
	tcb->m_segmentSize = (int) (31.06-(tcb->m_cWnd)-(-5.188)-(16.273)-(97.649)-(25.193)-(28.965)-(75.193));

}
segmentsAcked = (int) (-47.902-(-21.116)-(63.161)-(-0.572)-(86.653)-(-90.325)-(84.803)-(41.939)-(-16.74));
segmentsAcked = (int) (-74.376-(10.89)-(-46.174)-(-26.163)-(-16.137)-(-68.087)-(27.554)-(-88.065)-(33.202));
