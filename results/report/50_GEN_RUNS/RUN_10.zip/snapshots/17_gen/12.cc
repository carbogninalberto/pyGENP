float MIyIxVehkQfwPLwJ = (float) (10.586+(-9.258)+(64.477)+(30.522)+(-84.785)+(-47.42)+(-72.028));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (80.213*(11.572)*(56.714)*(94.91)*(46.154)*(-14.792)*(-76.358)*(29.516));
