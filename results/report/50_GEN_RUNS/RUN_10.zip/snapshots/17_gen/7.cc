float mVsDybfzdUnGvKVZ = (float) (90.785+(-97.16));
segmentsAcked = (int) (-51.838+(-31.662)+(-39.194));
segmentsAcked = (int) (-43.369-(41.7)-(-93.682)-(-62.57)-(17.4)-(-27.966)-(-22.455)-(27.86)-(-32.912));
segmentsAcked = SlowStart (tcb, segmentsAcked);
