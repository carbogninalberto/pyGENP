tcb->m_segmentSize = (int) (89.415*(52.37)*(44.272));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (14.807-(-41.823)-(-17.235)-(75.312)-(15.98)-(-51.614)-(-14.362)-(-27.895)-(95.457));
segmentsAcked = SlowStart (tcb, segmentsAcked);
