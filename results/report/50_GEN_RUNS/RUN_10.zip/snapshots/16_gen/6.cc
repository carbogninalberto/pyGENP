float htkUNndZqIcOIXiO = (float) (26.117*(-87.442)*(58.936)*(-41.751));
