float MIyIxVehkQfwPLwJ = (float) (-23.156+(28.921)+(-8.759)+(87.75)+(-10.348)+(80.167)+(-6.194));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-17.878*(-57.055)*(58.755)*(-84.226)*(76.225)*(62.762)*(-21.006)*(-99.824));
segmentsAcked = (int) (9.559*(95.871)*(-14.522)*(-38.683)*(-83.294)*(61.973)*(90.316)*(7.233));
