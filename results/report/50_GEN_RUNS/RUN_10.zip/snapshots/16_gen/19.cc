float MIyIxVehkQfwPLwJ = (float) (-66.861+(-47.677)+(11.758)+(-35.841)+(82.051)+(27.985)+(-53.266));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-6.785*(89.449)*(-74.609)*(52.4)*(39.773)*(96.574)*(99.59)*(-40.181));
