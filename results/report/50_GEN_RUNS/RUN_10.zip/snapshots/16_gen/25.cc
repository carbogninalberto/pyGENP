float mVsDybfzdUnGvKVZ = (float) 49.191;
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (79.587-(32.516)-(15.225)-(-14.436)-(-3.934)-(93.722)-(-50.885)-(-76.823)-(87.346));
segmentsAcked = SlowStart (tcb, segmentsAcked);
