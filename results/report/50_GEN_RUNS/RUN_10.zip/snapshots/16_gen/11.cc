tcb->m_segmentSize = (int) (-35.361+(-39.123)+(90.515));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (31.06-(tcb->m_cWnd)-(-5.188)-(16.273)-(97.649)-(25.193)-(28.965)-(75.193));

} else {
	tcb->m_segmentSize = (int) (74.179-(-18.676)-(58.789)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (63.215*(67.732)*(34.206)*(94.877));

}
segmentsAcked = (int) (63.283-(-19.843)-(15.752)-(-50.624)-(-83.218)-(-11.442)-(-93.094)-(-83.937)-(65.536));
segmentsAcked = (int) (0.719-(70.696)-(-82.044)-(99.676)-(61.846)-(-49.409)-(-55.221)-(98.024)-(15.116));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
