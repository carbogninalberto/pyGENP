if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (16.896-(62.317)-(75.394)-(19.589)-(84.574)-(11.638));

} else {
	tcb->m_cWnd = (int) (32.372-(41.803));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-41.879-(43.184)-(-45.509)-(0.395)-(-11.747)-(-24.257)-(22.106)-(-59.211));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (25.399-(-44.909)-(49.121));
