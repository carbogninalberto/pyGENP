ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
