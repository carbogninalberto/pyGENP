segmentsAcked = SlowStart (tcb, segmentsAcked);
float MIyIxVehkQfwPLwJ = (float) (-39.979+(-86.267)+(-52.14)+(-55.16)+(44.04)+(-49.925)+(-8.134));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (87.672*(-88.086)*(98.676)*(61.674)*(19.155)*(62.753)*(14.535)*(-0.886));
ReduceCwnd (tcb);
segmentsAcked = (int) (-26.552*(91.632)*(41.353)*(96.254)*(48.572)*(78.34)*(-72.524)*(-65.734));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (81.449*(-83.274)*(-31.263)*(99.396)*(7.582)*(-7.735)*(-89.53)*(23.547));
