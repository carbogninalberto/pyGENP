CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked == segmentsAcked) {
	tcb->m_cWnd = (int) (60.432-(32.627)-(53.61)-(57.528)-(60.557)-(56.435));

} else {
	tcb->m_cWnd = (int) (3.102+(67.67)+(-96.988));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
