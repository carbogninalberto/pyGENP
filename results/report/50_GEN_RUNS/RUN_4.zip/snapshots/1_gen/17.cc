tcb->m_cWnd = (int) (tcb->m_cWnd+(41.838)+(91.74)+(segmentsAcked)+(50.025)+(89.988)+(tcb->m_segmentSize));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (40.158/56.41);
segmentsAcked = (int) (((11.133)+(0.1)+(0.1)+(0.1)+(35.369)+((18.193+(55.509)))+(0.1))/((0.1)+(0.1)));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
