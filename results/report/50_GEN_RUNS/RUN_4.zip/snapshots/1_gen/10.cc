ReduceCwnd (tcb);
float TJqWqvsovmupFtRO = (float) (97.412-(tcb->m_segmentSize)-(42.225)-(57.14)-(42.925)-(26.514)-(7.229)-(43.523)-(66.969));
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (55.001+(59.498)+(TJqWqvsovmupFtRO)+(TJqWqvsovmupFtRO)+(43.477)+(10.641)+(31.422)+(33.71)+(11.576));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (10.97*(85.119)*(36.204)*(53.728)*(76.631)*(90.771)*(8.948)*(79.437));

} else {
	tcb->m_cWnd = (int) (12.331+(70.53)+(segmentsAcked)+(tcb->m_cWnd)+(48.346)+(66.244)+(21.461)+(87.255));
	tcb->m_cWnd = (int) (8.875-(92.392)-(93.838)-(81.013)-(86.857)-(1.124)-(33.456)-(83.749));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	TJqWqvsovmupFtRO = (float) (86.457*(27.142));
	TJqWqvsovmupFtRO = (float) (tcb->m_segmentSize*(tcb->m_segmentSize));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	TJqWqvsovmupFtRO = (float) (segmentsAcked+(56.564)+(69.756)+(32.41)+(79.143)+(0.167)+(53.955)+(45.784)+(13.122));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (91.915/97.427);

}
if (tcb->m_cWnd < TJqWqvsovmupFtRO) {
	tcb->m_cWnd = (int) (22.833*(segmentsAcked)*(56.366)*(60.901)*(3.65));

} else {
	tcb->m_cWnd = (int) (39.226+(96.816)+(67.705)+(3.896));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (TJqWqvsovmupFtRO <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(77.678))/((38.952)+(0.1)));
	TJqWqvsovmupFtRO = (float) (66.505-(57.189)-(89.596)-(96.824)-(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (32.202/86.012);

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (9.046+(tcb->m_segmentSize)+(60.246)+(80.066));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (29.295-(78.78)-(56.395)-(tcb->m_ssThresh)-(29.879)-(segmentsAcked)-(64.78));

}
tcb->m_segmentSize = (int) (29.942+(tcb->m_ssThresh)+(62.135)+(27.596)+(95.461));
segmentsAcked = SlowStart (tcb, segmentsAcked);
