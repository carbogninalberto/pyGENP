ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	segmentsAcked = (int) (9.758-(9.442)-(84.028)-(38.304)-(14.274)-(segmentsAcked));
	tcb->m_segmentSize = (int) (15.056*(84.457)*(95.167)*(tcb->m_ssThresh)*(4.364)*(61.749));

} else {
	segmentsAcked = (int) (41.154*(segmentsAcked)*(segmentsAcked)*(tcb->m_cWnd)*(27.718)*(24.554));
	tcb->m_cWnd = (int) (20.688-(8.228)-(14.052)-(tcb->m_cWnd)-(44.2)-(89.305)-(tcb->m_segmentSize)-(27.516));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
int NNuANxVFAAycieJp = (int) (tcb->m_segmentSize+(94.979)+(tcb->m_segmentSize)+(38.362)+(25.114));
tcb->m_ssThresh = (int) (0.1/52.522);
int JGcYyBLfEMzqKKkh = (int) (NNuANxVFAAycieJp+(66.458)+(35.907));
if (tcb->m_cWnd >= NNuANxVFAAycieJp) {
	tcb->m_segmentSize = (int) (99.668*(84.316)*(39.034)*(JGcYyBLfEMzqKKkh)*(tcb->m_ssThresh)*(90.327)*(29.805)*(1.147));
	NNuANxVFAAycieJp = (int) (((0.1)+(0.1)+((51.123+(63.257)+(tcb->m_cWnd)+(56.791)+(80.75)))+(23.007)+(0.1))/((0.1)+(0.1)+(0.1)+(78.607)));

} else {
	tcb->m_segmentSize = (int) (76.622*(22.648)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(43.221)*(99.807));
	CongestionAvoidance (tcb, segmentsAcked);

}
