tcb->m_segmentSize = (int) (15.563*(segmentsAcked)*(5.937)*(12.412)*(44.459)*(69.056)*(75.839));
tcb->m_ssThresh = (int) (72.236-(4.604)-(23.823));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (segmentsAcked+(10.681)+(20.086)+(tcb->m_cWnd)+(71.428)+(99.689)+(tcb->m_cWnd)+(82.741)+(30.944));
tcb->m_segmentSize = (int) (0.1/0.1);
