segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(tcb->m_segmentSize));
ReduceCwnd (tcb);
float ECnPeyCRmsIXOKbv = (float) (56.031*(34.253)*(48.798)*(56.109)*(54.826)*(21.472)*(33.056)*(54.319)*(36.517));
tcb->m_ssThresh = (int) (0.445*(76.185)*(26.769)*(4.634));
tcb->m_cWnd = (int) (12.441*(28.137));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd > ECnPeyCRmsIXOKbv) {
	segmentsAcked = (int) (3.104*(63.758)*(70.215)*(10.998));

} else {
	segmentsAcked = (int) (68.649*(3.685)*(tcb->m_ssThresh)*(segmentsAcked)*(tcb->m_cWnd));
	tcb->m_cWnd = (int) (4.979-(6.309));

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
