segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (segmentsAcked*(35.708)*(61.436)*(88.229)*(92.661)*(58.063));
tcb->m_cWnd = (int) (77.215*(43.837)*(88.9)*(94.012)*(segmentsAcked)*(7.364)*(2.918)*(24.86)*(tcb->m_ssThresh));
segmentsAcked = (int) (tcb->m_cWnd-(16.246)-(segmentsAcked));
segmentsAcked = SlowStart (tcb, segmentsAcked);
