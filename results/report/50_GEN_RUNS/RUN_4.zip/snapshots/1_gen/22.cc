CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (0.1/64.517);
segmentsAcked = (int) (19.514+(48.499)+(segmentsAcked));
tcb->m_ssThresh = (int) (4.921*(75.294));
tcb->m_ssThresh = (int) (9.903+(82.907)+(93.924)+(95.853)+(57.965)+(37.746));
ReduceCwnd (tcb);
