tcb->m_segmentSize = (int) (79.42+(94.459)+(49.634));
tcb->m_segmentSize = (int) (85.08+(60.998)+(13.707)+(70.782)+(97.002)+(tcb->m_ssThresh)+(61.967)+(25.402));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked == segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(75.183));
	tcb->m_segmentSize = (int) (49.183*(4.874)*(7.764)*(51.953)*(31.564)*(51.267)*(63.156)*(98.285)*(25.986));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(9.41)*(70.732)*(87.514)*(11.569));
	segmentsAcked = (int) (6.169+(11.407)+(tcb->m_cWnd)+(23.529)+(18.039));

}
