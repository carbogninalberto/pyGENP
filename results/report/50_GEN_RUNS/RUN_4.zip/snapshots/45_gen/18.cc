ReduceCwnd (tcb);
tcb->m_cWnd = (int) (93.273+(25.657)+(segmentsAcked)+(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (63.968-(6.266));
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_segmentSize = (int) (28.448+(71.859)+(20.329)+(85.106)+(92.57)+(24.366)+(segmentsAcked)+(tcb->m_ssThresh)+(0.734));

} else {
	tcb->m_segmentSize = (int) (((33.007)+(49.617)+(0.1)+(0.1)+(17.765)+(14.438))/((43.605)+(75.976)));
	tcb->m_cWnd = (int) (((48.08)+(0.1)+(0.1)+(29.067)+(0.1))/((22.754)+(57.366)+(0.1)));

}
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	segmentsAcked = (int) (0.1/74.393);
	tcb->m_cWnd = (int) (85.311/85.509);
	tcb->m_ssThresh = (int) (23.599*(36.715)*(80.341));

} else {
	segmentsAcked = (int) (tcb->m_cWnd+(segmentsAcked)+(26.889)+(97.44)+(41.476));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_cWnd = (int) (23.978-(segmentsAcked)-(56.548)-(19.495)-(tcb->m_cWnd)-(tcb->m_cWnd)-(84.01)-(70.525));
	tcb->m_ssThresh = (int) (segmentsAcked-(69.82)-(segmentsAcked)-(23.372)-(27.748)-(tcb->m_ssThresh)-(25.632)-(tcb->m_ssThresh)-(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (45.356-(52.295)-(tcb->m_cWnd)-(94.364));
	tcb->m_segmentSize = (int) (24.532-(86.836)-(28.661)-(tcb->m_cWnd));

}
tcb->m_ssThresh = (int) (50.291*(tcb->m_segmentSize)*(tcb->m_cWnd)*(5.728)*(93.926)*(67.059)*(segmentsAcked)*(33.738));
