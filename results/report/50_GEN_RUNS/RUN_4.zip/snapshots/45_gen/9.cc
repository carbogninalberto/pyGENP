ReduceCwnd (tcb);
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (90.851*(tcb->m_ssThresh)*(86.413)*(70.892));
	segmentsAcked = (int) (85.183+(tcb->m_segmentSize)+(22.424)+(95.515)+(37.148));

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((77.81)));
	tcb->m_segmentSize = (int) (91.24/0.1);
	segmentsAcked = (int) (10.487*(45.981)*(8.756)*(94.987));

}
tcb->m_ssThresh = (int) (((96.035)+(0.1)+(71.64)+(27.058))/((0.1)+(72.049)+(46.548)+(0.1)+(0.1)));
int btIwXkWJaCJSmzFb = (int) (0.1/82.128);
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (14.519+(tcb->m_cWnd)+(51.885)+(39.095)+(1.123)+(83.581)+(98.587)+(69.595));

} else {
	tcb->m_ssThresh = (int) (61.756-(17.853)-(tcb->m_ssThresh)-(82.881)-(tcb->m_cWnd)-(27.201)-(30.024));
	segmentsAcked = (int) (tcb->m_cWnd-(92.915)-(tcb->m_cWnd)-(btIwXkWJaCJSmzFb)-(43.763)-(68.409)-(6.357)-(82.13));
	tcb->m_segmentSize = (int) (0.1/80.762);

}
segmentsAcked = (int) (tcb->m_cWnd*(21.405)*(80.016)*(82.957));
