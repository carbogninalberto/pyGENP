if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (73.077+(65.833)+(67.319)+(39.103)+(24.699)+(20.982)+(68.185)+(16.028)+(41.977));

} else {
	segmentsAcked = (int) (96.606+(segmentsAcked)+(tcb->m_segmentSize)+(77.906)+(13.34));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (19.832+(82.266)+(33.729)+(43.014)+(29.657)+(84.893)+(46.313)+(50.76)+(5.576));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(tcb->m_segmentSize)-(1.402)-(18.691)-(56.613)-(tcb->m_segmentSize)-(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (64.244*(57.577)*(25.853)*(20.215));

} else {
	tcb->m_ssThresh = (int) (29.884-(94.729)-(tcb->m_ssThresh)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (19.759*(24.323)*(tcb->m_cWnd));
	tcb->m_cWnd = (int) (28.589-(79.51)-(tcb->m_segmentSize)-(33.053)-(94.039)-(76.992)-(47.135)-(52.163));

}
tcb->m_ssThresh = (int) (3.454*(37.827)*(55.232)*(49.384)*(tcb->m_cWnd));
