int FUatjJzUgydhVHSm = (int) (29.523-(90.96)-(-56.3)-(11.053));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int nrDtUhElczMNSvxJ = (int) (-58.55/46.029);
segmentsAcked = (int) (-37.579/-28.339);
