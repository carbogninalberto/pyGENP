if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_cWnd = (int) (40.509+(53.658)+(21.304)+(52.923)+(78.298)+(29.846)+(tcb->m_segmentSize)+(1.845)+(20.106));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (37.261+(31.574)+(34.596)+(1.988));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(73.124)+(50.718)+(segmentsAcked)+(tcb->m_cWnd)+(25.675));
	tcb->m_segmentSize = (int) (89.034/0.1);

}
tcb->m_cWnd = (int) (58.101+(38.882)+(18.117)+(-90.962)+(-53.114)+(-47.218)+(62.033));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (20.144*(-28.291)*(-48.468)*(-47.111)*(68.398));
