if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (68.195+(70.134)+(28.988));
	segmentsAcked = (int) (40.512*(tcb->m_cWnd)*(76.518)*(96.309));
	segmentsAcked = (int) (1.344+(23.078)+(74.093)+(57.443)+(56.793)+(9.398)+(71.137)+(79.368));

} else {
	tcb->m_cWnd = (int) (((6.449)+((tcb->m_cWnd+(11.467)+(34.621)+(segmentsAcked)+(26.158)))+(95.692)+(0.1)+(0.1)+(0.1)+(0.1))/((91.613)));
	tcb->m_segmentSize = (int) (61.895-(26.681)-(segmentsAcked)-(segmentsAcked)-(18.504)-(7.136)-(80.95)-(43.006)-(tcb->m_ssThresh));
	segmentsAcked = (int) (0.1/50.167);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
int BPaFrINGmHdUnbkM = (int) (14.293+(99.239)+(55.975)+(tcb->m_segmentSize));
ReduceCwnd (tcb);
