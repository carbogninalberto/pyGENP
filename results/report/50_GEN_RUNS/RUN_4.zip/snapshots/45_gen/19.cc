ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (96.741-(18.222)-(9.96)-(28.821)-(tcb->m_ssThresh)-(53.342));
tcb->m_segmentSize = (int) (91.782-(99.399)-(8.199)-(59.587)-(tcb->m_cWnd));
float xZAKnbOldBwAtEjO = (float) (9.167-(18.122)-(34.489));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int zdougMHEdPkPEaub = (int) (54.272-(tcb->m_cWnd)-(64.36)-(23.015)-(61.036)-(61.943)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(91.063));
