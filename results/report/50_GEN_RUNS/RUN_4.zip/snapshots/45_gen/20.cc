if (tcb->m_segmentSize == tcb->m_ssThresh) {
	segmentsAcked = (int) (79.108+(96.99)+(79.339)+(55.359));
	tcb->m_segmentSize = (int) (88.149/92.51);

} else {
	segmentsAcked = (int) (tcb->m_cWnd-(32.016)-(59.392)-(19.982));
	tcb->m_cWnd = (int) ((48.035*(92.288)*(49.768))/43.981);

}
tcb->m_ssThresh = (int) (40.406*(tcb->m_ssThresh)*(77.438)*(tcb->m_cWnd)*(13.253)*(20.765));
segmentsAcked = (int) (55.472-(94.815)-(50.858)-(65.215)-(69.109)-(6.331)-(71.707)-(tcb->m_segmentSize));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
