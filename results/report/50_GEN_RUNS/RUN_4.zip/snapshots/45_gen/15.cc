ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(segmentsAcked)-(12.94)-(25.205)-(58.012)-(95.867)-(58.317)-(48.755)-(tcb->m_ssThresh));
tcb->m_segmentSize = (int) (25.445/0.1);
int XanBdsCwpPyUSEya = (int) (43.381+(10.023)+(tcb->m_segmentSize)+(86.845)+(74.041));
if (XanBdsCwpPyUSEya != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (56.632-(9.446)-(76.308)-(91.779)-(10.616));
	segmentsAcked = (int) (6.226/12.002);
	XanBdsCwpPyUSEya = (int) ((((1.879*(42.149)*(9.464)))+(0.1)+(57.951)+(65.865)+(9.096))/((38.651)+(65.865)+(57.212)));

} else {
	tcb->m_cWnd = (int) (4.325-(tcb->m_cWnd)-(20.425)-(66.18));
	XanBdsCwpPyUSEya = (int) (51.824*(segmentsAcked)*(XanBdsCwpPyUSEya)*(82.248)*(90.403));

}
