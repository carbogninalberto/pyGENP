TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (((0.1)+(0.1)+((70.861-(55.858)-(tcb->m_cWnd)-(segmentsAcked)))+(13.421))/((94.452)+(95.673)+(0.1)));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (70.588/3.751);

} else {
	tcb->m_cWnd = (int) (86.781+(39.417)+(79.035)+(35.444)+(27.031)+(36.229));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(94.159)+(tcb->m_segmentSize)+(79.844)+(71.019)+(52.951)+(73.992)+(1.885));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(98.894)*(44.8)*(15.195));
	tcb->m_segmentSize = (int) (78.828-(15.892)-(15.461)-(59.243));
	tcb->m_segmentSize = (int) ((59.223*(tcb->m_segmentSize)*(31.877)*(69.74)*(tcb->m_segmentSize))/6.261);

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (68.145+(11.331)+(21.14)+(19.692)+(13.566)+(4.616));

} else {
	tcb->m_segmentSize = (int) (74.142-(64.197)-(11.304)-(58.039)-(8.679)-(segmentsAcked)-(75.847)-(25.617));

}
