int fVBenOyWwKnZNpaM = (int) 54.568;
ReduceCwnd (tcb);
fVBenOyWwKnZNpaM = (int) (5.847+(-36.161)+(87.915)+(-58.232)+(81.006)+(32.483)+(-87.035)+(-7.371));
segmentsAcked = SlowStart (tcb, segmentsAcked);
