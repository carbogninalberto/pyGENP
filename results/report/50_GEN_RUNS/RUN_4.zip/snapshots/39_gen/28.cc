int IwaxvlVnvktmJSVl = (int) (tcb->m_cWnd*(21.735)*(83.053)*(56.83));
ReduceCwnd (tcb);
IwaxvlVnvktmJSVl = (int) (14.756*(93.396)*(15.228)*(45.196)*(9.532)*(83.081));
int cKrmHGhMuNasQXJl = (int) (28.11+(tcb->m_segmentSize)+(74.272)+(6.398)+(51.011));
cKrmHGhMuNasQXJl = (int) (45.006-(39.984)-(14.287)-(tcb->m_ssThresh));
if (cKrmHGhMuNasQXJl == IwaxvlVnvktmJSVl) {
	tcb->m_ssThresh = (int) (10.422-(47.351)-(tcb->m_ssThresh)-(85.63)-(93.25)-(74.008)-(71.736));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (36.729-(80.551)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(73.917));

}
segmentsAcked = (int) (56.339*(48.116));
IwaxvlVnvktmJSVl = (int) (17.277-(segmentsAcked)-(46.868));
