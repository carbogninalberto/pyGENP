if (segmentsAcked <= segmentsAcked) {
	tcb->m_ssThresh = (int) (52.889+(37.452)+(40.603)+(44.327)+(18.346)+(tcb->m_ssThresh)+(35.029)+(8.089)+(5.354));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (3.239+(52.097)+(68.88));

} else {
	tcb->m_ssThresh = (int) (96.806-(tcb->m_segmentSize)-(53.462)-(47.843)-(segmentsAcked)-(84.636)-(18.817));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (45.223+(91.779)+(96.563)+(39.206)+(28.836)+(44.071)+(35.143)+(35.672)+(52.791));

}
tcb->m_ssThresh = (int) (tcb->m_segmentSize*(91.266)*(60.559)*(30.048)*(78.599)*(9.998)*(tcb->m_ssThresh)*(2.943));
tcb->m_segmentSize = (int) (21.348-(6.702)-(68.294)-(segmentsAcked)-(segmentsAcked)-(24.797)-(52.6));
if (tcb->m_ssThresh >= segmentsAcked) {
	segmentsAcked = (int) (41.753+(42.123)+(31.661)+(segmentsAcked));

} else {
	segmentsAcked = (int) (86.58+(44.473)+(71.169)+(40.025));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(9.97)*(tcb->m_cWnd)*(74.213)*(tcb->m_segmentSize)*(tcb->m_ssThresh));

}
tcb->m_ssThresh = (int) ((((76.714-(tcb->m_ssThresh)-(15.605)-(tcb->m_segmentSize)-(96.526)-(67.867)))+(0.1)+(88.186)+(0.1))/((0.1)));
