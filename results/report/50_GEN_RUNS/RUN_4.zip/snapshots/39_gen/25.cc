tcb->m_segmentSize = (int) (1.124+(96.178));
tcb->m_cWnd = (int) (0.1/33.566);
tcb->m_segmentSize = (int) (94.859-(segmentsAcked)-(46.207)-(51.374)-(segmentsAcked)-(34.422)-(13.242)-(60.551)-(67.934));
ReduceCwnd (tcb);
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (24.075+(82.143)+(0.118)+(63.426)+(78.331)+(49.272)+(84.954)+(81.784)+(43.031));

} else {
	tcb->m_ssThresh = (int) (((48.356)+(0.1)+(40.386)+((16.342+(84.942)+(86.434)+(81.783)+(98.348)+(49.491)))+(0.1))/((75.825)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
