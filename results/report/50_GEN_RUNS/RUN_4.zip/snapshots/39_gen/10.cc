TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (23.113-(57.893)-(77.35));
int UkVytTXYGYVLeOrv = (int) (91.007-(71.75));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (50.83/0.1);
CongestionAvoidance (tcb, segmentsAcked);
