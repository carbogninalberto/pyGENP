ReduceCwnd (tcb);
int WJBABIjKnaSmgTme = (int) (41.755*(-63.285)*(30.19)*(-25.883)*(-53.846)*(-62.396)*(12.957));
int fVBenOyWwKnZNpaM = (int) 81.411;
fVBenOyWwKnZNpaM = (int) (48.839+(-28.361)+(-86.264)+(81.847)+(38.3)+(-80.293)+(20.773)+(-44.6));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
