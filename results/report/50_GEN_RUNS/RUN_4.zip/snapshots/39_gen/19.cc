segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	segmentsAcked = (int) (6.509*(13.64)*(46.65)*(54.168)*(tcb->m_segmentSize)*(30.748)*(56.744)*(48.78)*(4.009));

} else {
	segmentsAcked = (int) (0.914-(85.489)-(90.886)-(tcb->m_ssThresh)-(93.695)-(19.998)-(46.982)-(43.43)-(63.145));

}
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (87.524*(29.638)*(18.364)*(27.557)*(25.824));
	tcb->m_cWnd = (int) (((0.1)+(0.1)+((60.28*(tcb->m_cWnd)*(92.466)*(76.222)*(35.0)))+(68.576)+(92.889)+(0.1))/((0.1)+(23.714)+(80.759)));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(2.023)+(89.859)+(90.131)+(30.583)+(35.106)+(80.906));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (37.783+(tcb->m_ssThresh)+(22.269)+(25.171)+(tcb->m_ssThresh)+(27.244)+(9.913)+(tcb->m_ssThresh)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (0.1/26.999);

} else {
	segmentsAcked = (int) (93.14/0.1);
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
