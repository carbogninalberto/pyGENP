tcb->m_cWnd = (int) (15.237*(6.717)*(segmentsAcked)*(81.261)*(tcb->m_segmentSize)*(20.69)*(87.816));
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (59.451+(0.147)+(37.558)+(53.462)+(79.777)+(45.027));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (45.073+(42.203));
	ReduceCwnd (tcb);

}
int kTSIGdqMzkgCTyJv = (int) (49.363/55.565);
segmentsAcked = (int) (27.62-(14.11)-(10.422)-(40.174));
tcb->m_cWnd = (int) (8.329/6.357);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
