int kvpJNkAtyQegxcSG = (int) 2.067;
ReduceCwnd (tcb);
