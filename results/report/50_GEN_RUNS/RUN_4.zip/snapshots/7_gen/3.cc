int hIcDCceEWvVxeYMu = (int) 38.099;
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
hIcDCceEWvVxeYMu = (int) (4.982*(22.239)*(-62.876)*(1.697));
