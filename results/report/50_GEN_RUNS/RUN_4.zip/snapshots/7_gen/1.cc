float EiujFVEwpBWWDRLI = (float) (-40.392/-12.431);
int NFrOHWyPZFYLaDRE = (int) 96.459;
segmentsAcked = (int) (70.904+(-77.62)+(55.725)+(77.82));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	NFrOHWyPZFYLaDRE = (int) ((NFrOHWyPZFYLaDRE*(49.59)*(44.307)*(tcb->m_cWnd)*(21.144)*(tcb->m_segmentSize)*(60.592)*(11.75))/20.05);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	NFrOHWyPZFYLaDRE = (int) (95.651-(48.396)-(16.645)-(50.563)-(56.501));

}
