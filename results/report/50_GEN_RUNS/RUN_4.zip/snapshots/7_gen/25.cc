ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (76.276+(60.382)+(30.295)+(85.693)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(80.965)+(76.495));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(8.533)*(segmentsAcked)*(tcb->m_ssThresh)*(43.928)*(40.794)*(tcb->m_ssThresh)*(51.238));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
int hTItjfRHobreQfDM = (int) (0.1/0.1);
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	segmentsAcked = (int) (((98.06)+(0.1)+(0.1)+(36.555)+(20.301))/((0.1)+(62.472)+(0.1)));
	tcb->m_cWnd = (int) (5.716+(69.835)+(94.535)+(56.655));
	hTItjfRHobreQfDM = (int) (28.905+(11.36)+(17.52)+(hTItjfRHobreQfDM)+(31.418));

} else {
	segmentsAcked = (int) ((((88.04-(90.648)-(21.391)-(3.118)-(86.92)-(34.407)-(10.076)-(27.325)))+((hTItjfRHobreQfDM+(segmentsAcked)+(58.707)+(89.754)+(46.42)+(70.885)+(40.98)+(4.083)))+(0.1)+(99.673)+((64.785-(tcb->m_cWnd)-(18.638)))+(76.941)+(84.163))/((0.1)));

}
if (hTItjfRHobreQfDM != tcb->m_cWnd) {
	segmentsAcked = (int) (((0.1)+((10.922*(54.123)))+((2.712-(52.291)-(6.17)-(97.598)-(tcb->m_ssThresh)-(92.359)))+(36.071))/((0.1)+(0.1)));
	tcb->m_cWnd = (int) (((0.1)+((97.719*(9.562)*(tcb->m_segmentSize)*(19.728)*(45.444)*(74.778)*(36.029)))+(80.964)+(0.1))/((0.1)+(24.333)+(59.719)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(14.999)*(85.769));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (87.58/77.9);

}
if (hTItjfRHobreQfDM < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (95.236+(18.008)+(30.7)+(segmentsAcked)+(93.273)+(33.088)+(52.264));

} else {
	tcb->m_segmentSize = (int) (30.182*(32.534)*(tcb->m_cWnd)*(68.415)*(segmentsAcked)*(46.856)*(84.193));

}
