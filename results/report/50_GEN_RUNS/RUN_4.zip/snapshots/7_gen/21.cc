ReduceCwnd (tcb);
if (segmentsAcked == segmentsAcked) {
	segmentsAcked = (int) (65.746*(38.786)*(segmentsAcked));

} else {
	segmentsAcked = (int) (58.529/0.1);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (43.552/0.1);
ReduceCwnd (tcb);
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_cWnd-(85.568)-(segmentsAcked)-(93.599)-(57.156)-(37.875)-(55.947)-(78.158)-(1.655));
	tcb->m_ssThresh = (int) (20.879+(81.124)+(83.855)+(48.1)+(69.636)+(80.184));

} else {
	segmentsAcked = (int) (63.219*(43.183));
	tcb->m_cWnd = (int) (75.223-(91.381)-(27.158)-(40.188));

}
