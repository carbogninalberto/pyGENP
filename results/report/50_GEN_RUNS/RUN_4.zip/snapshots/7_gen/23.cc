CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (99.012-(tcb->m_ssThresh)-(91.708)-(11.703)-(12.707)-(1.237)-(65.227)-(58.481));
ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	segmentsAcked = (int) (12.805-(9.614)-(86.719)-(98.278)-(49.779)-(39.066)-(66.874)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (82.095-(47.189)-(57.137)-(90.0)-(30.694));

} else {
	segmentsAcked = (int) (48.6+(3.847)+(19.189)+(51.234)+(85.13)+(95.154)+(18.938)+(tcb->m_segmentSize));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (31.863-(1.15)-(tcb->m_cWnd));
tcb->m_segmentSize = (int) (tcb->m_cWnd*(74.572)*(tcb->m_ssThresh)*(19.12)*(30.818)*(79.168)*(60.818));
