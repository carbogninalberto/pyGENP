CongestionAvoidance (tcb, segmentsAcked);
float GvhQnEKVTUqbNMaU = (float) (((-38.967)+(31.902)+(-72.939)+((-9.042*(96.413)*(5.039)*(-99.459)*(17.105)*(-77.335)*(53.866)*(-61.815)))+(2.287)+(53.559)+((58.22+(95.827)+(-27.788)+(20.327)+(-29.038)+(-49.181)+(51.96)))+(-42.425))/((42.783)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
