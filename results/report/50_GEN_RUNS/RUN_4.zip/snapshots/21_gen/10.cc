CongestionAvoidance (tcb, segmentsAcked);
float GvhQnEKVTUqbNMaU = (float) (((78.39)+(92.743)+(-12.852)+((47.836*(-4.261)*(-6.027)*(-0.914)*(30.097)*(-51.2)*(-45.218)*(7.161)))+(39.085)+(86.744)+((69.47+(86.536)+(-89.582)+(-65.033)+(70.932)+(-40.198)+(31.552)))+(35.239))/((95.251)));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
