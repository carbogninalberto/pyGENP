segmentsAcked = (int) (30.428+(-15.555)+(88.838)+(70.062)+(34.521)+(-8.847)+(40.095)+(58.741));
CongestionAvoidance (tcb, segmentsAcked);
