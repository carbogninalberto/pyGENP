float GvhQnEKVTUqbNMaU = (float) (((-26.791)+(98.605)+(35.025)+((-34.827*(-33.622)*(-59.418)*(-50.361)*(-19.346)*(39.287)*(-42.137)*(34.469)))+(-21.9)+(-59.541)+((-50.442+(44.203)+(25.799)+(-32.624)+(-75.26)+(-75.515)+(-20.126)))+(-40.187))/((52.442)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
