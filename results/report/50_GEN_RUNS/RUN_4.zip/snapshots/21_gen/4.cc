float GvhQnEKVTUqbNMaU = (float) (((-7.15)+(49.916)+(-2.373)+((96.848*(81.807)*(35.791)*(25.489)*(-60.09)*(25.705)*(-29.151)*(98.242)))+(-87.357)+(7.302)+((35.729+(-65.584)+(-2.387)+(-25.432)+(-64.689)+(-49.729)+(-26.464)))+(65.03))/((-10.151)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
