float GvhQnEKVTUqbNMaU = (float) (((-45.289)+(34.985)+(99.128)+((84.503*(-52.794)*(-86.624)*(39.953)*(98.97)*(71.346)*(69.512)*(23.684)))+(-46.195)+(-63.15)+((47.022+(-34.289)+(21.306)+(-36.261)+(64.073)+(85.315)+(68.954)))+(-16.566))/((-80.525)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
