float MTHxzdWUxZoBOOXa = (float) (0.1/94.887);
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(11.132)+(54.173)+(0.1)+(41.093))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (51.323*(14.31)*(85.396)*(75.735)*(tcb->m_ssThresh)*(66.236)*(15.902));
	MTHxzdWUxZoBOOXa = (float) (68.332/73.283);

}
int DZTSobWlpXGGsDfw = (int) ((((67.036+(tcb->m_ssThresh)+(35.512)+(19.139)+(90.901)))+(0.1)+(14.275)+(57.969))/((88.623)+(0.1)));
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_ssThresh = (int) (26.871-(tcb->m_ssThresh)-(DZTSobWlpXGGsDfw)-(DZTSobWlpXGGsDfw)-(79.856)-(25.914)-(6.554)-(11.232));
	ReduceCwnd (tcb);
	DZTSobWlpXGGsDfw = (int) (64.842*(DZTSobWlpXGGsDfw));

} else {
	tcb->m_ssThresh = (int) (67.01*(MTHxzdWUxZoBOOXa)*(82.393)*(82.195)*(DZTSobWlpXGGsDfw)*(16.972));
	CongestionAvoidance (tcb, segmentsAcked);

}
float wwVOpCnarxfyriFR = (float) (71.325*(97.376)*(52.969)*(19.506)*(31.442)*(tcb->m_cWnd)*(17.403));
segmentsAcked = (int) (((59.736)+(0.1)+(35.661)+(0.1)+(85.627))/((0.1)+(0.1)));
DZTSobWlpXGGsDfw = (int) (51.199+(44.192)+(42.237)+(25.312)+(64.482));
if (DZTSobWlpXGGsDfw > tcb->m_ssThresh) {
	segmentsAcked = (int) (11.406*(20.788)*(19.691)*(80.127)*(tcb->m_cWnd)*(43.866));
	segmentsAcked = (int) (67.53-(16.696)-(28.442)-(34.213)-(82.592)-(67.181)-(tcb->m_cWnd)-(67.347)-(segmentsAcked));

} else {
	segmentsAcked = (int) (24.853*(41.322)*(64.154)*(18.288)*(78.518)*(MTHxzdWUxZoBOOXa)*(77.925)*(68.64));

}
