int bmrbmuSZdZOrugEk = (int) (71.043/-61.554);
