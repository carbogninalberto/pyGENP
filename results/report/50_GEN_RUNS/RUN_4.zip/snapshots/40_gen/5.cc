ReduceCwnd (tcb);
int fVBenOyWwKnZNpaM = (int) 62.883;
ReduceCwnd (tcb);
fVBenOyWwKnZNpaM = (int) (13.023+(37.405)+(36.741)+(61.831)+(-77.363)+(-35.174)+(-88.828)+(-9.195));
segmentsAcked = SlowStart (tcb, segmentsAcked);
