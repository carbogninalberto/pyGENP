if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (19.005*(15.466)*(28.351)*(33.912)*(45.194)*(6.186)*(85.002)*(80.404));
	segmentsAcked = (int) (tcb->m_cWnd+(7.789)+(41.864)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (25.718*(tcb->m_segmentSize)*(98.932)*(6.176));

}
tcb->m_ssThresh = (int) (12.528+(4.798)+(60.605)+(54.402)+(49.407)+(24.594)+(32.823)+(5.771));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.1/60.406);

} else {
	tcb->m_ssThresh = (int) (82.597*(segmentsAcked)*(16.602)*(66.8)*(segmentsAcked)*(61.676)*(88.26)*(99.218));

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
