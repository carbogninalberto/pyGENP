CongestionAvoidance (tcb, segmentsAcked);
int fVBenOyWwKnZNpaM = (int) 4.247;
ReduceCwnd (tcb);
fVBenOyWwKnZNpaM = (int) (-58.948+(-65.8)+(91.516)+(-83.379)+(32.897)+(52.464)+(-94.001)+(56.09));
fVBenOyWwKnZNpaM = (int) (94.792+(67.128)+(73.021)+(-35.211)+(-39.98)+(76.391)+(11.135)+(-15.071));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
