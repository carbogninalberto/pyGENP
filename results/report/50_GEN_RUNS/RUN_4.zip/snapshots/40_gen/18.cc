tcb->m_cWnd = (int) (14.744*(74.766)*(19.431)*(69.83));
tcb->m_ssThresh = (int) (0.1/60.244);
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (72.461-(88.898)-(41.966)-(27.644)-(69.056));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(tcb->m_cWnd)-(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(14.388)-(87.985)-(97.135)-(66.747)-(63.819)-(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) ((42.025+(54.144))/0.1);

}
tcb->m_segmentSize = (int) (76.589-(tcb->m_cWnd)-(tcb->m_cWnd)-(29.282));
tcb->m_segmentSize = (int) (70.245*(tcb->m_ssThresh));
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	segmentsAcked = (int) (71.346-(segmentsAcked)-(72.803)-(tcb->m_ssThresh)-(29.596)-(27.592)-(96.356)-(tcb->m_cWnd)-(26.864));

} else {
	segmentsAcked = (int) ((tcb->m_cWnd+(96.447))/0.1);

}
