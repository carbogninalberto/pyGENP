tcb->m_segmentSize = (int) (95.369*(tcb->m_cWnd)*(15.553)*(12.787)*(34.639)*(58.761)*(tcb->m_cWnd)*(segmentsAcked)*(5.172));
ReduceCwnd (tcb);
float fnsjWONHyjPmiExs = (float) (98.836*(66.754)*(segmentsAcked)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(tcb->m_cWnd)*(59.597)*(13.903));
int hOcKXsTfAlcaNqeX = (int) (17.72*(68.449)*(28.401)*(segmentsAcked)*(tcb->m_ssThresh)*(56.812)*(tcb->m_segmentSize)*(90.866)*(tcb->m_segmentSize));
float BXrGIpyxzPtvLgei = (float) (56.535*(97.899)*(tcb->m_cWnd)*(63.977)*(23.243)*(73.129)*(23.411));
