tcb->m_segmentSize = (int) (22.806*(42.571)*(13.53)*(tcb->m_ssThresh));
segmentsAcked = (int) (0.1/0.1);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((29.317+(61.893)+(4.094)+(34.828))/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (19.512*(96.188)*(67.231)*(34.524)*(64.967)*(43.839)*(tcb->m_ssThresh)*(36.414));

}
if (segmentsAcked >= segmentsAcked) {
	tcb->m_cWnd = (int) (1.833*(25.185)*(90.216)*(49.689)*(tcb->m_segmentSize)*(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (14.173*(4.493)*(95.398)*(5.592)*(90.37)*(51.158));

}
