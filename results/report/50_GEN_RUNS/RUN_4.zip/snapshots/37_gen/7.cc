int FpXJTaZVTJnLGkbg = (int) (-81.458/-82.808);
int OEPHefGTWAAHYZTm = (int) (24.26*(-77.454)*(51.649)*(27.751));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
