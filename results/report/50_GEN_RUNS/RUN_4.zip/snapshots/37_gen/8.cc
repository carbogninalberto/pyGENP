if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (79.645*(tcb->m_ssThresh)*(segmentsAcked)*(91.532)*(64.711)*(31.105)*(37.233)*(tcb->m_cWnd)*(31.37));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (60.676+(33.137)+(34.638)+(48.313)+(86.115)+(69.919)+(1.963));

}
tcb->m_ssThresh = (int) (3.855*(tcb->m_segmentSize)*(80.704)*(tcb->m_ssThresh));
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (22.982+(tcb->m_segmentSize)+(93.217)+(6.161)+(76.689)+(88.11)+(80.594)+(9.945));
	tcb->m_segmentSize = (int) (0.1/77.448);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (0.1/61.927);

}
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
