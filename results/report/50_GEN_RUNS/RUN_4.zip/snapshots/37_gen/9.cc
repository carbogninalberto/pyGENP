ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (80.2*(45.356)*(43.821)*(28.629)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(4.8)*(53.321));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (2.664*(4.544)*(82.189)*(79.892)*(20.172));
tcb->m_ssThresh = (int) ((77.855-(53.073))/33.53);
tcb->m_segmentSize = (int) (73.994-(56.295)-(66.253)-(tcb->m_ssThresh));
