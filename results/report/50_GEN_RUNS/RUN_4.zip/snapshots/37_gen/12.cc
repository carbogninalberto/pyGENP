segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((((tcb->m_cWnd*(66.389)*(42.968)*(93.195)))+(0.1)+(0.1)+(47.423))/((97.185)+(24.287)));
segmentsAcked = (int) (70.068*(6.785)*(38.875)*(segmentsAcked)*(tcb->m_segmentSize)*(tcb->m_ssThresh));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (19.268/0.1);
ReduceCwnd (tcb);
segmentsAcked = (int) (30.271+(37.959)+(4.687)+(90.783)+(53.91)+(77.036)+(4.336)+(80.773));
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (9.791+(10.369)+(45.396)+(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (0.1/59.072);

}
