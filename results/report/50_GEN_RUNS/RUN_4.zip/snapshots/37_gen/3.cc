int IltYfeLsRVfbewOI = (int) (-59.835-(-69.573)-(89.614));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (84.151-(-44.849)-(-50.785)-(50.266)-(-9.755));
tcb->m_segmentSize = (int) (-41.869*(-5.934)*(-74.81)*(38.767));
