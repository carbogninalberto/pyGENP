if (segmentsAcked > segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(-59.405)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(86.266)-(42.977)-(57.349)-(segmentsAcked)-(89.221));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (78.465*(98.426)*(tcb->m_cWnd)*(59.024));

} else {
	tcb->m_cWnd = (int) (95.587*(46.712)*(tcb->m_cWnd)*(98.918)*(81.626)*(48.06)*(35.688));
	tcb->m_cWnd = (int) (15.269*(96.78));
	ReduceCwnd (tcb);

}
