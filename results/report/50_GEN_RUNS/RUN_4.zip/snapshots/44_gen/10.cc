if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (62.235+(tcb->m_cWnd)+(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(13.445)-(53.272)-(tcb->m_cWnd)-(49.288)-(75.404)-(tcb->m_cWnd)-(31.366));

}
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_cWnd = (int) (0.249-(44.057));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (11.29*(85.039));
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	segmentsAcked = (int) (97.128*(11.948)*(42.335)*(tcb->m_ssThresh)*(12.333)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(37.378));

} else {
	segmentsAcked = (int) (23.95+(63.313));

}
tcb->m_ssThresh = (int) (2.693/41.894);
