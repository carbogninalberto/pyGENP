tcb->m_cWnd = (int) (-81.689-(-16.928));
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (30.88*(68.282)*(tcb->m_segmentSize)*(55.401)*(27.399)*(36.848)*(89.091));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(29.142)*(73.224)*(tcb->m_cWnd)*(54.415)*(39.852)*(5.993));
	segmentsAcked = (int) (27.051*(13.793)*(98.496)*(tcb->m_cWnd)*(71.204)*(94.444)*(tcb->m_cWnd)*(tcb->m_segmentSize));

}
segmentsAcked = (int) ((-81.208+(58.377)+(tcb->m_cWnd)+(-37.079)+(89.593)+(36.875)+(95.766))/41.129);
