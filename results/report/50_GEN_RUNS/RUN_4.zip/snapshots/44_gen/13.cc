tcb->m_segmentSize = (int) (11.414-(21.922)-(54.894)-(tcb->m_segmentSize)-(57.739)-(80.07));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (56.216*(tcb->m_ssThresh)*(segmentsAcked)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(77.035)*(74.948));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (segmentsAcked+(51.167)+(tcb->m_cWnd)+(4.765)+(8.365));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(tcb->m_segmentSize)*(58.768)*(55.846));
	segmentsAcked = (int) (11.893+(11.219)+(94.49)+(segmentsAcked)+(78.215));
	CongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(tcb->m_cWnd));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (2.85+(tcb->m_segmentSize)+(34.003));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (48.911+(50.092)+(63.145)+(tcb->m_segmentSize)+(36.623)+(tcb->m_ssThresh));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (86.813*(segmentsAcked)*(tcb->m_ssThresh)*(57.967)*(tcb->m_ssThresh)*(12.932)*(21.594)*(2.012)*(15.504));
float muViADuSxvqbtilG = (float) (23.683+(45.615)+(90.918)+(16.612)+(44.102)+(19.174)+(82.855));
