float PZKfZAsoDXRKHXYw = (float) (segmentsAcked-(38.773)-(98.373)-(59.055)-(segmentsAcked)-(32.478));
float NUzQNWSqrmhgemLX = (float) (tcb->m_cWnd-(tcb->m_segmentSize)-(17.056)-(31.57)-(69.735)-(68.11)-(15.215)-(1.982));
if (tcb->m_segmentSize < segmentsAcked) {
	PZKfZAsoDXRKHXYw = (float) (13.109+(PZKfZAsoDXRKHXYw)+(68.955)+(12.911)+(94.23)+(81.508)+(87.927));

} else {
	PZKfZAsoDXRKHXYw = (float) (27.723+(5.76)+(55.881));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (tcb->m_cWnd+(46.919)+(22.17));
