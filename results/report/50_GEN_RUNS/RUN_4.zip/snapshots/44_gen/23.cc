tcb->m_ssThresh = (int) (tcb->m_cWnd+(72.881));
if (segmentsAcked != segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(93.677)-(68.74)-(77.902)-(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) ((72.188*(96.838)*(93.84)*(10.51)*(58.362)*(35.266)*(20.377)*(70.233)*(28.418))/96.018);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (segmentsAcked*(tcb->m_cWnd));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (2.636+(tcb->m_cWnd)+(tcb->m_cWnd)+(70.884)+(38.82)+(29.365));
