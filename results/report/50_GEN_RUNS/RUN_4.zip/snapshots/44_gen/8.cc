if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (76.479-(88.701)-(67.092)-(64.28)-(91.761)-(16.65));

} else {
	segmentsAcked = (int) (27.884/62.668);
	tcb->m_cWnd = (int) ((0.307*(46.93)*(41.664)*(94.644))/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (30.875*(79.789)*(61.14));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (96.212*(39.394)*(28.316)*(3.486)*(80.254)*(27.261));
	tcb->m_ssThresh = (int) (72.899-(36.774)-(73.463)-(57.955)-(90.108)-(segmentsAcked));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (35.72/0.1);
ReduceCwnd (tcb);
