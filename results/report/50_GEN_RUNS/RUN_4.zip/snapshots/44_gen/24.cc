ReduceCwnd (tcb);
tcb->m_cWnd = (int) (82.844+(47.422)+(18.48)+(44.141)+(81.811)+(31.913)+(61.472));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((((tcb->m_segmentSize*(tcb->m_segmentSize)))+(0.1)+(92.94)+(0.1)+(45.026))/((92.637)+(53.256)+(0.1)+(50.373)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (78.008-(16.501)-(62.578)-(92.368)-(84.535)-(45.464)-(segmentsAcked)-(90.951));
	tcb->m_ssThresh = (int) (55.549-(38.211)-(25.667)-(segmentsAcked));
	tcb->m_cWnd = (int) (45.571-(12.929)-(33.352)-(segmentsAcked)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(48.03));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (tcb->m_segmentSize*(1.578)*(48.392)*(0.533)*(tcb->m_ssThresh));
if (segmentsAcked < tcb->m_ssThresh) {
	segmentsAcked = (int) (23.545+(53.273));

} else {
	segmentsAcked = (int) (55.535+(51.89)+(4.607)+(89.439));
	tcb->m_cWnd = (int) (9.68+(42.433)+(15.353)+(70.443)+(tcb->m_ssThresh)+(87.989)+(tcb->m_cWnd));
	segmentsAcked = (int) (47.093+(26.032)+(73.197)+(28.328)+(65.369)+(87.634)+(tcb->m_cWnd)+(6.401)+(tcb->m_ssThresh));

}
