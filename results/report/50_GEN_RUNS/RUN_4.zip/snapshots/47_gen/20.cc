TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (44.39+(21.66)+(62.605)+(74.323)+(86.872)+(60.018));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (16.148-(45.897)-(59.84)-(26.213)-(segmentsAcked));
tcb->m_cWnd = (int) (11.949+(39.095)+(9.599)+(13.83)+(tcb->m_segmentSize)+(63.103));
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (91.503-(9.672));
	segmentsAcked = (int) (91.291-(85.303)-(86.429)-(51.709)-(26.086));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(33.668));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
