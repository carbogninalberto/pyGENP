if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_segmentSize = (int) (1.151-(76.731)-(segmentsAcked)-(segmentsAcked)-(6.844));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (((0.1)+(39.297)+(0.1)+(0.1))/((76.328)+(0.1)+(0.1)+(32.829)+(77.635)));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(43.406)+(0.1)+(0.1))/((54.541)));

}
tcb->m_cWnd = (int) (0.1/0.1);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(92.21)+(11.551));

} else {
	tcb->m_ssThresh = (int) (28.256-(99.547)-(86.095)-(8.825)-(23.885)-(34.618)-(36.506));

}
if (tcb->m_cWnd > tcb->m_cWnd) {
	segmentsAcked = (int) (1.949+(13.523)+(83.017)+(segmentsAcked)+(34.556)+(11.361)+(95.928)+(94.94)+(52.361));

} else {
	segmentsAcked = (int) (50.631*(45.175)*(12.482)*(25.188));

}
if (tcb->m_segmentSize != segmentsAcked) {
	segmentsAcked = (int) (80.732+(83.123)+(11.295)+(33.934)+(7.05)+(62.231)+(33.735)+(34.416));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (78.205+(55.63)+(tcb->m_ssThresh)+(60.959)+(tcb->m_segmentSize)+(45.525)+(segmentsAcked)+(39.638)+(99.144));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (4.345*(65.182)*(88.754)*(78.616)*(80.825)*(tcb->m_cWnd)*(88.465));
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(83.039)+(40.601)+(segmentsAcked)+(6.965)+(11.07)+(93.575));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (76.881+(36.084)+(75.449)+(30.445)+(20.612));

} else {
	tcb->m_segmentSize = (int) (((41.151)+(0.1)+(0.1)+(61.57))/((0.1)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (51.752/38.637);

}
