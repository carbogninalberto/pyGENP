ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) ((60.717-(88.86)-(71.37)-(46.416)-(46.67)-(1.769)-(80.842)-(tcb->m_ssThresh))/82.13);
	tcb->m_cWnd = (int) (25.002-(44.913)-(tcb->m_cWnd)-(segmentsAcked)-(45.796)-(tcb->m_ssThresh)-(76.672)-(50.769)-(54.717));
	tcb->m_cWnd = (int) (52.892-(87.807)-(segmentsAcked)-(segmentsAcked)-(tcb->m_cWnd)-(47.419));

} else {
	segmentsAcked = (int) (97.674*(32.262)*(4.366)*(14.347));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (61.095+(84.409)+(tcb->m_segmentSize)+(73.837)+(59.708));
tcb->m_segmentSize = (int) (7.809*(13.696)*(32.983)*(88.725)*(segmentsAcked)*(44.82)*(16.319)*(97.199)*(55.063));
