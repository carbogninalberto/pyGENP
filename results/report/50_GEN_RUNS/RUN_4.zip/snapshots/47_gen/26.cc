if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (82.788-(94.383)-(16.984)-(64.836)-(81.815)-(61.719));
	tcb->m_cWnd = (int) (4.021-(16.745)-(48.29)-(55.941)-(42.042)-(72.0)-(19.043)-(52.971));

} else {
	segmentsAcked = (int) (57.91+(82.342)+(92.931)+(segmentsAcked));
	tcb->m_ssThresh = (int) (26.939-(81.183)-(75.751)-(63.99)-(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (tcb->m_segmentSize*(97.36)*(segmentsAcked)*(30.312)*(tcb->m_segmentSize)*(segmentsAcked)*(19.923));
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_ssThresh*(57.086)*(90.848)*(54.477)*(tcb->m_cWnd)*(7.301)*(tcb->m_ssThresh)*(28.637));

} else {
	segmentsAcked = (int) (39.491-(15.383)-(73.409)-(tcb->m_segmentSize)-(61.315)-(2.233)-(83.296)-(45.63));

}
tcb->m_cWnd = (int) (42.477+(94.952));
if (tcb->m_cWnd < tcb->m_ssThresh) {
	segmentsAcked = (int) (89.876-(56.952)-(28.096)-(99.323)-(82.674)-(15.034)-(segmentsAcked)-(55.2)-(segmentsAcked));

} else {
	segmentsAcked = (int) (16.102-(51.825));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
