ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_cWnd) {
	segmentsAcked = (int) (63.775*(67.009)*(13.426)*(29.119)*(74.64)*(tcb->m_segmentSize)*(37.856)*(13.415));

} else {
	segmentsAcked = (int) (24.937*(tcb->m_ssThresh)*(segmentsAcked)*(19.66)*(82.673)*(32.726)*(35.424)*(42.737));

}
segmentsAcked = (int) (49.063*(86.629));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (85.157/0.1);
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(67.47)-(77.062)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(76.245));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(segmentsAcked)*(93.936)*(42.866)*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (75.022*(segmentsAcked)*(5.601)*(47.396)*(23.896)*(15.873)*(tcb->m_cWnd));
	segmentsAcked = (int) (25.951-(85.376)-(21.031)-(65.105)-(18.08));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (37.513+(56.859)+(99.416)+(5.432)+(47.388)+(50.153)+(19.466)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(63.976)*(segmentsAcked)*(47.311)*(14.237)*(tcb->m_cWnd)*(tcb->m_cWnd)*(45.202)*(segmentsAcked));

}
