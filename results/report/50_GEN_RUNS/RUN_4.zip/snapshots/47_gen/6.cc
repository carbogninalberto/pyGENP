if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (98.894-(24.065)-(78.114)-(tcb->m_ssThresh)-(90.233)-(73.096));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (98.379-(6.805)-(31.191)-(96.455));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (74.11*(15.168)*(89.616)*(62.409)*(86.213)*(17.162)*(77.617)*(96.392)*(95.536));

}
tcb->m_cWnd = (int) (34.266-(73.685)-(64.488));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (94.199-(37.327)-(68.782));
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (4.892+(5.694)+(11.045)+(tcb->m_ssThresh)+(22.544)+(90.82)+(17.634)+(68.921)+(96.375));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) ((((1.655-(tcb->m_ssThresh)-(20.794)-(36.842)-(tcb->m_segmentSize)-(segmentsAcked)-(tcb->m_cWnd)-(tcb->m_cWnd)))+((7.363-(29.528)-(segmentsAcked)-(70.441)))+(0.1)+(63.294))/((8.69)+(0.1)));
	tcb->m_segmentSize = (int) (47.706+(2.403)+(64.223)+(46.464)+(11.209)+(30.282)+(53.061)+(27.402));
	CongestionAvoidance (tcb, segmentsAcked);

}
