tcb->m_cWnd = (int) (96.876+(53.182)+(38.693)+(segmentsAcked)+(23.41));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float jxIlsajNMoADncGB = (float) ((10.253+(36.924)+(60.892)+(27.52)+(tcb->m_cWnd)+(tcb->m_ssThresh))/44.402);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
