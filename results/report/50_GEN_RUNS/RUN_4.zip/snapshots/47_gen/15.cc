tcb->m_cWnd = (int) (tcb->m_segmentSize*(3.918)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(54.149)*(19.294)*(71.945)*(77.814));
if (tcb->m_ssThresh < tcb->m_cWnd) {
	segmentsAcked = (int) ((((segmentsAcked*(tcb->m_segmentSize)*(90.824)*(41.522)*(tcb->m_segmentSize)*(47.848)))+((88.325+(82.923)+(17.546)))+((82.951-(17.442)-(1.602)-(segmentsAcked)-(56.311)-(tcb->m_segmentSize)-(29.524)-(tcb->m_ssThresh)-(tcb->m_ssThresh)))+(0.1)+(33.554))/((34.062)+(75.536)));
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) ((((90.577*(66.894)*(58.488)*(65.591)*(81.647)*(78.209)))+(88.23)+(0.1)+(10.094)+((tcb->m_ssThresh-(segmentsAcked)-(97.502)-(tcb->m_cWnd)-(80.054)))+(75.892))/((0.1)+(73.237)+(0.1)));

}
tcb->m_cWnd = (int) (26.667+(16.195)+(18.081)+(54.944)+(8.319)+(37.383)+(2.858)+(tcb->m_ssThresh));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/18.298);

} else {
	tcb->m_segmentSize = (int) (20.572-(47.711)-(81.675)-(62.501)-(39.817));
	tcb->m_ssThresh = (int) (segmentsAcked+(54.292)+(64.866)+(14.342)+(40.434)+(30.872));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (tcb->m_ssThresh-(44.567)-(78.566)-(66.76));
ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (55.849+(55.103));

} else {
	tcb->m_cWnd = (int) (16.866-(95.243)-(62.426));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
