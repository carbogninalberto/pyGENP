TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-16.668*(50.496));
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (97.034-(tcb->m_cWnd)-(48.813)-(30.346)-(12.294)-(30.789)-(78.081)-(70.074)-(33.473));

} else {
	tcb->m_cWnd = (int) (34.042-(14.89)-(94.404)-(9.147));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
