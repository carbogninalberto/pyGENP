float GvhQnEKVTUqbNMaU = (float) (((59.196)+(44.986)+(5.7)+((-34.26*(-49.724)*(24.18)*(-48.539)*(56.22)*(35.131)*(-37.179)*(-20.056)))+(-97.705)+(-56.687)+((36.424+(86.979)+(83.708)+(53.853)+(94.818)+(86.337)+(17.733)))+(-67.194))/((49.343)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
