CongestionAvoidance (tcb, segmentsAcked);
float GvhQnEKVTUqbNMaU = (float) (((-43.714)+(-17.976)+(8.612)+((29.958*(-16.485)*(-39.36)*(-76.005)*(-78.508)*(-3.363)*(-34.677)*(89.485)))+(10.368)+(69.648)+((38.776+(46.529)+(95.488)+(-83.624)+(-87.276)+(-28.923)+(-38.632)))+(-85.729))/((17.243)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
