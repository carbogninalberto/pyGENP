CongestionAvoidance (tcb, segmentsAcked);
float GvhQnEKVTUqbNMaU = (float) (((86.553)+(52.011)+(4.178)+((-49.112*(-74.305)*(40.174)*(88.683)*(36.159)*(-98.755)*(70.544)*(20.897)))+(-46.106)+(64.125)+((-18.222+(43.288)+(80.272)+(-13.906)+(-41.289)+(-29.31)+(-3.313)))+(18.636))/((73.931)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
