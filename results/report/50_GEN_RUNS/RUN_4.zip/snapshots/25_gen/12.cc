float GvhQnEKVTUqbNMaU = (float) (((-96.487)+(-26.021)+(32.929)+((-26.728*(25.884)*(-52.876)*(16.384)*(25.38)*(-72.307)*(5.142)*(-48.506)))+(-94.991)+(-1.852)+((88.508+(25.349)+(87.663)+(18.649)+(78.72)+(-85.554)+(-70.119)))+(76.571))/((74.319)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
