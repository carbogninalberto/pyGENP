float GvhQnEKVTUqbNMaU = (float) (((97.543)+(61.173)+(4.561)+((80.36*(-77.313)*(-13.11)*(-89.209)*(-39.957)*(-87.961)*(90.129)*(80.737)))+(70.919)+(-95.422)+((-20.103+(-75.057)+(-72.585)+(15.282)+(-20.137)+(-51.871)+(-17.603)))+(53.829))/((71.789)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
