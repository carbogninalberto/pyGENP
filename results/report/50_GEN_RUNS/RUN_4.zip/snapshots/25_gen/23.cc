int sBXlDqFgsFSxrnVH = (int) (40.382+(18.342));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (sBXlDqFgsFSxrnVH >= tcb->m_cWnd) {
	segmentsAcked = (int) (((0.1)+(0.1)+((tcb->m_ssThresh-(52.207)))+(0.1)+(87.019)+((39.91*(48.298)))+(63.427)+(51.86))/((0.1)));

} else {
	segmentsAcked = (int) (0.1/0.1);

}
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(80.832)*(37.256)*(75.687)*(37.826)*(23.912)*(tcb->m_cWnd)*(38.051));

} else {
	tcb->m_segmentSize = (int) (21.139*(65.518));
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (30.959-(segmentsAcked)-(92.904)-(39.05)-(20.445));
int LgQNVIXhyLLIyFRp = (int) (98.101+(99.382)+(47.66)+(90.234)+(15.282)+(88.752)+(63.829));
if (LgQNVIXhyLLIyFRp != segmentsAcked) {
	segmentsAcked = (int) (71.832-(segmentsAcked)-(25.272)-(26.929)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (sBXlDqFgsFSxrnVH+(LgQNVIXhyLLIyFRp)+(90.828)+(63.5)+(20.455)+(45.537)+(63.418)+(1.634)+(tcb->m_segmentSize));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
