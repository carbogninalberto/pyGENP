float GvhQnEKVTUqbNMaU = (float) (((99.916)+(-58.898)+(70.871)+((33.265*(-38.595)*(-65.196)*(68.714)*(48.237)*(-7.69)*(89.013)*(-50.438)))+(-75.6)+(64.805)+((41.522+(90.534)+(-3.497)+(46.09)+(-28.93)+(17.632)+(-83.769)))+(55.904))/((-89.521)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
