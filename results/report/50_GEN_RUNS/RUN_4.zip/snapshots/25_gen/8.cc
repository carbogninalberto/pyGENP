float GvhQnEKVTUqbNMaU = (float) (((47.422)+(-8.57)+(54.14)+((-97.883*(65.502)*(-33.411)*(41.938)*(-56.259)*(-60.617)*(96.207)*(-87.215)))+(-92.753)+(-47.698)+((85.186+(18.646)+(91.011)+(28.465)+(24.448)+(-99.862)+(50.66)))+(64.103))/((-27.405)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
