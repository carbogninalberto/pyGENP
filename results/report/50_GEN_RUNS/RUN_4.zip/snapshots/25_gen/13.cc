float GvhQnEKVTUqbNMaU = (float) (((74.987)+(-20.782)+(7.251)+((-54.472*(-4.59)*(-60.82)*(75.17)*(-15.587)*(16.25)*(15.623)*(42.212)))+(49.951)+(-92.841)+((-48.458+(-85.538)+(-93.609)+(70.998)+(51.407)+(61.392)+(-30.571)))+(50.405))/((68.472)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
