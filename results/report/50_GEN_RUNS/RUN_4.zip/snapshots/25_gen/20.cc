float GvhQnEKVTUqbNMaU = (float) (((-91.774)+(63.402)+(-9.001)+((61.671*(91.642)*(19.532)*(87.513)*(44.989)*(-36.941)*(-58.311)*(-86.152)))+(-26.169)+(-48.374)+((-70.825+(62.081)+(-62.192)+(-88.5)+(-15.039)+(-45.226)+(91.861)))+(-95.656))/((1.772)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
