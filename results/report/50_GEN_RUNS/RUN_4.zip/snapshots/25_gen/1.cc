float GvhQnEKVTUqbNMaU = (float) (((-46.72)+(-4.647)+(21.537)+((10.204*(31.848)*(-34.647)*(-22.274)*(76.512)*(76.214)*(1.606)*(43.276)))+(16.254)+(-29.234)+((11.29+(-93.126)+(-33.008)+(-99.776)+(-81.577)+(-96.662)+(51.483)))+(-7.958))/((11.696)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
