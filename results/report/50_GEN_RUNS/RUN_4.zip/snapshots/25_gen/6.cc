float GvhQnEKVTUqbNMaU = (float) (((-86.572)+(44.765)+(-16.76)+((57.857*(-20.845)*(29.414)*(62.072)*(-45.533)*(-53.751)*(24.86)*(-5.765)))+(-63.587)+(-46.833)+((61.777+(59.179)+(61.449)+(-18.354)+(62.743)+(-80.535)+(77.062)))+(50.245))/((-46.523)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
