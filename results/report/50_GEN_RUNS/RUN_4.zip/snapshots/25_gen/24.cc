CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_segmentSize = (int) (73.538-(99.594)-(66.444)-(23.274)-(35.78)-(70.306));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (64.427+(55.504)+(18.758)+(46.87)+(10.124));
	tcb->m_segmentSize = (int) ((10.017*(74.644)*(tcb->m_ssThresh))/0.1);

}
segmentsAcked = (int) (48.176-(91.605)-(63.106));
if (segmentsAcked == segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(3.938)-(89.625)-(39.045));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(77.305)+(80.36)+(51.359)+(0.1)+(94.398))/((0.1)));

} else {
	tcb->m_cWnd = (int) ((52.06+(23.062)+(40.512)+(tcb->m_ssThresh)+(tcb->m_cWnd))/0.1);
	segmentsAcked = (int) (22.24+(35.06)+(69.796));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((35.449*(40.231)*(93.533)*(0.433))/0.1);

} else {
	tcb->m_segmentSize = (int) (70.052*(65.993));
	tcb->m_ssThresh = (int) (59.858*(tcb->m_segmentSize)*(23.362)*(99.717)*(20.757)*(tcb->m_ssThresh)*(segmentsAcked)*(53.266));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
