float GvhQnEKVTUqbNMaU = (float) (((2.651)+(23.807)+(80.811)+((33.889*(-57.242)*(-87.284)*(-33.331)*(96.93)*(-28.046)*(85.339)*(-92.068)))+(59.736)+(66.289)+((92.075+(88.653)+(-95.697)+(-58.559)+(35.392)+(-45.717)+(72.508)))+(-51.236))/((78.124)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
