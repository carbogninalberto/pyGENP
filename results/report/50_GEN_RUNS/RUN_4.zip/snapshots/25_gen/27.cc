float ioHiAeAAzBLUDfua = (float) (92.423-(85.286)-(16.64));
ReduceCwnd (tcb);
segmentsAcked = (int) (10.45-(2.647)-(4.72)-(10.493)-(51.666)-(tcb->m_segmentSize)-(55.793)-(46.031)-(45.848));
ReduceCwnd (tcb);
if (ioHiAeAAzBLUDfua <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (81.032-(20.909)-(0.999)-(47.319)-(38.812)-(tcb->m_segmentSize)-(tcb->m_cWnd));
	ioHiAeAAzBLUDfua = (float) (97.528-(63.992));

} else {
	tcb->m_segmentSize = (int) (7.575*(88.365)*(46.096));
	tcb->m_segmentSize = (int) (90.457-(tcb->m_segmentSize));

}
