CongestionAvoidance (tcb, segmentsAcked);
float GvhQnEKVTUqbNMaU = (float) (((-93.753)+(-1.478)+(80.755)+((-68.578*(24.45)*(45.326)*(-77.567)*(-58.951)*(29.195)*(44.544)*(-39.887)))+(-37.725)+(-53.921)+((13.954+(-1.623)+(-7.339)+(-22.917)+(-39.912)+(-78.923)+(43.79)))+(85.004))/((10.134)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
