CongestionAvoidance (tcb, segmentsAcked);
float GvhQnEKVTUqbNMaU = (float) (((-47.331)+(-61.755)+(9.163)+((64.336*(3.9)*(-34.254)*(-42.838)*(13.111)*(47.513)*(-2.398)*(8.621)))+(75.684)+(0.274)+((43.656+(22.238)+(-45.164)+(80.075)+(-9.335)+(-78.94)+(-39.732)))+(-13.765))/((4.049)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
