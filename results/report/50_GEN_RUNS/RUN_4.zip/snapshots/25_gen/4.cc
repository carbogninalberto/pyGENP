float GvhQnEKVTUqbNMaU = (float) (((-35.174)+(27.876)+(-39.78)+((-18.308*(79.164)*(74.135)*(92.154)*(-57.155)*(-80.744)*(-34.792)*(40.463)))+(56.966)+(20.08)+((27.025+(-64.3)+(86.552)+(-51.355)+(-22.454)+(31.375)+(-35.706)))+(-94.818))/((-49.737)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
