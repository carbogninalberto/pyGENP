float GvhQnEKVTUqbNMaU = (float) (((69.27)+(85.936)+(47.22)+((13.1*(-40.382)*(85.667)*(-68.543)*(-30.951)*(-96.7)*(95.18)*(26.99)))+(8.98)+(64.489)+((-32.557+(-84.798)+(42.769)+(-63.856)+(10.392)+(-61.482)+(72.829)))+(-49.015))/((-9.57)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
