float QcUufkjwdvmGbAaX = (float) (-56.149*(-61.383)*(10.142)*(-81.183)*(85.447)*(-55.596)*(86.602)*(-75.295)*(-15.148));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
int QEGEDcnzQYmPxwUo = (int) (((-0.896)+(5.109)+((-84.19-(-35.732)))+(-85.667)+(99.671))/((-14.476)+(78.348)));
ReduceCwnd (tcb);
