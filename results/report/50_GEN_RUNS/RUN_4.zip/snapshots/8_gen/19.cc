int jXTEyIvRMQCsXAPq = (int) (16.269-(tcb->m_cWnd)-(35.962)-(23.343)-(40.671));
tcb->m_cWnd = (int) (jXTEyIvRMQCsXAPq*(tcb->m_ssThresh)*(75.271)*(47.644)*(tcb->m_cWnd)*(45.475)*(85.643)*(89.43));
if (segmentsAcked > segmentsAcked) {
	jXTEyIvRMQCsXAPq = (int) (69.411-(40.397)-(89.926)-(87.06)-(80.457)-(segmentsAcked)-(tcb->m_ssThresh)-(77.55)-(96.083));

} else {
	jXTEyIvRMQCsXAPq = (int) (31.558-(tcb->m_cWnd)-(48.221)-(12.544)-(24.93)-(42.095));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd < jXTEyIvRMQCsXAPq) {
	tcb->m_ssThresh = (int) (((0.1)+(36.368)+(0.1)+((40.685-(62.369)-(51.041)))+(73.806))/((0.1)));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (35.381*(6.328)*(31.221));
	segmentsAcked = (int) (0.1/(5.232+(19.341)+(79.676)+(64.741)+(18.181)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	jXTEyIvRMQCsXAPq = (int) (42.402*(82.223));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (76.348-(6.334)-(92.57)-(19.909)-(74.365)-(tcb->m_segmentSize)-(jXTEyIvRMQCsXAPq)-(59.83)-(jXTEyIvRMQCsXAPq));

} else {
	jXTEyIvRMQCsXAPq = (int) (22.966-(jXTEyIvRMQCsXAPq)-(segmentsAcked)-(55.86)-(21.992)-(89.933));
	ReduceCwnd (tcb);
	jXTEyIvRMQCsXAPq = (int) (59.018-(75.933)-(63.952)-(tcb->m_ssThresh)-(63.219)-(9.225)-(68.969)-(67.649));

}
