float fMCRSzZZexCjXFqm = (float) (63.581+(70.213)+(41.099)+(74.371));
float BBVEmtYrhNHHdnxp = (float) (30.386+(tcb->m_segmentSize)+(0.388)+(12.289)+(2.763)+(23.56)+(85.261)+(fMCRSzZZexCjXFqm));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (45.857/0.1);
