float LkWkbREeugKNVqnS = (float) (30.972/-31.278);
if (segmentsAcked >= segmentsAcked) {
	tcb->m_cWnd = (int) (26.545-(-55.776)-(49.104)-(6.436)-(57.795)-(50.237)-(37.032)-(97.63));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (45.196-(tcb->m_cWnd));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (72.256*(15.898)*(tcb->m_segmentSize)*(84.14)*(70.561)*(8.272)*(88.525)*(76.999));

}
float ZErmSzRxyeFkpmMs = (float) 18.759;
if (ZErmSzRxyeFkpmMs <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((0.1)+(2.423)+(0.1)+(0.1)+((2.414-(ZErmSzRxyeFkpmMs)))+(0.1)+(11.953))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (72.664+(49.687)+(44.303));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
ZErmSzRxyeFkpmMs = (float) (-99.767-(-81.574)-(43.765)-(83.243)-(-61.816)-(61.333));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
