float QcUufkjwdvmGbAaX = (float) (43.074*(-61.59)*(85.981)*(-38.177)*(-83.353)*(13.94)*(45.405)*(-25.14)*(-27.84));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
