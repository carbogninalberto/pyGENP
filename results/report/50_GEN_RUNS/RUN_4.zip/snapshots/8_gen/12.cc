int CAfJVwCSpIvHjqJi = (int) (-38.968+(-75.338)+(-37.253)+(-67.334)+(62.102)+(-10.702)+(46.45)+(-40.346));
float WgxwxhziLargijRB = (float) 87.751;
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_segmentSize = (int) (63.05-(7.083)-(tcb->m_segmentSize)-(-26.728)-(93.255)-(WgxwxhziLargijRB)-(50.623)-(8.019)-(15.778));

} else {
	tcb->m_segmentSize = (int) (24.779+(37.269));
	segmentsAcked = (int) (69.84-(64.057)-(80.302)-(71.132)-(23.891)-(75.066));

}
tcb->m_segmentSize = (int) (-91.701+(-45.303)+(84.776)+(-27.746)+(-43.263)+(-1.202));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (94.877+(0.437)+(-11.446)+(64.034)+(-73.323)+(-90.393));
