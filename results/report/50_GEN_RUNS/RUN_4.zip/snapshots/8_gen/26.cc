tcb->m_segmentSize = (int) (7.958/0.1);
segmentsAcked = (int) (38.562+(49.217)+(26.42)+(33.143)+(tcb->m_ssThresh)+(58.603)+(99.463)+(73.774));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (79.887+(44.555)+(23.316)+(tcb->m_cWnd)+(24.728));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (25.732*(segmentsAcked)*(86.237)*(74.266)*(44.184)*(41.892)*(tcb->m_ssThresh)*(66.369)*(segmentsAcked));
	tcb->m_ssThresh = (int) (52.942*(tcb->m_segmentSize)*(52.762)*(97.204)*(tcb->m_ssThresh));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (((66.183)+((55.594-(71.943)-(79.545)-(tcb->m_ssThresh)-(9.233)-(47.292)-(36.49)-(8.506)))+(85.728)+(75.421)+(0.1))/((0.1)+(0.1)));
tcb->m_ssThresh = (int) (10.116+(72.001)+(93.605)+(tcb->m_segmentSize)+(91.841)+(55.364)+(64.82));
tcb->m_segmentSize = (int) (76.237-(9.247)-(21.543)-(31.218)-(24.175)-(83.455)-(71.378)-(43.411));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
