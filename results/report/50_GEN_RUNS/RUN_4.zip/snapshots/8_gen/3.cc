int TKlgWjbjbWOCgWjO = (int) (-99.646*(-60.637)*(-19.663)*(-23.627)*(-65.496)*(-57.343)*(-31.629)*(82.036));
float YfqaYUWLSznnRhcG = (float) ((-14.811*(32.278)*(-77.373)*(47.513)*(-20.36))/-72.435);
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (34.787-(57.084));
	segmentsAcked = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (72.434+(77.568)+(47.013)+(69.687)+(78.998)+(57.556)+(segmentsAcked)+(95.053));

}
tcb->m_cWnd = (int) (25.843+(-94.277)+(27.582)+(-32.923)+(-19.343)+(66.535)+(-19.25)+(-85.363));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (11.376+(82.361)+(tcb->m_cWnd)+(1.336)+(50.332)+(43.035)+(49.885)+(29.113)+(65.844));
	segmentsAcked = (int) (90.204-(30.968)-(14.28)-(69.779)-(46.371));
	YfqaYUWLSznnRhcG = (float) (31.422-(24.654)-(YfqaYUWLSznnRhcG)-(tcb->m_cWnd)-(23.301));

} else {
	tcb->m_segmentSize = (int) (42.472-(69.545));
	YfqaYUWLSznnRhcG = (float) (((0.1)+(0.1)+(0.1)+(0.1)+(0.1)+(79.052))/((0.1)));
	tcb->m_cWnd = (int) (YfqaYUWLSznnRhcG*(28.573)*(tcb->m_segmentSize)*(54.499)*(14.07)*(YfqaYUWLSznnRhcG)*(64.367)*(tcb->m_segmentSize));

}
