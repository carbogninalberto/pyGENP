tcb->m_segmentSize = (int) (40.187+(tcb->m_segmentSize)+(28.941)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(24.818)+(79.281));
segmentsAcked = (int) (((96.668)+((99.315+(9.077)+(segmentsAcked)+(92.061)+(97.746)+(59.879)))+(67.847)+(9.1)+(0.1))/((0.1)+(28.675)+(76.702)+(2.798)));
tcb->m_segmentSize = (int) (0.1/6.105);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (54.17+(segmentsAcked));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	segmentsAcked = (int) (98.373-(segmentsAcked)-(tcb->m_ssThresh)-(53.629)-(82.174)-(56.483)-(tcb->m_ssThresh)-(13.213)-(51.096));
	tcb->m_segmentSize = (int) (10.373+(91.732)+(segmentsAcked)+(43.432)+(73.46));

} else {
	segmentsAcked = (int) (49.774+(10.803)+(3.88));
	tcb->m_segmentSize = (int) (94.628*(4.106)*(62.503)*(89.922)*(98.808)*(71.992));

}
