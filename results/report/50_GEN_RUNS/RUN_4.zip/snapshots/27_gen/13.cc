float GvhQnEKVTUqbNMaU = (float) (((12.947)+(-4.513)+(85.686)+((78.913*(2.755)*(-43.878)*(-42.31)*(12.974)*(-99.917)*(-85.746)*(-76.753)))+(-18.708)+(59.687)+((51.701+(-49.271)+(20.425)+(28.346)+(81.769)+(91.547)+(2.478)))+(-29.197))/((-92.584)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
