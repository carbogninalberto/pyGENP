if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (17.643+(50.451)+(98.483)+(16.359)+(21.976)+(62.703)+(42.047)+(63.849)+(36.61));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(segmentsAcked)*(tcb->m_ssThresh)*(6.67)*(5.954)*(59.741));

}
tcb->m_segmentSize = (int) (23.642-(tcb->m_ssThresh)-(57.231)-(92.589)-(tcb->m_ssThresh)-(11.337)-(tcb->m_cWnd)-(27.217));
tcb->m_segmentSize = (int) (31.965*(29.286)*(7.893)*(82.414)*(22.829)*(51.357)*(22.292)*(41.625));
tcb->m_ssThresh = (int) (42.56+(82.857)+(13.782)+(8.441)+(61.59)+(tcb->m_segmentSize)+(80.129)+(56.766));
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	segmentsAcked = (int) (19.626*(10.351)*(13.973)*(80.124)*(45.399)*(82.4)*(98.179));
	tcb->m_segmentSize = (int) (58.77-(0.754)-(22.738)-(7.408)-(73.375));
	segmentsAcked = (int) (91.355+(16.591));

} else {
	segmentsAcked = (int) (45.533/75.659);

}
