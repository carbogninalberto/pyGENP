float GvhQnEKVTUqbNMaU = (float) (((-55.751)+(-2.72)+(-81.857)+((-92.917*(4.346)*(42.047)*(-3.954)*(95.828)*(80.968)*(3.208)*(4.176)))+(-31.688)+(-13.385)+((12.107+(7.585)+(-29.446)+(64.482)+(-97.88)+(-42.862)+(29.363)))+(23.282))/((92.504)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
