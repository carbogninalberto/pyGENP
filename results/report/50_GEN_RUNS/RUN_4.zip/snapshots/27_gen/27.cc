if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (12.865*(51.53)*(0.986)*(tcb->m_cWnd)*(44.22)*(64.153)*(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) ((((61.622-(10.556)))+(9.079)+(22.231)+(0.1))/((78.391)+(0.1)+(0.1)+(0.1)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (97.762+(7.672));

}
int XRHlkOIkaIvmAWuY = (int) ((93.588+(63.076)+(47.688))/35.981);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((((tcb->m_cWnd-(57.181)-(79.284)-(92.562)-(37.537)-(42.385)-(4.804)-(tcb->m_cWnd)))+((80.024*(93.978)*(tcb->m_ssThresh)*(33.067)*(12.658)*(segmentsAcked)*(68.151)))+(84.652)+(0.1)+(51.975)+(0.1)+(71.427)+(10.195))/((78.921)));

} else {
	tcb->m_cWnd = (int) (30.846*(72.096)*(94.863));

}
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(90.357)-(XRHlkOIkaIvmAWuY)-(segmentsAcked)-(segmentsAcked)-(segmentsAcked)-(57.199)-(64.731));
	XRHlkOIkaIvmAWuY = (int) (99.309/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (68.617-(tcb->m_ssThresh));

}
ReduceCwnd (tcb);
