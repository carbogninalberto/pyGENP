float GvhQnEKVTUqbNMaU = (float) (((53.744)+(-89.256)+(-10.512)+((34.238*(17.859)*(28.145)*(-28.153)*(-64.4)*(-88.025)*(-23.143)*(-61.704)))+(93.797)+(87.827)+((52.099+(-86.88)+(-7.909)+(-21.228)+(-11.312)+(-99.795)+(50.755)))+(99.794))/((46.51)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
