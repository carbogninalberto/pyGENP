float GvhQnEKVTUqbNMaU = (float) (((2.656)+(47.865)+(76.301)+((89.016*(-11.386)*(-45.433)*(48.672)*(-2.723)*(-51.721)*(24.375)*(-92.119)))+(-61.677)+(90.525)+((67.313+(-29.968)+(30.888)+(5.494)+(71.143)+(-59.998)+(-80.408)))+(82.604))/((54.602)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
