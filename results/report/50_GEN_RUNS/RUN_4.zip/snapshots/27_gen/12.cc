float CtiKvbxCUJlaWHbf = (float) (47.212/84.185);
float ZQIWJAmEzNLOSaxr = (float) ((((-40.793-(22.035)-(-63.397)-(-94.516)-(-33.176)-(-25.574)-(69.472)-(-4.838)-(-79.68)))+(20.936)+((-32.571*(2.075)*(-35.792)*(-56.273)*(27.614)))+(-72.789))/((-79.491)+(-25.197)+(-97.991)));
ReduceCwnd (tcb);
int DhTxphFYGZPbJGBB = (int) (86.279+(-43.881)+(-25.815));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (28.101*(-16.92)*(-51.892)*(-41.403)*(-89.504)*(-74.648)*(92.906)*(60.739)*(7.766));
float kfwFXWYjLADOKgKB = (float) 63.697;
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-46.436*(-35.105)*(17.333)*(11.197)*(64.609)*(-24.342)*(62.189)*(15.401)*(-87.104));
if (tcb->m_segmentSize == ZQIWJAmEzNLOSaxr) {
	kfwFXWYjLADOKgKB = (float) (26.809/89.28);
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	kfwFXWYjLADOKgKB = (float) (kfwFXWYjLADOKgKB-(64.972)-(11.426)-(32.908)-(50.792)-(62.188)-(39.401)-(2.334)-(1.441));
	kfwFXWYjLADOKgKB = (float) (((52.617)+(68.106)+((tcb->m_ssThresh*(51.121)))+(0.1)+(85.879)+(2.287))/((17.134)+(0.1)));

}
