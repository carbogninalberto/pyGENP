float GvhQnEKVTUqbNMaU = (float) (((73.325)+(6.998)+(48.644)+((-78.355*(36.321)*(27.261)*(34.613)*(-9.267)*(-4.678)*(-75.807)*(-78.819)))+(-2.725)+(-35.052)+((-30.711+(-84.759)+(68.393)+(-21.707)+(-10.914)+(41.013)+(2.704)))+(-41.116))/((18.844)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
