float GvhQnEKVTUqbNMaU = (float) (((22.633)+(27.93)+(89.675)+((-45.003*(62.397)*(20.723)*(-40.719)*(46.06)*(-6.707)*(-48.042)*(-21.942)))+(-45.405)+(9.138)+((44.557+(-32.688)+(59.56)+(44.379)+(-77.614)+(76.998)+(27.548)))+(54.528))/((-58.624)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
