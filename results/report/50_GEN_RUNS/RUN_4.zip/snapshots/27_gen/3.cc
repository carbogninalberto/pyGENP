float GvhQnEKVTUqbNMaU = (float) (((-56.749)+(-29.684)+(-3.836)+((-34.087*(-7.349)*(-89.458)*(54.261)*(-1.289)*(16.984)*(34.944)*(66.946)))+(1.42)+(50.339)+((28.58+(-55.238)+(-70.202)+(-40.275)+(-90.309)+(91.959)+(27.034)))+(-14.615))/((39.16)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
