int JnChXPHXjJXoQSMR = (int) (-12.732/-0.22);
float kfwFXWYjLADOKgKB = (float) 41.449;
ReduceCwnd (tcb);
float ZQIWJAmEzNLOSaxr = (float) 27.691;
if (tcb->m_segmentSize == ZQIWJAmEzNLOSaxr) {
	kfwFXWYjLADOKgKB = (float) (kfwFXWYjLADOKgKB-(64.972)-(11.426)-(32.908)-(50.792)-(62.188)-(39.401)-(2.334)-(1.441));
	kfwFXWYjLADOKgKB = (float) (((52.617)+(68.106)+((tcb->m_ssThresh*(51.121)))+(0.1)+(85.879)+(2.287))/((17.134)+(0.1)));

} else {
	kfwFXWYjLADOKgKB = (float) (26.809/89.28);
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
