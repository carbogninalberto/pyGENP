float GvhQnEKVTUqbNMaU = (float) (((23.635)+(81.968)+(-85.158)+((-44.848*(-66.819)*(-12.265)*(68.035)*(-73.852)*(-79.025)*(-35.428)*(17.309)))+(9.019)+(-77.688)+((47.341+(-59.126)+(63.062)+(-5.482)+(79.084)+(77.329)+(46.276)))+(-76.13))/((-53.823)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
