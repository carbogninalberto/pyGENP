tcb->m_cWnd = (int) (((11.058)+(0.1)+(50.749)+(10.368)+(0.1))/((45.121)+(61.83)));
int rmzNqAyoeVXdrJmt = (int) (45.199*(51.954)*(98.962)*(39.691)*(57.414)*(47.264)*(3.594));
ReduceCwnd (tcb);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (77.075+(56.771));
	tcb->m_segmentSize = (int) (16.141+(59.585)+(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (55.66-(tcb->m_cWnd)-(70.579)-(89.492)-(tcb->m_cWnd)-(60.556)-(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (30.146*(70.997)*(55.382));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = (int) (67.417-(rmzNqAyoeVXdrJmt)-(46.976)-(77.084));
tcb->m_segmentSize = (int) (rmzNqAyoeVXdrJmt+(71.656)+(54.803)+(9.899)+(tcb->m_ssThresh));
ReduceCwnd (tcb);
