TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-57.315-(-93.889)-(-50.227)-(-7.341)-(-33.771)-(89.834));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
