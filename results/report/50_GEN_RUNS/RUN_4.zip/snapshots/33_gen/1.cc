segmentsAcked = (int) (28.283-(-68.03)-(33.715)-(93.833)-(-34.32)-(6.664)-(95.873)-(-27.407)-(59.708));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (16.286-(tcb->m_cWnd)-(39.851)-(62.394)-(92.119));

} else {
	tcb->m_cWnd = (int) (0.1/83.312);

}
segmentsAcked = (int) (34.782+(-39.093)+(14.049)+(-26.308)+(60.737)+(53.672)+(74.146)+(-86.987));
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (87.728-(82.642)-(31.079)-(69.082)-(77.0));
	tcb->m_segmentSize = (int) (67.37-(79.33)-(10.074)-(11.724)-(85.168)-(69.665)-(63.669));

} else {
	tcb->m_segmentSize = (int) (7.884-(91.585)-(22.317)-(50.142)-(40.201)-(93.23)-(21.061));
	segmentsAcked = (int) (49.054+(8.339)+(40.481)+(52.901)+(78.893));

}
segmentsAcked = (int) (53.639+(-92.512)+(17.604)+(68.212)+(65.878)+(84.866)+(80.302));
CongestionAvoidance (tcb, segmentsAcked);
