ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
float JvPpzYZQpsmXkCCS = (float) (99.595+(41.388)+(33.596)+(-0.015)+(84.752)+(78.353)+(58.342)+(1.253)+(20.039));
tcb->m_ssThresh = (int) (JvPpzYZQpsmXkCCS*(JvPpzYZQpsmXkCCS)*(segmentsAcked)*(60.906));
segmentsAcked = (int) (((95.635)+(92.214)+(0.1)+(68.342)+(0.1)+(1.308))/((77.394)+(24.047)+(0.1)));
