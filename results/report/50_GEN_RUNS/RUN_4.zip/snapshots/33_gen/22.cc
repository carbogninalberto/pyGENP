if (tcb->m_segmentSize == tcb->m_ssThresh) {
	segmentsAcked = (int) (81.77+(29.576)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(62.498)+(0.1)+(12.912)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (73.881-(54.432));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (84.374+(tcb->m_cWnd)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(27.648));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (82.035/0.1);

}
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(tcb->m_segmentSize)-(43.538)-(15.94)-(48.382));

} else {
	tcb->m_ssThresh = (int) (4.457-(47.201)-(7.342)-(83.71)-(50.922)-(7.387));
	tcb->m_ssThresh = (int) (47.568+(15.468)+(tcb->m_segmentSize)+(55.304)+(89.313)+(14.437)+(2.33));

}
float fGgmIIxIEqwmBFwI = (float) (76.761+(6.552)+(51.623)+(37.587)+(18.794)+(4.911));
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (52.098+(69.093)+(94.217)+(20.101)+(16.811)+(52.772)+(tcb->m_cWnd)+(37.337)+(42.575));
	fGgmIIxIEqwmBFwI = (float) (31.982*(17.453)*(1.069));
	tcb->m_ssThresh = (int) (74.294+(tcb->m_cWnd)+(36.188)+(segmentsAcked)+(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (40.964*(fGgmIIxIEqwmBFwI)*(0.883)*(tcb->m_segmentSize)*(99.166));

}
if (tcb->m_ssThresh < tcb->m_cWnd) {
	segmentsAcked = (int) (45.762-(23.33)-(fGgmIIxIEqwmBFwI)-(43.804)-(48.797)-(70.718));
	tcb->m_ssThresh = (int) (93.508*(23.641)*(2.078)*(60.048)*(26.335));
	segmentsAcked = (int) (33.73+(61.879)+(94.213));

} else {
	segmentsAcked = (int) (64.281/0.1);
	tcb->m_cWnd = (int) (75.522-(19.178)-(87.914)-(3.761)-(50.833)-(tcb->m_segmentSize)-(32.792));
	tcb->m_ssThresh = (int) (0.1/0.1);

}
