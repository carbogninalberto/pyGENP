segmentsAcked = (int) (4.189+(46.857)+(11.217));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (64.666-(75.15)-(32.453)-(48.839)-(10.716)-(11.448)-(75.915)-(34.307)-(62.478));
	tcb->m_ssThresh = (int) (segmentsAcked*(tcb->m_segmentSize)*(35.289)*(4.731)*(21.812)*(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (70.767-(74.84)-(25.92));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (segmentsAcked*(93.479)*(tcb->m_segmentSize)*(segmentsAcked)*(48.995));

} else {
	tcb->m_segmentSize = (int) (90.087-(tcb->m_segmentSize));

}
tcb->m_ssThresh = (int) (55.547-(35.385)-(35.763)-(53.277));
segmentsAcked = SlowStart (tcb, segmentsAcked);
