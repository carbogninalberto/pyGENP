int lYQKASSFjZEdZsXr = (int) (0.1/66.102);
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_cWnd = (int) (58.555/90.862);

} else {
	tcb->m_cWnd = (int) (75.012*(79.558)*(78.623)*(tcb->m_cWnd)*(80.579)*(32.038)*(lYQKASSFjZEdZsXr));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (18.674*(12.665)*(tcb->m_ssThresh)*(57.292)*(62.872)*(12.401)*(73.009)*(79.745));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (lYQKASSFjZEdZsXr < tcb->m_ssThresh) {
	lYQKASSFjZEdZsXr = (int) (21.979-(29.031)-(80.848)-(67.227)-(lYQKASSFjZEdZsXr)-(30.275)-(82.459)-(28.809)-(70.387));

} else {
	lYQKASSFjZEdZsXr = (int) (tcb->m_segmentSize+(77.329)+(47.919)+(63.106)+(27.86));

}
tcb->m_ssThresh = (int) (0.1/0.1);
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (24.041*(28.378)*(47.379)*(51.486)*(7.523)*(tcb->m_cWnd));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (21.505*(lYQKASSFjZEdZsXr));

} else {
	tcb->m_ssThresh = (int) ((0.091*(tcb->m_segmentSize)*(84.413)*(78.732)*(62.869)*(lYQKASSFjZEdZsXr)*(83.238))/0.1);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (0.1/0.1);

}
