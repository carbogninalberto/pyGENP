tcb->m_segmentSize = (int) (-22.615/-81.015);
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/83.312);

} else {
	tcb->m_cWnd = (int) (16.286-(tcb->m_cWnd)-(39.851)-(62.394)-(92.119));

}
segmentsAcked = (int) (-32.438+(41.147)+(30.728)+(91.687)+(-91.215)+(96.803)+(-36.068)+(-93.411));
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (87.728-(82.642)-(31.079)-(69.082)-(77.0));
	tcb->m_segmentSize = (int) (67.37-(79.33)-(10.074)-(11.724)-(85.168)-(69.665)-(63.669));

} else {
	tcb->m_segmentSize = (int) (7.884-(91.585)-(-80.224)-(50.142)-(40.201)-(93.23)-(21.061));
	segmentsAcked = (int) (49.054+(8.339)+(40.481)+(52.901)+(78.893));

}
segmentsAcked = (int) (50.626+(25.119)+(94.045)+(-93.07)+(62.979)+(13.299)+(58.85));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (87.728-(82.642)-(31.079)-(69.082)-(77.0));
	tcb->m_segmentSize = (int) (67.37-(79.33)-(10.074)-(11.724)-(85.168)-(69.665)-(63.669));

} else {
	tcb->m_segmentSize = (int) (7.884-(91.585)-(-47.126)-(50.142)-(40.201)-(93.23)-(21.061));
	segmentsAcked = (int) (49.054+(8.339)+(40.481)+(52.901)+(78.893));

}
segmentsAcked = (int) (-18.505+(59.556)+(24.249)+(77.601)+(-78.722)+(-77.458)+(75.147));
CongestionAvoidance (tcb, segmentsAcked);
