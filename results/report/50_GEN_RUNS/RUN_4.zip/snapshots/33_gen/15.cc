if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (86.781+(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (94.745+(97.591)+(6.334)+(tcb->m_segmentSize)+(78.668)+(84.673));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (19.672*(73.502)*(2.831)*(6.017));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (57.868*(40.616)*(63.498)*(5.134)*(48.229)*(70.441)*(18.271));

} else {
	tcb->m_ssThresh = (int) ((53.245-(34.966)-(72.748)-(tcb->m_cWnd)-(78.768)-(92.417)-(56.517))/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
