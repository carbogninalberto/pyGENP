tcb->m_cWnd = (int) (((0.1)+((87.363*(31.097)*(87.835)*(74.235)*(63.229)))+((69.827*(56.871)*(39.337)*(79.937)*(tcb->m_cWnd)*(segmentsAcked)*(30.329)))+(0.1)+(63.578))/((0.1)));
tcb->m_segmentSize = (int) (10.444*(40.154)*(41.425)*(35.378)*(46.159)*(segmentsAcked)*(35.073)*(26.054));
tcb->m_ssThresh = (int) (60.945+(28.217)+(55.988)+(17.538));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((39.029)+(0.1)+(53.9)+(0.1)+(71.424)+(0.1))/((0.1)+(75.71)));

} else {
	tcb->m_cWnd = (int) (20.723/0.1);
	segmentsAcked = (int) (80.926*(80.456)*(tcb->m_segmentSize)*(85.879)*(93.045)*(92.853));

}
