float KkvKnxPVbMkvHDjS = (float) (-11.861-(-61.718)-(-36.455));
float INPITWTLnckaeJJo = (float) (((-95.481)+((-55.715+(92.392)+(7.495)+(-87.133)+(-5.797)))+(51.988)+(-32.576))/((20.858)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (85.824+(tcb->m_cWnd)+(61.045));

} else {
	tcb->m_cWnd = (int) (71.415+(40.68)+(97.389)+(2.088)+(segmentsAcked)+(52.115)+(54.724)+(90.205));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (95.895+(96.629)+(76.053)+(0.576)+(6.426)+(81.005)+(37.009)+(81.446)+(96.919));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
