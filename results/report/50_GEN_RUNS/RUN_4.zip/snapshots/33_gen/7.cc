ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-46.464-(22.494)-(82.812)-(-21.115)-(96.209)-(-93.92)-(-14.864)-(-71.863));
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/26.391);

} else {
	tcb->m_cWnd = (int) (43.706-(2.347)-(58.457)-(85.661)-(63.341)-(25.696)-(36.083)-(26.021));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (78.505*(62.5)*(64.062)*(97.493));

}
tcb->m_segmentSize = (int) (98.913-(-70.025)-(57.826)-(-47.862)-(-84.429)-(58.904)-(-72.444)-(57.917));
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/26.391);

} else {
	tcb->m_cWnd = (int) (43.706-(-46.105)-(58.457)-(85.661)-(63.341)-(25.696)-(36.083)-(26.021));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (78.505*(62.5)*(64.062)*(97.493));

}
