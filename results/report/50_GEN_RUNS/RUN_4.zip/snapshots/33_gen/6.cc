tcb->m_cWnd = (int) (((56.545)+(-65.127)+(93.162)+((2.654-(-29.463)))+(55.066))/((-79.973)));
int VPZRGmGSXcSDdhAj = (int) 82.698;
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (81.799*(50.958)*(7.382)*(31.551)*(-93.17)*(91.47)*(34.99)*(-50.514));
tcb->m_segmentSize = (int) (51.359*(-49.328)*(-34.916)*(96.004)*(-18.607));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	VPZRGmGSXcSDdhAj = (int) (97.345-(7.197)-(tcb->m_segmentSize)-(31.636)-(35.762)-(segmentsAcked)-(11.903)-(14.55)-(97.644));

} else {
	VPZRGmGSXcSDdhAj = (int) (79.048+(15.946));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	VPZRGmGSXcSDdhAj = (int) (segmentsAcked+(segmentsAcked));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (6.306*(69.651)*(-78.452)*(13.476)*(19.45));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	VPZRGmGSXcSDdhAj = (int) (97.345-(7.197)-(tcb->m_segmentSize)-(31.636)-(35.762)-(segmentsAcked)-(11.903)-(14.55)-(97.644));

} else {
	VPZRGmGSXcSDdhAj = (int) (79.048+(15.946));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	VPZRGmGSXcSDdhAj = (int) (segmentsAcked+(segmentsAcked));

}
CongestionAvoidance (tcb, segmentsAcked);
