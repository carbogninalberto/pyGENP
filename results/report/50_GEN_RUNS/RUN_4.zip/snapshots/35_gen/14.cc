tcb->m_ssThresh = (int) (33.527+(tcb->m_segmentSize)+(6.204)+(tcb->m_cWnd)+(96.146)+(15.832));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int SNaxqzBHqoIvDInL = (int) (((23.365)+(0.1)+((32.527*(28.791)*(tcb->m_ssThresh)*(81.949)))+(38.032)+(70.252))/((0.1)));
int ZeMFNginzrSuPrsJ = (int) (tcb->m_ssThresh-(96.098)-(22.313)-(46.061)-(segmentsAcked)-(94.996)-(SNaxqzBHqoIvDInL)-(98.207));
tcb->m_ssThresh = (int) (93.084+(segmentsAcked)+(35.47)+(67.674)+(7.193)+(segmentsAcked)+(95.757));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) ((tcb->m_ssThresh-(23.907)-(82.547)-(9.798)-(2.845)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(8.405)-(19.104))/0.1);
ZeMFNginzrSuPrsJ = (int) (63.182+(tcb->m_ssThresh)+(3.027)+(92.174)+(86.667));
