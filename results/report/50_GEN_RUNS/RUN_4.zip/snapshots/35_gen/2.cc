TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (56.279-(68.471)-(14.882)-(14.029)-(62.908)-(44.731)-(93.48)-(-15.378));
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (43.706-(2.347)-(58.457)-(85.661)-(63.341)-(25.696)-(36.083)-(26.021));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (78.505*(62.5)*(64.062)*(97.493));

} else {
	tcb->m_cWnd = (int) (0.1/26.391);

}
tcb->m_segmentSize = (int) (16.124-(-18.884)-(94.012)-(34.4)-(6.627)-(-54.249)-(-19.51)-(-34.101));
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/26.391);

} else {
	tcb->m_cWnd = (int) (43.706-(-46.105)-(58.457)-(85.661)-(63.341)-(25.696)-(36.083)-(26.021));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (78.505*(62.5)*(64.062)*(97.493));

}
