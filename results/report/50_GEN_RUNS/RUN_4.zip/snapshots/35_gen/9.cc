tcb->m_ssThresh = (int) (tcb->m_ssThresh*(84.455)*(20.753)*(segmentsAcked));
tcb->m_ssThresh = (int) (14.854*(96.854));
tcb->m_cWnd = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(tcb->m_segmentSize)*(87.32)*(16.327)*(60.839));
tcb->m_ssThresh = (int) (((0.1)+(78.364)+(0.1)+((70.913*(41.562)))+(0.1))/((0.1)+(5.483)+(7.29)+(0.1)));
tcb->m_cWnd = (int) (tcb->m_cWnd+(56.432)+(17.31)+(28.567)+(41.687)+(17.092)+(38.726)+(25.711));
ReduceCwnd (tcb);
