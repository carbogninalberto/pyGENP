if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (4.572-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(30.188)-(26.954)-(segmentsAcked)-(11.844));
	segmentsAcked = (int) (74.832*(75.547)*(39.4)*(2.894)*(76.64)*(94.145)*(tcb->m_ssThresh)*(54.216));

} else {
	tcb->m_segmentSize = (int) (18.283-(39.015)-(5.383)-(7.749)-(68.882)-(39.503));
	tcb->m_ssThresh = (int) (7.84*(tcb->m_cWnd)*(61.276)*(73.98)*(99.404)*(1.955)*(tcb->m_segmentSize)*(4.773)*(3.065));

}
tcb->m_ssThresh = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(62.344)*(tcb->m_cWnd)*(89.156)*(59.317)*(90.026)*(segmentsAcked)*(85.384));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (tcb->m_ssThresh*(58.537)*(22.64)*(75.593)*(tcb->m_segmentSize)*(18.151)*(47.244)*(42.973));
