tcb->m_cWnd = (int) (72.902-(61.704)-(25.863)-(80.843)-(4.467)-(82.959));
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (91.497*(2.205)*(18.434)*(1.846)*(52.368)*(32.089)*(24.193));
	tcb->m_ssThresh = (int) (40.663+(57.187)+(89.726)+(82.938)+(93.519)+(30.64));

} else {
	tcb->m_ssThresh = (int) (94.922+(40.657)+(52.601)+(35.154)+(tcb->m_segmentSize));

}
tcb->m_cWnd = (int) (43.911+(92.636)+(16.135)+(tcb->m_ssThresh)+(87.676)+(6.756));
tcb->m_cWnd = (int) (93.924/92.068);
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	segmentsAcked = (int) ((((93.651*(67.085)*(99.851)*(42.591)))+(14.436)+(87.555)+(74.081))/((0.1)+(70.529)+(0.1)));
	tcb->m_ssThresh = (int) (4.705+(2.521)+(tcb->m_cWnd)+(57.429)+(tcb->m_segmentSize)+(7.948)+(segmentsAcked)+(segmentsAcked)+(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (54.229+(3.248)+(29.858)+(tcb->m_cWnd)+(58.695)+(13.51));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (92.134*(33.945)*(55.446)*(57.482));

}
CongestionAvoidance (tcb, segmentsAcked);
