int ZaFbakllUOUAcwZS = (int) (tcb->m_segmentSize-(33.909)-(55.675)-(34.372)-(50.948)-(30.644)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(71.245));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > ZaFbakllUOUAcwZS) {
	segmentsAcked = (int) (15.408-(19.986)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(63.981)-(29.153)-(4.776)-(98.021)-(37.313));
	ZaFbakllUOUAcwZS = (int) (85.529-(tcb->m_ssThresh)-(tcb->m_cWnd)-(42.974)-(29.7)-(94.951)-(10.826));

} else {
	segmentsAcked = (int) (23.5+(tcb->m_cWnd));
	tcb->m_cWnd = (int) (73.927+(tcb->m_cWnd)+(ZaFbakllUOUAcwZS)+(15.045)+(tcb->m_segmentSize));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (tcb->m_segmentSize*(44.455)*(54.272)*(5.712)*(56.672));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (4.045/58.76);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
