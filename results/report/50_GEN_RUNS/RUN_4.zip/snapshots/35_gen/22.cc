tcb->m_cWnd = (int) (69.848*(49.179)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(tcb->m_ssThresh));
if (tcb->m_cWnd > tcb->m_ssThresh) {
	segmentsAcked = (int) (16.375+(tcb->m_segmentSize)+(43.18)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(53.331)+(15.919));
	tcb->m_cWnd = (int) (4.854+(10.81)+(52.21)+(segmentsAcked));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (tcb->m_cWnd+(81.853)+(82.371)+(68.873)+(42.156)+(78.804)+(33.013));

}
tcb->m_ssThresh = (int) (tcb->m_cWnd+(segmentsAcked)+(9.823));
tcb->m_segmentSize = (int) (59.236-(80.456)-(28.815)-(91.323));
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (90.806+(46.955)+(tcb->m_cWnd)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (90.968-(tcb->m_ssThresh)-(28.828)-(85.054)-(2.951)-(95.808));

}
tcb->m_cWnd = (int) (42.013-(69.479)-(78.941)-(tcb->m_segmentSize));
ReduceCwnd (tcb);
