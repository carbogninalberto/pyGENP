tcb->m_ssThresh = (int) (51.127*(74.418)*(81.873));
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) ((68.172-(23.16)-(52.967)-(14.031)-(65.199))/48.912);
	tcb->m_cWnd = (int) (68.353-(59.857));

} else {
	tcb->m_segmentSize = (int) (82.28+(80.681)+(14.221)+(21.666)+(tcb->m_cWnd)+(26.892)+(23.415)+(68.116)+(69.845));

}
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((22.123)+(23.474)+(0.1)+(43.985)+(0.1))/((11.277)+(34.031)+(0.1)));
	ReduceCwnd (tcb);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (10.2*(22.852)*(22.783)*(69.175)*(97.52)*(41.627)*(32.89));
	segmentsAcked = (int) (((0.1)+(64.407)+(0.1)+((64.54-(62.855)-(tcb->m_cWnd)-(97.201)-(92.623)-(71.661)))+(71.214))/((0.1)+(18.313)));
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (38.313-(tcb->m_ssThresh)-(12.155)-(segmentsAcked)-(27.959)-(40.739)-(13.854));
	tcb->m_cWnd = (int) (73.179-(98.37)-(62.944)-(segmentsAcked)-(42.686));
	segmentsAcked = (int) (79.928+(21.826)+(35.521)+(26.52));

} else {
	tcb->m_segmentSize = (int) (58.915-(38.122)-(tcb->m_cWnd)-(18.809)-(tcb->m_segmentSize)-(77.593));

}
int uSSGTzdGDcsHYvpK = (int) (tcb->m_segmentSize-(59.142)-(segmentsAcked)-(36.138)-(10.578)-(segmentsAcked));
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	segmentsAcked = (int) (18.171*(24.719)*(20.56)*(tcb->m_segmentSize)*(36.494)*(15.872)*(16.89)*(47.591)*(tcb->m_ssThresh));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (segmentsAcked-(95.78)-(3.059)-(23.516)-(63.532));

}
