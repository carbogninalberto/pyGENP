segmentsAcked = (int) (tcb->m_ssThresh*(tcb->m_segmentSize)*(tcb->m_ssThresh));
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(tcb->m_segmentSize)-(segmentsAcked)-(44.907)-(87.771));

}
int JugXJedfVdGOsibB = (int) (0.1/43.09);
int rxqiRKPuCDeXjZLf = (int) (46.565+(0.816)+(47.607)+(60.032)+(JugXJedfVdGOsibB));
JugXJedfVdGOsibB = (int) (29.025+(92.223)+(65.316));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
