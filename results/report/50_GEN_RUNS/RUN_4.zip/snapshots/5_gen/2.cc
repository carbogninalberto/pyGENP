segmentsAcked = (int) (89.074*(30.163)*(91.185)*(57.186)*(-78.921)*(-81.297));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-10.821/-9.157);
tcb->m_segmentSize = (int) (-92.831-(94.891)-(-73.875)-(-71.833)-(67.74)-(30.593)-(98.647));
