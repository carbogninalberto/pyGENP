if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (46.071/0.1);
	tcb->m_segmentSize = (int) (31.927/33.461);

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(47.855)+(0.1))/((24.687)+(14.866)+(86.819)+(0.1)));

}
tcb->m_cWnd = (int) (97.279*(16.691)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(49.23)*(51.12)*(52.502)*(segmentsAcked));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (9.446*(tcb->m_segmentSize)*(14.798)*(92.222)*(57.766)*(20.041)*(65.358)*(9.033)*(69.426));
tcb->m_ssThresh = (int) (64.372+(94.274)+(76.605)+(15.09)+(47.389)+(55.594)+(28.053)+(99.457)+(68.624));
tcb->m_cWnd = (int) (3.507-(72.493));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
