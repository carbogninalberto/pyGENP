float ADjLVsuVIPICgzes = (float) (-74.28-(-5.404));
tcb->m_segmentSize = (int) (58.968-(9.699)-(-53.21)-(-0.215));
int NFrOHWyPZFYLaDRE = (int) 33.297;
segmentsAcked = (int) (31.874+(-63.341)+(-17.294)+(97.782));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	NFrOHWyPZFYLaDRE = (int) (95.651-(48.396)-(16.645)-(50.563)-(56.501));

} else {
	NFrOHWyPZFYLaDRE = (int) ((NFrOHWyPZFYLaDRE*(49.59)*(44.307)*(tcb->m_cWnd)*(21.144)*(tcb->m_segmentSize)*(60.592)*(11.75))/20.05);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (ADjLVsuVIPICgzes <= NFrOHWyPZFYLaDRE) {
	NFrOHWyPZFYLaDRE = (int) (NFrOHWyPZFYLaDRE*(58.296)*(79.778));
	NFrOHWyPZFYLaDRE = (int) (49.246-(55.676)-(34.77)-(58.6)-(tcb->m_cWnd)-(31.247)-(81.999)-(94.394)-(43.503));
	ReduceCwnd (tcb);

} else {
	NFrOHWyPZFYLaDRE = (int) (0.196-(44.948)-(48.943)-(6.847));
	segmentsAcked = (int) (((86.382)+(0.1)+(60.576)+(0.1)+(78.956)+(34.608))/((76.71)+(0.1)));
	segmentsAcked = (int) (0.1/81.678);

}
segmentsAcked = (int) (26.855+(-10.262)+(39.999)+(-91.347));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	NFrOHWyPZFYLaDRE = (int) (95.651-(48.396)-(16.645)-(50.563)-(56.501));

} else {
	NFrOHWyPZFYLaDRE = (int) ((NFrOHWyPZFYLaDRE*(49.59)*(44.307)*(tcb->m_cWnd)*(21.144)*(tcb->m_segmentSize)*(60.592)*(11.75))/20.05);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (ADjLVsuVIPICgzes <= NFrOHWyPZFYLaDRE) {
	NFrOHWyPZFYLaDRE = (int) (NFrOHWyPZFYLaDRE*(58.296)*(79.778));
	NFrOHWyPZFYLaDRE = (int) (49.246-(55.676)-(34.77)-(58.6)-(tcb->m_cWnd)-(31.247)-(81.999)-(94.394)-(43.503));
	ReduceCwnd (tcb);

} else {
	NFrOHWyPZFYLaDRE = (int) (0.196-(44.948)-(48.943)-(6.847));
	segmentsAcked = (int) (((86.382)+(0.1)+(60.576)+(0.1)+(78.956)+(34.608))/((76.71)+(0.1)));
	segmentsAcked = (int) (0.1/81.678);

}
