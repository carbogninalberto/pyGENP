CongestionAvoidance (tcb, segmentsAcked);
int rngMFFLuluiwEPBP = (int) (25.846/0.532);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= rngMFFLuluiwEPBP) {
	segmentsAcked = (int) ((((73.362-(2.156)-(46.953)-(tcb->m_segmentSize)-(40.65)-(64.508)-(13.782)))+((41.6*(segmentsAcked)*(tcb->m_cWnd)*(25.043)))+(0.1)+(0.1)+(0.1))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (89.573*(40.006)*(13.89)*(78.697));

} else {
	segmentsAcked = (int) (36.923-(42.043)-(2.607)-(12.975)-(89.996)-(49.771)-(87.48)-(89.685));
	segmentsAcked = (int) (-2.526-(tcb->m_segmentSize)-(5.493)-(6.613)-(tcb->m_cWnd)-(86.425)-(58.898)-(tcb->m_segmentSize));

}
