int cnIInQKRsjRkdQJT = (int) (85.001*(96.747)*(tcb->m_segmentSize)*(58.237));
if (segmentsAcked <= segmentsAcked) {
	cnIInQKRsjRkdQJT = (int) (92.648*(73.025)*(39.215)*(7.039)*(tcb->m_segmentSize)*(73.641)*(58.671)*(15.417)*(40.44));
	cnIInQKRsjRkdQJT = (int) (tcb->m_segmentSize-(75.898)-(63.182));
	cnIInQKRsjRkdQJT = (int) (0.852+(tcb->m_ssThresh)+(48.674)+(18.239)+(53.525)+(85.822)+(65.71)+(36.906));

} else {
	cnIInQKRsjRkdQJT = (int) (tcb->m_cWnd+(48.08));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize == cnIInQKRsjRkdQJT) {
	segmentsAcked = (int) (67.202+(tcb->m_segmentSize)+(80.296)+(31.804));

} else {
	segmentsAcked = (int) (66.055+(87.293)+(56.666)+(73.71));
	segmentsAcked = (int) (73.82-(3.759)-(88.739));

}
if (cnIInQKRsjRkdQJT == cnIInQKRsjRkdQJT) {
	segmentsAcked = (int) (23.802*(21.055)*(segmentsAcked)*(tcb->m_segmentSize)*(88.137)*(10.753)*(tcb->m_ssThresh)*(8.879)*(7.106));
	cnIInQKRsjRkdQJT = (int) (99.748-(82.293)-(23.708)-(37.007));
	tcb->m_ssThresh = (int) (28.991+(56.36));

} else {
	segmentsAcked = (int) (segmentsAcked*(8.394)*(37.047)*(29.228)*(tcb->m_ssThresh));

}
int qWrQAoqyjKsRrRvi = (int) (10.456-(72.317)-(87.188)-(22.414)-(71.839)-(3.594)-(59.599)-(cnIInQKRsjRkdQJT)-(37.941));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked != cnIInQKRsjRkdQJT) {
	tcb->m_cWnd = (int) (0.1/66.904);

} else {
	tcb->m_cWnd = (int) (53.289*(97.816)*(73.437)*(90.583)*(90.126)*(66.951)*(77.004)*(92.752)*(51.438));
	qWrQAoqyjKsRrRvi = (int) (56.452*(74.892));

}
if (tcb->m_cWnd >= cnIInQKRsjRkdQJT) {
	segmentsAcked = (int) (48.729*(77.041)*(8.098));
	cnIInQKRsjRkdQJT = (int) ((segmentsAcked+(segmentsAcked)+(59.014))/0.1);

} else {
	segmentsAcked = (int) (60.129-(15.029)-(94.286)-(qWrQAoqyjKsRrRvi)-(4.0)-(66.903)-(17.798)-(85.779)-(11.524));
	tcb->m_cWnd = (int) (11.953/76.974);

}
