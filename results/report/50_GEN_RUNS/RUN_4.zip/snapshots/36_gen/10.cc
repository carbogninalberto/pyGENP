TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-50.423+(88.801)+(-38.636)+(47.809)+(-47.274)+(-52.437));
tcb->m_cWnd = (int) (-13.52/83.143);
CongestionAvoidance (tcb, segmentsAcked);
