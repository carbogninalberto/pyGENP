if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) ((((9.582*(68.149)*(tcb->m_segmentSize)*(35.823)*(41.288)*(27.542)))+(91.037)+(62.773)+(1.662)+(0.1)+(0.1))/((90.58)+(0.1)));
	segmentsAcked = (int) (21.455/0.1);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(12.446)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (25.879-(13.886)-(35.691)-(69.539)-(90.382));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-82.366-(16.414)-(36.481)-(1.301)-(-71.633)-(89.227)-(-63.502));
