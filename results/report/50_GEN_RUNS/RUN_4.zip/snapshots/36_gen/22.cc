tcb->m_cWnd = (int) (49.691*(42.566)*(94.68));
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_ssThresh = (int) (44.995+(75.921)+(0.225));
	tcb->m_ssThresh = (int) (41.626*(11.91)*(51.294)*(28.04)*(55.86)*(tcb->m_cWnd)*(62.904));
	tcb->m_ssThresh = (int) (73.44+(22.52)+(92.577)+(18.482)+(tcb->m_ssThresh)+(27.705)+(77.918));

} else {
	tcb->m_ssThresh = (int) (31.202+(tcb->m_ssThresh)+(69.469)+(48.002)+(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (62.323+(46.92)+(75.354)+(segmentsAcked)+(41.376));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) ((16.241*(92.324)*(15.569)*(36.282)*(34.11))/0.1);
	tcb->m_segmentSize = (int) (53.678*(60.428)*(43.806)*(28.04)*(90.258)*(37.87)*(segmentsAcked)*(27.721)*(46.126));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (95.377-(tcb->m_segmentSize)-(88.737)-(2.606));

} else {
	tcb->m_cWnd = (int) (85.058/7.741);

}
