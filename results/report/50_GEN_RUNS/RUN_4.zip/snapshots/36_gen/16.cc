ReduceCwnd (tcb);
float oWzFRcBQFWGdUEUP = (float) (47.114*(59.55)*(39.756)*(25.637)*(tcb->m_ssThresh)*(49.082));
float VPMHZFWxhLmwpRoZ = (float) ((12.564+(5.671)+(tcb->m_ssThresh)+(11.873)+(11.532)+(75.301)+(1.552))/0.1);
int QpeVkceElOjmdJZu = (int) ((82.291*(24.776))/81.651);
tcb->m_ssThresh = (int) (27.59-(61.966)-(VPMHZFWxhLmwpRoZ)-(39.314));
int MQgPikcovwBUtcCj = (int) (64.727-(5.002)-(43.939)-(75.031));
if (MQgPikcovwBUtcCj <= segmentsAcked) {
	oWzFRcBQFWGdUEUP = (float) (MQgPikcovwBUtcCj*(VPMHZFWxhLmwpRoZ));
	QpeVkceElOjmdJZu = (int) (((65.972)+(63.869)+(57.188)+(30.931))/((11.093)+(0.1)));

} else {
	oWzFRcBQFWGdUEUP = (float) (56.964-(12.474)-(36.801)-(39.4)-(29.181)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (67.054-(oWzFRcBQFWGdUEUP)-(72.279)-(86.204)-(tcb->m_segmentSize)-(71.239)-(VPMHZFWxhLmwpRoZ)-(47.266)-(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
