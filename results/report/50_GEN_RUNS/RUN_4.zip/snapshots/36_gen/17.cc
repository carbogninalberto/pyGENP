if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (62.654-(61.029)-(31.231)-(82.438)-(16.2)-(39.046)-(25.151));

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(1.512)+(73.499)+(94.877)+(0.1)+(0.1))/((0.1)));
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(66.076)+(36.424)+(0.1))/((51.451)+(45.633)));
	tcb->m_cWnd = (int) ((((17.892*(26.126)))+(29.024)+(0.1)+(28.317)+(34.007))/((0.1)+(0.1)));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (0.1/51.4);
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(73.644)*(segmentsAcked)*(64.454)*(segmentsAcked)*(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) ((26.96*(59.517)*(47.358)*(3.294)*(74.376)*(92.601)*(segmentsAcked)*(tcb->m_ssThresh)*(65.862))/0.1);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(19.03)*(59.848)*(51.648)*(49.452)*(47.77)*(66.365));
	segmentsAcked = (int) (tcb->m_segmentSize+(22.055)+(80.347)+(94.813)+(85.703)+(19.472));

}
tcb->m_segmentSize = (int) (6.963/0.1);
