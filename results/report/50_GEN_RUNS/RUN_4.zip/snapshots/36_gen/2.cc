int SNaxqzBHqoIvDInL = (int) (((-0.012)+(65.671)+((-34.085*(-8.333)*(74.542)*(54.395)))+(58.517)+(72.496))/((51.64)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
