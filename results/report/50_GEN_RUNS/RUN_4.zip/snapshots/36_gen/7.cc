tcb->m_segmentSize = (int) (95.032-(4.267)-(-42.792)-(98.024));
tcb->m_cWnd = (int) (-18.46-(69.03)-(-1.262)-(58.981));
ReduceCwnd (tcb);
