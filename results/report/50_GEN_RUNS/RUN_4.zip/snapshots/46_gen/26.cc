ReduceCwnd (tcb);
segmentsAcked = (int) (0.1/29.31);
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) (81.212/19.593);
	segmentsAcked = (int) (57.225+(14.161));
	segmentsAcked = (int) (tcb->m_cWnd+(12.454)+(16.217)+(79.631)+(0.22)+(7.448)+(31.931));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(90.152)-(25.118)-(tcb->m_cWnd)-(6.223)-(34.773));
	tcb->m_ssThresh = (int) (16.191/0.1);

}
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_cWnd = (int) (segmentsAcked+(17.396)+(32.363)+(51.584));
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(80.997)*(50.968));
	tcb->m_cWnd = (int) (31.692+(93.237)+(23.331)+(11.233)+(24.15)+(71.379));

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(13.043)-(tcb->m_segmentSize));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (0.1/98.464);
ReduceCwnd (tcb);
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (87.443+(80.288)+(44.382)+(tcb->m_segmentSize)+(75.302));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(58.626)+(7.739)+(tcb->m_segmentSize)+(4.92)+(segmentsAcked)+(tcb->m_cWnd)+(21.689));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(3.843)-(86.595)-(tcb->m_cWnd)-(80.912));
	tcb->m_ssThresh = (int) ((48.085*(63.619)*(tcb->m_segmentSize)*(18.218)*(61.841))/75.386);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
