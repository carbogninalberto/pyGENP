segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_ssThresh*(97.807));
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (34.042-(14.89)-(94.404)-(9.147));

} else {
	tcb->m_cWnd = (int) (97.034-(tcb->m_cWnd)-(48.813)-(30.346)-(12.294)-(30.789)-(tcb->m_ssThresh)-(70.074)-(33.473));

}
tcb->m_ssThresh = (int) (33.105-(40.811));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_segmentSize = (int) (16.056+(tcb->m_cWnd)+(86.962)+(80.834));
	tcb->m_cWnd = (int) (((61.505)+(0.1)+((tcb->m_cWnd*(32.504)*(4.452)*(63.972)*(63.447)*(tcb->m_cWnd)*(52.028)))+(0.1)+((70.462+(tcb->m_ssThresh)+(83.584)+(27.076)))+(0.1))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (98.978-(75.532)-(20.477)-(14.418)-(28.701));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (87.388*(63.495)*(84.36)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(segmentsAcked));

}
