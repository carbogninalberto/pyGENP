if (tcb->m_cWnd > tcb->m_cWnd) {
	segmentsAcked = (int) (93.965*(99.385)*(5.333)*(9.939));
	tcb->m_cWnd = (int) (28.213*(53.624));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (92.348+(36.401));

}
segmentsAcked = (int) (75.184+(76.257));
