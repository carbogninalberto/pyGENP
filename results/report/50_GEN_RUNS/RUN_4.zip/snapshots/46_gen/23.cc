tcb->m_segmentSize = (int) (tcb->m_ssThresh+(15.466)+(tcb->m_segmentSize)+(57.629)+(99.089)+(23.045)+(64.865)+(tcb->m_cWnd));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd > tcb->m_cWnd) {
	segmentsAcked = (int) (60.589+(2.174)+(6.546));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (segmentsAcked+(39.103)+(tcb->m_ssThresh)+(51.679)+(tcb->m_segmentSize)+(51.085)+(75.202)+(tcb->m_cWnd)+(58.015));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (62.442*(68.702)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(69.194)*(6.052)*(98.248)*(99.652));
