CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (12.409*(tcb->m_ssThresh)*(11.691)*(81.664)*(63.174));

} else {
	tcb->m_ssThresh = (int) (84.217-(tcb->m_ssThresh)-(tcb->m_cWnd)-(65.612)-(54.846));

}
segmentsAcked = (int) (0.1/0.1);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (67.049*(94.655)*(tcb->m_segmentSize)*(8.886)*(85.781)*(54.814));
if (segmentsAcked == segmentsAcked) {
	tcb->m_segmentSize = (int) (63.705+(10.16)+(61.738)+(21.842)+(38.697)+(16.246));
	segmentsAcked = (int) (21.596-(71.603)-(43.708)-(2.797)-(4.626)-(9.501)-(89.927));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (14.279-(41.722)-(66.275)-(45.603));
	ReduceCwnd (tcb);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
