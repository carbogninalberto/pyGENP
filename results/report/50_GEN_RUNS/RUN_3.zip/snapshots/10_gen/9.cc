if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (76.421+(-9.164)+(61.934)+(90.139)+(-45.173)+(67.533)+(tcb->m_segmentSize)+(66.728)+(8.069));

} else {
	tcb->m_segmentSize = (int) (9.365*(tcb->m_cWnd)*(89.228)*(7.228)*(segmentsAcked)*(68.46)*(73.065)*(53.253));
	segmentsAcked = (int) (39.798-(50.968)-(28.344)-(90.071)-(tcb->m_cWnd)-(56.908));

}
segmentsAcked = (int) (76.838-(15.898)-(-44.781)-(34.936)-(70.159)-(-68.569)-(-43.964)-(-23.683));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (25.572*(43.008)*(94.004)*(-13.624)*(-69.726));
