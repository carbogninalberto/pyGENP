tcb->m_segmentSize = (int) (40.876*(4.008)*(44.702)*(-50.683));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
