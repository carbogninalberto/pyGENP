int SGRDItnmPSWpMGeq = (int) (-69.486+(-32.918)+(-45.632)+(53.678));
float dBWxDFsPXPQMHSLz = (float) (92.15-(-79.771)-(98.222)-(-35.683)-(83.513)-(-55.596)-(-76.882)-(84.633)-(39.116));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
