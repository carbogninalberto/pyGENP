int RGLvOtxQmqoICoHg = (int) 19.335;
int DQlvgQAJtRRVHRzp = (int) 27.996;
int LSucqMoYCYYVRoCG = (int) 20.945;
