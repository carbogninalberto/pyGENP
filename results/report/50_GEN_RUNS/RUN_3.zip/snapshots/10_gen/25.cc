if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (50.428*(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (0.1/78.011);

} else {
	tcb->m_cWnd = (int) (0.1/33.896);

}
tcb->m_segmentSize = (int) ((18.793+(1.163)+(51.794)+(14.504)+(segmentsAcked)+(68.299)+(48.796)+(22.531))/0.1);
tcb->m_ssThresh = (int) (31.009+(19.653)+(25.398)+(65.379)+(tcb->m_ssThresh)+(9.417)+(1.068));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != segmentsAcked) {
	segmentsAcked = (int) (tcb->m_segmentSize*(41.082)*(11.12)*(60.585)*(tcb->m_ssThresh)*(26.085));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (46.967/0.1);

} else {
	segmentsAcked = (int) (3.045*(63.336)*(56.661)*(segmentsAcked)*(tcb->m_ssThresh)*(24.276)*(26.474));
	ReduceCwnd (tcb);
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (16.568*(83.64)*(96.099)*(2.378)*(61.699)*(65.78)*(14.704)*(16.305)*(88.654));
segmentsAcked = (int) (0.1/1.57);
CongestionAvoidance (tcb, segmentsAcked);
