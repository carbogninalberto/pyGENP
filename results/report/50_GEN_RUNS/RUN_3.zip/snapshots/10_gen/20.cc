if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(3.268)-(25.69)-(38.136)-(tcb->m_cWnd)-(6.987)-(63.307)-(27.493));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(5.731));
	tcb->m_segmentSize = (int) (2.094+(89.891)+(64.939)+(tcb->m_cWnd)+(78.391)+(35.002));

} else {
	tcb->m_ssThresh = (int) (64.881+(segmentsAcked));
	tcb->m_ssThresh = (int) (segmentsAcked*(76.269)*(13.364)*(20.592)*(3.824)*(79.887)*(tcb->m_ssThresh));
	segmentsAcked = (int) (74.254-(tcb->m_ssThresh)-(52.306)-(27.756)-(74.138));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (85.443-(99.038)-(32.215)-(99.219));
	tcb->m_ssThresh = (int) (75.653+(19.277));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(49.129)*(84.272)*(0.353)*(10.581)*(59.17));
	segmentsAcked = (int) (28.076/11.497);

}
segmentsAcked = (int) (75.671+(21.919));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (51.399+(96.005)+(72.699)+(segmentsAcked)+(84.756)+(85.051)+(15.574));
ReduceCwnd (tcb);
