float vWjAzQQghiMeuCXr = (float) ((30.323+(60.348)+(41.803)+(-41.232)+(30.268)+(27.094)+(-84.85)+(-41.642))/37.31);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-94.084/-57.057);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
