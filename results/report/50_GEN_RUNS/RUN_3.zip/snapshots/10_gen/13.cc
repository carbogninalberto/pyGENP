float hYcopAGsCoxpxIIB = (float) (3.685+(13.807)+(-94.182)+(44.696)+(-80.446)+(58.996));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float crQjHbrRbCPHtksS = (float) (43.635*(-61.636)*(-94.055));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-80.095*(18.58));
