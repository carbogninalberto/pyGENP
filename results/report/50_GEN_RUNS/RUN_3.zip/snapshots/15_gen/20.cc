segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (92.456*(82.342)*(54.64)*(97.767)*(87.574)*(segmentsAcked)*(22.841));
segmentsAcked = (int) (segmentsAcked*(33.095));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked == segmentsAcked) {
	tcb->m_ssThresh = (int) (37.628-(2.816)-(66.54)-(76.991)-(45.744));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) ((((tcb->m_cWnd-(segmentsAcked)-(84.05)-(49.517)-(0.372)-(46.75)-(75.799)))+(0.1)+(0.1)+(82.197))/((18.897)+(43.844)));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (57.054+(70.259)+(55.332)+(72.54)+(37.873)+(61.879)+(92.431));

}
