CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (34.453-(67.168)-(59.324)-(tcb->m_cWnd)-(59.616)-(44.293)-(30.762)-(57.891));
tcb->m_ssThresh = (int) (34.309*(70.71)*(70.113)*(32.59)*(64.947)*(42.78)*(27.68)*(98.213));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (0.1/0.1);
