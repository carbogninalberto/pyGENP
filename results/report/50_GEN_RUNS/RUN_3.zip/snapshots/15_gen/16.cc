segmentsAcked = (int) (tcb->m_ssThresh*(19.819)*(49.943)*(tcb->m_segmentSize)*(26.157)*(60.992)*(60.607)*(78.813));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((((4.222*(tcb->m_segmentSize)*(30.669)*(31.237)*(3.876)*(49.368)*(36.799)*(45.105)))+(0.1)+((tcb->m_cWnd-(20.755)-(11.757)-(22.421)-(tcb->m_segmentSize)))+(0.1))/((0.1)+(48.712)+(89.292)+(10.28)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(19.384)*(3.085)*(46.652)*(tcb->m_ssThresh)*(73.761)*(70.248)*(53.935));
	tcb->m_segmentSize = (int) ((((24.603-(82.157)-(30.589)))+(0.1)+(0.1)+((56.175*(tcb->m_segmentSize)))+(54.696))/((4.324)+(12.899)+(69.643)+(80.35)));
	tcb->m_ssThresh = (int) (10.092+(91.233)+(42.461)+(29.995)+(25.39));

}
tcb->m_cWnd = (int) (tcb->m_segmentSize*(98.462)*(36.59)*(69.397)*(62.791)*(73.319)*(25.105)*(43.633)*(60.74));
segmentsAcked = (int) (95.618*(33.608)*(87.39));
segmentsAcked = (int) (68.81*(tcb->m_ssThresh)*(15.639)*(88.57)*(17.144));
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (37.068*(57.731)*(70.716)*(63.973)*(45.366)*(63.293));
	segmentsAcked = (int) (tcb->m_ssThresh*(63.583)*(63.707));

} else {
	tcb->m_segmentSize = (int) (37.506+(20.238)+(39.419));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (43.949+(15.901)+(12.453)+(49.627)+(9.217)+(segmentsAcked)+(63.537)+(15.705)+(11.018));
