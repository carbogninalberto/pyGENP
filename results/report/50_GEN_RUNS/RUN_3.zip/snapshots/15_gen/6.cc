CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
float lGvlwlSojYqJLPEy = (float) (86.187+(tcb->m_segmentSize)+(25.139)+(17.941)+(8.32));
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(19.195)-(73.561)-(93.163)-(19.205)-(99.268));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (54.886-(93.762));
	tcb->m_cWnd = (int) (38.552-(12.028)-(64.839)-(15.592)-(77.249)-(3.302)-(94.468)-(73.908));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	lGvlwlSojYqJLPEy = (float) (54.017+(44.828)+(86.722)+(27.643)+(39.928)+(64.879));

} else {
	lGvlwlSojYqJLPEy = (float) (((77.648)+(0.1)+(0.1)+(0.1)+((18.123*(93.049)*(tcb->m_ssThresh)*(32.696)*(1.159)))+(0.1))/((52.097)));
	tcb->m_cWnd = (int) (68.049+(segmentsAcked)+(7.646)+(8.407)+(24.192)+(46.706)+(tcb->m_cWnd));
	lGvlwlSojYqJLPEy = (float) (40.691*(4.244)*(85.751)*(98.823)*(45.723)*(segmentsAcked)*(33.365));

}
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	lGvlwlSojYqJLPEy = (float) (32.806/0.1);
	tcb->m_ssThresh = (int) (8.595-(48.853)-(segmentsAcked));

} else {
	lGvlwlSojYqJLPEy = (float) (((95.393)+(0.1)+(0.1)+(0.1)+(0.1))/((21.139)+(0.1)+(0.1)+(45.837)));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(77.078)+(81.133)+(5.096)+(tcb->m_segmentSize)+(17.959)+(94.776));

}
if (tcb->m_segmentSize < lGvlwlSojYqJLPEy) {
	tcb->m_cWnd = (int) (64.19*(31.674)*(52.567)*(lGvlwlSojYqJLPEy)*(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(90.932)*(69.685)*(84.539)*(16.931)*(39.714)*(38.669)*(15.229)*(41.165));

}
