CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (22.354*(35.966)*(tcb->m_segmentSize));
int axdSCJtnHvktOzLQ = (int) (58.494-(20.273));
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(74.224));
if (axdSCJtnHvktOzLQ > tcb->m_segmentSize) {
	axdSCJtnHvktOzLQ = (int) (segmentsAcked+(tcb->m_ssThresh)+(98.232)+(2.855)+(5.333)+(axdSCJtnHvktOzLQ)+(11.22)+(46.905));

} else {
	axdSCJtnHvktOzLQ = (int) (32.419*(tcb->m_ssThresh)*(2.778)*(tcb->m_ssThresh)*(20.524)*(tcb->m_segmentSize));

}
tcb->m_cWnd = (int) (34.558-(87.786)-(27.136)-(13.022)-(segmentsAcked)-(4.863));
