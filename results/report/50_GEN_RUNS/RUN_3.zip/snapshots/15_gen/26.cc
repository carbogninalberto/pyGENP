tcb->m_cWnd = (int) (33.887+(44.144)+(18.496)+(39.977)+(0.732)+(48.756)+(66.454)+(68.664));
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (83.391-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(30.291)-(81.893)-(73.842)-(76.608)-(77.374));
	tcb->m_cWnd = (int) (94.403-(55.492)-(56.963)-(12.057)-(32.161)-(93.87)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (67.968-(10.677)-(68.266));
	tcb->m_cWnd = (int) ((((12.865+(20.521)+(75.405)+(12.33)+(97.272)+(13.626)+(43.482)))+(0.1)+((43.593*(10.379)*(segmentsAcked)*(52.268)*(segmentsAcked)*(58.893)*(tcb->m_cWnd)*(74.601)*(18.723)))+(84.699)+(0.1))/((0.1)+(0.1)+(0.1)+(99.278)));

}
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) ((tcb->m_cWnd+(65.542)+(17.734)+(45.883)+(97.872)+(tcb->m_segmentSize)+(34.055))/21.97);
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (12.251+(41.439)+(95.556)+(52.519)+(46.486)+(43.343)+(54.111)+(segmentsAcked)+(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(27.373)+(57.69)+(segmentsAcked)+(80.854)+(90.855)+(39.934)+(tcb->m_ssThresh));
	segmentsAcked = (int) (((0.1)+(59.793)+(0.1)+(85.417)+(0.1))/((0.1)+(0.1)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) ((segmentsAcked+(48.099)+(44.937)+(62.857)+(88.3)+(13.438)+(9.756)+(68.65))/4.61);
tcb->m_ssThresh = (int) (2.194*(63.621)*(93.81));
