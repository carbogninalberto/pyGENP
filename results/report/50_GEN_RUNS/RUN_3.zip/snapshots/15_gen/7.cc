tcb->m_cWnd = (int) (89.4-(4.703));
tcb->m_cWnd = (int) (((99.188)+(88.581)+(72.374)+(0.1)+(1.57)+(40.758))/((7.177)));
tcb->m_cWnd = (int) (((52.952)+(30.182)+(0.1)+(16.505)+(0.1)+(70.998)+(0.1))/((0.1)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) ((tcb->m_cWnd*(45.829)*(60.307)*(59.01)*(88.308)*(23.992)*(18.561)*(94.897)*(41.727))/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (11.912-(81.864)-(tcb->m_segmentSize)-(14.215)-(71.364)-(segmentsAcked)-(67.676));
	segmentsAcked = (int) (63.576+(16.221)+(45.852)+(80.504)+(99.454)+(91.397)+(67.488));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (40.8-(45.435)-(9.936)-(43.796)-(6.166)-(83.279)-(43.877)-(96.698)-(89.541));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
