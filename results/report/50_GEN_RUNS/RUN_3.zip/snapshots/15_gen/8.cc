if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (16.919/0.1);

} else {
	tcb->m_ssThresh = (int) (0.1/85.974);
	segmentsAcked = (int) (8.002+(5.741));
	tcb->m_segmentSize = (int) (((24.781)+(0.1)+(0.1)+(0.1)+(41.023)+(78.937))/((61.021)+(0.1)));

}
tcb->m_segmentSize = (int) (((0.1)+(0.1)+(13.346)+(49.684)+(0.1)+(6.774))/((0.1)));
float LjjHAWdeDqLpvjkG = (float) (((61.391)+((83.71*(10.814)*(92.241)*(52.135)*(0.948)))+(0.1)+(51.779)+(0.1))/((0.1)+(0.1)+(11.298)+(0.1)));
int VnPDJGyhhDzMIYrX = (int) (38.401*(65.545)*(44.414)*(72.551));
float LtFjozDwvYOaXjut = (float) (11.408/21.596);
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (57.708/14.249);

} else {
	tcb->m_segmentSize = (int) (32.848*(77.649)*(93.484));
	ReduceCwnd (tcb);

}
if (segmentsAcked >= LtFjozDwvYOaXjut) {
	tcb->m_cWnd = (int) (((0.1)+((54.963*(47.18)*(53.444)*(4.547)*(23.525)*(tcb->m_segmentSize)))+(26.952)+(0.1))/((70.074)+(54.234)+(0.1)));
	ReduceCwnd (tcb);
	LjjHAWdeDqLpvjkG = (float) (50.943+(70.608)+(22.334)+(50.954)+(VnPDJGyhhDzMIYrX)+(78.682)+(78.028)+(11.932));

} else {
	tcb->m_cWnd = (int) (0.1/97.657);

}
if (segmentsAcked < tcb->m_segmentSize) {
	VnPDJGyhhDzMIYrX = (int) (35.479-(41.836));

} else {
	VnPDJGyhhDzMIYrX = (int) (LjjHAWdeDqLpvjkG-(segmentsAcked)-(47.791));
	VnPDJGyhhDzMIYrX = (int) (68.532-(LjjHAWdeDqLpvjkG)-(27.945));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
