if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_segmentSize = (int) (10.031-(34.942)-(25.748)-(23.609)-(72.703)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(67.536)-(29.668));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (45.296*(tcb->m_segmentSize)*(71.011)*(24.393)*(50.324)*(tcb->m_ssThresh)*(38.185)*(56.146)*(75.199));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
int ScnyoBwaodGtdpnO = (int) (tcb->m_cWnd*(51.272));
if (tcb->m_ssThresh != tcb->m_cWnd) {
	ScnyoBwaodGtdpnO = (int) (96.728*(61.365));

} else {
	ScnyoBwaodGtdpnO = (int) (((62.716)+(0.1)+((43.911*(41.243)))+(0.1)+((segmentsAcked+(50.478)+(tcb->m_ssThresh)+(49.932)+(54.099)))+(13.536))/((0.1)));
	tcb->m_cWnd = (int) (segmentsAcked*(tcb->m_cWnd)*(80.323)*(tcb->m_ssThresh));

}
tcb->m_ssThresh = (int) (61.185+(71.814));
ReduceCwnd (tcb);
