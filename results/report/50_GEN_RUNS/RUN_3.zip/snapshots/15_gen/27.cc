tcb->m_ssThresh = (int) (79.899-(38.444)-(segmentsAcked)-(56.028)-(2.782)-(segmentsAcked)-(33.37)-(24.38)-(tcb->m_cWnd));
ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (8.386+(76.125)+(51.264));
	segmentsAcked = (int) (65.133+(89.13)+(91.859)+(segmentsAcked)+(70.293)+(segmentsAcked)+(2.713));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (87.674*(24.228)*(68.364)*(89.019)*(45.891)*(tcb->m_ssThresh));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (91.318*(50.742)*(79.86)*(tcb->m_segmentSize)*(92.582)*(79.974)*(80.19));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (98.915-(tcb->m_cWnd)-(95.583)-(segmentsAcked)-(96.662)-(2.188)-(segmentsAcked)-(96.876)-(75.459));
	tcb->m_segmentSize = (int) (segmentsAcked+(71.332)+(49.859)+(tcb->m_segmentSize)+(14.258)+(18.219)+(99.81)+(81.176));
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(98.78)*(tcb->m_segmentSize)*(24.064)*(64.5));

}
segmentsAcked = (int) (((25.28)+(0.1)+(0.1)+(32.948)+(1.575))/((12.935)+(26.33)+(37.668)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (0.1/0.1);
