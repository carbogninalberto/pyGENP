TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int zeSThYgDMeoNpxmz = (int) ((tcb->m_cWnd+(32.526)+(tcb->m_ssThresh)+(36.291)+(28.456)+(tcb->m_segmentSize)+(37.96)+(59.229)+(tcb->m_cWnd))/(86.584*(36.514)*(tcb->m_ssThresh)*(segmentsAcked)*(70.32)*(11.281)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float LVfxjksEFlHZuQAp = (float) (61.778/0.1);
LVfxjksEFlHZuQAp = (float) (50.278*(tcb->m_cWnd)*(tcb->m_ssThresh)*(48.362)*(85.687)*(94.069)*(tcb->m_segmentSize)*(79.84)*(segmentsAcked));
segmentsAcked = (int) (35.75-(tcb->m_segmentSize)-(4.49)-(20.877)-(LVfxjksEFlHZuQAp)-(4.03));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (10.252-(segmentsAcked)-(13.808));
float fLhuzKAOGuTqrKrJ = (float) (37.173*(72.432)*(58.49)*(97.823)*(73.34)*(tcb->m_segmentSize)*(79.839));
