tcb->m_cWnd = (int) (62.659-(91.07)-(54.847)-(94.297)-(61.844)-(93.814)-(segmentsAcked));
tcb->m_cWnd = (int) (42.437*(33.369)*(80.382)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(55.231)*(56.959)*(segmentsAcked)*(19.04));
tcb->m_cWnd = (int) ((((segmentsAcked*(tcb->m_ssThresh)*(17.138)*(49.922)*(71.496)*(59.958)*(45.85)*(65.814)))+(0.1)+(0.1)+(13.415)+(0.1))/((0.1)+(75.871)+(44.963)+(33.122)));
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (15.288-(30.802)-(segmentsAcked)-(27.703)-(78.386)-(36.078)-(88.221));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(29.336)+(6.781)+(32.416)+(87.474)+(37.242)+(40.001)+(tcb->m_segmentSize)+(14.827));

}
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (31.556*(97.819)*(48.981));
	tcb->m_ssThresh = (int) (1.28-(6.102)-(81.17)-(39.81)-(17.213)-(56.619));

} else {
	tcb->m_cWnd = (int) ((2.528*(tcb->m_segmentSize)*(22.782)*(tcb->m_ssThresh))/0.1);
	tcb->m_ssThresh = (int) (75.203*(tcb->m_segmentSize)*(25.856)*(86.569)*(68.433)*(72.493)*(6.978)*(76.104));
	ReduceCwnd (tcb);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
