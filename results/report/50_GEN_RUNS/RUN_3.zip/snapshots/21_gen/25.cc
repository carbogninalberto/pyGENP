segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (44.892-(4.922));
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (43.575-(24.116)-(80.013)-(tcb->m_cWnd)-(37.307)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (8.074+(tcb->m_ssThresh)+(27.599)+(33.829));

}
tcb->m_segmentSize = (int) (42.54-(tcb->m_ssThresh)-(28.477)-(tcb->m_segmentSize)-(68.962)-(70.519)-(67.656)-(21.038));
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_ssThresh = (int) (segmentsAcked-(tcb->m_ssThresh)-(15.066)-(59.881));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) ((6.822+(5.59)+(tcb->m_segmentSize)+(61.813)+(75.864)+(tcb->m_segmentSize)+(15.821)+(75.479))/58.805);

} else {
	tcb->m_ssThresh = (int) ((36.465*(16.595)*(84.515)*(23.304)*(76.549)*(87.796)*(28.227)*(60.217))/(tcb->m_segmentSize+(13.161)));
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(19.363));
	tcb->m_ssThresh = (int) (44.616*(37.197)*(38.933)*(81.893)*(53.819)*(91.197)*(88.37)*(14.021)*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(23.571)*(98.93)*(33.064));
	segmentsAcked = (int) (47.623+(50.957));

}
