if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	segmentsAcked = (int) (36.885-(16.627)-(48.999)-(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (52.73/1.736);

} else {
	segmentsAcked = (int) (84.15-(52.925));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (91.152+(12.62)+(17.48)+(92.114)+(segmentsAcked)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(91.61));

}
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (11.274-(96.922)-(16.905)-(43.261)-(78.804)-(tcb->m_ssThresh)-(48.617)-(15.873)-(49.045));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) ((((94.185+(65.679)+(12.189)+(63.025)))+(39.103)+(30.791)+(83.732)+(83.376)+(0.1))/((0.1)+(41.739)));
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (99.27-(92.694)-(72.506)-(59.759)-(82.138)-(segmentsAcked)-(57.335)-(20.65));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (83.431+(92.537)+(58.556)+(tcb->m_cWnd)+(96.763)+(segmentsAcked));
	tcb->m_segmentSize = (int) (44.712*(17.582)*(54.291)*(39.526));

}
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (99.642+(68.204)+(tcb->m_segmentSize)+(59.76)+(76.067)+(61.183)+(12.944)+(tcb->m_segmentSize)+(40.844));
	tcb->m_ssThresh = (int) (17.14*(61.238)*(47.005)*(tcb->m_ssThresh)*(74.541)*(57.896)*(9.598)*(tcb->m_cWnd));

}
CongestionAvoidance (tcb, segmentsAcked);
