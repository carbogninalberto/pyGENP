int EqvvpWscKxmxQLVf = (int) (96.798+(57.656)+(-94.718)+(79.467)+(-34.886)+(39.851)+(-44.01)+(57.962));
ReduceCwnd (tcb);
int mwOVeFswKxBtGFZX = (int) (32.396-(-82.841)-(-69.341)-(-2.623));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (mwOVeFswKxBtGFZX <= EqvvpWscKxmxQLVf) {
	EqvvpWscKxmxQLVf = (int) (mwOVeFswKxBtGFZX-(44.104)-(12.924)-(6.828)-(68.71)-(tcb->m_cWnd)-(60.718));
	tcb->m_cWnd = (int) (EqvvpWscKxmxQLVf+(41.128)+(84.396)+(tcb->m_cWnd)+(28.642)+(EqvvpWscKxmxQLVf));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	EqvvpWscKxmxQLVf = (int) (42.29+(40.633));

}
if (mwOVeFswKxBtGFZX <= EqvvpWscKxmxQLVf) {
	EqvvpWscKxmxQLVf = (int) (mwOVeFswKxBtGFZX-(44.104)-(12.924)-(6.828)-(68.71)-(tcb->m_cWnd)-(60.718));
	tcb->m_cWnd = (int) (EqvvpWscKxmxQLVf+(41.128)+(84.396)+(tcb->m_cWnd)+(28.642)+(EqvvpWscKxmxQLVf));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	EqvvpWscKxmxQLVf = (int) (42.29+(40.633));

}
if (EqvvpWscKxmxQLVf >= tcb->m_cWnd) {
	segmentsAcked = (int) (segmentsAcked+(21.34)+(89.735)+(segmentsAcked)+(97.21)+(43.283));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (9.458-(72.617)-(2.873)-(53.368)-(83.808));
	segmentsAcked = (int) (44.478+(96.908)+(12.213));

}
if (EqvvpWscKxmxQLVf >= tcb->m_cWnd) {
	segmentsAcked = (int) (segmentsAcked+(21.34)+(89.735)+(segmentsAcked)+(97.21)+(90.478));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (9.458-(72.617)-(2.873)-(53.368)-(83.808));
	segmentsAcked = (int) (44.478+(96.908)+(12.213));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
mwOVeFswKxBtGFZX = (int) (-10.647/-67.365);
mwOVeFswKxBtGFZX = (int) (-81.031/-94.744);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (84.236-(95.766)-(89.095)-(5.207)-(93.192));

} else {
	segmentsAcked = (int) (65.299*(76.113)*(48.869));
	tcb->m_segmentSize = (int) (EqvvpWscKxmxQLVf*(77.655)*(mwOVeFswKxBtGFZX)*(4.667)*(tcb->m_segmentSize)*(56.617)*(32.736));

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (84.236-(95.766)-(89.095)-(5.207)-(93.192));

} else {
	segmentsAcked = (int) (65.299*(76.113)*(48.869));
	tcb->m_segmentSize = (int) (EqvvpWscKxmxQLVf*(77.655)*(mwOVeFswKxBtGFZX)*(4.667)*(tcb->m_segmentSize)*(56.617)*(32.736));

}
