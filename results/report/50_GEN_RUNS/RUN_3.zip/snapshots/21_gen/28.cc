int WWMnpkwehAPkeouE = (int) (0.1/63.583);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (0.1/0.1);
tcb->m_cWnd = (int) (segmentsAcked-(85.046)-(42.625)-(97.34)-(tcb->m_segmentSize)-(78.394)-(78.332)-(79.699)-(90.505));
tcb->m_ssThresh = (int) (92.909*(15.284)*(59.712)*(93.283)*(97.825)*(75.247)*(65.187)*(tcb->m_ssThresh));
