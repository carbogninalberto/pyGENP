int mwOVeFswKxBtGFZX = (int) (89.719-(29.894)-(34.45)-(-62.151));
ReduceCwnd (tcb);
int EqvvpWscKxmxQLVf = (int) (77.739+(66.456)+(47.359)+(54.75)+(-79.658)+(20.481)+(-6.005)+(-44.131));
CongestionAvoidance (tcb, segmentsAcked);
if (mwOVeFswKxBtGFZX <= EqvvpWscKxmxQLVf) {
	EqvvpWscKxmxQLVf = (int) (42.29+(40.633));

} else {
	EqvvpWscKxmxQLVf = (int) (mwOVeFswKxBtGFZX-(44.104)-(12.924)-(6.828)-(68.71)-(tcb->m_cWnd)-(60.718));
	tcb->m_cWnd = (int) (EqvvpWscKxmxQLVf+(41.128)+(84.396)+(tcb->m_cWnd)+(28.642)+(EqvvpWscKxmxQLVf));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (EqvvpWscKxmxQLVf >= tcb->m_cWnd) {
	segmentsAcked = (int) (segmentsAcked+(21.34)+(89.735)+(segmentsAcked)+(97.21)+(-68.191));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (9.458-(72.617)-(2.873)-(53.368)-(83.808));
	segmentsAcked = (int) (44.478+(96.908)+(12.213));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
mwOVeFswKxBtGFZX = (int) (-24.077/1.524);
if (mwOVeFswKxBtGFZX <= EqvvpWscKxmxQLVf) {
	EqvvpWscKxmxQLVf = (int) (42.29+(40.633));

} else {
	EqvvpWscKxmxQLVf = (int) (mwOVeFswKxBtGFZX-(44.104)-(12.924)-(6.828)-(68.71)-(tcb->m_cWnd)-(60.718));
	tcb->m_cWnd = (int) (EqvvpWscKxmxQLVf+(41.128)+(84.396)+(tcb->m_cWnd)+(28.642)+(EqvvpWscKxmxQLVf));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (84.236-(95.766)-(89.095)-(5.207)-(93.192));

} else {
	segmentsAcked = (int) (65.299*(76.113)*(48.869));
	tcb->m_segmentSize = (int) (EqvvpWscKxmxQLVf*(77.655)*(mwOVeFswKxBtGFZX)*(4.667)*(tcb->m_segmentSize)*(56.617)*(32.736));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (EqvvpWscKxmxQLVf >= tcb->m_cWnd) {
	segmentsAcked = (int) (segmentsAcked+(21.34)+(89.735)+(segmentsAcked)+(97.21)+(-68.191));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (9.458-(72.617)-(2.873)-(53.368)-(83.808));
	segmentsAcked = (int) (44.478+(96.908)+(12.213));

}
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
mwOVeFswKxBtGFZX = (int) (94.291/-18.271);
mwOVeFswKxBtGFZX = (int) (-37.214/-62.829);
if (mwOVeFswKxBtGFZX <= EqvvpWscKxmxQLVf) {
	EqvvpWscKxmxQLVf = (int) (42.29+(40.633));

} else {
	EqvvpWscKxmxQLVf = (int) (mwOVeFswKxBtGFZX-(44.104)-(12.924)-(6.828)-(68.71)-(tcb->m_cWnd)-(60.718));
	tcb->m_cWnd = (int) (EqvvpWscKxmxQLVf+(41.128)+(84.396)+(tcb->m_cWnd)+(28.642)+(EqvvpWscKxmxQLVf));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (84.236-(95.766)-(89.095)-(5.207)-(93.192));

} else {
	segmentsAcked = (int) (65.299*(76.113)*(48.869));
	tcb->m_segmentSize = (int) (EqvvpWscKxmxQLVf*(77.655)*(mwOVeFswKxBtGFZX)*(4.667)*(tcb->m_segmentSize)*(56.617)*(32.736));

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (84.236-(95.766)-(89.095)-(5.207)-(93.192));

} else {
	segmentsAcked = (int) (65.299*(76.113)*(48.869));
	tcb->m_segmentSize = (int) (EqvvpWscKxmxQLVf*(77.655)*(mwOVeFswKxBtGFZX)*(4.667)*(tcb->m_segmentSize)*(56.617)*(32.736));

}
if (EqvvpWscKxmxQLVf >= tcb->m_cWnd) {
	segmentsAcked = (int) (segmentsAcked+(21.34)+(89.735)+(segmentsAcked)+(97.21)+(-68.191));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (9.458-(72.617)-(2.873)-(53.368)-(83.808));
	segmentsAcked = (int) (44.478+(96.908)+(12.213));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
mwOVeFswKxBtGFZX = (int) (-84.765/88.217);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (84.236-(95.766)-(89.095)-(5.207)-(93.192));

} else {
	segmentsAcked = (int) (65.299*(76.113)*(48.869));
	tcb->m_segmentSize = (int) (EqvvpWscKxmxQLVf*(77.655)*(mwOVeFswKxBtGFZX)*(4.667)*(tcb->m_segmentSize)*(56.617)*(32.736));

}
