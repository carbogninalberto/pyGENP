tcb->m_segmentSize = (int) (45.528-(78.841)-(63.495)-(4.72)-(-81.854));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
