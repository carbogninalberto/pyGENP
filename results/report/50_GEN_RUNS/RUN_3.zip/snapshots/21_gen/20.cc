int PswGsDeTtbGmjxUQ = (int) (57.197-(49.791)-(50.159)-(38.151)-(91.968)-(86.725)-(14.919));
PswGsDeTtbGmjxUQ = (int) (88.938+(PswGsDeTtbGmjxUQ)+(75.798)+(60.823)+(34.044)+(85.795)+(85.791)+(22.213)+(76.316));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (0.1/0.1);
tcb->m_cWnd = (int) (11.595*(16.076));
if (PswGsDeTtbGmjxUQ <= tcb->m_segmentSize) {
	PswGsDeTtbGmjxUQ = (int) (((62.508)+((76.001-(2.345)-(77.254)-(PswGsDeTtbGmjxUQ)))+(0.1)+(0.1)+(85.12)+(0.1)+(73.677))/((0.1)+(0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	PswGsDeTtbGmjxUQ = (int) (82.761+(65.883)+(38.376)+(72.173)+(60.616)+(94.236)+(8.902));

} else {
	PswGsDeTtbGmjxUQ = (int) (49.677*(81.845)*(51.943)*(4.97)*(83.463)*(31.319)*(8.363)*(83.01));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (((81.118)+(0.1)+(0.1)+(0.1))/((0.1)+(70.591)+(0.1)+(0.1)));

}
if (PswGsDeTtbGmjxUQ != tcb->m_ssThresh) {
	segmentsAcked = (int) ((13.968-(88.935)-(32.952)-(57.25))/0.1);
	tcb->m_ssThresh = (int) (48.832-(44.954)-(4.28)-(47.951)-(40.184)-(95.63)-(50.577));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (tcb->m_cWnd-(82.019)-(29.377)-(segmentsAcked)-(tcb->m_ssThresh)-(segmentsAcked)-(tcb->m_ssThresh));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((0.1)+(7.558)+(89.666)+(0.1)+((60.449+(tcb->m_ssThresh)))+(0.1)+(32.976))/((0.1)));
	segmentsAcked = (int) (76.974+(tcb->m_ssThresh)+(23.562)+(50.644)+(59.707)+(tcb->m_cWnd)+(79.173)+(51.792));
	tcb->m_cWnd = (int) (81.648*(PswGsDeTtbGmjxUQ)*(tcb->m_ssThresh)*(7.337));

} else {
	tcb->m_cWnd = (int) (66.736-(87.009)-(tcb->m_segmentSize));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (21.813*(56.467)*(65.259)*(56.862)*(47.131)*(15.177));

}
