float jISTsCSGoqHeqabI = (float) 75.428;
if (segmentsAcked != segmentsAcked) {
	tcb->m_cWnd = (int) (63.49*(-82.196)*(99.478)*(86.479)*(21.457)*(84.22)*(12.713));

} else {
	tcb->m_cWnd = (int) ((72.159+(10.304)+(16.996)+(26.206)+(88.769)+(97.126)+(tcb->m_ssThresh)+(69.869)+(tcb->m_ssThresh))/5.43);

}
tcb->m_segmentSize = (int) (5.326*(-50.622)*(-44.808)*(48.742));
