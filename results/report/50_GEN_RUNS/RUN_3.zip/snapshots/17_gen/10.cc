if (tcb->m_segmentSize > tcb->m_cWnd) {
	segmentsAcked = (int) (18.0-(segmentsAcked)-(7.162)-(21.912)-(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (15.129*(tcb->m_cWnd)*(36.34)*(25.902)*(segmentsAcked)*(tcb->m_cWnd)*(86.044)*(93.721)*(62.095));

} else {
	segmentsAcked = (int) (29.515*(98.034)*(68.538)*(6.392)*(87.842)*(16.343)*(-24.837));

}
