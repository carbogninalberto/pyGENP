int fOZnQyodXKZSqmZu = (int) (68.381/-31.724);
float pzfCmiZtRdGvboUc = (float) (-52.219/9.035);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (60.924/77.224);
CongestionAvoidance (tcb, segmentsAcked);
