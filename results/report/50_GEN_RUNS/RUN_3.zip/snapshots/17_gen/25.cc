int fOZnQyodXKZSqmZu = (int) (6.687/70.784);
float pzfCmiZtRdGvboUc = (float) (45.635/35.561);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-33.122/92.987);
segmentsAcked = (int) (71.482/39.62);
CongestionAvoidance (tcb, segmentsAcked);
