CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-30.201*(60.776)*(8.846)*(1.969)*(-2.75)*(-47.527));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (86.758/0.1);

} else {
	tcb->m_cWnd = (int) (86.892-(27.773)-(tcb->m_segmentSize)-(segmentsAcked)-(33.991)-(56.271)-(6.225)-(72.512)-(26.797));

}
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (59.808+(86.683)+(90.732)+(tcb->m_segmentSize)+(24.677));
	tcb->m_cWnd = (int) (((15.628)+(18.12)+((61.863+(34.229)+(11.157)))+(63.952))/((0.1)+(17.688)));
	tcb->m_segmentSize = (int) (57.361*(-54.055)*(57.055)*(90.314)*(37.167)*(segmentsAcked)*(54.248)*(-15.22)*(84.315));

} else {
	segmentsAcked = (int) (39.133+(86.317)+(66.936)+(segmentsAcked)+(47.106)+(95.172)+(33.008)+(85.67));

}
