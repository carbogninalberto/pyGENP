segmentsAcked = (int) (23.203+(-72.459)+(26.049)+(6.558)+(-91.813));
int tRTlRLSiFFWbPJVd = (int) 14.646;
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((92.42+(82.505)+(38.632)+(tcb->m_segmentSize)+(65.951))/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (20.424*(95.783)*(70.064)*(42.986)*(18.828)*(51.493)*(tRTlRLSiFFWbPJVd)*(22.152));

}
ReduceCwnd (tcb);
