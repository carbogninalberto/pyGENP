float LZDNmFZyirLFvnRk = (float) (46.649-(-10.051)-(64.845));
