int YDcEfZeVTcvQpHJN = (int) (-76.074-(17.373)-(-42.618)-(84.285)-(-67.111)-(58.524));
int EWfFBMzwJiRJMhdE = (int) (-36.395*(-60.147)*(18.697)*(-52.564));
ReduceCwnd (tcb);
int MrppXAWIYoMIHaAQ = (int) 45.832;
tcb->m_cWnd = (int) ((6.762+(tcb->m_segmentSize)+(-90.162)+(57.479)+(-5.334)+(-5.905)+(-48.181)+(0.063))/-99.207);
