float jmFDLunzYoIztErd = (float) (62.645*(-19.03)*(56.029));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (40.018+(jmFDLunzYoIztErd)+(17.213)+(92.434)+(71.363)+(87.503)+(98.502)+(-40.63));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (59.239*(50.225));

}
