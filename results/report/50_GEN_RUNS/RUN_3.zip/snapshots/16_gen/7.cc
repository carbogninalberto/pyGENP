int MBJyvyMPuOHzLcqa = (int) (23.768+(19.638)+(46.219));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (54.161+(9.316)+(82.217)+(65.259)+(72.889)+(95.666)+(87.619)+(35.646)+(69.543));
if (MBJyvyMPuOHzLcqa != MBJyvyMPuOHzLcqa) {
	MBJyvyMPuOHzLcqa = (int) (((29.767)+((46.728*(91.817)*(20.104)*(59.241)*(47.237)*(59.114)*(88.812)*(26.298)))+(0.1)+(43.04)+(55.019)+(0.1))/((0.1)+(0.1)));
	tcb->m_segmentSize = (int) ((((39.345-(31.989)-(37.031)-(tcb->m_cWnd)-(78.909)-(16.588)))+(0.1)+((MBJyvyMPuOHzLcqa+(MBJyvyMPuOHzLcqa)+(5.755)+(32.19)+(59.176)))+((51.982-(tcb->m_ssThresh)-(48.791)-(56.412)-(2.668)-(70.389)-(68.645)))+(0.1)+(0.1))/((23.837)+(0.1)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(70.779)-(MBJyvyMPuOHzLcqa));

} else {
	MBJyvyMPuOHzLcqa = (int) (15.02-(12.099));
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh != MBJyvyMPuOHzLcqa) {
	tcb->m_cWnd = (int) ((5.249+(tcb->m_ssThresh)+(48.383)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(78.706))/0.1);

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(10.296)-(MBJyvyMPuOHzLcqa));

}
tcb->m_ssThresh = (int) (5.733+(segmentsAcked)+(55.566)+(tcb->m_cWnd)+(11.546));
