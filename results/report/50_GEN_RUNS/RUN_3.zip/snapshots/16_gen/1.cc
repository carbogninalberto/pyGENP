TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (26.893/69.297);

} else {
	segmentsAcked = (int) (41.334*(87.752)*(22.904)*(50.368));
	tcb->m_segmentSize = (int) (58.449-(99.106)-(1.452)-(88.743)-(23.252)-(32.091)-(-89.283));

}
