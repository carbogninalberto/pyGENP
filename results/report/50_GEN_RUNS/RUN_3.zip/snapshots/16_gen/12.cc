if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (87.049+(72.642)+(29.364)+(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) ((18.938*(83.673))/8.015);

}
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (tcb->m_cWnd+(2.504)+(82.028)+(62.528)+(95.297)+(tcb->m_segmentSize)+(5.68)+(25.005)+(74.432));
	segmentsAcked = (int) (30.384-(16.298)-(5.635)-(tcb->m_ssThresh)-(62.506)-(17.87)-(17.045)-(76.268)-(31.356));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(28.412)*(73.453));
	tcb->m_segmentSize = (int) (2.175-(53.264)-(79.959)-(tcb->m_cWnd)-(78.86));

}
float fXrvwRlEmOGEphZS = (float) (tcb->m_ssThresh+(59.6)+(54.304)+(91.164));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (77.309-(54.527)-(75.436)-(52.981)-(80.743)-(17.683)-(50.552)-(35.998));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	segmentsAcked = (int) (95.245*(23.957)*(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (79.643-(85.109)-(65.074)-(76.55)-(95.6)-(31.599)-(16.96)-(tcb->m_cWnd)-(17.814));
	tcb->m_cWnd = (int) (33.847-(29.776)-(71.637)-(40.052)-(segmentsAcked)-(58.76)-(90.448)-(8.301));

} else {
	segmentsAcked = (int) (0.1/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
