if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((0.1)+(68.078)+((99.838*(segmentsAcked)*(tcb->m_ssThresh)*(45.82)*(29.899)*(8.612)*(51.877)))+(0.1)+(3.822)+(53.441))/((1.248)));
	segmentsAcked = (int) (((6.085)+(0.1)+(86.445)+(20.884)+(37.985)+(83.219))/((0.1)+(0.1)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (59.141*(46.419)*(8.773)*(68.081)*(65.861)*(75.207)*(segmentsAcked)*(93.118));
	tcb->m_segmentSize = (int) (47.604-(35.46)-(94.915)-(tcb->m_cWnd)-(49.499)-(18.327)-(43.683)-(21.202)-(34.538));
	segmentsAcked = (int) (37.674-(99.055)-(tcb->m_segmentSize)-(95.007));

}
if (segmentsAcked != segmentsAcked) {
	tcb->m_cWnd = (int) (63.49*(tcb->m_ssThresh)*(99.478)*(86.479)*(21.457)*(84.22)*(12.713));

} else {
	tcb->m_cWnd = (int) ((72.159+(10.304)+(16.996)+(26.206)+(88.769)+(97.126)+(tcb->m_ssThresh)+(69.869)+(tcb->m_ssThresh))/5.43);

}
tcb->m_segmentSize = (int) (82.191*(51.97)*(10.85)*(8.466));
CongestionAvoidance (tcb, segmentsAcked);
float jISTsCSGoqHeqabI = (float) (45.541+(35.299)+(78.779));
if (tcb->m_cWnd > jISTsCSGoqHeqabI) {
	tcb->m_ssThresh = (int) (43.538+(tcb->m_segmentSize)+(54.035)+(tcb->m_ssThresh)+(5.579)+(19.074)+(74.133)+(10.39));
	tcb->m_ssThresh = (int) (segmentsAcked-(31.893)-(tcb->m_cWnd)-(87.83)-(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (56.798/0.1);
	tcb->m_ssThresh = (int) (24.625-(31.266)-(12.392)-(7.308)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(37.355)-(30.797)-(23.167));

}
if (segmentsAcked >= tcb->m_cWnd) {
	jISTsCSGoqHeqabI = (float) (segmentsAcked*(tcb->m_segmentSize)*(75.847)*(96.065)*(tcb->m_ssThresh)*(jISTsCSGoqHeqabI)*(18.873)*(jISTsCSGoqHeqabI)*(34.341));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(38.447)*(5.942)*(30.407)*(41.055)*(3.261)*(tcb->m_segmentSize)*(13.45));

} else {
	jISTsCSGoqHeqabI = (float) (((0.1)+(0.1)+(0.1)+(75.551)+(58.155))/((54.722)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	jISTsCSGoqHeqabI = (float) (81.982*(60.081)*(80.301)*(77.408)*(68.65)*(38.282)*(74.819)*(30.374)*(78.075));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(34.12)*(7.205)*(74.189)*(76.101)*(79.979)*(84.419)*(97.422));

} else {
	jISTsCSGoqHeqabI = (float) (70.419+(57.583)+(47.309)+(16.866)+(61.876)+(segmentsAcked));
	tcb->m_segmentSize = (int) (35.656-(93.359)-(39.699)-(tcb->m_ssThresh)-(jISTsCSGoqHeqabI)-(jISTsCSGoqHeqabI)-(17.4)-(34.793)-(tcb->m_ssThresh));

}
