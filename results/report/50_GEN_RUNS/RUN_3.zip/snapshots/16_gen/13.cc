segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (12.078+(46.849)+(11.324)+(40.126));

} else {
	tcb->m_cWnd = (int) (27.94-(95.847)-(1.934)-(80.2)-(94.141)-(43.216));

}
tcb->m_ssThresh = (int) (19.795/0.1);
tcb->m_ssThresh = (int) (98.239*(segmentsAcked)*(58.174)*(77.507)*(88.512)*(tcb->m_cWnd)*(59.876)*(11.765)*(28.114));
segmentsAcked = SlowStart (tcb, segmentsAcked);
