float vTfpVTPMCLlsaSEk = (float) (56.408+(39.744));
int fyRVHCTtkqCNfSsF = (int) (tcb->m_segmentSize-(16.65)-(65.668)-(39.13)-(23.707)-(56.993)-(22.82)-(65.822)-(segmentsAcked));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	fyRVHCTtkqCNfSsF = (int) (((0.1)+((6.232-(26.798)-(tcb->m_cWnd)-(0.299)-(35.03)-(44.597)-(60.965)))+(0.1)+(0.1))/((89.065)));
	fyRVHCTtkqCNfSsF = (int) (vTfpVTPMCLlsaSEk+(segmentsAcked));
	tcb->m_cWnd = (int) (segmentsAcked*(24.513)*(vTfpVTPMCLlsaSEk)*(74.053)*(57.765)*(29.453)*(tcb->m_ssThresh));

} else {
	fyRVHCTtkqCNfSsF = (int) (0.1/14.246);

}
int UOxdeCCpgCRhmQKS = (int) (43.83+(43.299)+(41.648)+(82.227)+(6.234)+(96.37)+(vTfpVTPMCLlsaSEk)+(vTfpVTPMCLlsaSEk)+(95.724));
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (41.413+(10.976)+(32.853)+(segmentsAcked)+(83.649)+(tcb->m_segmentSize)+(51.074)+(37.223)+(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (14.984+(vTfpVTPMCLlsaSEk)+(vTfpVTPMCLlsaSEk)+(4.902)+(16.252)+(44.888));
	UOxdeCCpgCRhmQKS = (int) (0.1/0.1);

}
