tcb->m_ssThresh = (int) (84.438-(6.91));
tcb->m_ssThresh = (int) (77.463-(87.87));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (63.783-(segmentsAcked)-(62.004)-(71.891)-(27.959)-(51.809)-(2.378)-(15.419)-(81.308));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (50.221+(tcb->m_segmentSize)+(8.973)+(84.147));

} else {
	tcb->m_cWnd = (int) (6.934/18.467);
	segmentsAcked = (int) (1.036-(97.059)-(segmentsAcked)-(65.316)-(tcb->m_ssThresh)-(46.047));
	tcb->m_ssThresh = (int) (38.986/0.1);

}
int QIFXQTlCBbvhZhiG = (int) (((72.378)+(0.1)+(0.1)+(56.584))/((0.1)+(25.836)+(0.1)));
