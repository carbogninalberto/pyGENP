tcb->m_ssThresh = (int) (17.774+(10.485)+(59.198));
int ycpUcZMWUjrTAujM = (int) (((57.885)+((22.784-(49.082)-(30.688)-(64.951)-(66.465)-(36.451)-(51.914)))+((8.989+(66.32)+(43.809)+(4.911)+(41.022)+(49.677)+(45.091)))+(0.1))/((94.339)+(58.067)+(50.762)));
if (tcb->m_ssThresh <= ycpUcZMWUjrTAujM) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(40.065)+(77.363)+(tcb->m_ssThresh)+(73.954)+(75.451));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (86.152*(74.184)*(62.626)*(39.219));

} else {
	tcb->m_segmentSize = (int) (39.323+(25.259)+(77.218)+(tcb->m_segmentSize)+(35.929)+(25.502)+(45.466)+(78.26)+(87.6));
	tcb->m_ssThresh = (int) (((0.1)+((22.438+(70.957)+(98.963)+(44.608)+(88.367)))+(23.645)+(49.673)+((40.313*(28.845)*(tcb->m_cWnd)*(2.527)*(83.256)*(20.156)*(29.368)*(76.787)*(42.537)))+(0.1)+(0.1))/((0.1)+(60.607)));
	ycpUcZMWUjrTAujM = (int) (88.102*(83.996)*(28.204)*(99.835)*(50.039)*(87.374)*(tcb->m_segmentSize)*(77.67));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((0.1)+(0.1)+(29.919)+(14.692))/((0.1)));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((((48.323+(ycpUcZMWUjrTAujM)+(79.437)+(17.506)+(61.867)+(76.529)+(97.242)+(54.625)))+(89.725)+(0.1)+(60.553))/((56.445)+(9.714)+(0.1)+(0.1)));
	segmentsAcked = (int) (tcb->m_ssThresh+(89.84)+(27.936)+(43.841)+(74.671)+(49.751)+(61.505));
	segmentsAcked = (int) (50.461-(10.961));

} else {
	tcb->m_cWnd = (int) (0.1/91.58);

}
if (ycpUcZMWUjrTAujM == segmentsAcked) {
	tcb->m_cWnd = (int) (97.694/0.1);
	tcb->m_segmentSize = (int) (96.418+(34.294)+(87.884)+(43.388));

} else {
	tcb->m_cWnd = (int) (81.297*(59.639)*(0.103)*(11.07)*(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(63.599)+(41.703))/((0.1)+(0.1)+(0.1)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
