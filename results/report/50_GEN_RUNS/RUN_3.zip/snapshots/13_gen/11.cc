tcb->m_segmentSize = (int) (50.748+(-71.117)+(31.211)+(-9.753)+(-33.548)+(-98.34)+(-38.785));
segmentsAcked = SlowStart (tcb, segmentsAcked);
