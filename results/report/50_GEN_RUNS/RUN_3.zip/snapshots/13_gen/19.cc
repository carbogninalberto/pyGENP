float YHINDExDxpvriLdc = (float) (29.508*(tcb->m_ssThresh)*(42.052)*(85.978)*(91.678)*(68.906)*(67.949)*(48.877)*(35.258));
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	segmentsAcked = (int) (48.326*(1.543));
	tcb->m_ssThresh = (int) (74.618-(23.018)-(tcb->m_segmentSize)-(77.779));

} else {
	segmentsAcked = (int) (((26.46)+(0.1)+((18.331-(24.121)))+((96.436+(7.38)+(32.259)+(95.424)+(10.381)))+(80.235)+(43.169)+(69.217))/((32.931)+(26.902)));

}
int OOaafOQlWPBPjBrg = (int) (42.468-(95.664)-(30.973)-(68.846)-(tcb->m_cWnd));
if (OOaafOQlWPBPjBrg <= YHINDExDxpvriLdc) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(OOaafOQlWPBPjBrg)+(44.008)+(89.554)+(6.921)+(82.806)+(45.927)+(98.685)+(OOaafOQlWPBPjBrg));

} else {
	tcb->m_cWnd = (int) (0.1/22.604);
	segmentsAcked = (int) (84.416*(61.246)*(YHINDExDxpvriLdc)*(43.031)*(tcb->m_ssThresh)*(69.429)*(13.88));
	OOaafOQlWPBPjBrg = (int) (88.812-(tcb->m_cWnd)-(YHINDExDxpvriLdc)-(tcb->m_cWnd)-(61.805)-(57.734));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
