tcb->m_cWnd = (int) (91.053+(68.505)+(tcb->m_cWnd)+(46.613)+(79.692)+(15.357)+(56.147)+(12.084)+(92.917));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
