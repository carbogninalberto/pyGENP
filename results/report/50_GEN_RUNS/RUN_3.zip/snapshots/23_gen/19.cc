TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	segmentsAcked = (int) (97.036+(93.753)+(67.96)+(34.821)+(64.024)+(tcb->m_segmentSize)+(78.305)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) ((59.568-(tcb->m_cWnd)-(56.508)-(1.472))/0.1);

}
ReduceCwnd (tcb);
