if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (82.734+(15.149)+(19.131)+(segmentsAcked)+(tcb->m_ssThresh)+(55.354)+(87.301));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(60.033)+(segmentsAcked)+(tcb->m_cWnd)+(tcb->m_cWnd)+(57.642)+(83.261));
	tcb->m_segmentSize = (int) (51.303-(tcb->m_ssThresh)-(6.686)-(46.662)-(50.173));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
float mXDIChRzqSLGbxcP = (float) (29.807-(71.302)-(60.144));
tcb->m_cWnd = (int) (42.583-(14.516)-(15.417)-(9.499));
CongestionAvoidance (tcb, segmentsAcked);
