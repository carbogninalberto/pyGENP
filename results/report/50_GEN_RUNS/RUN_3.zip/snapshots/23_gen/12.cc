if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (96.845+(85.543)+(55.965)+(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (35.996-(57.564)-(81.665)-(62.869)-(83.71));
	ReduceCwnd (tcb);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (77.907-(9.709)-(73.124));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (26.06-(24.47)-(30.612)-(13.182)-(tcb->m_cWnd)-(82.08)-(28.88)-(70.785)-(24.48));
tcb->m_ssThresh = (int) (0.1/3.088);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
