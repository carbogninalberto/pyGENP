if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((0.1)+(35.793)+(61.501)+(0.1))/((1.502)));

} else {
	tcb->m_segmentSize = (int) (8.474/0.1);

}
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (50.546-(26.695)-(25.304)-(76.67)-(40.174));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (83.329+(tcb->m_ssThresh));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (0.1/0.1);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (57.699+(44.313)+(54.512)+(13.146)+(15.753)+(48.606)+(tcb->m_ssThresh));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (10.674+(75.436)+(38.961)+(0.033)+(25.136)+(71.865));

} else {
	tcb->m_cWnd = (int) (0.1/63.786);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked < segmentsAcked) {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(11.716)+(33.464))/((25.406)));

} else {
	segmentsAcked = (int) (13.508+(98.862)+(tcb->m_ssThresh)+(11.959)+(22.439)+(56.993)+(75.502)+(20.01)+(4.071));
	tcb->m_cWnd = (int) (75.154/55.342);
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((0.1)+(16.945)+(8.614)+(6.191))/((52.906)+(0.1)+(36.225)));
	tcb->m_segmentSize = (int) (55.765*(67.004)*(94.811)*(20.652));
	tcb->m_cWnd = (int) (30.223-(tcb->m_ssThresh)-(13.016));

} else {
	tcb->m_ssThresh = (int) (10.418-(62.635)-(20.755)-(tcb->m_ssThresh)-(26.707)-(53.817)-(4.652));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) ((tcb->m_cWnd*(51.247)*(tcb->m_cWnd)*(62.702)*(42.543)*(53.187)*(66.218))/0.1);

}
segmentsAcked = (int) (8.199/20.589);
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	segmentsAcked = (int) (18.821-(1.406)-(16.905)-(91.911)-(83.306)-(60.093)-(82.933));
	tcb->m_ssThresh = (int) (segmentsAcked+(75.963)+(30.402)+(39.712)+(tcb->m_cWnd)+(38.676)+(80.532)+(33.759)+(12.459));
	tcb->m_ssThresh = (int) (43.492+(tcb->m_cWnd)+(14.75)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(16.99));

} else {
	segmentsAcked = (int) (segmentsAcked*(39.541)*(tcb->m_segmentSize)*(59.108)*(81.903));

}
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (5.247+(39.57)+(2.441));

} else {
	tcb->m_cWnd = (int) ((((24.434-(59.944)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(45.727)-(36.041)-(tcb->m_cWnd)-(61.442)))+(53.409)+((94.675*(56.597)*(96.871)*(tcb->m_segmentSize)*(42.481)))+(50.204)+(0.1))/((0.1)+(0.1)));
	tcb->m_ssThresh = (int) (20.164*(42.906)*(71.588)*(10.771)*(7.273)*(segmentsAcked)*(segmentsAcked));
	tcb->m_ssThresh = (int) (14.327/0.1);

}
