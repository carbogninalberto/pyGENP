TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd > tcb->m_cWnd) {
	segmentsAcked = (int) (32.527+(28.942)+(27.139)+(4.671)+(72.195)+(73.961));

} else {
	segmentsAcked = (int) (27.8*(67.486)*(11.713));
	tcb->m_ssThresh = (int) (75.145+(40.369)+(85.362)+(49.261)+(47.245)+(24.426)+(62.775));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
