tcb->m_segmentSize = (int) (0.1/0.1);
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (2.725-(98.17)-(tcb->m_segmentSize)-(22.157)-(tcb->m_cWnd)-(segmentsAcked));
	tcb->m_segmentSize = (int) (0.1/14.718);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (35.76/1.733);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = (int) (1.251/22.811);
tcb->m_segmentSize = (int) (((75.302)+(0.1)+(60.752)+(0.1))/((0.1)));
segmentsAcked = (int) ((79.489-(75.18)-(50.96)-(91.874))/0.1);
