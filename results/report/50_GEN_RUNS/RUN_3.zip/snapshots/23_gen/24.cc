CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	segmentsAcked = (int) (36.864*(1.435)*(42.117)*(84.276)*(51.029)*(58.887)*(73.193)*(segmentsAcked));

} else {
	segmentsAcked = (int) ((((9.384+(23.314)+(11.116)+(50.541)+(88.112)))+(73.653)+(11.156)+(82.912)+(81.717))/((0.1)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_cWnd = (int) ((0.451*(19.346)*(74.567)*(21.048)*(79.544))/0.1);
	segmentsAcked = (int) (tcb->m_cWnd-(48.28)-(35.697)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(81.057)-(tcb->m_cWnd));
	segmentsAcked = (int) (0.1/37.598);

} else {
	tcb->m_cWnd = (int) (15.942*(93.654)*(tcb->m_ssThresh)*(45.332)*(66.323)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_segmentSize*(31.584)*(14.164)*(50.295)*(60.484)*(31.4));
