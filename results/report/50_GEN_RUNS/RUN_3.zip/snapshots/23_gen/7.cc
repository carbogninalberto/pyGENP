float JJMoXkzXVFdzhSue = (float) (55.865+(15.72)+(91.572)+(-66.184)+(44.042)+(13.007)+(9.73)+(88.307));
int FZMBHnMOFqVbASQL = (int) (-19.36-(25.035)-(-57.443)-(-20.143)-(-92.256)-(-30.984)-(79.262)-(-0.92)-(-96.111));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-41.222+(99.328)+(-3.077)+(-41.444)+(32.296));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
