int TJdzmKaqGxskfIPT = (int) (((0.1)+(81.66)+(49.874)+(36.033)+(74.519))/((0.1)+(0.1)));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (52.931*(40.025)*(97.653)*(44.1)*(87.029)*(75.043)*(61.751)*(25.036)*(27.599));
tcb->m_ssThresh = (int) (segmentsAcked+(87.26)+(77.835)+(86.153));
segmentsAcked = (int) (64.302-(tcb->m_ssThresh)-(14.065)-(73.953)-(53.648)-(16.599)-(37.97)-(tcb->m_segmentSize));
TJdzmKaqGxskfIPT = (int) (5.757*(44.298)*(tcb->m_cWnd));
segmentsAcked = SlowStart (tcb, segmentsAcked);
