tcb->m_ssThresh = (int) (((51.753)+(0.1)+(27.412)+(0.1))/((7.195)+(45.117)+(0.1)));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (22.672*(21.895)*(16.816)*(tcb->m_cWnd)*(72.562)*(16.965));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (61.414*(4.143)*(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(53.838)+(64.359)+(74.606)+(63.689)+(94.376))/((51.548)));

}
