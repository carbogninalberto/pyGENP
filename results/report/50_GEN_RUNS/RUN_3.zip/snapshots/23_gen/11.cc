segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (5.201+(18.364));
	tcb->m_segmentSize = (int) (68.61+(90.497)+(49.317)+(74.695)+(58.019)+(segmentsAcked)+(55.171)+(tcb->m_ssThresh)+(43.548));
	tcb->m_cWnd = (int) (13.204+(56.588)+(21.56)+(68.774)+(55.649)+(43.784));

} else {
	tcb->m_cWnd = (int) (((36.213)+(0.1)+(83.175)+(0.1)+(0.1)+((71.682*(1.807)*(tcb->m_ssThresh)))+(0.1))/((95.285)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (73.183*(29.252)*(tcb->m_cWnd)*(28.773));
tcb->m_ssThresh = (int) (((27.35)+(0.1)+(8.209)+(0.1)+(0.1))/((0.1)+(0.1)));
tcb->m_segmentSize = (int) (99.586*(85.617)*(25.489)*(10.794));
ReduceCwnd (tcb);
