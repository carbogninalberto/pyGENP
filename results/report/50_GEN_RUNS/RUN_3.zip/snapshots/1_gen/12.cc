tcb->m_cWnd = (int) (18.697-(40.566)-(24.833)-(7.459)-(4.661)-(31.338));
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((84.279)+(0.1)+(24.84)+(28.975))/((0.1)+(59.771)+(0.1)));
	segmentsAcked = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (75.323+(8.062)+(segmentsAcked)+(tcb->m_cWnd)+(56.475));
	tcb->m_ssThresh = (int) (94.081*(tcb->m_cWnd)*(79.779)*(tcb->m_cWnd)*(4.558)*(87.701)*(50.132)*(22.246)*(10.604));
	tcb->m_ssThresh = (int) (56.865-(9.71)-(tcb->m_ssThresh)-(8.888)-(27.892)-(45.111)-(67.735)-(tcb->m_cWnd)-(78.399));

}
tcb->m_segmentSize = (int) (55.657-(4.267)-(38.831)-(segmentsAcked)-(segmentsAcked)-(1.856)-(85.863)-(24.173)-(51.574));
tcb->m_cWnd = (int) (58.901+(51.375)+(54.643)+(tcb->m_ssThresh));
segmentsAcked = (int) (11.368+(4.395)+(77.149)+(50.709)+(3.362)+(85.842));
