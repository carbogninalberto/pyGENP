int eGOcTPCqCBWTmrip = (int) (59.201-(tcb->m_cWnd)-(tcb->m_segmentSize)-(92.093)-(46.422)-(83.065)-(66.861)-(tcb->m_segmentSize));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	eGOcTPCqCBWTmrip = (int) (95.954+(tcb->m_segmentSize)+(76.112));

} else {
	eGOcTPCqCBWTmrip = (int) (78.8-(12.234)-(27.179));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (96.619-(67.864)-(tcb->m_ssThresh)-(segmentsAcked)-(eGOcTPCqCBWTmrip)-(81.255)-(30.755));

}
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(73.071)+(52.589)+(4.173)+(76.73)+(15.652)+(63.289)+(segmentsAcked));
	tcb->m_cWnd = (int) (7.822/0.1);

} else {
	tcb->m_cWnd = (int) (52.644*(6.102));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(47.643)+(89.686)+(26.439)+(59.772)+(48.963)+(segmentsAcked)+(71.821));

}
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (19.101*(18.395));

} else {
	tcb->m_ssThresh = (int) ((tcb->m_cWnd*(89.571)*(38.159)*(72.275)*(13.084)*(tcb->m_ssThresh))/72.645);
	eGOcTPCqCBWTmrip = (int) (((84.562)+(0.1)+(0.1)+((6.448-(92.426)-(61.4)-(73.563)))+(4.42))/((63.415)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (37.87-(71.154));

} else {
	tcb->m_segmentSize = (int) (30.088*(21.69)*(35.621)*(28.393));

}
ReduceCwnd (tcb);
if (eGOcTPCqCBWTmrip < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (82.968*(tcb->m_cWnd)*(35.885));
	tcb->m_segmentSize = (int) (31.318-(0.889)-(40.485)-(56.031)-(77.924));

} else {
	tcb->m_segmentSize = (int) (37.358*(39.445)*(50.221)*(61.765)*(48.145)*(57.5)*(9.055)*(72.271)*(tcb->m_segmentSize));
	segmentsAcked = (int) (segmentsAcked+(eGOcTPCqCBWTmrip)+(91.358));

}
