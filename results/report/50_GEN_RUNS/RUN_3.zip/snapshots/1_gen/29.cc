if (tcb->m_ssThresh == tcb->m_segmentSize) {
	segmentsAcked = (int) (12.66-(tcb->m_segmentSize)-(33.066)-(segmentsAcked)-(47.87)-(78.178));
	segmentsAcked = (int) (((0.1)+((segmentsAcked*(20.41)*(48.1)*(3.11)))+((63.177*(58.736)*(43.186)*(56.371)*(23.926)*(tcb->m_ssThresh)*(22.469)*(27.417)*(38.788)))+(0.1)+(67.773)+(0.1)+(0.1))/((99.942)+(61.964)));

} else {
	segmentsAcked = (int) (98.442*(34.37)*(46.482)*(tcb->m_cWnd)*(82.049)*(tcb->m_cWnd)*(41.048)*(9.296)*(tcb->m_cWnd));
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(43.746)-(58.485)-(18.196)-(39.964)-(17.967)-(8.318));
	tcb->m_ssThresh = (int) (25.416+(91.636)+(84.38)+(95.464)+(56.411)+(51.209)+(41.189));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (12.477+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(78.656)+(2.253));
segmentsAcked = (int) (94.563-(56.02));
tcb->m_segmentSize = (int) (tcb->m_cWnd-(42.762)-(segmentsAcked)-(85.662)-(9.79));
CongestionAvoidance (tcb, segmentsAcked);
