TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh == segmentsAcked) {
	segmentsAcked = (int) (((21.645)+(0.1)+(0.1)+(99.248))/((67.049)+(0.1)+(75.112)));

} else {
	segmentsAcked = (int) (16.694*(70.39));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (83.263-(21.746)-(40.857)-(56.909));

}
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(4.512)*(tcb->m_ssThresh)*(14.503)*(32.878)*(71.31)*(49.332));
	segmentsAcked = (int) (tcb->m_segmentSize+(tcb->m_cWnd));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (72.017-(23.224)-(segmentsAcked)-(tcb->m_segmentSize)-(24.401));
	tcb->m_segmentSize = (int) (90.202+(88.526));

}
tcb->m_segmentSize = (int) (16.241+(8.545)+(17.805)+(72.688));
float mcpEnhdYtFdkTdHv = (float) (58.063-(78.622)-(segmentsAcked)-(48.443));
float ecVDsPdthDvmJBSC = (float) (17.455+(tcb->m_cWnd)+(78.145)+(95.072)+(mcpEnhdYtFdkTdHv)+(45.911)+(81.538)+(tcb->m_cWnd));
ReduceCwnd (tcb);
