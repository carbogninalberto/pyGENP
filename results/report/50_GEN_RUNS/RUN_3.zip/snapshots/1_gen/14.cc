tcb->m_segmentSize = (int) (((16.145)+(0.1)+(54.937)+(0.1)+(0.1))/((30.006)+(0.1)+(0.1)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float LzAIjWUcYsTxLrIh = (float) (tcb->m_ssThresh*(7.294)*(92.99));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
