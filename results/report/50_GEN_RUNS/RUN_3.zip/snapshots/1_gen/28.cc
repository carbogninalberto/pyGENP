TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (59.903+(12.021)+(5.098)+(52.322)+(5.952)+(tcb->m_segmentSize)+(78.701));
tcb->m_cWnd = (int) (tcb->m_ssThresh+(60.782)+(34.249)+(tcb->m_cWnd)+(35.111)+(44.27)+(81.734)+(tcb->m_ssThresh));
float AvUCGABCjhfUTABA = (float) (65.934+(tcb->m_cWnd)+(72.273)+(60.24));
ReduceCwnd (tcb);
