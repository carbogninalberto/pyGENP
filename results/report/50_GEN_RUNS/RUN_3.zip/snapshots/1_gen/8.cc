segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (26.197/0.1);
if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (62.174+(55.793));
	tcb->m_ssThresh = (int) (34.086+(15.691)+(70.418)+(58.858)+(82.512)+(tcb->m_cWnd)+(39.702)+(94.165)+(87.572));

} else {
	tcb->m_cWnd = (int) (46.807/47.233);

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(92.003)*(tcb->m_segmentSize)*(60.459)*(43.655)*(64.63)*(25.214));
int TXGXDMZDUsZpTtsY = (int) (((82.485)+(66.515)+(0.1)+(92.173))/((0.1)+(0.1)+(14.761)+(20.888)));
if (TXGXDMZDUsZpTtsY == tcb->m_ssThresh) {
	segmentsAcked = (int) (92.07/16.366);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (0.1/(46.391-(61.768)-(24.323)-(0.113)-(34.355)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize-(26.589)-(90.617)-(99.263)-(55.754)-(7.782));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (13.306-(11.847)-(84.659)-(0.65)-(31.929));
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((((99.91*(segmentsAcked)*(43.389)*(22.877)*(18.316)*(16.044)*(48.916)))+((54.98+(tcb->m_ssThresh)+(20.016)+(34.226)+(70.833)+(60.52)))+(35.585)+(94.416)+((67.26-(71.487)-(tcb->m_ssThresh)-(7.553)-(27.509)-(segmentsAcked)-(35.37)-(15.289)))+(76.243))/((0.1)+(99.415)+(0.1)));
	TXGXDMZDUsZpTtsY = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (6.767+(59.463)+(21.426)+(77.283));

}
