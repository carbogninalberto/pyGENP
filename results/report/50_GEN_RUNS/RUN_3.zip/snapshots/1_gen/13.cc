if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (66.88-(56.283)-(35.189)-(60.695));
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(41.4)*(2.998));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (54.287+(81.821)+(57.695)+(27.411));

}
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	segmentsAcked = (int) (79.665*(segmentsAcked)*(18.279)*(8.158)*(61.927));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (36.069*(tcb->m_segmentSize)*(32.081)*(21.134)*(93.007)*(28.738));
	tcb->m_cWnd = (int) (7.803*(96.217)*(3.955));

}
segmentsAcked = (int) (88.663+(18.457)+(tcb->m_ssThresh)+(90.694)+(56.176)+(tcb->m_cWnd)+(46.469));
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (96.167*(46.909)*(46.567)*(53.266)*(68.337)*(24.955)*(26.838));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (11.536*(13.911)*(3.949)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(58.395)*(69.506)*(segmentsAcked));

}
tcb->m_ssThresh = (int) (0.396-(85.49)-(87.623)-(43.401)-(tcb->m_cWnd)-(35.4));
