segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
int sKIOAKEWVTLGguDX = (int) (19.98-(47.02)-(48.823)-(45.392)-(35.889));
tcb->m_ssThresh = (int) (0.1/33.358);
if (tcb->m_segmentSize <= sKIOAKEWVTLGguDX) {
	sKIOAKEWVTLGguDX = (int) (60.572+(38.887)+(tcb->m_segmentSize)+(24.221)+(29.86)+(95.651)+(tcb->m_cWnd)+(sKIOAKEWVTLGguDX)+(50.461));

} else {
	sKIOAKEWVTLGguDX = (int) (53.929+(24.634)+(79.894)+(tcb->m_cWnd)+(30.994)+(25.454));
	tcb->m_ssThresh = (int) (91.93/0.1);

}
