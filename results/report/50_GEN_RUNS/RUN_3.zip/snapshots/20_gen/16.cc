CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (55.813+(61.128)+(74.8));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (48.662+(73.803)+(36.749)+(61.146)+(80.732));
tcb->m_cWnd = (int) (51.035/0.1);
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (64.474+(6.343)+(57.842));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(86.549));
	tcb->m_ssThresh = (int) (15.402+(segmentsAcked)+(57.939)+(76.935));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (20.125-(57.927));

} else {
	tcb->m_segmentSize = (int) (48.023+(93.68)+(99.658)+(22.118)+(23.596));
	segmentsAcked = (int) (16.887/0.1);

}
