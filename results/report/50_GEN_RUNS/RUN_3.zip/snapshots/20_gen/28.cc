if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (96.33+(72.84)+(50.522)+(tcb->m_segmentSize)+(76.533)+(19.319)+(80.275)+(29.358));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (28.317+(7.405)+(tcb->m_ssThresh)+(87.163)+(21.088));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(79.256));

}
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(62.701)+(4.157)+(90.666)+(77.48)+(77.264)+(segmentsAcked)+(36.398)+(11.936));
	tcb->m_cWnd = (int) (70.658*(tcb->m_cWnd)*(85.486)*(1.559)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(15.25));
	tcb->m_ssThresh = (int) (95.536+(17.081)+(tcb->m_cWnd)+(60.895)+(17.992)+(46.295)+(67.834));

} else {
	tcb->m_cWnd = (int) ((26.989*(90.283)*(18.197)*(tcb->m_ssThresh)*(6.912)*(94.762))/0.1);
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (46.177*(40.314)*(85.7)*(tcb->m_segmentSize)*(segmentsAcked));
	tcb->m_cWnd = (int) (95.275/5.104);
	tcb->m_segmentSize = (int) (42.354*(tcb->m_cWnd)*(38.822)*(23.299)*(0.589)*(tcb->m_cWnd)*(tcb->m_cWnd)*(73.667));

} else {
	tcb->m_segmentSize = (int) (86.466+(79.863)+(76.904)+(79.494)+(tcb->m_ssThresh)+(37.414)+(40.951));
	tcb->m_ssThresh = (int) (((0.1)+(25.418)+(69.886)+((59.992*(68.499)*(89.994)*(6.04)*(48.178)))+(0.1)+(56.834))/((41.117)+(28.44)));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_segmentSize-(73.332)-(70.146)-(83.18)-(tcb->m_ssThresh)-(7.675)-(32.251)-(49.636));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh+(25.54)+(87.656)+(54.749)+(tcb->m_cWnd)+(20.286)+(tcb->m_ssThresh)+(49.978));
	tcb->m_ssThresh = (int) (83.878-(44.677)-(82.185)-(58.187)-(0.926)-(1.158)-(5.106)-(tcb->m_cWnd));
	segmentsAcked = (int) (36.812*(47.108)*(52.6)*(32.727)*(segmentsAcked));

}
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
