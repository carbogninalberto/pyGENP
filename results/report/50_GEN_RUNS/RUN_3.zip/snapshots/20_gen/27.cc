segmentsAcked = SlowStart (tcb, segmentsAcked);
float mNDzpboSCRZDRWgl = (float) (21.272+(segmentsAcked)+(75.704)+(55.531));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((0.1)+(50.67)+(82.91)+(0.1)+(12.258)+(0.1))/((30.11)+(0.1)+(0.1)));
