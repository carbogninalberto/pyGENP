segmentsAcked = (int) (11.926/94.337);
tcb->m_segmentSize = (int) (tcb->m_cWnd+(61.421)+(67.883)+(42.067)+(tcb->m_cWnd)+(2.687)+(18.705)+(tcb->m_ssThresh));
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/83.736);
	tcb->m_segmentSize = (int) (14.949-(74.33));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (98.291-(tcb->m_segmentSize)-(27.759)-(2.43)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(6.444));
	tcb->m_cWnd = (int) (((23.138)+(34.079)+(18.027)+((segmentsAcked*(55.802)*(10.486)*(59.84)*(23.127)))+(0.1)+(67.078))/((0.1)));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((((82.884*(88.538)*(46.356)*(99.571)*(22.955)*(tcb->m_segmentSize)*(51.736)))+(0.1)+(0.1)+(0.1)+(96.194)+(0.1)+(0.1)+(0.1))/((78.305)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
