if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_cWnd = (int) (65.321+(35.076)+(96.859)+(45.591)+(78.354)+(19.367));
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(58.647)+(34.896)+(17.639)+(3.645)+(tcb->m_cWnd)+(94.26)+(27.45));

} else {
	tcb->m_cWnd = (int) (23.261/0.1);

}
int MxRRDQVenORyMSZv = (int) (59.42*(60.798));
segmentsAcked = (int) (66.851*(19.259)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(51.103)*(60.468)*(tcb->m_ssThresh)*(89.237)*(54.589));
MxRRDQVenORyMSZv = (int) (24.599+(35.678)+(MxRRDQVenORyMSZv)+(tcb->m_ssThresh)+(74.587)+(28.678)+(tcb->m_segmentSize));
ReduceCwnd (tcb);
