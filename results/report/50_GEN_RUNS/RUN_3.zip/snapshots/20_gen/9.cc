int RIehxcDeRKsAHcUK = (int) (-84.714*(29.846)*(80.067)*(-56.899)*(58.37)*(67.529)*(4.993)*(-47.777)*(-0.766));
int zfqDXoniBxUTdZcT = (int) (-43.178-(-74.075)-(11.707));
if (zfqDXoniBxUTdZcT < RIehxcDeRKsAHcUK) {
	tcb->m_cWnd = (int) (21.52/0.1);
	segmentsAcked = (int) (44.3-(51.026)-(zfqDXoniBxUTdZcT)-(tcb->m_segmentSize)-(39.847)-(9.288)-(82.562)-(4.701)-(61.097));
	segmentsAcked = (int) (72.862/45.732);

} else {
	tcb->m_cWnd = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
