if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_cWnd = (int) (94.57+(62.656)+(42.043)+(84.719)+(48.493));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (92.971*(45.561)*(91.526));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_ssThresh+(70.571)+(tcb->m_ssThresh)+(26.419)+(tcb->m_segmentSize)+(3.995)+(59.134)+(55.115));
tcb->m_cWnd = (int) (1.591*(98.394)*(64.574));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (30.387*(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) ((((38.18*(46.076)*(31.828)*(17.145)*(13.436)*(11.907)))+((6.273*(85.55)*(81.626)*(90.023)))+((tcb->m_ssThresh+(segmentsAcked)+(tcb->m_segmentSize)))+(0.1)+(0.1)+((2.623+(40.803)+(92.961)+(72.173)+(20.776)+(92.538)+(0.379)))+(25.514))/((21.137)+(0.1)));

}
segmentsAcked = (int) (99.4*(18.777)*(83.816)*(15.17)*(76.993)*(10.418)*(82.512)*(4.576));
CongestionAvoidance (tcb, segmentsAcked);
