if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (69.385-(22.413)-(52.773)-(5.617)-(97.034)-(6.782)-(29.399)-(segmentsAcked));
	segmentsAcked = (int) (1.059/0.1);

} else {
	tcb->m_cWnd = (int) (38.779+(57.8)+(78.772));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(18.347)+(6.569)+((89.111*(tcb->m_cWnd)*(78.547)*(28.54)*(94.645)))+(0.1))/((0.1)));

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_ssThresh) {
	segmentsAcked = (int) (23.246+(tcb->m_cWnd)+(tcb->m_segmentSize)+(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (52.307+(segmentsAcked)+(79.759)+(78.957)+(35.717)+(16.783)+(88.501)+(54.939)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (60.574+(tcb->m_cWnd)+(tcb->m_segmentSize)+(35.551)+(tcb->m_segmentSize)+(segmentsAcked)+(70.844));

} else {
	segmentsAcked = (int) (60.411-(37.638)-(77.48)-(57.457)-(67.155)-(65.566));

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (90.514/37.605);
tcb->m_cWnd = (int) (tcb->m_segmentSize-(2.62)-(33.234)-(89.475)-(62.154)-(48.442));
segmentsAcked = SlowStart (tcb, segmentsAcked);
