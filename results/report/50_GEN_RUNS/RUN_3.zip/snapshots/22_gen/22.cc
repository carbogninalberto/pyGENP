tcb->m_segmentSize = (int) (52.461-(40.745)-(42.298));
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (61.593-(43.93));

} else {
	tcb->m_cWnd = (int) (75.175+(66.425)+(17.896));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (0.1/0.1);
tcb->m_cWnd = (int) (67.412-(segmentsAcked));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (segmentsAcked+(70.479));

} else {
	tcb->m_ssThresh = (int) (46.084*(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (0.1/0.1);

}
