segmentsAcked = (int) (tcb->m_ssThresh+(segmentsAcked)+(tcb->m_segmentSize)+(6.961));
segmentsAcked = SlowStart (tcb, segmentsAcked);
int DDIvyaWiSYaXcHhT = (int) (0.1/0.1);
tcb->m_ssThresh = (int) (37.46*(41.908)*(8.598)*(tcb->m_segmentSize)*(DDIvyaWiSYaXcHhT)*(47.883)*(16.741)*(37.206)*(96.209));
tcb->m_ssThresh = (int) (12.189+(1.291)+(tcb->m_segmentSize)+(75.499));
