tcb->m_cWnd = (int) (69.806-(80.083)-(-94.557));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
