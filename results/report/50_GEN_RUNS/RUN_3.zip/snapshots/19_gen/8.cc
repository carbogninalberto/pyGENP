tcb->m_segmentSize = (int) (-34.612*(-24.813)*(92.263)*(91.15));
tcb->m_segmentSize = (int) (39.022*(-58.045)*(2.256)*(-81.417)*(-40.566)*(-31.578));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (86.758/0.1);

} else {
	tcb->m_cWnd = (int) (86.892-(27.773)-(tcb->m_segmentSize)-(segmentsAcked)-(33.991)-(56.271)-(6.225)-(72.512)-(26.797));

}
