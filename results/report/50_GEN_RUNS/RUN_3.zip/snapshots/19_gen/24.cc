if (tcb->m_ssThresh < tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_cWnd-(95.118)-(3.626)-(9.735)-(4.138));

} else {
	segmentsAcked = (int) (0.1/(58.597*(97.489)*(1.782)));
	segmentsAcked = (int) (38.54*(36.697));

}
tcb->m_cWnd = (int) (89.114+(3.164)+(2.007)+(71.203));
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (46.317-(23.747)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(93.785));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (98.704-(25.973)-(tcb->m_segmentSize)-(79.855)-(61.325)-(35.184)-(63.001)-(85.342)-(93.855));
	tcb->m_segmentSize = (int) (94.718-(98.252));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
