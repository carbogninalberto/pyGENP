CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (91.451*(49.362)*(40.678)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(28.227)*(14.108)*(81.256));
	tcb->m_cWnd = (int) (20.997*(66.324)*(56.343)*(15.291));
	tcb->m_cWnd = (int) (40.183-(88.828)-(2.783));

} else {
	tcb->m_cWnd = (int) (55.092*(80.794)*(tcb->m_ssThresh)*(segmentsAcked)*(segmentsAcked)*(79.683)*(tcb->m_cWnd)*(segmentsAcked));
	tcb->m_segmentSize = (int) (52.092+(tcb->m_ssThresh)+(14.049));

}
int muLkeJMyIeNFjTNN = (int) (5.232*(tcb->m_cWnd)*(45.411)*(71.76)*(34.392)*(42.827)*(14.638)*(36.585));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (36.072*(52.186));
ReduceCwnd (tcb);
