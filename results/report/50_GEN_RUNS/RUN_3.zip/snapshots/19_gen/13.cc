TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (76.401*(98.342)*(-94.661)*(-21.75)*(31.825)*(-65.659)*(23.89)*(-83.278));
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (tcb->m_cWnd+(2.504)+(82.028)+(62.528)+(95.297)+(tcb->m_segmentSize)+(5.68)+(25.005)+(74.432));
	segmentsAcked = (int) (30.384-(16.298)-(5.635)-(3.923)-(62.506)-(17.87)-(17.045)-(76.268)-(31.356));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(28.412)*(73.453));
	tcb->m_segmentSize = (int) (2.175-(53.264)-(79.959)-(tcb->m_cWnd)-(78.86));

}
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (tcb->m_cWnd+(2.504)+(82.028)+(62.528)+(95.297)+(tcb->m_segmentSize)+(5.68)+(25.005)+(74.432));
	segmentsAcked = (int) (30.384-(16.298)-(5.635)-(3.923)-(62.506)-(17.87)-(17.045)-(76.268)-(31.356));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(28.412)*(73.453));
	tcb->m_segmentSize = (int) (2.175-(53.264)-(79.959)-(tcb->m_cWnd)-(78.86));

}
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (tcb->m_segmentSize*(28.412)*(73.453));
	tcb->m_segmentSize = (int) (2.175-(53.264)-(79.959)-(tcb->m_cWnd)-(78.86));

} else {
	segmentsAcked = (int) (tcb->m_cWnd+(2.504)+(82.028)+(62.528)+(95.297)+(tcb->m_segmentSize)+(5.68)+(25.005)+(74.432));
	segmentsAcked = (int) (30.384-(16.298)-(5.635)-(-16.408)-(62.506)-(17.87)-(17.045)-(76.268)-(31.356));

}
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (tcb->m_segmentSize*(28.412)*(73.453));
	tcb->m_segmentSize = (int) (2.175-(53.264)-(79.959)-(tcb->m_cWnd)-(78.86));

} else {
	segmentsAcked = (int) (tcb->m_cWnd+(2.504)+(82.028)+(62.528)+(95.297)+(tcb->m_segmentSize)+(5.68)+(25.005)+(74.432));
	segmentsAcked = (int) (30.384-(16.298)-(5.635)-(-16.408)-(62.506)-(17.87)-(17.045)-(76.268)-(31.356));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
