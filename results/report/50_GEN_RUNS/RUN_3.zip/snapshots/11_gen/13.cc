if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (22.092+(37.449)+(71.892)+(78.663)+(19.129)+(tcb->m_segmentSize)+(83.969)+(10.818));
	tcb->m_segmentSize = (int) (94.801*(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (32.313+(81.729)+(85.527));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh+(tcb->m_cWnd)+(57.393)+(12.746)+(83.134));

}
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	segmentsAcked = (int) (segmentsAcked+(segmentsAcked)+(89.119)+(9.2)+(18.225)+(88.383)+(66.422)+(93.73)+(68.015));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (12.541+(45.733));

} else {
	segmentsAcked = (int) (32.289+(96.969)+(54.195));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) (90.344+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(38.875)+(96.016)+(98.356)+(92.326)+(50.798)+(29.57));
	tcb->m_segmentSize = (int) (segmentsAcked*(tcb->m_cWnd)*(23.293));

} else {
	tcb->m_cWnd = (int) (57.611/12.129);
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(tcb->m_cWnd)+(19.091)+(tcb->m_ssThresh)+(86.312)+(92.706));

} else {
	tcb->m_ssThresh = (int) (94.965-(tcb->m_segmentSize)-(2.75)-(8.416)-(35.296)-(95.156)-(36.272)-(tcb->m_ssThresh)-(12.805));

}
