float QSKVhrXQoPmdosqW = (float) (-30.388/-68.516);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (71.801/59.639);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (94.539*(5.544)*(-70.747)*(-7.242)*(48.934));
tcb->m_segmentSize = (int) (-17.979*(-21.087)*(29.557)*(74.928)*(41.353)*(32.939)*(29.576)*(93.775)*(16.361));
