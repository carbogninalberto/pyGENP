segmentsAcked = (int) (tcb->m_segmentSize+(tcb->m_segmentSize)+(2.078));
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (73.817-(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(3.334));

}
tcb->m_ssThresh = (int) (tcb->m_segmentSize+(5.026)+(46.81)+(7.328)+(tcb->m_cWnd)+(78.121));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh != tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd-(70.702)-(51.023)-(5.126)-(78.811));

} else {
	segmentsAcked = (int) (12.255-(11.081)-(tcb->m_cWnd)-(15.76)-(96.536)-(47.124));

}
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_cWnd = (int) (2.182+(4.236)+(26.458)+(23.242)+(20.547)+(14.563));
	segmentsAcked = (int) (78.944-(74.152)-(tcb->m_segmentSize)-(44.356)-(tcb->m_cWnd)-(81.426)-(16.698)-(tcb->m_cWnd)-(64.982));

} else {
	tcb->m_cWnd = (int) (44.71*(39.843)*(71.119));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize <= segmentsAcked) {
	segmentsAcked = (int) (((0.1)+((16.288+(79.491)+(83.183)+(21.639)+(63.335)+(32.002)+(95.193)+(50.977)+(21.548)))+(0.1)+(0.1))/((83.974)+(55.432)+(4.193)));

} else {
	segmentsAcked = (int) (70.849/0.1);
	tcb->m_segmentSize = (int) (40.184+(25.397)+(63.824)+(9.867)+(87.513)+(97.122)+(57.079)+(33.153)+(1.245));

}
