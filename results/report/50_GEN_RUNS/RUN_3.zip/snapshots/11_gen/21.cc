if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_segmentSize*(71.834)*(82.601));
	tcb->m_segmentSize = (int) (89.457*(24.973)*(18.268)*(52.18)*(68.879));
	segmentsAcked = (int) (43.856+(65.925)+(15.824)+(38.905)+(31.807)+(34.435)+(6.398));

} else {
	segmentsAcked = (int) (64.41+(42.498)+(18.602)+(45.524)+(tcb->m_ssThresh)+(93.608)+(48.149));
	tcb->m_ssThresh = (int) (70.509*(19.293)*(84.309)*(43.303));
	tcb->m_ssThresh = (int) (12.094*(tcb->m_ssThresh)*(32.501));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (81.566+(segmentsAcked)+(88.486)+(43.088)+(22.793)+(6.96)+(31.268));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (59.582*(83.949)*(tcb->m_segmentSize)*(45.94));
