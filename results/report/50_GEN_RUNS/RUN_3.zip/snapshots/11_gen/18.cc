if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/39.78);

} else {
	tcb->m_cWnd = (int) (84.819-(tcb->m_ssThresh)-(88.13)-(75.182)-(62.598));

}
tcb->m_ssThresh = (int) (35.865*(49.478)*(83.872)*(15.212)*(tcb->m_ssThresh));
tcb->m_ssThresh = (int) (tcb->m_cWnd+(28.969)+(80.455));
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+((75.838*(47.451)*(11.167)*(99.913)*(21.407)*(26.404)*(4.124)))+(0.1)+(0.1))/((45.811)+(63.909)+(76.01)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (63.851+(33.73)+(59.396)+(24.286)+(92.629)+(1.84)+(tcb->m_segmentSize)+(97.034));

}
tcb->m_cWnd = (int) (((70.334)+(8.146)+(0.1)+(6.94))/((0.1)));
segmentsAcked = (int) (segmentsAcked+(32.285)+(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (segmentsAcked-(segmentsAcked)-(tcb->m_cWnd));
CongestionAvoidance (tcb, segmentsAcked);
