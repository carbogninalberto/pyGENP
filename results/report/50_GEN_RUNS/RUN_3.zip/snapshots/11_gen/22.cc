TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(51.714)*(35.17)*(22.438)*(8.938)*(94.509));
	tcb->m_segmentSize = (int) (64.623*(64.185)*(tcb->m_cWnd)*(96.8)*(54.733)*(59.419)*(tcb->m_cWnd)*(tcb->m_cWnd)*(19.243));
	segmentsAcked = (int) (25.393-(43.662)-(69.478)-(tcb->m_segmentSize)-(4.076));

} else {
	tcb->m_segmentSize = (int) (2.548-(52.381)-(85.829)-(52.976)-(19.441)-(85.748));

}
tcb->m_cWnd = (int) (48.753+(3.473)+(65.486)+(46.503)+(segmentsAcked)+(tcb->m_ssThresh)+(79.6)+(58.847));
ReduceCwnd (tcb);
if (tcb->m_ssThresh != tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/46.469);

} else {
	segmentsAcked = (int) (62.74-(tcb->m_ssThresh)-(55.171)-(3.246)-(16.132));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (7.802+(69.447)+(12.538)+(1.777)+(25.506)+(14.548));

}
