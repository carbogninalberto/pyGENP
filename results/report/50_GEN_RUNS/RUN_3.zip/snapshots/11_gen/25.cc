tcb->m_ssThresh = (int) (86.198-(1.4)-(26.154)-(25.17));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (14.524-(31.181));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (77.791+(21.049)+(56.751)+(92.264)+(52.965)+(22.175)+(29.461)+(0.823)+(19.09));

}
tcb->m_segmentSize = (int) ((41.867*(tcb->m_cWnd)*(79.191))/(73.756+(tcb->m_ssThresh)+(64.48)));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(64.865)+(40.941)+(45.399)+(80.765)+(10.694)+(82.091));
tcb->m_ssThresh = (int) (segmentsAcked-(75.607)-(48.078)-(segmentsAcked)-(11.902)-(27.851)-(44.599));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
