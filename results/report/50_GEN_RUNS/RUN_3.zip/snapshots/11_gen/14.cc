segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (24.932*(70.171)*(tcb->m_segmentSize)*(1.976)*(tcb->m_segmentSize)*(80.857)*(42.566));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (85.204*(33.648)*(43.384));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(tcb->m_cWnd)*(tcb->m_ssThresh)*(66.027)*(48.939)*(33.518)*(22.16));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(55.137)+(77.759)+(51.535)+(84.213)+(20.52)+(56.859));
	tcb->m_ssThresh = (int) (27.185-(46.925));

}
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_segmentSize = (int) (55.095+(39.551)+(tcb->m_cWnd)+(tcb->m_cWnd));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (5.518+(94.658)+(6.468)+(50.414)+(20.764)+(11.171)+(20.216));
	CongestionAvoidance (tcb, segmentsAcked);

}
