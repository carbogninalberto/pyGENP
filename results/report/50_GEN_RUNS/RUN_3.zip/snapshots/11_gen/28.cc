tcb->m_segmentSize = (int) (segmentsAcked*(85.756)*(64.19)*(46.94));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	segmentsAcked = (int) (11.283-(2.611)-(78.751)-(58.155)-(52.98)-(10.51)-(4.785));
	segmentsAcked = (int) (((0.1)+(0.1)+(87.952)+((tcb->m_cWnd-(26.683)-(2.207)-(67.046)))+(10.023))/((88.589)+(0.1)));
	tcb->m_cWnd = (int) (1.804-(86.733)-(54.082)-(75.705)-(90.597)-(79.28));

} else {
	segmentsAcked = (int) (6.997/11.546);

}
tcb->m_segmentSize = (int) (16.174+(3.71)+(51.273)+(84.442));
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_ssThresh = (int) (44.803*(13.217)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(58.208)*(96.76)*(19.428)*(tcb->m_ssThresh)*(34.785));
	segmentsAcked = (int) (91.688-(58.714)-(segmentsAcked)-(43.973)-(segmentsAcked)-(69.268)-(59.771));
	tcb->m_cWnd = (int) (segmentsAcked*(99.464));

} else {
	tcb->m_ssThresh = (int) (74.617*(29.452));
	ReduceCwnd (tcb);

}
float SkyRvXCnslFBOhTP = (float) (59.261+(2.24)+(20.886)+(40.883)+(30.66)+(tcb->m_ssThresh)+(segmentsAcked));
