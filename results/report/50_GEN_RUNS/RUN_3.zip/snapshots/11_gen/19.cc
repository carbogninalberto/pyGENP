ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	segmentsAcked = (int) (2.813*(tcb->m_segmentSize)*(62.554)*(22.894)*(tcb->m_cWnd)*(43.82)*(69.052)*(97.825));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (80.539*(95.151)*(41.495)*(18.207)*(57.827)*(40.446)*(43.909)*(16.76));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (0.1/93.226);

}
if (segmentsAcked < segmentsAcked) {
	tcb->m_ssThresh = (int) (62.162*(29.661)*(14.246)*(11.516)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(22.688)*(tcb->m_segmentSize)*(95.113));
	tcb->m_ssThresh = (int) (85.718+(13.475)+(32.096)+(tcb->m_ssThresh)+(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (95.315*(11.204)*(62.826)*(36.732)*(7.302));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (10.634+(12.94)+(65.977)+(19.742)+(89.576)+(48.069)+(43.945)+(0.506));

}
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (97.358*(83.803));

} else {
	tcb->m_segmentSize = (int) (41.001-(5.441)-(19.763)-(50.391));
	tcb->m_ssThresh = (int) (90.014*(tcb->m_segmentSize)*(60.522)*(51.97)*(15.15)*(85.981)*(23.642)*(segmentsAcked)*(16.413));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (78.651*(tcb->m_ssThresh));
tcb->m_cWnd = (int) (48.223+(79.74)+(44.136)+(73.086)+(10.059)+(1.03)+(51.561));
