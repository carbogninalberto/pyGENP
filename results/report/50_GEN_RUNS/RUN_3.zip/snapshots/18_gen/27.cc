if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (21.616-(61.193)-(49.112)-(51.084)-(24.434)-(19.613)-(58.463));
	segmentsAcked = (int) (28.117-(23.548)-(69.511)-(1.125)-(28.876)-(54.225));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (31.913*(96.524)*(34.835)*(63.974)*(39.511));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (21.616-(61.193)-(49.112)-(51.084)-(24.434)-(19.613)-(58.463));
	segmentsAcked = (int) (28.117-(23.548)-(69.511)-(1.125)-(28.876)-(54.225));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (31.913*(96.524)*(34.835)*(63.974)*(39.511));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
float nDOaBGLnMUpeqAFI = (float) (3.581*(35.481)*(3.81)*(6.49)*(95.853)*(63.782)*(-13.577)*(13.248));
tcb->m_cWnd = (int) (-40.236-(-1.391)-(-92.196)-(5.77));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-62.587-(-61.648)-(-74.303)-(-50.098));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
