float pzfCmiZtRdGvboUc = (float) (-60.393/37.234);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (66.269/-98.899);
CongestionAvoidance (tcb, segmentsAcked);
