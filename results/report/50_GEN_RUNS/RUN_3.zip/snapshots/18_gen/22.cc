int tRTlRLSiFFWbPJVd = (int) 14.646;
tcb->m_cWnd = (int) (-82.403*(82.98)*(65.413)*(79.805)*(10.663)*(84.901)*(-70.937));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((92.42+(82.505)+(38.632)+(tcb->m_segmentSize)+(65.951))/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (20.424*(95.783)*(70.064)*(42.986)*(18.828)*(51.493)*(tRTlRLSiFFWbPJVd)*(22.152));

}
segmentsAcked = (int) (-91.737+(-73.368)+(-50.344)+(77.712)+(-40.64));
ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((92.42+(82.505)+(38.632)+(tcb->m_segmentSize)+(65.951))/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (20.424*(95.783)*(70.064)*(42.986)*(18.828)*(51.493)*(tRTlRLSiFFWbPJVd)*(22.152));

}
ReduceCwnd (tcb);
