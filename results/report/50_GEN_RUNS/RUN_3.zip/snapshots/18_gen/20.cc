tcb->m_segmentSize = (int) (-14.791-(-11.673)-(-34.686)-(-36.379)-(8.26)-(-48.66));
tcb->m_segmentSize = (int) (24.937*(33.492)*(-28.776)*(-62.634));
tcb->m_segmentSize = (int) (-19.86*(34.11)*(-16.417)*(12.286)*(-35.271)*(-22.5));
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (-44.704+(86.683)+(90.732)+(tcb->m_segmentSize)+(24.677));
	tcb->m_cWnd = (int) (((15.628)+(18.12)+((61.863+(34.229)+(11.157)))+(63.952))/((0.1)+(17.688)));
	tcb->m_segmentSize = (int) (57.361*(97.071)*(57.055)*(90.314)*(37.167)*(segmentsAcked)*(54.248)*(-79.751)*(84.315));

} else {
	segmentsAcked = (int) (39.133+(86.317)+(66.936)+(segmentsAcked)+(47.106)+(95.172)+(-11.78)+(85.67));

}
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (86.892-(27.773)-(tcb->m_segmentSize)-(segmentsAcked)-(33.991)-(56.271)-(6.225)-(72.512)-(26.797));

} else {
	tcb->m_cWnd = (int) (86.758/0.1);

}
tcb->m_cWnd = (int) (-36.311+(51.425)+(-19.259)+(-15.017)+(-61.058)+(7.085)+(84.5));
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (-44.704+(86.683)+(90.732)+(tcb->m_segmentSize)+(24.677));
	tcb->m_cWnd = (int) (((15.628)+(18.12)+((61.863+(34.229)+(11.157)))+(63.952))/((0.1)+(17.688)));
	tcb->m_segmentSize = (int) (57.361*(97.071)*(57.055)*(90.314)*(37.167)*(segmentsAcked)*(54.248)*(-79.751)*(84.315));

} else {
	segmentsAcked = (int) (39.133+(86.317)+(66.936)+(segmentsAcked)+(47.106)+(95.172)+(-11.78)+(85.67));

}
tcb->m_segmentSize = (int) (86.977*(-77.12)*(-10.534)*(-46.726));
tcb->m_cWnd = (int) (67.345+(-67.304)+(-66.044)+(-0.406)+(-8.795)+(-22.304)+(23.755));
tcb->m_segmentSize = (int) (9.62*(-65.763)*(-2.815)*(2.699));
