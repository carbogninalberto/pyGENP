int tRTlRLSiFFWbPJVd = (int) 14.646;
segmentsAcked = (int) (96.096/36.105);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (20.424*(95.783)*(70.064)*(42.986)*(18.828)*(51.493)*(tRTlRLSiFFWbPJVd)*(22.152));

} else {
	tcb->m_segmentSize = (int) ((92.42+(82.505)+(38.632)+(tcb->m_segmentSize)+(65.951))/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
