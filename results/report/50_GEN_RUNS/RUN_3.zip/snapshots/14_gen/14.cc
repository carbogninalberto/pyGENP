tcb->m_ssThresh = (int) (40.181-(99.493)-(43.751)-(48.162));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((0.1)+((86.123+(tcb->m_segmentSize)+(2.696)))+(0.1)+((segmentsAcked*(21.322)*(13.399)*(tcb->m_ssThresh)*(91.564)*(41.199)))+(0.1))/((39.926)+(81.232)));
tcb->m_ssThresh = (int) (62.706+(12.512)+(11.083)+(21.677)+(77.235)+(63.421)+(23.647));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (80.206-(89.0)-(50.341));
	tcb->m_ssThresh = (int) (58.342-(56.936)-(50.135)-(56.612)-(70.925)-(44.452));

} else {
	segmentsAcked = (int) (92.545+(19.132)+(84.208)+(90.754)+(28.505));
	segmentsAcked = (int) (20.338+(tcb->m_cWnd)+(19.497));

}
ReduceCwnd (tcb);
