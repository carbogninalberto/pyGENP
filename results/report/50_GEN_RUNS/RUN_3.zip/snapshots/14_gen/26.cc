segmentsAcked = SlowStart (tcb, segmentsAcked);
float BqQBGwkAOpvIavoX = (float) (60.569*(64.055)*(tcb->m_ssThresh)*(tcb->m_cWnd));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(14.908));
