ReduceCwnd (tcb);
tcb->m_cWnd = (int) (56.127+(-73.577)+(-31.18));
tcb->m_segmentSize = (int) (-98.299*(21.126)*(-31.432)*(3.441)*(-63.115));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (88.186-(-26.212)-(57.049)-(-68.333)-(-11.262)-(-41.781)-(-22.168));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) ((31.332*(57.387)*(57.447)*(30.269)*(87.221))/90.295);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(81.152)+(26.001)+(27.881)+(15.324)+(8.864)+(47.293));
	tcb->m_cWnd = (int) (70.032*(7.885)*(46.023)*(67.119)*(36.775)*(60.87)*(99.115)*(tcb->m_cWnd));

}
tcb->m_segmentSize = (int) (40.278-(-5.026)-(42.72)-(-75.551)-(-46.043)-(7.7)-(-59.029));
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) ((31.332*(57.387)*(57.447)*(30.269)*(87.221))/90.295);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(81.152)+(26.001)+(27.881)+(15.324)+(8.864)+(47.293));
	tcb->m_cWnd = (int) (70.032*(7.885)*(46.023)*(67.119)*(-51.747)*(60.87)*(99.115)*(tcb->m_cWnd));

}
