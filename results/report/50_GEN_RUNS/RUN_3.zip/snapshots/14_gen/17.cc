int bCtKPJwxRgLmhIRb = (int) (9.774+(20.121)+(1.492));
segmentsAcked = (int) (56.749+(99.944)+(95.723)+(0.363)+(tcb->m_ssThresh)+(70.935)+(7.989)+(14.123)+(13.39));
ReduceCwnd (tcb);
float dQWyDQLtrZdWynsK = (float) (68.271-(82.29)-(14.228)-(48.466)-(tcb->m_ssThresh)-(bCtKPJwxRgLmhIRb)-(17.217)-(12.613));
ReduceCwnd (tcb);
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(87.015)+((29.089+(73.543)+(27.39)+(47.439)+(39.357)+(12.671)+(31.041)+(dQWyDQLtrZdWynsK)+(57.401)))+(0.1))/((24.562)+(18.05)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(83.874)+(segmentsAcked));

}
tcb->m_cWnd = (int) (32.775*(99.396)*(93.544));
int JMvouZILAdCrjtci = (int) (75.021-(87.099)-(10.303)-(74.231)-(bCtKPJwxRgLmhIRb)-(45.274)-(tcb->m_cWnd));
if (tcb->m_ssThresh == JMvouZILAdCrjtci) {
	segmentsAcked = (int) (31.27*(7.379)*(segmentsAcked)*(54.309)*(tcb->m_cWnd));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (83.532*(14.687)*(38.314)*(74.327)*(38.009));

}
