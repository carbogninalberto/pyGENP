float AiFYyRLoXHLDbHfi = (float) (((29.065)+(41.495)+(73.936)+((4.643+(tcb->m_segmentSize)+(segmentsAcked)+(73.092)+(tcb->m_ssThresh)))+(0.1))/((95.214)+(0.1)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (19.672*(87.124)*(88.347)*(53.722));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (12.406*(tcb->m_segmentSize)*(59.739)*(67.844)*(88.898));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (((39.013)+(0.1)+(0.1)+(66.333)+(0.1)+(0.1))/((6.471)+(0.1)+(0.1)));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) ((((56.583+(tcb->m_ssThresh)+(AiFYyRLoXHLDbHfi)+(38.841)+(62.906)))+((11.269+(50.032)+(98.292)+(tcb->m_ssThresh)+(30.93)+(tcb->m_ssThresh)+(14.688)+(97.243)+(segmentsAcked)))+(0.1)+(29.949)+(0.1)+(20.802))/((0.1)+(54.39)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
