int QcsHwISJALIilLrS = (int) (((66.389)+(0.1)+(22.977)+(14.592)+(66.372))/((37.507)));
QcsHwISJALIilLrS = (int) (15.992-(67.781)-(98.981));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (0.1/27.065);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(tcb->m_segmentSize)+(1.955)+(40.099)+(39.874)+(11.243)+(QcsHwISJALIilLrS)+(57.482)+(69.765));
	tcb->m_ssThresh = (int) (46.611*(4.818));
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((69.372)));

} else {
	tcb->m_cWnd = (int) (40.214+(92.495)+(77.402));

}
if (tcb->m_cWnd != tcb->m_cWnd) {
	QcsHwISJALIilLrS = (int) (90.332-(tcb->m_ssThresh)-(0.104)-(90.374)-(71.091)-(94.821));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	QcsHwISJALIilLrS = (int) (35.981*(28.362));

}
