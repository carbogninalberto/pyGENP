ReduceCwnd (tcb);
segmentsAcked = (int) (8.573*(segmentsAcked));
int XTydNgBXOPKvgvpo = (int) (98.646*(89.022)*(7.358)*(3.527)*(segmentsAcked)*(63.874)*(43.932));
ReduceCwnd (tcb);
XTydNgBXOPKvgvpo = (int) (78.464/0.1);
