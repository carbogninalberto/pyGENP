tcb->m_ssThresh = (int) (4.142*(tcb->m_ssThresh)*(tcb->m_cWnd)*(tcb->m_cWnd)*(14.551)*(82.354)*(segmentsAcked)*(36.303));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (79.262*(8.065)*(25.337)*(12.391)*(81.128)*(51.922)*(64.495)*(36.267)*(4.14));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
