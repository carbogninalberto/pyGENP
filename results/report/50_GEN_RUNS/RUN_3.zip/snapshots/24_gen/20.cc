tcb->m_ssThresh = (int) ((tcb->m_ssThresh*(15.747)*(47.883))/99.083);
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(81.029)-(71.858)-(16.333)-(49.124)-(9.884)-(tcb->m_cWnd)-(35.01));
	tcb->m_ssThresh = (int) (11.36*(67.032)*(34.521)*(43.835)*(41.27)*(80.633)*(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (81.573*(96.319)*(11.488)*(3.688));

}
tcb->m_segmentSize = (int) (89.627+(58.083));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/24.289);
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (0.753-(tcb->m_cWnd)-(tcb->m_ssThresh)-(35.261));

} else {
	tcb->m_segmentSize = (int) (16.089*(tcb->m_cWnd));

}
int AWnZHBppQMevuHSu = (int) (54.349*(72.499)*(47.61));
