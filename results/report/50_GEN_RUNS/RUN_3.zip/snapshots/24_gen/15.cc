if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (15.054/6.542);
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(21.647)*(2.318)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(76.113)*(78.048));

} else {
	tcb->m_cWnd = (int) (5.188*(segmentsAcked)*(76.769)*(tcb->m_ssThresh)*(47.035)*(7.862)*(44.68));
	tcb->m_ssThresh = (int) (36.294-(16.14)-(20.408));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
float PsjPLOWMuhcPdtqR = (float) (12.158+(24.84)+(55.869)+(40.544)+(95.083)+(tcb->m_ssThresh)+(84.392));
if (segmentsAcked == PsjPLOWMuhcPdtqR) {
	PsjPLOWMuhcPdtqR = (float) (53.26+(96.908)+(tcb->m_ssThresh)+(44.548)+(43.536));
	tcb->m_ssThresh = (int) (90.046+(39.268)+(PsjPLOWMuhcPdtqR)+(PsjPLOWMuhcPdtqR)+(23.604)+(segmentsAcked));

} else {
	PsjPLOWMuhcPdtqR = (float) (62.865*(86.257)*(4.665)*(40.798)*(50.185));

}
tcb->m_ssThresh = (int) (96.948+(PsjPLOWMuhcPdtqR)+(73.179)+(PsjPLOWMuhcPdtqR)+(55.933));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
