ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (4.265+(segmentsAcked));
tcb->m_segmentSize = (int) (46.096-(63.654)-(36.317)-(71.625)-(tcb->m_ssThresh)-(47.247));
tcb->m_ssThresh = (int) (0.1/0.1);
tcb->m_cWnd = (int) (14.902+(tcb->m_segmentSize)+(19.684)+(39.128)+(80.04)+(59.443)+(tcb->m_segmentSize)+(71.779));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (76.425+(26.28)+(48.306));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(27.36)*(58.536)*(30.624)*(92.217)*(63.807));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (44.026/64.792);
