tcb->m_cWnd = (int) (35.504*(21.186)*(-87.934)*(-28.833)*(-65.786)*(-48.025)*(-1.504));
int TJdzmKaqGxskfIPT = (int) 94.456;
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-42.968*(-58.435)*(59.588)*(-25.909)*(-50.226)*(62.085)*(-35.832)*(-27.275)*(29.237));
segmentsAcked = (int) (-22.654-(-64.744)-(44.253)-(-95.266)-(-35.994)-(7.207)-(15.928)-(-89.294));
TJdzmKaqGxskfIPT = (int) (88.759*(-26.644)*(-89.727));
segmentsAcked = SlowStart (tcb, segmentsAcked);
