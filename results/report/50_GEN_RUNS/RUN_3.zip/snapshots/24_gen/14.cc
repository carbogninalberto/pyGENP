tcb->m_segmentSize = (int) (tcb->m_segmentSize*(25.647)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(98.384));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (60.486*(45.668)*(26.713)*(tcb->m_segmentSize)*(30.363));
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (7.543-(52.708)-(45.788));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (31.711-(3.904));
	ReduceCwnd (tcb);

}
