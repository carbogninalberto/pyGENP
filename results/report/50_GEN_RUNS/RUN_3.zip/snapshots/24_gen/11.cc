int TJdzmKaqGxskfIPT = (int) 1.819;
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (90.317*(-30.284)*(-51.41)*(79.277)*(-14.22)*(75.262)*(-7.653)*(89.545)*(-41.394));
TJdzmKaqGxskfIPT = (int) (-24.795*(8.502)*(-31.977));
segmentsAcked = (int) (51.163-(-82.801)-(-51.489)-(-86.175)-(38.249)-(-60.414)-(68.768)-(-20.281));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TJdzmKaqGxskfIPT = (int) (-56.719*(-0.927)*(-99.435));
