CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_cWnd = (int) ((0.451*(19.346)*(74.567)*(21.048)*(79.544))/0.1);
	segmentsAcked = (int) (tcb->m_cWnd-(48.28)-(35.697)-(tcb->m_cWnd)-(-6.944)-(81.057)-(tcb->m_cWnd));
	segmentsAcked = (int) (0.1/37.598);

} else {
	tcb->m_cWnd = (int) (15.942*(93.654)*(-1.382)*(45.332)*(66.323)*(tcb->m_segmentSize)*(28.205)*(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-63.725*(-34.709)*(-6.74)*(-90.729)*(42.015)*(-4.555));
