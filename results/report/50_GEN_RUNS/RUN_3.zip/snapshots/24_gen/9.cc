tcb->m_segmentSize = (int) (-26.413/-52.594);
