int PfIvXxsiCaFshgGl = (int) (97.888+(29.684)+(43.693)+(14.747)+(81.405)+(tcb->m_segmentSize));
PfIvXxsiCaFshgGl = (int) (tcb->m_segmentSize*(38.713)*(83.168)*(tcb->m_ssThresh)*(66.402));
if (segmentsAcked >= tcb->m_segmentSize) {
	segmentsAcked = (int) (6.272-(66.876)-(64.163));
	segmentsAcked = (int) (0.1/41.983);

} else {
	segmentsAcked = (int) (71.95+(tcb->m_cWnd)+(tcb->m_ssThresh)+(35.378)+(64.39));
	tcb->m_cWnd = (int) (50.064-(31.082)-(50.226)-(9.084)-(98.958)-(79.434));

}
if (segmentsAcked == segmentsAcked) {
	tcb->m_segmentSize = (int) (49.356*(9.187)*(30.662)*(PfIvXxsiCaFshgGl)*(70.973)*(79.87)*(segmentsAcked));
	PfIvXxsiCaFshgGl = (int) (70.95+(60.903)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(20.189));

} else {
	tcb->m_segmentSize = (int) (2.984*(6.788));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	PfIvXxsiCaFshgGl = (int) (66.802/(18.041-(49.951)));
	tcb->m_cWnd = (int) (11.687*(0.181)*(23.984)*(89.336));
	PfIvXxsiCaFshgGl = (int) (31.824-(93.532)-(69.386)-(68.745)-(31.291)-(55.497)-(63.673)-(tcb->m_segmentSize)-(77.051));

} else {
	PfIvXxsiCaFshgGl = (int) (((77.688)+(77.65)+(0.1)+(0.1)+(0.1)+(57.893))/((0.1)+(72.007)));
	tcb->m_ssThresh = (int) (10.695+(PfIvXxsiCaFshgGl)+(41.606)+(16.097));
	tcb->m_ssThresh = (int) (79.833*(94.917)*(96.187)*(62.794)*(PfIvXxsiCaFshgGl)*(18.822)*(42.292)*(segmentsAcked)*(18.722));

}
ReduceCwnd (tcb);
if (PfIvXxsiCaFshgGl > segmentsAcked) {
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(67.497)-(92.513)-(80.133));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (52.788*(51.775)*(12.677)*(8.651)*(72.62)*(93.227));
	PfIvXxsiCaFshgGl = (int) (((0.1)+(0.1)+((31.246+(48.58)))+(69.666))/((0.1)+(0.1)+(16.658)));

}
