if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (5.909-(23.259)-(11.806)-(9.928)-(61.856)-(2.405)-(45.408)-(segmentsAcked)-(52.109));

} else {
	tcb->m_cWnd = (int) (14.318+(55.476)+(tcb->m_ssThresh)+(89.684));

}
tcb->m_ssThresh = (int) (46.418/0.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_ssThresh) {
	segmentsAcked = (int) (21.489*(tcb->m_cWnd)*(76.004)*(14.986));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (34.649+(81.705)+(11.927)+(36.858)+(68.948)+(97.916));

} else {
	segmentsAcked = (int) (((58.629)+(12.041)+(71.488)+(41.611))/((41.929)+(0.1)+(0.1)));

}
int sLnzXRJocCiaGFYP = (int) (39.878-(tcb->m_segmentSize)-(21.427)-(tcb->m_ssThresh)-(19.037));
ReduceCwnd (tcb);
