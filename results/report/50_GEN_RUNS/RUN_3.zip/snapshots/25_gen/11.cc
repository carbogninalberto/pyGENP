segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((50.99*(7.633))/0.1);
tcb->m_ssThresh = (int) (50.813-(3.411)-(54.235)-(tcb->m_cWnd));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (28.691-(83.86));
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (44.639+(53.361)+(segmentsAcked)+(39.831)+(78.656)+(52.836)+(36.273)+(segmentsAcked)+(70.456));
	tcb->m_ssThresh = (int) (95.848+(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (62.813-(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (50.084+(9.062)+(0.865)+(43.924)+(tcb->m_cWnd)+(36.123)+(19.466));
	segmentsAcked = (int) (19.273-(56.864)-(57.747)-(tcb->m_cWnd)-(96.07)-(48.552)-(71.473));

}
