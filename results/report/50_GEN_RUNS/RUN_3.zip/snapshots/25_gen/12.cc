segmentsAcked = (int) (((0.1)+(38.136)+(0.1)+(0.1)+(0.1)+(10.711))/((0.1)+(30.321)));
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (11.609-(29.766)-(76.526)-(66.122)-(tcb->m_ssThresh)-(47.696)-(85.796)-(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (24.794*(4.865));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(83.293)*(6.391)*(86.27)*(22.992)*(39.205)*(16.922)*(tcb->m_cWnd));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (99.928*(88.159));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	segmentsAcked = (int) (segmentsAcked+(tcb->m_ssThresh)+(98.369)+(40.872)+(78.869)+(3.768));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (40.342+(54.46)+(81.561)+(23.355)+(88.313)+(73.214)+(1.57));

} else {
	segmentsAcked = (int) (7.022+(52.687));
	segmentsAcked = (int) (86.638+(tcb->m_cWnd)+(90.569)+(1.915)+(78.349)+(80.092)+(93.187));
	tcb->m_cWnd = (int) (34.164+(17.416)+(72.817)+(tcb->m_ssThresh)+(42.138));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (33.532-(62.832)-(49.858)-(25.197)-(72.497)-(78.589));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (46.312+(tcb->m_cWnd)+(46.47)+(12.404));

}
if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) ((tcb->m_ssThresh*(21.37)*(6.248)*(19.448))/0.1);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (54.101*(3.877)*(67.708)*(73.141)*(22.29)*(2.7)*(44.877)*(81.894)*(95.28));
	ReduceCwnd (tcb);

}
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (68.82-(68.868)-(88.249));

} else {
	tcb->m_ssThresh = (int) (4.561+(24.185)+(47.335)+(66.383)+(tcb->m_ssThresh));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(tcb->m_segmentSize)*(37.048)*(47.127)*(46.386)*(37.845)*(13.714)*(tcb->m_cWnd));
	tcb->m_cWnd = (int) (3.031-(2.984)-(19.664)-(95.037)-(42.992));
	tcb->m_ssThresh = (int) (64.9+(41.274)+(33.07)+(29.674)+(segmentsAcked)+(94.941)+(18.625)+(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (89.465-(1.21)-(47.875)-(69.168));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (0.1/3.613);

}
