CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (45.738-(95.597));
tcb->m_ssThresh = (int) (tcb->m_cWnd*(87.168)*(18.196)*(27.785)*(tcb->m_cWnd)*(26.207)*(73.751));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (77.958-(89.502)-(88.479)-(9.586)-(15.997)-(93.64));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(87.785)-(64.682));
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
