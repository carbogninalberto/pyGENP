if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (62.524+(82.727)+(53.08)+(77.7)+(65.063)+(98.751)+(18.507));
	tcb->m_ssThresh = (int) (segmentsAcked+(42.185)+(41.54)+(74.04));

} else {
	tcb->m_cWnd = (int) (((36.047)+(87.352)+(36.362)+((11.467+(82.529)+(36.659)+(13.394)+(94.629)+(98.563)+(50.411)))+(45.71)+(20.812)+((tcb->m_cWnd*(50.997)*(tcb->m_segmentSize)*(91.198)*(88.154)*(36.576)))+(0.1))/((54.912)));
	tcb->m_ssThresh = (int) (46.69*(16.334)*(61.776)*(38.642));
	segmentsAcked = (int) (68.901*(1.389));

}
if (segmentsAcked == tcb->m_ssThresh) {
	segmentsAcked = (int) (90.972-(75.003));
	tcb->m_segmentSize = (int) (41.342*(71.62)*(47.778)*(25.253)*(30.196)*(1.344)*(63.561));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((50.299)+(0.1)+(0.1)+(0.1)+((19.833-(63.509)-(17.237)-(tcb->m_cWnd)))+(0.1))/((42.495)+(0.1)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (tcb->m_cWnd-(3.063)-(93.095)-(10.285)-(22.103)-(64.385)-(tcb->m_ssThresh)-(33.173));
tcb->m_ssThresh = (int) (0.1/0.1);
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (54.576+(segmentsAcked)+(67.026)+(53.028)+(81.051)+(8.458)+(tcb->m_cWnd)+(7.497));
	tcb->m_cWnd = (int) (33.395-(85.718)-(41.224)-(95.167)-(47.074)-(94.501));

} else {
	tcb->m_ssThresh = (int) (25.188*(34.744)*(49.308)*(0.171));

}
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (43.528-(11.474)-(25.076));

} else {
	tcb->m_segmentSize = (int) (9.128-(93.014)-(7.288)-(14.799)-(68.557));

}
