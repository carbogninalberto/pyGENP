segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-90.32-(-66.896)-(-2.282)-(-8.935)-(-59.247)-(9.895)-(-62.621)-(-53.416)-(27.896));
tcb->m_cWnd = (int) (-15.476+(67.876)+(23.561)+(12.509));
segmentsAcked = (int) (87.83+(97.66)+(-3.926)+(-0.148)+(62.467)+(-93.632));
