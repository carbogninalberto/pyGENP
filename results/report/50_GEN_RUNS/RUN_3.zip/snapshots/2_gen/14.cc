float AvUCGABCjhfUTABA = (float) (-76.473+(-55.767)+(56.011)+(26.182));
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_segmentSize = (int) (47.383*(91.548)*(28.943)*(6.774));
	AvUCGABCjhfUTABA = (float) ((((AvUCGABCjhfUTABA-(92.986)-(0.516)-(78.509)-(25.996)-(11.612)))+(40.678)+(0.1)+(29.948))/((0.1)+(0.1)+(49.01)+(30.567)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (1.099*(68.503)*(segmentsAcked)*(44.177)*(96.026)*(30.884)*(0.31)*(4.74)*(43.86));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (56.954+(36.788)+(-65.687)+(54.138)+(54.514)+(7.365)+(80.864));
tcb->m_cWnd = (int) (18.596+(4.362)+(24.192)+(-80.998)+(67.415)+(91.993)+(86.008)+(-31.744));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
