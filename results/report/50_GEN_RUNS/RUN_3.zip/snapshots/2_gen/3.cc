float TNCZKrbyhhtPgmWz = (float) (-26.485-(25.031)-(-50.219)-(-56.679)-(-86.715)-(-17.977)-(58.299));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TNCZKrbyhhtPgmWz = (float) (-33.622-(-9.446)-(-31.42)-(-41.907)-(67.629)-(40.721));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
