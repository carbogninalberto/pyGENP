int wsEqYYRlDtvysJKq = (int) (47.483-(0.773)-(83.478));
int OZNENSRNvjNbiIEA = (int) (63.029-(-62.685)-(70.637)-(-56.256)-(25.761));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
