float AvUCGABCjhfUTABA = (float) (-65.986+(42.155)+(-13.9)+(-62.255));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-70.021+(17.351)+(97.573)+(83.608)+(-28.137)+(-67.014)+(87.946));
tcb->m_cWnd = (int) (-78.903+(-21.225)+(78.063)+(85.681)+(15.782)+(50.614)+(-17.716)+(22.126));
ReduceCwnd (tcb);
