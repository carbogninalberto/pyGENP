int wsEqYYRlDtvysJKq = (int) (61.662-(-63.554)-(68.396));
int OZNENSRNvjNbiIEA = (int) (-36.474-(72.498)-(-85.144)-(-28.493)-(-44.711));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
