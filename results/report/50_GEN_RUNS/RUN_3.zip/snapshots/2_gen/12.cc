int nrVhWhbKfVNjmpHi = (int) 67.706;
float wwaSHDKnsFmpoAvZ = (float) 73.97;
