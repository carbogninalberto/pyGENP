ReduceCwnd (tcb);
int eGOcTPCqCBWTmrip = (int) 31.065;
ReduceCwnd (tcb);
if (eGOcTPCqCBWTmrip < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (82.968*(tcb->m_cWnd)*(35.885));
	tcb->m_segmentSize = (int) (31.318-(0.889)-(40.485)-(56.031)-(77.924));

} else {
	tcb->m_segmentSize = (int) (37.358*(39.445)*(50.221)*(61.765)*(48.145)*(57.5)*(9.055)*(72.271)*(tcb->m_segmentSize));
	segmentsAcked = (int) (segmentsAcked+(eGOcTPCqCBWTmrip)+(91.358));

}
