int GAKpOYfyyDxQBRkl = (int) (84.355+(-99.77)+(-4.308)+(-80.71));
if (GAKpOYfyyDxQBRkl <= tcb->m_segmentSize) {
	GAKpOYfyyDxQBRkl = (int) (68.25*(48.604)*(tcb->m_segmentSize)*(69.708)*(18.047)*(81.289));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (GAKpOYfyyDxQBRkl*(83.22)*(13.847)*(tcb->m_segmentSize)*(95.89));

} else {
	GAKpOYfyyDxQBRkl = (int) (69.274/0.1);
	segmentsAcked = (int) (40.711-(37.684)-(78.503));

}
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (72.341+(tcb->m_cWnd)+(9.337)+(90.863)+(97.669)+(tcb->m_segmentSize)+(69.864)+(41.278)+(68.102));
	segmentsAcked = (int) (tcb->m_cWnd+(59.946)+(37.402)+(76.118)+(40.707));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (41.978+(tcb->m_cWnd));
	tcb->m_cWnd = (int) (segmentsAcked+(52.825)+(58.194)+(11.783)+(segmentsAcked)+(77.952)+(55.215)+(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (45.94-(69.696)-(-64.899)-(-23.424)-(29.748)-(-38.343)-(-96.744)-(14.285)-(-81.401));
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((20.686)+(73.893)+(0.1)+(0.1)+((83.453*(20.776)*(70.884)*(tcb->m_segmentSize)*(48.8)*(87.359)*(segmentsAcked)*(7.5)))+((93.251*(18.17)*(46.288)*(70.282)*(96.331)))+(0.1)+(95.532))/((35.744)));
	segmentsAcked = (int) (((0.1)+(0.1)+(5.984)+(0.1))/((0.1)+(6.68)+(32.344)+(90.875)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (21.106-(35.9)-(66.471)-(96.496)-(48.494)-(83.142)-(45.729));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((20.686)+(73.893)+(0.1)+(0.1)+((83.453*(20.776)*(70.884)*(tcb->m_segmentSize)*(48.8)*(87.359)*(segmentsAcked)*(7.5)))+((93.251*(18.17)*(46.288)*(70.282)*(96.331)))+(0.1)+(95.532))/((35.744)));
	segmentsAcked = (int) (((0.1)+(0.1)+(5.984)+(0.1))/((0.1)+(6.68)+(32.344)+(90.875)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (21.106-(35.9)-(66.471)-(96.496)-(48.494)-(83.142)-(45.729));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (-51.023-(-81.747)-(-18.661)-(-0.684)-(-22.377)-(-86.748)-(-55.128)-(-38.412)-(62.423));
segmentsAcked = (int) (66.14-(-24.234)-(-68.47)-(-92.551)-(5.648)-(-47.453)-(68.056)-(20.859)-(-7.865));
if (GAKpOYfyyDxQBRkl >= GAKpOYfyyDxQBRkl) {
	segmentsAcked = (int) (20.612*(12.041)*(91.346)*(25.771)*(1.692));
	tcb->m_segmentSize = (int) (-96.848-(61.411)-(93.979)-(tcb->m_segmentSize)-(60.427)-(segmentsAcked)-(67.748)-(81.755)-(28.218));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (4.628-(99.143)-(56.4)-(42.811)-(71.446)-(63.409)-(tcb->m_segmentSize)-(46.52));
	tcb->m_cWnd = (int) (1.552+(38.765)+(27.684));

}
if (GAKpOYfyyDxQBRkl >= GAKpOYfyyDxQBRkl) {
	segmentsAcked = (int) (20.612*(12.041)*(91.346)*(25.771)*(1.692));
	tcb->m_segmentSize = (int) (-2.761-(61.411)-(93.979)-(tcb->m_segmentSize)-(60.427)-(segmentsAcked)-(67.748)-(81.755)-(28.218));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (4.628-(99.143)-(56.4)-(42.811)-(71.446)-(63.409)-(tcb->m_segmentSize)-(46.52));
	tcb->m_cWnd = (int) (1.552+(38.765)+(27.684));

}
