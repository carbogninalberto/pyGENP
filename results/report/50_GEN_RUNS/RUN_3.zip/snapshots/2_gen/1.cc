int GAKpOYfyyDxQBRkl = (int) (-75.643+(42.472)+(87.602)+(3.002));
segmentsAcked = (int) (-52.295*(-67.174)*(37.64));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (41.978+(tcb->m_cWnd));
	tcb->m_cWnd = (int) (segmentsAcked+(52.825)+(58.194)+(11.783)+(segmentsAcked)+(77.952)+(55.215)+(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (72.341+(tcb->m_cWnd)+(9.337)+(90.863)+(97.669)+(tcb->m_segmentSize)+(69.864)+(41.278)+(68.102));
	segmentsAcked = (int) (tcb->m_cWnd+(59.946)+(37.402)+(76.118)+(40.707));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (33.671-(21.471)-(10.503)-(18.108)-(-25.1)-(-9.802)-(70.954)-(-98.425)-(-18.694));
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((20.686)+(73.893)+(0.1)+(0.1)+((83.453*(20.776)*(70.884)*(tcb->m_segmentSize)*(48.8)*(87.359)*(segmentsAcked)*(7.5)))+((93.251*(18.17)*(46.288)*(70.282)*(96.331)))+(0.1)+(95.532))/((35.744)));
	segmentsAcked = (int) (((0.1)+(0.1)+(5.984)+(0.1))/((0.1)+(6.68)+(32.344)+(90.875)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (21.106-(35.9)-(66.471)-(96.496)-(48.494)-(83.142)-(45.729));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (-53.281-(-34.973)-(51.693)-(-27.188)-(44.237)-(51.042)-(39.511)-(-28.493)-(58.999));
if (GAKpOYfyyDxQBRkl >= GAKpOYfyyDxQBRkl) {
	segmentsAcked = (int) (20.612*(12.041)*(91.346)*(25.771)*(1.692));
	tcb->m_segmentSize = (int) (-0.301-(61.411)-(93.979)-(tcb->m_segmentSize)-(60.427)-(segmentsAcked)-(67.748)-(81.755)-(28.218));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (4.628-(99.143)-(56.4)-(42.811)-(71.446)-(63.409)-(tcb->m_segmentSize)-(46.52));
	tcb->m_cWnd = (int) (1.552+(38.765)+(27.684));

}
