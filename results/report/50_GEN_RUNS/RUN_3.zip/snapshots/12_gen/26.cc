CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (18.882-(61.576)-(tcb->m_cWnd)-(51.354)-(91.645)-(33.242));
tcb->m_segmentSize = (int) (11.971-(30.661)-(28.69)-(67.2)-(25.842)-(48.006));
ReduceCwnd (tcb);
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (31.503*(49.69)*(42.609));
	tcb->m_cWnd = (int) (14.417-(23.02)-(94.615)-(tcb->m_cWnd)-(28.632)-(58.592));
	tcb->m_segmentSize = (int) (24.482-(69.007)-(44.672)-(38.394)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(29.608));

} else {
	tcb->m_cWnd = (int) (3.132+(16.551)+(16.896)+(tcb->m_segmentSize)+(75.408)+(94.831)+(24.649)+(86.81)+(71.723));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (tcb->m_ssThresh-(29.314)-(76.509)-(72.256)-(83.129)-(70.684)-(18.151)-(62.145)-(3.077));
tcb->m_cWnd = (int) (33.203*(50.749)*(52.615)*(tcb->m_cWnd));
