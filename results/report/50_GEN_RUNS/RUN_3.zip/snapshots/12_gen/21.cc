if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/60.237);
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(76.384))/((9.086)+(0.1)+(0.1)+(68.75)));

} else {
	segmentsAcked = (int) (65.71*(43.034)*(0.479)*(segmentsAcked));
	segmentsAcked = (int) (tcb->m_ssThresh*(28.316)*(tcb->m_segmentSize)*(43.738)*(2.855)*(44.429)*(tcb->m_segmentSize)*(82.942)*(87.455));

}
int ObrHxCxxfpfHoThy = (int) (84.235*(38.767)*(88.978)*(88.868)*(82.548)*(segmentsAcked)*(78.283)*(22.614)*(68.608));
if (tcb->m_ssThresh >= ObrHxCxxfpfHoThy) {
	segmentsAcked = (int) (ObrHxCxxfpfHoThy+(tcb->m_segmentSize)+(28.264)+(5.617));

} else {
	segmentsAcked = (int) (9.709+(90.651)+(43.211)+(82.872)+(tcb->m_ssThresh)+(46.218)+(14.759));
	tcb->m_segmentSize = (int) ((0.02-(85.554))/89.222);
	tcb->m_ssThresh = (int) (81.341+(66.368)+(16.481)+(55.305)+(77.451));

}
if (ObrHxCxxfpfHoThy == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/91.325);
	tcb->m_ssThresh = (int) (88.302/0.1);
	tcb->m_cWnd = (int) (85.869*(18.251)*(97.643)*(82.034)*(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (((0.1)+(94.354)+(0.1)+(75.196))/((48.001)+(23.726)+(0.1)+(48.995)+(88.986)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (ObrHxCxxfpfHoThy != ObrHxCxxfpfHoThy) {
	segmentsAcked = (int) (((0.1)+(0.1)+((29.651-(74.48)-(60.003)-(32.115)-(71.564)-(85.557)))+(87.117))/((0.1)+(82.251)));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (39.902+(38.002)+(1.895));

} else {
	segmentsAcked = (int) (91.606-(19.109)-(tcb->m_cWnd)-(97.693));

}
segmentsAcked = (int) (ObrHxCxxfpfHoThy-(68.88)-(53.938)-(6.091)-(35.35));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (88.201-(66.914)-(segmentsAcked)-(tcb->m_segmentSize));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (73.364+(74.064));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (99.031-(16.152)-(53.521)-(2.87)-(38.176)-(99.055)-(90.969));

} else {
	tcb->m_segmentSize = (int) (ObrHxCxxfpfHoThy-(48.528));
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(49.521)+(95.859)+(27.783))/((16.865)));
	ReduceCwnd (tcb);

}
