float tzgtySTdvBkCJMJd = (float) (11.864/52.518);
tzgtySTdvBkCJMJd = (float) (65.272*(2.474)*(-99.821));
if (tzgtySTdvBkCJMJd == tcb->m_segmentSize) {
	tzgtySTdvBkCJMJd = (float) (tcb->m_segmentSize-(tcb->m_cWnd)-(75.846)-(4.772)-(45.424)-(4.141)-(49.279)-(32.684));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (19.456-(44.679)-(1.981)-(71.749)-(tcb->m_cWnd)-(-24.306)-(36.415));

} else {
	tzgtySTdvBkCJMJd = (float) (tzgtySTdvBkCJMJd*(24.694)*(24.604)*(98.295)*(70.271));

}
