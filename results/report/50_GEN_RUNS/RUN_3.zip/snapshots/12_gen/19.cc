if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_cWnd = (int) (21.648-(16.813)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(91.885));

} else {
	tcb->m_cWnd = (int) (53.632+(segmentsAcked)+(16.001)+(96.439)+(12.735)+(tcb->m_ssThresh)+(12.313)+(tcb->m_ssThresh)+(87.367));
	tcb->m_cWnd = (int) (32.318*(52.873)*(12.504)*(48.504)*(83.574)*(18.659)*(27.667));
	ReduceCwnd (tcb);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (63.389-(65.943)-(6.695)-(52.73)-(20.838)-(tcb->m_segmentSize)-(81.432));
ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) (65.905+(81.484)+(39.285)+(85.722));
	tcb->m_cWnd = (int) (96.469-(79.765)-(75.38)-(0.865)-(18.082)-(27.917));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (19.503+(30.45)+(segmentsAcked)+(73.288));
	segmentsAcked = (int) (41.33+(8.169)+(78.689)+(91.645)+(80.426));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
