tcb->m_cWnd = (int) (18.048+(28.252)+(tcb->m_ssThresh));
tcb->m_segmentSize = (int) (18.66*(65.398)*(14.814)*(28.534)*(33.03));
int bnMfXHWtHgtMSYOh = (int) (0.1/0.1);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (bnMfXHWtHgtMSYOh-(14.515)-(55.537)-(17.598)-(tcb->m_ssThresh)-(78.89)-(segmentsAcked));
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) ((31.332*(57.387)*(57.447)*(30.269)*(87.221))/90.295);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(81.152)+(26.001)+(27.881)+(15.324)+(8.864)+(47.293));
	tcb->m_cWnd = (int) (70.032*(7.885)*(46.023)*(67.119)*(tcb->m_ssThresh)*(60.87)*(99.115)*(tcb->m_cWnd));

}
