if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (0.1/(segmentsAcked*(tcb->m_segmentSize)*(87.92)*(11.48)*(85.767)*(tcb->m_segmentSize)*(28.533)*(62.899)*(15.603)));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh+(79.214)+(28.336)+(50.215)+(59.046));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (85.135+(89.514)+(16.352)+(75.19)+(7.221)+(73.928)+(75.11));
tcb->m_segmentSize = (int) (0.1/83.645);
CongestionAvoidance (tcb, segmentsAcked);
float OvPcKWbwEwssRtCq = (float) (49.6+(95.216)+(24.421));
OvPcKWbwEwssRtCq = (float) (tcb->m_segmentSize-(50.349)-(35.522));
segmentsAcked = SlowStart (tcb, segmentsAcked);
