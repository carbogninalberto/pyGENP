tcb->m_cWnd = (int) (47.423-(44.554));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-43.821*(-45.361)*(-14.904)*(34.281)*(37.33)*(-72.98));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-61.379*(-93.358)*(-16.891)*(-23.046)*(-68.601)*(-47.583));
