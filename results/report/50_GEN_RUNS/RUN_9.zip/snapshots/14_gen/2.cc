int ZfuazjNIPkdgJpzr = (int) (85.96+(-30.109)+(-13.103)+(52.239)+(13.584)+(-38.772)+(63.46));
ZfuazjNIPkdgJpzr = (int) (-28.658+(-67.393)+(35.372)+(-49.079)+(68.62));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
