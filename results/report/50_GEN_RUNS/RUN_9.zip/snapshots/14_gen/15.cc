ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (69.345*(94.264)*(17.481)*(23.584)*(39.502)*(74.495)*(tcb->m_ssThresh)*(80.596)*(51.559));
float wjpkTyolykfIYutE = (float) (tcb->m_cWnd-(54.268));
float fNFINFmXYAfTZuot = (float) (5.867*(11.281)*(wjpkTyolykfIYutE)*(tcb->m_cWnd)*(30.053)*(52.146)*(wjpkTyolykfIYutE)*(37.169));
float hXqDqgHFaqWwyobq = (float) (59.532+(50.769)+(63.254)+(88.913));
tcb->m_ssThresh = (int) (41.611*(72.817)*(fNFINFmXYAfTZuot)*(77.306));
