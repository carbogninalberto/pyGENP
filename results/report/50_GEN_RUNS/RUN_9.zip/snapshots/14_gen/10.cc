float uFodLbEcTPIPbMKw = (float) 9.515;
