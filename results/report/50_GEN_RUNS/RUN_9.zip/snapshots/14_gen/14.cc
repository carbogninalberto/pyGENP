float EzHaBOyCgmEBuIrt = (float) (64.32-(-13.694)-(76.397));
int hvzvYSQKUPfxHyqG = (int) (-22.388*(42.862));
int TPGjlQxnUDkDKYbl = (int) 88.396;
tcb->m_cWnd = (int) (22.585+(26.596)+(-71.042)+(11.742)+(-9.843)+(-50.257));
segmentsAcked = (int) (-62.626+(-64.853)+(2.15)+(-88.892)+(-58.509)+(-78.932));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-3.933+(65.707)+(61.135)+(-59.029));
