int qenDbtVuZBtTrDBV = (int) (-32.689+(-17.293)+(10.341)+(-36.918));
tcb->m_cWnd = (int) (28.061+(82.49)+(-71.479)+(-7.343)+(30.312)+(-64.735)+(9.142)+(-53.069));
if (tcb->m_cWnd < qenDbtVuZBtTrDBV) {
	qenDbtVuZBtTrDBV = (int) (((0.1)+(27.223)+(0.1)+(0.1))/((0.1)));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	qenDbtVuZBtTrDBV = (int) (tcb->m_segmentSize*(50.613)*(-38.412)*(15.899)*(segmentsAcked));
	qenDbtVuZBtTrDBV = (int) (52.401*(29.751)*(68.012));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < qenDbtVuZBtTrDBV) {
	qenDbtVuZBtTrDBV = (int) (tcb->m_segmentSize*(50.613)*(-83.173)*(15.899)*(segmentsAcked));
	qenDbtVuZBtTrDBV = (int) (52.401*(29.751)*(68.012));

} else {
	qenDbtVuZBtTrDBV = (int) (((0.1)+(27.223)+(0.1)+(0.1))/((0.1)));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

}
