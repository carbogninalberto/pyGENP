if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	segmentsAcked = (int) ((75.189*(64.852)*(18.522)*(52.37)*(33.398)*(tcb->m_cWnd)*(77.822)*(tcb->m_ssThresh)*(tcb->m_segmentSize))/0.1);
	tcb->m_ssThresh = (int) (63.51-(59.564));
	tcb->m_cWnd = (int) (26.201-(0.876)-(12.201)-(64.561));

} else {
	segmentsAcked = (int) (85.761*(81.342)*(17.081)*(tcb->m_segmentSize)*(32.505)*(45.824)*(0.623));
	segmentsAcked = (int) (71.275/(14.521+(94.597)+(segmentsAcked)+(35.762)+(99.804)+(tcb->m_cWnd)+(97.595)+(38.363)+(58.796)));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (15.02-(92.826)-(89.897)-(90.34));
ReduceCwnd (tcb);
segmentsAcked = (int) (64.559*(69.285)*(38.288)*(tcb->m_segmentSize)*(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
