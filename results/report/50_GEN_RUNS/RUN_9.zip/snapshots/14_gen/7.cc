float lAAPDGpIXaSjtfAq = (float) (4.828-(73.677)-(36.216)-(-27.466)-(-68.516)-(7.943));
