int qenDbtVuZBtTrDBV = (int) (-49.286+(-92.331)+(40.986)+(-59.165));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < qenDbtVuZBtTrDBV) {
	qenDbtVuZBtTrDBV = (int) (((0.1)+(27.223)+(0.1)+(0.1))/((0.1)));
	CongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	qenDbtVuZBtTrDBV = (int) (tcb->m_segmentSize*(50.613)*(85.113)*(15.899)*(segmentsAcked));
	qenDbtVuZBtTrDBV = (int) (52.401*(29.751)*(68.012));

}
