float uFodLbEcTPIPbMKw = (float) 14.788;
CongestionAvoidance (tcb, segmentsAcked);
float TXcmuvjielFyprPQ = (float) (21.252/41.864);
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (uFodLbEcTPIPbMKw-(22.731)-(uFodLbEcTPIPbMKw)-(86.459)-(14.734));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(segmentsAcked)-(18.723)-(-69.476)-(87.214)-(70.362));

}
if (tcb->m_cWnd < uFodLbEcTPIPbMKw) {
	segmentsAcked = (int) (1.22+(38.686)+(25.068)+(57.424)+(34.56));

} else {
	segmentsAcked = (int) (uFodLbEcTPIPbMKw-(-39.507)-(69.907)-(14.2)-(0.429)-(42.127)-(tcb->m_cWnd)-(65.842)-(3.053));

}
ReduceCwnd (tcb);
