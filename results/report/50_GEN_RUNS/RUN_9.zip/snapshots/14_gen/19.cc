tcb->m_segmentSize = (int) (33.454-(49.869)-(94.803));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(75.784)+(5.588)+(18.158)+(80.418));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (30.116/27.077);
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (56.866+(47.421)+(12.42)+(tcb->m_cWnd)+(3.259)+(37.861)+(71.198)+(4.073)+(78.469));

} else {
	tcb->m_cWnd = (int) (74.612-(85.865)-(11.22)-(20.582)-(tcb->m_segmentSize)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (24.721-(29.885)-(5.973));

}
