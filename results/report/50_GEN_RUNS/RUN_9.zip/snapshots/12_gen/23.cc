tcb->m_segmentSize = (int) (tcb->m_segmentSize*(66.594)*(41.99)*(58.58)*(27.926));
tcb->m_cWnd = (int) (95.861-(77.121)-(tcb->m_ssThresh)-(96.455)-(segmentsAcked)-(48.578));
segmentsAcked = (int) (59.119*(segmentsAcked)*(tcb->m_cWnd)*(30.617)*(41.674)*(segmentsAcked));
tcb->m_cWnd = (int) (((0.1)+((60.407-(tcb->m_ssThresh)-(97.541)-(tcb->m_ssThresh)-(-0.093)-(31.912)-(7.706)-(40.291)-(tcb->m_cWnd)))+(0.1)+(0.1))/((0.1)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
float dKueBDWtAxIEnPKo = (float) (tcb->m_segmentSize-(9.639));
if (dKueBDWtAxIEnPKo >= tcb->m_ssThresh) {
	dKueBDWtAxIEnPKo = (float) (85.485/87.203);
	tcb->m_ssThresh = (int) (59.323+(4.782)+(85.063)+(28.805)+(13.251)+(tcb->m_cWnd));

} else {
	dKueBDWtAxIEnPKo = (float) (46.768*(0.438)*(40.831)*(58.117)*(94.987)*(tcb->m_cWnd));

}
