float cBKYhFPFsoqlRDpO = (float) (83.606*(-78.222)*(-58.184)*(-26.121));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (33.984-(-50.435)-(-53.105)-(-28.573)-(-24.298));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-65.575-(-96.424)-(94.895)-(54.622)-(-85.324)-(-47.207));
