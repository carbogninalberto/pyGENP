float uFodLbEcTPIPbMKw = (float) (-61.561/(74.727*(-29.184)*(-57.534)*(-71.592)*(-93.328)));
if (tcb->m_segmentSize <= uFodLbEcTPIPbMKw) {
	uFodLbEcTPIPbMKw = (float) ((((80.19+(46.425)+(20.365)+(segmentsAcked)+(35.339)+(21.632)))+(0.1)+(0.1)+(33.762)+(0.1)+(8.964))/((0.1)));

} else {
	uFodLbEcTPIPbMKw = (float) (58.584+(43.419)+(41.682)+(50.618)+(57.893)+(59.591)+(57.526));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (0.1/68.622);

}
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (uFodLbEcTPIPbMKw-(22.731)-(uFodLbEcTPIPbMKw)-(86.459)-(14.734));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(segmentsAcked)-(18.723)-(-69.476)-(87.214)-(70.362));

}
if (tcb->m_cWnd < uFodLbEcTPIPbMKw) {
	segmentsAcked = (int) (1.22+(38.686)+(25.068)+(57.424)+(34.56));

} else {
	segmentsAcked = (int) (uFodLbEcTPIPbMKw-(-39.507)-(69.907)-(14.2)-(0.429)-(42.127)-(tcb->m_cWnd)-(65.842)-(3.053));

}
ReduceCwnd (tcb);
