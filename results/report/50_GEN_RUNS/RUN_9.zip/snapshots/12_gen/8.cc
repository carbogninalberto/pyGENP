int wvsaFsYSUQZEznfh = (int) (-10.613+(-15.226));
int xSVWJsGPlRTISkex = (int) 36.14;
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (72.016+(9.432)+(tcb->m_cWnd)+(52.056)+(87.759));

} else {
	tcb->m_cWnd = (int) (2.099*(64.404)*(27.516)*(33.925)*(24.606)*(segmentsAcked));

}
CongestionAvoidance (tcb, segmentsAcked);
