int hXqbDMfvMugmOTJa = (int) (-92.065/(-89.041+(-43.37)+(94.148)+(-39.138)+(38.792)+(-72.87)));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (1.546-(19.242)-(4.82)-(49.253)-(81.394)-(45.618)-(47.342)-(87.363));

} else {
	segmentsAcked = (int) (96.131-(3.075)-(16.638)-(88.464)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.571)-(25.867)-(14.467));
	CongestionAvoidance (tcb, segmentsAcked);

}
hXqbDMfvMugmOTJa = (int) (-30.424-(4.901)-(-35.009)-(-46.927)-(-38.363)-(-71.972));
segmentsAcked = (int) (40.653+(35.811)+(33.353)+(-60.097)+(26.138)+(80.982)+(61.857)+(54.123));
hXqbDMfvMugmOTJa = (int) (-97.453-(-26.709)-(67.585)-(25.146)-(-78.278)-(-8.585));
segmentsAcked = (int) (-73.242+(59.875)+(50.636)+(43.337)+(80.937)+(3.938)+(76.496)+(67.681));
