float AtpHjKPJnWeTmMCs = (float) (-50.187+(-48.563)+(19.379)+(-2.754)+(22.757)+(-49.712)+(21.297)+(85.576));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (33.286*(92.986)*(-50.409));
