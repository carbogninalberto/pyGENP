if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (89.632/0.1);
	segmentsAcked = (int) (57.372+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(68.407)+(26.931)+(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (74.729+(18.606)+(segmentsAcked)+(segmentsAcked)+(67.394)+(13.56)+(segmentsAcked));

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(6.744));
	tcb->m_segmentSize = (int) ((tcb->m_segmentSize-(90.909)-(77.761)-(71.682)-(tcb->m_segmentSize)-(segmentsAcked)-(tcb->m_segmentSize))/47.34);

} else {
	tcb->m_cWnd = (int) (62.05-(82.73)-(segmentsAcked)-(86.601)-(46.351)-(55.315)-(22.702)-(86.326)-(98.623));

}
segmentsAcked = (int) (71.993+(63.206)+(59.189)+(tcb->m_cWnd));
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_ssThresh = (int) (86.649-(75.829)-(6.021)-(74.414)-(69.661)-(13.214)-(44.633)-(tcb->m_segmentSize)-(1.393));
	tcb->m_cWnd = (int) (98.005*(46.331)*(26.421)*(76.478));

} else {
	tcb->m_ssThresh = (int) (61.371*(16.864)*(73.44)*(67.446)*(28.772)*(90.714));

}
if (segmentsAcked == segmentsAcked) {
	segmentsAcked = (int) (34.524/0.1);
	tcb->m_ssThresh = (int) (11.452+(2.267)+(35.199)+(62.854));

} else {
	segmentsAcked = (int) (47.858-(90.734)-(tcb->m_cWnd)-(75.539)-(tcb->m_ssThresh)-(1.649));
	tcb->m_segmentSize = (int) (51.955*(70.69)*(33.275));

}
tcb->m_segmentSize = (int) (49.037+(29.966)+(66.568)+(79.865)+(30.528)+(76.324));
