tcb->m_cWnd = (int) (31.582-(44.607));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-8.586*(-27.049)*(63.168)*(-65.897)*(92.91)*(-23.828));
