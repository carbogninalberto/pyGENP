ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (34.392-(23.477)-(63.774)-(tcb->m_cWnd)-(37.417)-(25.051)-(70.45)-(54.152));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (97.894/30.591);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
