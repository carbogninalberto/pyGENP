segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (segmentsAcked-(segmentsAcked)-(31.577)-(79.575)-(26.479)-(89.158)-(91.308)-(59.882));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (tcb->m_segmentSize-(tcb->m_ssThresh)-(22.578));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) ((69.939+(64.724)+(tcb->m_segmentSize)+(71.302)+(99.052)+(tcb->m_ssThresh))/47.72);
if (tcb->m_cWnd != tcb->m_ssThresh) {
	segmentsAcked = (int) ((((segmentsAcked*(9.712)*(tcb->m_cWnd)*(87.005)*(83.603)))+(0.1)+((49.732+(99.702)+(87.793)+(17.403)))+(74.184))/((70.293)));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (90.582+(26.835)+(73.016));

}
