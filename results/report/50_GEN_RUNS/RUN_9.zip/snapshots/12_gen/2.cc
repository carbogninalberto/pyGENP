tcb->m_cWnd = (int) (-90.009-(61.17));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (86.512*(73.202)*(29.287)*(-57.043)*(-89.169)*(-80.527));
