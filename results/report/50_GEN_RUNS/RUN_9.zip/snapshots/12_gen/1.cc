if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (1.546-(19.242)-(4.82)-(49.253)-(81.394)-(45.618)-(47.342)-(87.363));

} else {
	segmentsAcked = (int) (96.131-(3.075)-(16.638)-(88.464)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.571)-(25.867)-(14.467));
	CongestionAvoidance (tcb, segmentsAcked);

}
int hXqbDMfvMugmOTJa = (int) (31.315/(-54.518+(-76.847)+(-74.847)+(41.215)+(78.227)+(-9.29)));
hXqbDMfvMugmOTJa = (int) (-0.629-(-79.557)-(44.343)-(25.334)-(-16.856)-(-97.489));
segmentsAcked = (int) (79.428+(37.319)+(-89.182)+(31.237)+(-80.481)+(37.222)+(-53.019)+(-14.148));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (96.131-(3.075)-(16.638)-(88.464)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.571)-(25.867)-(14.467));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (1.546-(19.242)-(4.82)-(49.253)-(81.394)-(45.618)-(47.342)-(87.363));

}
hXqbDMfvMugmOTJa = (int) (34.14-(8.157)-(68.723)-(26.242)-(0.796)-(-77.421));
segmentsAcked = (int) (84.973+(-50.463)+(88.543)+(79.243)+(-36.072)+(-45.425)+(-80.551)+(-71.659));
segmentsAcked = (int) (63.032+(-54.939)+(-88.84)+(62.011)+(-32.76)+(-6.304)+(30.952)+(-93.192));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (96.131-(3.075)-(16.638)-(88.464)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.571)-(25.867)-(14.467));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (1.546-(19.242)-(4.82)-(49.253)-(81.394)-(45.618)-(47.342)-(87.363));

}
hXqbDMfvMugmOTJa = (int) (-96.07-(64.229)-(59.896)-(-37.715)-(50.315)-(-2.766));
segmentsAcked = (int) (25.371+(65.605)+(11.922)+(-36.261)+(9.794)+(31.061)+(-14.648)+(-36.603));
hXqbDMfvMugmOTJa = (int) (26.602-(1.209)-(-27.635)-(-79.766)-(38.608)-(24.837));
segmentsAcked = (int) (96.87+(67.554)+(-88.934)+(93.964)+(-5.293)+(57.407)+(56.126)+(-29.15));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (96.131-(3.075)-(16.638)-(88.464)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.571)-(25.867)-(14.467));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (1.546-(19.242)-(4.82)-(49.253)-(81.394)-(45.618)-(47.342)-(87.363));

}
hXqbDMfvMugmOTJa = (int) (-67.23-(-73.706)-(98.051)-(28.559)-(75.35)-(14.659));
segmentsAcked = (int) (-90.308+(-24.204)+(-69.204)+(54.789)+(20.831)+(36.132)+(76.659)+(11.962));
segmentsAcked = (int) (76.102+(21.357)+(-71.25)+(-55.329)+(-77.174)+(-21.761)+(-82.0)+(-94.031));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (96.131-(3.075)-(16.638)-(88.464)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.571)-(25.867)-(14.467));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (1.546-(19.242)-(4.82)-(49.253)-(81.394)-(45.618)-(47.342)-(87.363));

}
hXqbDMfvMugmOTJa = (int) (68.017-(84.412)-(90.598)-(-89.027)-(-24.625)-(-8.123));
segmentsAcked = (int) (-87.061+(-39.36)+(82.149)+(15.021)+(6.464)+(-17.644)+(84.305)+(-6.105));
