tcb->m_cWnd = (int) (83.898-(94.375));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-7.55*(75.231)*(-58.123)*(-51.203)*(-34.227)*(-5.54));
segmentsAcked = (int) (31.384*(44.565)*(99.329)*(1.04)*(78.818)*(88.295));
