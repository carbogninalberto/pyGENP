tcb->m_cWnd = (int) (42.779-(60.25));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-53.043*(-56.237)*(83.784)*(98.924)*(4.88)*(-29.094));
segmentsAcked = (int) (-5.347*(-7.941)*(-31.195)*(59.58)*(-73.814)*(84.229));
segmentsAcked = (int) (16.803*(62.462)*(-24.981)*(13.061)*(-3.425)*(86.395));
