if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (39.882+(7.619)+(29.787)+(32.847)+(16.532)+(43.052)+(5.443)+(45.716)+(67.659));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(-60.716)*(tcb->m_cWnd)*(-58.48)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(93.237));

} else {
	tcb->m_segmentSize = (int) (65.763-(24.998)-(26.183)-(7.849)-(93.681)-(23.265));
	tcb->m_cWnd = (int) (59.453-(tcb->m_segmentSize)-(10.818)-(tcb->m_segmentSize)-(72.447)-(segmentsAcked));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
