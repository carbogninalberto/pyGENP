tcb->m_cWnd = (int) (49.173-(-18.455));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (65.795*(48.115)*(22.826)*(87.215)*(73.054)*(41.486));
