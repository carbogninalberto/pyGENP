ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-77.666+(29.332)+(-58.433)+(-83.944)+(69.572));
CongestionAvoidance (tcb, segmentsAcked);
