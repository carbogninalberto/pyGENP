tcb->m_cWnd = (int) (54.376-(51.993));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-23.777*(30.316)*(-25.944)*(-48.594)*(-46.285)*(-23.83));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (44.373*(-64.749)*(9.071)*(-25.885)*(76.021)*(95.258));
