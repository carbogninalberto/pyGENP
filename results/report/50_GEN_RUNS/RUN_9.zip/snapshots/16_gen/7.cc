float nOBrIPKTBxQvgWsD = (float) (-55.575-(64.163)-(-75.704)-(10.159)-(-80.551)-(-16.693)-(96.356)-(46.239)-(-56.78));
int gskdDpCLaemyuQLj = (int) 29.004;
