int fmXHQlIpkMYPfGYt = (int) (62.453-(25.037));
if (tcb->m_cWnd > fmXHQlIpkMYPfGYt) {
	fmXHQlIpkMYPfGYt = (int) (61.499-(1.948)-(70.283)-(77.172)-(tcb->m_ssThresh)-(52.627));
	fmXHQlIpkMYPfGYt = (int) (0.1/3.882);

} else {
	fmXHQlIpkMYPfGYt = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (43.096-(98.017)-(53.331)-(16.901)-(25.244)-(46.817)-(tcb->m_segmentSize)-(fmXHQlIpkMYPfGYt)-(20.286));

}
tcb->m_ssThresh = (int) (72.941*(3.26)*(76.028));
fmXHQlIpkMYPfGYt = (int) (9.923-(79.812)-(segmentsAcked)-(8.808)-(13.182)-(34.351)-(tcb->m_ssThresh)-(22.55)-(71.933));
if (fmXHQlIpkMYPfGYt <= tcb->m_segmentSize) {
	fmXHQlIpkMYPfGYt = (int) (30.343-(tcb->m_segmentSize)-(fmXHQlIpkMYPfGYt)-(97.541)-(94.443)-(49.31)-(24.391)-(tcb->m_ssThresh)-(61.553));
	fmXHQlIpkMYPfGYt = (int) (((11.271)+(0.1)+((31.848*(tcb->m_cWnd)*(tcb->m_segmentSize)*(38.218)*(73.081)*(71.368)*(29.973)))+(0.1))/((92.08)));
	tcb->m_ssThresh = (int) (53.921*(37.761)*(tcb->m_ssThresh));

} else {
	fmXHQlIpkMYPfGYt = (int) (segmentsAcked*(66.877)*(49.297)*(91.698)*(44.65)*(25.666));

}
CongestionAvoidance (tcb, segmentsAcked);
