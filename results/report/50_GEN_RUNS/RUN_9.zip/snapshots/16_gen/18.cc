if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (0.1/28.257);
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (48.198+(20.236)+(19.369)+(47.927)+(64.793)+(30.158)+(82.862)+(97.825));

} else {
	tcb->m_ssThresh = (int) (13.964-(27.294)-(27.121)-(tcb->m_cWnd)-(9.206)-(segmentsAcked)-(segmentsAcked)-(97.513)-(3.574));

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (85.101*(86.792)*(29.761)*(92.7)*(59.949)*(28.337)*(segmentsAcked));
	segmentsAcked = (int) (18.58-(66.697)-(tcb->m_cWnd)-(54.894)-(60.214)-(39.004));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (0.1/15.801);
	tcb->m_ssThresh = (int) (96.899+(32.899)+(97.708));

}
segmentsAcked = (int) (((46.575)+(2.808)+(0.1)+(0.1)+(16.932)+(53.192)+(48.246)+(0.1))/((31.798)));
if (tcb->m_cWnd != tcb->m_ssThresh) {
	segmentsAcked = (int) (28.864/37.699);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (77.365+(35.575)+(77.147)+(76.008)+(89.975)+(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (11.463+(5.074)+(tcb->m_ssThresh)+(23.107));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (84.231-(72.968)-(53.423)-(segmentsAcked)-(71.205)-(39.605)-(48.412)-(17.55));
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (52.938+(25.441)+(9.727)+(0.399)+(60.77));

} else {
	tcb->m_ssThresh = (int) (58.267+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(18.151));
	tcb->m_ssThresh = (int) (37.148+(76.217)+(40.775)+(92.65)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(57.092));

}
