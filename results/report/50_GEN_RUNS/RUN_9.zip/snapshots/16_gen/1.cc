float wjpkTyolykfIYutE = (float) (80.404-(25.409));
segmentsAcked = (int) (((57.055)+(-17.998)+(-57.223)+(70.561)+(13.595)+(-5.96))/((-23.71)));
