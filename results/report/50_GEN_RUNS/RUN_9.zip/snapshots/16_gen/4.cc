float AqglIYBGTcjNwVBW = (float) 55.166;
int UZUGWBZjElRIfJTV = (int) 53.422;
