if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (94.915*(92.677));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (74.847*(80.809)*(47.476)*(24.114)*(38.51)*(4.3));

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
