tcb->m_cWnd = (int) (23.309-(81.527));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (-23.774*(31.707)*(35.71)*(29.958)*(-85.214)*(61.608));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-30.773*(-3.384)*(89.025)*(-21.252)*(-6.256)*(-50.339));
