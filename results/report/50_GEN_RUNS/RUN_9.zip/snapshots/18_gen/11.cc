float BhzLCDjxbrKwZzEg = (float) 57.903;
tcb->m_segmentSize = (int) (17.247-(86.039)-(17.26)-(-76.491)-(-96.805));
tcb->m_cWnd = (int) (78.463*(-20.47)*(38.672)*(56.389)*(65.654)*(-92.715)*(52.586)*(-20.845));
BhzLCDjxbrKwZzEg = (float) (-56.004/98.16);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (BhzLCDjxbrKwZzEg != tcb->m_segmentSize) {
	segmentsAcked = (int) (37.991+(79.914)+(30.876)+(BhzLCDjxbrKwZzEg)+(89.397)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (segmentsAcked*(35.107));

}
BhzLCDjxbrKwZzEg = (float) (20.048/-54.485);
