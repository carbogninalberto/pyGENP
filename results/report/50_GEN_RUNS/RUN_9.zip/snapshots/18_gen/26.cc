CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
int tkdekSKriDVjYcPJ = (int) (49.943+(28.571)+(5.434)+(tcb->m_ssThresh)+(97.471)+(tcb->m_segmentSize)+(40.645)+(74.887));
tcb->m_cWnd = (int) (tkdekSKriDVjYcPJ-(tkdekSKriDVjYcPJ)-(83.962)-(51.474)-(43.334)-(37.923)-(96.399)-(tkdekSKriDVjYcPJ));
tcb->m_segmentSize = (int) (27.368-(tcb->m_cWnd)-(segmentsAcked)-(79.609));
if (tcb->m_ssThresh == tkdekSKriDVjYcPJ) {
	tcb->m_ssThresh = (int) (96.685+(27.599));
	segmentsAcked = (int) (70.645*(54.199)*(50.576)*(93.484)*(86.034)*(31.427)*(71.299));

} else {
	tcb->m_ssThresh = (int) (48.746-(tcb->m_segmentSize)-(10.529));

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (56.799*(tcb->m_cWnd)*(43.301)*(2.741)*(tkdekSKriDVjYcPJ)*(33.798));

} else {
	tcb->m_cWnd = (int) (63.189*(tcb->m_cWnd)*(60.149)*(segmentsAcked)*(74.918)*(5.609)*(56.082)*(6.42)*(71.403));

}
int csnGxMKnWAAKuJFP = (int) (tcb->m_segmentSize*(0.315)*(tcb->m_cWnd)*(48.076)*(3.853));
