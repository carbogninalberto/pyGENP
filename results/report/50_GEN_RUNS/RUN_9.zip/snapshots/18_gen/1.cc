float qYVXqWSchzGXenSz = (float) 89.902;
if (segmentsAcked >= qYVXqWSchzGXenSz) {
	segmentsAcked = (int) (60.281/85.868);
	qYVXqWSchzGXenSz = (float) (1.61*(45.624)*(79.563));

} else {
	segmentsAcked = (int) (10.697-(60.048)-(6.064));
	tcb->m_cWnd = (int) (16.384-(56.099)-(40.144));

}
