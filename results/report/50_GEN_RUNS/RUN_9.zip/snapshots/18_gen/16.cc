TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
int psmNAdpBrxxdCmyE = (int) (1.022*(23.293));
tcb->m_segmentSize = (int) (62.405-(tcb->m_segmentSize));
if (psmNAdpBrxxdCmyE < tcb->m_segmentSize) {
	psmNAdpBrxxdCmyE = (int) (5.258/2.124);
	tcb->m_ssThresh = (int) (20.919/49.372);

} else {
	psmNAdpBrxxdCmyE = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((77.999)+(0.1)+(0.1)));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(42.849)*(27.243)*(86.098)*(tcb->m_cWnd));

}
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_ssThresh = (int) (40.483/63.339);

} else {
	tcb->m_ssThresh = (int) (26.578*(tcb->m_ssThresh)*(31.188)*(psmNAdpBrxxdCmyE)*(85.922)*(15.95)*(segmentsAcked)*(66.51)*(tcb->m_segmentSize));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (0.1/58.124);

}
int oxcbnnsQomGfpSBM = (int) (88.712*(12.66)*(31.133)*(11.002)*(69.785)*(20.33)*(49.309)*(74.355)*(25.719));
psmNAdpBrxxdCmyE = (int) (23.055+(41.561)+(75.777));
ReduceCwnd (tcb);
