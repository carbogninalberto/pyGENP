float BhzLCDjxbrKwZzEg = (float) 57.903;
tcb->m_cWnd = (int) (60.95*(-62.933)*(30.539)*(36.446)*(-3.671)*(-1.002)*(83.743)*(64.686));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (BhzLCDjxbrKwZzEg != tcb->m_segmentSize) {
	segmentsAcked = (int) (37.991+(79.914)+(30.876)+(BhzLCDjxbrKwZzEg)+(89.397)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (segmentsAcked*(35.107));

}
if (BhzLCDjxbrKwZzEg != tcb->m_segmentSize) {
	segmentsAcked = (int) (37.991+(79.914)+(30.876)+(BhzLCDjxbrKwZzEg)+(89.397)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (segmentsAcked*(35.107));

}
BhzLCDjxbrKwZzEg = (float) (69.239/53.646);
BhzLCDjxbrKwZzEg = (float) (-85.579/87.391);
