tcb->m_segmentSize = (int) (66.722-(37.696)-(tcb->m_segmentSize)-(83.915)-(7.3)-(28.769));
float VTPKJljUCOPBYBdZ = (float) (5.578+(7.545)+(30.864)+(tcb->m_cWnd)+(41.242)+(7.083));
segmentsAcked = (int) (8.267+(35.906)+(36.285));
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	segmentsAcked = (int) (41.841-(63.106)-(66.77)-(tcb->m_segmentSize)-(91.09)-(97.567)-(75.401));
	VTPKJljUCOPBYBdZ = (float) (87.221*(7.678)*(24.91)*(37.785)*(74.054)*(45.549));

} else {
	segmentsAcked = (int) (0.1/78.59);

}
if (segmentsAcked >= segmentsAcked) {
	tcb->m_ssThresh = (int) (94.956-(24.138));

} else {
	tcb->m_ssThresh = (int) (VTPKJljUCOPBYBdZ+(32.731)+(segmentsAcked));

}
float vqmZDlnmbxsqntWw = (float) (49.874-(segmentsAcked));
float PpypYBUcTggrewMa = (float) (77.16+(89.052));
ReduceCwnd (tcb);
PpypYBUcTggrewMa = (float) (tcb->m_ssThresh*(79.56)*(34.53)*(69.596)*(34.589)*(71.567)*(8.584)*(61.895)*(7.766));
