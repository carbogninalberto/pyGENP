ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (65.924-(-12.693)-(43.803)-(29.466)-(4.464)-(80.344)-(87.333)-(53.794));
	tcb->m_cWnd = (int) (10.292/0.1);

} else {
	segmentsAcked = (int) (((17.728)+(0.1)+(64.445)+(0.1)+(13.076))/((79.902)+(0.1)+(22.076)));
	segmentsAcked = (int) (43.434+(29.2)+(54.166)+(53.265)+(25.58)+(96.983));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = (int) ((53.906*(-40.057)*(20.325)*(-11.078)*(-87.847)*(-57.386)*(-98.127)*(48.718)*(tcb->m_cWnd))/-67.849);
segmentsAcked = (int) (67.188-(-74.687)-(54.557)-(98.486)-(92.656)-(20.948)-(25.776)-(83.681));
CongestionAvoidance (tcb, segmentsAcked);
