tcb->m_cWnd = (int) (-59.825-(-6.372));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (95.773*(-19.289)*(59.081)*(-4.353)*(-43.892)*(37.844));
segmentsAcked = (int) (87.545*(6.06)*(-85.637)*(-96.947)*(1.121)*(57.992));
