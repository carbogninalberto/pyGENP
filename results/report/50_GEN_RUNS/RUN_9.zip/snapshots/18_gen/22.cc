ReduceCwnd (tcb);
int tfsiyCnYWhIydFwB = (int) ((((79.935*(59.604)*(48.186)*(16.305)))+(0.1)+(33.744)+(0.1))/((51.428)));
if (tcb->m_ssThresh > tfsiyCnYWhIydFwB) {
	tfsiyCnYWhIydFwB = (int) (30.164+(19.532)+(tfsiyCnYWhIydFwB)+(47.749)+(58.241)+(5.555));
	segmentsAcked = (int) (6.997*(80.843)*(68.452)*(74.387)*(88.078)*(tfsiyCnYWhIydFwB));
	segmentsAcked = (int) (tcb->m_cWnd-(10.246)-(7.511)-(73.342)-(20.157)-(16.378)-(97.724));

} else {
	tfsiyCnYWhIydFwB = (int) (74.636/0.1);
	tcb->m_cWnd = (int) (6.171-(7.567)-(52.339)-(25.002)-(tcb->m_ssThresh));

}
if (tcb->m_cWnd != tcb->m_cWnd) {
	segmentsAcked = (int) (13.758*(16.156)*(31.181)*(58.265)*(51.213)*(37.327)*(20.301)*(32.944));

} else {
	segmentsAcked = (int) (18.896/0.1);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
