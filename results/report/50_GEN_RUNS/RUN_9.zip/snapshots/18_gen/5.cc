float BhzLCDjxbrKwZzEg = (float) 57.903;
tcb->m_cWnd = (int) (-86.974*(44.462)*(3.472)*(61.673)*(-55.857)*(23.901)*(-24.299)*(2.251));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (BhzLCDjxbrKwZzEg != tcb->m_segmentSize) {
	segmentsAcked = (int) (segmentsAcked*(35.107));

} else {
	segmentsAcked = (int) (37.991+(79.914)+(30.876)+(BhzLCDjxbrKwZzEg)+(89.397)+(tcb->m_segmentSize));

}
tcb->m_cWnd = (int) (57.52*(48.141)*(-48.491)*(-21.132)*(-62.507)*(-43.381)*(-4.106)*(6.757));
BhzLCDjxbrKwZzEg = (float) (9.374/15.383);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (BhzLCDjxbrKwZzEg != tcb->m_segmentSize) {
	segmentsAcked = (int) (37.991+(79.914)+(30.876)+(BhzLCDjxbrKwZzEg)+(89.397)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (segmentsAcked*(35.107));

}
BhzLCDjxbrKwZzEg = (float) (1.827/50.259);
