float IUxSxnkNcsGCgRxj = (float) (90.527+(51.966));
segmentsAcked = (int) (31.021*(18.959)*(29.788)*(56.318)*(84.362)*(37.972)*(78.561)*(segmentsAcked)*(37.716));
segmentsAcked = (int) (35.574*(31.282));
tcb->m_ssThresh = (int) (15.438-(98.152)-(76.345)-(24.544)-(IUxSxnkNcsGCgRxj));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (37.766-(tcb->m_ssThresh)-(98.691));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (20.859+(34.094)+(88.051)+(75.667));

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (77.288*(5.147)*(91.426)*(92.646)*(55.082));

} else {
	tcb->m_ssThresh = (int) (27.522/0.1);

}
