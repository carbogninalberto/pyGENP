tcb->m_cWnd = (int) (-57.11-(-62.961));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (38.002*(-88.976)*(59.343)*(-26.658)*(11.644)*(-65.925));
