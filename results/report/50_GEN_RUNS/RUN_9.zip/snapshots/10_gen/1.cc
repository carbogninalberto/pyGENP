tcb->m_cWnd = (int) (71.466-(33.206));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-97.342*(-47.567)*(90.864)*(-48.433)*(90.176)*(21.848));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-59.15*(95.228)*(9.823)*(-70.842)*(-40.982)*(14.206));
