tcb->m_cWnd = (int) (-99.828-(90.37));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (17.121*(49.796)*(97.336)*(-54.553)*(45.646)*(-74.293));
segmentsAcked = (int) (-13.055*(33.086)*(9.27)*(-78.154)*(-31.914)*(-99.999));
