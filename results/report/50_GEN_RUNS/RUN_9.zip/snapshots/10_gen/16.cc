tcb->m_cWnd = (int) (5.006-(-94.921));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (34.891*(-98.142)*(-33.952)*(-47.257)*(99.929)*(-86.143));
segmentsAcked = (int) (27.047*(28.14)*(82.186)*(-77.155)*(-49.057)*(77.681));
