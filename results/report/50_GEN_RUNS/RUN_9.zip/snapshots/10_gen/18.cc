if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (96.131-(3.075)-(16.638)-(88.464)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.571)-(25.867)-(14.467));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (1.546-(19.242)-(4.82)-(49.253)-(81.394)-(45.618)-(47.342)-(87.363));

}
int hXqbDMfvMugmOTJa = (int) (63.017/(-9.354+(-67.417)+(-20.842)+(61.024)+(6.644)+(-36.732)));
hXqbDMfvMugmOTJa = (int) (-81.549-(-46.519)-(55.228)-(81.163)-(-23.537)-(-68.757));
segmentsAcked = (int) (10.866+(-74.94)+(-62.936)+(70.094)+(-2.76)+(63.65)+(85.531)+(52.938));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (96.131-(3.075)-(16.638)-(88.464)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.571)-(25.867)-(14.467));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (1.546-(19.242)-(4.82)-(49.253)-(81.394)-(45.618)-(47.342)-(87.363));

}
segmentsAcked = (int) (-22.81+(-93.715)+(33.026)+(-64.945)+(94.663)+(72.134)+(-99.099)+(-73.379));
hXqbDMfvMugmOTJa = (int) (-67.897-(-67.362)-(66.943)-(-47.713)-(33.984)-(16.552));
segmentsAcked = (int) (15.498+(-25.314)+(55.763)+(5.938)+(10.272)+(12.74)+(74.195)+(12.646));
