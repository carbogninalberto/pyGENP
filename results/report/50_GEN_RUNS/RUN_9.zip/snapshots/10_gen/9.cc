tcb->m_cWnd = (int) (-61.789-(-2.443));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (-89.409*(39.564)*(-8.205)*(-38.755)*(-5.176)*(24.045));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-35.949*(-33.477)*(99.64)*(0.526)*(71.565)*(48.495));
