tcb->m_cWnd = (int) (66.312-(-20.721));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-52.21*(-18.141)*(-99.209)*(25.353)*(52.325)*(-50.854));
