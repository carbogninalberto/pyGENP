tcb->m_cWnd = (int) (89.117-(-13.302));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-64.185*(-75.472)*(19.435)*(24.145)*(-35.894)*(32.936));
segmentsAcked = (int) (-63.652*(-62.189)*(-51.568)*(80.398)*(-7.575)*(-92.044));
