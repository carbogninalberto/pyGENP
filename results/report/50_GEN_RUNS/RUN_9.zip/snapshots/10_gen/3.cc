if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (1.546-(19.242)-(4.82)-(49.253)-(81.394)-(45.618)-(47.342)-(87.363));

} else {
	segmentsAcked = (int) (96.131-(3.075)-(16.638)-(88.464)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.571)-(25.867)-(14.467));
	CongestionAvoidance (tcb, segmentsAcked);

}
int hXqbDMfvMugmOTJa = (int) (4.224/(-20.576+(-73.191)+(64.98)+(70.934)+(52.579)+(-99.633)));
hXqbDMfvMugmOTJa = (int) (43.392-(-85.827)-(-24.017)-(-81.872)-(28.88)-(98.674));
segmentsAcked = (int) (84.419+(-20.706)+(63.038)+(79.389)+(-62.072)+(87.401)+(-26.625)+(-98.099));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (96.131-(3.075)-(16.638)-(88.464)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.571)-(25.867)-(14.467));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (1.546-(19.242)-(4.82)-(49.253)-(81.394)-(45.618)-(47.342)-(87.363));

}
hXqbDMfvMugmOTJa = (int) (63.059-(16.239)-(73.146)-(-81.462)-(30.434)-(18.176));
segmentsAcked = (int) (-63.895+(20.754)+(-24.843)+(48.905)+(65.873)+(-9.715)+(-11.223)+(-46.05));
