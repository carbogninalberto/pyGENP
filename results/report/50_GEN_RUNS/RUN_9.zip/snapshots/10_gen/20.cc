tcb->m_cWnd = (int) (23.778-(-89.931));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (0.592*(73.377)*(97.038)*(83.569)*(-85.909)*(-59.599));
segmentsAcked = (int) (84.514*(-39.414)*(3.632)*(-60.955)*(61.579)*(24.78));
