CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (93.251*(94.997)*(5.872)*(tcb->m_cWnd));
if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (53.304*(tcb->m_ssThresh)*(50.811)*(93.58)*(16.96)*(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) ((((66.076+(68.215)+(62.146)+(tcb->m_cWnd)+(32.523)+(65.879)+(5.818)+(47.797)+(29.384)))+(2.178)+(90.313)+(0.1)+(0.1)+(17.64)+(76.801))/((0.1)));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(segmentsAcked)+(tcb->m_ssThresh));

}
tcb->m_cWnd = (int) (4.234+(3.515)+(74.581)+(26.613)+(22.619)+(94.788)+(91.563)+(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (44.084*(83.059)*(86.876)*(tcb->m_ssThresh)*(92.615)*(tcb->m_segmentSize)*(59.773));
tcb->m_ssThresh = (int) (70.925*(99.65));
