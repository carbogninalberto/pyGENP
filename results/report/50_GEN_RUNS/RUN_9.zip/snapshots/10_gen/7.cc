tcb->m_cWnd = (int) (-0.264-(13.687));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-25.45*(33.766)*(33.186)*(-48.554)*(71.9)*(49.144));
