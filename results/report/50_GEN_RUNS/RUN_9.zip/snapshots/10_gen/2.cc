if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (1.546-(19.242)-(4.82)-(49.253)-(81.394)-(45.618)-(47.342)-(87.363));

} else {
	segmentsAcked = (int) (96.131-(3.075)-(16.638)-(88.464)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.571)-(25.867)-(14.467));
	CongestionAvoidance (tcb, segmentsAcked);

}
int hXqbDMfvMugmOTJa = (int) (-48.301/(35.084+(20.984)+(-98.48)+(70.643)+(-34.924)+(-77.046)));
hXqbDMfvMugmOTJa = (int) (28.22-(94.922)-(57.08)-(-47.603)-(-82.61)-(58.499));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (1.546-(19.242)-(4.82)-(49.253)-(81.394)-(45.618)-(47.342)-(87.363));

} else {
	segmentsAcked = (int) (96.131-(3.075)-(16.638)-(88.464)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.571)-(25.867)-(14.467));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (74.188+(-8.294)+(-9.075)+(-69.956)+(-76.076)+(68.881)+(50.362)+(83.027));
hXqbDMfvMugmOTJa = (int) (33.786-(1.721)-(10.436)-(-49.693)-(-74.226)-(-46.502));
hXqbDMfvMugmOTJa = (int) (59.403-(-10.827)-(50.913)-(38.41)-(51.97)-(79.898));
segmentsAcked = (int) (-68.229+(24.366)+(77.211)+(2.506)+(-56.791)+(-17.233)+(41.712)+(-67.021));
segmentsAcked = (int) (8.923+(88.094)+(13.818)+(84.58)+(-69.329)+(-3.76)+(-79.305)+(-81.982));
hXqbDMfvMugmOTJa = (int) (43.543-(-16.822)-(-26.215)-(84.998)-(44.076)-(-51.558));
segmentsAcked = (int) (-63.767+(37.211)+(-2.162)+(88.38)+(63.553)+(-56.517)+(89.613)+(94.784));
