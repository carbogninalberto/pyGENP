tcb->m_cWnd = (int) (-36.348-(73.605));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (86.349*(-72.399)*(-11.017)*(-27.806)*(43.6)*(-85.694));
