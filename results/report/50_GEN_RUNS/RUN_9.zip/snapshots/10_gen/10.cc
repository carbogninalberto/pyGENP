tcb->m_cWnd = (int) (-40.392-(-36.506));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-86.522*(7.473)*(6.215)*(66.442)*(-34.155)*(20.178));
