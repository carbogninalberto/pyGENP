if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (40.745+(62.368)+(87.034)+(5.159)+(79.808)+(45.064)+(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (88.716-(83.565)-(tcb->m_cWnd));

}
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (19.227+(8.247));

} else {
	tcb->m_cWnd = (int) (32.388/0.1);
	tcb->m_ssThresh = (int) (((57.592)+(91.786)+(84.679)+(40.903))/((93.279)+(0.1)+(27.222)+(0.1)));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (segmentsAcked+(84.842)+(65.365));

} else {
	tcb->m_segmentSize = (int) (0.1/58.273);

}
float qvtVxJrrqprVgEEo = (float) (28.929+(34.228)+(57.119)+(tcb->m_segmentSize)+(3.825)+(14.901)+(59.025)+(43.937)+(segmentsAcked));
float REfCitHraDKwRAxi = (float) (27.106+(49.281));
int nDJtGZzIIeDMbAoC = (int) (((0.1)+((51.381-(42.37)-(12.974)))+((64.268-(qvtVxJrrqprVgEEo)-(4.023)-(16.61)-(36.722)-(58.476)-(68.294)))+(0.1)+(0.1))/((0.1)+(59.79)+(0.1)));
tcb->m_ssThresh = (int) ((69.248*(tcb->m_ssThresh)*(27.859)*(5.177)*(36.971)*(35.659))/81.209);
