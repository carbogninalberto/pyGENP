int BAuuindWiSRoCcZG = (int) (72.839+(7.268)+(11.103));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (36.938*(4.22)*(84.647)*(tcb->m_segmentSize)*(65.614)*(89.344)*(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
