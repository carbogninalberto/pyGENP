segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (50.934+(92.387)+(13.472)+(22.599));
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (75.583*(64.519)*(89.5)*(74.179));

} else {
	tcb->m_cWnd = (int) (74.775*(47.226));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (31.442*(84.164));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(47.444)-(82.104)-(56.422));
	tcb->m_ssThresh = (int) (67.327+(57.653)+(19.102)+(42.171)+(18.842));

} else {
	tcb->m_cWnd = (int) (51.732+(37.279)+(74.344)+(tcb->m_ssThresh)+(3.947)+(66.066)+(1.922)+(67.211)+(63.076));
	segmentsAcked = (int) (43.652+(40.768));

}
CongestionAvoidance (tcb, segmentsAcked);
