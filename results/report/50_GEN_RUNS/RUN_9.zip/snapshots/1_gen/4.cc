float HgjCCGcnOWOzfnpJ = (float) (40.024/0.1);
if (HgjCCGcnOWOzfnpJ > segmentsAcked) {
	segmentsAcked = (int) (14.84-(37.864));
	tcb->m_cWnd = (int) (61.101/45.288);
	tcb->m_segmentSize = (int) (0.1/39.319);

} else {
	segmentsAcked = (int) (18.265-(58.691)-(32.566)-(tcb->m_segmentSize)-(12.423)-(85.936));
	segmentsAcked = (int) (HgjCCGcnOWOzfnpJ*(HgjCCGcnOWOzfnpJ)*(19.151));

}
tcb->m_cWnd = (int) (98.157+(94.792)+(segmentsAcked)+(93.626));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float eBVZsnemgOTqtEgm = (float) (73.519/0.1);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (16.404-(87.403));
