if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (36.527-(52.385));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(61.158)+(50.117)+(0.1)+(0.1)+((45.215-(53.841)-(98.045)))+((88.491+(4.894)+(3.68)+(57.886)+(59.165)))+(21.814))/((0.1)));
	segmentsAcked = (int) (16.176+(36.779)+(22.786)+(49.484)+(79.757));

}
tcb->m_segmentSize = (int) (9.436+(98.364)+(11.955)+(25.771)+(98.288)+(52.336)+(20.898)+(4.847)+(81.207));
segmentsAcked = (int) (78.417/60.019);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (26.508+(tcb->m_cWnd)+(56.984)+(segmentsAcked)+(tcb->m_ssThresh)+(79.726)+(tcb->m_segmentSize)+(38.443));
tcb->m_segmentSize = (int) (84.688+(tcb->m_cWnd));
