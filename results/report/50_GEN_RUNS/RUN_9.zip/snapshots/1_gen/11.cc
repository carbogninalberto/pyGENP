if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (1.546-(19.242)-(4.82)-(49.253)-(81.394)-(45.618)-(47.342)-(87.363));

} else {
	segmentsAcked = (int) (96.131-(3.075)-(16.638)-(88.464)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.571)-(25.867)-(14.467));
	CongestionAvoidance (tcb, segmentsAcked);

}
int hXqbDMfvMugmOTJa = (int) (2.438/(33.839+(35.181)+(77.966)+(tcb->m_ssThresh)+(66.43)+(16.955)));
hXqbDMfvMugmOTJa = (int) (96.961-(93.895)-(13.202)-(19.126)-(tcb->m_cWnd)-(7.386));
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(hXqbDMfvMugmOTJa)-(24.118)-(38.465)-(65.73)-(27.64)-(12.907));
segmentsAcked = (int) (tcb->m_ssThresh+(45.979)+(2.456)+(65.058)+(76.456)+(22.77)+(tcb->m_cWnd)+(74.077));
