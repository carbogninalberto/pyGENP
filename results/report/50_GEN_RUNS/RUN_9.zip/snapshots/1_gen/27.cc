segmentsAcked = (int) (70.407-(2.429)-(tcb->m_ssThresh)-(94.179)-(74.674)-(4.391)-(tcb->m_segmentSize)-(38.853));
int EyWbRUfXIStyEXLC = (int) (79.048-(tcb->m_segmentSize)-(51.169)-(40.095)-(27.067)-(75.428)-(segmentsAcked)-(segmentsAcked)-(28.376));
tcb->m_ssThresh = (int) (7.283*(74.185)*(9.969)*(tcb->m_segmentSize)*(53.251)*(74.092)*(88.806)*(50.477));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh >= EyWbRUfXIStyEXLC) {
	tcb->m_ssThresh = (int) (54.289*(tcb->m_cWnd)*(51.507)*(50.597)*(64.058)*(95.062)*(3.535)*(77.935));
	segmentsAcked = (int) (tcb->m_cWnd+(89.717)+(tcb->m_cWnd)+(61.624)+(79.226));

} else {
	tcb->m_ssThresh = (int) (11.74*(30.109)*(38.644));

}
tcb->m_segmentSize = (int) (7.762-(22.511)-(52.992));
if (tcb->m_ssThresh < EyWbRUfXIStyEXLC) {
	tcb->m_segmentSize = (int) (81.36+(21.481)+(EyWbRUfXIStyEXLC)+(tcb->m_ssThresh)+(50.854));
	tcb->m_segmentSize = (int) (17.329*(tcb->m_segmentSize)*(21.562));

} else {
	tcb->m_segmentSize = (int) (31.206-(58.31)-(EyWbRUfXIStyEXLC)-(85.096)-(65.156)-(segmentsAcked)-(68.257)-(81.674)-(76.329));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	EyWbRUfXIStyEXLC = (int) (((20.947)+((tcb->m_segmentSize-(47.38)-(tcb->m_segmentSize)-(8.674)-(27.073)-(4.777)-(97.22)-(56.688)-(tcb->m_cWnd)))+(0.1)+(0.1))/((0.1)+(60.31)+(0.1)));

}
tcb->m_segmentSize = (int) (23.392+(38.535)+(73.169)+(2.272)+(60.643)+(22.832)+(71.33));
segmentsAcked = SlowStart (tcb, segmentsAcked);
