tcb->m_ssThresh = (int) (0.1/19.679);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (82.933+(83.252)+(42.058)+(tcb->m_segmentSize)+(45.5)+(62.499));
	tcb->m_ssThresh = (int) (94.227+(48.158)+(49.992)+(17.321)+(tcb->m_ssThresh)+(segmentsAcked)+(segmentsAcked)+(tcb->m_ssThresh)+(21.115));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (30.574-(65.349)-(32.802)-(tcb->m_ssThresh)-(68.732)-(43.36)-(18.509)-(61.253));
	tcb->m_ssThresh = (int) (22.906-(98.119)-(59.321));
	tcb->m_segmentSize = (int) (1.916+(24.373)+(55.312)+(tcb->m_segmentSize)+(22.002)+(60.0)+(79.545)+(50.161)+(tcb->m_ssThresh));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (97.206+(86.504)+(72.531)+(63.995)+(54.679));
	segmentsAcked = (int) (83.857*(34.034)*(56.929)*(10.358)*(39.866)*(24.134)*(tcb->m_cWnd)*(16.933));
	tcb->m_ssThresh = (int) (32.758+(9.727)+(81.979)+(1.579));

} else {
	tcb->m_segmentSize = (int) (43.833*(27.973)*(tcb->m_ssThresh)*(7.602)*(0.781)*(83.676)*(90.102));

}
