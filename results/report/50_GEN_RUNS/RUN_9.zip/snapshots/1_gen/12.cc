if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_cWnd = (int) (56.367*(tcb->m_segmentSize)*(9.245)*(60.52)*(84.317));

} else {
	tcb->m_cWnd = (int) (36.232*(76.721)*(segmentsAcked)*(32.03)*(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (((80.694)+(0.1)+(58.235)+(0.1)+(58.821)+((62.953+(29.108)))+(0.1)+(22.952))/((15.612)));
float eWsroanyoSfrgXWI = (float) ((((65.986*(38.168)*(21.396)*(88.03)))+(0.1)+(74.556)+((96.651-(63.898)-(27.926)-(64.778)-(0.492)-(4.967)))+(0.1)+(0.1))/((52.471)+(0.1)+(0.1)));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (45.7-(36.747)-(46.637)-(tcb->m_segmentSize)-(79.974)-(25.306));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(95.705)-(4.088)-(tcb->m_cWnd)-(eWsroanyoSfrgXWI)-(56.789)-(92.969));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) ((95.376+(98.436)+(32.447)+(68.341))/(37.525*(75.168)*(46.51)*(tcb->m_cWnd)*(99.646)*(78.974)));

}
tcb->m_ssThresh = (int) (92.681/73.598);
