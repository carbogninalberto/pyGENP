float tzCEtbIxNOJJfVrF = (float) (72.458+(3.916)+(24.274)+(segmentsAcked)+(59.414)+(61.247)+(17.08));
tcb->m_cWnd = (int) (51.983-(59.495)-(15.284)-(30.154)-(20.935));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked == tzCEtbIxNOJJfVrF) {
	tcb->m_segmentSize = (int) (79.848*(60.639)*(44.043)*(tcb->m_cWnd)*(65.191)*(96.351)*(tcb->m_ssThresh)*(99.165)*(25.928));

} else {
	tcb->m_segmentSize = (int) (62.942-(70.716)-(81.557)-(61.407)-(82.957)-(28.114));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
CongestionAvoidance (tcb, segmentsAcked);
