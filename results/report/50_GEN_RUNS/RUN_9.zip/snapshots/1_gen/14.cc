int OyGfCyocmwtoJXyO = (int) (9.359+(30.625)+(6.641)+(15.374)+(42.378)+(73.978)+(9.034)+(81.204));
segmentsAcked = (int) (OyGfCyocmwtoJXyO+(93.107)+(99.538)+(3.385)+(27.571)+(33.632));
tcb->m_segmentSize = (int) (84.318+(23.914)+(OyGfCyocmwtoJXyO)+(68.908)+(24.61)+(48.641));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked >= OyGfCyocmwtoJXyO) {
	tcb->m_ssThresh = (int) (32.91-(19.323)-(29.603)-(38.262)-(8.158)-(40.32)-(21.069)-(75.698)-(43.924));
	tcb->m_segmentSize = (int) (15.336-(83.346)-(58.35)-(76.518)-(1.525)-(17.35)-(26.607));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(77.266));
	tcb->m_cWnd = (int) (tcb->m_cWnd*(94.942)*(0.413)*(83.92));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (91.917*(16.329)*(2.559)*(40.763)*(32.479)*(38.883));
segmentsAcked = (int) (48.059*(36.28)*(95.715)*(67.064)*(19.599)*(11.768));
