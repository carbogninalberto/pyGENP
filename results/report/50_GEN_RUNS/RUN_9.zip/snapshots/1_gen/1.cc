TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (86.592-(93.182)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(41.588)-(48.342));
segmentsAcked = (int) (9.682+(58.119)+(3.25));
tcb->m_segmentSize = (int) (40.618/(73.243+(25.966)+(86.561)));
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((97.505-(tcb->m_segmentSize)-(13.553)-(tcb->m_segmentSize)-(63.408)-(5.76)-(segmentsAcked)-(97.621))/67.437);
	segmentsAcked = (int) (16.681+(40.389)+(75.909)+(78.103)+(segmentsAcked)+(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (27.299/25.221);

} else {
	tcb->m_cWnd = (int) (51.576*(25.223)*(21.399)*(segmentsAcked)*(tcb->m_cWnd)*(23.704)*(49.592)*(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (57.256/16.33);

}
