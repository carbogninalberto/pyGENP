tcb->m_cWnd = (int) (99.202-(-66.081));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-5.929*(-83.539)*(55.318)*(-18.631)*(56.268)*(14.673));
