segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(55.476)+(24.232));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked*(81.288)*(64.615));
	tcb->m_segmentSize = (int) (11.671/90.282);
	segmentsAcked = (int) (59.688/0.1);

}
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (75.549*(65.284)*(76.307)*(97.498)*(22.226)*(tcb->m_segmentSize)*(0.101)*(93.28)*(19.838));
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (32.737+(segmentsAcked)+(70.042)+(63.497)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(7.928)+(64.812)+(25.065));

}
if (tcb->m_ssThresh == segmentsAcked) {
	segmentsAcked = (int) (tcb->m_cWnd*(tcb->m_ssThresh)*(76.565)*(85.23)*(99.864));
	tcb->m_cWnd = (int) (5.254*(segmentsAcked)*(43.243)*(14.015)*(60.323));

} else {
	segmentsAcked = (int) (95.759*(54.071)*(tcb->m_ssThresh)*(91.545)*(35.775));
	tcb->m_ssThresh = (int) (59.559+(tcb->m_cWnd)+(tcb->m_cWnd));

}
