float gXAbiDKZWfnhJhwP = (float) (((54.19)+((48.085-(84.793)-(57.659)))+(0.1)+(0.1)+(0.1)+((92.575+(52.456)+(42.164)))+(39.59))/((0.1)+(31.726)));
tcb->m_cWnd = (int) (66.666+(8.245)+(67.21)+(tcb->m_ssThresh)+(segmentsAcked)+(segmentsAcked)+(17.398)+(23.56));
segmentsAcked = (int) (24.514+(3.912)+(38.523));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= gXAbiDKZWfnhJhwP) {
	tcb->m_segmentSize = (int) (((0.1)+(27.679)+(53.123)+(16.263)+((94.344-(82.189)-(tcb->m_cWnd)))+(86.844))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (6.938+(55.254)+(20.678)+(tcb->m_segmentSize)+(72.154)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(tcb->m_segmentSize));

}
if (gXAbiDKZWfnhJhwP > tcb->m_cWnd) {
	gXAbiDKZWfnhJhwP = (float) (48.955*(32.092)*(28.026)*(34.123)*(97.131));
	tcb->m_ssThresh = (int) (segmentsAcked+(9.788)+(82.933)+(33.021)+(79.931)+(24.447));

} else {
	gXAbiDKZWfnhJhwP = (float) (90.765+(34.681)+(18.644)+(82.231)+(27.714)+(54.984)+(3.619)+(58.315)+(9.862));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (15.937-(tcb->m_ssThresh));

}
if (gXAbiDKZWfnhJhwP != tcb->m_segmentSize) {
	segmentsAcked = (int) (72.446-(43.795)-(23.212)-(89.539)-(80.8)-(54.929)-(75.98));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (segmentsAcked-(tcb->m_ssThresh)-(52.345));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (16.548*(84.771)*(16.672));

}
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	segmentsAcked = (int) (98.97-(61.685));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (80.228/0.1);

} else {
	segmentsAcked = (int) ((10.405*(75.377)*(5.328)*(98.489)*(76.559)*(segmentsAcked))/94.249);
	tcb->m_ssThresh = (int) (76.192-(46.045)-(36.367)-(tcb->m_ssThresh)-(43.538)-(12.701)-(49.447)-(1.106)-(70.71));

}
