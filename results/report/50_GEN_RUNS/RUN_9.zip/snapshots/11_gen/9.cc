tcb->m_cWnd = (int) (77.135-(19.068));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (34.428*(5.054)*(98.497)*(93.378)*(74.641)*(-43.804));
segmentsAcked = (int) (36.657*(18.066)*(-54.016)*(18.117)*(52.249)*(99.604));
