segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
float AtpHjKPJnWeTmMCs = (float) (4.714+(29.794)+(45.182)+(tcb->m_ssThresh)+(89.818)+(72.474)+(tcb->m_cWnd)+(66.23));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_segmentSize*(30.422)*(17.945));
