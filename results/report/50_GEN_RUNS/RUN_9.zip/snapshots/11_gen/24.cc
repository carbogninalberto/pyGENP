tcb->m_ssThresh = (int) (46.826*(tcb->m_cWnd)*(82.573)*(42.574));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) ((22.44+(0.514))/94.308);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (tcb->m_ssThresh-(25.796)-(90.122)-(98.1));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(86.831));
	tcb->m_cWnd = (int) (74.51+(47.293));
	segmentsAcked = (int) (36.224-(tcb->m_cWnd)-(3.819)-(tcb->m_ssThresh));

}
