int xSVWJsGPlRTISkex = (int) (((68.474)+(0.1)+(0.1)+(83.899))/((51.99)));
int wvsaFsYSUQZEznfh = (int) (0.509+(82.986));
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (72.016+(tcb->m_ssThresh)+(tcb->m_cWnd)+(52.056)+(87.759));

} else {
	tcb->m_cWnd = (int) (2.099*(64.404)*(27.516)*(33.925)*(24.606)*(segmentsAcked));

}
if (tcb->m_cWnd >= wvsaFsYSUQZEznfh) {
	tcb->m_ssThresh = (int) (36.047*(7.104)*(16.862)*(84.639)*(xSVWJsGPlRTISkex)*(35.713)*(94.227)*(43.674)*(50.082));
	wvsaFsYSUQZEznfh = (int) (61.759*(62.514));

} else {
	tcb->m_ssThresh = (int) (55.437+(xSVWJsGPlRTISkex));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	wvsaFsYSUQZEznfh = (int) ((82.465+(wvsaFsYSUQZEznfh))/57.836);

} else {
	wvsaFsYSUQZEznfh = (int) (84.837+(13.727)+(wvsaFsYSUQZEznfh)+(2.977)+(73.942)+(0.061)+(82.501)+(51.264));
	wvsaFsYSUQZEznfh = (int) (58.178+(66.575)+(11.216)+(84.173)+(28.622)+(87.792)+(74.739)+(segmentsAcked)+(33.039));
	tcb->m_ssThresh = (int) (29.276+(tcb->m_ssThresh)+(39.269)+(74.842)+(25.966));

}
