segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) ((-25.827-(45.687)-(38.665)-(44.569))/17.873);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (37.668-(18.765)-(40.977)-(segmentsAcked)-(63.834)-(34.455));

} else {
	tcb->m_segmentSize = (int) (61.763*(86.366)*(15.94)*(tcb->m_segmentSize)*(1.978)*(17.711)*(42.948)*(27.819)*(57.296));

}
CongestionAvoidance (tcb, segmentsAcked);
