tcb->m_cWnd = (int) (-61.777-(-51.293));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (84.896*(-73.391)*(67.915)*(-32.651)*(29.21)*(-9.436));
