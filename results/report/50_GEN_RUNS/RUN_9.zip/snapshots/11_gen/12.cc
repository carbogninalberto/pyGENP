tcb->m_segmentSize = (int) (tcb->m_cWnd-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(98.393)-(9.419)-(88.185)-(83.56)-(tcb->m_ssThresh)-(27.56));
segmentsAcked = (int) (71.366-(30.8)-(44.993)-(99.211)-(39.95)-(23.985)-(80.2)-(97.432)-(54.394));
float QKJzBXhUdpStwyar = (float) (35.141+(68.977)+(segmentsAcked)+(65.677)+(segmentsAcked)+(42.853));
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	QKJzBXhUdpStwyar = (float) (0.022*(tcb->m_segmentSize)*(87.816)*(tcb->m_ssThresh)*(segmentsAcked)*(61.368)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(7.219)-(86.833)-(47.613)-(tcb->m_ssThresh)-(6.68)-(56.685)-(27.447));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	QKJzBXhUdpStwyar = (float) (((0.1)+(0.1)+(0.1)+(0.1)+(70.54)+(0.1)+(0.1)+(6.506))/((0.1)));
	tcb->m_cWnd = (int) (42.548-(8.201)-(48.285)-(tcb->m_cWnd)-(49.01)-(58.436)-(42.273));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (QKJzBXhUdpStwyar <= tcb->m_ssThresh) {
	segmentsAcked = (int) (44.375*(7.936));
	tcb->m_ssThresh = (int) (84.852*(41.341));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(91.9)-(10.784)-(10.701)-(16.079)-(1.484)-(36.285)-(39.282));

} else {
	segmentsAcked = (int) (8.213-(2.579));
	segmentsAcked = (int) (74.918*(92.31)*(67.691)*(15.363)*(1.888)*(segmentsAcked)*(58.773)*(53.314));
	tcb->m_ssThresh = (int) (93.712+(segmentsAcked)+(72.064)+(49.98)+(44.442)+(8.64)+(41.737)+(37.592));

}
segmentsAcked = (int) (97.054-(80.734)-(4.163)-(84.176)-(QKJzBXhUdpStwyar)-(93.06)-(tcb->m_cWnd));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
