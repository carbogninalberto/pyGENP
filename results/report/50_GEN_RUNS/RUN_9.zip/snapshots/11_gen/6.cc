tcb->m_cWnd = (int) (-17.002/-54.046);
segmentsAcked = (int) (36.73*(6.798)*(-2.131)*(-50.516));
if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) ((((66.076+(68.215)+(62.146)+(tcb->m_cWnd)+(32.523)+(65.879)+(5.818)+(47.797)+(29.384)))+(2.178)+(90.313)+(0.1)+(0.1)+(17.64)+(76.801))/((0.1)));
	tcb->m_segmentSize = (int) (7.435+(segmentsAcked)+(-18.106));

} else {
	segmentsAcked = (int) (53.304*(39.699)*(50.811)*(93.58)*(16.96)*(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_cWnd = (int) (93.185+(89.923)+(12.105)+(-18.416)+(62.19)+(-9.209)+(-0.425)+(38.659));
tcb->m_segmentSize = (int) (52.761*(79.583)*(-67.495)*(27.604)*(-95.798)*(31.668)*(-23.405));
