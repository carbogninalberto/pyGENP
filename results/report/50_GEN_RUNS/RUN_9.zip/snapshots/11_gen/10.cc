segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) ((7.676-(70.842)-(52.905)-(34.329))/-89.094);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (37.668-(18.765)-(40.977)-(segmentsAcked)-(63.834)-(34.455));

} else {
	tcb->m_segmentSize = (int) (61.763*(86.366)*(15.94)*(tcb->m_segmentSize)*(1.978)*(17.711)*(42.948)*(27.819)*(57.296));

}
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (37.668-(18.765)-(40.977)-(segmentsAcked)-(63.834)-(34.455));

} else {
	tcb->m_segmentSize = (int) (61.763*(86.366)*(15.94)*(tcb->m_segmentSize)*(1.978)*(17.711)*(42.948)*(27.819)*(57.296));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
