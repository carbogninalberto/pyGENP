tcb->m_cWnd = (int) (48.311-(-78.681));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (67.953*(44.21)*(-67.612)*(68.918)*(-41.55)*(69.319));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (79.807*(-92.154)*(10.156)*(52.194)*(86.462)*(-3.135));
