float IUxSxnkNcsGCgRxj = (float) 87.358;
segmentsAcked = (int) (-48.422*(-34.667)*(-42.234)*(-39.184)*(2.385)*(-65.885)*(-90.634)*(-27.048)*(57.359));
segmentsAcked = (int) (93.247*(29.869));
