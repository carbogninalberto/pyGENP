float qYVXqWSchzGXenSz = (float) 37.369;
if (segmentsAcked >= qYVXqWSchzGXenSz) {
	segmentsAcked = (int) (60.281/85.868);
	qYVXqWSchzGXenSz = (float) (1.61*(45.624)*(79.563));

} else {
	segmentsAcked = (int) (10.697-(60.048)-(6.064));
	tcb->m_cWnd = (int) (16.384-(56.099)-(40.144));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (45.322-(23.28)-(-39.453)-(-50.103)-(-52.931));
segmentsAcked = (int) (-58.687-(30.545)-(-25.372)-(-50.906)-(71.099));
segmentsAcked = (int) (-74.286*(80.201)*(-65.948)*(69.787)*(45.485)*(65.242));
segmentsAcked = (int) (-4.814*(-23.669)*(-54.887)*(44.768)*(71.662)*(-36.876));
