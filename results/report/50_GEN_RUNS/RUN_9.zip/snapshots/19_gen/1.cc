tcb->m_cWnd = (int) (-67.948-(-51.036));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (90.185*(76.045)*(-41.611)*(64.671)*(-38.879)*(43.587));
segmentsAcked = (int) (37.304*(93.172)*(32.277)*(-2.42)*(41.013)*(12.349));
