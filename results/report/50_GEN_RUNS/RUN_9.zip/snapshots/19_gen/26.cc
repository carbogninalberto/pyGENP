if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (61.252-(90.357)-(20.222)-(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (31.535-(tcb->m_segmentSize)-(57.763)-(17.492)-(46.644)-(47.984));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (10.124+(88.911)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(tcb->m_segmentSize));
	segmentsAcked = (int) (segmentsAcked-(75.336));
	segmentsAcked = (int) (tcb->m_ssThresh*(46.126)*(91.14)*(70.94)*(50.241)*(96.606));

}
ReduceCwnd (tcb);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (76.152*(37.545)*(41.723)*(tcb->m_cWnd)*(82.968)*(15.749));

} else {
	tcb->m_cWnd = (int) (98.955+(48.105)+(10.089)+(21.274)+(82.478)+(71.037)+(segmentsAcked));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
