tcb->m_cWnd = (int) (55.678-(87.419));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (89.738*(48.908)*(-39.882)*(-17.615)*(-47.272)*(58.427));
segmentsAcked = (int) (90.414*(-91.308)*(-43.595)*(-64.963)*(-16.529)*(-28.75));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (27.447*(-45.073)*(-57.632)*(20.38)*(40.73)*(-20.835));
