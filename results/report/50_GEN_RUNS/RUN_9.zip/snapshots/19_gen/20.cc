float hMWPmoCnbqfcwpXq = (float) (98.709+(40.201)+(tcb->m_cWnd)+(94.885)+(tcb->m_cWnd)+(33.345)+(12.307)+(63.665)+(35.501));
ReduceCwnd (tcb);
if (hMWPmoCnbqfcwpXq <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (51.617-(38.547)-(96.162)-(79.197)-(67.416)-(31.034)-(66.117));

} else {
	tcb->m_segmentSize = (int) (46.224+(99.021));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	hMWPmoCnbqfcwpXq = (float) (64.066*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(56.681)*(90.445)*(71.795)*(77.621)*(4.013)*(18.684));
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	hMWPmoCnbqfcwpXq = (float) (99.79/1.2);

}
hMWPmoCnbqfcwpXq = (float) (tcb->m_segmentSize*(71.749)*(62.009)*(55.47)*(6.503)*(segmentsAcked)*(97.249)*(5.584));
segmentsAcked = SlowStart (tcb, segmentsAcked);
