tcb->m_cWnd = (int) (-47.76-(-28.385));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (47.189*(-94.446)*(58.421)*(-41.473)*(-91.467)*(48.545));
