tcb->m_segmentSize = (int) (-33.983-(-15.606)-(-64.451));
float fXNYqpeAPbJkAwyH = (float) (42.214+(-61.631)+(-29.816)+(-5.605));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
