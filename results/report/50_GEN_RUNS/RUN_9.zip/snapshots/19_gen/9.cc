float IUxSxnkNcsGCgRxj = (float) 4.375;
segmentsAcked = (int) (-21.593*(-22.823)*(82.128)*(35.387)*(92.56)*(-85.21)*(90.784)*(-79.761)*(68.342));
segmentsAcked = (int) (86.381*(50.676));
