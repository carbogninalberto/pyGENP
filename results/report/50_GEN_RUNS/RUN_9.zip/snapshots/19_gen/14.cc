tcb->m_ssThresh = (int) (0.1/0.1);
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (6.955+(24.917)+(93.304)+(56.218)+(24.877)+(75.505)+(96.933)+(2.511)+(19.514));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (62.103*(71.304)*(64.967)*(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh*(73.21)*(92.784)*(88.35));
	tcb->m_segmentSize = (int) (segmentsAcked*(27.714)*(tcb->m_cWnd)*(86.046)*(30.173)*(77.266)*(12.673)*(segmentsAcked)*(tcb->m_cWnd));
	tcb->m_cWnd = (int) (71.694-(segmentsAcked));

}
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (10.882+(tcb->m_cWnd)+(26.425)+(23.726)+(51.98)+(tcb->m_ssThresh)+(1.789)+(32.616)+(48.548));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(62.285)+(tcb->m_ssThresh)+(6.379)+(76.412)+(37.142)+(15.398)+(21.313));

} else {
	tcb->m_segmentSize = (int) ((34.562-(75.007)-(56.447)-(85.093)-(12.214))/81.164);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
