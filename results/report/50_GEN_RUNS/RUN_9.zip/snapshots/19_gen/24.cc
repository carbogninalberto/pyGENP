tcb->m_cWnd = (int) (85.221-(segmentsAcked)-(32.074));
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (21.111*(32.52)*(66.783)*(5.069));

} else {
	tcb->m_cWnd = (int) (0.649*(13.668)*(58.386)*(52.342)*(40.903)*(68.321)*(47.446)*(28.39));
	tcb->m_segmentSize = (int) (35.306+(10.759)+(84.55)+(tcb->m_cWnd)+(45.959));
	tcb->m_ssThresh = (int) (77.027+(82.556)+(29.906)+(46.068)+(89.929)+(tcb->m_segmentSize)+(89.254)+(3.917)+(41.211));

}
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	segmentsAcked = (int) ((84.479-(62.312)-(tcb->m_ssThresh)-(26.537)-(49.154)-(64.958)-(13.982))/72.076);

} else {
	segmentsAcked = (int) (1.068/65.239);
	segmentsAcked = (int) (64.95-(78.168)-(tcb->m_cWnd)-(89.982));

}
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (24.363+(tcb->m_segmentSize)+(27.516)+(tcb->m_cWnd));
	segmentsAcked = (int) (50.975+(tcb->m_ssThresh)+(80.178)+(31.607)+(tcb->m_ssThresh)+(62.098)+(tcb->m_cWnd)+(86.379));

} else {
	tcb->m_cWnd = (int) (39.662-(43.569)-(tcb->m_segmentSize));
	segmentsAcked = (int) (tcb->m_ssThresh-(68.314)-(46.832)-(29.323));
	tcb->m_cWnd = (int) (70.341*(79.584)*(76.761)*(23.253)*(95.469)*(97.184)*(tcb->m_cWnd)*(28.261)*(92.242));

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (40.459-(65.277));
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (90.053*(16.193)*(27.581)*(tcb->m_cWnd)*(16.712)*(tcb->m_cWnd)*(70.427)*(tcb->m_cWnd));
	tcb->m_cWnd = (int) (78.233-(17.451)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(72.508)-(segmentsAcked)-(85.947)-(43.281)-(59.521));

}
