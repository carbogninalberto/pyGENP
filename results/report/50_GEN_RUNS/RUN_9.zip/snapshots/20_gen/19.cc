int uOdbDueGWnREYFqb = (int) (0.556*(tcb->m_cWnd)*(34.562)*(tcb->m_ssThresh));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (78.136/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (3.539-(46.527)-(39.732)-(48.749));
	tcb->m_ssThresh = (int) (76.012*(65.724)*(98.057)*(35.552)*(25.251)*(tcb->m_ssThresh)*(59.773));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (0.1/38.186);
if (tcb->m_cWnd == tcb->m_cWnd) {
	uOdbDueGWnREYFqb = (int) (73.831*(uOdbDueGWnREYFqb)*(32.422)*(64.506));
	ReduceCwnd (tcb);
	segmentsAcked = (int) ((27.479-(93.143)-(1.505)-(98.507)-(29.358)-(uOdbDueGWnREYFqb))/0.1);

} else {
	uOdbDueGWnREYFqb = (int) (40.111+(48.428)+(segmentsAcked)+(20.076)+(44.81)+(uOdbDueGWnREYFqb)+(tcb->m_segmentSize)+(10.049)+(74.557));
	tcb->m_cWnd = (int) (0.1/0.1);

}
