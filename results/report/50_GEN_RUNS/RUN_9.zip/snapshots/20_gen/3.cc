CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-70.521*(58.884)*(67.789)*(-41.513)*(-37.21)*(88.316)*(-16.524)*(69.236)*(-18.45));
segmentsAcked = (int) (41.687*(-28.942));
