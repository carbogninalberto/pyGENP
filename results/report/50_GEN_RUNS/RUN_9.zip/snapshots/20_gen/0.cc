tcb->m_cWnd = (int) (49.672-(43.906));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (11.369*(98.351)*(92.378)*(77.03)*(33.436)*(17.807));
segmentsAcked = (int) (20.949*(32.126)*(-6.687)*(81.553)*(-28.968)*(81.991));
