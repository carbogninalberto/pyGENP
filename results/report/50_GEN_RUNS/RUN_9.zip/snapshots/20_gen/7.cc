tcb->m_cWnd = (int) (98.019-(-58.078));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-22.421*(-94.203)*(99.507)*(57.01)*(31.315)*(19.143));
segmentsAcked = (int) (-7.463*(21.483)*(20.986)*(-45.884)*(49.994)*(49.575));
segmentsAcked = (int) (76.077*(7.412)*(-95.726)*(-48.748)*(80.514)*(-59.486));
