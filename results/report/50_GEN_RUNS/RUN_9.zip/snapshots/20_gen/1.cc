if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (-34.853*(73.21)*(92.784)*(88.35));
	tcb->m_segmentSize = (int) (segmentsAcked*(27.714)*(tcb->m_cWnd)*(86.046)*(30.173)*(77.266)*(12.673)*(segmentsAcked)*(tcb->m_cWnd));
	tcb->m_cWnd = (int) (71.694-(segmentsAcked));

} else {
	segmentsAcked = (int) (6.955+(24.917)+(93.304)+(56.218)+(24.877)+(75.505)+(96.933)+(2.511)+(19.514));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (62.103*(71.304)*(64.967)*(tcb->m_segmentSize));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
