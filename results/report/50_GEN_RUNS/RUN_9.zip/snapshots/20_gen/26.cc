segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (75.042*(55.366)*(73.697)*(tcb->m_segmentSize)*(92.152)*(segmentsAcked)*(segmentsAcked)*(22.081));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	segmentsAcked = (int) (53.921+(5.578)+(76.525)+(9.818));
	tcb->m_segmentSize = (int) (5.273*(27.19)*(tcb->m_cWnd)*(33.772)*(4.956)*(54.909)*(34.984)*(39.271));

} else {
	segmentsAcked = (int) (33.463-(33.111)-(63.283));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (74.679+(81.853)+(66.733)+(58.192)+(52.429)+(85.268)+(59.621));
