tcb->m_ssThresh = (int) (42.231+(29.333));
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) ((46.864*(8.054))/0.1);
	CongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (58.051+(13.273)+(85.116)+(69.103)+(94.792)+(tcb->m_segmentSize)+(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	segmentsAcked = (int) (61.502+(48.316)+(segmentsAcked)+(tcb->m_cWnd)+(tcb->m_cWnd)+(73.124)+(94.548));

} else {
	segmentsAcked = (int) (48.141*(30.328)*(91.21)*(tcb->m_cWnd)*(77.562)*(99.307)*(tcb->m_cWnd));
	segmentsAcked = (int) ((tcb->m_ssThresh-(75.668))/19.082);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
