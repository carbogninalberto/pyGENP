ReduceCwnd (tcb);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (76.152*(37.545)*(41.723)*(tcb->m_cWnd)*(82.968)*(15.749));

} else {
	tcb->m_cWnd = (int) (98.955+(48.105)+(10.089)+(21.274)+(82.478)+(71.037)+(segmentsAcked));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (76.152*(37.545)*(41.723)*(tcb->m_cWnd)*(82.968)*(15.749));

} else {
	tcb->m_cWnd = (int) (98.955+(48.105)+(10.089)+(21.274)+(82.478)+(71.037)+(segmentsAcked));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
