segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (89.239*(31.747)*(-36.722)*(-55.125)*(77.191)*(94.166)*(35.272)*(98.387)*(-48.71));
segmentsAcked = (int) (5.928*(50.032));
segmentsAcked = (int) (12.09*(60.477));
