int iGvZNCFlvIjWCoYj = (int) (98.84*(94.747));
if (tcb->m_cWnd > iGvZNCFlvIjWCoYj) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(54.539)-(61.217)-(segmentsAcked)-(42.432)-(93.893));
	tcb->m_ssThresh = (int) (0.1/99.222);

} else {
	tcb->m_cWnd = (int) (0.1/74.789);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > iGvZNCFlvIjWCoYj) {
	tcb->m_segmentSize = (int) (48.275*(8.753)*(74.937)*(tcb->m_segmentSize)*(segmentsAcked)*(tcb->m_ssThresh));
	iGvZNCFlvIjWCoYj = (int) (79.155/(10.307+(24.751)+(56.68)+(43.896)+(81.325)+(tcb->m_segmentSize)+(36.85)));

} else {
	tcb->m_segmentSize = (int) (69.158/0.1);
	tcb->m_cWnd = (int) (((0.1)+((9.373*(79.087)*(tcb->m_cWnd)*(4.573)*(59.707)*(tcb->m_segmentSize)*(18.215)))+((45.94*(59.285)*(39.231)))+((84.533+(30.142)+(95.53)+(51.852)))+(0.1)+(15.85)+(96.443)+(0.1))/((87.897)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(segmentsAcked)+(71.971)+(30.171));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (16.974+(segmentsAcked)+(11.211)+(10.294)+(24.135)+(67.738)+(6.133));
tcb->m_ssThresh = (int) (2.165+(76.194)+(79.149));
