tcb->m_cWnd = (int) (59.082-(18.67));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-21.135*(-61.296)*(-24.229)*(48.853)*(-62.542)*(-56.004));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-60.247*(-15.655)*(-14.867)*(-29.418)*(-29.02)*(59.992));
