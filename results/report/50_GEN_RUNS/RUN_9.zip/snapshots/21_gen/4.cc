segmentsAcked = (int) (77.352*(-65.882));
int DoLUxIXNjtpQjxkz = (int) (86.178*(44.475)*(4.132)*(-63.413)*(-12.38)*(-38.292));
segmentsAcked = (int) (11.719*(63.662));
