segmentsAcked = (int) (40.13/0.1);
float qGEuyrZIPBWcNhss = (float) (72.675-(18.478)-(14.003)-(70.163)-(18.63));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (81.177+(53.497));
tcb->m_cWnd = (int) (98.229-(87.765));
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	segmentsAcked = (int) (segmentsAcked-(39.32)-(29.264)-(tcb->m_ssThresh));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (48.474-(43.946)-(tcb->m_ssThresh)-(56.901)-(92.645));

}
