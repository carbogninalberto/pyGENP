segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_segmentSize) {
	segmentsAcked = (int) (59.679-(19.847)-(71.723));
	segmentsAcked = (int) (85.32*(41.772)*(84.914)*(35.14)*(44.777)*(16.096));

} else {
	segmentsAcked = (int) (17.207+(74.028)+(97.661)+(37.556)+(70.677)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(70.2)+(41.315));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
