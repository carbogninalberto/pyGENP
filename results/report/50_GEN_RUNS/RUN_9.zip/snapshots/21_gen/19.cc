segmentsAcked = (int) (67.03-(38.945)-(60.281)-(tcb->m_cWnd));
tcb->m_segmentSize = (int) (33.35-(91.135)-(tcb->m_cWnd)-(tcb->m_segmentSize)-(67.914)-(74.562)-(84.489)-(79.787));
tcb->m_cWnd = (int) ((61.54-(43.459)-(60.217))/0.1);
if (segmentsAcked <= segmentsAcked) {
	tcb->m_ssThresh = (int) (segmentsAcked-(26.653)-(2.956)-(70.336)-(tcb->m_ssThresh)-(41.807));
	segmentsAcked = (int) (segmentsAcked-(segmentsAcked)-(tcb->m_cWnd)-(27.479)-(81.031)-(34.428)-(tcb->m_ssThresh)-(42.571)-(70.373));
	tcb->m_ssThresh = (int) (47.184*(17.984)*(97.604)*(81.299)*(53.596)*(0.323)*(15.297));

} else {
	tcb->m_ssThresh = (int) ((33.663*(47.451)*(67.52)*(29.788)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(98.954))/77.06);
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (78.902*(41.483)*(50.37)*(tcb->m_ssThresh)*(28.979)*(tcb->m_cWnd));
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (79.758*(74.785)*(25.513)*(tcb->m_ssThresh)*(66.348)*(tcb->m_segmentSize));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (44.02/59.159);

} else {
	tcb->m_cWnd = (int) ((tcb->m_cWnd*(70.821)*(90.387))/32.775);
	segmentsAcked = (int) (1.738+(86.734)+(tcb->m_ssThresh)+(77.553)+(tcb->m_cWnd));

}
tcb->m_ssThresh = (int) (tcb->m_ssThresh-(segmentsAcked)-(46.136)-(94.042)-(81.486)-(tcb->m_segmentSize)-(41.766)-(52.124)-(tcb->m_ssThresh));
segmentsAcked = (int) (14.757-(51.25)-(4.992)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(52.35));
segmentsAcked = SlowStart (tcb, segmentsAcked);
