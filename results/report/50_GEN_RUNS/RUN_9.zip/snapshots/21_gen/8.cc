TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (31.758*(69.928));
segmentsAcked = (int) (-10.455*(-9.588)*(-50.938)*(72.613)*(-48.81)*(-81.893)*(-28.345)*(18.166)*(27.661));
segmentsAcked = (int) (-33.249*(-54.453));
segmentsAcked = (int) (22.257*(-59.609));
segmentsAcked = (int) (-84.283*(-4.981));
