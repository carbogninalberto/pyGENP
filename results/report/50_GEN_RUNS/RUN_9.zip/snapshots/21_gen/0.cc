tcb->m_cWnd = (int) (-2.979-(-33.913));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-90.83*(-75.377)*(19.891)*(-94.891)*(-70.225)*(65.614));
