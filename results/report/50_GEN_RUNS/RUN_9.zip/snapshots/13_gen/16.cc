segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (80.882*(tcb->m_ssThresh)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(48.896)*(segmentsAcked));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(85.546));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (segmentsAcked*(47.758)*(16.599)*(segmentsAcked)*(segmentsAcked)*(95.52)*(64.768));

}
int SifoQJYMDvGVnQWH = (int) ((3.407*(88.045)*(18.07)*(tcb->m_segmentSize)*(segmentsAcked)*(11.396)*(31.926)*(4.648)*(87.24))/0.1);
tcb->m_ssThresh = (int) (77.66+(93.221)+(84.571)+(65.596)+(25.172)+(72.438)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(-0.08));
tcb->m_cWnd = (int) (80.751-(40.018)-(95.161)-(20.404)-(45.214)-(48.257));
ReduceCwnd (tcb);
if (SifoQJYMDvGVnQWH < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (30.862*(41.062)*(18.965)*(92.871)*(74.959)*(66.102)*(12.782)*(58.055));

} else {
	tcb->m_cWnd = (int) (43.993-(96.305)-(14.82)-(50.385)-(56.022)-(20.942));
	ReduceCwnd (tcb);

}
