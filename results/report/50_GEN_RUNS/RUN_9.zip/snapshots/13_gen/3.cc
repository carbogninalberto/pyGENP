tcb->m_cWnd = (int) (25.48-(-37.43));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-17.628*(-74.692)*(-17.98)*(67.358)*(-99.717)*(-73.012));
segmentsAcked = (int) (-36.428*(33.909)*(30.071)*(35.692)*(67.993)*(-21.235));
segmentsAcked = (int) (-26.183*(-48.218)*(-49.27)*(23.744)*(-79.533)*(-14.379));
