tcb->m_cWnd = (int) (23.395+(34.855)+(tcb->m_segmentSize)+(78.668)+(80.45));
ReduceCwnd (tcb);
float rfPAGonhcYkMplvx = (float) (0.307*(tcb->m_segmentSize)*(67.069)*(71.961)*(23.58)*(12.655)*(70.042)*(66.259)*(64.927));
if (tcb->m_cWnd >= rfPAGonhcYkMplvx) {
	tcb->m_cWnd = (int) (50.88/(29.25*(71.135)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (55.73+(5.888)+(segmentsAcked));

}
if (segmentsAcked < rfPAGonhcYkMplvx) {
	rfPAGonhcYkMplvx = (float) (90.282+(24.698)+(38.585)+(55.254));

} else {
	rfPAGonhcYkMplvx = (float) (rfPAGonhcYkMplvx*(89.103)*(17.172)*(17.694)*(51.962)*(55.694)*(13.411)*(61.28));

}
rfPAGonhcYkMplvx = (float) (tcb->m_segmentSize-(25.933)-(tcb->m_segmentSize)-(50.504)-(52.324)-(rfPAGonhcYkMplvx));
ReduceCwnd (tcb);
