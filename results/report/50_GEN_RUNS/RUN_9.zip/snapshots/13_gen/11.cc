tcb->m_cWnd = (int) (61.938-(-44.875));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-43.894*(-92.42)*(29.958)*(-47.141)*(39.305)*(32.529));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-48.525*(-62.037)*(-43.407)*(37.524)*(-40.399)*(-40.838));
