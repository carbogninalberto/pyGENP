tcb->m_cWnd = (int) (71.491-(-92.376));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-7.237*(5.121)*(86.644)*(-67.553)*(95.711)*(48.344));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-85.629*(-87.765)*(-59.801)*(63.989)*(67.325)*(-64.772));
