CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (0.1/9.466);

} else {
	tcb->m_segmentSize = (int) (97.578-(27.523)-(34.074));
	tcb->m_ssThresh = (int) (18.695*(83.912)*(7.675)*(3.72)*(44.07)*(segmentsAcked)*(58.611)*(70.75)*(57.388));
	segmentsAcked = (int) (37.585+(16.146)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(76.009)+(tcb->m_ssThresh));

}
tcb->m_segmentSize = (int) (65.898-(57.259)-(52.004)-(49.53)-(70.115)-(tcb->m_cWnd)-(84.215)-(96.207));
tcb->m_segmentSize = (int) ((30.971-(68.354)-(44.156)-(43.65)-(77.15)-(34.577)-(tcb->m_ssThresh))/0.1);
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (25.218-(5.146)-(82.826)-(tcb->m_ssThresh)-(33.493)-(92.237)-(5.325)-(10.477));

} else {
	tcb->m_cWnd = (int) (78.022*(69.949)*(88.101)*(tcb->m_ssThresh)*(89.086)*(18.635)*(64.81)*(29.371));
	tcb->m_ssThresh = (int) (89.885+(68.705)+(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
