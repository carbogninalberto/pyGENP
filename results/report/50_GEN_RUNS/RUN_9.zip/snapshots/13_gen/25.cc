CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_segmentSize*(83.979)*(53.873)*(36.873)*(84.372)*(13.534)*(32.934)*(82.604)*(60.877));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.84-(61.424));
	segmentsAcked = (int) (23.274-(45.711)-(32.355)-(74.842)-(74.812)-(21.632));
	tcb->m_cWnd = (int) (21.885*(7.808)*(74.339)*(segmentsAcked)*(13.989)*(31.683)*(82.662)*(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(74.278)+(tcb->m_cWnd)+(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);

}
