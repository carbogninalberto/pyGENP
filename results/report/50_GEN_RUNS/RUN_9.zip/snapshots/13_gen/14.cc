float uFodLbEcTPIPbMKw = (float) (-67.596/(-5.392*(56.061)*(-89.348)*(-80.156)*(-28.124)));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (uFodLbEcTPIPbMKw-(22.731)-(uFodLbEcTPIPbMKw)-(86.459)-(14.734));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(segmentsAcked)-(18.723)-(-69.476)-(87.214)-(70.362));

}
