CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (50.515-(55.602)-(-54.102)-(-26.612)-(-89.267)-(27.057));
segmentsAcked = (int) (-11.974*(91.362)*(38.137)*(80.471)*(-31.592)*(-1.407));
tcb->m_cWnd = (int) (((33.76)+((-74.426-(tcb->m_ssThresh)-(-96.441)-(tcb->m_ssThresh)-(67.373)-(-73.72)-(-5.248)-(1.183)-(45.767)))+(-12.717)+(88.348))/((41.498)));
ReduceCwnd (tcb);
