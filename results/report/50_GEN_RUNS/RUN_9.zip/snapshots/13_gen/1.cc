float SKJEuBklaRvsNqPb = (float) (-27.588/64.109);
int ZfuazjNIPkdgJpzr = (int) (12.687+(-36.34)+(21.534)+(-4.643)+(87.245)+(39.68)+(-73.716));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
