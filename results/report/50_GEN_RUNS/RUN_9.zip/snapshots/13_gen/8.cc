tcb->m_segmentSize = (int) (64.875-(59.034)-(-26.771));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (62.05-(82.73)-(segmentsAcked)-(86.601)-(46.351)-(55.315)-(22.702)-(86.326)-(98.623));

} else {
	tcb->m_cWnd = (int) (22.192+(6.744));
	tcb->m_segmentSize = (int) ((tcb->m_segmentSize-(90.909)-(77.761)-(71.682)-(tcb->m_segmentSize)-(segmentsAcked)-(tcb->m_segmentSize))/47.34);

}
segmentsAcked = (int) (-64.186+(63.406)+(57.365)+(-18.344));
