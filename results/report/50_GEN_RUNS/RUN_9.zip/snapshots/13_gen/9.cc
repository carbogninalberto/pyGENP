tcb->m_cWnd = (int) (-29.632-(-12.938));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (-81.439*(18.396)*(-87.407)*(-98.14)*(-47.598)*(-85.958));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-46.395*(75.276)*(-22.379)*(-27.818)*(46.604)*(-80.229));
