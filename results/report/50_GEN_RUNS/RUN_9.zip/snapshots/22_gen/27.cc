tcb->m_segmentSize = (int) (0.1/0.1);
tcb->m_cWnd = (int) (((69.206)+(57.721)+(0.1)+((46.678*(tcb->m_segmentSize)*(99.648)))+(0.1))/((75.855)+(0.1)+(16.698)+(62.602)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
