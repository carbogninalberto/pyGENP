float rnUEZZfoUEbsNhOt = (float) (40.15-(tcb->m_ssThresh)-(3.072)-(2.96)-(5.937)-(93.328)-(26.761)-(90.949));
int HhzHwKroyjWhnXPY = (int) (74.368+(61.988)+(27.399)+(5.72)+(46.439));
int naBqstCGaHqdYUqb = (int) (rnUEZZfoUEbsNhOt-(52.617));
if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) (tcb->m_segmentSize+(27.857));

} else {
	segmentsAcked = (int) (28.993-(HhzHwKroyjWhnXPY)-(35.423)-(92.608)-(tcb->m_cWnd)-(73.252)-(37.954));
	tcb->m_cWnd = (int) (89.399-(51.213)-(80.095)-(16.469)-(tcb->m_cWnd)-(44.108));
	HhzHwKroyjWhnXPY = (int) (14.977*(51.132)*(61.599)*(88.839)*(93.989)*(82.167)*(rnUEZZfoUEbsNhOt)*(70.596)*(92.426));

}
naBqstCGaHqdYUqb = (int) (26.578*(30.756)*(64.655));
int CaqqehmlucNNRNwJ = (int) (((68.838)+((21.63+(3.449)+(69.249)+(72.502)))+((7.887-(rnUEZZfoUEbsNhOt)-(13.736)-(11.924)-(48.492)))+(0.1)+(0.1)+(4.652)+(0.1))/((65.276)+(0.1)));
if (segmentsAcked >= tcb->m_ssThresh) {
	CaqqehmlucNNRNwJ = (int) (29.099*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(75.912)*(42.655));

} else {
	CaqqehmlucNNRNwJ = (int) (segmentsAcked-(74.149)-(98.216)-(HhzHwKroyjWhnXPY)-(tcb->m_segmentSize)-(94.065));

}
