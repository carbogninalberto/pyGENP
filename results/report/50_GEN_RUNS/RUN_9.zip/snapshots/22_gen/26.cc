segmentsAcked = (int) (97.394+(87.894)+(26.19)+(71.235)+(segmentsAcked)+(76.417)+(7.902)+(48.892)+(39.056));
int pfRrvwQigksKqiHV = (int) (80.895/22.857);
int sJSDhUgALGTAgXpk = (int) (((15.159)+((64.411*(44.948)*(89.305)*(9.155)*(pfRrvwQigksKqiHV)))+(0.1)+(0.1)+(0.1))/((0.1)+(48.832)+(0.1)));
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	pfRrvwQigksKqiHV = (int) (tcb->m_ssThresh-(tcb->m_ssThresh)-(86.076)-(80.092)-(48.467)-(86.632)-(58.803)-(5.573));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(20.746)+(15.097)+(44.811)+(44.087)+(94.523));

} else {
	pfRrvwQigksKqiHV = (int) (89.545+(37.138)+(21.846)+(99.408)+(sJSDhUgALGTAgXpk)+(29.118)+(8.232)+(34.81)+(pfRrvwQigksKqiHV));

}
sJSDhUgALGTAgXpk = (int) (44.499-(43.414)-(27.897)-(96.639)-(81.737)-(30.708)-(pfRrvwQigksKqiHV));
float jMQVNCdudJlFtdIr = (float) (99.312-(59.696)-(95.538)-(68.861)-(34.562)-(53.524)-(87.814));
