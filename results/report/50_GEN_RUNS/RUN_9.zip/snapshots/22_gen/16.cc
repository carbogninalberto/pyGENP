if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (79.154+(26.245));
	segmentsAcked = (int) (42.132*(67.963)*(tcb->m_segmentSize)*(73.413)*(25.06)*(segmentsAcked));
	tcb->m_segmentSize = (int) (13.03+(2.282)+(tcb->m_ssThresh)+(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (61.132-(segmentsAcked)-(7.37));
	segmentsAcked = (int) ((7.416*(segmentsAcked)*(48.927)*(25.125))/59.787);
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(23.68)+(27.881)+(tcb->m_cWnd)+(24.778));

}
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (56.028+(50.74)+(tcb->m_cWnd)+(92.135)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(41.265)+(16.327)+(10.613)+(54.365)+(tcb->m_cWnd)+(39.088));

} else {
	tcb->m_ssThresh = (int) (28.074-(segmentsAcked)-(65.521));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (91.183+(tcb->m_ssThresh)+(94.533)+(40.401)+(40.763));
	tcb->m_segmentSize = (int) (73.652+(64.265)+(30.4));
	segmentsAcked = (int) (9.138+(tcb->m_ssThresh)+(58.194)+(7.437)+(36.265)+(31.077)+(79.202)+(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (18.718+(78.848)+(62.709)+(82.452)+(18.8)+(74.344)+(tcb->m_segmentSize)+(2.24)+(72.816));

}
tcb->m_ssThresh = (int) (39.937+(70.089)+(64.055));
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (78.017*(7.871)*(98.418));
	tcb->m_ssThresh = (int) (43.319*(segmentsAcked)*(50.831)*(62.273)*(63.202)*(55.239));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(73.575)+(73.496)+(30.544))/((0.1)+(59.39)+(0.1)+(60.124)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
