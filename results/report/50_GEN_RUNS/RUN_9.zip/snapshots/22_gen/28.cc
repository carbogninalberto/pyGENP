tcb->m_segmentSize = (int) (9.713*(18.607)*(tcb->m_ssThresh)*(80.039)*(37.917)*(tcb->m_segmentSize)*(23.56)*(9.931)*(94.455));
if (segmentsAcked < tcb->m_ssThresh) {
	segmentsAcked = (int) (91.219-(47.173)-(17.334)-(77.934)-(35.379)-(75.79)-(33.716)-(88.557)-(segmentsAcked));

} else {
	segmentsAcked = (int) (((46.635)+(29.52)+(0.1)+(0.1)+(0.1))/((16.157)+(0.1)+(52.178)));

}
tcb->m_ssThresh = (int) (31.143+(18.3)+(84.731)+(tcb->m_cWnd)+(76.658)+(83.716)+(tcb->m_cWnd)+(tcb->m_ssThresh));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((35.811)+(0.1)+(86.235)+(0.1)+(61.982)+((11.143*(86.822)*(79.026)*(91.31)*(58.769)))+(79.468)+(0.1))/((26.452)));
