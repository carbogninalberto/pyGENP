if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (32.406*(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (1.835+(tcb->m_cWnd)+(22.057)+(19.561)+(82.363)+(12.628)+(1.997));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) ((((24.116+(37.085)+(68.16)+(86.322)+(17.066)+(tcb->m_cWnd)+(18.567)+(7.154)+(segmentsAcked)))+(8.269)+((22.733*(66.419)*(tcb->m_segmentSize)*(16.273)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(53.965)*(43.302)))+(91.644)+(0.1))/((0.1)+(25.026)+(86.182)+(31.456)));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (65.567+(segmentsAcked)+(66.409)+(77.353)+(50.013)+(34.353));

} else {
	tcb->m_cWnd = (int) (36.278-(tcb->m_ssThresh)-(11.378)-(51.458)-(70.609)-(tcb->m_segmentSize)-(83.163)-(8.189));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (32.82*(24.161)*(tcb->m_ssThresh)*(76.186));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
