if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (77.372+(84.551)+(22.302)+(48.047)+(39.004));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (84.638+(14.516)+(tcb->m_segmentSize)+(4.696)+(70.047)+(78.848)+(90.324)+(79.419));
	CongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
int vUXirTPXdJqsipYb = (int) (49.957*(94.984));
tcb->m_ssThresh = (int) (63.437*(4.333)*(47.726)*(41.536)*(65.736)*(tcb->m_ssThresh)*(53.024)*(62.214));
ReduceCwnd (tcb);
