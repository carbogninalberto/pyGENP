int OsJNmUquCDCGwTSI = (int) 54.434;
if (segmentsAcked != segmentsAcked) {
	segmentsAcked = (int) (((0.1)+(0.1)+(1.996)+(0.1))/((80.34)+(50.966)+(78.468)));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (99.339*(98.04)*(51.031)*(-12.368)*(-14.072)*(tcb->m_segmentSize));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
