int wtLiXXihccKMaeWj = (int) (-92.613*(63.393)*(-54.613)*(-34.89)*(42.603));
wtLiXXihccKMaeWj = (int) (-67.841*(26.222)*(37.411)*(65.251)*(58.104)*(74.532)*(-92.963));
segmentsAcked = (int) (67.634*(48.336));
if (tcb->m_cWnd > wtLiXXihccKMaeWj) {
	tcb->m_segmentSize = (int) (46.814-(36.802));

} else {
	tcb->m_segmentSize = (int) (7.419+(54.119)+(segmentsAcked)+(37.284)+(66.506)+(42.041)+(wtLiXXihccKMaeWj));

}
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) ((((79.859-(64.768)-(5.114)-(69.871)-(14.635)-(0.7)-(59.488)))+(0.1)+(98.852)+(27.223))/((0.1)+(97.5)));

} else {
	tcb->m_cWnd = (int) (18.784*(86.603)*(78.714)*(segmentsAcked)*(17.828)*(16.889)*(20.201)*(35.907));
	wtLiXXihccKMaeWj = (int) (tcb->m_segmentSize-(18.578)-(40.996)-(27.029)-(46.131)-(24.458)-(tcb->m_cWnd)-(75.424));

}
segmentsAcked = (int) (-77.228*(81.548));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd > wtLiXXihccKMaeWj) {
	tcb->m_segmentSize = (int) (46.814-(36.802));

} else {
	tcb->m_segmentSize = (int) (7.419+(54.119)+(segmentsAcked)+(37.284)+(66.506)+(42.041)+(wtLiXXihccKMaeWj));

}
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) ((((79.859-(64.768)-(5.114)-(69.871)-(14.635)-(0.7)-(59.488)))+(0.1)+(98.852)+(27.223))/((0.1)+(97.5)));

} else {
	tcb->m_cWnd = (int) (18.784*(86.603)*(78.714)*(segmentsAcked)*(17.828)*(16.889)*(20.201)*(35.907));
	wtLiXXihccKMaeWj = (int) (tcb->m_segmentSize-(18.578)-(40.996)-(27.029)-(46.131)-(24.458)-(tcb->m_cWnd)-(75.424));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
