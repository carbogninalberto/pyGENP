tcb->m_ssThresh = (int) (45.167*(7.089)*(92.47)*(48.255)*(33.193)*(59.15)*(74.282)*(3.941)*(17.002));
if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) (32.788+(14.342)+(tcb->m_ssThresh)+(16.18)+(42.615)+(86.178)+(48.069));
	tcb->m_cWnd = (int) (tcb->m_cWnd*(14.911)*(97.033));

} else {
	segmentsAcked = (int) ((((tcb->m_cWnd*(22.146)*(tcb->m_cWnd)))+(0.1)+((tcb->m_ssThresh*(11.239)*(segmentsAcked)*(69.767)*(64.546)*(31.115)*(74.274)*(87.852)))+(77.685))/((16.068)+(0.1)+(0.1)+(25.086)));

}
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) ((((1.188-(72.517)-(25.688)-(42.175)-(61.228)-(segmentsAcked)-(82.792)-(4.374)-(segmentsAcked)))+(10.779)+(46.774)+(0.1))/((45.293)+(41.517)+(0.1)+(0.1)+(64.523)));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(79.079)*(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(16.499)+(14.749)+(80.441)+(15.207));
	tcb->m_segmentSize = (int) (69.364-(8.738)-(85.291)-(3.926)-(tcb->m_segmentSize)-(72.654));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked != segmentsAcked) {
	tcb->m_cWnd = (int) (((0.1)+(74.428)+(74.666)+((tcb->m_cWnd*(46.337)))+(43.538))/((0.1)));
	segmentsAcked = (int) (16.816*(37.794)*(tcb->m_cWnd)*(12.104)*(88.62)*(29.995));

} else {
	tcb->m_cWnd = (int) (55.933+(79.67)+(85.845));
	ReduceCwnd (tcb);

}
