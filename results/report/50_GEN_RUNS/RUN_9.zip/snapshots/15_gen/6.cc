int wtLiXXihccKMaeWj = (int) (-98.337*(73.424)*(-75.107)*(-40.431)*(-80.281));
segmentsAcked = (int) (-74.853*(86.995));
