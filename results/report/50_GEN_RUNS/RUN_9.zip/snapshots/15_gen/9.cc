tcb->m_segmentSize = (int) (33.791*(4.016)*(-87.247)*(81.973)*(50.505));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-88.512+(-33.829)+(65.386)+(-79.641)+(88.443));
segmentsAcked = SlowStart (tcb, segmentsAcked);
