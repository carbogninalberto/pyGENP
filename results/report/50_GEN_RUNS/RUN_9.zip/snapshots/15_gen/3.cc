tcb->m_cWnd = (int) ((8.788+(94.543)+(53.812)+(75.504)+(-11.24)+(97.846)+(segmentsAcked))/-95.473);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
