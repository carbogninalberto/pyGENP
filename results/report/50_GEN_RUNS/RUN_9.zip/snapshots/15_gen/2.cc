tcb->m_cWnd = (int) (-15.53-(-26.25));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-45.413*(40.884)*(29.788)*(92.313)*(-26.297)*(-96.476));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (84.037*(48.413)*(44.384)*(-68.383)*(54.323)*(52.022));
