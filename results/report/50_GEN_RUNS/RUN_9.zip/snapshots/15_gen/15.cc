if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(54.892)+(80.79)+(20.291));

} else {
	tcb->m_ssThresh = (int) (9.059-(segmentsAcked)-(tcb->m_segmentSize)-(91.843)-(tcb->m_segmentSize)-(68.157)-(53.495));
	tcb->m_ssThresh = (int) (23.575+(95.192)+(tcb->m_cWnd)+(80.515)+(21.807));

}
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_segmentSize = (int) (38.458*(37.96)*(tcb->m_cWnd)*(96.726)*(66.087)*(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (99.179*(38.886)*(18.723)*(12.929)*(4.13)*(58.565)*(60.697));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (segmentsAcked-(tcb->m_cWnd)-(81.841)-(tcb->m_segmentSize));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(18.404));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (18.017+(66.232)+(tcb->m_segmentSize)+(95.998)+(22.756)+(64.523));

}
