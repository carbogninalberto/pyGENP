CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-86.543-(-92.064));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) ((((30.358*(32.462)*(6.848)*(34.852)*(2.45)*(28.58)))+((12.813+(segmentsAcked)+(88.403)+(18.65)+(tcb->m_ssThresh)+(82.606)+(64.737)))+((29.881-(56.174)-(52.895)-(41.611)))+(31.187))/((0.1)));
	tcb->m_cWnd = (int) (84.821*(59.256)*(segmentsAcked)*(tcb->m_cWnd)*(69.792)*(80.819)*(98.489));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(28.679)-(21.634)-(81.18)-(73.556)-(33.229)-(tcb->m_cWnd)-(27.672));

}
