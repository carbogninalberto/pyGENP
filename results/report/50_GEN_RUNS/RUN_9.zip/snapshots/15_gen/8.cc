float PGFdRSosQMouVYww = (float) 2.371;
tcb->m_cWnd = (int) (-56.903-(3.685)-(-52.747)-(64.812)-(28.69)-(-7.647));
float RFdNuvUVjQhFebqP = (float) 5.637;
CongestionAvoidance (tcb, segmentsAcked);
PGFdRSosQMouVYww = (float) (2.607+(16.424)+(-96.598)+(-92.938));
