segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (87.125+(99.184)+(0.829)+(43.911)+(11.233)+(tcb->m_segmentSize)+(57.734));
int URGXkFPIXJnMUmPG = (int) (24.255-(31.535)-(97.379)-(35.711)-(72.134));
int MBUhCPCcScmFlQUK = (int) (17.277+(URGXkFPIXJnMUmPG)+(tcb->m_segmentSize)+(53.416)+(38.457)+(89.587));
tcb->m_ssThresh = (int) (16.88-(77.479)-(92.756)-(tcb->m_cWnd)-(61.023)-(URGXkFPIXJnMUmPG)-(70.72)-(9.208));
ReduceCwnd (tcb);
