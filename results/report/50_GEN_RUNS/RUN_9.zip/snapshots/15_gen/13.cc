tcb->m_cWnd = (int) (71.087-(85.016));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-31.946*(49.551)*(-88.868)*(-73.203)*(72.785)*(-45.963));
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (30.683*(-38.831)*(-18.414)*(13.004)*(-30.066)*(-19.171));
segmentsAcked = (int) (-6.017*(-77.16)*(-60.761)*(-49.453)*(-47.908)*(-64.04));
