tcb->m_cWnd = (int) (82.918-(-11.769));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (44.035*(-46.642)*(32.275)*(-31.94)*(33.175)*(73.889));
