CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (59.325*(45.541)*(-32.955));
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (29.121+(44.585)+(91.021)+(93.74)+(61.25)+(89.416)+(14.481)+(29.593)+(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (59.559-(61.447)-(48.269)-(41.875)-(40.797)-(12.269)-(-53.71));

}
