segmentsAcked = (int) (-5.7+(-0.694)+(62.517)+(21.352));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-30.991+(-0.331)+(32.893)+(-53.54)+(42.028));
