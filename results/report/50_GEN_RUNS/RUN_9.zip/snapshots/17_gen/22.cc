TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((0.1)+((60.319*(59.015)*(82.139)*(97.184)*(80.401)*(21.75)))+(0.1)+(0.1)+(11.982))/((0.1)));
	tcb->m_ssThresh = (int) (19.41*(63.378)*(93.356)*(46.961)*(48.591));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (19.576*(90.101)*(76.32)*(50.811)*(11.112)*(51.478)*(tcb->m_segmentSize)*(34.366)*(55.196));
	tcb->m_ssThresh = (int) (38.222-(52.677)-(71.119)-(14.123)-(2.491)-(88.607)-(tcb->m_ssThresh)-(44.83)-(6.09));

}
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_cWnd+(41.406)+(20.744));
segmentsAcked = SlowStart (tcb, segmentsAcked);
