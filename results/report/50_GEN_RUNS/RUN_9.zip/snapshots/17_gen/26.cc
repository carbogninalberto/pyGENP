CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (94.098-(13.173)-(tcb->m_cWnd)-(68.406)-(tcb->m_cWnd)-(1.397)-(31.548));
tcb->m_ssThresh = (int) (tcb->m_cWnd+(8.948));
segmentsAcked = (int) ((48.982*(1.344)*(tcb->m_cWnd)*(81.08)*(8.999)*(49.008)*(85.11))/76.66);
int bMXIMcBlmMkhCQzJ = (int) ((1.489+(tcb->m_cWnd)+(28.663)+(1.857)+(34.748)+(41.906)+(62.783)+(segmentsAcked))/97.74);
tcb->m_cWnd = (int) (99.536+(56.179)+(7.512));
