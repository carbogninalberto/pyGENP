ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (((17.728)+(0.1)+(64.445)+(0.1)+(13.076))/((79.902)+(0.1)+(22.076)));
	segmentsAcked = (int) (43.434+(29.2)+(tcb->m_ssThresh)+(53.265)+(25.58)+(96.983));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (65.924-(tcb->m_ssThresh)-(43.803)-(29.466)-(4.464)-(80.344)-(87.333)-(53.794));
	tcb->m_cWnd = (int) (10.292/0.1);

}
segmentsAcked = (int) ((41.622*(5.955)*(28.274)*(62.562)*(22.54)*(17.349)*(2.016)*(21.606)*(tcb->m_cWnd))/43.349);
segmentsAcked = (int) (16.642-(11.51)-(94.137)-(85.572)-(tcb->m_cWnd)-(28.903)-(82.327)-(tcb->m_segmentSize));
CongestionAvoidance (tcb, segmentsAcked);
