segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (0.1/0.1);
segmentsAcked = (int) (9.635-(tcb->m_segmentSize)-(49.62)-(segmentsAcked)-(19.18)-(14.003)-(43.275)-(18.367)-(0.263));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/62.882);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) ((tcb->m_cWnd-(89.593)-(22.292)-(12.705)-(21.314)-(90.153))/56.382);

} else {
	tcb->m_cWnd = (int) (0.578-(48.215));
	ReduceCwnd (tcb);

}
int ZShvfRGngZAHQrsY = (int) (((0.1)+((tcb->m_segmentSize+(32.648)+(39.041)+(42.975)+(74.812)+(tcb->m_ssThresh)+(20.105)+(30.961)+(85.382)))+(65.057)+(37.463)+(58.754)+(0.1)+(0.1))/((0.1)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (tcb->m_cWnd+(ZShvfRGngZAHQrsY)+(84.796)+(58.65)+(3.323)+(10.385));
if (tcb->m_cWnd > ZShvfRGngZAHQrsY) {
	ZShvfRGngZAHQrsY = (int) (18.407+(tcb->m_cWnd)+(ZShvfRGngZAHQrsY));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	ZShvfRGngZAHQrsY = (int) (48.507*(41.223));

}
