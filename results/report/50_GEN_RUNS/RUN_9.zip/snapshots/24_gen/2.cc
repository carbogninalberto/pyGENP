segmentsAcked = (int) (0.965*(25.405)*(-65.638)*(-53.823));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-35.848-(64.474));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-6.183-(-76.633)-(-50.634)-(8.582)-(40.56)-(-23.683)-(-5.178)-(-27.0));
if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (90.036*(77.335)*(79.529)*(61.549)*(55.303)*(13.696)*(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (19.703+(18.731)+(69.536)+(64.01)+(93.017));
	tcb->m_segmentSize = (int) (((0.1)+((4.429*(95.242)*(4.998)*(4.955)*(70.467)*(5.888)*(tcb->m_ssThresh)))+(74.065)+(0.1)+(0.1))/((0.1)+(0.1)+(40.1)));
	segmentsAcked = (int) (79.412-(68.854)-(37.108)-(45.635));

}
