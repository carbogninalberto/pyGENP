if (tcb->m_segmentSize < segmentsAcked) {
	segmentsAcked = (int) (1.008*(41.928)*(10.005)*(-18.214)*(52.188)*(66.795)*(77.109)*(tcb->m_cWnd));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (-18.067*(30.217)*(32.733)*(89.285)*(74.817)*(54.974)*(94.698));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-50.322-(-92.575));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-46.576-(10.616)-(-56.274)-(-85.884)-(83.535)-(72.366)-(46.694)-(-35.243));
tcb->m_cWnd = (int) (30.473-(1.774)-(34.166)-(-33.917)-(99.416)-(76.922)-(93.931)-(-0.316));
if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (90.036*(77.335)*(79.529)*(61.549)*(55.303)*(13.696)*(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (19.703+(18.731)+(69.536)+(64.01)+(93.017));
	tcb->m_segmentSize = (int) (((0.1)+((4.429*(95.242)*(4.998)*(4.955)*(70.467)*(5.888)*(tcb->m_ssThresh)))+(74.065)+(0.1)+(0.1))/((0.1)+(0.1)+(40.1)));
	segmentsAcked = (int) (79.412-(68.854)-(37.108)-(63.521));

}
if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (19.703+(18.731)+(69.536)+(64.01)+(93.017));
	tcb->m_segmentSize = (int) (((0.1)+((4.429*(95.242)*(4.998)*(4.955)*(70.467)*(5.888)*(tcb->m_ssThresh)))+(74.065)+(0.1)+(0.1))/((0.1)+(0.1)+(40.1)));
	segmentsAcked = (int) (79.412-(68.854)-(37.108)-(-71.01));

} else {
	segmentsAcked = (int) (90.036*(77.335)*(79.529)*(61.549)*(55.303)*(13.696)*(tcb->m_segmentSize));

}
