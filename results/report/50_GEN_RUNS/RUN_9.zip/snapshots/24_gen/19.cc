if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (38.908-(49.361)-(tcb->m_ssThresh)-(5.923)-(80.528));
	tcb->m_cWnd = (int) (47.679-(13.729)-(tcb->m_segmentSize)-(90.808)-(26.94));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(segmentsAcked)-(88.596)-(31.861)-(83.595)-(48.547)-(60.135)-(53.507));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (35.773-(76.681)-(90.556)-(83.179));
	tcb->m_ssThresh = (int) (78.818-(72.997)-(71.058)-(segmentsAcked)-(57.429)-(71.976));
	tcb->m_ssThresh = (int) (62.958*(37.799)*(21.876)*(tcb->m_ssThresh)*(40.923)*(tcb->m_ssThresh)*(62.78)*(61.475));

} else {
	tcb->m_ssThresh = (int) (17.844+(segmentsAcked)+(tcb->m_cWnd)+(segmentsAcked)+(79.086)+(1.79)+(70.402)+(49.413));
	tcb->m_segmentSize = (int) ((tcb->m_segmentSize-(23.623)-(90.466)-(78.348))/0.1);
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (43.611+(tcb->m_cWnd)+(tcb->m_segmentSize)+(91.124));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (61.884+(87.246)+(20.61)+(segmentsAcked)+(30.428)+(57.713));
tcb->m_cWnd = (int) (3.971+(42.901)+(tcb->m_ssThresh)+(2.619)+(11.239)+(61.421)+(83.772)+(10.758)+(95.88));
