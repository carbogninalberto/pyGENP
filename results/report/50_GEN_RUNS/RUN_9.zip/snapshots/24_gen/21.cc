tcb->m_segmentSize = (int) (99.287*(35.835));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(59.972)+(16.247)+(7.858)+(12.704)+(41.722));
	tcb->m_cWnd = (int) (60.9+(33.295)+(57.727)+(40.466)+(tcb->m_segmentSize)+(72.357)+(28.191));

} else {
	tcb->m_ssThresh = (int) (33.261+(4.989)+(36.729)+(segmentsAcked)+(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(tcb->m_ssThresh)*(61.453)*(48.903)*(tcb->m_segmentSize));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (13.991+(tcb->m_ssThresh)+(68.232)+(9.169));
	tcb->m_segmentSize = (int) ((tcb->m_segmentSize*(71.74)*(33.082))/0.1);

}
