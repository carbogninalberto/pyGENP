tcb->m_cWnd = (int) (20.493*(tcb->m_ssThresh)*(46.768)*(27.07)*(tcb->m_cWnd)*(16.048));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	segmentsAcked = (int) (7.16*(2.367)*(segmentsAcked)*(tcb->m_ssThresh)*(92.645)*(tcb->m_segmentSize)*(43.103)*(75.399));
	segmentsAcked = (int) (tcb->m_ssThresh+(56.471)+(69.936)+(5.742)+(61.239)+(76.623)+(tcb->m_cWnd)+(71.0));
	tcb->m_cWnd = (int) (95.345+(58.102));

} else {
	segmentsAcked = (int) (92.441*(15.246)*(83.811)*(86.168)*(65.892)*(46.335)*(22.118)*(61.932)*(45.735));
	tcb->m_cWnd = (int) (80.999-(18.876)-(44.685)-(segmentsAcked)-(54.988)-(63.682)-(80.87));
	tcb->m_cWnd = (int) (69.998*(tcb->m_cWnd));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (13.688-(63.704)-(94.206)-(0.467)-(8.48)-(27.626));
