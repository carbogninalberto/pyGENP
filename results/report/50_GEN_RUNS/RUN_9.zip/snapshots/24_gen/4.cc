int WnUzkMHdEZUdyUkw = (int) (-1.739/-1.686);
tcb->m_cWnd = (int) (-75.683+(-1.859)+(-15.443)+(14.576));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
