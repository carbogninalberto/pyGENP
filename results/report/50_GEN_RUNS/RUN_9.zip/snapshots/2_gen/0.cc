int hXqbDMfvMugmOTJa = (int) (-64.999/(85.681+(73.734)+(-22.744)+(-55.377)+(-60.667)+(2.686)));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (96.131-(3.075)-(16.638)-(88.464)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.571)-(25.867)-(14.467));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (1.546-(19.242)-(4.82)-(49.253)-(81.394)-(45.618)-(47.342)-(87.363));

}
hXqbDMfvMugmOTJa = (int) (7.213-(-34.889)-(61.612)-(24.192)-(-13.626)-(84.56));
segmentsAcked = (int) (27.04+(-11.168)+(-63.778)+(-96.647)+(-68.122)+(30.36)+(-17.985)+(60.177));
