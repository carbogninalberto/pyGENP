float PJtjlZlYXQfuuZWE = (float) (39.416+(-47.658)+(-11.21)+(-24.224)+(45.694)+(-8.207)+(-91.324));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float vWpcWjHVGpNiIzHW = (float) (-71.01*(-52.199)*(53.193)*(28.983)*(-73.39)*(76.129)*(99.215)*(-38.327)*(72.977));
if (segmentsAcked != PJtjlZlYXQfuuZWE) {
	PJtjlZlYXQfuuZWE = (float) (((0.1)+(0.1)+((9.571-(99.377)-(86.214)-(36.288)))+(0.1)+((39.345-(11.057)-(PJtjlZlYXQfuuZWE)))+(0.1))/((36.139)));

} else {
	PJtjlZlYXQfuuZWE = (float) (((0.1)+(0.1)+(84.519)+(34.711)+(0.1)+(0.1)+(67.313))/((51.864)));
	segmentsAcked = (int) (61.879+(tcb->m_segmentSize)+(20.863)+(59.135)+(17.817)+(96.384)+(95.511));
	tcb->m_segmentSize = (int) (45.536-(70.233)-(17.934)-(86.609)-(74.936)-(62.812)-(68.312)-(44.736)-(70.638));

}
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_cWnd = (int) (((0.1)+(47.078)+(29.533)+(21.63))/((0.1)));

} else {
	tcb->m_cWnd = (int) (((0.1)+(7.686)+((74.666-(tcb->m_ssThresh)-(14.389)-(60.771)-(PJtjlZlYXQfuuZWE)-(tcb->m_segmentSize)-(PJtjlZlYXQfuuZWE)-(37.329)))+(15.558)+(0.1))/((0.1)+(77.754)+(92.753)+(81.711)));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
