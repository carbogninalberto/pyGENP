float hwEDqSlIBHuTKEtp = (float) (-18.639+(-17.381));
tcb->m_cWnd = (int) (-52.472*(63.168)*(14.198)*(-30.255)*(-72.468));
int NuAVXXGFEywZmGey = (int) 18.448;
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-40.251+(41.962)+(-9.848)+(41.756)+(-88.106)+(-22.089)+(-1.729)+(84.037));
CongestionAvoidance (tcb, segmentsAcked);
