float qnENNvcAZAJWOrOC = (float) (7.365-(98.639)-(-36.668)-(-70.334)-(23.285)-(10.353)-(30.137)-(39.375)-(85.211));
qnENNvcAZAJWOrOC = (float) (-40.963-(-22.209)-(-6.624)-(37.907)-(40.039)-(53.22)-(-63.728)-(-99.098)-(-59.068));
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
