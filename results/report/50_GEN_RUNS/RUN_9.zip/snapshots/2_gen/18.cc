float qnENNvcAZAJWOrOC = (float) (-47.897-(28.35)-(-81.263)-(-88.713)-(-95.403)-(39.024)-(38.114)-(-5.004)-(30.932));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
qnENNvcAZAJWOrOC = (float) (-39.158-(-29.353)-(38.903)-(79.304)-(42.615)-(54.87)-(-31.338));
