int kIpLkAcESCUmruKl = (int) (((58.005)+(-54.041)+((80.236-(-87.698)-(54.94)-(39.973)-(21.177)-(42.988)))+(-34.466)+(-15.519)+(-10.854))/((-33.304)+(-24.12)));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-90.211*(-30.106)*(-77.941)*(-80.222)*(-32.753)*(-88.099));
