float qnENNvcAZAJWOrOC = (float) 59.702;
