tcb->m_segmentSize = (int) (63.702-(54.996)-(89.011)-(81.979)-(50.964)-(4.1)-(66.518));
tcb->m_ssThresh = (int) (18.483*(30.796)*(61.421));
tcb->m_segmentSize = (int) (98.869*(65.496)*(90.302)*(tcb->m_cWnd)*(83.571)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(70.627));
tcb->m_ssThresh = (int) (87.065-(1.215)-(tcb->m_ssThresh)-(74.531)-(11.756));
tcb->m_ssThresh = (int) ((16.266-(56.213)-(67.445)-(92.191)-(15.35)-(68.257)-(tcb->m_segmentSize)-(segmentsAcked))/36.791);
