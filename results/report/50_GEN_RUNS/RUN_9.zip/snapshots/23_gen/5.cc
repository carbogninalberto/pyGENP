if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (65.842*(segmentsAcked)*(segmentsAcked)*(25.262)*(32.028)*(9.471)*(72.552));

} else {
	tcb->m_segmentSize = (int) (91.753+(tcb->m_cWnd)+(62.059)+(22.504)+(29.344)+(30.468)+(tcb->m_cWnd));
	tcb->m_cWnd = (int) (51.44-(7.403)-(23.549)-(tcb->m_ssThresh)-(22.788)-(26.21)-(2.501)-(segmentsAcked)-(37.161));

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(53.822)-(93.926)-(65.656)-(42.299)-(46.64)-(tcb->m_segmentSize)-(68.597)-(61.066));
	tcb->m_cWnd = (int) (59.452+(tcb->m_cWnd)+(65.056)+(83.038)+(49.499)+(81.255)+(76.982)+(58.634));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (47.622/0.1);
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (76.006+(44.717)+(49.027)+(26.712)+(74.957)+(40.981));

}
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (90.074+(46.637)+(56.462)+(38.459)+(20.665)+(12.709)+(tcb->m_segmentSize)+(60.606)+(82.665));

} else {
	tcb->m_cWnd = (int) (70.656-(98.816)-(12.401)-(8.479));
	tcb->m_cWnd = (int) (16.864-(13.811));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (38.341+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(95.498)+(97.002)+(95.118)+(33.058));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
