if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((((87.368+(17.103)+(tcb->m_cWnd)))+(0.1)+(7.197)+(0.1)+(0.1)+(57.854)+(0.1))/((99.37)+(80.24)));
	tcb->m_segmentSize = (int) (6.786*(10.651)*(77.598));

} else {
	tcb->m_segmentSize = (int) (32.035*(64.176)*(18.705)*(1.579)*(85.433)*(1.372));
	tcb->m_ssThresh = (int) (12.051-(30.114)-(91.842)-(91.427)-(44.752)-(2.973)-(segmentsAcked));
	tcb->m_cWnd = (int) (segmentsAcked-(25.425));

}
tcb->m_segmentSize = (int) (segmentsAcked-(3.262)-(6.534)-(tcb->m_ssThresh)-(80.102)-(6.724)-(0.947));
segmentsAcked = (int) (82.483-(19.828)-(37.559)-(29.489)-(segmentsAcked)-(tcb->m_ssThresh)-(tcb->m_ssThresh));
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.1+(92.428)+(77.457)+(86.521));
	segmentsAcked = (int) (22.361*(97.849)*(tcb->m_ssThresh)*(96.141)*(54.625));

} else {
	tcb->m_ssThresh = (int) (28.566+(37.504)+(34.942)+(60.774)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(67.745)+(50.542)+(69.821));
	segmentsAcked = (int) (96.914-(77.366)-(51.749));
	tcb->m_segmentSize = (int) (0.1/29.442);

}
segmentsAcked = (int) (1.96+(72.669)+(segmentsAcked)+(51.05)+(56.389)+(tcb->m_segmentSize));
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (26.932+(59.359)+(10.449)+(39.443)+(4.324)+(46.424)+(48.68)+(40.139)+(23.76));
	tcb->m_cWnd = (int) ((45.542+(64.171)+(95.887)+(74.95))/0.1);
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (42.515+(43.305)+(75.863));

}
