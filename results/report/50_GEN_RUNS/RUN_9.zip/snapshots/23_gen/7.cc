int WnUzkMHdEZUdyUkw = (int) (33.399/0.1);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (95.399*(82.358)*(44.383)*(52.618)*(WnUzkMHdEZUdyUkw)*(30.518));
if (segmentsAcked <= WnUzkMHdEZUdyUkw) {
	tcb->m_cWnd = (int) (73.675-(99.472)-(38.233)-(90.417));
	segmentsAcked = (int) (72.335-(43.881)-(82.398)-(45.003)-(10.369)-(tcb->m_segmentSize)-(64.8)-(78.579));

} else {
	tcb->m_cWnd = (int) (((45.582)+((58.774+(82.077)))+(79.063)+(0.1))/((0.1)));
	tcb->m_ssThresh = (int) (segmentsAcked-(97.873)-(tcb->m_ssThresh)-(segmentsAcked)-(segmentsAcked));

}
ReduceCwnd (tcb);
