ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-37.79+(3.479));
tcb->m_cWnd = (int) (-24.166*(-89.833)*(-20.964)*(32.663)*(-76.396));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd > tcb->m_cWnd) {
	segmentsAcked = (int) (7.717+(67.798)+(44.734));
	segmentsAcked = (int) (63.013+(9.673)+(70.278)+(3.786)+(7.425)+(tcb->m_cWnd)+(72.748));
	segmentsAcked = (int) (47.044+(28.502)+(54.34)+(57.168)+(segmentsAcked)+(72.212));

} else {
	segmentsAcked = (int) (57.654+(-53.977));

}
segmentsAcked = (int) (-23.986*(17.584)*(-89.648)*(70.62)*(11.584)*(79.261)*(-16.362)*(-63.827));
