TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (77.667-(20.461)-(4.713)-(24.405)-(33.509)-(55.616)-(8.961)-(89.407)-(37.484));
	segmentsAcked = (int) (((0.1)+(0.1)+(41.466)+(0.1)+(75.058)+(0.1)+((39.331*(92.206)*(tcb->m_segmentSize)*(83.689)*(65.866)*(43.522)))+(7.158))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(tcb->m_segmentSize)+(41.865)+(88.078)+(82.601)+(4.693)+(56.227));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (8.165*(52.046)*(74.613)*(95.911)*(70.662)*(80.629));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
