if (segmentsAcked > tcb->m_ssThresh) {
	segmentsAcked = (int) (48.518*(59.374)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(segmentsAcked)*(73.194)*(19.878)*(9.354)*(tcb->m_ssThresh));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (8.272*(0.431)*(95.576)*(tcb->m_cWnd)*(9.747));
	tcb->m_cWnd = (int) (82.832-(41.735)-(tcb->m_ssThresh)-(20.936)-(4.887)-(6.985)-(28.345));
	tcb->m_segmentSize = (int) (76.602/0.1);

}
ReduceCwnd (tcb);
float MywSJcnmHitVOTFV = (float) (segmentsAcked+(69.296)+(53.136)+(8.104)+(31.036)+(99.081));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (13.908*(tcb->m_cWnd)*(18.896)*(73.203)*(99.285)*(25.782)*(90.443)*(54.753));
tcb->m_ssThresh = (int) (tcb->m_cWnd-(18.382)-(71.886)-(81.589)-(84.906)-(tcb->m_cWnd));
