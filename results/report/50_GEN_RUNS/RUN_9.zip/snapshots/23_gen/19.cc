segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (24.921+(28.369)+(84.312)+(10.83)+(16.395)+(82.075)+(segmentsAcked)+(84.478)+(50.325));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (62.451-(25.56)-(30.888)-(42.901)-(42.798)-(19.681)-(19.489)-(99.088));
