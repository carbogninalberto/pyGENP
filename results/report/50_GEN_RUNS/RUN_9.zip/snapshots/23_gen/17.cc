if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (55.179-(59.282)-(50.492)-(16.329)-(2.235)-(83.239)-(24.291)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (69.315+(74.31)+(83.17)+(65.147)+(85.963)+(17.405)+(28.412)+(19.441)+(26.232));

}
float HIxaHEOLlFSHIkcB = (float) (0.515*(89.566)*(43.725)*(21.257)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(96.908)*(22.69)*(tcb->m_segmentSize));
HIxaHEOLlFSHIkcB = (float) (tcb->m_ssThresh+(80.478)+(tcb->m_cWnd));
tcb->m_ssThresh = (int) (36.609+(59.405)+(78.205)+(16.119));
if (tcb->m_segmentSize >= HIxaHEOLlFSHIkcB) {
	segmentsAcked = (int) (51.455-(HIxaHEOLlFSHIkcB)-(68.431));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (47.894+(46.272)+(45.624)+(tcb->m_ssThresh)+(74.516)+(76.884)+(84.777)+(tcb->m_segmentSize));

}
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	HIxaHEOLlFSHIkcB = (float) (31.131*(21.226)*(99.481)*(53.971)*(92.095)*(13.396)*(tcb->m_segmentSize)*(2.18)*(segmentsAcked));
	HIxaHEOLlFSHIkcB = (float) (71.216+(63.52)+(segmentsAcked)+(77.169)+(64.066));
	segmentsAcked = (int) (79.658+(94.207)+(45.734));

} else {
	HIxaHEOLlFSHIkcB = (float) (26.622/69.373);
	HIxaHEOLlFSHIkcB = (float) (95.271+(95.704)+(15.14)+(segmentsAcked)+(89.786)+(86.888));

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (79.623-(14.614)-(81.453)-(33.275)-(44.394)-(1.435));

} else {
	tcb->m_ssThresh = (int) (8.831+(37.7)+(78.204)+(43.338)+(26.175)+(78.848)+(59.947)+(13.592));
	tcb->m_segmentSize = (int) (72.036*(tcb->m_ssThresh)*(49.608)*(segmentsAcked)*(83.425)*(6.446)*(68.64));

}
