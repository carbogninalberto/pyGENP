int hQtFMrCgwiTlvvgt = (int) (tcb->m_ssThresh-(40.397));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (((98.857)+(0.1)+((9.829+(22.541)+(62.527)+(95.655)))+(50.243)+(0.1)+(0.1)+(86.997))/((0.1)));
int hpDJAxCixXyrxcGT = (int) (5.704-(31.216)-(71.219)-(25.371)-(38.995)-(65.942));
if (tcb->m_segmentSize <= segmentsAcked) {
	segmentsAcked = (int) (tcb->m_ssThresh*(20.785)*(tcb->m_ssThresh));
	hpDJAxCixXyrxcGT = (int) (11.556+(8.412)+(25.191)+(54.212));
	tcb->m_ssThresh = (int) (hQtFMrCgwiTlvvgt+(83.427)+(tcb->m_ssThresh)+(78.605)+(hpDJAxCixXyrxcGT)+(47.993));

} else {
	segmentsAcked = (int) (((20.688)+((29.18+(69.752)))+((97.972+(76.522)+(hQtFMrCgwiTlvvgt)+(37.288)))+(73.043)+(1.207)+(5.453))/((0.1)+(99.488)+(43.023)));
	hQtFMrCgwiTlvvgt = (int) (62.79-(0.403)-(7.803));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (hpDJAxCixXyrxcGT > hpDJAxCixXyrxcGT) {
	tcb->m_ssThresh = (int) (hpDJAxCixXyrxcGT-(80.909));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (29.801-(tcb->m_segmentSize)-(40.766)-(6.68)-(27.177));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(11.6)*(35.844)*(89.586)*(53.636)*(2.681)*(60.61)*(1.857)*(80.57));
	segmentsAcked = (int) (97.956*(58.679)*(tcb->m_cWnd)*(41.108)*(61.151)*(58.079)*(25.438)*(10.741)*(hpDJAxCixXyrxcGT));
	hpDJAxCixXyrxcGT = (int) (33.135-(37.687)-(77.187)-(95.921)-(7.956)-(30.244)-(45.866)-(76.566));

}
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((1.249)+((80.532*(1.276)))+(75.341)+(83.292)+(66.646)+(0.1))/((45.278)+(0.1)+(0.1)));
	hpDJAxCixXyrxcGT = (int) (98.78+(segmentsAcked)+(tcb->m_ssThresh)+(33.599)+(62.768)+(96.568)+(0.937));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(98.26)-(67.871)-(12.665)-(tcb->m_ssThresh)-(71.185)-(57.475)-(82.587));
	segmentsAcked = (int) (0.823*(82.391)*(72.047)*(86.704)*(16.431)*(12.451)*(52.522)*(69.128)*(82.281));

}
