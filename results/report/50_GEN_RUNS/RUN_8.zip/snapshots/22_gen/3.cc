if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(87.948)+(63.092)+(tcb->m_segmentSize)+(68.872)+(68.977)+(54.975)+(65.032)+(17.672));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+((25.441-(91.052)))+(0.1))/((42.695)+(13.777)+(0.1)+(6.795)));
	segmentsAcked = (int) (93.206-(32.948)-(3.502)-(17.579)-(19.091)-(12.02)-(82.045)-(54.46));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
int PRjagzcUCCnoEmgm = (int) (-38.0/14.349);
if (segmentsAcked == tcb->m_cWnd) {
	segmentsAcked = (int) (17.045-(93.998)-(7.13)-(35.668)-(43.597)-(segmentsAcked)-(-6.934)-(50.174));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (87.039*(68.99)*(30.985)*(13.841));

}
