ReduceCwnd (tcb);
ReduceCwnd (tcb);
float HIFmiOBxgBRCwgdp = (float) (64.676+(86.694)+(15.934)+(segmentsAcked)+(34.242)+(18.217)+(25.702)+(7.133)+(tcb->m_cWnd));
HIFmiOBxgBRCwgdp = (float) (0.1/0.1);
tcb->m_ssThresh = (int) (95.386+(21.658)+(tcb->m_ssThresh)+(segmentsAcked)+(29.771)+(71.043)+(35.649));
