segmentsAcked = (int) (25.644-(7.117)-(tcb->m_cWnd)-(tcb->m_segmentSize)-(26.075)-(99.748)-(20.855)-(87.085)-(72.136));
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	segmentsAcked = (int) (21.038/95.058);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (60.779-(78.856)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (2.386*(55.724)*(46.044));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (tcb->m_ssThresh*(38.925)*(91.343));
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (60.789*(tcb->m_segmentSize)*(85.346));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (52.447+(2.223)+(78.034)+(34.566)+(64.348)+(55.092)+(0.744));

}
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.968+(58.167)+(tcb->m_ssThresh)+(14.083)+(34.454));

} else {
	tcb->m_cWnd = (int) (34.299*(tcb->m_ssThresh)*(66.385)*(tcb->m_cWnd)*(11.67)*(75.981)*(76.591)*(92.735)*(tcb->m_cWnd));

}
segmentsAcked = (int) (14.547*(48.338)*(24.983));
tcb->m_segmentSize = (int) (70.476+(45.814));
tcb->m_segmentSize = (int) (76.019+(89.539));
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (58.117-(tcb->m_cWnd)-(37.053)-(18.384)-(81.746)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (82.107-(79.719)-(13.11)-(96.12)-(4.59)-(7.742)-(13.414)-(37.378));

}
