CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_cWnd = (int) (((0.1)+(86.484)+(0.1)+(65.735))/((0.1)+(31.242)+(15.324)+(0.1)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(86.502)*(62.021)*(75.198)*(21.311)*(tcb->m_segmentSize)*(74.995)*(10.555));
	tcb->m_ssThresh = (int) (34.752+(tcb->m_ssThresh)+(segmentsAcked)+(segmentsAcked)+(56.264)+(38.467)+(tcb->m_cWnd)+(91.36));

}
tcb->m_ssThresh = (int) (58.37+(tcb->m_ssThresh)+(2.048)+(39.211)+(17.31)+(tcb->m_ssThresh)+(42.496));
if (segmentsAcked >= segmentsAcked) {
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) ((89.033-(7.406)-(tcb->m_cWnd)-(61.656)-(46.445)-(65.261)-(47.538)-(73.962))/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (67.55*(50.735)*(83.603)*(37.334)*(62.273)*(98.195)*(5.009)*(91.353));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
