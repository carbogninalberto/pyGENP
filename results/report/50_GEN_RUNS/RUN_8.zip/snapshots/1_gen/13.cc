segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (43.467-(90.085));
	tcb->m_cWnd = (int) (94.129+(14.706));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (91.142*(48.961)*(39.395));
	segmentsAcked = (int) (tcb->m_cWnd*(41.297)*(27.782)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(87.666));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (31.797*(99.795)*(45.417)*(24.9)*(66.866)*(52.364)*(24.15)*(14.599));
tcb->m_ssThresh = (int) (38.941*(59.011)*(26.243)*(23.453));
ReduceCwnd (tcb);
