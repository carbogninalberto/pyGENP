segmentsAcked = (int) (33.94-(6.253)-(tcb->m_ssThresh));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (87.619*(segmentsAcked)*(48.114)*(19.183)*(51.997)*(54.072)*(20.139));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(12.486)*(77.994)*(3.934)*(2.855)*(5.059)*(7.837));
	tcb->m_segmentSize = (int) (((2.675)+((21.838*(tcb->m_cWnd)*(34.945)*(42.476)*(43.306)*(72.004)*(30.232)))+(5.929)+(68.113))/((76.011)));

}
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (72.131*(53.717));
	tcb->m_segmentSize = (int) (94.218-(17.581)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(45.948)-(40.174)-(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (10.503/91.309);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/23.342);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (16.947+(23.577)+(28.826));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(8.969)*(93.653)*(47.714));
	tcb->m_ssThresh = (int) (32.682*(6.185)*(91.73));

}
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (24.76-(tcb->m_cWnd)-(39.265)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (26.939+(81.89)+(tcb->m_ssThresh)+(85.634)+(20.279)+(33.647));

}
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((0.1)+((58.644-(41.92)-(6.12)-(tcb->m_ssThresh)-(15.326)-(tcb->m_ssThresh)-(91.213)-(tcb->m_ssThresh)-(segmentsAcked)))+(0.1)+(36.47)+(50.186))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (59.441+(21.522));

}
