int YlzbXvRvjgMOJJXD = (int) (10.576+(87.873)+(44.895)+(23.113)+(23.313)+(3.035));
float EUnajxpsIavjgndl = (float) (tcb->m_ssThresh*(15.936)*(59.353));
ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (52.766*(77.5)*(65.013));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	EUnajxpsIavjgndl = (float) (tcb->m_ssThresh-(71.328)-(EUnajxpsIavjgndl)-(79.703)-(98.081)-(59.334)-(89.389)-(17.605));

} else {
	tcb->m_ssThresh = (int) (0.1/48.615);
	EUnajxpsIavjgndl = (float) (84.43+(0.164)+(1.936)+(5.437));
	EUnajxpsIavjgndl = (float) (25.634*(7.719)*(43.029)*(36.497)*(YlzbXvRvjgMOJJXD)*(85.657));

}
tcb->m_segmentSize = (int) (67.85-(43.068)-(95.351));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (EUnajxpsIavjgndl > segmentsAcked) {
	tcb->m_segmentSize = (int) (86.037-(70.133)-(16.789)-(42.899));

} else {
	tcb->m_segmentSize = (int) (74.391-(11.346)-(62.355)-(5.181));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (10.913/0.1);

}
