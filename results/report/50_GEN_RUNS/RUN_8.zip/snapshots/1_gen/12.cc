tcb->m_ssThresh = (int) (((56.098)+(0.1)+((54.903+(8.68)+(21.904)))+(54.158)+(13.368))/((73.101)+(0.1)+(81.124)));
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_cWnd = (int) (73.796-(4.191)-(37.414)-(81.612)-(30.979)-(39.619)-(34.339));
	tcb->m_cWnd = (int) (((0.1)+(7.189)+(0.1)+(11.875)+(0.1)+(75.696))/((89.293)+(0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (40.274-(51.11)-(21.643)-(tcb->m_segmentSize)-(62.849)-(41.567)-(15.425)-(55.618)-(18.537));
	tcb->m_cWnd = (int) (70.597/(tcb->m_ssThresh+(44.653)+(74.253)+(48.195)+(97.27)));

}
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (67.708-(13.493)-(0.322)-(27.651)-(61.025)-(17.477)-(93.066)-(35.617));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (40.231+(segmentsAcked)+(31.773)+(56.9)+(75.246));
	tcb->m_segmentSize = (int) (0.1/53.07);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (64.849+(20.656)+(70.938)+(64.16));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (76.755-(tcb->m_cWnd));
tcb->m_ssThresh = (int) (70.99-(40.405)-(71.811)-(80.907)-(53.695)-(30.815)-(32.297)-(tcb->m_ssThresh));
