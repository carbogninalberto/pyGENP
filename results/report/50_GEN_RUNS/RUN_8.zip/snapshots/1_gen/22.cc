int FzBkgtYOUKWOFjfa = (int) (16.76/0.1);
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (44.323+(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (29.286+(85.365)+(26.12)+(tcb->m_ssThresh)+(18.973)+(80.054)+(30.58)+(66.062));

}
if (FzBkgtYOUKWOFjfa <= tcb->m_cWnd) {
	FzBkgtYOUKWOFjfa = (int) (26.315+(10.564));
	segmentsAcked = (int) (5.947-(2.508));

} else {
	FzBkgtYOUKWOFjfa = (int) ((61.439*(18.714)*(51.346))/80.623);
	tcb->m_cWnd = (int) (19.89*(47.116)*(44.025)*(50.787)*(36.769));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (FzBkgtYOUKWOFjfa < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (78.395-(tcb->m_cWnd)-(9.706)-(tcb->m_segmentSize)-(FzBkgtYOUKWOFjfa)-(tcb->m_ssThresh)-(FzBkgtYOUKWOFjfa)-(79.043)-(95.092));
	tcb->m_cWnd = (int) (((97.364)+(0.1)+(0.1)+(63.414)+(0.1)+(0.1))/((22.408)));

} else {
	tcb->m_ssThresh = (int) ((75.285*(58.799)*(tcb->m_ssThresh)*(73.416)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(tcb->m_ssThresh))/67.789);
	segmentsAcked = (int) (4.447+(84.661)+(49.64)+(46.838)+(62.109)+(72.923));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (0.1/68.932);
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((72.145)+(37.198)+(0.1)+(59.367))/((50.859)+(0.1)));

} else {
	tcb->m_ssThresh = (int) ((((25.924*(34.877)*(tcb->m_ssThresh)*(98.764)*(99.112)*(32.518)*(tcb->m_ssThresh)*(18.585)))+(0.1)+(25.103)+(0.1))/((0.1)+(0.1)));
	ReduceCwnd (tcb);
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	segmentsAcked = (int) (42.459-(65.444)-(97.329)-(77.298)-(56.8)-(73.962)-(63.855)-(8.832)-(segmentsAcked));

} else {
	segmentsAcked = (int) ((75.601*(27.296)*(57.016)*(FzBkgtYOUKWOFjfa)*(57.122)*(segmentsAcked))/80.326);
	FzBkgtYOUKWOFjfa = (int) (4.292+(56.873));

}
ReduceCwnd (tcb);
