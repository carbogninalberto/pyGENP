ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int zIhYPctUanIWpQPj = (int) (73.876*(6.395)*(segmentsAcked)*(21.06)*(0.979)*(68.475)*(3.97));
segmentsAcked = SlowStart (tcb, segmentsAcked);
