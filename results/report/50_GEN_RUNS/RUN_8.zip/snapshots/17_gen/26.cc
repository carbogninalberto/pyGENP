tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(48.122))/((0.1)+(0.1)+(74.349)+(29.121)));
int GVTRgaFhdbMKkvRA = (int) (73.833*(19.184)*(6.065)*(65.542));
GVTRgaFhdbMKkvRA = (int) (88.835*(55.732));
ReduceCwnd (tcb);
if (GVTRgaFhdbMKkvRA == segmentsAcked) {
	tcb->m_cWnd = (int) (98.432+(tcb->m_segmentSize)+(95.001)+(70.494));
	tcb->m_ssThresh = (int) (74.078*(32.756));

} else {
	tcb->m_cWnd = (int) (((0.1)+(37.444)+((1.439-(19.202)-(59.771)-(23.49)-(25.032)))+(68.361)+(65.068))/((36.222)));
	tcb->m_cWnd = (int) (38.815/0.1);
	CongestionAvoidance (tcb, segmentsAcked);

}
GVTRgaFhdbMKkvRA = (int) (12.999-(91.073)-(73.221)-(1.935)-(71.424)-(92.076));
