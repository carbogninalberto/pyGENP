segmentsAcked = (int) (42.468+(-40.22)+(80.538)+(-14.833)+(90.883)+(-80.838)+(-91.042)+(-80.353));
int KrXUxcWenmrIMYtV = (int) ((-24.403+(69.199)+(79.055))/5.924);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
