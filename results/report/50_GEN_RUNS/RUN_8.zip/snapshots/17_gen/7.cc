int KrXUxcWenmrIMYtV = (int) ((-9.504+(40.296)+(23.473))/-80.425);
segmentsAcked = (int) (14.777+(72.727)+(0.55)+(-46.65)+(36.643)+(69.22)+(-24.831)+(53.802));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
