TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (tcb->m_cWnd*(49.335));
tcb->m_segmentSize = (int) (11.363/0.1);
tcb->m_segmentSize = (int) (34.156-(tcb->m_ssThresh));
segmentsAcked = (int) (((0.1)+(11.918)+(30.967)+(0.1))/((97.523)+(14.13)+(8.221)+(0.1)+(72.966)));
