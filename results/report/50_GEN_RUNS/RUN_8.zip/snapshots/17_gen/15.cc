float uxqKPdCmFVWXckff = (float) (24.589+(-19.749)+(-61.113)+(90.996));
float MrQBueREaJJlkukS = (float) (-86.56*(93.369)*(-94.22)*(15.615));
tcb->m_segmentSize = (int) (((42.753)+(48.031)+(71.351)+(55.605)+(84.855))/((29.958)+(57.259)));
float KushNNkzbPWfRbPm = (float) 48.135;
KushNNkzbPWfRbPm = (float) (-47.099*(65.0)*(56.689));
