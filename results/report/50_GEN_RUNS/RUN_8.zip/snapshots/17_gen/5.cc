TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int KrXUxcWenmrIMYtV = (int) ((87.965+(76.925)+(-11.498))/-57.973);
segmentsAcked = (int) (33.011+(5.867)+(81.149)+(66.813)+(86.945)+(-50.317)+(63.16)+(-17.757));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
