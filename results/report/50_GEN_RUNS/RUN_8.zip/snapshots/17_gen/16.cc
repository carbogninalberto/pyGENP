int CeMpSROEIIHlUrca = (int) (-54.384-(78.321));
int QlfmpcISHcOlNLsI = (int) (29.809+(35.527)+(-97.58)+(-3.036)+(4.344)+(-69.304)+(-10.637)+(-62.79));
