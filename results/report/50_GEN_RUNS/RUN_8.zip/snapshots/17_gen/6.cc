segmentsAcked = (int) (88.877+(-91.388)+(-70.988)+(-8.728)+(65.245)+(82.083)+(-95.622)+(66.185));
int KrXUxcWenmrIMYtV = (int) ((75.164+(35.773)+(63.337))/77.996);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
