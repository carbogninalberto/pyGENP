int KrXUxcWenmrIMYtV = (int) ((87.817+(-51.711)+(77.719))/-50.22);
segmentsAcked = (int) (59.269+(19.673)+(89.516)+(-0.674)+(-72.554)+(73.312)+(-11.327)+(1.523));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
