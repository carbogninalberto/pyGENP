int KrXUxcWenmrIMYtV = (int) ((-5.723+(-67.88)+(65.734))/-71.408);
segmentsAcked = (int) (-69.28+(79.088)+(-69.678)+(72.167)+(31.104)+(33.23)+(-9.848)+(40.696));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
