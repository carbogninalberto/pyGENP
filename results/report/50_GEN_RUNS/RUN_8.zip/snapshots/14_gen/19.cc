if (segmentsAcked > segmentsAcked) {
	segmentsAcked = (int) (58.727+(91.041)+(segmentsAcked)+(6.684)+(segmentsAcked)+(66.756));

} else {
	segmentsAcked = (int) (2.519+(5.091)+(25.479)+(11.392)+(segmentsAcked)+(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (-79.259+(-46.062)+(-90.064)+(6.317));
tcb->m_segmentSize = (int) (75.739+(-70.392)+(33.471)+(98.908));
tcb->m_cWnd = (int) (-1.5+(63.379)+(-29.844)+(61.334)+(-58.84)+(80.444)+(-77.236));
tcb->m_cWnd = (int) (35.078/21.558);
