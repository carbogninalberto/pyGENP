int KrXUxcWenmrIMYtV = (int) ((-37.153+(84.951)+(90.107))/-13.131);
segmentsAcked = (int) (34.443+(-88.721)+(99.817)+(24.154)+(-87.538)+(18.967)+(-65.835)+(-17.686));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
