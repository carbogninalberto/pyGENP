segmentsAcked = (int) (95.79+(43.14)+(33.922)+(56.197)+(93.601)+(-68.43)+(7.066)+(-92.569));
int KrXUxcWenmrIMYtV = (int) ((90.877+(-2.774)+(18.529))/-63.425);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
