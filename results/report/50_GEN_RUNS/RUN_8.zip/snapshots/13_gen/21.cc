CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (0.926+(99.049)+(52.685)+(4.367));
tcb->m_segmentSize = (int) (82.845+(tcb->m_cWnd)+(54.578)+(tcb->m_cWnd));
tcb->m_cWnd = (int) (64.553+(8.295)+(2.935)+(66.081)+(50.002)+(tcb->m_cWnd)+(86.39));
tcb->m_cWnd = (int) (0.1/0.1);
if (tcb->m_ssThresh >= segmentsAcked) {
	segmentsAcked = (int) ((((tcb->m_ssThresh*(0.702)*(14.187)*(75.743)*(72.403)*(58.566)*(40.207)))+(0.1)+(91.136)+(0.1)+(12.886)+(40.964))/((26.133)));
	tcb->m_ssThresh = (int) (34.142+(55.757)+(20.705)+(63.009)+(tcb->m_cWnd)+(tcb->m_cWnd)+(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) (19.543*(84.65)*(98.695)*(22.717));

}
ReduceCwnd (tcb);
