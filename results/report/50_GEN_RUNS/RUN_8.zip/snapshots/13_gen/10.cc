int KrXUxcWenmrIMYtV = (int) ((67.594+(-68.933)+(33.825))/-51.75);
segmentsAcked = (int) (-25.542+(-95.637)+(67.303)+(-13.392)+(99.881)+(54.142)+(70.841)+(29.489));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
