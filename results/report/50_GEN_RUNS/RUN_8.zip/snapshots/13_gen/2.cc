segmentsAcked = (int) (-36.221+(-87.962)+(80.55)+(-53.061)+(-67.994)+(-17.9)+(52.047)+(43.978));
int KrXUxcWenmrIMYtV = (int) ((-68.68+(2.323)+(58.219))/-92.851);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
