tcb->m_segmentSize = (int) (92.614-(70.831));
tcb->m_ssThresh = (int) (((0.1)+(43.145)+(98.098)+(69.75)+(0.1))/((23.483)+(0.1)+(0.1)));
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (segmentsAcked+(86.672)+(75.51)+(10.7));
	tcb->m_ssThresh = (int) (94.847+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(segmentsAcked)+(64.524)+(59.718)+(tcb->m_segmentSize)+(42.805)+(77.121));

} else {
	tcb->m_segmentSize = (int) (81.025/73.625);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
