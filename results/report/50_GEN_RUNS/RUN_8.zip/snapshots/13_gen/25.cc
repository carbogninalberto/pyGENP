float sBvlyPCaUqMagVYQ = (float) (0.1/(segmentsAcked*(0.943)*(tcb->m_cWnd)*(62.466)));
tcb->m_segmentSize = (int) (11.718-(62.314)-(15.939)-(99.176)-(95.182)-(22.978)-(23.105)-(tcb->m_segmentSize));
tcb->m_cWnd = (int) (62.97/63.647);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (12.976/56.877);
