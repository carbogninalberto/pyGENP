segmentsAcked = (int) (87.224+(39.106)+(86.589)+(-84.245)+(56.166)+(-36.814)+(-30.867)+(62.282));
int KrXUxcWenmrIMYtV = (int) ((-42.067+(-18.853)+(-50.792))/82.012);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
