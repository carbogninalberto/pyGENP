segmentsAcked = (int) (12.497+(-40.758)+(93.833)+(-14.883)+(97.131)+(32.321)+(-67.661)+(-34.767));
int KrXUxcWenmrIMYtV = (int) ((-95.637+(85.321)+(50.862))/-62.966);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
