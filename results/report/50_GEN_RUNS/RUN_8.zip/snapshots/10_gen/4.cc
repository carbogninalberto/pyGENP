int KrXUxcWenmrIMYtV = (int) ((-62.34+(97.926)+(91.901))/92.036);
segmentsAcked = (int) (-4.339+(90.558)+(-4.79)+(1.87)+(-67.258)+(-7.726)+(-77.348)+(-75.464));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
