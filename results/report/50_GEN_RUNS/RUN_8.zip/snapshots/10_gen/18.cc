int pEHEMfUeQCwVuptW = (int) 42.334;
if (tcb->m_segmentSize > tcb->m_cWnd) {
	pEHEMfUeQCwVuptW = (int) (((33.376)+(0.1)+(9.998)+(14.178)+(71.915)+(0.1))/((0.1)+(0.1)+(0.1)));

} else {
	pEHEMfUeQCwVuptW = (int) (11.57*(23.83)*(tcb->m_cWnd)*(8.86));

}
tcb->m_segmentSize = (int) (-61.119*(-33.796)*(45.092));
CongestionAvoidance (tcb, segmentsAcked);
