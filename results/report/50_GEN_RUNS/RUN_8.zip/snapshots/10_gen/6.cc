segmentsAcked = (int) (33.659+(-62.976)+(99.029)+(99.551)+(89.372)+(9.386)+(-88.129)+(57.25));
int KrXUxcWenmrIMYtV = (int) ((86.179+(42.02)+(11.304))/71.809);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
