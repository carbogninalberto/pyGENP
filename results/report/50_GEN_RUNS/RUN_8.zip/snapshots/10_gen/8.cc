int KrXUxcWenmrIMYtV = (int) ((-73.593+(-72.477)+(-50.505))/54.262);
segmentsAcked = (int) (14.08+(70.464)+(-81.816)+(70.39)+(-18.891)+(58.134)+(-24.52)+(97.381));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
