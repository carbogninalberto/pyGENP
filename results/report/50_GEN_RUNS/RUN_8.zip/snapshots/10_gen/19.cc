CongestionAvoidance (tcb, segmentsAcked);
float QfjHoHsXqhNCupnJ = (float) (28.42/-55.933);
CongestionAvoidance (tcb, segmentsAcked);
