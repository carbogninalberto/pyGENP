segmentsAcked = (int) (8.28+(-20.424)+(-72.547)+(71.5)+(-92.36)+(78.421)+(33.032)+(27.371));
int KrXUxcWenmrIMYtV = (int) ((28.742+(35.897)+(-88.14))/-67.028);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
