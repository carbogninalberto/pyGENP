int KrXUxcWenmrIMYtV = (int) ((37.865+(1.423)+(97.585))/-90.77);
segmentsAcked = (int) (-94.912+(-42.426)+(84.596)+(-11.202)+(93.061)+(-28.519)+(89.255)+(-0.627));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
