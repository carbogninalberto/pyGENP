int ODnauuLfDILYokDJ = (int) 17.649;
ODnauuLfDILYokDJ = (int) (76.268*(-45.361)*(25.131)*(50.416)*(41.966)*(-49.87)*(73.45));
