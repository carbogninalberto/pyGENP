TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (87.251+(71.393)+(25.535)+(18.249)+(54.787)+(94.728)+(65.859)+(87.939)+(11.864));
	tcb->m_cWnd = (int) (66.826*(tcb->m_cWnd)*(36.866)*(21.758)*(segmentsAcked)*(53.685)*(0.37)*(21.419));
	tcb->m_segmentSize = (int) (49.086*(56.914)*(8.862)*(62.147)*(59.973)*(91.953)*(13.298));

} else {
	segmentsAcked = (int) (72.757-(12.725)-(18.761));
	tcb->m_cWnd = (int) (21.937-(4.441)-(25.561)-(-10.917)-(58.795)-(81.501)-(tcb->m_cWnd));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (72.757-(12.725)-(18.761));
	tcb->m_cWnd = (int) (21.937-(4.441)-(25.561)-(-10.917)-(58.795)-(81.501)-(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (87.251+(71.393)+(25.535)+(18.249)+(54.787)+(94.728)+(65.859)+(87.939)+(11.864));
	tcb->m_cWnd = (int) (66.826*(tcb->m_cWnd)*(36.866)*(21.758)*(segmentsAcked)*(53.685)*(0.37)*(21.419));
	tcb->m_segmentSize = (int) (49.086*(56.914)*(8.862)*(62.147)*(59.973)*(91.953)*(13.298));

}
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (72.757-(12.725)-(18.761));
	tcb->m_cWnd = (int) (21.937-(4.441)-(25.561)-(-10.917)-(58.795)-(81.501)-(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (87.251+(71.393)+(25.535)+(18.249)+(54.787)+(94.728)+(65.859)+(87.939)+(11.864));
	tcb->m_cWnd = (int) (66.826*(tcb->m_cWnd)*(36.866)*(21.758)*(segmentsAcked)*(53.685)*(0.37)*(21.419));
	tcb->m_segmentSize = (int) (49.086*(56.914)*(8.862)*(62.147)*(59.973)*(91.953)*(13.298));

}
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
