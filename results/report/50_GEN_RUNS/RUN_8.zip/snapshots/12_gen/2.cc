float RpfjewwqNbePnxtN = (float) 1.126;
float jKiOlNPIfoZpXZvb = (float) (-45.248-(-42.624)-(-89.05)-(-36.635)-(-87.945)-(36.868));
tcb->m_segmentSize = (int) (-32.549*(63.713)*(55.012)*(74.49)*(-9.007)*(-18.155));
float GRsTSwYnkWUJRiQD = (float) 72.783;
tcb->m_cWnd = (int) (-10.478+(70.44)+(-78.802)+(-46.171)+(-64.971)+(-34.201)+(-76.279));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	GRsTSwYnkWUJRiQD = (float) (segmentsAcked+(segmentsAcked));
	segmentsAcked = (int) (((35.552)+(11.006)+(4.12)+(0.1)+(32.816)+(0.1))/((80.453)+(0.1)+(0.1)));

} else {
	GRsTSwYnkWUJRiQD = (float) (97.29*(segmentsAcked)*(75.589)*(67.957)*(35.642)*(7.481)*(27.201)*(46.876));

}
if (RpfjewwqNbePnxtN > tcb->m_segmentSize) {
	GRsTSwYnkWUJRiQD = (float) (23.146+(51.659)+(29.901)+(10.318)+(19.979)+(89.071));
	tcb->m_segmentSize = (int) (47.026/8.435);
	segmentsAcked = (int) (RpfjewwqNbePnxtN-(3.865)-(85.364)-(85.832)-(18.188)-(18.401)-(85.557)-(14.73)-(84.759));

} else {
	GRsTSwYnkWUJRiQD = (float) (83.649-(16.474));

}
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (83.515-(91.92)-(99.421)-(-48.104)-(55.166)-(66.089)-(48.795));
	tcb->m_segmentSize = (int) (67.91+(tcb->m_segmentSize)+(76.144)+(70.355)+(38.425));
	GRsTSwYnkWUJRiQD = (float) (((0.1)+(36.773)+(72.176)+(0.1)+(35.804)+(48.402)+(0.1))/((0.1)+(96.953)));

} else {
	tcb->m_cWnd = (int) (0.1/83.623);
	ReduceCwnd (tcb);
	GRsTSwYnkWUJRiQD = (float) (7.768-(80.91)-(segmentsAcked)-(tcb->m_cWnd)-(71.483)-(43.525)-(82.988)-(60.352));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	GRsTSwYnkWUJRiQD = (float) (segmentsAcked+(segmentsAcked));
	segmentsAcked = (int) (((35.552)+(11.006)+(4.12)+(0.1)+(32.816)+(0.1))/((80.453)+(0.1)+(0.1)));

} else {
	GRsTSwYnkWUJRiQD = (float) (97.29*(segmentsAcked)*(75.589)*(67.957)*(35.642)*(7.481)*(27.201)*(46.876));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (RpfjewwqNbePnxtN > tcb->m_segmentSize) {
	GRsTSwYnkWUJRiQD = (float) (23.146+(51.659)+(29.901)+(10.318)+(19.979)+(89.071));
	tcb->m_segmentSize = (int) (47.026/8.435);
	segmentsAcked = (int) (RpfjewwqNbePnxtN-(3.865)-(85.364)-(85.832)-(18.188)-(18.401)-(85.557)-(14.73)-(84.759));

} else {
	GRsTSwYnkWUJRiQD = (float) (83.649-(16.474));

}
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	GRsTSwYnkWUJRiQD = (float) (segmentsAcked+(segmentsAcked));
	segmentsAcked = (int) (((35.552)+(11.006)+(4.12)+(0.1)+(32.816)+(0.1))/((80.453)+(0.1)+(0.1)));

} else {
	GRsTSwYnkWUJRiQD = (float) (97.29*(segmentsAcked)*(75.589)*(67.957)*(35.642)*(7.481)*(27.201)*(46.876));

}
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (83.515-(91.92)-(99.421)-(-48.104)-(55.166)-(66.089)-(48.795));
	tcb->m_segmentSize = (int) (67.91+(tcb->m_segmentSize)+(76.144)+(70.355)+(38.425));
	GRsTSwYnkWUJRiQD = (float) (((0.1)+(36.773)+(72.176)+(0.1)+(35.804)+(48.402)+(0.1))/((0.1)+(96.953)));

} else {
	tcb->m_cWnd = (int) (0.1/83.623);
	ReduceCwnd (tcb);
	GRsTSwYnkWUJRiQD = (float) (7.768-(80.91)-(segmentsAcked)-(tcb->m_cWnd)-(71.483)-(43.525)-(82.988)-(60.352));

}
if (RpfjewwqNbePnxtN > tcb->m_segmentSize) {
	GRsTSwYnkWUJRiQD = (float) (23.146+(51.659)+(29.901)+(10.318)+(19.979)+(89.071));
	tcb->m_segmentSize = (int) (47.026/8.435);
	segmentsAcked = (int) (RpfjewwqNbePnxtN-(3.865)-(85.364)-(85.832)-(18.188)-(18.401)-(85.557)-(14.73)-(27.601));

} else {
	GRsTSwYnkWUJRiQD = (float) (83.649-(16.474));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	GRsTSwYnkWUJRiQD = (float) (segmentsAcked+(segmentsAcked));
	segmentsAcked = (int) (((35.552)+(11.006)+(4.12)+(0.1)+(32.816)+(0.1))/((80.453)+(0.1)+(0.1)));

} else {
	GRsTSwYnkWUJRiQD = (float) (97.29*(segmentsAcked)*(75.589)*(67.957)*(35.642)*(7.481)*(27.201)*(46.876));

}
if (RpfjewwqNbePnxtN > tcb->m_segmentSize) {
	GRsTSwYnkWUJRiQD = (float) (23.146+(51.659)+(29.901)+(10.318)+(19.979)+(89.071));
	tcb->m_segmentSize = (int) (47.026/8.435);
	segmentsAcked = (int) (RpfjewwqNbePnxtN-(3.865)-(85.364)-(85.832)-(18.188)-(18.401)-(85.557)-(14.73)-(27.601));

} else {
	GRsTSwYnkWUJRiQD = (float) (83.649-(16.474));

}
