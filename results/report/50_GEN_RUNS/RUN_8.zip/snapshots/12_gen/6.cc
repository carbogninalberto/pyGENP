segmentsAcked = (int) (55.292+(-21.655)+(52.005)+(-29.735)+(-37.873)+(-57.166)+(78.856)+(11.072));
int KrXUxcWenmrIMYtV = (int) ((44.817+(-51.563)+(-86.264))/14.194);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
