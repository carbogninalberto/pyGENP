int KrXUxcWenmrIMYtV = (int) ((-68.667+(-53.357)+(18.544))/-44.624);
segmentsAcked = (int) (-58.99+(-30.448)+(-32.256)+(-49.382)+(-79.65)+(-7.381)+(12.188)+(-14.613));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
