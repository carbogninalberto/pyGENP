segmentsAcked = (int) (-14.672+(33.014)+(-50.021)+(70.792)+(-85.189)+(13.611)+(54.57)+(-88.489));
int KrXUxcWenmrIMYtV = (int) ((91.513+(-73.012)+(35.774))/-53.968);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
