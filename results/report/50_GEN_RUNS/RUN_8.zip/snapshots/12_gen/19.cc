int KrXUxcWenmrIMYtV = (int) ((-11.308+(43.766)+(-44.809))/51.805);
segmentsAcked = (int) (73.47+(-8.19)+(16.704)+(24.639)+(-49.051)+(95.137)+(59.133)+(22.967));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
