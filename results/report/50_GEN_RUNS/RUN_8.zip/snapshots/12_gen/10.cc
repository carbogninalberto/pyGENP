int KrXUxcWenmrIMYtV = (int) ((-79.057+(31.344)+(77.933))/-89.905);
segmentsAcked = (int) (56.926+(2.062)+(57.352)+(53.434)+(-80.559)+(13.887)+(40.423)+(77.807));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
