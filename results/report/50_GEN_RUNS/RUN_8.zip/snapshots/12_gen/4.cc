int KrXUxcWenmrIMYtV = (int) ((-43.424+(-66.555)+(-88.382))/-18.14);
segmentsAcked = (int) (85.455+(-83.848)+(-86.182)+(-52.962)+(84.118)+(-51.895)+(-3.56)+(-86.068));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
