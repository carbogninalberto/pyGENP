tcb->m_cWnd = (int) (44.453*(tcb->m_cWnd)*(43.162)*(tcb->m_segmentSize)*(72.726)*(54.499)*(64.394)*(97.389));
segmentsAcked = (int) (98.678*(19.855)*(83.867)*(tcb->m_segmentSize)*(92.839)*(92.861)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(25.31));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((((22.785*(tcb->m_segmentSize)*(93.375)*(1.421)*(68.197)*(84.504)))+(51.607)+(0.1)+(30.98))/((0.1)+(58.219)+(0.1)+(95.707)+(6.774)));

} else {
	tcb->m_ssThresh = (int) (0.438+(33.164)+(89.996)+(tcb->m_segmentSize));

}
tcb->m_ssThresh = (int) (8.108/21.944);
