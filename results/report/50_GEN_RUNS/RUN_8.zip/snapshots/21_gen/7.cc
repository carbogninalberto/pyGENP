float zYlJbqbPBBTzreYs = (float) (-48.526-(-63.428)-(41.828));
float laEOUHFfgiPOwkpZ = (float) (-93.254-(0.002)-(63.339)-(84.126)-(74.937)-(-62.908)-(43.232)-(-99.531));
segmentsAcked = SlowStart (tcb, segmentsAcked);
int oUFkbLZWnBhvFHZx = (int) 75.308;
tcb->m_cWnd = (int) (-54.724*(75.312)*(-17.643)*(-1.63)*(36.028)*(-94.472)*(42.411)*(-29.114)*(-3.652));
