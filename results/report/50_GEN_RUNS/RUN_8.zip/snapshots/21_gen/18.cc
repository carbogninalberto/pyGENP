tcb->m_ssThresh = (int) (57.095*(tcb->m_ssThresh));
tcb->m_segmentSize = (int) (75.167-(57.216));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (70.841*(67.029));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(64.569)-(tcb->m_segmentSize)-(5.128)-(19.83)-(68.218)-(74.295));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (35.153+(tcb->m_cWnd)+(tcb->m_segmentSize)+(35.217)+(76.514)+(38.959));

}
