float juNMZmtKtCXcoCzC = (float) 78.472;
