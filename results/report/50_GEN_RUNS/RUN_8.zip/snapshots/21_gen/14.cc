if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (8.362-(51.229)-(96.38));

} else {
	tcb->m_ssThresh = (int) (21.308+(11.133)+(78.091)+(68.854));
	tcb->m_cWnd = (int) (67.943-(tcb->m_cWnd)-(63.159)-(18.709)-(76.359));
	tcb->m_segmentSize = (int) (54.479*(5.448)*(56.523)*(55.613)*(tcb->m_cWnd));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (68.126+(47.062)+(segmentsAcked)+(83.991));
	tcb->m_cWnd = (int) (19.184*(90.355)*(28.502)*(25.708)*(92.231)*(46.65));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked*(3.498)*(28.137)*(41.175)*(85.395)*(46.047)*(87.503)*(27.285)*(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (72.288*(49.52)*(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) (34.657+(tcb->m_ssThresh)+(74.575)+(10.471)+(55.131)+(41.431)+(94.736));

} else {
	segmentsAcked = (int) (72.955-(68.318)-(95.148)-(7.657)-(58.613)-(57.707)-(56.749)-(5.935));

}
