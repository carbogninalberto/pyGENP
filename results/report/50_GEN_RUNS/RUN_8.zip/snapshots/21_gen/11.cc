segmentsAcked = (int) (53.771+(25.299));
