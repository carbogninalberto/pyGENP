if (segmentsAcked < tcb->m_ssThresh) {
	segmentsAcked = (int) (23.581*(16.379)*(64.108)*(tcb->m_cWnd)*(16.858)*(1.156)*(12.574)*(73.902));
	tcb->m_ssThresh = (int) (79.369*(36.251)*(59.142));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (76.696-(2.396)-(segmentsAcked)-(tcb->m_segmentSize)-(33.312)-(24.927)-(31.586)-(57.835)-(43.187));
	tcb->m_cWnd = (int) (0.399-(tcb->m_segmentSize)-(30.317)-(8.17));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
int nCnVUsSjJwOKysdU = (int) (segmentsAcked-(95.971)-(tcb->m_cWnd));
CongestionAvoidance (tcb, segmentsAcked);
