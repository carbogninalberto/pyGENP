float laEOUHFfgiPOwkpZ = (float) (-27.049-(-36.933)-(5.327)-(7.482)-(-17.927)-(6.461)-(-63.288)-(83.112));
int oUFkbLZWnBhvFHZx = (int) (45.059/70.503);
