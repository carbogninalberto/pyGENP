float fIBpcsaLgnklSIYI = (float) (0.1/57.235);
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (68.818*(tcb->m_ssThresh));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(78.666)+(54.731)+(5.247)+(63.748)+(46.216)+(33.454)+(52.09));
	tcb->m_cWnd = (int) (45.796-(51.675)-(12.577)-(20.53)-(8.02)-(34.124)-(tcb->m_ssThresh)-(19.346)-(96.38));

}
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_ssThresh = (int) (66.19+(63.242)+(83.108)+(11.805)+(55.252));

} else {
	tcb->m_ssThresh = (int) (((0.1)+((tcb->m_cWnd-(88.957)-(41.134)))+(0.1)+(77.705)+(65.494)+(87.765))/((0.1)+(41.714)+(23.043)));
	tcb->m_cWnd = (int) (((78.665)+(57.604)+(86.074)+((18.168-(11.467)-(85.097)-(segmentsAcked)-(22.814)-(87.102)))+(0.1)+((68.29-(fIBpcsaLgnklSIYI)-(2.763)))+(48.526))/((0.1)+(44.918)));

}
if (fIBpcsaLgnklSIYI >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (30.486+(79.153));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (80.619/0.1);
