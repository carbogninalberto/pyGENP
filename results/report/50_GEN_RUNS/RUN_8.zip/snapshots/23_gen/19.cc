if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (1.867*(41.93)*(92.155)*(85.419)*(87.734)*(86.106)*(9.272)*(40.904));

} else {
	tcb->m_ssThresh = (int) (0.1/62.896);
	segmentsAcked = (int) (92.315+(99.754)+(38.389)+(85.709)+(segmentsAcked)+(22.75)+(67.585));
	tcb->m_ssThresh = (int) (((0.1)+((53.358-(tcb->m_cWnd)-(33.342)-(67.702)-(tcb->m_ssThresh)-(70.418)-(48.511)-(6.362)-(26.807)))+(0.1)+((74.156-(71.684)-(65.816)))+(0.1))/((0.1)+(0.1)+(17.474)+(48.661)));

}
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (99.994+(tcb->m_segmentSize));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (14.392+(15.607)+(tcb->m_segmentSize)+(37.273)+(31.064)+(79.637)+(98.775)+(81.939)+(23.213));

} else {
	tcb->m_cWnd = (int) (2.253-(53.236)-(53.747)-(15.015)-(tcb->m_segmentSize));

}
float OikSLaRJFOpevwxZ = (float) (-0.081+(18.452)+(54.804)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(39.276)+(94.114)+(81.866));
tcb->m_cWnd = (int) (OikSLaRJFOpevwxZ+(tcb->m_segmentSize)+(53.664)+(5.824)+(48.318)+(39.685)+(OikSLaRJFOpevwxZ)+(30.305));
if (segmentsAcked <= OikSLaRJFOpevwxZ) {
	OikSLaRJFOpevwxZ = (float) ((78.727-(22.207)-(5.598)-(88.991)-(tcb->m_cWnd))/86.977);
	tcb->m_segmentSize = (int) (0.1/0.1);
	segmentsAcked = (int) (segmentsAcked+(9.73)+(42.553)+(OikSLaRJFOpevwxZ)+(94.163)+(38.016));

} else {
	OikSLaRJFOpevwxZ = (float) (49.346+(99.408));

}
if (OikSLaRJFOpevwxZ <= OikSLaRJFOpevwxZ) {
	tcb->m_segmentSize = (int) (OikSLaRJFOpevwxZ-(48.08)-(8.915)-(3.727)-(7.562));
	tcb->m_segmentSize = (int) (1.541*(tcb->m_ssThresh)*(97.307)*(21.278)*(5.561)*(17.2)*(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (3.873+(33.096)+(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (88.145-(8.334));

}
if (tcb->m_segmentSize <= OikSLaRJFOpevwxZ) {
	tcb->m_ssThresh = (int) (90.703/23.887);
	tcb->m_cWnd = (int) (48.889+(43.455)+(74.477)+(1.037)+(34.063)+(23.957)+(segmentsAcked)+(51.297)+(75.932));
	tcb->m_cWnd = (int) (25.23*(OikSLaRJFOpevwxZ)*(77.395)*(30.278)*(6.217)*(86.219)*(tcb->m_ssThresh)*(48.213)*(7.756));

} else {
	tcb->m_ssThresh = (int) (37.031*(71.413)*(67.912)*(34.488)*(72.626));

}
OikSLaRJFOpevwxZ = (float) (16.313*(31.453)*(57.602)*(58.627)*(81.48)*(36.322));
