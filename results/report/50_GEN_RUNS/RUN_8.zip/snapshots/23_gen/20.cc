ReduceCwnd (tcb);
if (tcb->m_ssThresh < segmentsAcked) {
	segmentsAcked = (int) (44.771-(29.219)-(tcb->m_ssThresh)-(31.731)-(62.964)-(35.485)-(tcb->m_cWnd)-(87.106));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (tcb->m_segmentSize-(11.063)-(50.678));

}
tcb->m_ssThresh = (int) (90.51-(segmentsAcked)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(49.739)-(segmentsAcked)-(tcb->m_cWnd)-(67.373)-(87.964));
int woRjZAnhxFyoCiYO = (int) (0.1/0.1);
woRjZAnhxFyoCiYO = (int) (1.621*(43.871));
tcb->m_segmentSize = (int) (99.492-(76.14)-(51.966));
