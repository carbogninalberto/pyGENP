if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(61.743));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (23.582/0.1);
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(30.496)+(39.43)+(39.034)+(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (66.926-(tcb->m_ssThresh)-(segmentsAcked)-(10.089));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (segmentsAcked <= tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (7.497*(61.421)*(16.044)*(90.606)*(84.887)*(tcb->m_segmentSize));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
float ezXQzLosaGUCqAjf = (float) (40.616*(tcb->m_segmentSize));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh <= ezXQzLosaGUCqAjf) {
	tcb->m_ssThresh = (int) (11.114-(43.68)-(tcb->m_cWnd));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (32.828-(tcb->m_cWnd)-(8.399)-(ezXQzLosaGUCqAjf)-(69.318)-(90.47));
	tcb->m_segmentSize = (int) (80.322+(97.415)+(41.414));
	ezXQzLosaGUCqAjf = (float) (95.488+(56.5)+(11.293));

}
