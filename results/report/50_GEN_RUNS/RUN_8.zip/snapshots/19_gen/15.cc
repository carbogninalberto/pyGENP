int FOBXCelGLBHMfbyI = (int) (-97.553+(43.075)+(-94.496)+(-86.878)+(-25.091)+(33.64)+(28.903)+(-12.962)+(-43.659));
ReduceCwnd (tcb);
segmentsAcked = (int) (-85.348/-59.365);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
