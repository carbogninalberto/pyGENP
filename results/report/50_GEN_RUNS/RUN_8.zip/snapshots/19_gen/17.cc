int FOBXCelGLBHMfbyI = (int) (-1.605+(27.562)+(44.005)+(76.288)+(-23.771)+(-55.54)+(16.323)+(26.795)+(8.823));
FOBXCelGLBHMfbyI = (int) (-47.004/8.482);
segmentsAcked = (int) (-6.294/-60.594);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
