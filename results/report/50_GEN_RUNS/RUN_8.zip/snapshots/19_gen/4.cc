int FOBXCelGLBHMfbyI = (int) (-62.981+(-64.355)+(-63.226)+(-56.423)+(2.451)+(-45.13)+(77.332)+(-51.624)+(-33.38));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
