CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (((87.978)+(-79.519)+(-44.361)+(-60.959))/((10.953)));
segmentsAcked = (int) (45.306*(-9.225)*(90.456)*(-45.547)*(20.745)*(0.036)*(-94.522)*(-68.398)*(65.721));
