float mWRTfTLmSFCYyTRs = (float) (58.928+(25.129)+(96.115)+(70.595)+(-13.044)+(-53.939)+(12.215)+(-43.456));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
