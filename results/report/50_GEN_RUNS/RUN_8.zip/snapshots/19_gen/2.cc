TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int KrXUxcWenmrIMYtV = (int) ((-36.106+(-23.559)+(12.341))/94.234);
segmentsAcked = (int) (-26.56+(19.565)+(10.173)+(-96.871)+(-17.456)+(-21.776)+(-80.027)+(-32.403));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
