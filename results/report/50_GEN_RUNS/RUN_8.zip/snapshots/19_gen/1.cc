segmentsAcked = (int) (20.132+(-7.023)+(39.821)+(-10.052)+(-30.563)+(-6.58)+(-76.904)+(67.693));
int KrXUxcWenmrIMYtV = (int) ((-65.727+(-52.616)+(-41.682))/-9.623);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
