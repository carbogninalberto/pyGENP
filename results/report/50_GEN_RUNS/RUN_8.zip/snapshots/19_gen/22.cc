tcb->m_segmentSize = (int) (22.163*(86.884)*(74.742)*(38.272)*(tcb->m_cWnd)*(83.508)*(70.531));
tcb->m_ssThresh = (int) (22.076+(72.198)+(30.936)+(33.234)+(11.372)+(tcb->m_cWnd)+(42.891)+(94.363)+(93.01));
int wZpPCtjSVVpUDfwi = (int) (tcb->m_segmentSize+(35.466)+(78.949)+(40.885)+(12.564)+(55.368)+(59.595)+(93.242));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (92.3-(65.566));
	wZpPCtjSVVpUDfwi = (int) (6.587-(50.209));

} else {
	tcb->m_ssThresh = (int) (25.128+(73.47)+(9.833)+(57.339)+(49.261)+(7.145)+(9.296)+(47.84));
	tcb->m_ssThresh = (int) (39.482+(84.875)+(83.961)+(92.593)+(72.361)+(75.546));
	tcb->m_segmentSize = (int) (segmentsAcked+(52.035)+(99.574)+(90.699)+(41.872));

}
