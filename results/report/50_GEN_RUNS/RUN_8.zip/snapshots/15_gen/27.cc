TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-1.757+(51.688)+(34.483)+(53.723)+(-0.586)+(-21.509)+(7.523)+(-97.225));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int KrXUxcWenmrIMYtV = (int) ((95.975+(91.634)+(-60.123))/-63.668);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
