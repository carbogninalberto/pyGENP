int KrXUxcWenmrIMYtV = (int) ((-57.911+(-69.47)+(97.94))/13.783);
segmentsAcked = (int) (-29.183+(39.462)+(53.022)+(-51.796)+(-67.289)+(-1.562)+(-0.768)+(-91.651));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
