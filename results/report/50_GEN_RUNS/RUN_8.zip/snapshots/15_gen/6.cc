segmentsAcked = (int) (87.99+(75.525)+(-20.867)+(-76.895)+(77.735)+(-87.789)+(3.486)+(-88.325));
int KrXUxcWenmrIMYtV = (int) ((75.957+(-75.638)+(-57.808))/47.835);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
