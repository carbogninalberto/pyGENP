segmentsAcked = (int) (-54.016+(15.647)+(37.271)+(19.42)+(78.534)+(55.223)+(-91.261)+(-57.052));
int KrXUxcWenmrIMYtV = (int) ((-71.169+(49.902)+(51.136))/-74.457);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
