int SVFPNHCvKeXUVYeF = (int) (54.014*(-1.376)*(36.363)*(52.237)*(-59.687));
