segmentsAcked = (int) (24.722+(-42.567)+(58.044)+(85.715)+(-51.758)+(-65.288)+(-91.658)+(28.33));
int KrXUxcWenmrIMYtV = (int) ((49.623+(-21.288)+(-88.339))/-13.007);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
