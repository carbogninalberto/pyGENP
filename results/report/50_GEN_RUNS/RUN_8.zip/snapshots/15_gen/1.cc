segmentsAcked = (int) (42.582+(95.13)+(-11.362)+(5.018)+(59.992)+(2.2)+(-58.22)+(-56.28));
int KrXUxcWenmrIMYtV = (int) ((-26.503+(-0.84)+(88.772))/-41.082);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
