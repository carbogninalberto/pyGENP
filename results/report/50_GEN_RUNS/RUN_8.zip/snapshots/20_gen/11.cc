TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
float pHlgRPvJeDySAlUz = (float) (64.417-(93.382)-(17.689)-(0.975)-(segmentsAcked)-(9.552)-(20.115)-(95.347));
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (92.85-(55.177)-(10.141)-(69.899)-(58.078)-(55.675)-(50.25)-(3.019)-(50.379));
	pHlgRPvJeDySAlUz = (float) (57.198+(23.499)+(92.77)+(94.993)+(38.052));
	tcb->m_segmentSize = (int) (26.605*(55.698)*(segmentsAcked)*(55.38)*(40.462)*(61.609)*(59.181)*(pHlgRPvJeDySAlUz)*(81.166));

} else {
	tcb->m_cWnd = (int) (94.703/1.87);
	tcb->m_cWnd = (int) (45.457-(77.071)-(73.414)-(49.432)-(15.559)-(13.406)-(50.229)-(23.068)-(58.413));
	tcb->m_cWnd = (int) (tcb->m_cWnd*(tcb->m_ssThresh)*(60.865)*(73.184)*(93.758)*(9.416)*(96.382));

}
float DeZwefXpszMlJXMJ = (float) (33.608*(tcb->m_segmentSize)*(70.47)*(77.659)*(42.556)*(21.817)*(21.333)*(85.261));
if (DeZwefXpszMlJXMJ < tcb->m_ssThresh) {
	pHlgRPvJeDySAlUz = (float) (42.713+(52.895)+(55.652));
	tcb->m_ssThresh = (int) (43.319*(31.599)*(1.798)*(23.656)*(segmentsAcked)*(7.034)*(47.235)*(30.133)*(62.353));
	tcb->m_segmentSize = (int) (25.269/(97.952*(39.806)*(61.08)*(18.062)*(37.401)*(99.671)*(82.332)*(36.511)*(76.265)));

} else {
	pHlgRPvJeDySAlUz = (float) (79.413*(tcb->m_cWnd)*(55.594)*(segmentsAcked)*(segmentsAcked)*(50.974));
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
if (pHlgRPvJeDySAlUz <= tcb->m_cWnd) {
	pHlgRPvJeDySAlUz = (float) (((0.1)+(36.237)+(0.1)+((22.735+(92.506)+(56.748)+(12.259)+(segmentsAcked)+(31.234)))+(45.1)+(0.1)+((61.635*(tcb->m_segmentSize)*(8.299)))+(0.1))/((0.1)));
	DeZwefXpszMlJXMJ = (float) (((0.1)+(22.456)+(84.761)+(34.888))/((0.1)+(28.709)+(0.1)));

} else {
	pHlgRPvJeDySAlUz = (float) (0.1/0.1);
	ReduceCwnd (tcb);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_cWnd <= pHlgRPvJeDySAlUz) {
	tcb->m_segmentSize = (int) (15.44*(83.741)*(tcb->m_ssThresh)*(94.165)*(63.638));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(8.884)+(38.082)+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)+(0.1)));

}
