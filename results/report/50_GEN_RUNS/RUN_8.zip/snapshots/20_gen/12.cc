segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(62.518)-(97.701)-(60.622)-(25.95)-(31.931)-(60.602));
tcb->m_cWnd = (int) (tcb->m_segmentSize-(tcb->m_segmentSize)-(72.347)-(44.341));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (segmentsAcked-(88.707)-(61.628)-(23.017)-(94.055));
