segmentsAcked = SlowStart (tcb, segmentsAcked);
float HrHzfKIXTAOMXKsx = (float) (92.654-(89.997)-(-68.58)-(76.3));
CongestionAvoidance (tcb, segmentsAcked);
