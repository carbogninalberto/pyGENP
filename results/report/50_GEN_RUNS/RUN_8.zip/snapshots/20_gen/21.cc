tcb->m_ssThresh = (int) (66.215/90.72);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_cWnd+(32.904)+(85.62)+(78.157)+(92.704)+(64.21)+(50.408));
tcb->m_cWnd = (int) (44.924+(tcb->m_ssThresh)+(1.937)+(97.645)+(10.523)+(60.164));
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (65.069*(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (34.425+(3.884)+(99.296)+(75.706));

} else {
	tcb->m_segmentSize = (int) (21.696*(48.054)*(17.521)*(84.196)*(tcb->m_segmentSize));

}
tcb->m_ssThresh = (int) (((0.1)+(23.441)+(3.239)+(86.71)+(0.1))/((7.828)+(43.133)+(0.1)));
