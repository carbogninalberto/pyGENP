if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (segmentsAcked-(51.335)-(60.188));
	tcb->m_cWnd = (int) (65.464*(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (78.141+(44.396)+(78.107)+(4.436)+(22.178)+(24.167)+(87.262)+(44.947));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (74.559-(66.907)-(18.872)-(tcb->m_segmentSize)-(50.73)-(64.841));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (13.649+(61.886)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(53.442)+(tcb->m_ssThresh)+(94.705)+(16.129));
ReduceCwnd (tcb);
