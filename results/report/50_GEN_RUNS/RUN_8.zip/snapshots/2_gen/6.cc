int zIhYPctUanIWpQPj = (int) (-6.877*(-28.679)*(13.699)*(41.48)*(59.916)*(-48.105)*(-34.614));
if (zIhYPctUanIWpQPj == tcb->m_cWnd) {
	zIhYPctUanIWpQPj = (int) (84.594*(segmentsAcked)*(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	zIhYPctUanIWpQPj = (int) (43.436-(21.311)-(88.713)-(39.358)-(6.4)-(9.263));
	zIhYPctUanIWpQPj = (int) (((91.029)+(6.773)+(38.862)+(40.017)+((31.147*(tcb->m_cWnd)*(19.159)*(47.822)))+((17.229*(zIhYPctUanIWpQPj)*(64.073)*(tcb->m_cWnd)*(79.953)*(tcb->m_cWnd)))+(31.349))/((11.932)+(10.43)));
	tcb->m_cWnd = (int) (97.089*(45.774)*(73.042));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
