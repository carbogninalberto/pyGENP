int oSYQxoQOfmkVsZkM = (int) (94.762+(-33.241)+(92.35)+(-29.97));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
