float VIpnskdFvEnZrhMR = (float) (-10.275-(82.628)-(38.735)-(-46.425)-(-55.573)-(-97.992)-(51.311));
float RJEqqVXSeRXWDdjv = (float) ((-61.751+(-14.319)+(-90.679)+(86.261)+(-10.95)+(-21.636)+(67.089)+(-40.117))/-65.193);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
