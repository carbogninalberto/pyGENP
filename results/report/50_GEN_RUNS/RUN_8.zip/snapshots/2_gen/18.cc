int FydiTkWcgQDlqtaX = (int) (-12.331/69.954);
float qCwuxqCnJwdBAQJv = (float) (81.233-(99.57)-(1.974)-(-63.478));
segmentsAcked = SlowStart (tcb, segmentsAcked);
float SivOYELeFcjYCXYd = (float) 30.9;
SivOYELeFcjYCXYd = (float) (-9.083+(-60.716)+(-11.424)+(-1.189)+(-14.913)+(96.962)+(-86.171)+(65.405)+(54.864));
SivOYELeFcjYCXYd = (float) (92.583+(93.7)+(78.465)+(44.88)+(-3.591)+(-60.19)+(-97.954)+(-16.612)+(-68.358));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize <= SivOYELeFcjYCXYd) {
	qCwuxqCnJwdBAQJv = (float) (segmentsAcked-(SivOYELeFcjYCXYd)-(43.227)-(tcb->m_cWnd));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	qCwuxqCnJwdBAQJv = (float) (14.643/0.1);

} else {
	qCwuxqCnJwdBAQJv = (float) (((0.1)+(0.1)+(48.429)+(47.501))/((0.1)+(3.392)+(0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (tcb->m_segmentSize <= SivOYELeFcjYCXYd) {
	qCwuxqCnJwdBAQJv = (float) (segmentsAcked-(SivOYELeFcjYCXYd)-(43.227)-(tcb->m_cWnd));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	qCwuxqCnJwdBAQJv = (float) (14.643/0.1);

} else {
	qCwuxqCnJwdBAQJv = (float) (((0.1)+(0.1)+(48.429)+(47.501))/((0.1)+(3.392)+(0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
