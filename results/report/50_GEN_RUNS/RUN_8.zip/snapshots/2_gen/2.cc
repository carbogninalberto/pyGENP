int oSYQxoQOfmkVsZkM = (int) (-82.074+(-24.579)+(-81.229)+(-84.396));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
