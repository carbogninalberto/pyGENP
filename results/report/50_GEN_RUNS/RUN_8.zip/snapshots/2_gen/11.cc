segmentsAcked = (int) (54.084*(-86.247)*(78.727)*(-75.726)*(-31.434)*(-50.749)*(-44.56)*(-45.87));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-11.691+(19.876)+(-42.248)+(17.538));
CongestionAvoidance (tcb, segmentsAcked);
