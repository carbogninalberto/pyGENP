int FOvZDuFkhESZWnoi = (int) (99.605-(-62.578)-(-52.728)-(69.132)-(-0.953)-(-67.039)-(-75.009)-(-63.543)-(-99.846));
tcb->m_cWnd = (int) (20.124-(26.747)-(-37.771)-(61.262)-(-29.037)-(-55.168)-(98.738)-(-20.733));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-49.426-(-58.284)-(-45.46));
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((0.1)+(95.913)+((31.258+(18.543)+(15.592)+(1.903)))+(0.1)+(0.1)+(0.1))/((99.609)+(48.623)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);
	FOvZDuFkhESZWnoi = (int) (27.07-(82.226)-(95.217)-(69.569)-(19.855)-(41.649)-(86.271));

} else {
	tcb->m_cWnd = (int) (90.827-(94.473)-(segmentsAcked)-(21.685)-(94.693));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (62.92+(19.636));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (2.814-(68.683)-(-13.935));
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((0.1)+(95.913)+((31.258+(18.543)+(15.592)+(1.903)))+(0.1)+(0.1)+(0.1))/((99.609)+(48.623)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);
	FOvZDuFkhESZWnoi = (int) (27.07-(82.226)-(95.217)-(69.569)-(19.855)-(41.649)-(86.271));

} else {
	tcb->m_cWnd = (int) (90.827-(94.473)-(segmentsAcked)-(21.685)-(94.693));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (62.92+(19.636));

}
ReduceCwnd (tcb);
