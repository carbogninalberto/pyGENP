float VIpnskdFvEnZrhMR = (float) (74.3-(-5.859)-(0.936)-(58.772)-(-10.774)-(79.777)-(-49.221));
float RJEqqVXSeRXWDdjv = (float) ((-88.547+(-88.278)+(95.694)+(27.484)+(-45.062)+(14.691)+(-13.414)+(-38.152))/65.001);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
