if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (42.855+(1.382)+(6.229)+(tcb->m_segmentSize)+(57.498)+(48.535));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (62.542+(39.201));

} else {
	segmentsAcked = (int) (81.759+(-80.654)+(8.757));

}
if (segmentsAcked >= segmentsAcked) {
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) ((89.033-(7.406)-(tcb->m_cWnd)-(61.656)-(46.445)-(65.261)-(47.538)-(73.962))/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (67.55*(50.735)*(83.603)*(37.334)*(62.273)*(98.195)*(5.009)*(91.353));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
