float WygaSgKIxrKkcJCs = (float) (14.559*(66.056)*(-95.404)*(-74.013));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
