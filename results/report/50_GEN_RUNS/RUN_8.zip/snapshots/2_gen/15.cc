int vaApLaYqxlBLzyPZ = (int) (-83.251-(-6.593)-(85.765)-(55.356)-(14.246)-(94.22));
int JtNwutveAdGgBXTm = (int) (78.305-(79.91)-(-49.726)-(-72.384)-(-93.552)-(-16.232)-(-58.443));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-95.027/-66.495);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
