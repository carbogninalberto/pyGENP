segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-45.067+(-95.957)+(-77.701)+(-64.986));
CongestionAvoidance (tcb, segmentsAcked);
