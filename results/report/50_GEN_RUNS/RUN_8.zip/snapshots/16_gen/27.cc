float cmAIYVKUflRvJdkW = (float) (0.1/7.217);
CongestionAvoidance (tcb, segmentsAcked);
if (cmAIYVKUflRvJdkW >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (34.584-(9.242)-(18.599));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (55.001*(segmentsAcked)*(89.816)*(72.498)*(72.204));
	tcb->m_cWnd = (int) (81.183-(13.651)-(99.143)-(64.43)-(8.308)-(78.336)-(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (((81.199)+(0.1)+(27.732)+(81.291)+(93.072)+(0.1)+(64.62))/((0.1)));

}
if (tcb->m_ssThresh <= cmAIYVKUflRvJdkW) {
	tcb->m_segmentSize = (int) (73.082-(60.063)-(6.963)-(34.367)-(41.963)-(95.377)-(cmAIYVKUflRvJdkW)-(51.558)-(33.151));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(98.806)-(45.043)-(9.105));

} else {
	tcb->m_segmentSize = (int) (25.813*(17.192)*(67.318)*(35.961)*(55.942)*(4.301)*(74.412)*(56.751));
	segmentsAcked = (int) (32.064-(1.348)-(80.168)-(91.655)-(37.463));

}
tcb->m_cWnd = (int) (10.844-(26.557)-(5.761)-(cmAIYVKUflRvJdkW)-(tcb->m_segmentSize)-(82.596)-(48.492)-(12.031));
CongestionAvoidance (tcb, segmentsAcked);
float dalVrGptTdPNEXpF = (float) (0.1/19.786);
int zHsNYjJxULPBLlVI = (int) (cmAIYVKUflRvJdkW*(3.298));
if (cmAIYVKUflRvJdkW >= dalVrGptTdPNEXpF) {
	tcb->m_cWnd = (int) (7.238*(76.39)*(47.817));

} else {
	tcb->m_cWnd = (int) (21.142+(60.649)+(cmAIYVKUflRvJdkW)+(98.65)+(8.339));

}
