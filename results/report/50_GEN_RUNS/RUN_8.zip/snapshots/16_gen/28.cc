int JwSPxMKwJQKntVsd = (int) (21.282-(53.089));
int CeMpSROEIIHlUrca = (int) (40.823-(98.295));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (JwSPxMKwJQKntVsd < tcb->m_ssThresh) {
	segmentsAcked = (int) (52.191/24.121);
	CeMpSROEIIHlUrca = (int) (13.657+(56.621)+(CeMpSROEIIHlUrca)+(14.266)+(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (59.349*(0.351)*(29.421));

} else {
	segmentsAcked = (int) (25.472/20.64);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
