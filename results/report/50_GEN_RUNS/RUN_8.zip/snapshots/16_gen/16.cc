int KrXUxcWenmrIMYtV = (int) ((39.374+(24.208)+(51.394))/-49.816);
segmentsAcked = (int) (-87.704+(94.607)+(-2.054)+(20.294)+(40.823)+(42.064)+(21.018)+(33.318));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
