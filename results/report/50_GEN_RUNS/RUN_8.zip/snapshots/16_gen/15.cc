int KrXUxcWenmrIMYtV = (int) ((77.175+(-64.711)+(-57.805))/-93.104);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (64.822+(75.192)+(-12.95)+(21.892)+(43.292)+(54.378)+(64.325)+(-20.254));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
