segmentsAcked = (int) (88.194+(9.218)+(12.799)+(-19.662)+(63.153)+(18.182)+(54.312)+(44.735));
int KrXUxcWenmrIMYtV = (int) ((-80.801+(18.056)+(-65.482))/-85.102);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
