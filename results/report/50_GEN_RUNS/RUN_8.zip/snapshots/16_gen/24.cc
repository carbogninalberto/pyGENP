tcb->m_cWnd = (int) (64.91+(66.243)+(18.537)+(60.807)+(78.179)+(38.027)+(57.674)+(segmentsAcked));
tcb->m_ssThresh = (int) (5.311*(54.74)*(90.621)*(57.974));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (94.816-(81.608)-(65.351)-(tcb->m_segmentSize)-(48.56)-(37.598)-(79.736)-(88.612)-(74.017));

} else {
	segmentsAcked = (int) (1.491+(71.9));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
