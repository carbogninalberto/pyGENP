int KrXUxcWenmrIMYtV = (int) ((-57.197+(-59.38)+(-58.135))/61.237);
segmentsAcked = (int) (-13.259+(23.249)+(8.792)+(-89.158)+(-73.035)+(-19.687)+(-96.428)+(-2.684));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
