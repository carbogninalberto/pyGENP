segmentsAcked = (int) (-25.052+(-10.742)+(-45.669)+(-56.495)+(44.616)+(75.9)+(-98.737)+(-84.191));
int KrXUxcWenmrIMYtV = (int) ((66.828+(-17.133)+(-63.841))/91.494);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
