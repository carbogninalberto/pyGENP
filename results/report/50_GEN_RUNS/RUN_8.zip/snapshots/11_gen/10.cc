segmentsAcked = (int) (-49.382+(-17.804)+(42.248)+(2.974)+(-66.455)+(91.367)+(-41.513)+(-19.787));
int KrXUxcWenmrIMYtV = (int) ((28.463+(17.965)+(44.644))/-25.594);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
