float QfjHoHsXqhNCupnJ = (float) (32.645/-8.211);
