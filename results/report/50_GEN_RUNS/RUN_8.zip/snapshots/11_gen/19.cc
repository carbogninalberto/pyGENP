int KrXUxcWenmrIMYtV = (int) ((-63.302+(-68.109)+(56.572))/-27.749);
segmentsAcked = (int) (-5.1+(24.594)+(29.6)+(-55.54)+(-75.385)+(35.582)+(-30.388)+(-51.879));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
