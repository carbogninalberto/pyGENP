segmentsAcked = (int) (-72.719+(60.091)+(-49.071)+(-24.673)+(53.058)+(-55.594)+(-35.997)+(10.847));
int KrXUxcWenmrIMYtV = (int) ((61.683+(66.209)+(-21.859))/-80.446);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
