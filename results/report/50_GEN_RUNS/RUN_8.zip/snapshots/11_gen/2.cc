segmentsAcked = (int) (-88.943+(-97.953)+(-33.317)+(84.826)+(-28.819)+(-57.331)+(94.82)+(75.697));
int KrXUxcWenmrIMYtV = (int) ((7.843+(-16.846)+(-30.261))/-6.736);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
