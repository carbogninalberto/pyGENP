int KrXUxcWenmrIMYtV = (int) ((-18.28+(-41.501)+(26.61))/-44.439);
segmentsAcked = (int) (56.332+(-16.793)+(34.694)+(31.061)+(-85.92)+(-92.842)+(93.241)+(-84.79));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
