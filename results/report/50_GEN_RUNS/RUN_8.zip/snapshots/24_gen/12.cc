int woRjZAnhxFyoCiYO = (int) (-28.1/-15.13);
int ebxolWYZeUbjDvWS = (int) (-88.551+(-86.489)+(-83.096)+(16.707));
woRjZAnhxFyoCiYO = (int) (-60.278*(86.17));
woRjZAnhxFyoCiYO = (int) (-2.77*(14.692));
tcb->m_segmentSize = (int) (30.163-(28.535)-(71.224));
tcb->m_segmentSize = (int) (-98.004-(3.75)-(41.701));
