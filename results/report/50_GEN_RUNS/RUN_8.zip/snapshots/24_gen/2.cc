int hfDMHdjhCaXuQKma = (int) 1.099;
