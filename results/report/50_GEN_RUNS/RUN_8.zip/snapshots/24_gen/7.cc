int woRjZAnhxFyoCiYO = (int) (37.979/-69.631);
ReduceCwnd (tcb);
woRjZAnhxFyoCiYO = (int) (-33.395*(-54.323));
tcb->m_segmentSize = (int) (33.942-(-57.693)-(1.994));
