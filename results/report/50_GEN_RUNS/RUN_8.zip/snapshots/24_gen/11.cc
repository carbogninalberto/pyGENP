int smOzPBgSHnGRbjsf = (int) (38.366+(80.074)+(78.155)+(5.397)+(-33.96)+(44.101));
int PRjagzcUCCnoEmgm = (int) (-54.789/68.544);
CongestionAvoidance (tcb, segmentsAcked);
