int woRjZAnhxFyoCiYO = (int) (43.672/-57.854);
int nBTqGhwCpounUxyQ = (int) (-9.799-(0.975)-(19.086));
woRjZAnhxFyoCiYO = (int) (-45.966*(18.497));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-97.483-(-7.749)-(19.906));
