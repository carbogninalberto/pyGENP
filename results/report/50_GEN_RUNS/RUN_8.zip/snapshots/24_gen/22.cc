tcb->m_segmentSize = (int) (tcb->m_ssThresh-(8.094)-(87.073)-(67.467)-(58.508)-(83.673));
tcb->m_segmentSize = (int) (83.385+(tcb->m_segmentSize)+(71.76)+(59.61)+(77.412)+(0.403)+(60.236)+(tcb->m_ssThresh));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (12.388+(tcb->m_cWnd)+(tcb->m_ssThresh));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (62.571/29.848);
	tcb->m_cWnd = (int) (37.874+(7.32)+(84.751)+(15.845)+(21.895));
	tcb->m_segmentSize = (int) (85.226/0.1);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (0.1/9.96);

} else {
	tcb->m_ssThresh = (int) (88.499+(37.583));
	ReduceCwnd (tcb);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (58.157-(35.126)-(tcb->m_segmentSize)-(36.633)-(54.143)-(98.656)-(8.45)-(60.508));
