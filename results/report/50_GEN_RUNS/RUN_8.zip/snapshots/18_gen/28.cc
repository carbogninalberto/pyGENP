tcb->m_ssThresh = (int) (((46.388)+(0.1)+((2.506-(89.53)-(81.678)-(63.229)-(21.086)-(1.652)))+(0.1))/((38.756)+(0.1)+(0.1)+(0.1)));
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(67.337)+(65.366)+(74.122)+(17.345)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(79.048));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (98.779+(24.62)+(3.249)+(tcb->m_ssThresh)+(22.183));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (92.668+(51.821)+(44.402)+(27.082)+(93.155)+(24.648)+(tcb->m_segmentSize)+(43.083));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (((93.11)+(0.1)+(0.1)+((35.453-(72.712)-(99.406)-(68.552)-(22.758)-(23.749)-(48.897)-(segmentsAcked)))+(79.861)+(46.048))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked-(69.767)-(44.238)-(segmentsAcked)-(12.773));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (48.331/0.1);
