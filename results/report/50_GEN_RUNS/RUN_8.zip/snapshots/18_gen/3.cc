int KrXUxcWenmrIMYtV = (int) ((67.519+(-15.086)+(38.166))/46.465);
segmentsAcked = (int) (63.795+(-28.634)+(50.875)+(-57.597)+(-64.098)+(91.116)+(54.549)+(49.464));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
