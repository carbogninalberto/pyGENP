float YAmtWUxuhYjSfKQf = (float) (98.898+(-84.808)+(18.71)+(-40.493)+(23.728)+(-94.674));
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
YAmtWUxuhYjSfKQf = (float) (42.994/52.758);
