int KrXUxcWenmrIMYtV = (int) ((-81.258+(-51.605)+(68.683))/-43.627);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (12.09+(91.095)+(4.111)+(0.418)+(-84.528)+(2.162)+(-40.613)+(2.959));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
