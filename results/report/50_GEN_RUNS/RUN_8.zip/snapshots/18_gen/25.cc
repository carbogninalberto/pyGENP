segmentsAcked = (int) (0.1/0.1);
int FOBXCelGLBHMfbyI = (int) (82.075+(79.657)+(27.457)+(tcb->m_segmentSize)+(19.871)+(3.769)+(36.269)+(18.456)+(11.624));
tcb->m_ssThresh = (int) (FOBXCelGLBHMfbyI-(FOBXCelGLBHMfbyI)-(70.489)-(47.295)-(52.053)-(tcb->m_segmentSize)-(tcb->m_cWnd));
if (FOBXCelGLBHMfbyI == segmentsAcked) {
	segmentsAcked = (int) (68.648*(11.558)*(segmentsAcked)*(15.343)*(98.251)*(99.317));
	FOBXCelGLBHMfbyI = (int) (67.359-(53.366)-(0.375)-(64.385));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (16.75-(2.015)-(FOBXCelGLBHMfbyI)-(50.355)-(25.413));
	tcb->m_ssThresh = (int) (76.192*(95.77)*(41.822)*(99.12)*(76.41)*(88.999)*(35.844)*(7.402)*(88.279));

}
CongestionAvoidance (tcb, segmentsAcked);
