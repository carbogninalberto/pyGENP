int KrXUxcWenmrIMYtV = (int) ((13.543+(-42.379)+(-71.583))/66.012);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-67.239+(-23.049)+(-95.56)+(45.802)+(64.0)+(-12.161)+(-41.789)+(-93.698));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
