segmentsAcked = (int) (49.246+(34.531)+(95.823)+(36.941)+(92.256)+(9.845)+(48.482)+(81.147));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) ((((12.078*(72.76)*(83.351)*(14.723)))+(0.1)+(44.09)+(20.112))/((0.1)+(42.422)+(13.038)+(14.946)+(77.013)));
float mAmksyhvnuVEIqGW = (float) (92.678-(24.323)-(tcb->m_ssThresh));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
