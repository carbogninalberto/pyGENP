if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (88.992*(tcb->m_segmentSize)*(35.743)*(67.901)*(69.23)*(87.912)*(12.931)*(89.369)*(76.912));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(95.344)-(53.281)-(72.188)-(35.163)-(39.015));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (69.714+(tcb->m_ssThresh)+(45.632)+(95.004)+(40.888)+(7.383)+(tcb->m_segmentSize)+(segmentsAcked)+(34.041));

}
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_ssThresh = (int) (19.467-(tcb->m_cWnd)-(75.684)-(69.924)-(4.061)-(80.298)-(89.423));

} else {
	tcb->m_ssThresh = (int) (93.508-(tcb->m_segmentSize)-(52.409)-(21.681)-(tcb->m_ssThresh)-(69.922));
	tcb->m_cWnd = (int) (17.869+(94.392)+(75.418)+(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
float mWRTfTLmSFCYyTRs = (float) (segmentsAcked+(1.452)+(33.759)+(81.906)+(61.377)+(77.638)+(73.887)+(segmentsAcked));
