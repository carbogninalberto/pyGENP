TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (98.565-(93.891)-(43.668)-(18.492)-(tcb->m_ssThresh)-(71.151)-(tcb->m_cWnd)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (3.545+(44.877)+(56.641)+(70.741)+(tcb->m_segmentSize)+(98.304));
	segmentsAcked = (int) ((tcb->m_cWnd+(segmentsAcked))/0.1);
	tcb->m_ssThresh = (int) (32.427/96.382);

}
CongestionAvoidance (tcb, segmentsAcked);
