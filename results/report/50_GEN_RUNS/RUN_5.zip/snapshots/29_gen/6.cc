tcb->m_cWnd = (int) (-97.158+(-77.921)+(-69.324)+(64.296)+(-27.968)+(92.007)+(58.557)+(92.029));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-63.46*(1.721)*(29.257)*(-56.625)*(-32.191)*(45.02)*(-40.878)*(48.501)*(-84.704));
ReduceCwnd (tcb);
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (50.218-(91.912)-(5.693)-(76.437)-(69.687)-(19.711)-(37.051)-(segmentsAcked)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (43.558-(20.146));
	segmentsAcked = (int) (segmentsAcked*(2.001)*(38.861)*(75.068)*(11.245)*(93.605)*(tcb->m_cWnd));

}
