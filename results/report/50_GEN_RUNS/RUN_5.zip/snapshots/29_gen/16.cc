ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (19.386-(3.505)-(83.457)-(37.007)-(29.378)-(96.873)-(56.159)-(70.646));
tcb->m_ssThresh = (int) (tcb->m_cWnd+(46.494));
tcb->m_ssThresh = (int) (76.211+(18.21)+(38.81)+(segmentsAcked));
tcb->m_segmentSize = (int) (((53.806)+((19.0*(tcb->m_cWnd)))+((segmentsAcked-(98.447)-(45.234)-(tcb->m_cWnd)))+(0.1)+(66.921)+(52.893))/((0.1)));
int yGsrQfNZXqCyiTqD = (int) (82.941/30.284);
if (yGsrQfNZXqCyiTqD <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (19.725+(segmentsAcked)+(4.456)+(tcb->m_segmentSize)+(92.865)+(18.877)+(51.039)+(tcb->m_segmentSize));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (((0.1)+(35.814)+(0.1)+(0.1))/((0.1)+(10.999)+(82.075)+(16.227)));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (65.928*(18.242)*(57.359)*(74.598)*(98.085)*(79.959)*(29.653)*(yGsrQfNZXqCyiTqD));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
