if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (50.218-(91.912)-(5.693)-(76.437)-(69.687)-(19.711)-(37.051)-(segmentsAcked)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (43.558-(20.146));
	segmentsAcked = (int) (segmentsAcked*(2.001)*(38.861)*(75.068)*(11.245)*(93.605)*(tcb->m_cWnd));

}
ReduceCwnd (tcb);
int AFOrkdhNMuxhaquG = (int) (71.99*(-56.795)*(-94.207)*(-91.313)*(-47.75)*(69.056));
tcb->m_cWnd = (int) (93.18*(69.465)*(28.266)*(55.118)*(19.939)*(68.949)*(-95.121)*(12.649)*(-42.118));
ReduceCwnd (tcb);
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (50.218-(91.912)-(5.693)-(76.437)-(69.687)-(19.711)-(37.051)-(segmentsAcked)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (43.558-(20.146));
	segmentsAcked = (int) (segmentsAcked*(2.001)*(38.861)*(75.068)*(11.245)*(93.605)*(tcb->m_cWnd));

}
