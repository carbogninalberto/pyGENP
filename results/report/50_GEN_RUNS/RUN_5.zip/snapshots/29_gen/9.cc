float HTcPTcFEkfaVEcPn = (float) (46.776/-62.672);
if (segmentsAcked >= tcb->m_cWnd) {
	segmentsAcked = (int) (98.81/92.741);
	tcb->m_cWnd = (int) (11.365*(0.672));

} else {
	segmentsAcked = (int) (0.1/86.873);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
int sXWvHJYirzbPdxGW = (int) (((-90.314)+(0.527)+((51.155*(57.991)*(-95.528)*(68.886)*(-46.525)*(-6.447)*(-5.33)*(-85.135)))+((-38.764*(54.978)))+((38.215+(28.09)+(-96.204)))+(73.13)+(26.639))/((64.592)));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) ((67.007+(-66.919)+(-74.228)+(94.557)+(-33.301)+(-91.86))/76.76);
ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_cWnd) {
	segmentsAcked = (int) (98.81/92.741);
	tcb->m_cWnd = (int) (11.365*(0.672));

} else {
	segmentsAcked = (int) (0.1/86.873);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) ((-30.522+(-63.294)+(1.787)+(-47.705)+(39.36)+(-95.942))/38.808);
