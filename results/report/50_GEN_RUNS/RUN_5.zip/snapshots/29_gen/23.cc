if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) ((2.752+(66.222)+(68.316)+(56.197)+(86.693)+(tcb->m_segmentSize)+(tcb->m_cWnd))/0.1);
	tcb->m_segmentSize = (int) (54.933/93.838);
	tcb->m_ssThresh = (int) (85.972-(21.685)-(69.784)-(tcb->m_segmentSize)-(93.058));

} else {
	tcb->m_cWnd = (int) (((55.121)+(65.053)+(0.1)+(0.1)+(39.523)+(0.1))/((0.1)));
	tcb->m_ssThresh = (int) (71.601-(93.604)-(9.028)-(tcb->m_cWnd)-(17.102));

}
int KlSOBUCbrkfgTCqF = (int) (12.129-(10.07)-(25.789)-(tcb->m_cWnd)-(76.973));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((50.489)+(18.631)+((2.218*(tcb->m_ssThresh)*(29.94)*(93.39)*(8.782)*(52.758)*(90.496)*(99.217)))+(0.1)+(0.1))/((49.814)));

} else {
	tcb->m_segmentSize = (int) (93.111*(37.545)*(85.761)*(75.904)*(50.404)*(18.585)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(89.448));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (43.171-(60.774)-(tcb->m_cWnd)-(27.329)-(98.912)-(46.473)-(40.644));

}
if (KlSOBUCbrkfgTCqF <= KlSOBUCbrkfgTCqF) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(79.794)+(44.117)+(83.736));
	tcb->m_cWnd = (int) (0.1/26.055);

} else {
	tcb->m_segmentSize = (int) (((0.1)+(70.647)+(0.1)+(24.989))/((0.1)));
	ReduceCwnd (tcb);

}
KlSOBUCbrkfgTCqF = (int) (48.251*(20.255)*(96.807)*(78.556)*(63.048));
tcb->m_cWnd = (int) (74.747+(92.0)+(46.877)+(segmentsAcked)+(93.161)+(tcb->m_ssThresh));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh > KlSOBUCbrkfgTCqF) {
	tcb->m_segmentSize = (int) (29.199+(36.206)+(12.108)+(53.148)+(51.537));

} else {
	tcb->m_segmentSize = (int) (55.557-(25.574)-(71.749)-(39.718)-(22.754)-(tcb->m_cWnd));
	segmentsAcked = (int) (55.975+(tcb->m_segmentSize)+(segmentsAcked)+(85.485)+(segmentsAcked)+(93.977)+(1.627)+(61.507)+(36.35));

}
