tcb->m_segmentSize = (int) (80.673+(segmentsAcked)+(77.505)+(39.842)+(3.868));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
int dWmzWUtBYurUBfMd = (int) (97.09*(31.99)*(67.617)*(43.135)*(81.847));
