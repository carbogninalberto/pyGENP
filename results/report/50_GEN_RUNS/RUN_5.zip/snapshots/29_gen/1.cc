float qLlQswZkkMOqbhBq = (float) (20.75+(-85.397)+(-11.725)+(-18.457)+(36.671));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
