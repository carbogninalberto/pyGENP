if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (94.929*(2.878)*(tcb->m_cWnd)*(31.674)*(91.672));

} else {
	tcb->m_segmentSize = (int) (57.633/77.437);
	tcb->m_segmentSize = (int) (75.854*(11.039)*(1.586)*(50.623)*(30.089)*(5.501)*(32.845));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (segmentsAcked-(52.271)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(39.158)-(93.338)-(70.456));
float UfDRvSsUcTHBISDs = (float) (0.1/23.637);
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (9.361-(tcb->m_segmentSize)-(69.234)-(97.769)-(tcb->m_ssThresh)-(46.013)-(14.592)-(37.927)-(24.492));
	tcb->m_cWnd = (int) ((7.096-(16.149)-(UfDRvSsUcTHBISDs))/0.1);

} else {
	tcb->m_segmentSize = (int) (64.687+(51.631)+(57.153)+(59.823));
	tcb->m_ssThresh = (int) (58.176/12.749);
	segmentsAcked = (int) ((87.696+(50.595)+(65.919))/0.1);

}
tcb->m_cWnd = (int) (31.926-(89.33)-(21.299)-(72.083)-(54.033));
if (segmentsAcked >= segmentsAcked) {
	segmentsAcked = (int) (29.451+(91.177));
	tcb->m_cWnd = (int) (((43.943)+(0.1)+((97.642+(0.831)+(tcb->m_cWnd)+(48.096)))+((93.812+(77.432)+(2.023)+(19.879)+(79.842)+(44.187)+(17.717)+(tcb->m_segmentSize)))+(99.741))/((97.231)+(6.603)+(36.426)));
	segmentsAcked = (int) (70.453+(95.945)+(67.764)+(93.601)+(76.73)+(63.424)+(16.12)+(86.307));

} else {
	segmentsAcked = (int) (29.503*(39.631));

}
float LcEVeFPVFKCTngJL = (float) (49.459*(28.405)*(35.524)*(90.281)*(73.038)*(UfDRvSsUcTHBISDs)*(24.667)*(41.533)*(84.153));
if (UfDRvSsUcTHBISDs != LcEVeFPVFKCTngJL) {
	tcb->m_cWnd = (int) (UfDRvSsUcTHBISDs+(78.495)+(25.911)+(51.718)+(97.084));
	tcb->m_ssThresh = (int) (72.357-(72.41)-(86.39)-(1.597)-(45.897));

} else {
	tcb->m_cWnd = (int) (0.1/26.59);
	tcb->m_ssThresh = (int) (8.285*(1.512));
	segmentsAcked = (int) (LcEVeFPVFKCTngJL-(55.75)-(74.993)-(4.864));

}
