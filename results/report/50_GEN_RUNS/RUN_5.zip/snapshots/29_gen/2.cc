ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-27.548*(57.944)*(42.263)*(86.554)*(67.545)*(-46.603)*(50.303)*(-77.42)*(99.526));
ReduceCwnd (tcb);
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (50.218-(91.912)-(5.693)-(76.437)-(69.687)-(19.711)-(37.051)-(segmentsAcked)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (43.558-(20.146));
	segmentsAcked = (int) (segmentsAcked*(2.001)*(38.861)*(75.068)*(11.245)*(93.605)*(tcb->m_cWnd));

}
