TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (14.323-(18.005)-(tcb->m_segmentSize)-(6.859)-(24.349)-(65.318)-(segmentsAcked)-(43.387));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (63.773+(tcb->m_segmentSize)+(34.236)+(19.923)+(13.05));

}
tcb->m_segmentSize = (int) (segmentsAcked+(5.146));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(61.804));
	tcb->m_cWnd = (int) (19.795+(94.185)+(18.285)+(17.571)+(tcb->m_cWnd)+(84.307));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (0.1/11.89);

}
if (tcb->m_ssThresh < segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(27.99)+(21.128)+(86.118)+(60.267)+(43.82)+(segmentsAcked)+(23.97));
	tcb->m_ssThresh = (int) (9.352-(tcb->m_cWnd)-(29.487)-(20.729)-(tcb->m_segmentSize)-(50.488)-(33.749)-(55.14)-(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) (96.048-(13.447));
	tcb->m_segmentSize = (int) (20.617/24.674);
	CongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((84.582)+(0.1)+((26.65-(77.871)-(61.082)-(24.232)-(tcb->m_segmentSize)-(36.22)))+(52.662))/((0.1)));
	tcb->m_ssThresh = (int) (49.092-(58.782)-(46.743)-(57.663));

} else {
	tcb->m_cWnd = (int) (7.603-(96.819)-(75.503)-(97.116)-(86.735)-(68.628));
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(7.421)+(76.715));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(61.908)+(71.595)+(33.555)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(80.613)+(tcb->m_ssThresh)+(62.062));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	segmentsAcked = (int) (95.888+(tcb->m_ssThresh)+(10.601)+(segmentsAcked)+(63.791));

} else {
	segmentsAcked = (int) (59.414-(53.549)-(7.853));

}
