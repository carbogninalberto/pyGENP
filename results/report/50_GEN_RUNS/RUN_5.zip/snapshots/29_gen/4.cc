float HTcPTcFEkfaVEcPn = (float) 26.853;
if (segmentsAcked >= tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/86.873);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (98.81/92.741);
	tcb->m_cWnd = (int) (11.365*(0.672));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
