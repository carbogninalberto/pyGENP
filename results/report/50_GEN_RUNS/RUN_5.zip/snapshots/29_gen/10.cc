tcb->m_cWnd = (int) (38.871-(71.312));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_ssThresh = (int) (97.876-(89.147));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (88.357*(tcb->m_cWnd)*(67.409)*(tcb->m_cWnd)*(83.177)*(88.997)*(tcb->m_ssThresh));

}
int gzjiEKLyZCqAMcbR = (int) ((26.165-(59.82)-(92.522)-(3.701)-(94.008))/18.867);
tcb->m_cWnd = (int) (85.278*(49.606)*(2.395));
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_cWnd = (int) (19.653*(44.088)*(tcb->m_cWnd)*(tcb->m_cWnd)*(74.289)*(32.257));
	gzjiEKLyZCqAMcbR = (int) (((53.677)+(11.768)+(95.587)+(0.1))/((0.1)+(0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (70.76-(53.226)-(96.681)-(35.893)-(26.046)-(95.61)-(15.05));
	tcb->m_segmentSize = (int) (((0.1)+(37.119)+(0.1)+(0.1)+(10.445)+(0.1))/((0.1)+(0.1)+(0.1)));

}
