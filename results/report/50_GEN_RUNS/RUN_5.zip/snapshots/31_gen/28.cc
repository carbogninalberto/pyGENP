ReduceCwnd (tcb);
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked*(62.894)*(99.772)*(97.433)*(1.83)*(tcb->m_ssThresh)*(82.694));
	tcb->m_cWnd = (int) (26.663*(tcb->m_segmentSize)*(49.593)*(tcb->m_segmentSize)*(47.266));
	tcb->m_cWnd = (int) ((((34.974-(54.212)-(24.311)-(72.776)-(11.777)-(14.788)))+(75.518)+(84.088)+(0.1))/((15.843)+(0.1)));

} else {
	segmentsAcked = (int) (96.492+(77.687)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(37.8)+(79.582)+(82.24)+(tcb->m_segmentSize));

}
segmentsAcked = (int) (tcb->m_segmentSize-(51.148)-(35.481)-(27.104)-(48.387));
segmentsAcked = (int) (25.437-(15.524)-(72.584)-(68.461)-(tcb->m_ssThresh)-(49.773)-(22.554)-(97.275));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (50.644*(77.55)*(21.518)*(tcb->m_segmentSize)*(14.424)*(91.48)*(53.921)*(7.616)*(94.89));
