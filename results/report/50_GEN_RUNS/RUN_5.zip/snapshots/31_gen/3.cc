segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (5.065+(76.239)+(77.934)+(24.487));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (15.815-(35.963)-(39.107)-(50.125)-(44.1)-(10.26)-(33.814));
	tcb->m_ssThresh = (int) (73.973-(91.757)-(72.159)-(0.247)-(96.079)-(76.937));
	segmentsAcked = (int) (79.104-(12.361)-(93.728)-(9.002));

} else {
	segmentsAcked = (int) (9.198+(3.816)+(8.268)+(71.449)+(42.369)+(58.247)+(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);

}
tcb->m_ssThresh = (int) (19.89+(tcb->m_segmentSize)+(43.626)+(37.257)+(93.241));
