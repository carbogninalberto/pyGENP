int fTWgujvQmnZMwyNh = (int) (49.486-(-32.149)-(-39.687)-(-33.499)-(-96.963)-(-24.493)-(60.204)-(30.888));
tcb->m_cWnd = (int) (-15.657+(-31.885)+(-89.392)+(-3.305));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-71.994-(-80.551)-(0.087)-(69.962)-(-55.998));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (0.261-(-72.125)-(54.12));
