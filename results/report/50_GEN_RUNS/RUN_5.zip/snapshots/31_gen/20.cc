tcb->m_segmentSize = (int) (tcb->m_segmentSize*(33.05));
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (22.773*(31.559)*(21.299)*(segmentsAcked)*(39.119)*(86.56)*(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_ssThresh = (int) (96.625-(tcb->m_ssThresh)-(98.838)-(11.317));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(tcb->m_segmentSize)+(94.631)+(14.964)+(74.338)+(3.926)+(30.342)+(73.857)+(8.118));
	tcb->m_segmentSize = (int) (7.002/0.1);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (56.272/0.1);
CongestionAvoidance (tcb, segmentsAcked);
