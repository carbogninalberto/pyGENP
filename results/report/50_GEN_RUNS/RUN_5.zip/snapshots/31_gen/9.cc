segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (47.345+(89.909)+(42.547)+(33.031)+(10.118));
float gsIhBjDxiDtFooSD = (float) (tcb->m_segmentSize+(88.083)+(45.616)+(68.217));
