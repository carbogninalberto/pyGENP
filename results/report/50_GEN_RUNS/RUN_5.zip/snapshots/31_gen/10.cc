segmentsAcked = (int) (0.1/98.213);
tcb->m_segmentSize = (int) (2.406/0.1);
segmentsAcked = (int) (37.394-(54.485)-(21.539)-(18.605)-(44.005));
tcb->m_cWnd = (int) (44.988+(66.796)+(36.27)+(57.492));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (21.916*(24.158)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (5.755+(27.982)+(38.943)+(59.271)+(66.639));

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(tcb->m_segmentSize)-(86.954));
	tcb->m_segmentSize = (int) (((0.1)+(92.349)+(0.1)+(44.663)+((34.367-(52.522)-(58.752)-(53.017)))+(78.403))/((0.1)+(95.307)+(85.74)));

}
segmentsAcked = (int) (84.97*(68.833));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (58.57-(tcb->m_ssThresh)-(segmentsAcked)-(83.342)-(72.581));
