segmentsAcked = (int) (31.077/24.274);
segmentsAcked = (int) (6.815+(tcb->m_ssThresh)+(96.256));
ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((0.1)+((49.075*(5.826)*(21.292)*(91.118)*(67.479)*(95.529)*(34.959)*(80.619)*(4.133)))+(0.1)+(48.945)+(41.595)+(0.1)+(0.1)+(54.191))/((34.238)));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (((24.943)+(0.1)+((tcb->m_segmentSize+(tcb->m_segmentSize)+(34.447)+(20.445)+(tcb->m_segmentSize)+(93.227)+(68.712)))+(63.946))/((5.615)));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
int HRecHBjuMjEedLSo = (int) (((20.104)+(0.1)+(0.1)+((97.551+(99.566)))+(96.732))/((95.898)+(0.1)));
ReduceCwnd (tcb);
