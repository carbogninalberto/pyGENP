tcb->m_cWnd = (int) (-63.678*(-98.864)*(22.858));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (20.3+(3.895)+(30.081)+(33.222)+(7.811)+(50.667)+(-5.044)+(-72.013));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
