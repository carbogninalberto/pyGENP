segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (segmentsAcked-(96.017)-(92.087));
	tcb->m_ssThresh = (int) (6.324-(82.855)-(7.539)-(99.18)-(61.802)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(47.1)-(21.811));
	tcb->m_ssThresh = (int) (99.429*(87.962)*(13.664)*(81.755)*(83.782)*(14.816)*(62.18));

} else {
	tcb->m_cWnd = (int) (63.669+(2.641));

}
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (84.729*(65.373)*(93.786)*(tcb->m_ssThresh)*(69.896));

} else {
	tcb->m_cWnd = (int) ((74.671-(22.568)-(24.675)-(9.871)-(51.059))/0.1);
	tcb->m_segmentSize = (int) (19.607+(34.791)+(54.761)+(65.047)+(37.693)+(tcb->m_cWnd));

}
tcb->m_segmentSize = (int) (1.359+(59.385));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (24.256-(83.317));
	segmentsAcked = (int) (((0.1)+(0.1)+(26.343)+(0.1)+(72.753))/((7.166)));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (44.445/98.39);
	segmentsAcked = (int) (47.956-(59.643)-(94.085)-(tcb->m_ssThresh));

}
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (8.784*(14.042)*(15.903)*(74.614)*(14.782)*(1.459)*(77.904)*(segmentsAcked)*(93.448));
	tcb->m_ssThresh = (int) (18.078+(tcb->m_segmentSize)+(11.608)+(94.418));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(segmentsAcked)-(26.144)-(segmentsAcked)-(96.428)-(24.832));
	segmentsAcked = (int) (8.393/0.1);

}
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (86.989+(40.478)+(80.324)+(19.953)+(95.076)+(1.212)+(86.829));
	tcb->m_cWnd = (int) (2.716-(78.568)-(tcb->m_segmentSize)-(88.217)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (84.277/77.715);

}
