if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (12.112/1.224);
	ReduceCwnd (tcb);
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (6.82-(69.521));

}
tcb->m_ssThresh = (int) (22.784*(18.202)*(54.945)*(31.241)*(96.119)*(33.839)*(36.634)*(69.751)*(19.721));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (33.84+(tcb->m_cWnd));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (2.774+(tcb->m_ssThresh)+(35.27)+(93.482));
	tcb->m_cWnd = (int) (11.091*(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (46.98-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(48.269)-(51.186)-(88.448)-(81.875)-(38.649));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (83.175-(tcb->m_cWnd)-(52.907)-(9.987)-(44.555)-(9.652)-(99.272));
	tcb->m_segmentSize = (int) ((((62.406-(56.712)-(85.247)-(66.085)-(53.765)))+(0.1)+(95.823)+(0.1)+(3.83))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (65.51-(15.822)-(tcb->m_segmentSize)-(89.834)-(12.995));

}
segmentsAcked = (int) (65.626+(75.41));
