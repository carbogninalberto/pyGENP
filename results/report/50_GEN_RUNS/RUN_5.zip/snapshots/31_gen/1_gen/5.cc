segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-7.448+(59.347));
segmentsAcked = (int) (-86.932/30.152);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (49.643+(-51.338)+(-65.439));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (29.199+(75.541)+(78.444));
