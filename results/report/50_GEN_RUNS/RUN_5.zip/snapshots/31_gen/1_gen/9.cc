CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-66.403+(-38.677)+(-42.742)+(-50.107)+(46.436)+(52.598)+(56.841)+(-34.177));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
