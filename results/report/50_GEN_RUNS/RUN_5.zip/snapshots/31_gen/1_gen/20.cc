if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(18.36)+(16.054)+(6.351));
	tcb->m_cWnd = (int) (46.316+(74.166)+(66.916)+(1.213)+(74.503)+(83.953));

} else {
	segmentsAcked = (int) (((0.1)+(55.99)+(0.1)+(0.1)+(0.1))/((33.768)));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
