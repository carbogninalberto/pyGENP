float BXAXKgHdQSfVmNBv = (float) 68.31;
