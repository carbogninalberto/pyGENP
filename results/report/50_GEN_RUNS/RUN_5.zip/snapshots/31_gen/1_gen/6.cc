segmentsAcked = (int) (54.418-(82.506)-(-62.252)-(21.508)-(15.177));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (7.209+(-38.825)+(-28.479)+(-97.015)+(-67.788)+(-33.535)+(77.821)+(-12.383));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-96.366+(89.584)+(13.995)+(-83.908)+(-30.211)+(-98.905)+(71.755)+(-84.675));
