tcb->m_ssThresh = (int) (0.1/0.1);
tcb->m_segmentSize = (int) (47.159+(tcb->m_ssThresh)+(55.965)+(26.712)+(17.491));
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
