tcb->m_ssThresh = (int) (24.678-(17.478)-(85.189)-(90.749)-(26.541)-(36.265)-(45.069)-(22.26));
tcb->m_ssThresh = (int) (79.852+(63.274)+(69.762)+(22.363)+(81.598)+(90.806)+(tcb->m_cWnd));
tcb->m_ssThresh = (int) (33.886+(16.262)+(21.375));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	segmentsAcked = (int) (2.75+(83.206));
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(3.162)-(75.104));
	tcb->m_ssThresh = (int) (85.143+(tcb->m_cWnd)+(16.26));

} else {
	segmentsAcked = (int) (((0.1)+((tcb->m_ssThresh-(76.466)-(94.771)-(segmentsAcked)-(11.269)-(tcb->m_segmentSize)))+(0.1)+(74.636)+(72.664)+(81.772))/((94.678)+(0.1)));

}
