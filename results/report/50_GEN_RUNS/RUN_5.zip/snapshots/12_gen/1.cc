segmentsAcked = (int) (-11.905+(-97.818)+(84.673)+(-0.578)+(4.325));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-75.666+(-50.191)+(50.914)+(54.252)+(11.118));
segmentsAcked = (int) (-24.797+(-44.872)+(52.524)+(60.36)+(-70.324));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
