segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-42.556*(77.145)*(-76.043)*(-36.078));
tcb->m_segmentSize = (int) (93.049*(-34.001)*(-28.615)*(45.769)*(98.308));
tcb->m_segmentSize = (int) (54.799-(-58.944)-(41.493)-(-96.085)-(-16.504)-(-74.612)-(65.714)-(-40.589));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-56.274*(18.549)*(76.995)*(-52.875)*(-41.729));
segmentsAcked = SlowStart (tcb, segmentsAcked);
