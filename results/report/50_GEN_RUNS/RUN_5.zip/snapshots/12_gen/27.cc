if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_ssThresh = (int) (((0.1)+(62.888)+(0.1)+(40.536)+(0.1))/((32.457)));

} else {
	tcb->m_ssThresh = (int) (81.945*(76.613)*(12.398)*(96.156)*(77.784)*(77.172)*(29.514)*(8.693));
	segmentsAcked = (int) (50.192+(89.105)+(80.454));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) (90.967*(49.607)*(tcb->m_ssThresh)*(43.524)*(38.778));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (96.97*(70.072)*(89.311)*(35.833)*(29.532)*(22.111)*(40.288)*(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh-(71.995)-(31.717));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((24.227)+(75.317)+(0.1)+(74.242)+(0.1))/((0.1)+(0.1)+(91.755)));
	tcb->m_segmentSize = (int) (33.083*(62.137)*(53.502)*(tcb->m_ssThresh)*(10.144)*(82.733)*(84.162)*(69.893));
	tcb->m_cWnd = (int) (41.164+(38.16)+(4.573)+(9.455)+(72.516)+(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (83.882-(tcb->m_cWnd)-(1.544)-(93.656));
	tcb->m_ssThresh = (int) (31.593*(81.085)*(33.692)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(57.436));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
