segmentsAcked = (int) (51.922+(-16.454)+(-44.772)+(-55.282)+(94.73));
segmentsAcked = (int) (88.539+(-77.348)+(87.626)+(-68.749)+(85.301));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (95.303+(-12.905)+(61.6)+(28.537)+(22.225));
segmentsAcked = SlowStart (tcb, segmentsAcked);
