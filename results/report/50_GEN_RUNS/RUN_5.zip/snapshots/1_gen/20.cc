tcb->m_cWnd = (int) (77.529-(46.072));
tcb->m_ssThresh = (int) (tcb->m_ssThresh*(18.234)*(39.159)*(99.676)*(47.062)*(tcb->m_cWnd));
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (70.727*(69.075)*(0.969)*(49.577)*(tcb->m_cWnd)*(42.926));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (33.482+(tcb->m_segmentSize)+(52.001)+(segmentsAcked));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
