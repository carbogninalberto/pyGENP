float PmzShqaJPGKBZklh = (float) (3.27-(tcb->m_segmentSize)-(62.009)-(segmentsAcked)-(29.124));
float EnIlFjlUSLRmbzwU = (float) (tcb->m_cWnd-(segmentsAcked)-(67.166)-(63.586)-(tcb->m_cWnd)-(PmzShqaJPGKBZklh)-(11.034));
if (tcb->m_cWnd <= PmzShqaJPGKBZklh) {
	PmzShqaJPGKBZklh = (float) (((0.1)+(0.1)+(0.1)+(88.075)+(43.589))/((0.1)+(71.051)));

} else {
	PmzShqaJPGKBZklh = (float) (14.438+(15.118)+(77.966));
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (7.976*(tcb->m_ssThresh)*(14.648)*(60.59));
tcb->m_ssThresh = (int) (99.6*(21.535)*(5.85)*(32.656)*(tcb->m_ssThresh)*(segmentsAcked));
PmzShqaJPGKBZklh = (float) (78.259+(6.495)+(19.272)+(39.399)+(74.778)+(70.557));
if (tcb->m_segmentSize > EnIlFjlUSLRmbzwU) {
	segmentsAcked = (int) (45.219*(1.728)*(1.995)*(10.248)*(10.937)*(40.259));
	EnIlFjlUSLRmbzwU = (float) (segmentsAcked-(99.917)-(68.616)-(46.302)-(62.439)-(35.18)-(PmzShqaJPGKBZklh));

} else {
	segmentsAcked = (int) (20.756-(58.697)-(67.817)-(12.806));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (0.1/59.526);

}
segmentsAcked = (int) (37.692+(33.345)+(EnIlFjlUSLRmbzwU)+(84.649));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
