ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (segmentsAcked+(60.238)+(17.741)+(27.054)+(46.63));
int ZhpWMureVECrtKGT = (int) (tcb->m_cWnd+(16.961)+(38.54)+(48.481));
tcb->m_ssThresh = (int) (32.489*(tcb->m_segmentSize)*(37.026)*(tcb->m_segmentSize)*(24.602));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float SoSHwpdRFObCaTlm = (float) (0.1/69.848);
