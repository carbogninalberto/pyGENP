if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (32.442*(15.971)*(16.816)*(tcb->m_cWnd)*(16.373));
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(64.663)+(30.351)+(39.703));

} else {
	tcb->m_cWnd = (int) (50.629+(58.944)+(59.39)+(48.239)+(segmentsAcked));
	tcb->m_segmentSize = (int) (66.522*(tcb->m_ssThresh));
	segmentsAcked = (int) (84.422-(71.364)-(54.909));

}
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_cWnd = (int) (2.295/46.402);

} else {
	tcb->m_cWnd = (int) (6.416*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(45.995)*(83.97));

}
segmentsAcked = (int) (tcb->m_segmentSize+(61.643)+(3.587)+(88.199)+(tcb->m_ssThresh));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (20.437*(tcb->m_segmentSize)*(87.264)*(80.68));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(35.427)-(69.526)-(74.972)-(98.279)-(tcb->m_segmentSize)-(4.159)-(0.31)-(21.098));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(66.222)*(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (66.456*(tcb->m_segmentSize)*(90.769)*(tcb->m_segmentSize)*(52.526)*(40.981)*(segmentsAcked)*(60.292)*(tcb->m_ssThresh));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
