ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (0.1/46.495);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((54.001)+(0.1)+(0.1)+(92.01)+((33.556-(51.915)-(77.852)-(tcb->m_ssThresh)-(35.17)-(24.653)))+(57.182))/((26.129)));
float eWubzIKxHXIjzhln = (float) (7.982+(68.654)+(53.173)+(63.995)+(54.615)+(53.636)+(segmentsAcked)+(2.912)+(52.367));
tcb->m_ssThresh = (int) (37.015*(38.186)*(26.799)*(0.665)*(26.603)*(89.608));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
