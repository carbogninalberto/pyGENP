segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (86.967*(58.287)*(66.009)*(70.996));
tcb->m_segmentSize = (int) (35.524-(8.607)-(61.086)-(15.183)-(3.113)-(tcb->m_cWnd)-(84.364)-(75.289));
tcb->m_ssThresh = (int) (78.509+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(49.193)+(tcb->m_cWnd)+(73.679)+(81.002));
tcb->m_segmentSize = (int) (26.803*(84.147)*(segmentsAcked)*(3.214)*(1.794));
segmentsAcked = SlowStart (tcb, segmentsAcked);
