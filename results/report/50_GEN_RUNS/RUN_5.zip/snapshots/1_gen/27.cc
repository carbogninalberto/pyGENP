tcb->m_cWnd = (int) (25.788*(30.864)*(45.023)*(59.314)*(74.815)*(50.513)*(63.404));
segmentsAcked = (int) (8.871*(86.401)*(62.895));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	segmentsAcked = (int) (94.453*(98.69)*(19.642)*(10.898));

} else {
	segmentsAcked = (int) (28.432*(86.547)*(segmentsAcked)*(80.496));
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (16.624+(88.606)+(36.172)+(68.706)+(65.566)+(24.821)+(32.103)+(87.564)+(59.984));
int qVaWqWCBAwYIAXXK = (int) (45.287*(1.837));
