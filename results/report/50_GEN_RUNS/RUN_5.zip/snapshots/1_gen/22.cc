CongestionAvoidance (tcb, segmentsAcked);
float tOVCpnWHeSowuQzZ = (float) ((73.393+(20.85)+(75.188)+(tcb->m_ssThresh))/22.289);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/43.98);

} else {
	tcb->m_cWnd = (int) (77.82+(45.712)+(41.509)+(54.587)+(99.464)+(88.741));

}
ReduceCwnd (tcb);
