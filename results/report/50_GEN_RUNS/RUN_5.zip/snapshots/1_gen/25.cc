tcb->m_segmentSize = (int) (tcb->m_ssThresh*(35.842)*(tcb->m_segmentSize)*(35.868)*(6.725)*(73.003)*(tcb->m_cWnd));
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (28.158*(tcb->m_ssThresh)*(73.569)*(76.408)*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (37.943*(35.997)*(tcb->m_segmentSize)*(segmentsAcked));
	segmentsAcked = (int) (71.107-(83.622)-(13.311));
	ReduceCwnd (tcb);

}
float uElwkYxLurTfUvBu = (float) (0.1/0.1);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
