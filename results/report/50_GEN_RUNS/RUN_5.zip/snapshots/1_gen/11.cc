ReduceCwnd (tcb);
tcb->m_cWnd = (int) (87.383+(79.776)+(68.861)+(tcb->m_segmentSize)+(94.845));
tcb->m_ssThresh = (int) (12.726*(tcb->m_ssThresh));
tcb->m_ssThresh = (int) (99.232+(tcb->m_ssThresh)+(5.344)+(25.881));
tcb->m_segmentSize = (int) (tcb->m_cWnd-(tcb->m_segmentSize)-(56.8)-(78.222)-(92.885));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
