ReduceCwnd (tcb);
if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_ssThresh = (int) (93.657-(55.16)-(49.017)-(tcb->m_ssThresh)-(66.455)-(84.954)-(19.715)-(62.042)-(52.868));
	segmentsAcked = (int) (86.15-(95.674)-(55.307)-(49.72)-(25.302)-(40.319)-(81.562));
	tcb->m_cWnd = (int) (7.506+(39.848)+(9.161));

} else {
	tcb->m_ssThresh = (int) (94.574+(42.98)+(41.846)+(26.97));

}
float lmzNUBtopmZzKLvG = (float) (49.954/28.04);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
lmzNUBtopmZzKLvG = (float) (67.657+(65.779)+(99.807)+(tcb->m_ssThresh)+(36.869)+(59.227)+(53.599));
CongestionAvoidance (tcb, segmentsAcked);
