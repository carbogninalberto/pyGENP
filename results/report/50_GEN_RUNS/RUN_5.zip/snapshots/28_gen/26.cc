if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (61.305*(26.721)*(tcb->m_segmentSize)*(41.077)*(70.228)*(28.679)*(34.599));

} else {
	tcb->m_segmentSize = (int) ((44.0+(72.217)+(46.688)+(10.061))/14.048);
	tcb->m_cWnd = (int) (((77.521)+(28.526)+((27.483+(62.424)+(72.245)+(59.669)+(98.501)+(98.812)+(16.436)+(segmentsAcked)+(tcb->m_cWnd)))+(95.494))/((93.286)+(27.234)+(0.1)));
	tcb->m_segmentSize = (int) (41.167-(41.106)-(52.121)-(21.93)-(28.359)-(78.789)-(57.944)-(66.643)-(17.059));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (67.46/0.1);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((70.016*(91.001)*(59.061)*(12.754)*(18.345)*(60.185)*(79.475))/0.1);
	tcb->m_ssThresh = (int) (64.633-(tcb->m_ssThresh)-(tcb->m_ssThresh));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (89.507*(87.18)*(87.494));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (6.826-(84.075)-(18.261)-(22.096)-(16.878)-(segmentsAcked)-(60.34)-(95.784));
