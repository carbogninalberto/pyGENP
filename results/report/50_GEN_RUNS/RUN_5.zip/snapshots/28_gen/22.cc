float CixwODnXKSGvcVPd = (float) (0.1/46.675);
tcb->m_ssThresh = (int) (69.147*(segmentsAcked)*(70.659));
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= segmentsAcked) {
	CixwODnXKSGvcVPd = (float) (0.1/0.1);
	tcb->m_cWnd = (int) (tcb->m_cWnd*(tcb->m_ssThresh)*(segmentsAcked)*(61.176)*(42.484));

} else {
	CixwODnXKSGvcVPd = (float) (((79.665)+((4.693+(77.909)+(91.702)+(86.619)+(segmentsAcked)+(40.398)+(tcb->m_cWnd)))+((57.087+(tcb->m_cWnd)))+(98.515)+(91.568)+(66.669))/((4.543)+(0.1)+(27.782)));
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (42.859-(73.901)-(88.384)-(11.648)-(50.302)-(95.244)-(66.877));
CixwODnXKSGvcVPd = (float) (((0.1)+(80.268)+((23.438*(tcb->m_segmentSize)))+(0.1)+((14.239+(CixwODnXKSGvcVPd)))+(39.761))/((64.347)+(0.1)));
