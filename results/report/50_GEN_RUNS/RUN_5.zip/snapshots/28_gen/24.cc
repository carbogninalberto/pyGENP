CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	segmentsAcked = (int) (24.461*(1.966)*(49.955)*(27.86)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (22.03-(19.264)-(42.298));

} else {
	segmentsAcked = (int) (53.875*(1.873)*(11.951)*(17.397)*(19.573)*(segmentsAcked));

}
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	segmentsAcked = (int) (85.714-(6.341)-(88.353)-(8.165));
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(57.381)+(39.085)+(67.097)+(83.163)+(57.635));

} else {
	segmentsAcked = (int) (52.216+(17.691)+(66.666)+(69.666)+(72.348)+(81.395)+(26.429)+(98.456));

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(52.419)*(51.335)*(87.634)*(50.661)*(83.582)*(70.603));
	tcb->m_ssThresh = (int) (70.786/0.1);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (30.345-(tcb->m_ssThresh)-(56.516)-(2.795)-(50.241));

}
tcb->m_segmentSize = (int) (88.005*(82.134)*(tcb->m_segmentSize)*(segmentsAcked)*(35.271)*(81.973));
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked*(22.686));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) ((((74.932-(2.965)-(50.223)-(46.802)-(segmentsAcked)-(tcb->m_segmentSize)-(97.876)-(50.469)))+((67.585*(86.689)*(64.08)*(tcb->m_segmentSize)*(76.958)*(0.451)))+((90.646*(14.518)))+(58.161)+(94.266)+(75.531))/((67.253)));

} else {
	tcb->m_segmentSize = (int) (99.744-(tcb->m_cWnd)-(56.511)-(tcb->m_cWnd)-(2.988)-(53.155)-(3.937)-(21.193));
	tcb->m_ssThresh = (int) (16.12-(50.995)-(14.484)-(87.039)-(29.201)-(44.283)-(5.382)-(87.06)-(segmentsAcked));
	tcb->m_segmentSize = (int) (84.903*(45.592)*(19.333)*(85.479)*(61.144)*(33.146)*(tcb->m_ssThresh)*(63.58));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (21.417+(segmentsAcked)+(41.234)+(segmentsAcked)+(10.045)+(98.287)+(58.031));
tcb->m_ssThresh = (int) (89.294/18.675);
