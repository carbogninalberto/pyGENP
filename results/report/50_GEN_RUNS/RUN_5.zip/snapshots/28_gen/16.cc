tcb->m_cWnd = (int) (43.413/52.766);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (30.065*(50.711)*(13.467)*(40.096)*(71.73)*(14.892)*(34.196)*(18.389)*(segmentsAcked));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (75.136+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(40.429));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (35.983+(91.843)+(74.07));
	tcb->m_segmentSize = (int) (79.884-(tcb->m_cWnd));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (75.184+(51.324));
	CongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_cWnd = (int) (50.218-(91.912)-(5.693)-(76.437)-(69.687)-(19.711)-(37.051)-(segmentsAcked)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (43.558-(20.146));
	segmentsAcked = (int) (segmentsAcked*(2.001)*(38.861)*(75.068)*(11.245)*(93.605)*(tcb->m_cWnd));

}
