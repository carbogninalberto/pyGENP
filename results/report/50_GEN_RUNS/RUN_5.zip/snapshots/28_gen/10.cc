TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (29.548+(17.838)+(59.171)+(69.701)+(33.347)+(tcb->m_cWnd)+(tcb->m_segmentSize));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (68.834*(64.833)*(tcb->m_ssThresh)*(32.769)*(64.134));
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(90.708)+(64.397)+(0.1))/((6.824)));

} else {
	tcb->m_segmentSize = (int) (66.438*(73.732)*(tcb->m_segmentSize)*(1.645)*(40.851)*(43.352)*(71.318));
	tcb->m_segmentSize = (int) (36.861*(26.834)*(tcb->m_segmentSize)*(47.757)*(90.5)*(segmentsAcked)*(72.666));
	tcb->m_segmentSize = (int) (80.869*(95.286)*(74.963)*(64.878));

}
segmentsAcked = (int) (21.362+(tcb->m_ssThresh)+(79.771));
