segmentsAcked = (int) (tcb->m_ssThresh+(82.741)+(2.334));
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (5.124+(90.512)+(27.79)+(85.899)+(6.987)+(61.115));

} else {
	tcb->m_segmentSize = (int) (35.512*(70.12)*(18.498)*(74.963)*(14.553)*(38.883)*(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(73.544)+(0.1))/((99.016)+(87.43)+(0.1)+(0.1)+(0.1)));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(87.448));

}
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(1.144));
tcb->m_segmentSize = (int) (35.458+(77.456)+(84.06)+(15.568)+(tcb->m_segmentSize)+(65.151)+(6.241)+(39.162)+(segmentsAcked));
segmentsAcked = (int) (91.02*(68.262)*(80.543)*(segmentsAcked));
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
