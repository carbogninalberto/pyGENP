if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (34.681/49.601);

} else {
	tcb->m_ssThresh = (int) (41.741*(tcb->m_segmentSize)*(52.66)*(16.836));

}
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (85.965+(48.396)+(13.575)+(26.133));

} else {
	tcb->m_ssThresh = (int) ((48.012+(segmentsAcked)+(64.128)+(9.723)+(55.246)+(95.198)+(tcb->m_ssThresh))/0.1);
	tcb->m_segmentSize = (int) (65.522-(51.797)-(27.685)-(tcb->m_ssThresh)-(7.558)-(34.361)-(75.077)-(93.511));
	tcb->m_segmentSize = (int) (90.794-(25.915)-(35.447)-(tcb->m_cWnd)-(97.14)-(40.259)-(89.115)-(1.976)-(tcb->m_segmentSize));

}
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_cWnd*(tcb->m_segmentSize)*(58.702)*(segmentsAcked)*(21.803)*(segmentsAcked)*(17.44)*(74.558));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(48.885)+(tcb->m_segmentSize)+(27.508)+(17.919)+(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (57.61*(94.628)*(5.98)*(60.807)*(87.537)*(6.694)*(97.371)*(63.612)*(13.967));
tcb->m_segmentSize = (int) (43.777-(89.526)-(tcb->m_segmentSize)-(62.226)-(26.733));
