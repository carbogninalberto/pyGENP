tcb->m_cWnd = (int) (75.961-(35.443)-(8.073)-(tcb->m_cWnd)-(7.936)-(7.18)-(27.232)-(segmentsAcked));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (6.683*(67.201)*(tcb->m_segmentSize)*(3.835)*(16.671));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (segmentsAcked+(51.713)+(88.417)+(21.901)+(58.508)+(tcb->m_cWnd)+(11.77)+(tcb->m_ssThresh));
