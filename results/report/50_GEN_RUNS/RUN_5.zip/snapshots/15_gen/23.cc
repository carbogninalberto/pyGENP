ReduceCwnd (tcb);
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_ssThresh = (int) (segmentsAcked-(93.266)-(97.749)-(44.4));
	CongestionAvoidance (tcb, segmentsAcked);
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (0.1/(33.616-(71.799)-(53.7)));

}
tcb->m_segmentSize = (int) (20.858+(9.501));
segmentsAcked = (int) (99.307/50.208);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (85.306+(43.744)+(8.46));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (95.696+(3.093)+(tcb->m_ssThresh));
