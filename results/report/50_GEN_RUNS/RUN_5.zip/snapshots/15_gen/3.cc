if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_cWnd = (int) ((((74.042-(1.657)-(80.439)-(20.629)-(81.146)))+(98.369)+(0.1)+(0.1)+(1.943)+(90.579))/((0.1)));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(tcb->m_segmentSize)*(tcb->m_cWnd)*(tcb->m_cWnd)*(34.624)*(tcb->m_cWnd)*(13.462));

}
if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) (90.967*(49.607)*(-64.616)*(43.524)*(38.778));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (96.97*(70.072)*(89.311)*(35.833)*(29.532)*(22.111)*(40.288)*(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (-19.738-(71.995)-(31.717));
	CongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) (90.967*(49.607)*(85.948)*(43.524)*(38.778));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	segmentsAcked = (int) (96.97*(70.072)*(89.311)*(35.833)*(29.532)*(22.111)*(40.288)*(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (37.356-(71.995)-(31.717));
	CongestionAvoidance (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
