ReduceCwnd (tcb);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float cwTPvIcRgkDSXrQe = (float) (0.1/4.914);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (50.493+(81.916));
