segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-87.272*(58.301)*(63.391)*(5.296));
tcb->m_segmentSize = (int) (-90.038-(45.339)-(-61.826)-(-37.737)-(84.387)-(-24.701)-(-84.848)-(-48.74));
tcb->m_segmentSize = (int) (-11.803-(26.398)-(16.347)-(74.259)-(56.346)-(-77.54)-(-48.768)-(-4.512));
tcb->m_segmentSize = (int) (-88.762*(-36.619)*(-31.132)*(71.301)*(-78.76));
tcb->m_segmentSize = (int) (-93.766*(13.767)*(-18.26)*(97.751)*(-41.771));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
