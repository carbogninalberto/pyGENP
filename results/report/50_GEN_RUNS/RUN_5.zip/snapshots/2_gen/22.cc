segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-30.26*(-27.548)*(-13.914)*(22.747));
tcb->m_segmentSize = (int) (15.045*(16.393)*(-34.393)*(-4.289)*(71.838));
tcb->m_segmentSize = (int) (39.664-(96.596)-(39.623)-(-43.161)-(67.397)-(-75.336)-(-37.772)-(-1.027));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-77.331*(12.209)*(-62.472)*(96.701)*(-71.008));
segmentsAcked = SlowStart (tcb, segmentsAcked);
