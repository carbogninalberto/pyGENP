segmentsAcked = (int) (98.31+(-46.293)+(84.062)+(-14.645)+(-40.501));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-55.876+(53.163)+(-65.302)+(35.793)+(-13.991));
segmentsAcked = SlowStart (tcb, segmentsAcked);
