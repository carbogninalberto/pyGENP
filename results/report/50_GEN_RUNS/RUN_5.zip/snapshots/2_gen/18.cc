int WQauZRmhSEGvTFIw = (int) (12.88/54.499);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-99.736+(-66.198)+(-56.923));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-30.422+(34.801)+(-26.459)+(-2.493)+(-60.64));
tcb->m_cWnd = (int) (31.751+(15.583)+(3.657));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-8.029+(45.055)+(-91.974)+(-5.167)+(68.291));
