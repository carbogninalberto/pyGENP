float SZCZxuFUZNhLUjCE = (float) (((-34.033)+(74.035)+((89.389*(32.647)*(41.601)*(22.751)*(98.047)*(45.032)*(80.467)*(-67.188)*(24.412)))+(-3.093)+((-80.672+(40.245)+(27.429)+(-43.837)+(-82.973)+(62.16)))+(-83.231))/((13.116)+(-97.647)+(79.516)));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (68.077+(3.028)+(11.142)+(-38.9)+(-1.593));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
