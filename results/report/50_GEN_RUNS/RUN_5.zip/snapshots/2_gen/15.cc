float URAFFDStCDtaXKrO = (float) (-56.829/-77.292);
float lGHcjhUxtRtoQaCN = (float) (-34.322+(-35.658)+(-1.794)+(45.577)+(-43.968)+(40.722));
if (segmentsAcked > tcb->m_segmentSize) {
	segmentsAcked = (int) (90.429-(tcb->m_segmentSize)-(20.016)-(72.645)-(47.318)-(29.47)-(44.887));

} else {
	segmentsAcked = (int) (((62.062)+(0.1)+(0.1)+(0.1)+(0.1)+(75.359))/((52.01)));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (7.372+(28.373)+(segmentsAcked)+(-11.535)+(70.604));
	tcb->m_cWnd = (int) (54.703+(segmentsAcked)+(50.09)+(99.433)+(tcb->m_cWnd)+(88.041)+(12.319));

} else {
	tcb->m_segmentSize = (int) (87.144*(84.27)*(74.653)*(52.067)*(27.582)*(67.738)*(4.565)*(97.652)*(77.49));
	segmentsAcked = (int) (39.073+(80.586)+(segmentsAcked)+(26.025)+(-45.523)+(37.755)+(99.934)+(33.533));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (52.159*(36.838)*(4.352)*(55.199));
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked > tcb->m_segmentSize) {
	segmentsAcked = (int) (90.429-(tcb->m_segmentSize)-(20.016)-(72.645)-(47.318)-(29.47)-(44.887));

} else {
	segmentsAcked = (int) (((62.062)+(0.1)+(0.1)+(0.1)+(0.1)+(75.359))/((52.01)));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (7.372+(28.373)+(segmentsAcked)+(17.152)+(70.604));
	tcb->m_cWnd = (int) (54.703+(segmentsAcked)+(50.09)+(99.433)+(tcb->m_cWnd)+(88.041)+(12.319));

} else {
	tcb->m_segmentSize = (int) (87.144*(84.27)*(74.653)*(52.067)*(27.582)*(67.738)*(4.565)*(97.652)*(77.49));
	segmentsAcked = (int) (39.073+(80.586)+(segmentsAcked)+(26.025)+(-50.289)+(37.755)+(99.934)+(33.533));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-55.119*(51.217)*(-15.351)*(-15.853));
CongestionAvoidance (tcb, segmentsAcked);
