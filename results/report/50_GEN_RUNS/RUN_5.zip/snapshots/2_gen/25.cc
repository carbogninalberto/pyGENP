int WQauZRmhSEGvTFIw = (int) (72.6/-38.325);
tcb->m_cWnd = (int) (-71.044+(97.759)+(94.839));
tcb->m_cWnd = (int) (-83.081+(-99.484)+(87.993));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-4.202+(-49.052)+(19.845)+(62.953)+(-95.157));
tcb->m_cWnd = (int) (93.473+(-32.374)+(43.859)+(-23.061)+(-5.987));
