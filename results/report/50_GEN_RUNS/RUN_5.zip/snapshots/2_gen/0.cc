segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-35.383*(-89.225)*(3.15)*(30.528));
tcb->m_segmentSize = (int) (51.126-(-77.465)-(33.527)-(-63.518)-(84.523)-(79.997)-(-26.634)-(-0.39));
tcb->m_segmentSize = (int) (38.797*(42.212)*(31.254)*(-70.558)*(13.622));
segmentsAcked = SlowStart (tcb, segmentsAcked);
