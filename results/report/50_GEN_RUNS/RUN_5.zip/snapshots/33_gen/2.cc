segmentsAcked = (int) (15.248-(37.676)-(37.247)-(-77.594)-(18.849));
tcb->m_cWnd = (int) (40.92+(92.126)+(-75.786)+(-28.229));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (21.916*(24.158)*(-17.368)*(tcb->m_cWnd)*(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (5.755+(27.982)+(38.943)+(59.271)+(66.639));

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(tcb->m_segmentSize)-(86.954));
	tcb->m_segmentSize = (int) (((0.1)+(92.349)+(0.1)+(44.663)+((34.367-(52.522)-(58.752)-(53.017)))+(78.403))/((0.1)+(95.307)+(85.74)));

}
segmentsAcked = (int) (-20.286*(84.64));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (21.916*(24.158)*(87.041)*(tcb->m_cWnd)*(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (5.755+(27.982)+(38.943)+(59.271)+(66.639));

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(tcb->m_segmentSize)-(86.954));
	tcb->m_segmentSize = (int) (((0.1)+(92.349)+(0.1)+(44.663)+((34.367-(52.522)-(58.752)-(53.017)))+(78.403))/((0.1)+(95.307)+(85.74)));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (-98.83*(-77.009));
tcb->m_segmentSize = (int) (-79.005-(97.677)-(72.293)-(-51.806)-(45.125));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (25.919-(-78.008)-(-57.965)-(71.7)-(60.392));
