float VpjpfvzZaqpXgxOb = (float) (((63.632)+((81.414+(52.022)+(45.253)))+(0.1)+(0.1)+(0.1))/((49.839)));
int yPfKHdSwDBULBNaw = (int) (80.22-(tcb->m_cWnd)-(71.298)-(70.774)-(31.667)-(17.103)-(79.569));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (74.928+(96.739));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (35.99-(83.768)-(54.896)-(47.396)-(80.974)-(49.318)-(yPfKHdSwDBULBNaw)-(73.981)-(30.454));
	tcb->m_ssThresh = (int) (12.336-(96.464)-(87.437)-(tcb->m_ssThresh)-(43.087));

} else {
	tcb->m_cWnd = (int) (12.756+(VpjpfvzZaqpXgxOb)+(1.345)+(86.382));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(tcb->m_ssThresh)-(9.082)-(8.352)-(24.408)-(tcb->m_ssThresh)-(79.628));

}
VpjpfvzZaqpXgxOb = (float) (0.1/0.1);
yPfKHdSwDBULBNaw = (int) (3.826+(71.131)+(tcb->m_ssThresh)+(68.498)+(55.805)+(1.187)+(79.058)+(78.549)+(76.299));
if (VpjpfvzZaqpXgxOb <= yPfKHdSwDBULBNaw) {
	VpjpfvzZaqpXgxOb = (float) (tcb->m_cWnd+(62.323)+(77.412));

} else {
	VpjpfvzZaqpXgxOb = (float) (32.21+(71.619)+(38.675)+(42.059)+(25.098)+(VpjpfvzZaqpXgxOb)+(59.568)+(88.974));
	tcb->m_cWnd = (int) (34.516-(tcb->m_cWnd)-(94.534)-(53.826));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
