segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_cWnd = (int) (78.952+(79.461)+(67.212));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (47.713-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (87.995+(tcb->m_ssThresh)+(43.527)+(52.719)+(96.583)+(tcb->m_cWnd)+(segmentsAcked)+(tcb->m_cWnd)+(tcb->m_ssThresh));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
tcb->m_segmentSize = (int) (tcb->m_cWnd-(14.286)-(segmentsAcked)-(86.79));
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (43.062-(segmentsAcked)-(77.92)-(95.102)-(98.762));
	tcb->m_cWnd = (int) (73.277-(85.441)-(93.175)-(36.024)-(59.668)-(84.681)-(70.949)-(26.534)-(56.045));

} else {
	tcb->m_ssThresh = (int) (82.779*(60.632)*(24.741));

}
float CTJaPaUEXnxARSEQ = (float) (66.867*(36.407)*(65.156)*(36.588)*(tcb->m_cWnd)*(13.637)*(44.852)*(51.703)*(51.061));
tcb->m_cWnd = (int) (55.475*(tcb->m_ssThresh)*(43.427)*(tcb->m_segmentSize)*(segmentsAcked)*(2.899)*(64.003)*(21.362));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
