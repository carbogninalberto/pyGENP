tcb->m_cWnd = (int) (18.881-(-56.966)-(5.018)-(-34.816)-(7.549)-(-86.907)-(93.161)-(7.794)-(54.845));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
