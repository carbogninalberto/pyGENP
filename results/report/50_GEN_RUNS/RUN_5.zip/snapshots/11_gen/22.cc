segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (76.505*(47.75)*(tcb->m_cWnd)*(1.649)*(14.614)*(71.792)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(tcb->m_cWnd));
tcb->m_segmentSize = (int) (41.031-(61.914)-(60.328)-(tcb->m_cWnd)-(35.156)-(21.481));
tcb->m_ssThresh = (int) (56.105-(70.97)-(34.299)-(10.026)-(70.54)-(46.493));
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (52.335*(21.621)*(6.028)*(79.837)*(54.789)*(1.761)*(83.539)*(75.834)*(91.454));

} else {
	tcb->m_segmentSize = (int) (60.722*(39.423)*(36.501)*(57.536)*(52.987)*(7.671)*(55.803)*(82.744)*(86.402));
	tcb->m_ssThresh = (int) (8.068*(70.279)*(98.327)*(52.865)*(36.428)*(99.404));

}
tcb->m_ssThresh = (int) (0.1/0.1);
