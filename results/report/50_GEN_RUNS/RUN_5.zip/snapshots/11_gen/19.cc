CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (15.316-(0.652)-(segmentsAcked)-(7.826));

} else {
	tcb->m_ssThresh = (int) (76.085-(segmentsAcked)-(8.122)-(31.269));
	segmentsAcked = (int) (42.276-(90.267)-(41.758)-(78.032)-(12.84)-(tcb->m_cWnd)-(93.259)-(36.691));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_segmentSize = (int) (20.639-(29.925)-(segmentsAcked)-(67.711)-(segmentsAcked)-(29.323)-(tcb->m_ssThresh)-(16.334)-(47.026));
	segmentsAcked = (int) (62.594*(4.562)*(17.712)*(65.065)*(38.442)*(tcb->m_cWnd)*(44.43)*(83.711));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(1.049)*(87.932)*(tcb->m_segmentSize));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (2.544*(11.103)*(22.468)*(41.86)*(59.618)*(92.148)*(tcb->m_ssThresh));
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_cWnd = (int) (50.742-(37.437)-(98.614)-(0.591)-(12.368));
	segmentsAcked = (int) (tcb->m_segmentSize+(3.365)+(87.547));

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(tcb->m_ssThresh)-(77.141)-(57.501)-(67.922)-(36.187)-(62.961)-(4.878)-(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (26.814+(8.523)+(11.32));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
