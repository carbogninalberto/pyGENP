segmentsAcked = (int) (99.32+(72.857)+(-33.992)+(-96.445)+(-24.594));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-35.007+(-12.106)+(-99.273)+(-21.233)+(71.987));
segmentsAcked = (int) (38.76+(92.32)+(-16.458)+(-5.615)+(1.147));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
