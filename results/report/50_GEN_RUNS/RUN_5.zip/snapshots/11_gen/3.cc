segmentsAcked = (int) (66.459+(50.946)+(-30.531)+(-44.39)+(67.653));
segmentsAcked = (int) (76.836+(-50.77)+(-52.907)+(-12.491)+(-3.567));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (38.227+(36.72)+(60.289)+(-53.177)+(98.468));
segmentsAcked = SlowStart (tcb, segmentsAcked);
