segmentsAcked = (int) (87.706+(-77.129)+(10.35)+(15.309)+(35.579));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-38.822+(71.402)+(-8.46)+(28.053)+(-22.847));
segmentsAcked = SlowStart (tcb, segmentsAcked);
