segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (58.115*(33.458)*(-12.599)*(20.521));
tcb->m_segmentSize = (int) (-66.184*(28.833)*(40.349)*(67.631)*(10.697));
tcb->m_segmentSize = (int) (69.854-(94.479)-(-1.038)-(-13.255)-(-9.655)-(-65.781)-(-36.047)-(37.587));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (73.521*(-17.104)*(74.379)*(-54.977)*(85.489));
segmentsAcked = SlowStart (tcb, segmentsAcked);
