if (tcb->m_ssThresh < segmentsAcked) {
	segmentsAcked = (int) (7.672-(55.829)-(66.361)-(46.3)-(tcb->m_cWnd)-(52.984));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (0.1/8.764);

} else {
	segmentsAcked = (int) (tcb->m_cWnd+(71.268)+(89.673)+(33.451)+(tcb->m_ssThresh)+(segmentsAcked)+(4.542));

}
segmentsAcked = (int) ((54.389-(59.312)-(21.735)-(72.688))/51.222);
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_cWnd = (int) ((41.733-(18.086))/82.94);

} else {
	tcb->m_cWnd = (int) (1.403-(29.463)-(63.8));
	tcb->m_ssThresh = (int) ((tcb->m_ssThresh-(31.572)-(19.384)-(80.32)-(25.858)-(94.709)-(91.607)-(47.14))/0.1);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
