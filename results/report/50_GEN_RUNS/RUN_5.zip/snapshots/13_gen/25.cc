float wlPrhXjEHjzbWbdI = (float) (tcb->m_cWnd-(82.457)-(2.044)-(segmentsAcked)-(54.736)-(92.569)-(tcb->m_cWnd)-(62.202)-(76.351));
tcb->m_ssThresh = (int) (66.092*(73.504)*(52.075)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(89.269)*(23.276)*(84.365));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (85.54-(14.906)-(15.278)-(95.567)-(41.312)-(82.659));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (93.622*(98.799)*(59.363)*(tcb->m_cWnd)*(wlPrhXjEHjzbWbdI)*(79.923));
	CongestionAvoidance (tcb, segmentsAcked);
	wlPrhXjEHjzbWbdI = (float) (45.46*(58.382)*(68.519)*(25.235)*(2.973)*(tcb->m_segmentSize));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (segmentsAcked != tcb->m_segmentSize) {
	wlPrhXjEHjzbWbdI = (float) (((0.1)+(0.1)+(0.1)+(0.1)+(43.23))/((11.98)+(0.1)+(0.1)));
	tcb->m_segmentSize = (int) (15.792+(15.161)+(1.591)+(51.189)+(96.482)+(4.657)+(88.502));

} else {
	wlPrhXjEHjzbWbdI = (float) (39.94*(22.507));
	wlPrhXjEHjzbWbdI = (float) (0.1/4.122);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
