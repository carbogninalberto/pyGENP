tcb->m_segmentSize = (int) ((21.177-(97.459)-(66.557)-(68.269)-(segmentsAcked))/37.918);
CongestionAvoidance (tcb, segmentsAcked);
int PduQVzixdcpGDdIO = (int) (25.185-(29.2)-(tcb->m_ssThresh)-(16.333)-(73.412)-(4.348)-(81.568));
float UbhhyaMVccfsBEXJ = (float) (62.385-(26.435)-(92.438));
segmentsAcked = (int) ((PduQVzixdcpGDdIO+(90.262)+(88.624))/0.1);
