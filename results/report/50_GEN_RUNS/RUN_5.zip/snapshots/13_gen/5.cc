int zgrurHSLkNiswHWZ = (int) 96.791;
tcb->m_segmentSize = (int) (43.524*(51.687)*(-42.935)*(69.583)*(-13.405)*(26.579));
