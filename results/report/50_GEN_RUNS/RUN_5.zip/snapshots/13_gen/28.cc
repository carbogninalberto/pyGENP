if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) (44.944*(45.832)*(74.033));
	tcb->m_segmentSize = (int) ((((28.959*(95.124)*(89.3)*(28.35)*(62.848)*(64.217)*(segmentsAcked)*(45.852)*(64.894)))+(57.628)+(0.1)+(0.1)+(78.222))/((0.1)+(0.1)+(0.1)+(31.46)));

} else {
	segmentsAcked = (int) (44.142*(66.868)*(24.935)*(35.745)*(28.919)*(84.46));

}
tcb->m_cWnd = (int) (81.523*(65.382));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (62.504*(8.789)*(95.498)*(81.774));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
