tcb->m_ssThresh = (int) (97.18-(segmentsAcked));
tcb->m_segmentSize = (int) (63.561*(65.175)*(77.639)*(35.888));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (20.636*(tcb->m_ssThresh)*(2.135)*(33.308)*(67.623)*(18.167)*(50.518)*(49.587)*(1.535));
ReduceCwnd (tcb);
