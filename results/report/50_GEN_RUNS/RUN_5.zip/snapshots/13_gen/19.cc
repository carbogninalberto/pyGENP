if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (24.234+(40.159));

} else {
	tcb->m_cWnd = (int) (67.31-(49.334)-(tcb->m_segmentSize)-(46.676)-(31.532)-(3.626)-(26.64)-(18.118)-(58.045));
	segmentsAcked = (int) (59.761+(82.428)+(16.871)+(91.651)+(tcb->m_segmentSize)+(43.963));

}
tcb->m_cWnd = (int) (33.425*(32.211)*(79.553)*(32.657)*(16.121)*(8.688)*(72.449));
float cTEzXGXRdXGtaYgR = (float) (35.654*(24.307)*(76.763)*(tcb->m_cWnd)*(81.395)*(tcb->m_segmentSize));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
