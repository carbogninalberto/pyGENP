tcb->m_cWnd = (int) (46.503-(27.184)-(33.474)-(-97.563)-(-9.442)-(-35.682)-(-15.855)-(-40.544)-(37.247));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
