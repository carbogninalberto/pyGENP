int yzPYONRvQnydNfFK = (int) (45.456-(89.943));
if (tcb->m_ssThresh != yzPYONRvQnydNfFK) {
	yzPYONRvQnydNfFK = (int) (65.807+(74.307)+(7.342)+(tcb->m_ssThresh)+(33.34)+(tcb->m_ssThresh)+(10.662)+(94.412));

} else {
	yzPYONRvQnydNfFK = (int) (75.659*(23.402)*(62.486)*(1.663)*(tcb->m_cWnd)*(4.216)*(11.092));
	tcb->m_cWnd = (int) (segmentsAcked+(82.917)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(42.787));
	yzPYONRvQnydNfFK = (int) (8.814+(30.745)+(82.942)+(tcb->m_segmentSize)+(27.139)+(tcb->m_ssThresh)+(50.299));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (segmentsAcked+(92.926)+(46.083)+(tcb->m_ssThresh)+(97.445)+(25.713));
ReduceCwnd (tcb);
if (tcb->m_segmentSize == yzPYONRvQnydNfFK) {
	tcb->m_segmentSize = (int) (yzPYONRvQnydNfFK+(44.831)+(37.252)+(86.099)+(80.953)+(tcb->m_ssThresh));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (19.337/57.804);

}
float WPHsArMwponOtTZY = (float) (20.328*(2.059)*(21.543)*(97.225)*(12.94));
WPHsArMwponOtTZY = (float) ((((68.678*(25.827)*(50.892)*(15.495)))+(0.1)+((12.959+(87.283)+(41.132)+(21.159)+(57.127)+(8.952)+(55.422)+(29.51)))+(0.1)+(87.134)+(0.1))/((0.1)));
if (WPHsArMwponOtTZY > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((16.654*(80.15)*(23.646)*(17.191)*(87.95))/56.149);
	WPHsArMwponOtTZY = (float) (22.801+(19.234)+(tcb->m_cWnd)+(WPHsArMwponOtTZY)+(75.625)+(24.734));

} else {
	tcb->m_ssThresh = (int) (23.702+(yzPYONRvQnydNfFK)+(WPHsArMwponOtTZY)+(yzPYONRvQnydNfFK));

}
