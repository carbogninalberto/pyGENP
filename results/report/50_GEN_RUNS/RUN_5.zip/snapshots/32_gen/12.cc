if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (26.476*(68.401)*(18.038)*(9.031)*(74.513)*(76.811)*(52.753));
	tcb->m_ssThresh = (int) ((((tcb->m_ssThresh-(27.349)))+((45.955-(tcb->m_ssThresh)-(39.046)-(28.698)))+((28.485*(tcb->m_cWnd)*(43.787)*(61.17)*(31.264)*(12.385)))+(53.906))/((18.425)+(0.1)));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_segmentSize = (int) (14.932+(41.973)+(10.325)+(16.176)+(84.264)+(7.659)+(63.216));
	segmentsAcked = (int) (segmentsAcked-(37.1)-(63.906)-(8.547)-(21.467));
	tcb->m_segmentSize = (int) (((0.1)+((tcb->m_segmentSize+(tcb->m_cWnd)))+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(48.438)+(88.229)));

}
int gnqePpbMJVRpOrjf = (int) (segmentsAcked+(6.359)+(6.377));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (gnqePpbMJVRpOrjf+(gnqePpbMJVRpOrjf)+(48.58)+(92.214)+(31.483));
	tcb->m_segmentSize = (int) (61.082-(57.594)-(tcb->m_cWnd)-(93.39)-(4.406));
	gnqePpbMJVRpOrjf = (int) (18.282*(85.825)*(79.162)*(54.321)*(tcb->m_segmentSize)*(64.804)*(tcb->m_ssThresh)*(segmentsAcked)*(58.099));

} else {
	tcb->m_ssThresh = (int) (((0.1)+((39.589+(tcb->m_ssThresh)+(24.76)+(67.467)+(17.593)+(22.337)))+(35.301)+(0.1))/((61.301)+(95.024)+(0.1)+(0.1)));

}
tcb->m_segmentSize = (int) (tcb->m_cWnd-(gnqePpbMJVRpOrjf)-(63.571)-(71.407)-(88.835)-(tcb->m_segmentSize)-(2.796)-(16.106));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (95.133+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(41.377)+(tcb->m_segmentSize)+(gnqePpbMJVRpOrjf)+(46.363)+(56.527));

} else {
	tcb->m_ssThresh = (int) (28.412*(96.393)*(tcb->m_ssThresh)*(segmentsAcked)*(85.384)*(70.745));
	gnqePpbMJVRpOrjf = (int) (tcb->m_cWnd*(40.348));

}
gnqePpbMJVRpOrjf = (int) (tcb->m_cWnd-(93.371)-(57.818)-(46.342));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
