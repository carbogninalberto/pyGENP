if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (94.103/41.115);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

} else {
	tcb->m_cWnd = (int) (30.703-(63.825));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-11.849+(-92.244));
