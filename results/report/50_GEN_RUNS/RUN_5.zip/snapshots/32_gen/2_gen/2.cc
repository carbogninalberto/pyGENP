CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-43.072+(-94.054)+(-74.321)+(-69.043)+(89.75)+(-52.499)+(50.472));
tcb->m_cWnd = (int) (33.956+(-96.263)+(17.243)+(-39.963)+(60.181)+(-75.403)+(49.677)+(92.489)+(56.513));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
