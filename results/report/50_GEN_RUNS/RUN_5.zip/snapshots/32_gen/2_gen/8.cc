tcb->m_segmentSize = (int) (66.253+(0.892)+(47.753)+(-22.523)+(-76.82)+(-44.414)+(-50.539)+(2.537));
CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
