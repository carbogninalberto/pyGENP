int EgJuHfuSqYCJXkHI = (int) 25.26;
