int jfZSAsgZBhxsQYns = (int) (-27.163*(-5.843)*(-84.376)*(42.266)*(7.709)*(65.139));
int iXTkTOYrfDOiVEUf = (int) (-54.142-(-16.949)-(73.133)-(-2.972)-(8.389)-(76.331)-(22.927)-(-79.856)-(-10.508));
int ryDERCXPSWMBEspN = (int) (((-44.267)+(-55.17)+(10.399)+(41.25))/((47.38)+(18.876)+(56.285)));
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (ryDERCXPSWMBEspN-(42.225)-(58.352)-(85.972)-(5.182)-(46.424));
	tcb->m_segmentSize = (int) (8.268-(segmentsAcked));
	segmentsAcked = (int) (82.052-(85.989)-(83.58));

} else {
	segmentsAcked = (int) (64.173+(25.752)+(51.109));
	ryDERCXPSWMBEspN = (int) (92.012+(39.797)+(77.676));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (-32.347*(-79.923)*(30.787)*(7.871)*(35.869)*(-25.839));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (ryDERCXPSWMBEspN-(42.225)-(58.352)-(85.972)-(5.182)-(46.424));
	tcb->m_segmentSize = (int) (8.268-(segmentsAcked));
	segmentsAcked = (int) (82.052-(85.989)-(83.58));

} else {
	segmentsAcked = (int) (64.173+(25.752)+(51.109));
	ryDERCXPSWMBEspN = (int) (92.012+(39.797)+(77.676));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (-98.507*(80.122)*(-80.388)*(-90.639)*(-68.271)*(-14.519));
segmentsAcked = SlowStart (tcb, segmentsAcked);
