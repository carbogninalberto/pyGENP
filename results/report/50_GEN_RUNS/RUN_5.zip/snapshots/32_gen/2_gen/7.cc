CongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-89.228+(-3.38)+(46.204)+(24.37)+(-14.296)+(-69.623)+(-70.19)+(10.617));
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-43.802+(92.42)+(56.093)+(-10.342)+(7.852)+(-43.766)+(60.371)+(-46.952));
