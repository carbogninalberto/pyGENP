tcb->m_cWnd = (int) (38.406/(29.974+(98.632)+(tcb->m_cWnd)));
float kmUuljQrPewBgAhF = (float) (94.369-(98.001)-(63.558)-(62.743)-(4.678)-(84.785));
tcb->m_segmentSize = (int) (28.318*(39.446)*(61.421)*(tcb->m_cWnd));
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_ssThresh = (int) (5.901/47.877);

} else {
	tcb->m_ssThresh = (int) (33.641-(67.407)-(1.442));

}
if (kmUuljQrPewBgAhF > segmentsAcked) {
	tcb->m_cWnd = (int) (3.005+(segmentsAcked)+(63.032));
	tcb->m_ssThresh = (int) (0.1/(77.2+(34.54)+(segmentsAcked)+(40.114)));

} else {
	tcb->m_cWnd = (int) (9.268-(95.406)-(87.593)-(60.78));

}
kmUuljQrPewBgAhF = (float) (61.718+(55.355)+(18.158)+(4.973)+(13.818)+(85.769)+(segmentsAcked));
