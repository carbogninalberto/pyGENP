ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_segmentSize+(59.005));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (91.632-(57.91)-(76.914)-(49.181)-(94.595)-(74.661)-(segmentsAcked)-(75.192));
	tcb->m_ssThresh = (int) (74.013-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(75.165));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_cWnd = (int) ((12.733+(86.079))/50.426);
	tcb->m_segmentSize = (int) (10.782*(62.698)*(77.776)*(81.086)*(64.908)*(62.062)*(23.027));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(31.736)-(72.613)-(43.139)-(segmentsAcked)-(14.891)-(45.228)-(53.089));

}
segmentsAcked = (int) (75.231-(28.435)-(33.78)-(51.464)-(78.215));
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	segmentsAcked = (int) (67.228-(41.532)-(segmentsAcked)-(7.636));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	segmentsAcked = (int) (69.515+(segmentsAcked)+(21.171)+(segmentsAcked)+(46.672)+(75.147)+(77.367));

}
