if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (7.713*(9.643)*(segmentsAcked)*(14.072)*(28.122)*(77.452)*(segmentsAcked)*(43.521)*(76.398));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(77.451)-(75.104)-(76.738)-(29.348)-(80.286)-(38.36));
	tcb->m_ssThresh = (int) (12.587*(34.394)*(7.587)*(segmentsAcked));

}
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (46.135/0.1);
	tcb->m_cWnd = (int) (0.1/45.082);

} else {
	segmentsAcked = (int) (78.523*(1.54)*(30.586)*(48.634));
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(65.954)+(tcb->m_cWnd)+(65.036)+(24.681)+(43.385));

}
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (99.638+(tcb->m_segmentSize)+(92.51)+(58.906)+(52.686)+(12.99)+(67.395));
	tcb->m_cWnd = (int) (95.719-(55.643));

} else {
	tcb->m_segmentSize = (int) (65.856*(73.691)*(tcb->m_cWnd)*(59.105)*(52.529)*(65.877));
	segmentsAcked = SlowStart (tcb, segmentsAcked);
	CongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (segmentsAcked+(9.859)+(tcb->m_ssThresh)+(96.316)+(30.644)+(45.488)+(segmentsAcked));
ReduceCwnd (tcb);
