segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(58.607));
tcb->m_cWnd = (int) ((55.584+(tcb->m_cWnd)+(73.548)+(34.853))/0.1);
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((0.1)+(54.587)+(39.118)+(82.848))/((0.1)+(49.183)+(4.795)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (72.77/0.1);
	tcb->m_cWnd = (int) (51.486+(42.431)+(20.332)+(52.789)+(tcb->m_segmentSize)+(40.009));

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((segmentsAcked+(91.787)+(91.838)+(tcb->m_ssThresh)+(tcb->m_cWnd))/0.1);

} else {
	tcb->m_segmentSize = (int) (5.942+(19.759)+(46.185)+(23.057)+(54.102)+(78.308)+(41.238));

}
