int HRecHBjuMjEedLSo = (int) (((75.582)+(99.696)+(-81.573)+((-36.192+(-7.688)))+(-1.469))/((37.826)+(-37.953)));
HRecHBjuMjEedLSo = (int) (18.0+(-46.633)+(26.059)+(75.877)+(57.238)+(70.266)+(27.315));
segmentsAcked = (int) (-62.239+(-70.767)+(-38.67));
ReduceCwnd (tcb);
segmentsAcked = (int) (-52.247/-51.96);
segmentsAcked = (int) (-53.744+(-23.812)+(-24.283));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
