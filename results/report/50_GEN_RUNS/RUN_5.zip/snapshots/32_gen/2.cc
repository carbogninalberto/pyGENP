ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (97.031/-59.315);
segmentsAcked = (int) (40.183-(2.28)-(-79.635)-(49.946)-(39.522));
tcb->m_cWnd = (int) (16.998+(47.698)+(30.854)+(-69.875));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (21.916*(24.158)*(18.3)*(tcb->m_cWnd)*(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (5.755+(27.982)+(38.943)+(59.271)+(66.639));

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(tcb->m_segmentSize)-(86.954));
	tcb->m_segmentSize = (int) (((0.1)+(92.349)+(0.1)+(44.663)+((34.367-(52.522)-(58.752)-(53.017)))+(78.403))/((0.1)+(95.307)+(85.74)));

}
segmentsAcked = (int) (56.999*(-84.806));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (78.869-(27.421)-(-71.953)-(74.581)-(-18.406));
