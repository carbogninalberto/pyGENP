tcb->m_ssThresh = (int) (tcb->m_ssThresh-(60.739)-(30.179)-(33.83)-(segmentsAcked)-(42.549)-(75.277)-(17.955));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (61.57/12.99);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh > tcb->m_cWnd) {
	segmentsAcked = (int) (83.532-(55.321));

} else {
	segmentsAcked = (int) (10.774+(93.119)+(97.855)+(46.713)+(38.116)+(29.467)+(segmentsAcked)+(segmentsAcked)+(tcb->m_ssThresh));

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (35.0*(tcb->m_ssThresh)*(71.217)*(27.972)*(segmentsAcked)*(tcb->m_cWnd));
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (8.239+(48.493)+(35.818)+(43.382)+(10.226));
	tcb->m_ssThresh = (int) (segmentsAcked*(23.071)*(tcb->m_ssThresh)*(26.165)*(72.67)*(7.63)*(63.992));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (29.839/0.1);
	tcb->m_ssThresh = (int) (97.09-(tcb->m_ssThresh)-(28.403)-(6.791)-(segmentsAcked)-(73.784)-(23.648)-(63.43)-(83.542));

}
