int jQJfqCLwIEGWRHgA = (int) (-91.605-(-27.674)-(-57.637)-(55.057));
jQJfqCLwIEGWRHgA = (int) (28.215/86.539);
if (segmentsAcked >= tcb->m_cWnd) {
	jQJfqCLwIEGWRHgA = (int) (40.922-(segmentsAcked)-(segmentsAcked));
	CongestionAvoidance (tcb, segmentsAcked);

} else {
	jQJfqCLwIEGWRHgA = (int) (0.1/0.1);

}
jQJfqCLwIEGWRHgA = (int) (67.949-(76.023)-(36.826)-(17.856)-(81.728));
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	jQJfqCLwIEGWRHgA = (int) (((0.1)+(0.1)+(0.1)+(60.994))/((0.1)+(0.1)+(34.783)+(57.582)));

} else {
	jQJfqCLwIEGWRHgA = (int) (((0.1)+(0.1)+(9.482)+((24.584*(67.459)*(tcb->m_cWnd)*(99.296)*(46.299)*(74.008)))+((44.659+(tcb->m_segmentSize)+(21.102)+(88.177)))+(0.1)+(29.53)+(0.1))/((0.1)));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (jQJfqCLwIEGWRHgA+(33.011)+(51.895)+(60.697)+(5.743)+(20.377)+(68.833)+(44.998));

} else {
	tcb->m_segmentSize = (int) (51.759+(63.405)+(42.272)+(61.104)+(26.506)+(45.211)+(60.908)+(15.217));
	segmentsAcked = (int) (0.1/19.211);

}
