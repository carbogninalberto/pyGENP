float PmzShqaJPGKBZklh = (float) 70.553;
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (PmzShqaJPGKBZklh*(61.262)*(85.155)*(43.449)*(10.977)*(91.068)*(tcb->m_cWnd)*(87.584)*(-73.126));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (segmentsAcked*(70.342)*(segmentsAcked)*(64.524)*(segmentsAcked)*(27.045)*(32.036));

} else {
	segmentsAcked = (int) (1.263*(4.503)*(18.19)*(74.459)*(11.121)*(64.232));
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
segmentsAcked = (int) (47.176*(-31.983)*(-26.957)*(-81.808)*(-66.833)*(0.783)*(-17.598));
if (tcb->m_cWnd <= PmzShqaJPGKBZklh) {
	PmzShqaJPGKBZklh = (float) (14.438+(15.118)+(77.966));
	ReduceCwnd (tcb);

} else {
	PmzShqaJPGKBZklh = (float) (((0.1)+(0.1)+(0.1)+(88.075)+(43.589))/((0.1)+(71.051)));

}
tcb->m_cWnd = (int) (75.431*(45.116)*(-24.686)*(-70.651));
