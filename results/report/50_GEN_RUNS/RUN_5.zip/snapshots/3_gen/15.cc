segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (10.86*(-75.536)*(-74.534)*(-48.918));
tcb->m_segmentSize = (int) (-94.509*(-92.986)*(-76.953)*(72.437)*(27.76));
tcb->m_segmentSize = (int) (-31.637-(-1.433)-(-60.196)-(89.531)-(46.859)-(-52.821)-(6.746)-(-3.978));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (19.103*(-21.913)*(40.85)*(-5.528)*(-23.876));
segmentsAcked = SlowStart (tcb, segmentsAcked);
