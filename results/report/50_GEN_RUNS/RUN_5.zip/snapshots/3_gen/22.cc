segmentsAcked = (int) (-13.078+(-14.94)+(68.09)+(75.036)+(38.718));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (20.229+(42.486)+(-99.458)+(-83.467)+(71.223));
segmentsAcked = (int) (-52.777+(29.378)+(14.788)+(-39.674)+(49.427));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-73.135+(51.064)+(62.723)+(67.814)+(54.246));
segmentsAcked = SlowStart (tcb, segmentsAcked);
