segmentsAcked = (int) (-81.062+(21.482)+(16.685)+(-18.314)+(3.062));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-23.055+(84.574)+(-99.362)+(12.152)+(16.916));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (88.354+(33.21)+(-66.122)+(-58.551)+(56.553));
segmentsAcked = SlowStart (tcb, segmentsAcked);
