segmentsAcked = (int) (67.692+(98.626)+(51.65)+(-71.89)+(40.725));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-13.808+(-43.678)+(25.687)+(31.741)+(-14.736));
segmentsAcked = SlowStart (tcb, segmentsAcked);
