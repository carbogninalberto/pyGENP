segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (19.583*(-96.786)*(-68.089)*(-48.486));
tcb->m_segmentSize = (int) (78.534-(71.133)-(-87.618)-(-55.416)-(-1.858)-(18.873)-(85.504)-(35.272));
tcb->m_segmentSize = (int) (-34.196*(-0.234)*(66.674)*(-77.422)*(-54.334));
segmentsAcked = SlowStart (tcb, segmentsAcked);
