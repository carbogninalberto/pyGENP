segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (90.16*(66.336)*(75.449)*(34.643));
tcb->m_segmentSize = (int) (-22.978-(-92.972)-(20.69)-(88.497)-(-55.838)-(-68.943)-(17.42)-(-88.331));
tcb->m_segmentSize = (int) (-77.896*(30.016)*(-1.926)*(88.122)*(-23.693));
segmentsAcked = SlowStart (tcb, segmentsAcked);
