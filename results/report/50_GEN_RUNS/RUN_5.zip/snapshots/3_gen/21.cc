tcb->m_segmentSize = (int) (74.115+(-89.331)+(-82.728));
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (49.765+(78.737)+(-7.585)+(-31.877)+(-56.334));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
