segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (94.518*(-95.856)*(49.028)*(19.702));
tcb->m_segmentSize = (int) (-5.953-(78.921)-(75.626)-(-10.432)-(20.126)-(-30.594)-(-42.338)-(2.421));
tcb->m_segmentSize = (int) (76.307-(23.109)-(-94.042)-(-92.458)-(-62.024)-(23.571)-(-36.499)-(-97.093));
tcb->m_segmentSize = (int) (-52.2*(42.122)*(-37.062)*(-45.817)*(-79.542));
tcb->m_segmentSize = (int) (-67.451*(-6.936)*(-91.534)*(33.464)*(-90.892));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
