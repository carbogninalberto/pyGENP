segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-45.096*(62.633)*(-10.921)*(-24.219));
tcb->m_segmentSize = (int) (-52.583*(7.978)*(-52.736)*(68.12)*(23.071));
tcb->m_segmentSize = (int) (-86.739-(51.335)-(-64.921)-(-8.712)-(-74.02)-(-55.972)-(4.206)-(20.929));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (54.431*(-38.169)*(22.807)*(-20.25)*(68.731));
segmentsAcked = SlowStart (tcb, segmentsAcked);
