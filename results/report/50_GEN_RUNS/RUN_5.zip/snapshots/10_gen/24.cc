TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_ssThresh+(segmentsAcked)+(60.603)+(58.264)+(91.844)+(27.785)+(64.255));
	segmentsAcked = (int) (6.703*(5.212)*(tcb->m_cWnd)*(48.417)*(33.25));

} else {
	segmentsAcked = (int) (58.181+(37.363)+(0.016)+(tcb->m_cWnd)+(3.426)+(69.567)+(51.135)+(0.368));

}
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(27.165));

} else {
	tcb->m_segmentSize = (int) (30.13*(44.32)*(57.073)*(71.014)*(tcb->m_ssThresh)*(segmentsAcked));
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(67.488));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(70.396)-(84.121)-(66.779)-(42.586)-(tcb->m_ssThresh)-(1.399)-(segmentsAcked));
tcb->m_cWnd = (int) (5.822*(13.919)*(85.501)*(67.105)*(15.919)*(32.573)*(20.362)*(96.357));
ReduceCwnd (tcb);
