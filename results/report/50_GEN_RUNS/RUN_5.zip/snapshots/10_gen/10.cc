segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-93.038*(-41.349)*(-2.647)*(-94.3));
tcb->m_segmentSize = (int) (76.539*(62.271)*(93.062)*(65.614)*(-25.523));
tcb->m_segmentSize = (int) (17.901-(-9.337)-(-70.099)-(-49.673)-(-75.806)-(0.989)-(3.264)-(-46.337));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (-50.954*(-63.145)*(49.388)*(32.895)*(86.234));
segmentsAcked = SlowStart (tcb, segmentsAcked);
