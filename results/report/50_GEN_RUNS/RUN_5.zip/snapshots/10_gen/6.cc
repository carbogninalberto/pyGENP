segmentsAcked = (int) (-29.1+(69.273)+(-40.233)+(44.33)+(52.141));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (93.273+(16.679)+(47.333)+(-11.096)+(-78.964));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
