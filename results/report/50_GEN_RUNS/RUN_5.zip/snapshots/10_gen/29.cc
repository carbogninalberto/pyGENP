tcb->m_cWnd = (int) (-35.57-(8.774)-(40.067)-(-10.066)-(-94.61)-(-27.737)-(7.804)-(-26.23)-(2.28));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
