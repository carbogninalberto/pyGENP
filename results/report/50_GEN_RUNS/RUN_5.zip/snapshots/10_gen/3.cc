segmentsAcked = (int) (1.797+(-3.38)+(20.572)+(3.109)+(23.3));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (89.339+(65.162)+(98.334)+(-3.214)+(-24.187));
segmentsAcked = SlowStart (tcb, segmentsAcked);
