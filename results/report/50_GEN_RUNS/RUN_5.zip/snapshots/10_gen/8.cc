segmentsAcked = (int) (46.08+(-55.32)+(-20.315)+(68.08)+(-46.376));
segmentsAcked = (int) (-89.889+(-56.982)+(-48.338)+(56.981)+(43.789));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (-65.483+(-2.667)+(-6.984)+(-31.577)+(94.363));
segmentsAcked = SlowStart (tcb, segmentsAcked);
