float vlIxyqphGatqZIHw = (float) (0.1/48.712);
tcb->m_cWnd = (int) (0.1/0.1);
tcb->m_cWnd = (int) (4.141+(68.386)+(29.555)+(43.271)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(27.26)+(92.619)+(20.778));
tcb->m_segmentSize = (int) (38.937+(33.901)+(segmentsAcked)+(tcb->m_segmentSize)+(52.559));
tcb->m_ssThresh = (int) (65.767+(63.736)+(60.155)+(91.393)+(52.245)+(96.572)+(25.569)+(30.927)+(42.334));
