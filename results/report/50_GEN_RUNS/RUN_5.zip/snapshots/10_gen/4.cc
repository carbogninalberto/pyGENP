segmentsAcked = (int) (41.696+(86.333)+(-90.152)+(-35.608)+(-8.819));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (13.224+(-39.829)+(-44.405)+(83.704)+(-88.992));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
