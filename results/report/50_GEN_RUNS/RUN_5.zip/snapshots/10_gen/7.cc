segmentsAcked = (int) (-55.315+(21.407)+(0.174)+(-8.876)+(8.869));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (72.987+(51.476)+(70.879)+(51.885)+(15.854));
segmentsAcked = (int) (-90.062+(-13.939)+(-12.623)+(39.146)+(-45.941));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
