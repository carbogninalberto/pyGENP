segmentsAcked = (int) (71.645+(-53.722)+(32.959)+(95.308)+(33.274));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (-93.642+(9.82)+(-26.797)+(-78.558)+(52.157));
segmentsAcked = (int) (-2.429+(-36.938)+(-15.78)+(-17.028)+(-89.095));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
