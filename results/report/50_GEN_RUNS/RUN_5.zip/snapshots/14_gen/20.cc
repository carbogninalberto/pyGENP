CongestionAvoidance (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (14.168+(51.596)+(59.568)+(36.712)+(21.84)+(tcb->m_cWnd)+(tcb->m_cWnd)+(32.744)+(2.183));
tcb->m_segmentSize = (int) (93.838+(73.213)+(22.458)+(63.027)+(25.951)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(73.1));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (37.283+(21.134)+(44.243));

} else {
	tcb->m_segmentSize = (int) (23.962+(71.097));
	tcb->m_ssThresh = (int) (17.149+(9.925)+(73.657)+(7.196));

}
