CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	segmentsAcked = (int) (94.893*(5.346)*(9.201)*(tcb->m_segmentSize)*(50.517));

} else {
	segmentsAcked = (int) (segmentsAcked+(79.471)+(tcb->m_ssThresh)+(53.402)+(87.308));
	CongestionAvoidance (tcb, segmentsAcked);
	segmentsAcked = (int) (9.733/27.045);

}
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (15.858+(15.986)+(tcb->m_cWnd)+(83.902)+(segmentsAcked)+(43.33));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (4.249+(73.307)+(71.372));
	ReduceCwnd (tcb);
	segmentsAcked = SlowStart (tcb, segmentsAcked);

}
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
ReduceCwnd (tcb);
segmentsAcked = (int) (0.1/46.523);
ReduceCwnd (tcb);
