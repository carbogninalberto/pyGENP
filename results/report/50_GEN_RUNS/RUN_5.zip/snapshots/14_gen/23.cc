tcb->m_ssThresh = (int) (segmentsAcked*(34.609)*(23.148)*(58.713)*(53.102)*(28.562)*(94.548)*(7.211)*(tcb->m_segmentSize));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/55.612);
	tcb->m_segmentSize = (int) (59.757*(78.713)*(16.226));
	tcb->m_cWnd = (int) (0.1/27.15);

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(4.777)+(64.833)+(91.658));

}
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	segmentsAcked = (int) (52.048+(segmentsAcked));
	tcb->m_ssThresh = (int) (4.963-(34.32)-(88.195)-(60.941)-(93.409)-(tcb->m_segmentSize)-(7.181)-(81.354)-(22.279));
	tcb->m_segmentSize = (int) (segmentsAcked-(4.647)-(29.566)-(15.847));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize-(16.286)-(0.605)-(23.729)-(2.077)-(23.845)-(1.444));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (32.863*(23.318)*(segmentsAcked));
	tcb->m_ssThresh = (int) (17.277+(42.46)+(49.981)+(84.078)+(12.02)+(23.206));
	tcb->m_ssThresh = (int) (31.408/6.487);

} else {
	tcb->m_ssThresh = (int) (((0.1)+((35.675-(tcb->m_cWnd)-(tcb->m_cWnd)-(98.08)-(tcb->m_segmentSize)-(17.359)-(60.219)))+(0.1)+(0.1))/((94.564)+(37.436)+(0.1)+(39.212)+(0.1)));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (75.398+(55.711)+(80.437)+(51.866)+(4.547));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) ((((89.932-(89.543)-(tcb->m_segmentSize)-(40.45)-(77.784)-(87.947)-(13.052)))+(0.1)+(0.1)+(0.1)+(0.1)+(71.06))/((18.996)));
