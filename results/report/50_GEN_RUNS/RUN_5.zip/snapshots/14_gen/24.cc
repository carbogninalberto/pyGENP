segmentsAcked = (int) (((0.1)+(0.1)+(33.598)+(0.1))/((88.288)+(0.1)+(0.1)+(29.406)));
tcb->m_cWnd = (int) (tcb->m_ssThresh+(47.582)+(3.603)+(tcb->m_cWnd)+(19.881));
tcb->m_cWnd = (int) (((71.859)+(0.1)+(10.342)+(84.924))/((50.08)));
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (66.96+(46.161)+(37.431)+(14.637));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

} else {
	tcb->m_ssThresh = (int) (18.159-(90.908)-(64.87)-(45.688)-(28.05));
	tcb->m_cWnd = (int) (83.365-(78.372)-(90.865)-(tcb->m_segmentSize)-(83.389)-(64.02)-(66.65));
	tcb->m_ssThresh = (int) (9.216*(58.718)*(26.601)*(11.347)*(84.82)*(13.909)*(10.481)*(25.691));

}
int bgxUOVBgiEYsUMfP = (int) (((0.1)+(86.76)+(0.1)+(0.1))/((12.732)+(47.541)));
tcb->m_ssThresh = (int) (31.143-(28.271)-(66.335)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(64.817)-(segmentsAcked)-(bgxUOVBgiEYsUMfP));
tcb->m_ssThresh = (int) ((((84.204-(23.154)-(bgxUOVBgiEYsUMfP)-(54.314)))+(0.1)+((77.781*(segmentsAcked)*(45.273)*(66.553)*(33.226)*(tcb->m_ssThresh)))+(0.1)+((97.64+(46.408)+(10.732)+(23.21)+(85.677)+(59.927)))+(89.031)+(0.1))/((0.1)));
tcb->m_ssThresh = (int) (34.35+(5.641)+(tcb->m_cWnd)+(11.168)+(73.458)+(33.976)+(16.232));
