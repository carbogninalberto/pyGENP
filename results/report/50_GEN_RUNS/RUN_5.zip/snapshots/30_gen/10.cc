segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (34.102+(90.223)+(segmentsAcked)+(73.013)+(4.519)+(87.766)+(48.605)+(tcb->m_segmentSize)+(26.627));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (33.788+(tcb->m_ssThresh));
	segmentsAcked = (int) (85.57-(48.873));

} else {
	tcb->m_ssThresh = (int) (0.1/95.229);
	tcb->m_cWnd = (int) (5.786+(tcb->m_cWnd)+(88.442)+(tcb->m_ssThresh)+(44.311)+(32.702)+(50.841));

}
tcb->m_cWnd = (int) (tcb->m_cWnd+(tcb->m_ssThresh)+(72.366)+(41.638)+(24.834));
tcb->m_segmentSize = (int) (((69.263)+(88.64)+(0.1)+(0.1)+(73.202)+(0.1)+(0.1))/((60.068)));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
