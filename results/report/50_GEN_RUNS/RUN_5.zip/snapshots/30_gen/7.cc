if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (98.202+(2.011)+(6.687)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(36.821));

} else {
	tcb->m_cWnd = (int) (17.512-(segmentsAcked));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
	tcb->m_segmentSize = (int) (segmentsAcked+(85.789));

}
ReduceCwnd (tcb);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (0.1/66.492);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
