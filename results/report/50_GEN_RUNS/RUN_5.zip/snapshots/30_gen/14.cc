segmentsAcked = SlowStart (tcb, segmentsAcked);
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (73.706*(6.938)*(tcb->m_segmentSize)*(16.945));
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(0.21)+(21.965)+(segmentsAcked)+(6.043)+(71.061));
	segmentsAcked = (int) (segmentsAcked-(27.506));

} else {
	tcb->m_segmentSize = (int) (30.845*(47.703)*(76.696));
	segmentsAcked = (int) (71.843+(28.576)+(62.187)+(82.438)+(26.515)+(10.14)+(5.107)+(tcb->m_cWnd));

}
segmentsAcked = (int) (25.172-(60.122)-(80.079)-(27.827)-(tcb->m_cWnd)-(27.489));
