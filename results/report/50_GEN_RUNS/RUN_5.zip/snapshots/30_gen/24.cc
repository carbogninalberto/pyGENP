if (tcb->m_ssThresh != tcb->m_ssThresh) {
	segmentsAcked = (int) (96.525*(3.198)*(92.093)*(64.658));

} else {
	segmentsAcked = (int) (60.569*(32.374));
	tcb->m_ssThresh = (int) (54.314+(51.548)+(segmentsAcked)+(tcb->m_cWnd));
	TcpLinuxCongestionAvoidance (tcb, segmentsAcked);

}
segmentsAcked = (int) (0.1/9.002);
tcb->m_segmentSize = (int) (66.689-(30.676)-(2.543)-(51.286)-(segmentsAcked)-(18.715)-(51.222)-(43.595)-(14.926));
tcb->m_cWnd = (int) (segmentsAcked-(67.934)-(9.682)-(11.321)-(1.953)-(47.767)-(30.129));
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_cWnd = (int) (61.456-(19.418));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (segmentsAcked+(71.535)+(11.498)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (((0.1)+(56.403)+(0.1)+(86.882)+(48.425)+((tcb->m_ssThresh+(48.796)+(tcb->m_segmentSize)+(78.344)+(44.167)+(25.076)+(65.577)))+(6.968)+(85.184))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (30.308-(35.097)-(28.546)-(7.628)-(44.361)-(tcb->m_ssThresh)-(72.57));
	CongestionAvoidance (tcb, segmentsAcked);
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(tcb->m_segmentSize)*(46.114)*(29.04)*(3.12)*(39.717)*(64.144));

}
