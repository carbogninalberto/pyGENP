tcb->m_segmentSize = (int) (50.622-(97.834)-(tcb->m_segmentSize));
tcb->m_cWnd = (int) (23.287+(69.744)+(82.967)+(64.569)+(45.627)+(16.449)+(59.294)+(97.348)+(segmentsAcked));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_ssThresh = (int) (89.267-(52.959)-(15.376)-(66.342)-(32.147)-(64.499)-(8.872));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (94.54*(tcb->m_segmentSize));
segmentsAcked = (int) (88.562+(tcb->m_cWnd));
tcb->m_cWnd = (int) (tcb->m_cWnd-(segmentsAcked)-(tcb->m_cWnd)-(tcb->m_segmentSize)-(47.33)-(32.038)-(99.2)-(55.586));
