segmentsAcked = (int) (0.1/55.901);
tcb->m_ssThresh = (int) (97.018-(97.509)-(9.545)-(64.57)-(9.909)-(77.893)-(76.964));
tcb->m_segmentSize = (int) ((76.044+(88.054)+(49.071)+(tcb->m_cWnd)+(58.578)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(52.441)+(33.563))/49.66);
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(58.398)-(tcb->m_ssThresh)-(83.693));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(58.87)-(56.12)-(tcb->m_ssThresh)-(66.557)-(tcb->m_segmentSize)-(66.085));
	tcb->m_cWnd = (int) (30.85+(53.874)+(58.872)+(18.591)+(53.383)+(18.228));

}
ReduceCwnd (tcb);
int bMfBkklRovJeYvYT = (int) (81.793*(tcb->m_segmentSize)*(8.282)*(15.403)*(49.471)*(90.115)*(4.113));
