ReduceCwnd (tcb);
if (tcb->m_segmentSize < cnt) {
	tcb->m_ssThresh = (int) (2.756-(18.306)-(95.854)-(7.078)-(62.107));

} else {
	tcb->m_ssThresh = (int) (46.744*(39.349)*(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (16.701+(30.562)+(31.815)+(33.844)+(13.891)+(7.424)+(11.834)+(22.748)+(31.171));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (3.413*(20.051)*(65.773)*(36.241)*(97.764));
