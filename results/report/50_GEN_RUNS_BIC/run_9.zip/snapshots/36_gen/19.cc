tcb->m_ssThresh = (int) (tcb->m_cWnd+(64.387)+(segmentsAcked)+(20.495));
tcb->m_cWnd = (int) (85.004*(77.952));
tcb->m_cWnd = (int) (segmentsAcked-(54.078)-(62.284)-(46.702)-(33.285)-(90.287));
float KiTSrjLanDnLeJyn = (float) (45.111+(tcb->m_cWnd)+(53.788)+(cnt)+(tcb->m_cWnd)+(18.969));
tcb->m_segmentSize = (int) (75.31*(75.748)*(82.895)*(71.002)*(cnt)*(28.157)*(48.261)*(42.216));
