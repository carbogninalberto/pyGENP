if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (0.1/0.1);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	cnt = (int) (46.231-(11.57));
	tcb->m_cWnd = (int) (44.285/78.715);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (76.566-(cnt)-(41.75)-(56.762)-(15.752)-(35.212)-(69.196));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (((93.828)+(60.489)+(85.829)+(78.03))/((96.716)+(86.73)+(0.1)+(0.1)));
