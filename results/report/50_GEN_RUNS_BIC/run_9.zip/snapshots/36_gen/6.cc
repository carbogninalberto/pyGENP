ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (cnt-(39.44)-(55.625)-(11.113)-(76.309)-(68.647)-(31.92)-(28.823));

} else {
	tcb->m_ssThresh = (int) (24.137-(16.218)-(87.907)-(tcb->m_cWnd));

}
tcb->m_ssThresh = (int) (84.869*(57.332)*(18.626)*(85.873)*(80.861));
tcb->m_cWnd = (int) (65.752+(18.125)+(0.435)+(cnt)+(tcb->m_segmentSize)+(30.988));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/(30.719*(54.994)*(73.308)*(41.906)*(21.442)));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(96.027));

} else {
	tcb->m_segmentSize = (int) (10.574*(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
