tcb->m_ssThresh = (int) (3.5-(33.717)-(44.54)-(83.233));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (57.45-(21.528)-(segmentsAcked)-(58.865)-(39.788)-(76.911)-(5.209)-(26.226));

} else {
	tcb->m_segmentSize = (int) (32.436+(2.604)+(tcb->m_cWnd)+(61.946)+(tcb->m_ssThresh)+(6.104));

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (1.656-(94.159));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) ((93.803+(21.915)+(segmentsAcked)+(2.471)+(cnt)+(68.158)+(40.6)+(62.789))/91.249);
	tcb->m_segmentSize = (int) (0.1/0.1);
	ReduceCwnd (tcb);

}
