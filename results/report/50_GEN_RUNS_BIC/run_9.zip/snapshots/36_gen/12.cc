ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_ssThresh-(1.17)-(82.01)-(39.169)-(73.617)-(28.329)-(82.627));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	cnt = (int) (39.65*(94.644));
	segmentsAcked = (int) (50.996*(46.171)*(tcb->m_segmentSize)*(9.555)*(17.28)*(49.312)*(segmentsAcked)*(68.899));
	tcb->m_ssThresh = (int) (0.1/86.271);

} else {
	cnt = (int) (41.533*(30.992));

}
cnt = (int) (cnt*(48.051)*(tcb->m_cWnd)*(41.233)*(37.773)*(26.061));
int IUgqwnUXZIRoGThe = (int) (68.821-(8.93)-(cnt));
