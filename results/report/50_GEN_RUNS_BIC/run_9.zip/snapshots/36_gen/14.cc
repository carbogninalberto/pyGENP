if (tcb->m_ssThresh != tcb->m_segmentSize) {
	cnt = (int) (95.53+(86.645)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(cnt)+(35.539)+(72.91));
	tcb->m_ssThresh = (int) (32.649-(89.337)-(48.928)-(53.253)-(9.645)-(95.027));

} else {
	cnt = (int) (99.839-(cnt)-(63.653)-(11.553)-(32.703)-(tcb->m_segmentSize)-(59.972)-(44.567)-(tcb->m_segmentSize));

}
if (tcb->m_ssThresh == cnt) {
	segmentsAcked = (int) (36.567+(86.198)+(78.554)+(59.785)+(85.496));

} else {
	segmentsAcked = (int) (92.345-(tcb->m_segmentSize)-(40.686)-(82.508)-(0.313)-(0.657));
	tcb->m_segmentSize = (int) (49.861*(44.852)*(12.094)*(cnt)*(8.598));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh >= cnt) {
	cnt = (int) (1.56*(42.197));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (cnt-(42.319)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(12.674)-(65.556)-(20.512));

}
tcb->m_ssThresh = (int) (81.743*(87.329)*(43.503)*(27.647)*(tcb->m_segmentSize)*(10.195));
