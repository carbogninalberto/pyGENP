tcb->m_segmentSize = (int) (86.571*(5.594)*(tcb->m_segmentSize));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((23.373)+(0.1)+(0.1)+(82.543)+(0.1)+(0.1))/((21.896)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (61.769-(42.858)-(52.638)-(58.989));
	segmentsAcked = (int) (26.411*(2.602)*(47.979)*(81.852)*(cnt)*(80.498));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (72.174*(tcb->m_ssThresh)*(59.247)*(90.826)*(89.833)*(71.192)*(0.261)*(47.092)*(25.044));
