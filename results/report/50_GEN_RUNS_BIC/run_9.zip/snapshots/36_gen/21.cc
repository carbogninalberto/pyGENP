if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((9.769)+(0.1)+(1.008)+((45.828-(86.717)-(64.475)-(16.396)-(15.218)-(77.04)-(51.865)-(45.016)-(92.618)))+(10.132)+(0.1)+(7.943)+(0.1))/((0.1)));

} else {
	tcb->m_cWnd = (int) (87.988+(segmentsAcked)+(6.366));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (97.548+(tcb->m_ssThresh)+(33.901)+(26.489)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(86.361)+(43.849));

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (31.552-(34.484)-(87.447));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (16.155+(77.305)+(54.117)+(18.378)+(22.563)+(59.002)+(24.268)+(79.802));
	tcb->m_cWnd = (int) (50.022+(95.515)+(17.569)+(62.366));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
int giQyMtHwZlwISdCN = (int) (62.12-(tcb->m_ssThresh));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
giQyMtHwZlwISdCN = (int) (8.711*(85.22)*(18.59)*(56.909)*(giQyMtHwZlwISdCN)*(14.794)*(85.968));
tcb->m_ssThresh = (int) (cnt*(8.615));
tcb->m_segmentSize = (int) (segmentsAcked+(tcb->m_segmentSize)+(90.506)+(21.928));
