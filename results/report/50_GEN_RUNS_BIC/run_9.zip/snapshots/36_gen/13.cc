ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (98.797*(78.807));
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (11.909*(18.619)*(4.123)*(cnt));

} else {
	tcb->m_segmentSize = (int) (55.538-(4.733)-(90.85)-(52.203)-(78.044)-(61.086)-(29.466)-(18.098));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (13.204*(24.971)*(segmentsAcked)*(23.641)*(cnt)*(78.244)*(73.028)*(51.226));

}
