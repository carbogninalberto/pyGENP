tcb->m_cWnd = (int) (97.918+(1.28)+(30.541));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
segmentsAcked = (int) (94.189*(31.984));
if (cnt > tcb->m_ssThresh) {
	segmentsAcked = (int) (cnt-(19.871));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (98.72+(58.304)+(16.544)+(91.275)+(67.288)+(tcb->m_segmentSize));

}
if (cnt == segmentsAcked) {
	tcb->m_ssThresh = (int) (((0.1)+(31.195)+(0.1)+(65.163))/((10.869)+(25.323)+(6.217)));

} else {
	tcb->m_ssThresh = (int) ((tcb->m_ssThresh+(tcb->m_cWnd)+(tcb->m_ssThresh)+(cnt)+(47.0)+(tcb->m_segmentSize)+(66.66))/37.107);

}
