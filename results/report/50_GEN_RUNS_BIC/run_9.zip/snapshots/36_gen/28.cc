if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (58.14-(2.403)-(3.899)-(tcb->m_cWnd)-(96.087));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (79.374/99.761);

} else {
	tcb->m_segmentSize = (int) (62.015+(54.954));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int lXAnJzzbSaPNHGXv = (int) (tcb->m_cWnd*(88.599)*(35.346)*(40.094)*(61.174));
