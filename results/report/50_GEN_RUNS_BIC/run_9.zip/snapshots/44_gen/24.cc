ReduceCwnd (tcb);
tcb->m_ssThresh = (int) ((((22.458+(tcb->m_segmentSize)+(58.136)+(8.297)+(70.409)))+(0.1)+(48.327)+(0.1)+(87.096)+(88.769))/((58.354)+(0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	cnt = (int) (73.801-(41.597)-(segmentsAcked)-(71.591)-(94.034)-(segmentsAcked)-(6.822)-(64.224));
	tcb->m_segmentSize = (int) (79.128+(segmentsAcked)+(28.213)+(15.676)+(0.646)+(25.181)+(96.991)+(38.752));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (27.75+(9.841)+(95.117));
	ReduceCwnd (tcb);
	cnt = (int) (44.057*(32.994)*(24.579));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(21.281)-(89.508));
	tcb->m_ssThresh = (int) (73.318-(55.767)-(32.624)-(22.837)-(10.02)-(segmentsAcked)-(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (segmentsAcked+(60.076));

}
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(55.042)*(17.54)*(33.442));
	segmentsAcked = (int) (tcb->m_ssThresh*(tcb->m_segmentSize)*(46.145)*(56.997));

} else {
	tcb->m_cWnd = (int) (49.158*(31.021)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(20.006)*(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
