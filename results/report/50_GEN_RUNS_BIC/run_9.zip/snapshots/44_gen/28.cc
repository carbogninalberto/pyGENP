int ldHBKyJaPenBRcpX = (int) (cnt*(18.117)*(77.743)*(tcb->m_segmentSize));
if (ldHBKyJaPenBRcpX < tcb->m_segmentSize) {
	ldHBKyJaPenBRcpX = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((68.565)+(95.768)));
	tcb->m_cWnd = (int) (14.828-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	ldHBKyJaPenBRcpX = (int) (77.201-(98.964)-(41.513)-(3.364)-(segmentsAcked)-(58.043)-(48.562)-(14.056));

}
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (95.593*(ldHBKyJaPenBRcpX)*(52.74)*(24.984)*(69.183)*(5.668)*(segmentsAcked)*(tcb->m_segmentSize)*(52.797));
	cnt = (int) ((((44.644*(71.161)*(tcb->m_cWnd)*(29.465)))+(0.1)+(0.1)+(36.625))/((0.1)+(75.046)+(20.812)));

} else {
	segmentsAcked = (int) (32.309-(44.748));
	ldHBKyJaPenBRcpX = (int) (48.735-(20.169)-(25.299)-(19.53));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (40.689*(57.572)*(12.781)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(11.443)*(49.269));
