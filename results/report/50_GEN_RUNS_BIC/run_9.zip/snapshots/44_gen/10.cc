ReduceCwnd (tcb);
float yDJrLBJiYsUVRBWc = (float) ((((70.002*(tcb->m_ssThresh)*(82.892)))+(0.1)+(13.919)+(0.1))/((0.1)));
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (67.747-(72.354)-(42.45)-(42.553)-(20.849)-(tcb->m_segmentSize)-(21.931)-(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (71.484-(9.484)-(92.271));
	cnt = (int) (50.147+(cnt)+(28.594)+(97.984)+(19.149));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float HkGTcbvtmEHkIDCG = (float) (0.1/17.786);
