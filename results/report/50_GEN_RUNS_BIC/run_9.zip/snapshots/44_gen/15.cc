tcb->m_cWnd = (int) (47.525-(segmentsAcked)-(46.936)-(tcb->m_cWnd)-(72.196)-(78.285)-(0.46)-(17.687));
tcb->m_ssThresh = (int) (33.325/0.1);
float JWChWbzeuWrNblId = (float) (57.816/33.266);
int QTNWqwvRpmUkjVhG = (int) (0.1/0.1);
tcb->m_segmentSize = (int) (((79.265)+(16.753)+(96.87)+(0.1)+((QTNWqwvRpmUkjVhG*(segmentsAcked)*(14.369)))+(6.011))/((0.1)+(64.405)));
ReduceCwnd (tcb);
