if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	segmentsAcked = (int) (27.158+(5.439)+(99.233)+(68.801)+(tcb->m_cWnd)+(67.23)+(tcb->m_cWnd)+(-0.081)+(cnt));

} else {
	segmentsAcked = (int) (((25.566)+((83.698+(35.017)))+(0.1)+(96.721)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)));
	tcb->m_ssThresh = (int) (95.35*(21.305)*(79.1)*(74.061)*(65.333));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (84.226*(87.742));
tcb->m_segmentSize = (int) (81.967-(tcb->m_cWnd)-(9.556)-(tcb->m_ssThresh)-(15.873)-(27.044)-(46.849)-(12.909)-(85.499));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (56.19*(42.148)*(81.546)*(7.616)*(-0.028)*(tcb->m_segmentSize)*(44.544)*(cnt));

} else {
	tcb->m_ssThresh = (int) (55.128*(65.588));

}
