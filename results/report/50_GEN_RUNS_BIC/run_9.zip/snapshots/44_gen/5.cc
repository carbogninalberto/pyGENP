if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int NzAAwmGZxGriksdC = (int) (tcb->m_segmentSize+(93.644)+(25.504)+(77.22)+(60.961)+(3.774)+(tcb->m_segmentSize));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (36.797*(16.345)*(73.215)*(12.09)*(64.925)*(78.768)*(69.11)*(60.782));
cnt = (int) (74.572+(31.31));
