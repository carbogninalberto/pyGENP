cnt = (int) (7.491/93.511);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int eJfGQaNhcvqVSgSE = (int) (16.676-(94.397)-(14.643)-(20.421)-(37.194)-(47.895)-(63.36)-(9.339));
if (tcb->m_ssThresh > eJfGQaNhcvqVSgSE) {
	cnt = (int) (39.418*(51.498)*(1.002)*(43.105)*(81.34)*(74.743)*(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	cnt = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (56.13-(42.053)-(24.073)-(tcb->m_ssThresh)-(66.435)-(13.523)-(93.437)-(85.475));

}
cnt = (int) (eJfGQaNhcvqVSgSE-(42.343)-(79.315));
tcb->m_ssThresh = (int) (74.343-(segmentsAcked)-(52.271)-(19.293)-(21.537)-(57.728)-(55.553)-(40.299));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
