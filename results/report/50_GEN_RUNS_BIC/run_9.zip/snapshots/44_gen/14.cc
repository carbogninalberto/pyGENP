if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (((17.376)+(0.1)+((70.68-(segmentsAcked)-(85.356)-(51.307)-(14.82)-(segmentsAcked)-(35.667)))+(0.1)+(68.298))/((78.009)));
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (38.354+(97.36));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(37.173));

}
segmentsAcked = (int) (72.701*(12.13)*(18.946));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (segmentsAcked*(46.036)*(45.577)*(17.885)*(tcb->m_segmentSize));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (51.335+(57.687)+(tcb->m_cWnd)+(tcb->m_ssThresh));

}
