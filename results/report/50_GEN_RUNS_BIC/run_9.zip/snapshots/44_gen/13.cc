if (tcb->m_cWnd <= tcb->m_cWnd) {
	cnt = (int) (86.101*(28.902)*(87.248)*(99.465)*(40.032)*(51.159)*(97.509));

} else {
	cnt = (int) (54.858+(93.743)+(28.372)+(62.23));

}
cnt = (int) (15.53+(80.321)+(46.926)+(7.084)+(tcb->m_segmentSize)+(9.992)+(29.215));
if (cnt <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (cnt+(tcb->m_segmentSize)+(62.107)+(55.594)+(36.89)+(87.46)+(55.751)+(5.093));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (76.511+(64.845)+(73.584)+(93.004)+(93.276));

} else {
	tcb->m_cWnd = (int) (0.1/77.139);

}
tcb->m_cWnd = (int) (98.644-(26.826)-(60.019)-(55.344)-(60.332)-(tcb->m_ssThresh));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (49.87-(7.685)-(30.765)-(88.758)-(23.04)-(29.791)-(tcb->m_ssThresh)-(50.446)-(segmentsAcked));
	segmentsAcked = (int) (16.188*(93.925)*(96.452));
	tcb->m_ssThresh = (int) (59.764-(38.573)-(63.261));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(78.218)*(72.229));

}
ReduceCwnd (tcb);
