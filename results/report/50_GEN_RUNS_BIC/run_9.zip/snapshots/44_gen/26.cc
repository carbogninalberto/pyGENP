if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (76.375*(5.125)*(99.775)*(3.813)*(7.812)*(95.214)*(96.924));
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (35.742+(14.927)+(95.083)+(26.071));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) ((tcb->m_segmentSize*(58.173)*(tcb->m_ssThresh)*(94.097)*(cnt))/0.1);
	tcb->m_cWnd = (int) ((73.935*(tcb->m_cWnd)*(97.913)*(74.271)*(tcb->m_segmentSize)*(62.262)*(60.555)*(77.801))/0.1);

}
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/37.287);
	tcb->m_cWnd = (int) (31.479+(52.495)+(cnt)+(79.683)+(46.65)+(66.999)+(92.251)+(85.598)+(51.957));
	tcb->m_ssThresh = (int) (14.928+(33.684)+(tcb->m_ssThresh)+(84.079)+(2.151)+(tcb->m_ssThresh)+(62.861)+(37.567)+(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (95.716-(87.666)-(92.699)-(84.887)-(tcb->m_ssThresh)-(10.852)-(tcb->m_cWnd)-(97.085)-(35.606));
	tcb->m_cWnd = (int) (44.524*(23.635)*(81.558)*(23.315)*(segmentsAcked)*(22.488)*(33.316)*(85.466));

}
