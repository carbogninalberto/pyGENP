tcb->m_cWnd = (int) (-86.772+(70.689)+(34.638)+(-13.278)+(-93.638)+(-49.052)+(41.068)+(-60.133)+(-5.682));
segmentsAcked = (int) (58.124-(-16.023)-(-52.608)-(60.262)-(92.323)-(-97.839)-(60.119)-(90.873)-(73.741));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
