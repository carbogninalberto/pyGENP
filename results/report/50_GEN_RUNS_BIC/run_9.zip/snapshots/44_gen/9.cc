if (tcb->m_ssThresh > segmentsAcked) {
	segmentsAcked = (int) (20.782+(57.317)+(41.554)+(47.484)+(47.83)+(66.769)+(28.803));

} else {
	segmentsAcked = (int) (segmentsAcked+(tcb->m_cWnd)+(51.74)+(4.834)+(57.664)+(95.031));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (27.428*(7.669)*(tcb->m_segmentSize)*(0.918)*(28.751)*(21.779)*(tcb->m_segmentSize)*(81.854)*(56.921));

}
segmentsAcked = (int) (80.479*(segmentsAcked)*(61.46)*(91.237));
cnt = (int) (54.06+(59.131));
float jRbnSjXLIWOkfHXU = (float) (78.383-(27.021)-(6.798)-(49.618)-(26.62)-(39.759)-(28.818));
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_cWnd = (int) ((jRbnSjXLIWOkfHXU*(31.09)*(92.113)*(84.484)*(cnt))/64.214);
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(cnt)+(46.928)+(58.975)+(10.137)+(27.873)+(segmentsAcked)+(68.725)+(45.04));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(70.258)-(31.389)-(1.8)-(88.852));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(71.443));

}
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (76.528+(33.386)+(tcb->m_ssThresh)+(43.661)+(13.612)+(61.324)+(70.402)+(69.699)+(22.912));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(41.495)-(91.654)-(51.175));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
