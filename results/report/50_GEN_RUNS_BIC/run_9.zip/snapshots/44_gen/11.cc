if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	cnt = (int) (77.665*(33.061)*(99.467)*(66.319)*(9.028)*(2.252)*(60.986)*(60.2)*(segmentsAcked));
	tcb->m_cWnd = (int) (57.099-(19.571)-(6.108));
	tcb->m_segmentSize = (int) (34.182-(61.561)-(segmentsAcked)-(31.982)-(segmentsAcked)-(52.991)-(tcb->m_segmentSize)-(99.399)-(32.671));

} else {
	cnt = (int) (84.317*(85.236)*(tcb->m_ssThresh)*(94.046)*(67.249)*(45.917)*(38.949)*(82.489)*(37.501));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
cnt = (int) (5.419-(99.452)-(76.605));
