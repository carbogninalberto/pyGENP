int FikFZhaCVqsABABe = (int) (-57.534-(98.46)-(-17.069)-(-7.584)-(-96.561)-(9.475));
float yfpyesPtAVyYFKsF = (float) (-40.128-(38.948)-(48.695)-(-99.419)-(-32.598)-(56.325)-(2.265)-(87.623));
tcb->m_cWnd = (int) (17.101+(-73.264));
ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_cWnd) {
	yfpyesPtAVyYFKsF = (float) (69.631+(68.116)+(89.147)+(93.646)+(94.306)+(94.444)+(97.847));

} else {
	yfpyesPtAVyYFKsF = (float) (36.271+(53.733)+(21.597)+(60.004)+(44.976)+(7.885)+(48.013));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (15.58-(50.123)-(-82.034));
