tcb->m_cWnd = (int) (65.542-(1.735));
segmentsAcked = (int) (54.724*(69.143)*(42.361)*(72.241));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	segmentsAcked = (int) (5.155*(32.243)*(tcb->m_ssThresh)*(9.02)*(52.896)*(33.307)*(49.888)*(tcb->m_segmentSize)*(20.211));
	tcb->m_ssThresh = (int) (92.011*(73.202)*(14.166)*(75.091)*(79.188));

} else {
	segmentsAcked = (int) (((0.1)+(91.927)+((35.155-(26.576)-(83.161)-(56.611)-(36.919)))+(0.1)+(0.1)+(0.1))/((0.1)+(82.513)));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
