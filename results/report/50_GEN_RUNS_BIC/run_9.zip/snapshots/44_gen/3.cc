int dqtBaeClzheKSwdJ = (int) (19.38/18.407);
float zIthTlYlsnHRJQbZ = (float) (90.169-(-83.064)-(-77.872)-(-4.569)-(54.649)-(62.533));
segmentsAcked = (int) (24.398*(56.274)*(78.946)*(-78.826)*(-86.514));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (6.552-(59.65)-(-61.663)-(96.358)-(-73.12)-(37.989)-(-29.256)-(-14.228));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
