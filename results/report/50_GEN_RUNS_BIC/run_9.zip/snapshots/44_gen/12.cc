if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (67.14-(12.168));
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.383*(82.712)*(56.879)*(61.667)*(58.918)*(26.261)*(52.65));
	tcb->m_cWnd = (int) (19.129+(3.268)+(74.73)+(31.689)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (8.088/0.1);

} else {
	tcb->m_ssThresh = (int) (33.032+(5.471)+(58.661)+(78.716));

}
ReduceCwnd (tcb);
