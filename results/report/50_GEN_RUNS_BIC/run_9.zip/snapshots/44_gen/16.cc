ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (52.856+(2.915)+(8.431)+(segmentsAcked)+(tcb->m_cWnd)+(71.213)+(97.299));
float MvPjiwdUjJmytOhK = (float) (segmentsAcked+(92.584)+(63.672)+(1.882)+(63.578)+(16.317));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (2.432-(13.076)-(cnt)-(60.375)-(26.587)-(17.569));
