if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked != cnt) {
	tcb->m_ssThresh = (int) (20.296*(tcb->m_cWnd)*(33.786)*(65.526)*(37.527));

} else {
	tcb->m_ssThresh = (int) ((71.032*(37.519)*(cnt)*(85.136)*(5.767))/0.1);

}
tcb->m_ssThresh = (int) (((66.196)+(11.197)+(0.1)+(77.478))/((0.1)));
ReduceCwnd (tcb);
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (43.362-(58.979));
	segmentsAcked = (int) (27.884+(52.126));

} else {
	tcb->m_cWnd = (int) (0.1/97.815);
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (56.115-(15.606));

} else {
	tcb->m_ssThresh = (int) (96.328-(17.578)-(9.544)-(tcb->m_cWnd)-(50.699));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
