tcb->m_segmentSize = (int) (37.669+(52.489)+(39.468)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(15.638)+(80.632)+(88.348)+(71.098));
tcb->m_segmentSize = (int) (0.1/(82.111*(47.6)*(69.986)*(81.451)*(97.405)*(97.836)*(74.297)*(cnt)*(29.501)));
int ZnmNWcvkWZDLQiEi = (int) (57.644+(segmentsAcked)+(65.788)+(24.888)+(cnt));
float juovOAvCnoIiZAUS = (float) (49.921+(10.133)+(83.048)+(81.673)+(82.459)+(11.845));
ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_cWnd) {
	cnt = (int) (67.233+(13.973));
	ZnmNWcvkWZDLQiEi = (int) (80.728-(juovOAvCnoIiZAUS)-(87.801)-(46.434)-(34.281));

} else {
	cnt = (int) (cnt-(84.153)-(cnt)-(70.869)-(92.294)-(30.817)-(39.746));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt == segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(tcb->m_segmentSize)+(25.127)+(tcb->m_ssThresh)+(75.29)+(63.944));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) ((((tcb->m_cWnd*(93.175)*(6.421)*(49.308)*(ZnmNWcvkWZDLQiEi)*(72.909)*(78.376)*(31.373)))+(9.281)+(0.1)+(8.454)+(11.483))/((47.718)+(0.1)+(61.599)+(2.895)));

} else {
	tcb->m_cWnd = (int) ((cnt+(51.604)+(40.218)+(8.925)+(26.433)+(26.691)+(42.71)+(97.254)+(tcb->m_ssThresh))/28.999);
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_segmentSize = (int) (ZnmNWcvkWZDLQiEi-(18.198)-(90.472)-(92.595)-(58.872)-(juovOAvCnoIiZAUS)-(2.007)-(ZnmNWcvkWZDLQiEi)-(0.112));

} else {
	tcb->m_segmentSize = (int) (((87.881)+(0.1)+(0.1)+(24.304))/((1.757)));
	juovOAvCnoIiZAUS = (float) (cnt+(10.523)+(57.183)+(43.727)+(94.541)+(11.308));

}
