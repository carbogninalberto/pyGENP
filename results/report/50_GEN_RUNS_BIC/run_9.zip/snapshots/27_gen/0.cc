tcb->m_cWnd = (int) (((-18.973)+(-10.896)+(18.62)+(64.587)+(-51.17))/((-16.955)+(-79.064)+(-87.43)));
float GuyUVdKroxGZfQfO = (float) (-96.503-(-94.52)-(-43.454));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) ((-74.727*(77.816)*(-68.447)*(tcb->m_ssThresh)*(-97.072))/18.113);
tcb->m_segmentSize = (int) ((22.988*(77.227)*(-39.25)*(tcb->m_ssThresh)*(-59.573))/-44.879);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (24.069-(36.232)-(-70.951)-(13.428)-(36.124));

} else {
	tcb->m_cWnd = (int) (20.308*(segmentsAcked)*(60.756)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(88.44)*(49.34)*(90.908));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (24.069-(36.621)-(49.593)-(13.428)-(36.124));

} else {
	tcb->m_cWnd = (int) (20.308*(segmentsAcked)*(60.756)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(88.44)*(49.34)*(90.908));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
