if (tcb->m_cWnd >= tcb->m_segmentSize) {
	cnt = (int) ((53.054*(cnt))/0.1);
	tcb->m_segmentSize = (int) (24.45*(12.302));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (52.662-(87.279));
	tcb->m_cWnd = (int) ((cnt-(1.664)-(78.768)-(tcb->m_segmentSize)-(81.286))/(52.634-(52.394)-(20.03)-(76.152)-(52.756)-(33.851)-(tcb->m_segmentSize)-(cnt)-(93.474)));

}
float txshHsCZurIFDCcQ = (float) (65.144*(77.601)*(46.481)*(94.039)*(7.712));
tcb->m_segmentSize = (int) (tcb->m_ssThresh*(24.288));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (txshHsCZurIFDCcQ <= cnt) {
	tcb->m_ssThresh = (int) (79.77*(43.674)*(20.915)*(91.091));
	tcb->m_segmentSize = (int) (79.875+(50.546)+(10.405)+(5.317)+(94.327)+(25.856)+(tcb->m_cWnd));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (37.349*(31.133)*(67.706)*(85.92)*(79.61)*(80.906)*(23.102)*(66.612));
	tcb->m_cWnd = (int) (98.543+(segmentsAcked)+(txshHsCZurIFDCcQ)+(45.213)+(cnt)+(55.954)+(cnt)+(txshHsCZurIFDCcQ));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
txshHsCZurIFDCcQ = (float) (29.666-(76.512)-(7.0)-(73.583)-(6.198)-(cnt)-(segmentsAcked)-(0.906));
