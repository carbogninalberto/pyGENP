ReduceCwnd (tcb);
segmentsAcked = (int) ((43.066-(45.097)-(7.276))/0.1);
if (cnt > tcb->m_ssThresh) {
	cnt = (int) (cnt*(21.456)*(23.939)*(12.978)*(cnt));
	tcb->m_segmentSize = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (98.076-(70.817));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (67.75+(45.304)+(42.934)+(tcb->m_ssThresh)+(95.427)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(61.596));

}
tcb->m_ssThresh = (int) (0.1/22.583);
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (23.465-(87.549)-(3.914));

}
tcb->m_ssThresh = (int) ((cnt*(84.437)*(71.749)*(cnt))/9.226);
tcb->m_segmentSize = (int) (73.804-(44.104)-(segmentsAcked)-(34.595)-(66.638)-(tcb->m_cWnd)-(15.892));
ReduceCwnd (tcb);
