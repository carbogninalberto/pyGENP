float RsnUHQZuazNrmyER = (float) (0.1/3.389);
if (tcb->m_ssThresh <= cnt) {
	RsnUHQZuazNrmyER = (float) (88.393*(3.615)*(92.401)*(77.691)*(80.104));
	segmentsAcked = (int) (98.317+(58.92)+(20.031)+(52.657)+(89.792)+(56.487)+(46.722)+(tcb->m_segmentSize)+(8.323));

} else {
	RsnUHQZuazNrmyER = (float) (72.426-(99.779)-(71.071)-(4.145)-(6.485)-(66.47)-(cnt)-(83.241)-(tcb->m_cWnd));
	segmentsAcked = (int) (62.164-(70.813)-(RsnUHQZuazNrmyER)-(90.354)-(9.627)-(22.385)-(91.062)-(33.436)-(tcb->m_segmentSize));

}
if (tcb->m_segmentSize <= RsnUHQZuazNrmyER) {
	tcb->m_cWnd = (int) (RsnUHQZuazNrmyER*(80.908));
	tcb->m_segmentSize = (int) (94.29*(13.415)*(44.951)*(11.226)*(14.645)*(77.465)*(13.795)*(tcb->m_ssThresh)*(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (78.469+(27.018));

}
cnt = (int) (cnt+(61.354)+(78.058)+(97.136)+(56.459));
int zOShBvyciUTUEsJh = (int) (75.43-(cnt)-(72.763)-(56.611)-(tcb->m_segmentSize)-(RsnUHQZuazNrmyER)-(tcb->m_cWnd));
ReduceCwnd (tcb);
int eXxChgHWfBivgiCK = (int) (tcb->m_ssThresh-(28.702)-(39.718)-(73.653)-(zOShBvyciUTUEsJh)-(89.919)-(20.994));
int LdsfTrJfACffsAoc = (int) (47.545*(tcb->m_ssThresh)*(95.729)*(27.839)*(36.828)*(RsnUHQZuazNrmyER)*(tcb->m_segmentSize)*(86.395)*(42.388));
