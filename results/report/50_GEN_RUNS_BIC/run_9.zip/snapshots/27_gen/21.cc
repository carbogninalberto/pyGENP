ReduceCwnd (tcb);
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (64.286*(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(52.343)*(50.335)*(85.083)*(41.402)*(segmentsAcked)*(tcb->m_ssThresh));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (34.392*(tcb->m_segmentSize)*(44.563));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (85.283-(67.713));
	tcb->m_cWnd = (int) (59.068+(11.499)+(39.427)+(96.259)+(84.332)+(cnt)+(54.954));

} else {
	tcb->m_ssThresh = (int) (50.192+(tcb->m_segmentSize)+(26.555)+(12.364)+(16.408)+(47.894)+(80.606)+(3.129));
	segmentsAcked = (int) (tcb->m_cWnd*(14.013)*(5.933)*(cnt)*(tcb->m_ssThresh)*(44.58)*(6.111));

}
