if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(76.182)-(99.309));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	cnt = (int) (30.608*(98.553)*(46.406)*(39.784)*(78.915)*(98.78));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	segmentsAcked = (int) (12.344/0.1);
	ReduceCwnd (tcb);
	cnt = (int) (0.1/39.05);

} else {
	segmentsAcked = (int) (43.504-(89.569)-(tcb->m_ssThresh)-(segmentsAcked)-(cnt)-(6.052)-(7.372)-(40.288));
	tcb->m_ssThresh = (int) (17.225*(43.385)*(43.372)*(94.192)*(tcb->m_ssThresh)*(cnt)*(tcb->m_ssThresh));

}
tcb->m_segmentSize = (int) (8.947-(33.312)-(74.663)-(97.217)-(72.932)-(25.166)-(86.885)-(tcb->m_cWnd)-(27.53));
if (segmentsAcked >= tcb->m_cWnd) {
	cnt = (int) (78.783*(37.082)*(5.876)*(60.341)*(18.219)*(28.478));

} else {
	cnt = (int) (cnt*(51.975)*(43.76)*(28.085)*(tcb->m_ssThresh)*(11.545)*(27.909)*(38.609)*(23.494));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (56.226+(85.969)+(segmentsAcked)+(82.679)+(4.894)+(tcb->m_cWnd)+(59.617)+(83.964)+(93.474));
tcb->m_cWnd = (int) (45.127/33.46);
segmentsAcked = (int) (9.474+(22.977)+(tcb->m_segmentSize));
