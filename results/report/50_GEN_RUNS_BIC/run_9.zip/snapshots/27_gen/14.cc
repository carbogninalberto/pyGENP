tcb->m_segmentSize = (int) (8.135+(87.738)+(70.879)+(69.019)+(24.609)+(68.667)+(65.325));
tcb->m_ssThresh = (int) (13.51+(7.515)+(84.498)+(47.46)+(cnt));
cnt = (int) (49.882+(81.142)+(68.785));
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (99.47-(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (44.876+(42.495)+(segmentsAcked)+(57.661)+(18.742)+(44.831)+(15.617)+(43.502)+(76.453));

}
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (47.912-(31.406)-(33.853)-(39.531)-(tcb->m_segmentSize)-(22.288));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (24.522+(tcb->m_ssThresh)+(tcb->m_cWnd)+(15.798)+(13.985));
	segmentsAcked = (int) (40.425+(64.709)+(8.694)+(99.725)+(86.147)+(cnt)+(67.466)+(tcb->m_ssThresh));

}
int LiFVdpOMtWTzWdWp = (int) (17.755+(tcb->m_ssThresh));
tcb->m_cWnd = (int) (70.173+(18.594)+(85.895));
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) (60.798+(70.791)+(76.703)+(tcb->m_cWnd)+(75.753)+(57.635));
	LiFVdpOMtWTzWdWp = (int) (84.317-(81.506)-(77.81)-(tcb->m_ssThresh)-(28.284));
	cnt = (int) (25.589-(65.507)-(28.229)-(32.884)-(82.603)-(37.668)-(LiFVdpOMtWTzWdWp)-(38.794)-(68.377));

} else {
	tcb->m_cWnd = (int) (16.975*(76.99));

}
