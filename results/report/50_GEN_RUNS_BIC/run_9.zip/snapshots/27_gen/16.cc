if (cnt > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (cnt*(tcb->m_segmentSize));
	cnt = (int) (49.494+(59.983)+(tcb->m_ssThresh)+(64.668)+(80.789)+(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (((38.27)+(16.482)+(0.1)+(56.324)+(28.296)+(83.952))/((78.077)+(93.345)+(1.473)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (32.871-(46.187)-(50.232)-(segmentsAcked)-(77.372)-(tcb->m_ssThresh)-(66.224)-(31.16)-(tcb->m_segmentSize));

}
tcb->m_cWnd = (int) (91.757*(0.805)*(segmentsAcked)*(44.112)*(78.906)*(tcb->m_ssThresh)*(48.893));
if (tcb->m_ssThresh >= segmentsAcked) {
	segmentsAcked = (int) (tcb->m_ssThresh+(7.633)+(38.609)+(28.385)+(64.055));

} else {
	segmentsAcked = (int) (77.057*(segmentsAcked)*(tcb->m_segmentSize)*(16.405)*(68.252)*(99.816)*(67.347)*(cnt)*(cnt));
	cnt = (int) (6.575*(52.453)*(60.391)*(60.069)*(13.715)*(16.216)*(28.161)*(62.98)*(cnt));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float mKddkcELvkYqAPKh = (float) (37.091*(56.521)*(61.104)*(0.301)*(tcb->m_ssThresh)*(39.266));
tcb->m_cWnd = (int) (((35.244)+(0.1)+(39.427)+(22.635)+(2.514))/((0.1)+(0.1)+(0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked == tcb->m_cWnd) {
	mKddkcELvkYqAPKh = (float) (82.727+(63.619)+(61.309)+(tcb->m_ssThresh)+(34.111)+(62.733)+(12.27));
	cnt = (int) (60.805-(69.885)-(15.864)-(mKddkcELvkYqAPKh)-(48.626)-(tcb->m_segmentSize)-(71.277));

} else {
	mKddkcELvkYqAPKh = (float) (96.532-(45.468)-(27.858)-(94.654)-(tcb->m_cWnd)-(84.622)-(12.725)-(69.589)-(mKddkcELvkYqAPKh));
	segmentsAcked = (int) (97.484-(88.054)-(38.351)-(27.765)-(cnt)-(47.406)-(19.892)-(58.373));

}
