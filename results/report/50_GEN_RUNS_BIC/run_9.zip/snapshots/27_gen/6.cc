tcb->m_segmentSize = (int) (10.983+(12.187)+(98.768)+(55.654)+(-36.642)+(8.777)+(-43.087)+(47.194)+(67.447));
segmentsAcked = (int) (((84.513)+(54.763)+(23.745)+(6.054))/((75.535)+(59.03)+(-70.319)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
