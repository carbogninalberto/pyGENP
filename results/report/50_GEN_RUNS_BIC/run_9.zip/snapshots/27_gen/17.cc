if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (((34.638)+(0.1)+(96.946)+(0.1))/((0.1)));
	cnt = (int) (tcb->m_segmentSize-(67.563));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(4.763));
	cnt = (int) (cnt*(tcb->m_segmentSize)*(segmentsAcked)*(cnt)*(64.413)*(86.873));
	tcb->m_cWnd = (int) (0.1/13.093);

}
if (cnt > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(6.471)-(42.739)-(tcb->m_segmentSize)-(58.66));
	tcb->m_segmentSize = (int) (cnt*(9.672)*(41.985)*(95.414)*(6.67)*(42.66)*(90.665)*(22.458)*(60.795));

} else {
	tcb->m_segmentSize = (int) (27.986+(cnt)+(22.35)+(6.343));
	tcb->m_segmentSize = (int) (6.666+(tcb->m_ssThresh)+(47.957)+(77.557));
	ReduceCwnd (tcb);

}
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (64.543+(93.897)+(41.782)+(49.938)+(55.805)+(61.692)+(25.87));

} else {
	tcb->m_ssThresh = (int) (((61.814)+(92.426)+(11.045)+(68.132))/((0.1)));
	segmentsAcked = (int) (70.189+(88.31)+(tcb->m_ssThresh)+(46.079)+(29.674)+(63.388)+(96.38)+(51.612));

}
int ljYyFEdkxquPkGyW = (int) (49.159-(5.068)-(63.114)-(75.316)-(40.754)-(41.907)-(65.46)-(66.817)-(61.894));
if (tcb->m_ssThresh <= ljYyFEdkxquPkGyW) {
	ljYyFEdkxquPkGyW = (int) (segmentsAcked+(35.617)+(9.31)+(74.956)+(10.634)+(31.293)+(60.924)+(6.209)+(42.726));
	tcb->m_cWnd = (int) (62.667-(90.984)-(58.499));

} else {
	ljYyFEdkxquPkGyW = (int) (8.224+(94.583)+(76.654)+(11.269)+(60.856)+(tcb->m_segmentSize)+(10.539)+(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (99.903*(81.433)*(90.917));

}
