if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (54.687-(tcb->m_segmentSize)-(98.312));

} else {
	tcb->m_ssThresh = (int) (0.1/61.14);
	tcb->m_ssThresh = (int) (29.768-(27.92)-(77.146)-(tcb->m_ssThresh)-(16.346)-(69.086));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (18.045*(70.266));

} else {
	tcb->m_cWnd = (int) (40.547-(92.208)-(9.677)-(0.963)-(tcb->m_segmentSize)-(43.543)-(91.886)-(68.863));
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((0.1)+(38.027)+(0.1)+(0.1))/((66.065)+(41.937)));

} else {
	tcb->m_segmentSize = (int) (33.155*(tcb->m_ssThresh)*(cnt)*(30.418)*(43.843)*(90.369)*(17.052)*(21.627)*(28.525));
	ReduceCwnd (tcb);
	cnt = (int) (32.492*(58.085)*(55.525)*(11.712));

}
tcb->m_segmentSize = (int) (94.791*(tcb->m_ssThresh)*(52.15));
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (12.147-(35.395));
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (68.049*(69.631)*(tcb->m_segmentSize)*(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (25.359-(cnt)-(23.897)-(segmentsAcked)-(77.637)-(90.718)-(98.244));
	tcb->m_segmentSize = (int) (55.573+(59.388));
	tcb->m_ssThresh = (int) (78.848*(49.098)*(76.678)*(36.377)*(tcb->m_ssThresh)*(95.323)*(tcb->m_cWnd));

}
if (tcb->m_ssThresh < cnt) {
	tcb->m_cWnd = (int) (4.393+(96.705)+(tcb->m_cWnd)+(98.529)+(50.739)+(82.326)+(91.109)+(87.072)+(31.268));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(53.721)+(56.643)+(37.169)+(7.942)+(4.641)+(56.362)+(69.867));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
