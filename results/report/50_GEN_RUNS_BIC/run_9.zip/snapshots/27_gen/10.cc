float JuSHzonVGteTiput = (float) (0.1/1.884);
if (segmentsAcked > cnt) {
	cnt = (int) (82.682+(32.575)+(25.822)+(85.599)+(93.161)+(88.479));
	segmentsAcked = (int) (76.037+(5.295)+(cnt)+(29.728)+(tcb->m_ssThresh)+(37.905)+(27.482)+(tcb->m_cWnd)+(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (91.393/53.382);

}
segmentsAcked = (int) (7.334-(17.817)-(17.317)-(13.766));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (87.394*(61.761)*(70.105)*(43.952)*(90.23)*(8.811));
