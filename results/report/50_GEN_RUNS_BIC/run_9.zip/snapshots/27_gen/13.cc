if (segmentsAcked >= segmentsAcked) {
	cnt = (int) (67.239*(75.748)*(tcb->m_ssThresh)*(74.671)*(tcb->m_cWnd));
	tcb->m_ssThresh = (int) ((39.237-(48.442)-(2.254)-(segmentsAcked)-(96.562))/0.1);

} else {
	cnt = (int) (96.79-(tcb->m_cWnd)-(85.102)-(segmentsAcked)-(25.981)-(5.875));
	tcb->m_ssThresh = (int) (59.342-(10.788)-(45.012));
	ReduceCwnd (tcb);

}
if (cnt <= segmentsAcked) {
	segmentsAcked = (int) (68.598-(16.781)-(0.855)-(5.489)-(66.476));
	tcb->m_cWnd = (int) (84.209-(99.761)-(45.163)-(10.822)-(46.251)-(37.767)-(9.324)-(46.825)-(49.811));

} else {
	segmentsAcked = (int) (56.727+(segmentsAcked)+(segmentsAcked)+(92.18)+(45.846)+(tcb->m_cWnd)+(79.606)+(40.766)+(9.34));

}
tcb->m_segmentSize = (int) (36.397/0.1);
segmentsAcked = (int) (24.15*(21.867)*(tcb->m_cWnd)*(81.194)*(72.437)*(38.483));
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(86.971)+(71.595))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (55.044-(97.759)-(24.117)-(80.557)-(66.098)-(75.646)-(23.695));
	cnt = (int) (74.065-(31.443)-(12.309)-(segmentsAcked)-(segmentsAcked)-(90.291)-(76.775)-(39.248));

}
tcb->m_ssThresh = (int) (41.598*(cnt)*(54.51)*(97.801)*(55.886)*(tcb->m_cWnd)*(91.455)*(42.617)*(31.337));
