if (cnt != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (segmentsAcked*(86.087)*(67.565)*(36.624)*(27.239));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (((0.1)+(33.164)+(0.1)+(0.1))/((0.1)));
	tcb->m_ssThresh = (int) (47.202+(14.515)+(tcb->m_ssThresh)+(63.687)+(41.622)+(tcb->m_cWnd)+(75.554));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize <= cnt) {
	tcb->m_ssThresh = (int) (cnt*(58.968));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(25.536)*(92.796)*(55.602)*(52.204)*(83.954)*(86.221)*(66.536));

}
if (tcb->m_ssThresh <= cnt) {
	segmentsAcked = (int) (22.01*(79.925)*(83.676)*(tcb->m_segmentSize)*(43.994)*(67.075)*(41.808)*(81.811));
	segmentsAcked = (int) (80.825+(53.365)+(58.407)+(21.735));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(37.928)+(7.354)+(17.319)+(38.63)+(23.412));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (25.767/(tcb->m_cWnd+(37.972)+(17.523)+(51.737)+(2.698)+(84.9)+(tcb->m_cWnd)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (0.1/14.558);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
