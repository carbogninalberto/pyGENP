ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(97.244)*(61.23));
if (tcb->m_ssThresh != cnt) {
	cnt = (int) (79.533+(42.038)+(79.883)+(9.336)+(25.649)+(18.37)+(tcb->m_ssThresh));

} else {
	cnt = (int) (19.338/0.1);
	tcb->m_cWnd = (int) (32.626-(93.67)-(segmentsAcked)-(41.663)-(64.978)-(36.705)-(tcb->m_segmentSize)-(99.929)-(segmentsAcked));

}
tcb->m_ssThresh = (int) (0.1/0.1);
int eYkdgoVcWcndPbbd = (int) (18.491-(2.178)-(16.967)-(74.187)-(20.689)-(76.55)-(7.701)-(tcb->m_segmentSize)-(tcb->m_ssThresh));
if (segmentsAcked >= segmentsAcked) {
	tcb->m_cWnd = (int) ((((66.55+(11.708)+(56.586)+(45.695)))+((95.029*(tcb->m_ssThresh)*(cnt)*(30.994)*(eYkdgoVcWcndPbbd)*(cnt)*(eYkdgoVcWcndPbbd)))+(0.1)+(53.678)+(78.094))/((18.357)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(91.976)*(tcb->m_cWnd)*(22.898)*(58.201)*(29.835)*(20.434)*(segmentsAcked));
	segmentsAcked = (int) (cnt+(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (eYkdgoVcWcndPbbd*(92.744)*(31.488)*(57.853)*(71.679)*(69.107)*(eYkdgoVcWcndPbbd));

}
if (eYkdgoVcWcndPbbd >= cnt) {
	tcb->m_cWnd = (int) (segmentsAcked*(0.334)*(1.439)*(tcb->m_ssThresh)*(44.912)*(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (34.467-(60.866)-(86.894)-(10.574)-(22.834));

}
