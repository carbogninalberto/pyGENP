if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int wuRcmJUHvPDfnZyf = (int) (30.908*(87.826)*(segmentsAcked)*(65.717)*(81.996)*(tcb->m_cWnd));
ReduceCwnd (tcb);
cnt = (int) (19.848-(70.875)-(wuRcmJUHvPDfnZyf)-(14.393)-(78.292)-(23.554));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (43.813+(87.116)+(92.518)+(84.207)+(wuRcmJUHvPDfnZyf)+(33.286));
int uTnmSSWROhZUuzBD = (int) (0.1/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
