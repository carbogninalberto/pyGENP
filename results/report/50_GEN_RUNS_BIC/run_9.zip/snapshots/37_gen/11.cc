float IdfirpLcXOORDXAm = (float) (tcb->m_cWnd+(84.994)+(50.178)+(76.677)+(24.276)+(70.544));
cnt = (int) (24.053-(28.353)-(11.578)-(68.903)-(27.437)-(78.087)-(1.74)-(29.926));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (65.195+(2.044)+(tcb->m_ssThresh)+(IdfirpLcXOORDXAm)+(7.37));
tcb->m_segmentSize = (int) (10.513*(82.595)*(32.502));
