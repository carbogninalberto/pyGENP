ReduceCwnd (tcb);
if (cnt == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_cWnd = (int) ((((62.002+(22.78)+(67.078)+(32.591)))+((85.534+(76.166)+(segmentsAcked)+(33.13)+(27.618)+(19.089)+(segmentsAcked)+(segmentsAcked)+(98.027)))+(53.819)+(96.611))/((0.1)));
	tcb->m_segmentSize = (int) ((53.786-(88.637)-(cnt)-(12.195)-(98.531)-(45.633)-(54.244)-(21.704))/0.1);

} else {
	tcb->m_segmentSize = (int) (28.493-(27.639)-(19.73)-(20.35)-(12.347)-(9.605)-(44.821)-(39.958));
	cnt = (int) (4.732-(86.305)-(64.758)-(10.682)-(53.899)-(5.037)-(14.291)-(70.249)-(73.177));

}
tcb->m_cWnd = (int) (tcb->m_ssThresh-(tcb->m_cWnd));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh >= cnt) {
	cnt = (int) (50.194+(tcb->m_cWnd)+(33.952)+(77.844)+(81.597)+(77.873));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (46.47-(54.695)-(91.258)-(7.969)-(49.595)-(36.484)-(70.849)-(80.205)-(75.863));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
