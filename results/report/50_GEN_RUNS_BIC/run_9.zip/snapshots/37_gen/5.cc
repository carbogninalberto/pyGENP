if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (69.722-(35.147)-(tcb->m_cWnd)-(41.188)-(tcb->m_segmentSize));
	cnt = (int) (36.867+(86.363)+(cnt)+(37.106)+(cnt));

} else {
	segmentsAcked = (int) (19.545-(29.67));

}
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (96.301-(9.469)-(99.091)-(1.349)-(tcb->m_cWnd)-(36.785));
	tcb->m_cWnd = (int) (tcb->m_cWnd*(16.147));

} else {
	tcb->m_ssThresh = (int) (86.434*(cnt)*(cnt)*(29.413)*(37.883)*(78.821)*(73.821));
	tcb->m_cWnd = (int) (((0.1)+(26.93)+(0.1)+(0.1))/((18.849)+(0.1)+(51.457)+(0.1)+(0.1)));
	tcb->m_ssThresh = (int) (2.206*(29.861)*(67.474)*(69.381)*(46.707)*(34.354)*(tcb->m_segmentSize)*(13.913)*(63.203));

}
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (81.719+(19.453)+(39.866));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (16.503/0.1);

}
if (cnt < tcb->m_segmentSize) {
	cnt = (int) ((69.584*(tcb->m_cWnd)*(tcb->m_cWnd)*(76.427)*(9.716)*(tcb->m_segmentSize)*(1.695))/(81.017+(12.34)+(tcb->m_ssThresh)+(62.17)+(74.714)+(89.282)+(89.927)+(21.775)));
	tcb->m_ssThresh = (int) (46.574-(tcb->m_segmentSize)-(3.493)-(42.381)-(94.912));

} else {
	cnt = (int) (segmentsAcked+(34.724));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (70.337-(6.449)-(20.834)-(57.293)-(24.332)-(9.821)-(37.875)-(16.621));

}
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (57.702-(75.559)-(63.377)-(tcb->m_segmentSize)-(cnt)-(82.087)-(21.183));

} else {
	tcb->m_segmentSize = (int) (1.643*(0.783)*(1.13)*(25.779)*(cnt)*(65.288)*(22.481));

}
