if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (segmentsAcked+(61.832)+(32.276));

} else {
	tcb->m_ssThresh = (int) (97.194-(47.748));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (tcb->m_cWnd*(84.376)*(83.821)*(tcb->m_ssThresh)*(28.785)*(42.522));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
