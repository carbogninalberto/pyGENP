segmentsAcked = (int) (76.215/(tcb->m_segmentSize*(48.563)*(31.572)*(49.653)*(74.001)*(68.745)*(segmentsAcked)*(68.973)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= segmentsAcked) {
	tcb->m_cWnd = (int) (93.069*(tcb->m_ssThresh)*(3.95)*(27.268)*(49.568)*(73.974)*(19.674)*(13.473));

} else {
	tcb->m_cWnd = (int) (68.511*(tcb->m_cWnd)*(24.351));
	cnt = (int) (18.891*(94.807)*(1.676)*(77.337)*(88.02)*(33.054)*(cnt));
	segmentsAcked = (int) (((40.676)+(7.315)+(0.1)+(0.1))/((29.451)+(0.1)+(82.662)));

}
tcb->m_cWnd = (int) (3.973-(segmentsAcked)-(tcb->m_cWnd)-(segmentsAcked)-(2.294)-(tcb->m_segmentSize)-(5.555)-(5.917));
tcb->m_segmentSize = (int) (85.488*(90.507)*(50.585));
tcb->m_cWnd = (int) (48.657/75.582);
tcb->m_cWnd = (int) (tcb->m_segmentSize-(71.57)-(39.135));
