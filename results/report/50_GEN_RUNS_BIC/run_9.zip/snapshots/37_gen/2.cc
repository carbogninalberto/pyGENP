if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (39.542-(92.274)-(93.018)-(75.677)-(70.196)-(76.234));

} else {
	tcb->m_segmentSize = (int) (66.685-(61.825)-(17.078)-(5.536));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
int YsrntFvmiLqhcTrP = (int) 89.948;
