if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	cnt = (int) (80.867-(40.484)-(tcb->m_segmentSize)-(92.174)-(54.16)-(12.325)-(88.152)-(54.421)-(75.006));
	cnt = (int) (74.679-(60.862)-(8.44));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(tcb->m_ssThresh)-(95.444)-(43.785)-(40.52));
	ReduceCwnd (tcb);
	cnt = (int) (83.254-(28.646)-(75.171)-(tcb->m_segmentSize)-(78.87)-(50.253)-(65.805)-(21.246)-(55.208));

} else {
	tcb->m_segmentSize = (int) (((54.466)+(0.1)+((17.338+(26.503)+(41.543)+(74.643)+(cnt)+(97.502)+(20.459)))+(94.135)+(41.216)+(36.213))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (90.701*(46.289)*(34.269)*(segmentsAcked));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
