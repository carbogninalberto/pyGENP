tcb->m_cWnd = (int) (26.793/36.649);
if (tcb->m_ssThresh < cnt) {
	tcb->m_segmentSize = (int) (27.698-(tcb->m_segmentSize)-(80.35)-(tcb->m_cWnd)-(26.521)-(73.673)-(77.781)-(62.152));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked-(35.137)-(23.466));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize > segmentsAcked) {
	cnt = (int) (0.1/53.439);
	tcb->m_ssThresh = (int) (38.043-(19.392));
	ReduceCwnd (tcb);

} else {
	cnt = (int) ((cnt*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(39.154))/0.1);

}
segmentsAcked = (int) (67.034/0.1);
