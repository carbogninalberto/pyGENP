segmentsAcked = (int) (96.596/-2.134);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
