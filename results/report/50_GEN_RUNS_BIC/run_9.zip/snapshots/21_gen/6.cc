if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-96.005+(-4.87)+(-94.386)+(61.414)+(-61.86)+(4.0)+(-93.028));
