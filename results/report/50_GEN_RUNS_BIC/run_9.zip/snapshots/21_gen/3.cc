if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int hfmWmzRjDmmAtCpJ = (int) 80.953;
if (segmentsAcked == tcb->m_segmentSize) {
	hfmWmzRjDmmAtCpJ = (int) (segmentsAcked*(36.466)*(73.223));
	hfmWmzRjDmmAtCpJ = (int) (57.26-(91.024)-(25.798)-(73.274));

} else {
	hfmWmzRjDmmAtCpJ = (int) (13.201+(32.983)+(84.265)+(5.326)+(-97.972)+(65.755)+(84.575)+(54.734)+(39.281));

}
