ReduceCwnd (tcb);
if (cnt >= segmentsAcked) {
	segmentsAcked = (int) (62.438+(21.273));
	tcb->m_segmentSize = (int) ((((2.217*(tcb->m_cWnd)*(segmentsAcked)*(6.11)*(tcb->m_segmentSize)*(cnt)*(84.525)*(87.308)*(90.317)))+(47.449)+((9.104*(30.897)*(95.458)*(48.5)*(10.046)*(35.736)*(93.129)))+((76.094+(58.566)+(5.011)+(segmentsAcked)+(52.398)+(segmentsAcked)+(39.46)+(78.073)))+(0.1)+(0.1)+((tcb->m_ssThresh*(94.052)*(61.716)*(88.401)*(86.833)*(69.585)*(90.563)))+(0.1))/((0.1)));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (15.009+(90.152)+(72.411)+(segmentsAcked)+(tcb->m_cWnd)+(63.184)+(96.045)+(53.281));
	tcb->m_cWnd = (int) (18.015*(36.601)*(90.217)*(cnt)*(86.659)*(27.238)*(67.89)*(11.151)*(17.144));
	tcb->m_ssThresh = (int) (92.486*(18.258)*(58.853)*(90.774)*(56.255)*(cnt));

}
segmentsAcked = (int) (35.287+(95.381)+(10.171)+(tcb->m_ssThresh));
float PtPyiMHVRSUDqchH = (float) ((((37.926*(cnt)*(tcb->m_segmentSize)*(55.572)*(1.512)*(37.031)))+(72.678)+(15.95)+((12.781+(97.884)+(86.76)+(70.018)+(59.761)+(segmentsAcked)+(tcb->m_ssThresh)))+(0.1)+(0.1)+(85.258))/((0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= tcb->m_cWnd) {
	cnt = (int) (52.449-(80.236)-(87.686)-(cnt)-(71.063)-(cnt)-(tcb->m_segmentSize)-(84.552)-(11.654));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (48.657-(75.233)-(PtPyiMHVRSUDqchH)-(59.524)-(45.138)-(90.061));

} else {
	cnt = (int) (26.268+(79.909)+(26.092)+(94.465)+(96.267)+(99.121));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < tcb->m_ssThresh) {
	PtPyiMHVRSUDqchH = (float) ((65.906-(69.855)-(7.313)-(PtPyiMHVRSUDqchH)-(11.089))/16.573);
	cnt = (int) ((56.884*(tcb->m_segmentSize)*(29.776)*(29.117)*(31.158)*(17.803)*(63.024)*(cnt)*(tcb->m_segmentSize))/6.819);

} else {
	PtPyiMHVRSUDqchH = (float) (segmentsAcked+(39.799)+(tcb->m_segmentSize)+(11.364)+(16.524)+(1.769)+(45.65)+(24.436)+(17.927));

}
