float EyfSeBfNEIBNOOgi = (float) 0.993;
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (87.647-(-57.533));
ReduceCwnd (tcb);
segmentsAcked = (int) (-14.782*(3.455)*(59.599)*(12.366)*(38.018));
EyfSeBfNEIBNOOgi = (float) (16.185+(-9.515)+(80.439)+(3.71));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (22.118*(-60.47)*(7.981)*(34.111)*(-57.802));
EyfSeBfNEIBNOOgi = (float) (-99.309+(-55.105)+(-15.926)+(-69.874));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
EyfSeBfNEIBNOOgi = (float) (-57.154+(69.52)+(-85.203)+(38.43));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
