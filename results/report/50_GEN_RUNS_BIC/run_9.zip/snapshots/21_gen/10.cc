segmentsAcked = (int) (-72.096-(5.032)-(6.997)-(66.647)-(42.856)-(-50.478)-(6.514)-(75.152));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-36.127-(-78.315)-(-88.568)-(-93.318)-(41.179));
segmentsAcked = (int) (-98.231-(45.815)-(-74.13)-(-57.412)-(-34.844));
