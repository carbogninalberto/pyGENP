tcb->m_cWnd = (int) (cnt*(52.949)*(cnt)*(18.305));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (80.419+(18.798)+(61.769)+(37.069)+(0.585)+(7.474)+(tcb->m_cWnd));
tcb->m_segmentSize = (int) (13.181-(76.303));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
