segmentsAcked = (int) (-39.392/10.514);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
