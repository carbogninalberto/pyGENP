if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (93.262/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (60.163-(tcb->m_ssThresh)-(30.876)-(78.922));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
cnt = (int) (95.933-(cnt)-(87.604)-(11.125)-(41.407)-(tcb->m_ssThresh)-(43.682)-(tcb->m_cWnd)-(43.044));
ReduceCwnd (tcb);
