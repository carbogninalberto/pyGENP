segmentsAcked = (int) (-35.569/-17.93);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
