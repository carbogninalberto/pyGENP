ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
float YDsVhWzamjLrHYCG = (float) (80.981-(15.743)-(19.433));
tcb->m_ssThresh = (int) (32.288-(94.171)-(87.19)-(77.761)-(segmentsAcked)-(49.624)-(YDsVhWzamjLrHYCG)-(4.156));
cnt = (int) (71.136+(46.246)+(40.916)+(25.39)+(39.761));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
