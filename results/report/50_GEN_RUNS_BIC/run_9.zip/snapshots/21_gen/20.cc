float ClGjtaIlxCcHMaGr = (float) (cnt*(99.605)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(63.883)*(67.284)*(tcb->m_segmentSize));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float rfxZNFAkkrfDsMKZ = (float) (ClGjtaIlxCcHMaGr+(cnt)+(tcb->m_ssThresh));
int oMYIoVrnYuVgTXkz = (int) (68.933*(86.598)*(10.585)*(68.932)*(31.519)*(rfxZNFAkkrfDsMKZ)*(rfxZNFAkkrfDsMKZ)*(38.342));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int EwCPRaJzZXVYOids = (int) (63.819/74.847);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > tcb->m_segmentSize) {
	ClGjtaIlxCcHMaGr = (float) (30.881*(85.385)*(8.593));
	oMYIoVrnYuVgTXkz = (int) (tcb->m_cWnd+(81.28)+(25.035)+(70.716)+(40.505));

} else {
	ClGjtaIlxCcHMaGr = (float) (18.463*(10.235)*(6.338)*(tcb->m_segmentSize)*(65.103));

}
ReduceCwnd (tcb);
