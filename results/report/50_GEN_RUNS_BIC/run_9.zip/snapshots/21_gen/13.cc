ReduceCwnd (tcb);
float EyfSeBfNEIBNOOgi = (float) 96.303;
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-62.191-(-23.083));
ReduceCwnd (tcb);
EyfSeBfNEIBNOOgi = (float) (-81.93+(23.055)+(2.593)+(-96.023));
segmentsAcked = (int) (-43.524*(-79.26)*(-71.924)*(-83.861)*(-12.998));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
EyfSeBfNEIBNOOgi = (float) (34.812+(-85.291)+(-13.128)+(54.578));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-43.244-(87.852));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
EyfSeBfNEIBNOOgi = (float) (-87.393+(25.827)+(-16.745)+(-79.493));
segmentsAcked = (int) (-65.04*(-82.262)*(34.074)*(-12.665)*(-94.569));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
EyfSeBfNEIBNOOgi = (float) (0.902+(-2.841)+(71.097)+(69.547));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
