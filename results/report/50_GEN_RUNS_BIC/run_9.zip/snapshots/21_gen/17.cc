tcb->m_segmentSize = (int) (2.296-(84.159)-(69.134)-(tcb->m_segmentSize)-(29.419)-(34.218)-(71.762)-(16.548));
tcb->m_ssThresh = (int) (10.519+(44.095)+(22.154)+(tcb->m_ssThresh)+(43.924)+(62.829));
ReduceCwnd (tcb);
if (segmentsAcked != segmentsAcked) {
	tcb->m_ssThresh = (int) (69.129+(6.654)+(tcb->m_cWnd)+(30.637)+(50.355));

} else {
	tcb->m_ssThresh = (int) (33.581-(tcb->m_ssThresh)-(77.563)-(69.714)-(85.247)-(87.349)-(91.435));
	cnt = (int) (98.356-(54.325)-(80.795)-(33.155)-(cnt)-(79.448)-(tcb->m_cWnd));

}
int gvziaGwRfmSTdKfr = (int) (46.387+(52.396)+(tcb->m_segmentSize));
if (segmentsAcked <= segmentsAcked) {
	cnt = (int) (((81.436)+((55.617*(39.547)*(73.411)*(56.07)*(segmentsAcked)))+(0.1)+(98.92))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (tcb->m_ssThresh*(3.375)*(95.066)*(67.734)*(14.172));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize <= gvziaGwRfmSTdKfr) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(27.028)-(78.884)-(96.952)-(77.711)-(72.03)-(55.914)-(4.211)-(87.843));

} else {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(48.736)+(0.1)+(0.1))/((0.1)));
	segmentsAcked = (int) (0.1/56.042);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_cWnd = (int) (0.1/30.182);
