cnt = (int) (14.034/0.1);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (95.656+(33.728)+(24.464)+(86.328)+(42.113)+(75.542));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int GgQprAeuoJojTkQj = (int) (((0.1)+((45.462*(69.89)*(segmentsAcked)*(38.361)))+((15.791-(0.915)-(6.948)-(97.541)))+(0.1)+(0.1)+(52.045)+(47.044))/((2.464)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
