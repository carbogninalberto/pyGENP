float EyfSeBfNEIBNOOgi = (float) 18.119;
ReduceCwnd (tcb);
ReduceCwnd (tcb);
EyfSeBfNEIBNOOgi = (float) (-39.408+(-71.217)+(-53.845)+(59.392));
tcb->m_cWnd = (int) (-57.785-(42.903));
segmentsAcked = (int) (-96.73*(17.43)*(36.406)*(44.499)*(40.253));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
EyfSeBfNEIBNOOgi = (float) (34.528+(17.153)+(-15.368)+(-3.08));
EyfSeBfNEIBNOOgi = (float) (92.457+(-80.436)+(52.011)+(-70.732));
segmentsAcked = (int) (-63.439*(89.866)*(-1.826)*(-72.108)*(8.776));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
EyfSeBfNEIBNOOgi = (float) (-27.763+(7.057)+(8.09)+(66.681));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
