int dhtjcjFumrvykUDB = (int) (-62.037*(93.169)*(-68.607)*(14.748)*(72.503)*(97.711)*(23.303)*(-72.71)*(-27.068));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-27.514+(-22.588)+(27.025)+(75.782)+(89.907)+(-85.612)+(19.458));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (55.678+(-17.777)+(-76.395)+(-47.931)+(26.666)+(-69.442)+(3.359));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
