tcb->m_cWnd = (int) (23.364/0.1);
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((0.1)+(84.771)+(54.245)+(91.72)+(0.1)+(0.1))/((17.299)));
	cnt = (int) (95.342+(57.792)+(31.142)+(41.499));
	cnt = (int) (tcb->m_ssThresh+(cnt)+(76.798)+(10.068)+(tcb->m_cWnd)+(94.953)+(94.816)+(60.108)+(31.647));

} else {
	tcb->m_segmentSize = (int) (60.331/6.586);
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(82.864)+(0.1)+(0.1)+(0.1)+(0.1)+(90.713))/((0.1)));
	tcb->m_cWnd = (int) (36.307+(tcb->m_segmentSize)+(80.472)+(55.225)+(75.231)+(60.469)+(79.914)+(24.098)+(86.65));

}
tcb->m_cWnd = (int) (64.82+(53.736)+(65.417)+(28.873)+(15.535)+(segmentsAcked)+(tcb->m_segmentSize)+(cnt));
if (tcb->m_cWnd != tcb->m_cWnd) {
	segmentsAcked = (int) (16.943*(10.233)*(segmentsAcked)*(49.803)*(89.627)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (37.474+(46.695)+(segmentsAcked)+(12.523));

} else {
	segmentsAcked = (int) (0.1/53.662);
	tcb->m_segmentSize = (int) (28.359-(tcb->m_segmentSize)-(81.303)-(tcb->m_segmentSize)-(cnt)-(72.687)-(segmentsAcked)-(tcb->m_cWnd));

}
segmentsAcked = (int) ((cnt*(14.965)*(64.655)*(14.629))/0.1);
