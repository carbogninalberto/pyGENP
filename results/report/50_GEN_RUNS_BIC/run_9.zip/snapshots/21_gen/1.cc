float EyfSeBfNEIBNOOgi = (float) ((94.566+(-95.81)+(-88.27)+(-83.948)+(93.012))/17.678);
