segmentsAcked = (int) (46.874/-85.938);
segmentsAcked = (int) (-6.261/7.961);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
