ReduceCwnd (tcb);
segmentsAcked = (int) (((80.204)+(44.989)+(0.1)+(0.1))/((8.017)+(94.295)+(10.852)+(56.568)));
if (tcb->m_cWnd < cnt) {
	tcb->m_cWnd = (int) (((63.094)+(0.1)+((68.52*(10.885)))+(0.1))/((89.076)));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (15.334*(20.391)*(55.467)*(48.354)*(10.537)*(23.577)*(5.24)*(81.102)*(49.907));

} else {
	tcb->m_cWnd = (int) (71.247-(6.485)-(45.951)-(58.54)-(68.489)-(68.968)-(90.645)-(0.372));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) (tcb->m_ssThresh*(91.369)*(87.277)*(65.777)*(75.156)*(76.801));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh*(tcb->m_ssThresh)*(80.696)*(57.822)*(99.294)*(tcb->m_ssThresh));

}
