if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (87.779+(88.472)+(97.836)+(-33.203)+(-11.351)+(28.899)+(-97.985)+(26.163)+(-41.594));
tcb->m_segmentSize = (int) (36.332+(-85.471)+(-69.491)+(-86.44)+(70.69)+(-37.668)+(-14.122)+(36.889)+(8.808));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (72.43+(58.974)+(32.619)+(93.407)+(-85.919)+(-14.501)+(-97.909)+(92.795)+(-36.385));
tcb->m_segmentSize = (int) (-18.054+(29.879)+(27.265)+(-69.971)+(-90.985)+(-69.112)+(-16.914)+(-40.325)+(17.434));
