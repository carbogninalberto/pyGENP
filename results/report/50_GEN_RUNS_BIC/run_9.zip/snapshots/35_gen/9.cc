if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (14.401+(16.059)+(segmentsAcked)+(97.93)+(92.753)+(92.627)+(tcb->m_segmentSize)+(81.378));
	cnt = (int) (cnt-(40.17));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (21.733*(89.227)*(88.963)*(98.404)*(57.161)*(tcb->m_cWnd)*(17.859)*(3.551));
	segmentsAcked = (int) (53.75+(tcb->m_ssThresh));

}
int jwXsfqnYGaCAexgp = (int) (48.723+(93.343)+(47.169)+(19.194)+(tcb->m_cWnd)+(14.369)+(tcb->m_segmentSize)+(46.255)+(4.887));
if (jwXsfqnYGaCAexgp >= cnt) {
	tcb->m_cWnd = (int) (24.162/0.1);
	jwXsfqnYGaCAexgp = (int) (49.318+(4.457)+(51.055)+(tcb->m_ssThresh)+(34.545)+(32.188)+(45.062));

} else {
	tcb->m_cWnd = (int) (71.937+(cnt));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize >= cnt) {
	tcb->m_segmentSize = (int) (16.071-(8.139)-(51.697)-(tcb->m_ssThresh)-(10.533));

} else {
	tcb->m_segmentSize = (int) (20.237+(46.011)+(19.34)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (62.622-(87.504)-(67.272)-(cnt)-(97.368)-(27.103)-(52.85));
	tcb->m_segmentSize = (int) (84.112+(tcb->m_cWnd)+(66.426)+(jwXsfqnYGaCAexgp)+(58.982)+(33.92)+(23.912)+(cnt)+(72.366));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
