if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (33.26+(35.642)+(95.7)+(61.017)+(76.101));
	tcb->m_ssThresh = (int) (23.7-(cnt)-(tcb->m_segmentSize)-(cnt)-(47.017)-(14.445));

} else {
	tcb->m_ssThresh = (int) (cnt-(87.701));
	cnt = (int) (46.624-(19.883)-(92.656)-(80.046));
	tcb->m_cWnd = (int) (cnt*(54.687)*(52.359));

}
tcb->m_cWnd = (int) (0.1/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(11.086)+(81.826)+(90.78)+(92.302)+(36.963)+(4.766)+(55.419)+(tcb->m_segmentSize));
