tcb->m_segmentSize = (int) (51.377*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(22.274)*(30.231)*(segmentsAcked)*(43.535));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (15.251-(38.554)-(segmentsAcked)-(73.626)-(41.04)-(95.526));
int RRLJeyAhEgpRStxf = (int) (((0.1)+((tcb->m_ssThresh-(segmentsAcked)-(73.55)-(6.74)-(22.387)-(tcb->m_cWnd)))+(67.317)+((56.577*(tcb->m_segmentSize)*(tcb->m_cWnd)*(86.27)*(60.531)*(tcb->m_ssThresh)))+(0.1)+(0.1)+(0.1))/((30.23)));
tcb->m_cWnd = (int) (17.045*(55.431)*(segmentsAcked)*(63.688)*(tcb->m_cWnd)*(6.216)*(43.359)*(98.746)*(46.701));
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((60.641)+(90.676)+(25.698)+(43.043)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (40.49-(77.104)-(68.398)-(6.127)-(57.2));
	ReduceCwnd (tcb);
	RRLJeyAhEgpRStxf = (int) (94.337*(49.869)*(98.879)*(cnt)*(34.468));

}
tcb->m_segmentSize = (int) (83.412-(78.341)-(14.063));
ReduceCwnd (tcb);
