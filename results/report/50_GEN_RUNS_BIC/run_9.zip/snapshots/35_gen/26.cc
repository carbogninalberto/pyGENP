if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (69.844*(98.03)*(84.634)*(43.616));
if (tcb->m_segmentSize == cnt) {
	tcb->m_cWnd = (int) (2.586*(16.975)*(86.728)*(cnt)*(tcb->m_segmentSize)*(79.033)*(tcb->m_cWnd)*(83.645));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (78.693+(11.314)+(32.87)+(98.538));

} else {
	tcb->m_cWnd = (int) (49.193*(52.214)*(tcb->m_ssThresh)*(30.761)*(19.888)*(17.153)*(tcb->m_segmentSize));
	cnt = (int) (tcb->m_segmentSize*(43.823));
	tcb->m_cWnd = (int) (47.694+(26.83)+(4.457)+(16.202)+(9.944)+(tcb->m_ssThresh)+(94.408)+(cnt));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (44.382-(27.656)-(tcb->m_cWnd)-(46.478)-(95.729)-(cnt)-(40.793)-(9.587)-(25.757));
