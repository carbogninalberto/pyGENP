tcb->m_ssThresh = (int) (86.418+(81.653)+(7.031)+(44.161)+(94.552));
ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_cWnd) {
	segmentsAcked = (int) (37.139/0.1);
	tcb->m_ssThresh = (int) (9.521*(tcb->m_segmentSize)*(74.112)*(63.251)*(42.523)*(segmentsAcked)*(99.78)*(30.153)*(33.221));
	tcb->m_ssThresh = (int) (3.701/0.1);

} else {
	segmentsAcked = (int) (83.924/0.1);
	tcb->m_ssThresh = (int) ((38.258*(60.505))/(11.231+(tcb->m_ssThresh)+(90.418)+(90.814)+(93.11)+(tcb->m_ssThresh)+(17.376)+(cnt)+(10.414)));
	tcb->m_segmentSize = (int) ((25.398*(26.517)*(segmentsAcked)*(29.014)*(20.278))/36.266);

}
float XgWfkjJDtKxBgLCR = (float) (55.153+(segmentsAcked)+(57.922)+(11.675)+(16.59)+(33.285)+(28.476)+(35.865)+(86.836));
int qNSRejQiiNBgRkGk = (int) (segmentsAcked-(49.224)-(82.081)-(53.192)-(5.061)-(91.965)-(54.526));
