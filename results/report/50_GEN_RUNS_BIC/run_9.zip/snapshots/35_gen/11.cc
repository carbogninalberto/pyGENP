if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_ssThresh = (int) (99.844-(15.734)-(19.183)-(63.606)-(cnt)-(75.223));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (96.803*(5.093)*(57.074)*(14.629)*(73.526)*(tcb->m_cWnd)*(3.393)*(30.279)*(45.74));
	segmentsAcked = (int) (0.1/52.74);

}
tcb->m_cWnd = (int) (7.415+(83.699));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
