if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-48.497+(82.202)+(-52.7)+(-24.01)+(-15.145)+(-40.053)+(-88.862)+(61.415)+(38.896));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (66.946+(4.277)+(-21.558)+(54.232)+(72.18)+(31.865)+(9.092)+(-52.779)+(-40.194));
