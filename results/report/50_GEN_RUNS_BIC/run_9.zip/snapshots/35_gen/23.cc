if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	cnt = (int) (82.85-(tcb->m_segmentSize)-(96.613)-(7.586));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (86.703+(34.293)+(73.502)+(77.547)+(10.693));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (28.481/0.1);
	cnt = (int) (14.118-(tcb->m_ssThresh)-(90.205)-(segmentsAcked)-(35.573)-(67.339));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (7.212-(45.87)-(38.697)-(44.801)-(50.495)-(31.565));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == cnt) {
	tcb->m_cWnd = (int) (segmentsAcked-(76.746)-(9.108)-(cnt)-(31.858)-(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (segmentsAcked-(53.774)-(80.998)-(99.725)-(segmentsAcked)-(14.412)-(72.888)-(50.468)-(96.686));

} else {
	tcb->m_cWnd = (int) (71.145*(54.511)*(47.256)*(37.61));
	tcb->m_ssThresh = (int) (5.43*(tcb->m_ssThresh)*(91.017));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(86.644)-(33.081)-(tcb->m_cWnd)-(26.171)-(72.674)-(6.727)-(27.972));

}
if (cnt == cnt) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(63.353)+(71.251));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (87.456-(98.953)-(cnt));

} else {
	tcb->m_ssThresh = (int) (7.812-(47.232)-(76.533)-(69.748)-(cnt)-(10.349)-(75.071)-(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (72.148+(91.178)+(42.447)+(88.939)+(tcb->m_cWnd)+(71.07)+(cnt));
