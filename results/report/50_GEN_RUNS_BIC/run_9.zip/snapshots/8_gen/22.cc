segmentsAcked = (int) (64.848/35.727);
