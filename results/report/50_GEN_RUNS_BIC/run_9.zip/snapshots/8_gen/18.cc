tcb->m_segmentSize = (int) (-99.149-(67.844)-(52.025)-(-60.35)-(97.056)-(-89.684)-(47.812)-(-6.79));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
