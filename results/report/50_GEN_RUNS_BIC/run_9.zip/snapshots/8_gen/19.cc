float WlZdmdhqTBjGcyVO = (float) (-58.845*(48.823)*(60.084)*(89.363)*(98.028)*(-12.665));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (((-24.828)+(-9.198)+(-67.233)+((tcb->m_segmentSize*(segmentsAcked)*(-81.732)*(27.606)))+(-25.917)+(25.147))/((-11.208)));
WlZdmdhqTBjGcyVO = (float) (-77.322*(-50.574)*(0.215)*(-58.306)*(-65.413));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked <= WlZdmdhqTBjGcyVO) {
	WlZdmdhqTBjGcyVO = (float) (99.556-(2.067)-(48.68)-(32.134));

} else {
	WlZdmdhqTBjGcyVO = (float) (81.504*(57.868)*(60.543)*(77.31)*(80.118)*(-39.456)*(8.055)*(3.787)*(segmentsAcked));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
