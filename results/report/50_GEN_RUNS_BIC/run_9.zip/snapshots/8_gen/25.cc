float gEuRfKLpWXheIHVy = (float) (46.172*(-9.157)*(70.509)*(41.621)*(38.006));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
