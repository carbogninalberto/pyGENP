segmentsAcked = (int) (99.596*(90.046)*(-49.656));
