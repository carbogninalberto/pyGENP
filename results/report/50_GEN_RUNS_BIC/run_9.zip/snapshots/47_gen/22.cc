if (tcb->m_segmentSize == tcb->m_segmentSize) {
	cnt = (int) (76.743*(26.58)*(69.047)*(87.738)*(14.974)*(cnt)*(74.261));

} else {
	cnt = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (7.573+(25.053)+(tcb->m_cWnd)+(93.766));

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (73.958/0.1);
segmentsAcked = (int) ((((cnt+(37.858)+(70.176)+(68.58)+(tcb->m_ssThresh)+(13.509)))+(52.467)+(0.1)+(52.023))/((19.161)));
ReduceCwnd (tcb);
