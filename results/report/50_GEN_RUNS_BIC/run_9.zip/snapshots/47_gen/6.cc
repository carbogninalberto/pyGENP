tcb->m_cWnd = (int) (33.781+(38.897)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(77.049)+(39.467)+(18.578)+(91.98)+(tcb->m_segmentSize));
segmentsAcked = (int) (tcb->m_ssThresh*(tcb->m_segmentSize)*(3.601)*(tcb->m_segmentSize)*(45.38));
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	segmentsAcked = (int) (0.1/75.282);
	tcb->m_segmentSize = (int) (61.026-(69.163)-(21.091)-(14.988)-(28.648)-(28.752)-(31.795)-(99.175));

} else {
	segmentsAcked = (int) (cnt*(segmentsAcked)*(71.543)*(15.734)*(49.769));

}
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_segmentSize = (int) (11.924-(1.15)-(16.339)-(38.272)-(53.435)-(cnt));
	segmentsAcked = (int) (78.396*(97.826)*(35.426)*(70.606)*(91.071)*(82.614)*(75.799)*(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (55.011*(98.228)*(96.287)*(84.861)*(65.824)*(31.216)*(78.521)*(59.137));

}
ReduceCwnd (tcb);
