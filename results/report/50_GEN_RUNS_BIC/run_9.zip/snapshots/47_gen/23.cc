if (tcb->m_ssThresh > cnt) {
	tcb->m_cWnd = (int) (0.1/4.028);
	tcb->m_cWnd = (int) (74.752+(48.871)+(tcb->m_segmentSize)+(54.555)+(65.161)+(49.327)+(62.097)+(79.613)+(10.108));
	cnt = (int) (segmentsAcked+(37.261)+(50.716));

} else {
	tcb->m_cWnd = (int) (18.061+(12.39)+(55.914));

}
cnt = (int) (27.203*(21.811)*(24.856)*(cnt)*(45.567)*(27.501)*(37.849)*(23.414)*(32.162));
if (segmentsAcked > tcb->m_segmentSize) {
	segmentsAcked = (int) (98.467*(67.411)*(47.508)*(65.658)*(tcb->m_ssThresh)*(84.261));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (90.367-(71.248));

} else {
	segmentsAcked = (int) (((85.84)+(0.1)+(0.1)+(50.04))/((77.995)+(0.1)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
