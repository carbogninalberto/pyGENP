tcb->m_segmentSize = (int) (((0.1)+((cnt*(29.567)*(20.343)*(tcb->m_ssThresh)*(11.964)*(65.391)*(69.547)*(65.243)))+(7.797)+(0.1)+(0.1))/((0.1)+(26.373)));
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (16.477+(77.732)+(42.61)+(94.577)+(2.772)+(73.338)+(tcb->m_ssThresh)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (37.386+(47.453));

} else {
	tcb->m_cWnd = (int) (53.423-(tcb->m_ssThresh)-(4.251)-(63.251)-(33.061));
	tcb->m_cWnd = (int) (23.741-(tcb->m_cWnd)-(79.324)-(40.594)-(34.859)-(91.411)-(31.943));

}
cnt = (int) (0.1/26.671);
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (76.486*(segmentsAcked)*(62.964)*(tcb->m_ssThresh)*(71.048)*(tcb->m_cWnd)*(29.892)*(96.426));
	cnt = (int) (87.205+(10.973)+(26.702)+(67.242)+(14.285)+(88.534)+(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (((41.312)+(0.1)+(0.1)+(0.1)+(93.527)+(0.1))/((0.1)+(10.718)));

} else {
	tcb->m_cWnd = (int) (96.302-(48.39)-(tcb->m_segmentSize)-(88.514)-(45.736)-(19.139)-(22.904)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (94.196*(82.708)*(58.945)*(21.484)*(98.265)*(63.543)*(17.144)*(27.821)*(segmentsAcked));
	tcb->m_segmentSize = (int) (segmentsAcked+(47.021)+(86.591)+(45.071));

}
if (tcb->m_segmentSize > cnt) {
	tcb->m_ssThresh = (int) (61.467-(29.665));
	tcb->m_ssThresh = (int) (3.505-(25.141)-(83.507)-(tcb->m_ssThresh)-(49.559)-(90.517)-(92.003)-(8.328)-(10.032));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(cnt)-(tcb->m_segmentSize)-(45.766));

} else {
	tcb->m_ssThresh = (int) (71.287+(tcb->m_cWnd)+(8.566)+(tcb->m_segmentSize)+(5.224)+(tcb->m_cWnd)+(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (34.296-(86.484)-(23.07)-(tcb->m_ssThresh)-(20.488)-(54.498)-(55.865));
ReduceCwnd (tcb);
