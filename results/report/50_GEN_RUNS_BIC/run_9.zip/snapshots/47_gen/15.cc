int YiqjLkdLkMPpRVbZ = (int) (tcb->m_cWnd+(26.503)+(78.979)+(91.681)+(74.717));
float RhMbYlkfVQTboioF = (float) (tcb->m_segmentSize-(11.455)-(80.995)-(87.897)-(69.463)-(38.26));
int wkSFDAbgggDMANWv = (int) (YiqjLkdLkMPpRVbZ*(37.095));
if (wkSFDAbgggDMANWv > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (67.765+(87.435)+(96.326)+(78.192)+(wkSFDAbgggDMANWv)+(30.6)+(10.656)+(4.081));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(20.397)+(12.591)+(93.796)+(0.1))/((85.51)));
	tcb->m_cWnd = (int) (68.768+(26.647)+(63.94)+(75.043));

}
if (tcb->m_segmentSize > RhMbYlkfVQTboioF) {
	YiqjLkdLkMPpRVbZ = (int) (24.319-(16.647)-(38.126)-(43.238)-(82.874)-(cnt));

} else {
	YiqjLkdLkMPpRVbZ = (int) (0.1/53.305);
	YiqjLkdLkMPpRVbZ = (int) (segmentsAcked-(82.872)-(79.048)-(67.434)-(85.533)-(48.506)-(86.268)-(58.198)-(tcb->m_segmentSize));
	YiqjLkdLkMPpRVbZ = (int) (25.078*(64.716)*(94.852)*(tcb->m_ssThresh)*(37.05)*(segmentsAcked)*(43.399));

}
