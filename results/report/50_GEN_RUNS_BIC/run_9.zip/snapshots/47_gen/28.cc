tcb->m_cWnd = (int) (79.506/8.876);
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (32.702*(55.557)*(0.777));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(63.671)+(42.483)+(48.796));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (((0.1)+(37.769)+(0.1)+(84.754)+(0.1))/((0.1)+(49.63)));

} else {
	segmentsAcked = (int) (85.865+(segmentsAcked)+(63.942)+(58.928)+(cnt)+(45.511)+(26.806)+(4.526)+(96.532));

}
segmentsAcked = (int) (cnt-(94.171)-(71.292));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (segmentsAcked+(51.571));
	tcb->m_ssThresh = (int) (11.363-(14.591)-(44.01)-(78.122));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(tcb->m_ssThresh)*(34.738)*(44.104)*(59.232)*(79.95)*(74.439));
	cnt = (int) (0.1/0.1);
	cnt = (int) (0.1/(77.109*(15.269)));

}
segmentsAcked = (int) (7.909-(92.588)-(28.388)-(tcb->m_ssThresh));
tcb->m_cWnd = (int) (segmentsAcked-(33.057)-(68.388));
