tcb->m_segmentSize = (int) (54.732*(45.9)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(44.728)*(55.223)*(cnt)*(segmentsAcked));
tcb->m_cWnd = (int) (14.254+(64.039)+(28.485)+(83.049)+(segmentsAcked)+(33.213)+(67.597)+(4.032));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (tcb->m_cWnd*(12.346)*(tcb->m_segmentSize)*(5.598)*(25.095)*(27.895));
if (tcb->m_segmentSize < cnt) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (95.707-(tcb->m_ssThresh)-(cnt)-(50.533)-(14.913)-(71.451)-(11.293)-(91.454)-(97.984));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(85.923)-(15.294)-(segmentsAcked));
	tcb->m_segmentSize = (int) (84.222-(tcb->m_cWnd)-(88.196)-(10.641));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked != cnt) {
	tcb->m_segmentSize = (int) (51.716+(26.974)+(segmentsAcked)+(3.908)+(77.445)+(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (84.469-(tcb->m_ssThresh)-(53.202)-(74.574)-(64.045));

}
tcb->m_ssThresh = (int) (10.152-(4.824)-(cnt));
ReduceCwnd (tcb);
