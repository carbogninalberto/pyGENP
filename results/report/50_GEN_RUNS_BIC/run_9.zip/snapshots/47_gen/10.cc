if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((78.024)+(0.1)+(56.5)+(0.1)+(2.648)+(0.1))/((0.1)+(72.889)));

} else {
	tcb->m_cWnd = (int) ((((44.778-(97.751)-(77.511)-(31.299)-(38.383)-(94.522)))+(65.123)+(0.1)+(69.29))/((0.1)+(0.1)+(0.1)+(0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
cnt = (int) (47.371*(23.599)*(8.068));
cnt = (int) (99.96+(79.915)+(53.815)+(1.733)+(55.356)+(90.233));
tcb->m_ssThresh = (int) (0.1/93.816);
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (64.967+(cnt)+(79.392)+(42.592)+(18.716)+(48.655)+(68.137)+(19.957));
	tcb->m_segmentSize = (int) (32.961*(54.902)*(cnt)*(92.407)*(5.241)*(86.74)*(9.204)*(60.396));
	tcb->m_ssThresh = (int) (46.254*(68.437)*(39.773)*(4.549)*(19.313)*(30.489));

} else {
	tcb->m_cWnd = (int) (0.1/99.571);
	tcb->m_ssThresh = (int) ((71.67*(tcb->m_cWnd)*(36.652)*(48.856)*(12.777)*(28.362)*(78.323)*(1.575))/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
