if (tcb->m_segmentSize != cnt) {
	tcb->m_cWnd = (int) (47.049/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (38.476-(85.978)-(35.224)-(77.506)-(56.713)-(99.388)-(45.458)-(45.436)-(39.732));
	tcb->m_cWnd = (int) (29.471+(20.644)+(60.084)+(19.589)+(43.381)+(69.474)+(tcb->m_segmentSize)+(cnt));
	tcb->m_cWnd = (int) (cnt-(99.212)-(6.965)-(15.378));

}
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (19.39-(95.544)-(33.429)-(79.078)-(16.264)-(19.027));
	cnt = (int) (segmentsAcked-(23.989)-(51.865)-(70.314)-(12.194)-(99.127)-(47.921)-(2.282));
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(96.701));

} else {
	tcb->m_ssThresh = (int) (90.265+(39.194)+(39.118)+(tcb->m_ssThresh)+(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked > cnt) {
	tcb->m_ssThresh = (int) (((0.1)+((12.837-(76.116)-(10.775)))+(0.1)+(35.724))/((16.852)+(0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (50.928+(tcb->m_segmentSize)+(2.484)+(99.929)+(6.763)+(40.339));

}
tcb->m_cWnd = (int) (25.292*(65.461)*(60.263)*(10.702)*(60.432)*(71.414));
if (segmentsAcked <= segmentsAcked) {
	segmentsAcked = (int) (3.757/64.844);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (31.758/(tcb->m_segmentSize+(33.195)+(48.4)+(95.951)+(98.489)+(41.184)));

} else {
	segmentsAcked = (int) (44.404*(10.287)*(66.998)*(3.469)*(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (cnt+(20.781)+(41.962)+(5.796)+(27.931)+(79.415)+(20.049)+(58.239)+(76.941));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (97.834+(11.186)+(75.534));
