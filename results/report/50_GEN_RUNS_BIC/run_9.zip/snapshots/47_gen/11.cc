tcb->m_cWnd = (int) (9.155+(11.086)+(37.62)+(3.518)+(1.029)+(51.947)+(86.004)+(tcb->m_ssThresh));
int KKRTDOxEPgGVEkXB = (int) (81.835+(tcb->m_ssThresh)+(95.471)+(19.646)+(64.569)+(78.108));
KKRTDOxEPgGVEkXB = (int) (KKRTDOxEPgGVEkXB+(85.497));
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	KKRTDOxEPgGVEkXB = (int) (10.733+(56.476)+(98.589)+(87.967)+(KKRTDOxEPgGVEkXB));

} else {
	KKRTDOxEPgGVEkXB = (int) (56.929*(64.873)*(59.525)*(cnt)*(61.915));
	cnt = (int) (52.638+(70.639)+(26.621)+(tcb->m_segmentSize)+(cnt)+(68.233)+(57.79)+(55.589));
	tcb->m_cWnd = (int) (0.1/0.1);

}
tcb->m_cWnd = (int) (68.31*(43.006)*(tcb->m_ssThresh)*(30.831)*(tcb->m_cWnd)*(87.15));
