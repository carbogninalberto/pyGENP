if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_ssThresh = (int) (58.726*(32.456));
	tcb->m_cWnd = (int) (6.504*(tcb->m_segmentSize)*(95.519)*(31.789)*(61.27)*(55.698)*(tcb->m_ssThresh));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (91.056+(31.533));
	cnt = (int) (21.915+(16.171)+(13.903)+(52.694));

}
segmentsAcked = (int) (10.846-(2.063)-(73.352)-(50.739)-(18.289)-(88.651)-(71.484));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (cnt != tcb->m_cWnd) {
	segmentsAcked = (int) (36.707+(94.093)+(68.91));
	tcb->m_cWnd = (int) (38.655*(43.533)*(tcb->m_cWnd)*(24.588)*(32.006)*(77.545)*(83.891));

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(87.312)+(0.1))/((0.1)));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(21.672)+(89.543)+(29.242)+(tcb->m_segmentSize)+(72.989)+(24.865)+(45.965)+(74.012));
