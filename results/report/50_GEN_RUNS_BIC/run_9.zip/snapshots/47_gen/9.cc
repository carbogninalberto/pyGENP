segmentsAcked = (int) (tcb->m_ssThresh+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(segmentsAcked)+(71.041)+(40.038)+(segmentsAcked)+(41.708)+(segmentsAcked));
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_segmentSize = (int) (65.441+(70.471)+(22.929)+(28.989)+(72.414)+(segmentsAcked)+(22.815));
	tcb->m_segmentSize = (int) (83.62*(90.601)*(89.747)*(tcb->m_segmentSize)*(71.843));

} else {
	tcb->m_segmentSize = (int) (36.758*(95.35)*(20.256)*(47.728)*(65.212)*(72.983)*(68.677)*(43.889));
	cnt = (int) (16.383-(44.587)-(49.888)-(47.014)-(1.061)-(34.655)-(81.663)-(95.153));

}
if (cnt <= segmentsAcked) {
	cnt = (int) (segmentsAcked+(94.926)+(9.354)+(82.775));

} else {
	cnt = (int) (67.881+(38.098));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (50.259-(48.166));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
