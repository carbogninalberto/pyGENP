ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (cnt+(61.191)+(tcb->m_cWnd)+(1.335)+(86.434)+(cnt));
	tcb->m_segmentSize = (int) (segmentsAcked+(90.19));
	segmentsAcked = (int) (75.408-(5.824)-(6.283)-(15.474)-(75.51));

} else {
	tcb->m_cWnd = (int) (70.611-(5.087)-(62.737)-(31.63));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float WhsASTzBmBcKvReM = (float) (55.691-(40.027)-(41.983)-(8.894)-(52.891)-(tcb->m_segmentSize)-(9.982));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
