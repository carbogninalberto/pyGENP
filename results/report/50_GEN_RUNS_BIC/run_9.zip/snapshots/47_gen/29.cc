if (tcb->m_segmentSize > tcb->m_ssThresh) {
	cnt = (int) (84.856+(segmentsAcked)+(41.608)+(62.376)+(5.075)+(tcb->m_cWnd)+(92.315)+(tcb->m_cWnd));
	tcb->m_cWnd = (int) (cnt*(tcb->m_ssThresh));

} else {
	cnt = (int) (1.312-(11.989));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(83.695)+(84.262)+(2.174)+(57.167)+(segmentsAcked)+(49.435)+(92.672)+(50.225));

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	segmentsAcked = (int) (61.701-(36.056)-(26.234)-(tcb->m_segmentSize)-(55.947)-(6.126));
	tcb->m_cWnd = (int) (98.603/0.1);
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(0.1))/((33.084)+(0.1)));

} else {
	segmentsAcked = (int) (20.094-(78.853)-(tcb->m_segmentSize)-(8.628)-(18.479)-(tcb->m_ssThresh)-(segmentsAcked)-(22.377)-(segmentsAcked));
	cnt = (int) (tcb->m_ssThresh-(tcb->m_segmentSize)-(79.504)-(6.435)-(12.164)-(segmentsAcked)-(29.899));

}
if (tcb->m_ssThresh >= segmentsAcked) {
	segmentsAcked = (int) (60.49+(98.596)+(75.705)+(30.331)+(24.401));

} else {
	segmentsAcked = (int) ((87.846+(72.062)+(tcb->m_ssThresh)+(44.19))/83.456);
	cnt = (int) (26.636+(50.292));

}
ReduceCwnd (tcb);
if (cnt < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(91.883)*(91.222)*(10.076)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(42.516));
	segmentsAcked = (int) (62.538*(4.865)*(17.693)*(90.294)*(12.771)*(84.32)*(42.684));

} else {
	tcb->m_cWnd = (int) ((((tcb->m_cWnd*(82.871)*(98.062)*(49.775)*(tcb->m_ssThresh)*(83.14)))+(0.1)+(77.907)+(0.1)+(0.1))/((1.341)));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(91.101)+(54.792)+(98.972)+(89.801)+(95.821)+(20.761)+(8.365));

}
if (cnt <= cnt) {
	tcb->m_segmentSize = (int) (31.436*(45.368)*(37.145)*(segmentsAcked)*(97.675)*(41.188)*(98.366)*(32.977)*(51.876));

} else {
	tcb->m_segmentSize = (int) ((64.132+(8.404))/48.539);
	tcb->m_cWnd = (int) (20.003-(segmentsAcked)-(tcb->m_cWnd)-(33.08)-(83.773));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (25.604*(42.669)*(66.831)*(16.533)*(33.332)*(tcb->m_segmentSize)*(98.89));
