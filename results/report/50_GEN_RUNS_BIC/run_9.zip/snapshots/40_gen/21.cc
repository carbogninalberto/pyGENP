if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(51.349)*(tcb->m_ssThresh)*(65.717));

} else {
	tcb->m_ssThresh = (int) (54.504-(27.3)-(1.608));
	tcb->m_cWnd = (int) (68.123*(14.496)*(87.561)*(25.484));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) ((54.616-(96.784)-(16.59)-(51.806)-(63.14)-(31.303)-(tcb->m_ssThresh)-(80.113)-(34.667))/91.658);
	segmentsAcked = (int) (((35.146)+(0.1)+(0.1)+(0.1)+((31.837*(82.619)*(70.47)*(72.66)))+(29.285))/((0.1)+(29.107)));
	tcb->m_segmentSize = (int) (74.238*(57.473));

} else {
	tcb->m_cWnd = (int) (88.322*(96.816)*(segmentsAcked)*(33.336)*(87.841)*(53.394)*(17.241)*(11.052)*(91.617));

}
