segmentsAcked = (int) (93.492/19.5);
ReduceCwnd (tcb);
segmentsAcked = (int) (73.607/14.287);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
