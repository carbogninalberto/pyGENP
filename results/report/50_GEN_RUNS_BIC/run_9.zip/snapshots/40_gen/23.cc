ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (51.899+(93.43)+(49.605)+(segmentsAcked)+(64.366)+(81.102)+(31.353));
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(29.073)+(85.153))/((41.678)+(0.1)+(68.282)));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (18.933+(21.55));

} else {
	tcb->m_cWnd = (int) (90.517+(cnt)+(2.602)+(33.376));
	tcb->m_ssThresh = (int) ((45.245+(93.802)+(80.645)+(37.143))/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh <= segmentsAcked) {
	segmentsAcked = (int) (35.797*(1.996)*(26.779)*(25.463)*(43.653)*(73.495));
	segmentsAcked = (int) (segmentsAcked+(10.289)+(46.748)+(tcb->m_ssThresh)+(70.335)+(26.057)+(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (72.752+(11.275)+(tcb->m_cWnd)+(23.781));

}
if (cnt <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(24.045)+((cnt+(12.578)+(26.471)+(64.343)+(72.294)+(47.366)+(50.553)+(52.04)))+(0.1))/((0.1)));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	cnt = (int) (79.032+(31.312)+(75.987)+(86.417)+(78.027));
	tcb->m_cWnd = (int) (94.212+(13.975)+(80.735)+(47.38));

}
ReduceCwnd (tcb);
if (cnt <= segmentsAcked) {
	tcb->m_cWnd = (int) (74.879-(cnt)-(35.491)-(cnt)-(15.742)-(21.174));

} else {
	tcb->m_cWnd = (int) (5.979/0.1);

}
