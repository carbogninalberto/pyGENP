segmentsAcked = (int) (72.814/-15.585);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (57.388/-98.608);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
