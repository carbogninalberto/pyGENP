if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (87.357*(53.277)*(67.628)*(29.541)*(55.02)*(70.772)*(74.905)*(78.5));
tcb->m_cWnd = (int) (14.437+(87.442)+(79.615)+(58.777)+(9.94)+(49.359)+(tcb->m_ssThresh));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (72.058+(78.371));
if (tcb->m_segmentSize <= cnt) {
	tcb->m_ssThresh = (int) (69.354/0.1);

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
