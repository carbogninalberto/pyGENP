segmentsAcked = (int) (36.475*(85.152)*(88.692)*(31.069)*(94.14)*(99.305)*(tcb->m_cWnd));
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (87.124-(94.366)-(89.075)-(72.245)-(73.346)-(3.067)-(51.104)-(89.351));
	cnt = (int) (59.902/61.184);

} else {
	tcb->m_cWnd = (int) (68.915-(42.567)-(tcb->m_ssThresh));

}
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_segmentSize = (int) (15.245*(92.14)*(2.449)*(cnt)*(49.542)*(9.339)*(23.829)*(13.2)*(tcb->m_segmentSize));
	cnt = (int) (21.199-(72.169)-(cnt)-(tcb->m_ssThresh)-(82.924)-(segmentsAcked)-(48.685));

} else {
	tcb->m_segmentSize = (int) (29.425*(73.117)*(13.382)*(96.898)*(1.43)*(tcb->m_cWnd)*(96.165)*(67.306));
	segmentsAcked = (int) (16.41-(tcb->m_ssThresh)-(69.721)-(71.743)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(11.225));
	tcb->m_cWnd = (int) (70.196-(46.073)-(tcb->m_cWnd)-(22.765)-(18.432)-(70.484)-(10.792)-(tcb->m_cWnd));

}
cnt = (int) (((30.661)+(0.1)+(61.22)+(0.1)+((17.829-(82.827)))+(0.1)+(69.894)+(0.1))/((88.116)));
tcb->m_ssThresh = (int) (66.884+(cnt)+(27.625)+(77.248));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
