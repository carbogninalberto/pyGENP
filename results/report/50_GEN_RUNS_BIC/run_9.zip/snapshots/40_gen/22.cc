segmentsAcked = (int) (82.821-(44.146)-(tcb->m_ssThresh));
if (cnt <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (41.084/(75.13-(55.932)-(59.07)-(73.134)));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (((11.409)+(81.789)+(0.1)+(42.16)+(0.1))/((92.27)+(0.1)+(50.845)+(88.516)));
	tcb->m_segmentSize = (int) (29.042-(84.183)-(27.618)-(66.553)-(44.527)-(1.809)-(39.771)-(58.292)-(83.894));

}
segmentsAcked = (int) (63.758+(46.247));
if (cnt < tcb->m_cWnd) {
	cnt = (int) (89.927-(tcb->m_cWnd));
	cnt = (int) (88.189-(48.146)-(14.071)-(37.735)-(23.589)-(81.782)-(48.928)-(26.877)-(47.659));

} else {
	cnt = (int) (22.421-(tcb->m_ssThresh)-(59.824)-(tcb->m_ssThresh)-(9.7)-(cnt)-(tcb->m_ssThresh)-(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (25.756/75.071);

} else {
	tcb->m_cWnd = (int) (41.87+(83.109)+(9.755)+(31.722));

}
