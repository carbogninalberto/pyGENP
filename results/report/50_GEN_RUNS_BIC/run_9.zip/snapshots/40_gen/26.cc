segmentsAcked = (int) (13.12+(66.66)+(tcb->m_segmentSize));
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (((0.1)+(39.41)+(36.317)+(17.553)+(0.1)+(54.412)+(0.1))/((46.062)+(33.37)));
	segmentsAcked = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (((36.195)+(0.1)+(24.289)+(0.1))/((62.599)+(0.1)+(25.182)+(0.1)));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (9.031*(90.292)*(1.35)*(54.696)*(43.47)*(48.415)*(68.133));
segmentsAcked = (int) (0.1/0.1);
