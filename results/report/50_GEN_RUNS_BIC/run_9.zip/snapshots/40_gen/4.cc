ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-16.934-(3.251)-(27.696)-(71.972)-(-97.521)-(-1.661));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-86.97-(-27.285)-(-29.691)-(-68.219)-(-64.302)-(27.824));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
