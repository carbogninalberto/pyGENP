segmentsAcked = (int) (54.288/53.023);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (1.705/43.799);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
