segmentsAcked = (int) (33.47/69.127);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (-36.361/59.748);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
