if (tcb->m_cWnd < tcb->m_ssThresh) {
	cnt = (int) (93.325+(9.28)+(94.565)+(cnt)+(66.962)+(98.95)+(17.022)+(64.767)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (segmentsAcked-(99.708)-(47.38)-(tcb->m_cWnd)-(8.32)-(60.896)-(24.365));

} else {
	cnt = (int) (53.922*(tcb->m_ssThresh)*(50.028)*(19.421)*(74.136)*(12.564)*(20.8));
	tcb->m_cWnd = (int) (69.415/0.1);

}
tcb->m_segmentSize = (int) (78.394+(20.326)+(33.209)+(6.903));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	segmentsAcked = (int) (59.674/0.1);

} else {
	segmentsAcked = (int) (19.423+(86.802)+(80.466));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (88.096-(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (45.571-(23.607));
tcb->m_cWnd = (int) (29.063+(99.292)+(64.813)+(cnt)+(tcb->m_cWnd)+(10.979));
