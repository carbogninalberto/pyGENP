int OynXzUeoFSaRBohq = (int) (92.743*(52.25));
tcb->m_segmentSize = (int) (40.056-(-76.579)-(-24.131)-(-10.641)-(53.787)-(6.574));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
