segmentsAcked = (int) (-67.589/-96.227);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
