float WrSflUyIZgBZsDjj = (float) (((97.785)+(82.895)+(63.104)+(0.1))/((0.1)));
int BvgMUXKcInGJjIZl = (int) (89.542-(78.131)-(30.265)-(79.126)-(tcb->m_segmentSize));
int yfxxAIuOPyomEgpu = (int) (40.223*(55.596)*(92.587)*(tcb->m_segmentSize)*(7.727)*(BvgMUXKcInGJjIZl)*(47.472));
yfxxAIuOPyomEgpu = (int) (((95.249)+((80.943*(97.423)*(52.004)*(90.278)*(77.262)*(71.826)*(21.149)*(56.633)*(84.385)))+(62.68)+(0.1))/((87.297)+(0.1)+(5.901)));
float ApzcehcnCqwLPHtH = (float) (38.928-(13.396)-(58.765)-(BvgMUXKcInGJjIZl)-(85.481)-(tcb->m_cWnd)-(73.697)-(43.146)-(cnt));
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.1/69.729);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (segmentsAcked*(tcb->m_ssThresh)*(99.844));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (yfxxAIuOPyomEgpu >= cnt) {
	BvgMUXKcInGJjIZl = (int) (6.86*(50.844)*(BvgMUXKcInGJjIZl)*(58.606)*(25.117)*(WrSflUyIZgBZsDjj)*(18.353));
	cnt = (int) (cnt*(24.4)*(2.226)*(BvgMUXKcInGJjIZl)*(51.616)*(63.605)*(90.637)*(21.672)*(68.429));
	cnt = (int) (30.195/0.1);

} else {
	BvgMUXKcInGJjIZl = (int) (((0.1)+((77.935-(64.74)-(33.024)-(3.748)))+(0.1)+(27.746)+(58.357))/((1.284)+(0.1)+(0.1)));
	cnt = (int) (67.545+(12.311)+(54.679)+(58.611)+(85.329));

}
