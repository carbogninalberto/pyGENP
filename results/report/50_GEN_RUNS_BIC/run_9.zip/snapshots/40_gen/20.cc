ReduceCwnd (tcb);
if (cnt < segmentsAcked) {
	cnt = (int) (0.1/37.154);

} else {
	cnt = (int) (51.077+(25.958)+(18.662)+(39.49)+(5.69)+(tcb->m_segmentSize)+(40.981)+(tcb->m_ssThresh)+(27.506));

}
if (tcb->m_segmentSize >= cnt) {
	cnt = (int) (cnt*(51.225)*(53.111)*(segmentsAcked)*(tcb->m_cWnd)*(51.001)*(cnt)*(67.563));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (cnt*(85.838)*(57.522)*(71.305)*(tcb->m_segmentSize)*(78.887)*(25.905)*(24.264));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (12.326-(61.456)-(54.874)-(66.847));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((0.1)+(69.157)+(77.663)+(48.725)+(50.822)+(90.884))/((25.907)+(34.377)+(0.1)));
ReduceCwnd (tcb);
int zgRjsUAvmIQviVtW = (int) (10.23-(33.947)-(66.459)-(tcb->m_ssThresh)-(29.861)-(13.326));
