segmentsAcked = (int) (-32.045/63.337);
segmentsAcked = (int) (-2.036/-66.56);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
