if (segmentsAcked <= cnt) {
	cnt = (int) (88.909-(cnt)-(78.364)-(53.337)-(tcb->m_segmentSize)-(84.828)-(13.252)-(1.008)-(0.856));

} else {
	cnt = (int) (67.075+(20.117)+(97.854)+(92.417)+(60.817)+(96.36)+(73.167));
	segmentsAcked = (int) (84.406-(segmentsAcked)-(69.112)-(59.351));

}
segmentsAcked = (int) (6.606*(87.143)*(segmentsAcked));
tcb->m_segmentSize = (int) (96.294*(52.301)*(45.794)*(16.773));
ReduceCwnd (tcb);
if (segmentsAcked >= segmentsAcked) {
	tcb->m_ssThresh = (int) ((((47.402*(27.903)*(14.517)*(15.44)*(43.943)*(99.976)))+(0.1)+((45.876+(40.241)+(tcb->m_cWnd)+(26.223)+(7.157)+(73.504)+(90.341)+(34.921)))+(68.369)+(20.775))/((13.934)));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (47.512+(15.272)+(59.565)+(48.92)+(76.52)+(89.689)+(tcb->m_segmentSize));
	segmentsAcked = (int) (94.948-(tcb->m_cWnd));
	segmentsAcked = (int) ((15.597*(92.921)*(68.313)*(47.517)*(90.059)*(61.29)*(14.349))/63.277);

}
tcb->m_ssThresh = (int) (9.79+(9.53)+(4.669)+(40.336));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (76.577-(65.512)-(8.002)-(21.128)-(44.442)-(7.834));
	tcb->m_cWnd = (int) (40.303*(45.232)*(44.856)*(segmentsAcked)*(33.025)*(49.125));
	segmentsAcked = (int) (tcb->m_segmentSize*(9.389)*(17.215)*(30.292)*(cnt)*(41.428)*(7.07)*(68.45)*(50.281));

} else {
	tcb->m_ssThresh = (int) (19.399+(27.988));

}
tcb->m_segmentSize = (int) (0.1/81.98);
tcb->m_cWnd = (int) (24.822/0.1);
