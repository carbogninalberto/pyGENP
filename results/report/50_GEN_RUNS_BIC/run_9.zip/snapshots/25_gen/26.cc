if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (95.655+(58.535)+(26.745)+(tcb->m_ssThresh)+(24.487)+(tcb->m_cWnd)+(0.829)+(19.461));
tcb->m_segmentSize = (int) (80.439*(40.086));
tcb->m_cWnd = (int) (0.1/64.681);
tcb->m_cWnd = (int) (17.8+(46.497)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(segmentsAcked));
if (segmentsAcked <= segmentsAcked) {
	cnt = (int) (18.505/0.1);

} else {
	cnt = (int) (19.274+(93.041)+(30.272)+(34.847)+(cnt));

}
tcb->m_ssThresh = (int) (60.881*(tcb->m_ssThresh)*(36.6)*(34.531)*(12.603)*(54.679));
