tcb->m_segmentSize = (int) (-81.629*(-27.691)*(-12.226)*(89.988)*(34.307)*(44.463)*(21.155)*(82.993));
tcb->m_segmentSize = (int) (97.979*(20.781)*(-26.141)*(-20.667));
tcb->m_cWnd = (int) (80.232*(90.589)*(67.373)*(93.923)*(63.671));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (32.812*(22.911)*(97.621)*(-11.381));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
