ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (27.647-(tcb->m_cWnd));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
int iwUsFLbGXMbIYWjh = (int) (cnt-(44.408)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(30.63)-(37.427));
if (cnt > iwUsFLbGXMbIYWjh) {
	iwUsFLbGXMbIYWjh = (int) (43.191+(36.762));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	iwUsFLbGXMbIYWjh = (int) (42.203-(iwUsFLbGXMbIYWjh)-(8.543));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
int qSOCzFqzEdmSePzo = (int) ((((72.421+(iwUsFLbGXMbIYWjh)))+(0.1)+(0.1)+(69.025))/((53.892)+(92.069)+(43.142)+(98.411)+(0.1)));
cnt = (int) ((35.037-(tcb->m_ssThresh)-(qSOCzFqzEdmSePzo))/0.1);
