segmentsAcked = (int) (35.609*(6.828)*(4.84)*(64.053)*(62.478)*(42.221)*(44.115));
tcb->m_segmentSize = (int) (38.483/0.1);
tcb->m_cWnd = (int) (((88.463)+(0.1)+(0.1)+(0.1)+(82.335))/((88.049)+(32.944)+(32.007)));
ReduceCwnd (tcb);
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(tcb->m_segmentSize)+(76.986)+(73.789)+(64.068)+(44.902)+(54.134)+(32.483));

} else {
	tcb->m_segmentSize = (int) (51.229*(87.361)*(15.189)*(tcb->m_cWnd));

}
tcb->m_segmentSize = (int) ((96.886*(35.373)*(4.031)*(tcb->m_ssThresh)*(31.314))/0.1);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (24.069-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(13.428)-(36.124));

} else {
	tcb->m_cWnd = (int) (20.308*(segmentsAcked)*(60.756)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(88.44)*(49.34)*(90.908));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
