float nUiOjyMsdBIalEcF = (float) (87.212-(86.53)-(16.873)-(-40.283)-(0.971)-(1.394)-(1.763)-(-57.643)-(-26.652));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (87.765+(19.831)+(-38.656)+(-14.808)+(30.711));
segmentsAcked = (int) (14.517+(92.655)+(-82.93));
segmentsAcked = (int) (1.136+(-5.033)+(68.982));
