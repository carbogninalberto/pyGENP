tcb->m_segmentSize = (int) (((-26.956)+(-96.988)+(-43.043)+(6.629)+((-16.039*(36.028)*(-31.378)))+(-67.134)+(-83.801))/((-14.975)));
tcb->m_segmentSize = (int) (-95.7*(29.432)*(-9.182)*(-62.751));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
