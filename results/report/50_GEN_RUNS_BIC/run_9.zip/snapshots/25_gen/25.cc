if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_ssThresh = (int) (12.104-(25.758)-(tcb->m_segmentSize)-(35.686)-(22.913)-(95.772)-(cnt)-(91.104)-(4.737));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (96.411-(tcb->m_segmentSize)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(40.354)-(56.099)-(66.368));

} else {
	tcb->m_ssThresh = (int) (32.377-(81.972)-(71.965)-(56.166)-(77.669)-(tcb->m_segmentSize)-(14.947)-(51.005));
	cnt = (int) (70.93+(tcb->m_ssThresh)+(71.153)+(35.1)+(89.203)+(41.695)+(segmentsAcked)+(90.502));
	tcb->m_ssThresh = (int) (((0.1)+(28.365)+(4.033)+(6.829))/((0.1)+(99.263)+(81.575)+(0.1)));

}
if (cnt >= tcb->m_cWnd) {
	cnt = (int) (54.819+(8.346)+(57.148));
	ReduceCwnd (tcb);
	cnt = (int) (((99.05)+(43.818)+(0.1)+(0.1)+(0.1)+(31.385)+(64.272))/((0.1)+(0.1)));

} else {
	cnt = (int) (16.247*(12.034)*(30.972)*(cnt));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_cWnd = (int) (80.953+(34.63)+(2.682)+(11.053)+(34.775)+(91.394)+(89.9));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (0.1/14.033);

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (65.328*(34.485)*(34.73)*(60.254)*(tcb->m_ssThresh));
if (cnt < tcb->m_ssThresh) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) ((((58.97+(tcb->m_segmentSize)+(16.811)+(90.355)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(34.551)+(2.424)+(41.623)))+(0.1)+(35.191)+(7.111))/((93.946)+(0.1)+(73.249)+(67.239)+(0.1)));
	tcb->m_segmentSize = (int) (50.472*(tcb->m_cWnd)*(26.376)*(tcb->m_ssThresh)*(43.674)*(tcb->m_cWnd)*(71.681)*(14.867)*(71.699));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd == cnt) {
	tcb->m_cWnd = (int) ((((tcb->m_ssThresh-(segmentsAcked)-(66.165)))+(0.1)+(0.1)+(0.1))/((0.1)+(32.399)));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(55.075)*(34.45)*(13.605)*(85.293)*(74.114)*(37.686)*(46.133)*(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(22.333)-(91.45)-(35.627)-(39.134)-(12.5)-(segmentsAcked));

}
