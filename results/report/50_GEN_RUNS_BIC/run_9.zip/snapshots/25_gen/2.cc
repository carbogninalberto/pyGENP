float nUiOjyMsdBIalEcF = (float) (98.341-(75.495)-(48.087)-(-41.249)-(-9.397)-(40.87)-(99.408)-(27.028)-(-72.833));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-26.203+(-45.685)+(-16.732)+(-95.809)+(35.889));
segmentsAcked = (int) (71.741+(-83.122)+(-85.583));
