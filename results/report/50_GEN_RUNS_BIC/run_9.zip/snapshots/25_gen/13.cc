cnt = (int) (((39.161)+((98.471-(33.24)-(tcb->m_ssThresh)))+(0.1)+(29.584)+(4.742))/((28.987)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
cnt = (int) (31.692-(2.072)-(53.701)-(36.466)-(98.479)-(34.92)-(45.541));
segmentsAcked = (int) (83.777*(5.2)*(86.281)*(76.725));
tcb->m_ssThresh = (int) (8.653+(tcb->m_segmentSize));
cnt = (int) (68.998-(94.569));
tcb->m_segmentSize = (int) (19.941-(tcb->m_segmentSize)-(13.568)-(88.469)-(32.354)-(28.507)-(cnt));
if (segmentsAcked != cnt) {
	segmentsAcked = (int) (54.975-(8.968));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (36.28*(cnt)*(29.258)*(64.371)*(32.745)*(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
