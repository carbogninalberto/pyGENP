tcb->m_cWnd = (int) (((76.537)+(50.621)+((84.281*(13.218)*(11.228)*(49.531)*(tcb->m_ssThresh)*(0.105)*(-49.016)*(37.832)*(19.762)))+(-60.303))/((41.818)));
tcb->m_segmentSize = (int) (-43.711*(76.811)*(72.147)*(30.229));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
