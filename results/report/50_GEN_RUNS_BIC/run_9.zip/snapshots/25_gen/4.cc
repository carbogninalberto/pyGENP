float nUiOjyMsdBIalEcF = (float) (39.129-(-96.258)-(-96.009)-(-81.939)-(-69.979)-(26.457)-(-45.633)-(8.877)-(-39.075));
if (nUiOjyMsdBIalEcF >= segmentsAcked) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	nUiOjyMsdBIalEcF = (float) (65.521-(19.272)-(66.144));

} else {
	tcb->m_segmentSize = (int) (3.335-(36.829)-(83.993));

}
tcb->m_segmentSize = (int) (-58.699+(30.538)+(42.885)+(-74.34)+(16.444));
segmentsAcked = (int) (-67.964+(80.872)+(-83.777));
