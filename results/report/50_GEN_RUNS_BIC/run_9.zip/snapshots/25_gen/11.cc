ReduceCwnd (tcb);
if (segmentsAcked >= segmentsAcked) {
	tcb->m_cWnd = (int) (54.586+(5.914)+(3.489)+(tcb->m_ssThresh)+(89.733)+(33.171)+(8.075)+(82.657)+(82.179));
	tcb->m_segmentSize = (int) (10.762+(40.014)+(tcb->m_ssThresh)+(97.243)+(88.692)+(cnt)+(6.99)+(79.942)+(36.752));

} else {
	tcb->m_cWnd = (int) (10.53*(tcb->m_segmentSize)*(tcb->m_cWnd)*(44.006)*(tcb->m_ssThresh)*(60.21)*(30.857)*(51.943));
	cnt = (int) (cnt-(61.599)-(55.703));

}
if (cnt != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (25.181-(57.938)-(98.182)-(cnt)-(46.903)-(61.223)-(tcb->m_segmentSize)-(97.135)-(36.88));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (73.367*(72.311)*(34.488)*(21.452)*(60.855)*(31.173)*(cnt)*(83.654));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_ssThresh = (int) (2.163/0.1);
tcb->m_cWnd = (int) (cnt-(37.628));
