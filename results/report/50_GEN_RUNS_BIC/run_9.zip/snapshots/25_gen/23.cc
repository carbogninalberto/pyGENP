cnt = (int) (tcb->m_segmentSize*(46.205)*(36.38)*(25.062));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (81.226-(24.837)-(54.095)-(4.197));

} else {
	tcb->m_ssThresh = (int) (38.853*(62.536)*(36.451)*(0.891)*(7.396)*(12.891));
	cnt = (int) (((0.1)+((52.218-(88.344)-(42.846)-(31.504)-(tcb->m_segmentSize)-(4.444)-(23.844)))+(91.778)+(0.1)+(0.1))/((80.014)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (41.647/94.545);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (35.355+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(5.445)+(tcb->m_ssThresh)+(94.264)+(48.124));
segmentsAcked = (int) (26.525/23.177);
if (segmentsAcked > segmentsAcked) {
	tcb->m_ssThresh = (int) (91.353+(82.3)+(77.392)+(88.175)+(60.14)+(11.087)+(1.728));
	cnt = (int) (15.436+(3.528)+(43.122)+(61.199)+(75.982)+(45.701)+(tcb->m_ssThresh)+(94.098));
	cnt = (int) (95.235-(tcb->m_segmentSize)-(21.355)-(32.055)-(cnt)-(segmentsAcked)-(segmentsAcked)-(35.267));

} else {
	tcb->m_ssThresh = (int) (cnt-(cnt)-(99.929));

}
