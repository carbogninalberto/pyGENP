if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float YXKehZjAEDLFWhQv = (float) (-85.465-(89.616)-(37.645)-(45.453)-(-14.55)-(-98.282)-(57.324)-(-46.555)-(-7.571));
tcb->m_segmentSize = (int) (-90.887*(19.559)*(67.073)*(-15.306));
