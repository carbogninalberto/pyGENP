ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (28.701-(77.179)-(46.467)-(66.197)-(tcb->m_cWnd)-(2.214)-(cnt)-(82.573)-(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(77.51)*(8.562)*(93.422)*(37.63));

} else {
	segmentsAcked = (int) (((27.981)+(91.829)+(0.1)+(65.144)+(0.1)+(0.1))/((88.917)+(0.1)));

}
if (cnt >= segmentsAcked) {
	cnt = (int) ((47.224-(70.604)-(tcb->m_segmentSize)-(55.882)-(76.004)-(84.138)-(37.577)-(tcb->m_segmentSize)-(49.214))/0.1);

} else {
	cnt = (int) (7.351*(11.009)*(cnt)*(tcb->m_cWnd)*(27.421));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(39.919)-(62.759));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < cnt) {
	segmentsAcked = (int) (11.86-(85.66)-(31.069)-(5.258)-(47.968)-(20.037)-(93.473));
	cnt = (int) (6.525+(56.964)+(23.057));
	segmentsAcked = (int) (33.317-(47.507));

} else {
	segmentsAcked = (int) (67.506/0.1);

}
