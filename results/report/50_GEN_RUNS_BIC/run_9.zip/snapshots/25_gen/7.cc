segmentsAcked = (int) (1.436/63.507);
segmentsAcked = (int) (97.238/-45.205);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
