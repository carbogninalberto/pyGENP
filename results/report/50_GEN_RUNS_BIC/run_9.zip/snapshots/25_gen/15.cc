segmentsAcked = (int) (47.266-(15.654)-(63.247)-(segmentsAcked)-(89.149)-(38.225)-(8.502)-(15.36));
cnt = (int) (30.989-(69.729)-(88.43)-(4.973));
segmentsAcked = (int) (87.873*(55.5));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (tcb->m_cWnd-(59.6)-(34.173)-(0.416)-(78.605)-(66.42)-(97.314)-(30.557));
tcb->m_ssThresh = (int) (80.194/0.1);
cnt = (int) (79.694+(33.863)+(tcb->m_cWnd));
if (tcb->m_ssThresh != tcb->m_cWnd) {
	segmentsAcked = (int) (89.402+(65.077)+(tcb->m_cWnd)+(11.988)+(31.439));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((0.1)+(88.668)+(0.1)+(23.091)+(90.107))/((0.1)+(23.148)+(9.67)));
	tcb->m_ssThresh = (int) (87.172+(22.239));
	tcb->m_cWnd = (int) (56.722+(tcb->m_ssThresh)+(67.49)+(83.634)+(35.588)+(91.941)+(tcb->m_segmentSize)+(98.628));

}
