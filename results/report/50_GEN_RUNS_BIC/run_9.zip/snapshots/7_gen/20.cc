cnt = (int) (53.173-(19.365)-(tcb->m_cWnd)-(tcb->m_cWnd));
segmentsAcked = (int) (tcb->m_cWnd+(18.147));
if (tcb->m_cWnd == cnt) {
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (74.378-(tcb->m_ssThresh)-(segmentsAcked)-(96.624)-(87.093)-(14.921)-(41.896));
	tcb->m_ssThresh = (int) (35.203-(72.698)-(23.169));
	segmentsAcked = (int) (42.224+(86.496)+(82.547)+(tcb->m_cWnd)+(81.776));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd+(11.231)+(tcb->m_ssThresh)+(41.452)+(50.632)+(tcb->m_ssThresh)+(38.864)+(25.651));

} else {
	segmentsAcked = (int) (69.538-(80.832)-(52.829)-(72.205));
	tcb->m_cWnd = (int) (cnt-(8.365)-(cnt)-(28.992)-(98.111)-(69.929));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
