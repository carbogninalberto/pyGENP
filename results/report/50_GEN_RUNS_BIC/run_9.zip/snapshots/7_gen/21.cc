if (cnt <= segmentsAcked) {
	tcb->m_cWnd = (int) (30.137*(23.425));
	tcb->m_cWnd = (int) (29.586/0.1);

} else {
	tcb->m_cWnd = (int) (((0.1)+(69.023)+(88.388)+(0.1))/((0.1)+(0.1)+(72.829)+(0.1)));

}
tcb->m_segmentSize = (int) (39.369-(44.433)-(61.006)-(0.028));
if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (54.118*(60.523)*(85.874)*(70.726)*(50.685)*(31.887)*(tcb->m_ssThresh)*(80.165)*(58.717));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (((19.428)+(0.1)+(7.217)+((cnt+(60.89)+(89.489)+(32.197)+(cnt)+(92.538)+(81.983)+(23.131)+(98.606)))+(0.1))/((66.126)+(40.961)));

}
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (50.556+(56.713)+(91.135)+(96.715)+(13.252)+(tcb->m_ssThresh)+(90.911));
	cnt = (int) (21.775*(9.142)*(90.038)*(0.404)*(58.261)*(17.88));
	tcb->m_ssThresh = (int) (7.028+(segmentsAcked)+(5.313));

} else {
	tcb->m_segmentSize = (int) (0.1/68.714);
	ReduceCwnd (tcb);
	segmentsAcked = (int) (35.065*(12.159)*(16.859));

}
ReduceCwnd (tcb);
