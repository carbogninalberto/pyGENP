tcb->m_ssThresh = (int) (tcb->m_ssThresh-(tcb->m_segmentSize)-(cnt)-(51.083)-(77.379)-(segmentsAcked)-(65.694));
float gEuRfKLpWXheIHVy = (float) (30.585*(segmentsAcked)*(tcb->m_segmentSize)*(55.641)*(tcb->m_ssThresh));
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (4.711-(cnt)-(82.317)-(85.988)-(4.213)-(41.134)-(tcb->m_segmentSize)-(gEuRfKLpWXheIHVy));
	tcb->m_segmentSize = (int) (17.755*(12.449)*(15.168)*(0.93));

} else {
	tcb->m_ssThresh = (int) (61.831/5.356);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_ssThresh != segmentsAcked) {
	gEuRfKLpWXheIHVy = (float) (segmentsAcked+(53.018)+(64.62)+(73.458)+(23.032)+(92.227)+(3.914));
	tcb->m_cWnd = (int) (21.257-(86.881)-(42.12)-(9.529)-(36.879)-(77.654));

} else {
	gEuRfKLpWXheIHVy = (float) (gEuRfKLpWXheIHVy-(gEuRfKLpWXheIHVy)-(57.37)-(81.761));
	tcb->m_cWnd = (int) (43.735*(28.975)*(79.27)*(tcb->m_cWnd)*(92.032)*(57.554)*(53.931));

}
ReduceCwnd (tcb);
