if (tcb->m_segmentSize <= tcb->m_cWnd) {
	segmentsAcked = (int) (49.956*(19.601)*(37.447));
	segmentsAcked = (int) (0.1/0.1);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (29.243-(6.334)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(2.766)-(16.675)-(68.126)-(45.035));

}
ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_cWnd) {
	cnt = (int) (88.494*(9.023)*(tcb->m_segmentSize)*(75.078)*(tcb->m_cWnd)*(31.784)*(56.258)*(67.445));
	tcb->m_cWnd = (int) (55.18-(58.692)-(18.9)-(28.392));

} else {
	cnt = (int) (25.165/35.059);
	tcb->m_ssThresh = (int) (64.299-(7.079)-(93.917)-(26.338)-(42.65)-(11.126));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd == segmentsAcked) {
	cnt = (int) (tcb->m_segmentSize+(85.556));
	tcb->m_cWnd = (int) (segmentsAcked*(53.819));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (8.027+(47.304));
	segmentsAcked = (int) (98.252+(76.084)+(35.938)+(31.265)+(29.832)+(55.331));
	tcb->m_ssThresh = (int) (21.298*(27.496)*(segmentsAcked));

}
if (cnt > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(65.196)-(33.871)-(18.941)-(tcb->m_segmentSize)-(65.8)-(45.247)-(69.92));
	tcb->m_cWnd = (int) (76.281+(27.412));
	tcb->m_ssThresh = (int) (92.591-(20.795)-(92.044)-(51.166)-(99.485)-(49.747)-(16.981)-(50.853)-(58.77));

} else {
	tcb->m_segmentSize = (int) (((1.077)+(47.662)+(0.1)+(8.815))/((78.742)));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
