if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(62.591)+(52.242)+(55.411));

} else {
	tcb->m_ssThresh = (int) (51.727/0.1);

}
ReduceCwnd (tcb);
