tcb->m_cWnd = (int) (50.857/86.788);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-72.634-(25.715)-(83.562)-(-97.872)-(-40.154));
ReduceCwnd (tcb);
