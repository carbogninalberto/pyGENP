if (tcb->m_ssThresh == tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_segmentSize*(cnt));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+(73.813)+(0.1)+(60.534))/((0.1)+(0.1)+(21.226)));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh != tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_segmentSize+(25.802)+(75.431)+(33.663));
	tcb->m_cWnd = (int) (34.428*(40.702)*(tcb->m_cWnd)*(21.728));
	tcb->m_segmentSize = (int) (23.811+(11.406));

} else {
	segmentsAcked = (int) (80.031+(78.744)+(0.789)+(4.921)+(cnt)+(tcb->m_ssThresh));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/2.101);

} else {
	tcb->m_cWnd = (int) (62.327/33.337);

}
