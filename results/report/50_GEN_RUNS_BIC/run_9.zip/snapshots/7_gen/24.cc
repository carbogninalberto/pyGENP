tcb->m_segmentSize = (int) (90.286*(12.865)*(5.098)*(35.929)*(87.004)*(64.598)*(21.134));
float ZSzmnNUZVdrccRHy = (float) (((0.1)+(0.1)+(34.461)+(58.334)+(22.181))/((98.374)+(0.1)));
if (tcb->m_ssThresh >= ZSzmnNUZVdrccRHy) {
	tcb->m_ssThresh = (int) (20.929*(ZSzmnNUZVdrccRHy)*(0.193)*(38.778)*(cnt)*(35.966)*(6.908)*(73.709)*(99.084));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (61.819*(10.524));
	ReduceCwnd (tcb);

}
if (cnt < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((81.409)+(0.1)+(0.1)+(0.1)+(0.1))/((16.966)+(29.909)+(52.81)+(87.96)));
	ZSzmnNUZVdrccRHy = (float) (47.979-(59.063)-(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (14.956-(97.898)-(96.02));
	tcb->m_ssThresh = (int) (50.781-(76.976)-(68.159)-(99.053)-(49.481));

}
cnt = (int) (44.657+(46.661)+(segmentsAcked)+(tcb->m_cWnd));
segmentsAcked = (int) (tcb->m_cWnd*(ZSzmnNUZVdrccRHy)*(ZSzmnNUZVdrccRHy)*(10.395)*(cnt));
if (tcb->m_cWnd < tcb->m_cWnd) {
	cnt = (int) (97.144+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(46.055)+(16.655)+(13.642));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (91.565+(52.557)+(85.382)+(ZSzmnNUZVdrccRHy)+(0.882));

} else {
	cnt = (int) (74.195*(ZSzmnNUZVdrccRHy)*(8.25)*(70.556)*(98.958)*(75.343)*(70.836)*(63.152));
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(53.431));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ZSzmnNUZVdrccRHy = (float) (91.427*(90.85)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(62.332)*(segmentsAcked)*(17.213)*(tcb->m_cWnd)*(54.604));
