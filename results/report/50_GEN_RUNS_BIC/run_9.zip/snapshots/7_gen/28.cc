if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	segmentsAcked = (int) (17.526+(83.562)+(7.136)+(6.208)+(49.199));

} else {
	segmentsAcked = (int) (11.352*(77.529)*(tcb->m_ssThresh)*(80.307)*(88.652)*(85.018)*(61.33)*(tcb->m_segmentSize)*(0.113));
	segmentsAcked = (int) (0.1/0.1);

}
if (segmentsAcked == tcb->m_cWnd) {
	cnt = (int) (0.1/0.1);

} else {
	cnt = (int) (5.506+(40.597)+(81.182));
	segmentsAcked = (int) (44.899+(35.115)+(0.838)+(57.574)+(5.328)+(42.507)+(42.429)+(79.855)+(36.088));
	segmentsAcked = (int) (2.106-(67.827)-(tcb->m_ssThresh)-(62.264)-(44.12));

}
if (segmentsAcked <= segmentsAcked) {
	cnt = (int) (tcb->m_segmentSize*(28.39)*(50.982));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (segmentsAcked-(76.665)-(4.88)-(54.085)-(91.785)-(82.877)-(tcb->m_ssThresh));

}
tcb->m_segmentSize = (int) (36.254*(6.606)*(42.883)*(66.857)*(67.413)*(17.366));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
