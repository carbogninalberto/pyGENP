tcb->m_cWnd = (int) (86.618+(segmentsAcked)+(34.147));
if (segmentsAcked >= cnt) {
	tcb->m_ssThresh = (int) ((73.624*(cnt)*(92.455)*(cnt))/0.1);
	tcb->m_cWnd = (int) (((4.454)+(0.1)+(0.1)+((8.356*(cnt)*(19.716)))+(0.1)+(0.1)+(0.1))/((36.014)+(0.1)));
	tcb->m_segmentSize = (int) (83.657-(31.503)-(86.042)-(49.81)-(26.669));

} else {
	tcb->m_ssThresh = (int) (0.1/71.863);

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(72.043)+(tcb->m_ssThresh)+(48.777)+(segmentsAcked));
	tcb->m_segmentSize = (int) (((0.1)+(60.297)+(0.1)+(86.305))/((58.031)));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked+(28.78)+(tcb->m_cWnd)+(83.122)+(tcb->m_ssThresh)+(31.032));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (38.215-(72.089)-(70.143)-(83.288)-(21.744)-(91.097)-(24.449));

}
float fWbyIzoFmzQDWTUu = (float) (61.308*(27.896)*(33.571)*(71.703)*(3.617)*(11.537)*(88.195));
if (segmentsAcked != fWbyIzoFmzQDWTUu) {
	segmentsAcked = (int) (59.859*(fWbyIzoFmzQDWTUu)*(63.764)*(43.328)*(35.025)*(81.478));

} else {
	segmentsAcked = (int) (45.535*(24.601)*(75.539)*(44.982)*(65.025)*(38.529)*(tcb->m_segmentSize));
	segmentsAcked = (int) (52.088*(tcb->m_ssThresh)*(14.787));

}
cnt = (int) (56.67+(57.816)+(72.937)+(cnt));
tcb->m_cWnd = (int) (85.774-(segmentsAcked)-(13.419)-(32.949)-(0.65)-(97.478)-(73.285)-(52.764));
ReduceCwnd (tcb);
if (fWbyIzoFmzQDWTUu <= fWbyIzoFmzQDWTUu) {
	tcb->m_ssThresh = (int) (29.994-(tcb->m_ssThresh)-(cnt));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (18.884*(tcb->m_segmentSize)*(91.746)*(fWbyIzoFmzQDWTUu)*(segmentsAcked)*(88.434)*(91.356));
	tcb->m_ssThresh = (int) (((0.1)+(44.601)+(72.187)+(67.687)+(0.1)+(0.1))/((86.384)+(77.94)+(44.492)));
	ReduceCwnd (tcb);

}
