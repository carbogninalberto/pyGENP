ReduceCwnd (tcb);
int aSSKyUVRKboeGLcM = (int) (12.823*(cnt)*(segmentsAcked)*(segmentsAcked)*(25.815));
cnt = (int) (tcb->m_ssThresh-(59.727)-(tcb->m_cWnd)-(60.582)-(tcb->m_segmentSize)-(91.191));
tcb->m_cWnd = (int) (74.528*(1.864)*(73.35)*(68.768)*(64.899)*(95.048)*(5.372)*(83.956)*(79.263));
aSSKyUVRKboeGLcM = (int) (23.195+(76.417)+(28.515)+(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
