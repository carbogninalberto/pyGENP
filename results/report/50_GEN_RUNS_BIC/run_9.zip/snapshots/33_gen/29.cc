tcb->m_segmentSize = (int) (((0.1)+(7.996)+(68.753)+(30.347))/((0.1)+(0.1)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (33.46*(tcb->m_cWnd)*(13.859));
	tcb->m_ssThresh = (int) (((0.1)+(88.934)+(0.1)+(47.367)+(0.1))/((31.925)+(51.615)));

} else {
	tcb->m_cWnd = (int) (32.839*(75.587)*(tcb->m_segmentSize)*(88.208)*(99.474)*(23.294)*(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
segmentsAcked = (int) (76.69*(87.381)*(35.417));
