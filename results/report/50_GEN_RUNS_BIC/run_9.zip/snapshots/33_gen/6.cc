tcb->m_cWnd = (int) (95.669/0.1);
if (segmentsAcked > segmentsAcked) {
	tcb->m_cWnd = (int) (41.635+(17.02)+(23.273)+(54.097));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(cnt));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (90.107*(17.26)*(72.09)*(63.14));
	cnt = (int) (19.225+(56.892));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+((60.614+(51.815)+(52.842)+(14.561)+(53.934)+(19.156)+(95.543)+(50.924)))+(73.777))/((57.891)));

}
ReduceCwnd (tcb);
