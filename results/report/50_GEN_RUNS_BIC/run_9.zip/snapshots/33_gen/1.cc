segmentsAcked = (int) (31.983/51.975);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (58.873/-61.174);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
