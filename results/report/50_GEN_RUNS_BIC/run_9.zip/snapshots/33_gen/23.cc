ReduceCwnd (tcb);
if (tcb->m_segmentSize < cnt) {
	tcb->m_segmentSize = (int) (84.836/64.982);
	tcb->m_segmentSize = (int) (3.584*(tcb->m_cWnd)*(88.237)*(20.117)*(97.118)*(cnt)*(51.5)*(10.63));

} else {
	tcb->m_segmentSize = (int) ((((79.98-(tcb->m_ssThresh)-(9.399)-(53.4)-(62.831)-(7.664)-(20.736)))+(4.922)+(20.942)+(38.148)+(16.204)+(0.1))/((0.1)));
	tcb->m_cWnd = (int) (0.1/37.163);

}
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+((93.231-(75.805)-(tcb->m_segmentSize)))+(90.72)+(43.813)+(0.1))/((0.1)));
	segmentsAcked = (int) (88.542-(53.859)-(85.639)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (9.619*(54.623)*(42.456)*(23.71));

} else {
	tcb->m_segmentSize = (int) (5.46+(85.203)+(cnt)+(46.976)+(tcb->m_cWnd)+(segmentsAcked));

}
ReduceCwnd (tcb);
cnt = (int) (81.314-(65.065)-(tcb->m_cWnd));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
