if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (78.178+(92.082)+(23.82)+(4.335));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(87.358)+(81.411)+(56.581)+(3.665)+(87.388));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (17.564+(38.083)+(10.551)+(tcb->m_ssThresh)+(86.823)+(3.486)+(cnt)+(56.788)+(91.437));
