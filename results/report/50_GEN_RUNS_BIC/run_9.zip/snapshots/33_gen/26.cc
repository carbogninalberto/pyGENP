segmentsAcked = (int) (83.715+(tcb->m_cWnd)+(7.22)+(cnt)+(tcb->m_cWnd)+(91.895)+(57.109));
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (0.1/19.992);
	tcb->m_cWnd = (int) (42.722+(tcb->m_segmentSize)+(68.659)+(79.11)+(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (72.467*(22.931)*(91.921)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(91.539)*(21.244)*(52.547));

} else {
	tcb->m_segmentSize = (int) (30.289+(33.207)+(25.316));

}
tcb->m_cWnd = (int) (50.889*(segmentsAcked)*(86.915)*(61.495));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
