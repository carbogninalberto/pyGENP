if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_segmentSize = (int) (85.294+(10.0));
	tcb->m_ssThresh = (int) (62.371-(11.684)-(58.661)-(75.703)-(15.874)-(0.833)-(87.966));

} else {
	tcb->m_segmentSize = (int) (cnt-(71.346)-(84.353)-(38.957)-(58.897)-(4.365)-(19.421));
	tcb->m_cWnd = (int) (2.313*(tcb->m_ssThresh));

}
if (tcb->m_ssThresh >= cnt) {
	cnt = (int) (10.862-(29.632)-(segmentsAcked)-(99.701)-(62.91)-(89.567));

} else {
	cnt = (int) ((88.87-(10.042)-(segmentsAcked)-(69.868)-(segmentsAcked)-(4.24)-(33.084)-(29.063)-(16.637))/48.611);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt > segmentsAcked) {
	segmentsAcked = (int) (80.256*(31.219)*(27.614)*(16.228)*(16.694)*(9.523)*(33.288)*(segmentsAcked)*(31.851));

} else {
	segmentsAcked = (int) (59.277+(91.57)+(67.263));
	tcb->m_ssThresh = (int) (60.108+(28.317)+(39.641)+(71.452)+(11.936)+(5.59)+(35.924));
	tcb->m_cWnd = (int) (80.155-(66.448)-(49.006)-(tcb->m_segmentSize));

}
segmentsAcked = (int) (8.247-(tcb->m_segmentSize)-(14.363)-(75.947)-(48.461)-(83.723)-(89.391));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	cnt = (int) (34.978-(92.712)-(cnt)-(67.107)-(41.408)-(93.821)-(tcb->m_segmentSize)-(11.611)-(51.089));
	cnt = (int) (22.485+(75.16)+(50.467)+(17.282)+(66.825)+(cnt)+(68.885)+(52.818));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (34.1+(84.141)+(45.918)+(85.891)+(98.291));
	tcb->m_cWnd = (int) (32.113+(94.552)+(95.776)+(36.578)+(14.603)+(68.419)+(26.704));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
