ReduceCwnd (tcb);
if (tcb->m_cWnd == cnt) {
	tcb->m_segmentSize = (int) (44.029+(45.594)+(21.103)+(31.024)+(7.778));

} else {
	tcb->m_segmentSize = (int) (cnt*(56.048)*(33.972));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
int UfJcGRykIdGQOFll = (int) ((((cnt+(30.318)+(35.707)+(8.723)+(3.093)))+(81.056)+(0.1)+(0.1))/((0.1)+(0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
