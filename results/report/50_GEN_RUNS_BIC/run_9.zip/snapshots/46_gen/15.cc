tcb->m_ssThresh = (int) (segmentsAcked+(10.792)+(81.585)+(segmentsAcked)+(64.138));
float eUwhZUEVcAhEjNmg = (float) (71.723*(9.041)*(92.905)*(cnt)*(45.217)*(cnt)*(19.966)*(cnt)*(74.336));
tcb->m_ssThresh = (int) (39.016*(47.797)*(77.823)*(99.587));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) ((19.633*(10.842)*(21.878)*(segmentsAcked)*(87.34)*(68.895)*(43.351))/63.457);
	tcb->m_cWnd = (int) (19.421*(61.971)*(34.484)*(90.954)*(76.623)*(tcb->m_segmentSize)*(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked+(82.237)+(68.216)+(69.001)+(20.261)+(59.346)+(segmentsAcked)+(93.484));
	segmentsAcked = (int) (22.484*(41.889)*(73.518)*(64.817)*(26.949)*(75.507)*(82.795)*(76.944));

}
ReduceCwnd (tcb);
