ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_cWnd = (int) (99.768-(74.561)-(20.907)-(89.443)-(cnt)-(80.723)-(20.603)-(59.719)-(39.243));
	tcb->m_ssThresh = (int) (80.495/0.1);
	tcb->m_cWnd = (int) (41.24-(tcb->m_segmentSize)-(24.923)-(tcb->m_segmentSize)-(98.019)-(0.864)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (42.948+(48.896)+(8.207)+(42.089)+(41.454)+(14.009)+(3.642)+(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (65.139+(segmentsAcked)+(66.031)+(3.744)+(66.001)+(85.66));
	cnt = (int) (tcb->m_ssThresh-(tcb->m_ssThresh)-(cnt)-(95.75)-(60.416)-(71.101)-(32.755));

}
if (tcb->m_segmentSize != cnt) {
	tcb->m_ssThresh = (int) (50.155-(73.942)-(51.904)-(63.976)-(14.889));

} else {
	tcb->m_ssThresh = (int) (64.501+(9.421)+(8.772)+(7.047)+(98.802)+(22.301)+(tcb->m_ssThresh)+(85.353));
	tcb->m_ssThresh = (int) (cnt-(95.097)-(23.817)-(76.614)-(64.484)-(39.02)-(2.431)-(8.735)-(95.475));

}
tcb->m_cWnd = (int) (tcb->m_segmentSize*(18.983)*(64.646)*(15.722)*(97.442)*(10.172));
if (tcb->m_segmentSize != cnt) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (68.906-(8.57)-(88.833)-(0.129)-(67.315)-(tcb->m_segmentSize)-(35.318)-(78.561));

} else {
	tcb->m_segmentSize = (int) (((0.1)+((96.345+(16.941)+(91.733)+(11.536)+(9.109)+(tcb->m_cWnd)+(tcb->m_cWnd)+(28.179)))+(0.1)+(0.1))/((50.984)+(78.22)));
	segmentsAcked = (int) ((0.125+(62.718)+(35.753)+(12.038)+(56.777)+(cnt)+(84.942))/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
