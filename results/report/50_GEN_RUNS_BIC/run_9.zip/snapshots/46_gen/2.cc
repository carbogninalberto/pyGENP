tcb->m_segmentSize = (int) (((0.1)+(5.326)+(98.599)+(0.1))/((62.435)+(0.1)+(92.357)));
float lQpnJmEhynRPQuXX = (float) (66.086*(65.883)*(26.951)*(81.956)*(cnt)*(42.954)*(61.26));
lQpnJmEhynRPQuXX = (float) (22.738+(83.831)+(tcb->m_segmentSize)+(5.539)+(40.257)+(17.133)+(80.306));
if (lQpnJmEhynRPQuXX >= cnt) {
	tcb->m_ssThresh = (int) (74.688*(67.167)*(cnt)*(cnt)*(tcb->m_cWnd)*(45.296));
	tcb->m_segmentSize = (int) (9.721*(tcb->m_cWnd)*(53.556));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (9.301*(86.83));

}
if (cnt == tcb->m_segmentSize) {
	cnt = (int) (42.729*(63.337)*(39.974)*(76.745)*(72.057));
	tcb->m_cWnd = (int) (0.1/41.276);

} else {
	cnt = (int) (20.193*(tcb->m_segmentSize)*(88.252)*(62.617)*(44.502)*(62.921)*(tcb->m_ssThresh)*(14.599));

}
if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(tcb->m_cWnd)-(43.832));

} else {
	tcb->m_ssThresh = (int) (0.1/85.147);
	segmentsAcked = (int) (62.967-(63.51)-(76.427)-(68.404)-(5.696)-(59.828)-(14.305)-(79.998));

}
