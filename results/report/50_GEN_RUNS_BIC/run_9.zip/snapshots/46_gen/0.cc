int SItDWPlReWMuBHbJ = (int) (6.303+(14.216)+(-63.3));
