tcb->m_segmentSize = (int) (94.896+(33.183)+(82.395)+(41.816)+(74.774)+(cnt)+(46.774));
if (segmentsAcked <= tcb->m_cWnd) {
	cnt = (int) (36.928+(tcb->m_cWnd)+(17.183)+(32.719)+(35.715)+(24.794)+(73.596));

} else {
	cnt = (int) (55.919*(cnt)*(83.723)*(96.41)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(12.898));
	tcb->m_cWnd = (int) (((35.87)+(0.1)+(0.1)+(47.073))/((45.854)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize < cnt) {
	segmentsAcked = (int) (99.176*(40.668)*(cnt)*(tcb->m_segmentSize)*(2.025)*(segmentsAcked)*(65.473)*(60.358));
	tcb->m_segmentSize = (int) (56.716*(93.728)*(67.332)*(17.026)*(52.984)*(64.464)*(24.278));
	tcb->m_cWnd = (int) (23.619+(83.019)+(40.804)+(31.158));

} else {
	segmentsAcked = (int) (cnt+(25.458)+(82.408)+(61.0)+(88.194)+(41.935)+(89.467));
	tcb->m_segmentSize = (int) (42.606+(7.094)+(1.357)+(83.293)+(51.925));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
