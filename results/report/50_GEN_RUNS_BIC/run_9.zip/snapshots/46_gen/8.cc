ReduceCwnd (tcb);
if (cnt <= segmentsAcked) {
	segmentsAcked = (int) (2.446-(tcb->m_cWnd)-(94.733)-(22.609)-(4.181)-(58.9)-(3.841)-(tcb->m_ssThresh)-(63.958));
	cnt = (int) (((0.1)+((56.939+(91.981)+(35.905)))+(0.1)+(99.241)+((75.113-(58.478)-(tcb->m_cWnd)-(15.714)))+(0.1))/((6.708)+(14.976)));

} else {
	segmentsAcked = (int) (8.319/0.1);

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (0.1/74.806);
if (segmentsAcked < segmentsAcked) {
	segmentsAcked = (int) (71.193-(segmentsAcked)-(47.304));
	tcb->m_ssThresh = (int) (62.183*(13.753)*(52.368));

} else {
	segmentsAcked = (int) (segmentsAcked-(cnt));

}
if (tcb->m_cWnd == cnt) {
	cnt = (int) (77.018-(cnt)-(15.353));

} else {
	cnt = (int) (42.444-(87.94)-(85.931)-(37.325)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(tcb->m_segmentSize));

}
int KuobGakohTeuNDZe = (int) (((0.1)+(0.1)+(0.1)+(34.828)+(80.917)+(49.263))/((57.45)+(0.1)));
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (98.279*(71.319)*(28.792)*(28.93));

} else {
	tcb->m_ssThresh = (int) (29.217*(tcb->m_segmentSize)*(cnt)*(40.813)*(segmentsAcked)*(43.809));

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	cnt = (int) (tcb->m_segmentSize+(35.65)+(67.075)+(13.804)+(72.877)+(63.322)+(tcb->m_cWnd)+(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (58.777*(86.453));

} else {
	cnt = (int) (24.8/42.716);

}
