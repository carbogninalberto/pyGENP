ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (10.427-(38.568)-(11.123)-(70.644)-(tcb->m_segmentSize)-(7.681));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (82.791-(20.424)-(88.013)-(89.976)-(cnt));

}
segmentsAcked = (int) ((42.868-(95.77)-(tcb->m_segmentSize)-(1.301)-(cnt))/62.59);
if (tcb->m_cWnd > tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd-(26.101)-(29.866)-(32.21));
	tcb->m_cWnd = (int) (7.442-(83.393)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(44.851)-(44.123)-(24.112)-(27.062)-(47.973));
	tcb->m_segmentSize = (int) (65.433*(tcb->m_cWnd)*(52.958)*(cnt)*(52.838)*(88.704)*(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (72.481-(74.648)-(45.203)-(11.723));
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+((12.334*(23.133)*(12.163)*(25.765)*(cnt)*(6.259)))+(0.1)+(92.478))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (90.495*(55.339)*(72.722)*(68.48));
