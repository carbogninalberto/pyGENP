if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (tcb->m_cWnd*(95.174)*(28.443)*(3.594)*(78.319)*(15.514)*(13.845)*(73.944));
segmentsAcked = (int) (63.265*(11.752));
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (23.077+(43.753)+(1.442)+(79.379)+(tcb->m_cWnd)+(56.661));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (85.355/50.075);

}
if (tcb->m_ssThresh != cnt) {
	tcb->m_segmentSize = (int) (88.257*(segmentsAcked)*(tcb->m_ssThresh)*(18.934)*(14.435)*(tcb->m_segmentSize)*(62.677)*(57.904));
	tcb->m_ssThresh = (int) (((0.1)+(77.132)+(97.54)+(99.884)+(23.188)+(0.1))/((0.1)+(0.1)+(0.1)));
	segmentsAcked = (int) (0.1/56.376);

} else {
	tcb->m_segmentSize = (int) (19.177*(cnt));
	segmentsAcked = (int) (52.612*(95.031)*(76.338)*(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(34.053)-(41.743)-(segmentsAcked)-(31.595)-(45.233));

}
