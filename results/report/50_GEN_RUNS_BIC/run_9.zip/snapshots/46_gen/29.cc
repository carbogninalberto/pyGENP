ReduceCwnd (tcb);
int hoILlOYqfAvddPYw = (int) (((0.1)+(0.1)+((tcb->m_cWnd-(0.737)-(21.035)))+(0.1))/((40.208)+(0.1)));
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	hoILlOYqfAvddPYw = (int) (79.282*(50.825)*(38.299)*(tcb->m_ssThresh)*(83.074)*(51.125)*(20.375)*(36.922)*(99.003));
	segmentsAcked = (int) (tcb->m_cWnd-(38.012));

} else {
	hoILlOYqfAvddPYw = (int) (24.075/22.211);

}
if (tcb->m_ssThresh > hoILlOYqfAvddPYw) {
	cnt = (int) (21.969*(51.888)*(92.304)*(49.585));
	tcb->m_segmentSize = (int) (76.488*(22.781)*(61.045)*(63.798)*(1.845));
	tcb->m_segmentSize = (int) (23.194-(73.126)-(32.847)-(97.692)-(-0.072)-(75.365)-(hoILlOYqfAvddPYw)-(8.634)-(52.435));

} else {
	cnt = (int) (46.63*(tcb->m_ssThresh)*(68.997)*(tcb->m_cWnd)*(92.634)*(tcb->m_segmentSize));
	hoILlOYqfAvddPYw = (int) (7.092-(17.692)-(cnt)-(69.291));

}
tcb->m_ssThresh = (int) (72.305+(70.873)+(2.239)+(12.358)+(67.706)+(72.061)+(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (62.79*(90.416)*(38.982)*(tcb->m_cWnd));
