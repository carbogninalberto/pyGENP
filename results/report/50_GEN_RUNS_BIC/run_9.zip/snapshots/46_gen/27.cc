if (cnt == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((38.801)+(29.545)+(0.1)+(0.1)+(0.1)+(73.319))/((27.603)+(19.571)+(0.1)));
	tcb->m_ssThresh = (int) (0.1/(19.743+(24.101)+(66.46)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(53.397)+(32.961)));
	tcb->m_segmentSize = (int) (0.1/17.823);

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (39.785+(82.882)+(72.053)+(97.054)+(segmentsAcked)+(51.794));

} else {
	tcb->m_cWnd = (int) (18.898+(30.346)+(29.569)+(tcb->m_segmentSize)+(12.822)+(32.606)+(6.249));

}
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (36.436-(38.603)-(53.445)-(cnt)-(tcb->m_cWnd)-(cnt)-(17.821)-(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (24.586+(83.315)+(99.74));

} else {
	tcb->m_cWnd = (int) (67.71*(66.959)*(53.607)*(55.346)*(20.219)*(81.839)*(79.609)*(39.941)*(2.125));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (97.484+(cnt)+(25.217)+(39.427)+(24.062)+(segmentsAcked)+(53.101)+(5.074));

}
segmentsAcked = (int) (6.632-(51.027)-(56.262)-(94.99)-(97.837)-(tcb->m_segmentSize)-(cnt)-(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (38.22/21.253);
if (tcb->m_ssThresh == cnt) {
	cnt = (int) (0.1/0.1);

} else {
	cnt = (int) (42.243+(77.007)+(tcb->m_segmentSize)+(78.965));
	tcb->m_cWnd = (int) (0.1/43.462);

}
