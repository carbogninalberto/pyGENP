ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (96.809*(74.024)*(segmentsAcked)*(49.258)*(45.078)*(29.181));
float ATEFxPhvDYGljydc = (float) (tcb->m_cWnd+(8.813)+(tcb->m_segmentSize));
segmentsAcked = (int) (20.35-(2.036));
ReduceCwnd (tcb);
