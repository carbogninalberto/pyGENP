tcb->m_segmentSize = (int) (60.288/0.1);
int NPfSlGtdsyfNzBrA = (int) (90.94-(tcb->m_cWnd)-(38.597)-(43.999)-(23.602));
tcb->m_cWnd = (int) (73.58/32.222);
tcb->m_ssThresh = (int) (0.1/62.149);
if (tcb->m_ssThresh > NPfSlGtdsyfNzBrA) {
	cnt = (int) (0.1/76.649);

} else {
	cnt = (int) (38.881-(40.928)-(96.5)-(93.449));
	NPfSlGtdsyfNzBrA = (int) (82.629*(29.218));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
