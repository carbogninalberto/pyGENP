if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (37.702+(16.755)+(tcb->m_ssThresh)+(97.768));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (-0.011-(92.076)-(segmentsAcked)-(89.994)-(62.131));

} else {
	tcb->m_cWnd = (int) (37.103+(44.039)+(92.575)+(tcb->m_segmentSize)+(31.022)+(55.024)+(74.797));
	ReduceCwnd (tcb);

}
cnt = (int) (20.604-(tcb->m_ssThresh)-(46.203));
cnt = (int) (49.553-(58.989)-(segmentsAcked)-(tcb->m_ssThresh)-(cnt)-(segmentsAcked)-(96.412));
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (93.566+(7.141)+(2.31));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (16.657*(15.569)*(35.194)*(76.419)*(39.839));

} else {
	tcb->m_ssThresh = (int) (10.448*(18.273)*(3.584)*(0.622)*(87.337)*(25.791)*(83.886)*(35.073));

}
tcb->m_cWnd = (int) (46.71+(50.086)+(32.148)+(21.58));
