if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (80.704-(5.944)-(66.601)-(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (53.14+(48.678)+(cnt)+(21.961)+(cnt));
	ReduceCwnd (tcb);

}
if (segmentsAcked == tcb->m_cWnd) {
	segmentsAcked = (int) (12.518+(30.968)+(14.86));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((58.109)+(74.185)+(0.1)+(0.1)+((79.887-(tcb->m_cWnd)-(83.942)))+(0.1))/((0.1)+(35.149)+(0.1)));

}
if (tcb->m_segmentSize > tcb->m_cWnd) {
	cnt = (int) (83.16+(36.475)+(52.725)+(23.769));
	segmentsAcked = (int) (48.999+(78.619)+(95.342)+(65.543)+(69.281));
	segmentsAcked = (int) (((15.039)+(85.389)+(0.1)+((6.12+(cnt)+(0.902)+(56.795)+(40.306)+(34.154)+(5.611)))+(12.013))/((75.62)));

} else {
	cnt = (int) (((60.878)+(89.686)+((32.365*(71.355)))+((cnt*(49.334)*(22.198)*(tcb->m_segmentSize)*(35.922)*(94.901)*(94.901)*(cnt)*(21.327)))+(0.1)+(0.1))/((0.1)+(3.846)));
	cnt = (int) (7.985*(1.711)*(95.232)*(tcb->m_cWnd));

}
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (59.245-(9.905)-(46.628)-(tcb->m_segmentSize)-(94.895)-(75.63)-(29.755)-(81.246)-(88.082));

} else {
	tcb->m_cWnd = (int) (87.799+(46.001)+(28.058)+(6.67)+(69.986));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (((80.983)+(0.1)+((74.491*(36.514)*(84.299)*(25.925)))+((1.936-(24.475)-(27.671)-(27.537)-(96.719)-(82.865)-(93.238)))+(0.1)+(6.031)+(0.1))/((89.091)+(0.1)));

}
tcb->m_segmentSize = (int) (64.344*(5.863)*(17.268)*(15.733)*(tcb->m_cWnd)*(69.439));
