if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (8.594-(95.611)-(83.077)-(29.268)-(38.897)-(tcb->m_ssThresh)-(55.717)-(14.644));
	tcb->m_segmentSize = (int) (60.465-(56.789)-(segmentsAcked)-(tcb->m_cWnd)-(44.175)-(58.632));
	tcb->m_segmentSize = (int) (71.198+(tcb->m_ssThresh)+(segmentsAcked)+(28.362)+(tcb->m_segmentSize)+(0.576)+(91.224)+(65.895));

} else {
	tcb->m_ssThresh = (int) (((44.287)+(0.1)+(49.446)+(42.261)+(0.1))/((0.1)));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	cnt = (int) (0.525+(72.761)+(2.204)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(32.369)+(24.115)+(25.455)+(54.91));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(24.755)+(tcb->m_segmentSize)+(10.334)+(40.418)+(85.057)+(53.307));
	tcb->m_ssThresh = (int) (15.67+(80.352));

} else {
	cnt = (int) (((51.455)+(0.1)+((60.085+(43.39)+(13.74)+(28.12)+(tcb->m_ssThresh)+(16.842)+(36.104)))+(0.1))/((49.852)));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (18.601/74.633);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int gVkPSmtkBadsiBWQ = (int) (4.405+(46.728)+(94.511)+(15.414)+(9.189)+(90.088));
if (cnt > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (54.946+(30.021)+(9.142)+(61.923)+(97.154));

} else {
	tcb->m_ssThresh = (int) (54.343+(37.342)+(tcb->m_segmentSize)+(gVkPSmtkBadsiBWQ)+(1.64)+(58.312)+(gVkPSmtkBadsiBWQ)+(40.048)+(51.827));
	cnt = (int) (((60.697)+(0.1)+(3.82)+(0.1))/((0.1)+(0.1)+(92.372)));
	segmentsAcked = (int) (tcb->m_ssThresh*(72.131)*(gVkPSmtkBadsiBWQ)*(47.786));

}
segmentsAcked = (int) (47.436*(66.278)*(49.419)*(58.088)*(38.738)*(54.838)*(10.764)*(32.658)*(92.313));
