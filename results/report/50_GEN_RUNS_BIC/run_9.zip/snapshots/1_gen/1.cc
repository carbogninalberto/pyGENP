if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((84.784)+((97.877+(tcb->m_segmentSize)))+((94.461-(86.184)-(tcb->m_segmentSize)-(80.261)-(12.682)-(50.974)-(35.929)))+(0.1)+(34.059))/((91.354)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (20.562+(51.865));

} else {
	tcb->m_ssThresh = (int) (88.579*(41.076)*(99.885)*(cnt));
	tcb->m_ssThresh = (int) (69.955-(5.625)-(17.063)-(67.398)-(68.038)-(97.804));
	cnt = (int) (37.251*(tcb->m_cWnd));

}
if (tcb->m_ssThresh > cnt) {
	tcb->m_cWnd = (int) (((18.51)+(43.198)+(23.975)+(55.352)+(64.299)+(4.933))/((0.1)+(0.1)+(0.1)));

} else {
	tcb->m_cWnd = (int) (60.052+(55.923));
	cnt = (int) (62.081*(64.948)*(99.733)*(94.365)*(84.002));

}
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (20.908/44.052);

} else {
	tcb->m_segmentSize = (int) (1.428+(tcb->m_segmentSize)+(29.113)+(21.688)+(91.784)+(60.909)+(cnt)+(66.562));

}
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (2.365*(segmentsAcked)*(4.652)*(16.347)*(91.076)*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (((54.328)+(0.1)+(0.1)+(0.1))/((74.634)));
	segmentsAcked = (int) (9.686+(84.667)+(78.906)+(93.612)+(50.034)+(79.359)+(40.949)+(54.762)+(32.533));

}
