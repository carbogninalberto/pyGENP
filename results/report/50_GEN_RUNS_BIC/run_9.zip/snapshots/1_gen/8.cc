if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (4.138*(60.57)*(28.265)*(34.432)*(1.503)*(tcb->m_segmentSize)*(62.616)*(20.632)*(tcb->m_segmentSize));
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (cnt*(segmentsAcked)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(20.041)*(8.157));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (96.254*(8.691)*(0.361)*(53.866)*(19.707)*(11.645)*(tcb->m_cWnd)*(2.359)*(27.619));
	cnt = (int) (25.359/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (5.874-(47.663)-(72.342)-(98.914)-(53.575)-(86.334)-(95.367)-(43.314));
	tcb->m_cWnd = (int) (35.084-(87.019)-(0.358)-(13.147)-(96.558)-(3.453)-(40.739)-(56.538)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (52.241+(segmentsAcked));

}
