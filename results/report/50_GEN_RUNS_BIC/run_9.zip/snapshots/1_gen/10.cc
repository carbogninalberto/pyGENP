if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(65.695)-(98.748)-(tcb->m_cWnd)-(82.58)-(7.401)-(tcb->m_segmentSize));
	ReduceCwnd (tcb);
	cnt = (int) (20.04-(84.751)-(48.936)-(15.826)-(48.121)-(tcb->m_segmentSize)-(80.177));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(32.238)+(41.84)+(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (91.008*(31.424)*(4.405)*(16.616));

}
tcb->m_ssThresh = (int) (57.754*(90.42));
ReduceCwnd (tcb);
int CxoCtZarEzWbYpTL = (int) (8.615-(36.55)-(76.185)-(65.448)-(58.775)-(tcb->m_ssThresh)-(50.558)-(30.611)-(segmentsAcked));
cnt = (int) ((78.13*(53.315)*(60.285)*(95.289)*(30.465)*(62.534)*(29.058)*(90.49)*(97.619))/89.224);
CxoCtZarEzWbYpTL = (int) (CxoCtZarEzWbYpTL-(45.045)-(10.639)-(71.999)-(25.832)-(tcb->m_ssThresh)-(74.385));
tcb->m_segmentSize = (int) ((78.55+(cnt)+(57.626)+(99.746)+(36.437)+(69.177)+(56.013)+(31.376))/0.1);
tcb->m_segmentSize = (int) (((70.315)+(16.421)+(0.1)+(71.995)+(0.1)+(15.821)+(0.1))/((0.1)+(94.198)));
if (tcb->m_cWnd == tcb->m_cWnd) {
	CxoCtZarEzWbYpTL = (int) (68.693+(25.025)+(63.114)+(84.45)+(51.946));

} else {
	CxoCtZarEzWbYpTL = (int) (tcb->m_ssThresh+(9.574)+(49.251));

}
