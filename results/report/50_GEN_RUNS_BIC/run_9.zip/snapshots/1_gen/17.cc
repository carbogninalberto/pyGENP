ReduceCwnd (tcb);
if (tcb->m_cWnd == segmentsAcked) {
	cnt = (int) (14.505-(55.618)-(21.747)-(7.211)-(97.285)-(tcb->m_segmentSize)-(14.551)-(95.961));

} else {
	cnt = (int) (73.479+(7.684)+(0.348)+(49.777)+(tcb->m_cWnd)+(98.459)+(74.917)+(43.929));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_cWnd = (int) (-0.073-(78.693)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(71.128)-(55.624));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (25.647/(tcb->m_cWnd+(41.404)+(5.963)+(tcb->m_cWnd)+(tcb->m_cWnd)+(75.415)+(tcb->m_ssThresh)+(32.728)));
	tcb->m_cWnd = (int) (0.1/65.358);
	tcb->m_cWnd = (int) (64.935-(9.759)-(66.149)-(9.45)-(41.076)-(69.87)-(24.397)-(37.623)-(cnt));

} else {
	tcb->m_segmentSize = (int) (37.545+(78.734)+(69.783)+(17.428));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(22.077)+(57.075));

}
segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(48.51))/((0.1)));
float ikrmPOpUvNCirntJ = (float) (9.65*(78.259)*(79.158)*(99.732)*(22.048));
ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_ssThresh) {
	ikrmPOpUvNCirntJ = (float) (66.785+(14.195)+(88.825));
	ReduceCwnd (tcb);

} else {
	ikrmPOpUvNCirntJ = (float) (67.846+(51.822)+(ikrmPOpUvNCirntJ)+(tcb->m_cWnd)+(78.311)+(tcb->m_cWnd)+(50.349)+(tcb->m_segmentSize));
	ReduceCwnd (tcb);

}
