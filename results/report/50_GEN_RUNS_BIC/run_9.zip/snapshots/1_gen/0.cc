ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (90.149*(59.583)*(89.946)*(23.293)*(69.773)*(50.725));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (97.817*(tcb->m_ssThresh)*(6.521)*(45.086)*(65.44));
	tcb->m_ssThresh = (int) (26.484*(35.179)*(39.338)*(98.807)*(83.726)*(12.902)*(68.555)*(67.837)*(48.79));

} else {
	tcb->m_ssThresh = (int) (90.576+(cnt)+(83.433)+(segmentsAcked)+(92.782));
	tcb->m_ssThresh = (int) (18.087+(73.332)+(tcb->m_segmentSize)+(cnt)+(94.169)+(50.28)+(96.764));

}
cnt = (int) (((99.712)+(82.424)+((90.894*(5.78)*(28.631)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(segmentsAcked)*(31.146)*(66.127)*(29.254)))+((86.755*(tcb->m_ssThresh)*(97.182)*(tcb->m_cWnd)*(16.942)*(tcb->m_ssThresh)*(67.07)*(11.763)*(27.042)))+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)));
segmentsAcked = (int) (2.258-(cnt)-(89.18)-(5.576)-(96.748)-(tcb->m_ssThresh)-(23.837)-(8.494));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	cnt = (int) (0.1/0.1);
	segmentsAcked = (int) (47.286-(cnt)-(69.549)-(98.471)-(27.978)-(tcb->m_cWnd)-(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (70.819*(cnt));
	cnt = (int) (30.794*(cnt)*(10.514)*(25.203)*(16.15)*(33.535)*(35.243)*(40.194));
	tcb->m_cWnd = (int) (55.897-(46.954)-(31.124)-(73.164)-(tcb->m_cWnd)-(85.917)-(87.185)-(20.377));

}
