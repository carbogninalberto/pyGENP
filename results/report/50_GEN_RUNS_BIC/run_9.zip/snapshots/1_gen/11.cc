float JQrfGwCdkfAhFJXW = (float) (32.857*(74.779)*(89.327)*(tcb->m_ssThresh));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_ssThresh = (int) (69.825+(98.088)+(23.866));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (JQrfGwCdkfAhFJXW+(tcb->m_ssThresh)+(5.052));

}
segmentsAcked = (int) (73.776/28.572);
ReduceCwnd (tcb);
