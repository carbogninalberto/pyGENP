segmentsAcked = (int) (0.1/0.1);
float MXxHwuhHeoZaibOx = (float) (tcb->m_segmentSize+(57.794));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_ssThresh < MXxHwuhHeoZaibOx) {
	tcb->m_ssThresh = (int) (75.961-(93.345)-(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (23.086+(53.2)+(59.792)+(tcb->m_cWnd)+(5.779)+(48.801)+(68.825));
	tcb->m_ssThresh = (int) (47.281*(22.488)*(57.467)*(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh > cnt) {
	segmentsAcked = (int) (49.551+(88.887)+(74.377)+(tcb->m_cWnd)+(85.667)+(15.381)+(15.968)+(MXxHwuhHeoZaibOx)+(79.338));

} else {
	segmentsAcked = (int) (6.913-(65.5)-(39.39)-(50.973));

}
tcb->m_segmentSize = (int) (67.639+(85.869)+(38.924)+(67.071)+(31.141));
