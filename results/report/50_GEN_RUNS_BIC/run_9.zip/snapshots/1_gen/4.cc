if (tcb->m_cWnd != cnt) {
	tcb->m_segmentSize = (int) (58.886/63.19);

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(98.549)-(87.434)-(81.02)-(36.766));

}
if (tcb->m_segmentSize >= cnt) {
	tcb->m_ssThresh = (int) (2.031+(72.85)+(tcb->m_segmentSize)+(79.876));
	tcb->m_segmentSize = (int) (86.992-(49.999)-(50.961)-(75.101)-(16.029)-(63.802));

} else {
	tcb->m_ssThresh = (int) (97.566/19.241);
	segmentsAcked = (int) (0.1/0.1);

}
if (tcb->m_cWnd <= cnt) {
	tcb->m_cWnd = (int) (60.16-(54.204));
	tcb->m_segmentSize = (int) (9.074/0.1);
	segmentsAcked = (int) (segmentsAcked+(47.483)+(30.339));

} else {
	tcb->m_cWnd = (int) (14.723/4.823);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(41.197));

}
if (tcb->m_segmentSize > tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_ssThresh-(65.301)-(66.579)-(77.832)-(56.482)-(47.072)-(segmentsAcked)-(67.82));
	tcb->m_cWnd = (int) (72.501*(58.138));

} else {
	segmentsAcked = (int) (68.52-(14.382)-(82.851)-(cnt)-(48.157)-(32.21)-(42.645)-(48.22));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (25.002+(38.655)+(27.971)+(tcb->m_cWnd)+(51.889)+(63.273)+(segmentsAcked)+(70.342)+(54.225));

} else {
	tcb->m_ssThresh = (int) ((((70.882+(39.302)+(85.956)+(83.622)+(66.834)+(96.947)+(31.798)+(segmentsAcked)+(79.321)))+((72.322+(67.877)+(84.868)+(99.25)+(8.669)+(tcb->m_ssThresh)+(48.456)))+(20.702)+(0.1))/((0.1)+(73.139)+(0.1)));
	ReduceCwnd (tcb);

}
