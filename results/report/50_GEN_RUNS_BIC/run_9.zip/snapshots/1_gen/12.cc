ReduceCwnd (tcb);
int GutUBdXezdeJLGoT = (int) (59.739+(29.711)+(segmentsAcked)+(35.019)+(cnt)+(2.627)+(62.821)+(51.017)+(7.195));
tcb->m_cWnd = (int) (2.458*(4.95)*(tcb->m_segmentSize)*(99.805));
GutUBdXezdeJLGoT = (int) (1.567*(90.448)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(GutUBdXezdeJLGoT)*(32.467)*(21.058)*(tcb->m_ssThresh)*(GutUBdXezdeJLGoT));
GutUBdXezdeJLGoT = (int) (0.1/0.1);
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (84.326+(14.929)+(tcb->m_ssThresh)+(31.67)+(38.816));

} else {
	tcb->m_cWnd = (int) (81.481/0.1);
	GutUBdXezdeJLGoT = (int) (segmentsAcked+(62.114));

}
segmentsAcked = (int) (94.161+(52.506)+(86.91)+(tcb->m_cWnd)+(61.073)+(63.071)+(17.015)+(19.674)+(10.668));
if (tcb->m_cWnd <= cnt) {
	cnt = (int) (28.218/0.1);
	segmentsAcked = (int) (87.802-(32.198));

} else {
	cnt = (int) (64.587*(63.155));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
