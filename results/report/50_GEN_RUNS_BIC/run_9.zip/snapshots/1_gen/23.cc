cnt = (int) (89.587-(93.978));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
float oTTOgkvnoRMsZlKS = (float) (47.358-(99.004));
tcb->m_segmentSize = (int) (((55.293)+(0.1)+(0.1)+(0.1)+(0.1)+(0.1)+(0.1)+(79.031))/((9.202)));
oTTOgkvnoRMsZlKS = (float) (tcb->m_segmentSize+(37.868)+(62.959)+(0.425)+(tcb->m_cWnd)+(90.023)+(12.973));
if (tcb->m_segmentSize > oTTOgkvnoRMsZlKS) {
	tcb->m_ssThresh = (int) (68.687-(58.051));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (0.1/75.691);

}
oTTOgkvnoRMsZlKS = (float) (82.643-(tcb->m_segmentSize)-(21.59)-(95.797)-(11.926));
