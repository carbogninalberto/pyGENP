ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (13.745*(38.651)*(81.03)*(tcb->m_segmentSize)*(5.535));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (6.99+(61.603)+(52.707));
	cnt = (int) (53.155-(cnt)-(segmentsAcked));
	tcb->m_ssThresh = (int) (33.241+(23.967));

}
int QXoZVLHypMlCzTck = (int) (24.763-(29.966)-(12.402));
if (segmentsAcked <= cnt) {
	cnt = (int) (12.102*(45.923)*(69.98));

} else {
	cnt = (int) (68.781-(99.335)-(16.605)-(56.931)-(56.916)-(80.206));
	tcb->m_segmentSize = (int) (36.216-(45.391)-(QXoZVLHypMlCzTck));
	ReduceCwnd (tcb);

}
if (QXoZVLHypMlCzTck != QXoZVLHypMlCzTck) {
	tcb->m_ssThresh = (int) (46.191+(60.034)+(tcb->m_segmentSize)+(33.693)+(27.858)+(segmentsAcked)+(24.902)+(0.163));
	cnt = (int) (73.523+(87.96)+(tcb->m_segmentSize)+(25.819)+(43.975));

} else {
	tcb->m_ssThresh = (int) (14.34-(16.61)-(43.913));

}
ReduceCwnd (tcb);
cnt = (int) ((((50.123*(21.314)*(tcb->m_ssThresh)*(84.164)))+(0.1)+((QXoZVLHypMlCzTck-(23.327)-(segmentsAcked)-(19.425)-(63.983)-(51.348)-(tcb->m_cWnd)))+(0.1))/((95.284)+(10.467)));
