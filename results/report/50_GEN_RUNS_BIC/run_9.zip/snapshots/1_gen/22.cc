if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_cWnd = (int) (14.943*(cnt)*(21.177));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(59.112)+(29.761)+(85.719)+(cnt)+(12.277)+(tcb->m_segmentSize));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (46.618+(38.742)+(tcb->m_cWnd)+(97.144)+(cnt));

}
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (74.506-(88.704)-(24.985)-(76.382)-(3.648)-(18.672)-(96.418)-(45.513));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (0.262*(35.299)*(99.228)*(10.782)*(15.51)*(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) ((12.141+(tcb->m_ssThresh))/96.961);

}
cnt = (int) (81.853+(62.914));
if (cnt < tcb->m_cWnd) {
	segmentsAcked = (int) (14.836-(42.652)-(87.008)-(98.361)-(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (0.1/0.1);
	cnt = (int) (21.811+(tcb->m_segmentSize)+(tcb->m_cWnd)+(84.876)+(6.376)+(36.485)+(segmentsAcked)+(92.494));

} else {
	segmentsAcked = (int) (27.653+(71.976)+(21.687)+(60.923)+(45.671)+(35.426));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (71.998+(74.007));
if (tcb->m_cWnd < cnt) {
	tcb->m_ssThresh = (int) (26.117-(71.175)-(77.099)-(tcb->m_ssThresh)-(68.492)-(4.453)-(12.613)-(25.538)-(45.96));
	tcb->m_ssThresh = (int) (segmentsAcked-(tcb->m_ssThresh)-(0.146)-(70.595)-(70.308));
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(35.077)+(33.147)+(28.396));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(14.337)*(83.222)*(segmentsAcked)*(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(92.962));
segmentsAcked = (int) (tcb->m_cWnd-(57.819)-(93.653)-(39.885));
