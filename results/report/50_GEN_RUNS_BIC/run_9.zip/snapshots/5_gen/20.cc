tcb->m_cWnd = (int) (81.109/0.1);
if (segmentsAcked != tcb->m_cWnd) {
	cnt = (int) (22.938*(26.141)*(91.642)*(87.217)*(86.426)*(70.705)*(67.835)*(tcb->m_ssThresh));
	cnt = (int) (75.12+(segmentsAcked)+(59.962)+(87.305)+(53.38)+(tcb->m_segmentSize)+(43.263));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (41.104+(63.984)+(39.309)+(52.516)+(80.385));
	tcb->m_ssThresh = (int) (((0.1)+(18.01)+(0.1)+(46.702)+(0.1)+(0.1))/((0.1)+(23.658)));
	cnt = (int) (cnt+(tcb->m_ssThresh)+(66.894)+(77.847)+(91.09));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (((0.1)+(20.332)+(0.1)+(59.525)+(68.974))/((81.819)));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (49.685-(99.404)-(segmentsAcked)-(84.832)-(74.206)-(82.901));
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(34.055)+(63.628)+(20.188));

} else {
	tcb->m_cWnd = (int) (77.603/64.63);
	tcb->m_cWnd = (int) (97.159/86.349);

}
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (44.151+(22.974)+(45.451)+(24.924)+(51.899)+(42.705)+(50.272));

} else {
	tcb->m_cWnd = (int) ((tcb->m_cWnd+(31.933)+(37.375)+(10.051)+(43.19))/29.367);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
