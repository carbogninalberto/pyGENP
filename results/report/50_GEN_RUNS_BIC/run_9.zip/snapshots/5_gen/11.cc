segmentsAcked = (int) (-26.736+(16.903)+(-92.777)+(45.516)+(-15.308)+(-40.727)+(-84.759));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-74.424-(-35.831)-(1.663)-(-6.098)-(-5.209));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
