tcb->m_ssThresh = (int) (segmentsAcked-(tcb->m_ssThresh)-(59.146)-(94.444)-(26.968));
ReduceCwnd (tcb);
if (cnt <= cnt) {
	cnt = (int) (43.173+(95.74));
	tcb->m_cWnd = (int) (43.257-(28.237));

} else {
	cnt = (int) (65.26+(56.469)+(26.156)+(14.389)+(23.826)+(13.986)+(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (67.889+(63.568)+(99.94)+(62.182)+(94.678));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
