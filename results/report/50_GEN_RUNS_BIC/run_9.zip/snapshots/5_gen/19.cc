if (tcb->m_cWnd >= cnt) {
	tcb->m_ssThresh = (int) (56.178+(3.067)+(tcb->m_segmentSize)+(50.614)+(16.296)+(tcb->m_cWnd));
	segmentsAcked = (int) (82.266-(96.587)-(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (88.673*(48.351)*(74.462)*(27.179)*(73.466)*(tcb->m_segmentSize)*(tcb->m_segmentSize));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize >= cnt) {
	tcb->m_segmentSize = (int) (31.513+(60.405)+(segmentsAcked));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(4.626)+(42.723)+(77.231)+(45.332));

}
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	segmentsAcked = (int) (83.572+(4.138)+(40.0)+(74.236)+(42.914)+(84.079)+(67.062)+(40.455));

} else {
	segmentsAcked = (int) (78.048/0.1);
	tcb->m_cWnd = (int) (84.207*(86.912)*(96.234));

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	cnt = (int) (5.275+(48.377)+(53.643)+(89.547)+(tcb->m_cWnd));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (24.875/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
