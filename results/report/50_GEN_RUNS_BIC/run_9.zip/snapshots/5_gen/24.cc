if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (8.313+(40.462)+(tcb->m_ssThresh)+(27.589)+(97.965));
	tcb->m_segmentSize = (int) (43.989-(76.429)-(40.094)-(74.683));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (60.355+(74.03)+(38.196)+(21.61)+(30.993)+(49.546)+(89.473));

}
tcb->m_segmentSize = (int) (61.273+(40.098)+(22.605)+(35.45)+(70.048)+(20.082)+(47.797));
tcb->m_ssThresh = (int) (98.86-(91.302)-(44.112)-(94.561)-(87.59)-(82.911)-(47.793));
cnt = (int) (35.232*(95.515)*(24.558)*(52.604));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (25.865*(20.126)*(89.167));
