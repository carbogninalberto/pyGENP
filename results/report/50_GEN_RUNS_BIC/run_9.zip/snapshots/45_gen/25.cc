if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
segmentsAcked = (int) (65.949*(48.958)*(segmentsAcked)*(18.707));
tcb->m_ssThresh = (int) (0.1/1.676);
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (12.987*(49.857)*(60.498)*(39.376)*(18.981)*(29.53)*(79.981));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (84.334-(segmentsAcked)-(49.478)-(tcb->m_ssThresh)-(72.666)-(8.541));
	segmentsAcked = (int) (tcb->m_ssThresh*(93.248));

}
