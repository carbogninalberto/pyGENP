if (cnt <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (segmentsAcked*(99.871)*(74.77)*(1.642));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(34.229)-(72.039)-(34.667)-(16.341)-(81.545));

}
segmentsAcked = (int) (0.1/46.557);
if (segmentsAcked < tcb->m_segmentSize) {
	cnt = (int) (63.533-(48.603)-(38.711)-(tcb->m_ssThresh)-(segmentsAcked)-(40.367));

} else {
	cnt = (int) (74.445*(85.405)*(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (67.741*(89.706)*(16.837)*(tcb->m_cWnd)*(34.779));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (cnt-(38.209)-(86.051)-(tcb->m_segmentSize)-(9.408)-(83.425)-(25.148));
	cnt = (int) (71.693-(86.031)-(37.187)-(36.079)-(74.747)-(75.371)-(1.633)-(73.566)-(88.472));

} else {
	tcb->m_segmentSize = (int) (61.493+(36.343)+(11.915)+(69.38)+(95.866)+(21.778)+(39.154));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
