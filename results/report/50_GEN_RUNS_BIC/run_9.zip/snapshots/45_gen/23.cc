cnt = (int) (60.848-(96.738)-(58.61)-(6.281)-(80.837)-(68.157)-(20.551)-(31.93));
tcb->m_ssThresh = (int) (36.813*(60.735)*(36.749)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(10.096)*(segmentsAcked)*(12.663)*(76.507));
cnt = (int) (0.057-(57.267)-(8.677)-(78.238)-(segmentsAcked)-(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float TvqCvcxQjBqRbNJB = (float) (90.11/20.622);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (58.441-(TvqCvcxQjBqRbNJB)-(23.408));
