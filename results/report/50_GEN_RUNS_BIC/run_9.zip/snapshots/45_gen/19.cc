if (segmentsAcked < segmentsAcked) {
	cnt = (int) (92.38+(tcb->m_ssThresh)+(2.629)+(tcb->m_cWnd)+(84.155)+(24.799)+(7.008));

} else {
	cnt = (int) (segmentsAcked*(78.314)*(90.221)*(61.493)*(30.67)*(85.465)*(39.702)*(90.679));
	cnt = (int) (cnt*(tcb->m_ssThresh));

}
tcb->m_segmentSize = (int) (14.857-(tcb->m_ssThresh)-(57.894)-(30.834));
tcb->m_ssThresh = (int) (((52.738)+(49.302)+(80.321)+(0.1)+((16.186*(17.087)*(42.987)*(76.883)*(61.505)*(95.747)*(97.601)))+(0.1)+(0.1))/((0.1)));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (75.19/0.1);
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (47.936+(0.281)+(7.809)+(60.197)+(17.146)+(96.013)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (34.184+(22.11)+(15.313)+(1.921)+(5.544)+(29.192)+(9.003)+(81.404)+(12.8));

} else {
	tcb->m_segmentSize = (int) (32.293-(91.959)-(44.156)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(20.155));

}
ReduceCwnd (tcb);
