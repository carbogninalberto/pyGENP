if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (69.444*(88.878)*(63.685)*(segmentsAcked)*(35.484)*(10.394)*(51.111)*(2.128));
int DbkRDJUKaeEuOCNh = (int) (75.27*(40.267)*(8.347)*(tcb->m_segmentSize)*(58.473)*(26.173)*(43.105)*(cnt));
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_cWnd = (int) (63.73+(4.601)+(60.594));
	DbkRDJUKaeEuOCNh = (int) (56.458/23.29);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(54.022)*(78.19)*(18.022)*(97.49)*(79.996)*(8.906)*(17.759)*(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (34.946-(tcb->m_cWnd)-(82.747)-(DbkRDJUKaeEuOCNh));

} else {
	tcb->m_ssThresh = (int) (71.043*(89.029)*(41.729)*(8.737)*(91.818)*(75.478)*(48.29)*(2.193)*(29.948));
	ReduceCwnd (tcb);

}
