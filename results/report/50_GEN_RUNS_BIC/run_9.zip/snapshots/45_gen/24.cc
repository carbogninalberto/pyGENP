if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (69.398+(25.708)+(cnt)+(84.987)+(59.636)+(cnt));
tcb->m_ssThresh = (int) (84.808-(tcb->m_segmentSize)-(17.198)-(47.379)-(51.701)-(segmentsAcked)-(35.853)-(59.908)-(tcb->m_segmentSize));
