tcb->m_ssThresh = (int) (61.183-(68.73)-(segmentsAcked));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (94.85*(12.121)*(35.109)*(84.073));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (88.382+(58.493)+(66.843)+(96.359));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (77.463-(96.994)-(70.984)-(10.12));

}
tcb->m_cWnd = (int) (38.189*(81.934)*(66.89)*(54.308)*(segmentsAcked)*(13.985)*(36.28)*(19.067));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (28.894/0.1);
tcb->m_segmentSize = (int) (56.515*(0.241)*(53.147));
