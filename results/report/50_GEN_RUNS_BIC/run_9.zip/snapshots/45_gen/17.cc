ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (cnt < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (71.321+(42.892)+(32.304)+(57.194)+(cnt)+(63.223));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) ((8.38-(0.258))/0.1);

}
tcb->m_ssThresh = (int) (51.648-(65.186)-(55.148)-(7.75)-(69.27)-(1.013)-(93.296)-(tcb->m_ssThresh)-(47.74));
if (segmentsAcked >= cnt) {
	tcb->m_cWnd = (int) (26.222/68.411);

} else {
	tcb->m_cWnd = (int) (25.218+(65.458));

}
float AvxOrlTSGPDHpCLm = (float) (32.025-(20.148)-(41.499)-(55.612));
AvxOrlTSGPDHpCLm = (float) (AvxOrlTSGPDHpCLm+(60.873)+(10.599));
ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_cWnd) {
	AvxOrlTSGPDHpCLm = (float) (88.747+(cnt)+(14.915)+(66.62)+(48.966)+(65.669)+(82.671));
	segmentsAcked = (int) (97.865+(79.887)+(tcb->m_ssThresh)+(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (61.013+(14.728));

} else {
	AvxOrlTSGPDHpCLm = (float) (31.556-(95.218)-(tcb->m_cWnd)-(7.417)-(4.948));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (90.373-(62.061)-(segmentsAcked)-(63.87)-(segmentsAcked)-(77.797)-(53.517)-(52.414)-(segmentsAcked));

}
