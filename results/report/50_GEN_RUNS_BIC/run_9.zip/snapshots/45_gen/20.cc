if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (13.144*(88.511));
	cnt = (int) (segmentsAcked-(2.71)-(32.041));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (96.057+(tcb->m_cWnd)+(31.745)+(29.035)+(87.384));
	tcb->m_ssThresh = (int) (83.178+(84.114));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (56.133-(tcb->m_segmentSize)-(57.321));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (40.424*(67.837)*(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (89.75-(30.208)-(43.365)-(90.304));
	cnt = (int) (tcb->m_segmentSize-(21.438)-(52.285)-(70.798)-(28.697));
	segmentsAcked = (int) (98.394*(23.375)*(49.231)*(72.715)*(33.326)*(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (95.301*(33.562)*(50.173));
	segmentsAcked = (int) (tcb->m_segmentSize-(86.093)-(77.488)-(88.974)-(37.53)-(57.02)-(25.021)-(11.272));
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(tcb->m_segmentSize)+(46.373)+(3.159));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (57.906*(tcb->m_segmentSize)*(16.767)*(26.284)*(18.072)*(98.79)*(9.908));

} else {
	tcb->m_cWnd = (int) (85.263*(67.493)*(57.874)*(34.5)*(66.28)*(19.429)*(34.321));

}
