tcb->m_ssThresh = (int) (37.767*(98.043));
tcb->m_cWnd = (int) (21.554-(67.931)-(59.089)-(26.468)-(41.066)-(cnt)-(18.085));
ReduceCwnd (tcb);
cnt = (int) (7.616+(75.892)+(78.015)+(46.278)+(11.277)+(78.016)+(68.026)+(tcb->m_segmentSize)+(tcb->m_cWnd));
segmentsAcked = (int) (39.648*(2.408)*(56.185)*(37.218)*(tcb->m_ssThresh)*(segmentsAcked)*(tcb->m_segmentSize));
cnt = (int) (18.829*(5.5)*(tcb->m_cWnd)*(10.425)*(79.281));
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (41.235*(46.984)*(tcb->m_cWnd)*(39.817)*(63.741)*(78.888)*(51.422)*(62.108)*(66.208));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (cnt-(19.705));

}
