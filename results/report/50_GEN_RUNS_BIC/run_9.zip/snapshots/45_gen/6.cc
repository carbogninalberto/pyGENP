if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (70.571+(87.053)+(37.601)+(13.449)+(65.572)+(46.149)+(80.463)+(8.407));
	segmentsAcked = (int) (28.376+(39.629));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (39.331+(30.655)+(15.507)+(14.326)+(tcb->m_ssThresh)+(54.357)+(71.748));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
cnt = (int) (73.877*(82.351)*(92.825)*(segmentsAcked)*(26.398));
cnt = (int) (0.1/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) ((((84.864-(80.405)-(tcb->m_cWnd)-(48.16)-(32.361)-(69.514)-(37.793)-(1.248)-(28.033)))+((72.808*(58.648)*(tcb->m_ssThresh)))+(65.933)+(49.851))/((22.093)+(0.1)+(0.1)));
