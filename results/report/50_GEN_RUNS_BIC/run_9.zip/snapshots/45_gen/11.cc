ReduceCwnd (tcb);
tcb->m_cWnd = (int) (12.251-(32.361)-(tcb->m_segmentSize));
ReduceCwnd (tcb);
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)));
	tcb->m_cWnd = (int) (segmentsAcked*(93.175)*(3.739)*(75.917));

} else {
	segmentsAcked = (int) (90.495-(31.973));

}
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (98.748*(85.788)*(82.069)*(73.578)*(7.601)*(56.579)*(99.745)*(66.672)*(83.904));

} else {
	tcb->m_cWnd = (int) (20.829*(49.388)*(21.247)*(11.008));

}
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (54.269-(72.656)-(94.111)-(25.497)-(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (37.443*(33.223)*(tcb->m_cWnd)*(54.492)*(33.3)*(1.322)*(97.119)*(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (80.158+(86.16)+(83.436)+(98.531)+(30.637)+(10.005)+(20.475));
	tcb->m_cWnd = (int) (29.026/0.1);

}
