float MUvCyyADxotQSfiV = (float) (((40.546)+(56.489)+((-96.688*(-95.467)*(51.362)*(8.496)*(73.591)*(6.161)))+(22.288)+(88.392)+(-42.982))/((62.261)));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (95.792+(MUvCyyADxotQSfiV)+(64.707));

} else {
	segmentsAcked = (int) (83.845+(36.028));
	tcb->m_segmentSize = (int) (98.426-(76.953)-(98.509));

}
tcb->m_cWnd = (int) (-5.242/40.59);
segmentsAcked = (int) (-41.286/-1.015);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (43.833*(15.071)*(6.348)*(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (53.278-(37.05));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (22.279*(25.513)*(tcb->m_cWnd)*(71.151)*(17.638));

}
if (MUvCyyADxotQSfiV != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (99.909-(MUvCyyADxotQSfiV));
	tcb->m_cWnd = (int) (94.419-(20.684)-(37.521)-(5.204)-(99.655)-(tcb->m_cWnd)-(83.734));

} else {
	tcb->m_segmentSize = (int) (64.017/0.1);

}
