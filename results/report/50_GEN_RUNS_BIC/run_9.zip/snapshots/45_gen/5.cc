ReduceCwnd (tcb);
if (cnt > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+(23.355)+(41.357)+(0.1)+(43.283)+(21.167))/((0.1)+(0.1)+(37.749)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (27.865*(91.754)*(67.525)*(64.406)*(85.427)*(3.773)*(73.161)*(11.575)*(30.326));

}
if (tcb->m_cWnd == cnt) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(86.625)*(tcb->m_ssThresh)*(75.404));
	tcb->m_cWnd = (int) (16.481*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(48.178));

} else {
	tcb->m_cWnd = (int) (75.591-(51.627));

}
if (tcb->m_cWnd >= cnt) {
	tcb->m_segmentSize = (int) (24.118-(77.809)-(69.366)-(59.909));

} else {
	tcb->m_segmentSize = (int) ((93.422-(81.633))/31.303);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	cnt = (int) (((0.1)+(92.7)+(95.635)+(0.1))/((0.1)));

} else {
	cnt = (int) (53.823+(10.79)+(33.969)+(tcb->m_cWnd)+(63.277)+(3.593)+(73.829)+(82.32));
	tcb->m_ssThresh = (int) (38.303*(tcb->m_segmentSize)*(69.888)*(43.306)*(68.034)*(15.273)*(39.893));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
