float QBXJCJcPtmVlDoXb = (float) (tcb->m_segmentSize*(66.708)*(18.374)*(7.452)*(segmentsAcked)*(29.564));
tcb->m_ssThresh = (int) (58.577+(10.886)+(tcb->m_segmentSize)+(93.312)+(74.777));
ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_segmentSize) {
	QBXJCJcPtmVlDoXb = (float) (segmentsAcked-(QBXJCJcPtmVlDoXb));
	QBXJCJcPtmVlDoXb = (float) (36.221/0.1);

} else {
	QBXJCJcPtmVlDoXb = (float) (83.567*(13.852)*(82.213)*(33.436)*(42.153)*(44.007));
	tcb->m_ssThresh = (int) (49.775-(20.731)-(32.54)-(cnt)-(tcb->m_cWnd)-(56.351)-(82.125)-(tcb->m_cWnd));

}
QBXJCJcPtmVlDoXb = (float) (((20.355)+(0.1)+(0.1)+(0.1))/((28.812)+(74.121)));
