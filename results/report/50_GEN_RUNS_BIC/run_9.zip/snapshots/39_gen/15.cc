if (cnt == tcb->m_ssThresh) {
	segmentsAcked = (int) (73.568*(64.461)*(15.86)*(27.572)*(95.583)*(31.484)*(95.007));
	segmentsAcked = (int) (9.751*(93.854)*(25.059)*(85.321)*(72.174)*(71.33));

} else {
	segmentsAcked = (int) (0.1/0.1);

}
cnt = (int) (89.701/0.1);
tcb->m_segmentSize = (int) (((12.239)+(0.1)+(0.1)+(88.621)+(21.2))/((98.141)+(6.5)+(37.903)+(0.1)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (7.329/2.972);
if (cnt == tcb->m_ssThresh) {
	segmentsAcked = (int) (51.163-(tcb->m_cWnd)-(25.959));
	tcb->m_segmentSize = (int) ((tcb->m_ssThresh*(75.927)*(tcb->m_cWnd)*(cnt)*(4.456)*(54.747)*(57.847))/(29.989+(tcb->m_ssThresh)+(40.853)));
	tcb->m_ssThresh = (int) ((79.512-(67.154)-(segmentsAcked)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(57.894)-(60.557)-(48.642)-(38.424))/0.1);

} else {
	segmentsAcked = (int) (0.1/68.866);
	segmentsAcked = (int) (1.401/14.301);

}
