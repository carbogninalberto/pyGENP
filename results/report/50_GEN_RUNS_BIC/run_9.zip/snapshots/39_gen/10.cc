if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked != cnt) {
	tcb->m_ssThresh = (int) (77.262+(69.054)+(39.632)+(3.262));

} else {
	tcb->m_ssThresh = (int) (71.369*(56.152)*(41.494)*(65.142)*(tcb->m_ssThresh)*(16.028)*(92.705)*(tcb->m_cWnd)*(75.454));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (37.396+(53.857)+(19.605)+(58.111));
	tcb->m_ssThresh = (int) (4.133-(66.747)-(tcb->m_segmentSize)-(18.696)-(cnt)-(21.981)-(48.245)-(tcb->m_segmentSize)-(80.631));
	segmentsAcked = (int) (22.212*(tcb->m_ssThresh)*(49.543));

} else {
	segmentsAcked = (int) (98.214-(7.38));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(35.53)-(tcb->m_ssThresh)-(50.989)-(tcb->m_cWnd)-(0.182)-(tcb->m_segmentSize)-(5.695));

}
if (tcb->m_cWnd > tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_ssThresh-(41.466)-(81.119)-(69.276)-(81.843)-(88.638)-(39.485)-(3.21));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (0.1/91.395);
	tcb->m_segmentSize = (int) (cnt+(50.591)+(87.71)+(86.296)+(cnt)+(94.349));
	tcb->m_ssThresh = (int) (2.984-(19.985)-(34.251)-(24.871)-(tcb->m_cWnd)-(91.066)-(2.855));

}
segmentsAcked = (int) (49.2-(60.343)-(tcb->m_segmentSize));
