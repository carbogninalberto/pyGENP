ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (14.259+(88.216)+(0.932));
float YvhvXBMsGfvoBwOY = (float) (26.416*(41.653)*(cnt)*(49.856)*(segmentsAcked));
