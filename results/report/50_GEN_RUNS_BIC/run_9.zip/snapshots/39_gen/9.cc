if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize > segmentsAcked) {
	cnt = (int) (tcb->m_cWnd-(95.916)-(10.112)-(cnt)-(28.419)-(98.272)-(48.905)-(86.709));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (segmentsAcked*(tcb->m_cWnd)*(19.189));

} else {
	cnt = (int) (tcb->m_cWnd-(cnt)-(13.143)-(94.567)-(cnt)-(90.338));
	cnt = (int) (9.076-(75.318)-(63.925)-(15.391)-(9.246));

}
tcb->m_segmentSize = (int) (10.523-(6.771)-(59.742)-(43.079)-(tcb->m_cWnd)-(5.41));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
