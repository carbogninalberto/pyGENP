float oNAzaktaNUUtnYvu = (float) (tcb->m_ssThresh-(9.801)-(74.644)-(51.354)-(tcb->m_cWnd)-(52.794));
segmentsAcked = (int) (51.169/77.707);
if (oNAzaktaNUUtnYvu != oNAzaktaNUUtnYvu) {
	tcb->m_ssThresh = (int) (segmentsAcked+(56.39)+(7.804)+(20.205)+(91.151)+(59.667)+(cnt)+(24.628));

} else {
	tcb->m_ssThresh = (int) (17.904+(tcb->m_cWnd)+(-0.074)+(oNAzaktaNUUtnYvu)+(65.624)+(46.209)+(68.897));

}
tcb->m_segmentSize = (int) (56.536*(tcb->m_cWnd)*(68.285));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (51.695*(57.497)*(6.089)*(27.605)*(77.374)*(6.427)*(91.942)*(98.253));
	tcb->m_ssThresh = (int) (60.744+(29.985)+(71.417)+(96.569)+(47.573));
	cnt = (int) (74.57-(oNAzaktaNUUtnYvu));

} else {
	tcb->m_ssThresh = (int) (38.194+(oNAzaktaNUUtnYvu)+(cnt));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
