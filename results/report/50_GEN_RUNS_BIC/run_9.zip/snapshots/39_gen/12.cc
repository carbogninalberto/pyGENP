segmentsAcked = (int) (5.939-(52.822)-(62.901)-(49.547)-(59.714)-(65.925)-(77.32));
cnt = (int) (segmentsAcked+(cnt)+(46.511)+(74.838));
tcb->m_ssThresh = (int) (59.761*(62.238)*(tcb->m_ssThresh)*(19.001)*(tcb->m_cWnd)*(75.072)*(57.395));
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/0.1);
	segmentsAcked = (int) (0.1/91.601);
	tcb->m_ssThresh = (int) ((15.687-(67.5))/0.1);

} else {
	tcb->m_cWnd = (int) (74.405*(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (54.277/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (12.384+(55.693)+(tcb->m_cWnd)+(95.981)+(29.158));

} else {
	tcb->m_segmentSize = (int) (73.182-(70.407));
	cnt = (int) (89.433-(51.448)-(80.496)-(52.697)-(tcb->m_cWnd)-(36.721));

}
