tcb->m_cWnd = (int) (97.081-(99.15)-(56.237)-(55.223)-(23.356)-(85.067));
if (segmentsAcked == segmentsAcked) {
	tcb->m_ssThresh = (int) (cnt*(segmentsAcked)*(segmentsAcked)*(53.028)*(83.834)*(segmentsAcked));
	segmentsAcked = (int) (tcb->m_ssThresh+(76.719)+(29.475));

} else {
	tcb->m_ssThresh = (int) (0.1/2.347);
	segmentsAcked = (int) (((10.086)+(34.809)+(0.1)+((68.496*(82.704)*(13.178)*(71.54)*(80.307)*(6.73)*(segmentsAcked)*(71.114)))+(90.515))/((94.731)));
	cnt = (int) (13.189+(4.692));

}
if (cnt >= segmentsAcked) {
	tcb->m_segmentSize = (int) ((((60.037*(78.7)*(76.521)*(93.035)*(cnt)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(70.399)*(11.754)))+(0.1)+(75.921)+(77.063)+(0.1)+(0.1))/((36.316)));

} else {
	tcb->m_segmentSize = (int) ((((61.262+(28.604)+(88.036)+(59.363)+(98.116)+(95.316)+(60.609)+(tcb->m_segmentSize)))+(7.707)+(89.876)+(57.409)+((77.89*(segmentsAcked)*(95.923)*(10.505)*(tcb->m_segmentSize)))+(63.42))/((39.454)+(0.1)));
	segmentsAcked = (int) (87.566/0.1);
	tcb->m_ssThresh = (int) (36.854-(79.288));

}
cnt = (int) (6.779+(90.686)+(45.911)+(96.701)+(11.37)+(56.748)+(28.378));
tcb->m_cWnd = (int) (8.615*(61.086)*(31.949)*(89.151)*(4.532)*(11.201)*(60.193)*(76.195)*(segmentsAcked));
