if (segmentsAcked >= tcb->m_cWnd) {
	segmentsAcked = (int) (96.681-(93.845));

} else {
	segmentsAcked = (int) (2.192-(55.495)-(51.688)-(94.784));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (11.826*(21.216)*(69.884)*(0.583)*(50.826));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(17.474)-(37.541)-(39.877)-(75.022));
	segmentsAcked = (int) ((40.047+(46.33)+(36.346)+(30.376)+(9.021)+(80.272)+(53.074)+(64.374)+(tcb->m_segmentSize))/0.1);

} else {
	tcb->m_segmentSize = (int) (14.568/0.1);
	tcb->m_cWnd = (int) (((70.335)+(0.1)+(79.763)+(0.1)+(88.845)+(0.1)+(0.1))/((47.779)+(25.033)));
	cnt = (int) (40.742+(73.748)+(10.599)+(36.879)+(39.57));

}
tcb->m_ssThresh = (int) (48.58/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (94.966+(81.4)+(tcb->m_cWnd)+(50.01));

} else {
	segmentsAcked = (int) (62.743*(97.712)*(43.488)*(80.881)*(84.299)*(67.401));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
