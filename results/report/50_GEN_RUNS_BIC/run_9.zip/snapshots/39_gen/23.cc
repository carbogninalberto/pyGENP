segmentsAcked = (int) (43.391-(tcb->m_ssThresh)-(53.849)-(tcb->m_ssThresh)-(90.305));
int PCiyIeIooCSHwFQA = (int) (38.741+(79.755)+(22.597)+(54.1));
if (tcb->m_ssThresh <= PCiyIeIooCSHwFQA) {
	cnt = (int) (83.32-(16.508)-(segmentsAcked)-(29.271)-(39.398)-(72.45)-(73.675)-(segmentsAcked)-(PCiyIeIooCSHwFQA));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (((57.879)+(0.1)+(0.1)+(0.1)+(0.1)+((86.778+(54.948)+(tcb->m_cWnd)+(segmentsAcked)+(70.432)))+(0.1))/((0.1)+(75.459)));
	segmentsAcked = (int) (33.449*(82.645)*(50.951)*(72.525));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (14.522/6.049);
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (0.1/99.916);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (21.95+(86.99)+(13.072)+(25.663)+(39.354)+(53.979)+(72.074)+(40.666));
	segmentsAcked = (int) (37.364*(cnt)*(55.272)*(4.354)*(45.259)*(73.793)*(20.43)*(19.048));
	tcb->m_cWnd = (int) (38.982+(68.746)+(66.226)+(95.966)+(90.109)+(38.881));

}
