if (segmentsAcked != tcb->m_ssThresh) {
	cnt = (int) (71.526*(69.942)*(78.663)*(99.051));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (80.588+(99.898)+(segmentsAcked)+(88.163)+(92.464)+(78.771));

} else {
	cnt = (int) (90.26+(27.778));
	segmentsAcked = (int) (28.992+(26.556)+(50.503)+(48.66));
	tcb->m_ssThresh = (int) (51.869-(36.656));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (82.854-(34.348)-(9.457)-(3.881)-(49.224)-(cnt)-(89.526)-(25.222)-(89.606));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (((89.83)+(35.174)+(0.1)+(62.021))/((0.1)+(83.609)));
