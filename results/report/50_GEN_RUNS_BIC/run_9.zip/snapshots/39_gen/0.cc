int rTifaRUdLllpLQWx = (int) (((-29.303)+(-64.071)+((-92.713-(97.481)-(12.575)-(-28.084)-(-55.678)-(63.887)))+((53.792-(13.254)-(91.242)-(2.205)-(86.391)-(58.556)-(-82.376)))+(-46.375)+(-41.393))/((68.392)+(-61.59)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (40.541+(-58.035)+(-30.807)+(97.035)+(73.221)+(-66.856));
