ReduceCwnd (tcb);
float iyHAtewCupebyvvS = (float) (67.392-(72.388)-(cnt)-(15.421)-(18.008)-(63.142)-(segmentsAcked)-(7.679)-(25.609));
segmentsAcked = (int) (29.872-(9.313)-(19.121));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (97.104*(tcb->m_cWnd));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
