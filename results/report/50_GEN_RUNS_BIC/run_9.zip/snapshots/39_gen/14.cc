if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (cnt+(7.293)+(tcb->m_segmentSize)+(1.654));
tcb->m_segmentSize = (int) (35.884/23.51);
if (tcb->m_ssThresh <= cnt) {
	cnt = (int) (((28.497)+(10.669)+((10.946+(6.514)+(97.806)))+(0.1)+(1.011)+(82.162))/((0.1)+(0.1)));
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	cnt = (int) (cnt*(42.168)*(segmentsAcked)*(38.466)*(66.294)*(94.462));
	tcb->m_cWnd = (int) ((((4.691+(95.605)+(72.443)+(70.851)+(78.953)))+(0.1)+(36.05)+(0.1)+(72.478)+(47.242))/((0.1)));
	tcb->m_ssThresh = (int) (27.94-(64.213)-(13.835)-(72.095)-(75.864)-(86.368)-(53.294)-(tcb->m_segmentSize));

}
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (37.355+(94.614)+(97.589)+(24.601)+(60.978));

} else {
	tcb->m_ssThresh = (int) (56.148*(21.632)*(28.517)*(22.142)*(64.423)*(86.051)*(92.972)*(segmentsAcked)*(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (tcb->m_cWnd+(28.179)+(90.646)+(73.062)+(75.308)+(5.951)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(26.392));
if (cnt != tcb->m_cWnd) {
	cnt = (int) (85.455+(92.377)+(71.073)+(segmentsAcked)+(50.366)+(tcb->m_cWnd)+(41.179)+(39.217)+(54.71));
	segmentsAcked = (int) (72.803/(93.961+(tcb->m_cWnd)+(tcb->m_segmentSize)+(73.788)));
	tcb->m_segmentSize = (int) (49.968+(6.173)+(50.701)+(12.902)+(69.904));

} else {
	cnt = (int) (91.268+(83.516)+(10.258)+(40.81)+(15.049)+(cnt)+(80.863)+(35.027));

}
