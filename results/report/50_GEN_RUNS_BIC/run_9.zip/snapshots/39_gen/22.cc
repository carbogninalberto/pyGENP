tcb->m_ssThresh = (int) (0.1/0.1);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (75.442+(70.865)+(91.144));
	cnt = (int) (58.308-(54.898)-(31.222));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(1.909)+(68.602)+(16.356));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(85.103));

}
tcb->m_segmentSize = (int) (49.038*(59.065));
ReduceCwnd (tcb);
if (tcb->m_segmentSize != cnt) {
	tcb->m_cWnd = (int) (76.322-(11.598)-(32.537)-(45.922)-(57.307)-(63.275)-(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (86.887*(39.057)*(cnt)*(68.319)*(72.272)*(41.017)*(tcb->m_ssThresh));

}
