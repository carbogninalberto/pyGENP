if (tcb->m_segmentSize <= cnt) {
	cnt = (int) (58.326-(82.939)-(62.283));
	tcb->m_cWnd = (int) (88.387/48.451);

} else {
	cnt = (int) (0.1/87.961);
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
float uHHQLeuSzzmTgbaP = (float) (cnt-(99.803)-(83.13)-(tcb->m_cWnd));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > uHHQLeuSzzmTgbaP) {
	tcb->m_ssThresh = (int) (((0.1)+(68.699)+(0.1)+(91.056)+(66.724)+(0.1))/((0.1)+(9.823)+(11.36)));

} else {
	tcb->m_ssThresh = (int) (73.992-(13.917)-(tcb->m_segmentSize)-(81.388)-(79.972)-(80.169));

}
if (tcb->m_segmentSize >= cnt) {
	tcb->m_segmentSize = (int) (93.577-(cnt)-(tcb->m_cWnd)-(tcb->m_cWnd)-(cnt)-(cnt)-(94.634));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (74.102+(segmentsAcked));
	segmentsAcked = (int) (75.091-(80.037));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
