int htdLeTFEyyBwbVHz = (int) (cnt-(tcb->m_segmentSize)-(64.384)-(segmentsAcked)-(20.171)-(24.266)-(41.407));
tcb->m_cWnd = (int) (42.642*(segmentsAcked)*(7.196)*(cnt));
tcb->m_cWnd = (int) (30.642*(cnt)*(90.54)*(16.201)*(tcb->m_cWnd)*(tcb->m_segmentSize));
htdLeTFEyyBwbVHz = (int) (17.418+(72.252));
ReduceCwnd (tcb);
if (htdLeTFEyyBwbVHz < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(24.691)+(58.706)+(0.1))/((80.59)));
	tcb->m_cWnd = (int) (22.423-(23.721)-(65.634)-(9.224)-(tcb->m_cWnd)-(22.381));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+((htdLeTFEyyBwbVHz-(78.122)-(92.443)-(84.649)-(tcb->m_cWnd)-(75.382)-(9.548)-(55.893)))+(65.816))/((96.207)));

}
