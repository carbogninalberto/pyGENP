int QaskTiMMJaOYxGJE = (int) (34.549+(-54.566)+(8.968)+(-33.584)+(-90.917)+(-23.246)+(-46.796)+(-93.776)+(-18.355));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/19.911);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (86.246*(41.887)*(26.411)*(88.22)*(6.658));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
