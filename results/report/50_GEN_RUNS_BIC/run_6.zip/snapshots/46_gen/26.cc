if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	cnt = (int) (((35.706)+(39.068)+(0.1)+(90.018)+((79.601-(39.667)-(8.929)-(39.029)-(27.218)-(40.901)-(73.669)-(46.463)))+(56.745)+(0.1)+(0.1))/((0.1)));
	tcb->m_segmentSize = (int) (44.572+(75.641)+(88.532)+(segmentsAcked)+(85.219)+(segmentsAcked)+(29.708)+(tcb->m_cWnd)+(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (66.641*(97.526)*(9.837)*(segmentsAcked));
	tcb->m_ssThresh = (int) (55.108+(80.117)+(tcb->m_ssThresh)+(18.759));

}
cnt = (int) (cnt-(95.935)-(65.354));
tcb->m_segmentSize = (int) (84.283+(tcb->m_segmentSize)+(cnt)+(tcb->m_segmentSize)+(82.741)+(tcb->m_ssThresh)+(19.236));
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((64.196)+(0.1)+(28.833)+(25.852))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (90.096+(4.649)+(15.324)+(34.823)+(61.158));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(tcb->m_cWnd)*(29.391));
	cnt = (int) (tcb->m_ssThresh*(32.995)*(tcb->m_segmentSize)*(13.109)*(0.419));
	segmentsAcked = (int) (93.254+(69.858)+(51.87)+(40.465)+(segmentsAcked)+(tcb->m_segmentSize));

}
if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(57.972)-(31.701)-(96.271)-(26.8)-(90.92));
	tcb->m_cWnd = (int) (9.068/37.06);

} else {
	tcb->m_cWnd = (int) (40.572/11.42);
	cnt = (int) (46.167/0.1);

}
if (cnt != tcb->m_ssThresh) {
	cnt = (int) (tcb->m_cWnd*(46.749)*(37.54)*(92.672));
	tcb->m_ssThresh = (int) ((((14.538*(30.382)*(segmentsAcked)*(89.293)*(87.394)*(49.641)*(95.717)*(53.87)*(10.563)))+(59.823)+(15.975)+(46.251)+(25.616))/((0.1)));

} else {
	cnt = (int) ((14.972-(47.634)-(81.039)-(41.734)-(82.103)-(64.448))/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (((42.452)+(57.017)+(0.1)+(16.877))/((0.1)));

}
