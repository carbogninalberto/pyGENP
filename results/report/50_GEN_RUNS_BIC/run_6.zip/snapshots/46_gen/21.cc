cnt = (int) (7.309+(25.421)+(47.621)+(45.535)+(91.063)+(12.727));
tcb->m_ssThresh = (int) (70.041*(92.009)*(17.297)*(cnt)*(86.028)*(95.133)*(45.02)*(83.361));
ReduceCwnd (tcb);
int aFNLEYBWkCmiIcNO = (int) (81.45-(49.64));
cnt = (int) (42.316-(92.961)-(84.975)-(57.622)-(60.913)-(55.607)-(53.817)-(37.893));
segmentsAcked = (int) (59.604-(66.411)-(tcb->m_ssThresh)-(20.401)-(51.032)-(5.15)-(47.282));
if (aFNLEYBWkCmiIcNO < aFNLEYBWkCmiIcNO) {
	aFNLEYBWkCmiIcNO = (int) ((98.281*(11.13)*(11.885))/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (aFNLEYBWkCmiIcNO*(cnt)*(86.827)*(48.886)*(60.898)*(21.378));

} else {
	aFNLEYBWkCmiIcNO = (int) ((93.386*(72.598)*(41.835)*(78.959)*(tcb->m_ssThresh))/13.08);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (75.232+(tcb->m_ssThresh)+(25.718));

}
tcb->m_segmentSize = (int) (99.159*(tcb->m_ssThresh)*(cnt)*(83.74));
segmentsAcked = (int) (98.293+(83.547));
