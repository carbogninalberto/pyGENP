if (tcb->m_segmentSize != segmentsAcked) {
	segmentsAcked = (int) (((0.1)+(50.48)+((74.999-(cnt)-(18.292)-(97.763)-(64.438)))+(0.1)+(0.1)+(0.1))/((0.1)+(14.45)));
	tcb->m_cWnd = (int) (88.776*(79.139)*(31.427)*(34.641)*(60.244));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh*(73.99)*(tcb->m_ssThresh)*(88.423));
	tcb->m_segmentSize = (int) (0.1/0.1);
	segmentsAcked = (int) (61.8*(segmentsAcked)*(tcb->m_ssThresh)*(90.099)*(93.182)*(46.459)*(29.75));

}
tcb->m_ssThresh = (int) (25.295/0.1);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd != tcb->m_segmentSize) {
	cnt = (int) (37.593*(78.214));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (7.206+(63.741)+(36.573)+(29.281));

} else {
	cnt = (int) (((3.438)+(38.466)+(0.1)+(0.1)+(61.459))/((43.289)+(24.491)));

}
ReduceCwnd (tcb);
