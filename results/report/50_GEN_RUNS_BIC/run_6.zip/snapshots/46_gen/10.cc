float JAwCwgZHmkuAdLav = (float) (segmentsAcked+(78.749)+(84.937)+(61.329)+(59.642)+(50.464)+(65.854));
if (tcb->m_cWnd == JAwCwgZHmkuAdLav) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(56.113)*(tcb->m_segmentSize)*(97.894)*(2.21)*(71.646)*(99.802)*(95.576));
	tcb->m_segmentSize = (int) (cnt+(57.615)+(56.278)+(65.696)+(71.439)+(21.989)+(45.209)+(26.607));
	tcb->m_segmentSize = (int) (30.514+(72.424)+(76.774)+(51.972)+(tcb->m_segmentSize)+(2.318)+(tcb->m_ssThresh)+(47.469)+(73.404));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(76.396)-(62.864)-(74.673)-(34.318));

}
if (JAwCwgZHmkuAdLav == segmentsAcked) {
	segmentsAcked = (int) (84.127+(14.849)+(33.444));

} else {
	segmentsAcked = (int) (98.047-(JAwCwgZHmkuAdLav)-(82.336)-(66.693)-(75.859)-(96.558)-(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (53.947-(54.399)-(56.737)-(74.197)-(90.372));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_cWnd = (int) (81.069+(28.276)+(26.673)+(23.239)+(83.611));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (60.944+(66.775)+(89.975)+(20.989)+(67.207)+(36.765)+(87.71));
if (JAwCwgZHmkuAdLav < cnt) {
	cnt = (int) (91.211+(tcb->m_ssThresh)+(tcb->m_cWnd)+(45.054)+(29.987)+(69.537)+(11.785));
	tcb->m_ssThresh = (int) (99.498+(78.107)+(32.029)+(99.624)+(JAwCwgZHmkuAdLav)+(36.472)+(30.65)+(32.083)+(69.894));
	tcb->m_cWnd = (int) (35.461+(20.521));

} else {
	cnt = (int) (26.894*(32.825)*(45.169));
	tcb->m_ssThresh = (int) (83.281*(64.833)*(62.689)*(0.473)*(tcb->m_segmentSize)*(61.397));

}
if (cnt < tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (50.567+(cnt)+(tcb->m_segmentSize)+(82.825));
	tcb->m_segmentSize = (int) (JAwCwgZHmkuAdLav+(2.458)+(25.0));

}
