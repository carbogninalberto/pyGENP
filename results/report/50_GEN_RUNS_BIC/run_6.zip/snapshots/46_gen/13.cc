tcb->m_cWnd = (int) (41.662+(53.607)+(24.867)+(53.062)+(58.046));
float bjEvGNPCHqUbWYbc = (float) (66.79+(84.875)+(tcb->m_cWnd)+(tcb->m_cWnd)+(19.276)+(cnt)+(73.852));
ReduceCwnd (tcb);
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (13.295*(36.31)*(99.492)*(12.454)*(22.3)*(77.209)*(17.287));

} else {
	tcb->m_ssThresh = (int) (49.294+(74.693)+(22.61)+(11.522)+(22.668)+(76.361)+(47.976));
	bjEvGNPCHqUbWYbc = (float) (tcb->m_segmentSize-(84.616)-(44.329)-(2.136)-(80.812)-(96.919)-(10.162));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (94.895*(82.69)*(89.707)*(11.737)*(segmentsAcked)*(49.536)*(bjEvGNPCHqUbWYbc)*(28.504));
bjEvGNPCHqUbWYbc = (float) (94.529*(82.756)*(55.74));
if (tcb->m_ssThresh == bjEvGNPCHqUbWYbc) {
	cnt = (int) (45.781+(86.898)+(84.455));
	cnt = (int) (51.384*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(60.495)*(16.215)*(46.85)*(41.244));

} else {
	cnt = (int) ((30.679*(80.456)*(92.07)*(5.747)*(75.339)*(48.221)*(74.156))/0.1);

}
if (cnt <= segmentsAcked) {
	cnt = (int) (8.982-(tcb->m_cWnd)-(77.374)-(tcb->m_segmentSize));
	cnt = (int) (25.951*(23.873)*(cnt)*(15.987)*(47.411)*(6.061)*(24.336)*(11.047)*(tcb->m_ssThresh));

} else {
	cnt = (int) (67.74/93.995);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
