if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (0.1/88.2);
ReduceCwnd (tcb);
if (cnt == cnt) {
	tcb->m_ssThresh = (int) (48.596/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (cnt*(48.868)*(16.255)*(tcb->m_ssThresh)*(5.925)*(segmentsAcked)*(81.085)*(54.602)*(28.675));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
cnt = (int) (89.077-(97.678));
tcb->m_segmentSize = (int) (75.528+(70.827));
cnt = (int) (90.677-(35.352)-(78.141));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
