segmentsAcked = (int) (78.286/38.645);
int pOMUDwFBiQQuItqT = (int) (((51.624)+(0.1)+(0.1)+((30.16*(63.133)))+(71.397))/((0.1)+(7.517)+(28.501)+(12.61)));
if (tcb->m_ssThresh < pOMUDwFBiQQuItqT) {
	tcb->m_segmentSize = (int) (63.194+(86.068)+(0.81)+(pOMUDwFBiQQuItqT)+(tcb->m_ssThresh)+(2.583));
	tcb->m_ssThresh = (int) (21.215+(77.549)+(68.109)+(80.303)+(77.408)+(10.888)+(75.452)+(pOMUDwFBiQQuItqT));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (6.364/0.1);
	cnt = (int) (0.1/42.372);
	ReduceCwnd (tcb);

}
cnt = (int) (26.802+(tcb->m_cWnd)+(66.416)+(45.54)+(tcb->m_segmentSize)+(17.024));
if (cnt < segmentsAcked) {
	tcb->m_ssThresh = (int) (37.555*(pOMUDwFBiQQuItqT)*(87.551));

} else {
	tcb->m_ssThresh = (int) (30.13-(40.486)-(34.984)-(78.632)-(92.85)-(23.516));
	segmentsAcked = (int) (13.48+(57.21)+(tcb->m_ssThresh)+(90.745)+(pOMUDwFBiQQuItqT)+(44.82)+(92.631)+(82.114)+(cnt));
	pOMUDwFBiQQuItqT = (int) (73.021+(71.512)+(57.891));

}
tcb->m_ssThresh = (int) (((0.1)+(85.89)+(98.494)+((89.534*(41.743)*(77.346)*(67.586)*(14.826)))+(0.1))/((59.598)+(0.1)+(0.1)));
tcb->m_segmentSize = (int) (98.007-(tcb->m_segmentSize)-(2.014)-(9.428)-(28.979)-(10.389)-(54.674));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
