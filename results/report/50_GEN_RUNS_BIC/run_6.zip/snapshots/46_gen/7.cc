segmentsAcked = (int) (0.1/0.1);
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (86.143*(7.414)*(2.108)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(66.175)*(cnt));

} else {
	tcb->m_cWnd = (int) (40.304/30.5);

}
segmentsAcked = (int) (((0.1)+(0.1)+((61.887*(18.799)*(27.863)*(93.317)*(50.917)*(0.682)*(99.262)*(27.071)))+(76.259))/((0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
