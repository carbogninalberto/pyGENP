ReduceCwnd (tcb);
if (tcb->m_segmentSize > cnt) {
	tcb->m_cWnd = (int) (57.866*(tcb->m_cWnd)*(27.065)*(50.83));
	cnt = (int) (24.731*(37.389)*(47.398)*(48.984)*(90.728)*(55.12)*(81.739));
	cnt = (int) (65.552*(28.2)*(49.093)*(4.09)*(27.975)*(cnt));

} else {
	tcb->m_cWnd = (int) (44.874-(34.612)-(26.023));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (33.805*(12.89)*(67.676)*(27.089)*(24.816)*(58.047)*(41.6));

}
if (segmentsAcked >= segmentsAcked) {
	cnt = (int) (73.225-(tcb->m_segmentSize)-(21.713));
	tcb->m_segmentSize = (int) (41.491-(9.746)-(cnt)-(10.93)-(90.47)-(2.163)-(34.823));

} else {
	cnt = (int) (71.185+(cnt)+(86.333)+(71.477)+(45.027)+(47.613)+(77.438)+(tcb->m_ssThresh));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (55.655+(tcb->m_ssThresh)+(10.029)+(17.394)+(64.204)+(segmentsAcked)+(4.022));

}
tcb->m_cWnd = (int) (77.995/0.1);
if (segmentsAcked < tcb->m_ssThresh) {
	cnt = (int) (2.803*(segmentsAcked)*(35.309)*(9.859)*(91.971)*(88.634)*(27.976)*(74.456)*(45.503));
	tcb->m_ssThresh = (int) (35.636*(48.441)*(95.614)*(15.828)*(25.282)*(33.1)*(88.41)*(tcb->m_ssThresh));

} else {
	cnt = (int) (50.547-(5.969)-(segmentsAcked)-(96.457)-(73.894)-(segmentsAcked)-(75.559));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
