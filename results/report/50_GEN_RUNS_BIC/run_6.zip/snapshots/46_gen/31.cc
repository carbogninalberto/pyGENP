float UVfOUyoHPLhdmMzS = (float) (46.43+(64.932)+(68.616));
cnt = (int) ((30.953+(99.821)+(32.316)+(tcb->m_ssThresh)+(83.668)+(57.965)+(80.766)+(7.557)+(19.162))/(8.981-(93.717)-(59.387)-(12.948)-(78.045)-(17.181)-(49.253)-(28.901)-(tcb->m_cWnd)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int FxrsPpnLtmABZyBm = (int) (63.07+(77.405)+(7.684)+(cnt)+(28.507)+(86.13)+(44.654)+(3.126)+(94.844));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
