tcb->m_segmentSize = (int) ((((94.281-(67.928)-(segmentsAcked)-(tcb->m_ssThresh)-(90.216)-(36.012)-(0.84)-(94.178)))+((99.769*(87.558)))+(0.1)+(0.1))/((0.1)));
if (cnt == tcb->m_ssThresh) {
	segmentsAcked = (int) (87.262+(53.678)+(44.402)+(76.103)+(16.993)+(72.056)+(23.205));
	segmentsAcked = (int) (68.416+(74.881));
	cnt = (int) (segmentsAcked-(45.269)-(53.113));

} else {
	segmentsAcked = (int) (99.066+(32.526)+(27.978)+(49.641)+(19.505));

}
segmentsAcked = (int) (72.829*(tcb->m_ssThresh)*(43.677)*(77.813));
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(28.661)+(tcb->m_ssThresh)+(7.132)+(cnt));
	tcb->m_segmentSize = (int) (41.156-(46.681)-(20.107)-(segmentsAcked)-(tcb->m_segmentSize)-(42.1));
	tcb->m_cWnd = (int) (83.629-(tcb->m_cWnd)-(18.783)-(41.92)-(89.95)-(71.269)-(87.573)-(70.847));

} else {
	tcb->m_segmentSize = (int) (25.604*(87.239)*(56.014)*(cnt)*(68.033)*(38.617)*(66.358)*(98.821)*(53.669));
	tcb->m_ssThresh = (int) (91.192*(99.877)*(26.442)*(94.232)*(67.715)*(tcb->m_ssThresh));

}
