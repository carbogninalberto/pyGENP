ReduceCwnd (tcb);
if (cnt != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (11.992+(tcb->m_cWnd)+(tcb->m_cWnd)+(segmentsAcked)+(19.836)+(10.008)+(tcb->m_segmentSize)+(64.399));

}
cnt = (int) (37.848+(6.547)+(tcb->m_cWnd)+(segmentsAcked));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (21.061+(18.867)+(52.361));
cnt = (int) (52.564*(29.56));
cnt = (int) ((((84.976+(78.315)+(49.42)+(63.954)+(90.476)))+(2.845)+(22.274)+(0.1))/((0.1)));
if (cnt < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (cnt-(46.932)-(40.409)-(28.289)-(tcb->m_ssThresh)-(segmentsAcked));
	segmentsAcked = (int) (78.25+(50.984)+(segmentsAcked)+(68.201)+(tcb->m_ssThresh)+(95.39)+(66.24));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (0.1/98.815);

}
