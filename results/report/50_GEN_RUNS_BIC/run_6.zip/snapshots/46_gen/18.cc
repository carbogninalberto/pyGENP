cnt = (int) (47.617-(segmentsAcked)-(39.201)-(70.786)-(10.515));
if (tcb->m_cWnd != cnt) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(47.545)*(11.858));
	ReduceCwnd (tcb);
	cnt = (int) ((38.644*(cnt)*(79.254)*(22.576)*(tcb->m_ssThresh)*(19.807))/0.1);

} else {
	tcb->m_segmentSize = (int) (78.355/0.1);
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(2.29));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((22.936*(segmentsAcked))/0.1);
	cnt = (int) (26.923*(79.367)*(1.68)*(40.609)*(41.094)*(78.703)*(14.04)*(88.363));

} else {
	tcb->m_ssThresh = (int) (92.419-(79.019)-(tcb->m_segmentSize)-(79.705)-(15.409)-(90.058)-(segmentsAcked)-(tcb->m_segmentSize)-(4.994));
	tcb->m_cWnd = (int) (cnt*(94.797));

}
tcb->m_segmentSize = (int) (cnt*(78.826)*(52.032)*(52.354));
segmentsAcked = (int) (44.901+(80.127)+(91.712)+(cnt)+(56.596)+(11.849)+(64.34)+(63.652));
int kjUqSzvICThbaDJJ = (int) (62.584-(38.539)-(32.333)-(0.18)-(76.175)-(48.862)-(82.205)-(42.157)-(segmentsAcked));
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= cnt) {
	cnt = (int) (0.228*(66.229)*(51.443)*(cnt)*(tcb->m_segmentSize)*(81.367)*(7.261)*(tcb->m_ssThresh));
	cnt = (int) (((0.1)+((84.412+(82.221)+(62.231)+(tcb->m_segmentSize)+(66.008)+(99.124)+(57.503)+(9.609)))+(0.1)+(0.1)+(0.1)+((19.934*(24.171)*(26.93)*(kjUqSzvICThbaDJJ)*(87.989)*(96.093)*(80.829)*(92.056)*(tcb->m_segmentSize)))+(0.1))/((48.505)));
	tcb->m_cWnd = (int) (segmentsAcked-(19.867)-(72.466)-(11.848)-(cnt));

} else {
	cnt = (int) (49.967-(kjUqSzvICThbaDJJ)-(30.398));
	kjUqSzvICThbaDJJ = (int) (13.158*(12.11)*(88.038));

}
