ReduceCwnd (tcb);
float xkxfhVzdgXeCQXjg = (float) (76.846*(tcb->m_cWnd)*(tcb->m_cWnd)*(cnt)*(segmentsAcked)*(84.443)*(2.455)*(31.333));
int wzutpsCyHOFBUYYg = (int) (86.643-(1.605)-(81.504)-(66.54)-(9.396)-(cnt)-(58.712)-(86.313));
if (segmentsAcked < xkxfhVzdgXeCQXjg) {
	tcb->m_ssThresh = (int) (61.001*(60.556)*(83.357)*(38.996)*(10.748)*(60.378)*(35.898));

} else {
	tcb->m_ssThresh = (int) (((0.1)+(48.087)+((18.55*(46.915)*(67.795)*(35.55)*(4.554)*(segmentsAcked)))+((92.344-(tcb->m_cWnd)-(97.999)-(tcb->m_ssThresh)))+(30.417)+(61.672)+(0.1)+(0.1))/((0.1)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
wzutpsCyHOFBUYYg = (int) (53.386-(77.345)-(36.776)-(27.238)-(16.513)-(50.682)-(1.136));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	cnt = (int) (32.709/79.174);
	wzutpsCyHOFBUYYg = (int) (tcb->m_segmentSize+(61.519)+(74.051)+(25.802)+(tcb->m_cWnd)+(90.454)+(14.501)+(94.847));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) ((78.618*(73.43)*(tcb->m_segmentSize)*(71.02)*(50.456)*(79.041)*(segmentsAcked)*(12.871)*(75.301))/0.1);

}
