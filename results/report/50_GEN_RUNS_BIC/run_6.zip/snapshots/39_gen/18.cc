if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) ((((44.597+(tcb->m_ssThresh)+(90.13)+(segmentsAcked)+(48.946)+(19.692)+(84.209)))+(29.073)+(0.1)+(0.1)+(14.176))/((0.1)+(0.1)));
	tcb->m_segmentSize = (int) (51.201+(10.82));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (51.55-(72.55)-(52.495)-(37.342)-(39.693));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
float XJHXvsTrhCYYUbnx = (float) (48.096-(tcb->m_segmentSize));
if (tcb->m_ssThresh != XJHXvsTrhCYYUbnx) {
	XJHXvsTrhCYYUbnx = (float) (14.724+(22.483)+(99.677)+(7.515)+(XJHXvsTrhCYYUbnx)+(cnt)+(8.862));
	tcb->m_segmentSize = (int) (46.962*(73.368)*(13.81)*(86.84)*(98.826)*(tcb->m_cWnd)*(1.631));

} else {
	XJHXvsTrhCYYUbnx = (float) (69.874-(XJHXvsTrhCYYUbnx));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt != XJHXvsTrhCYYUbnx) {
	tcb->m_segmentSize = (int) (34.687*(0.616));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (94.298+(29.806)+(96.021)+(0.603));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
XJHXvsTrhCYYUbnx = (float) (24.045+(92.302)+(27.932)+(36.81));
