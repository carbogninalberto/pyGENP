if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (45.183*(95.801)*(35.617)*(0.51)*(tcb->m_segmentSize)*(68.923)*(88.804)*(63.827)*(49.519));
	segmentsAcked = (int) (47.078-(56.763)-(78.775)-(22.754)-(11.544));

} else {
	tcb->m_segmentSize = (int) (((14.048)+((63.365+(76.377)+(90.174)+(29.69)+(tcb->m_segmentSize)+(89.334)+(10.588)+(segmentsAcked)))+(0.1)+(69.939))/((72.917)));
	cnt = (int) (46.713+(12.569)+(segmentsAcked)+(52.112)+(52.273));

}
if (cnt <= tcb->m_cWnd) {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(16.596)+(43.605)+(0.1)));

} else {
	segmentsAcked = (int) (0.1/20.821);
	tcb->m_segmentSize = (int) (6.623-(58.737)-(51.685)-(77.909)-(80.999)-(81.149)-(44.74)-(66.121));

}
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_segmentSize = (int) (11.267*(51.624));
	tcb->m_segmentSize = (int) (47.818+(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (98.537+(segmentsAcked)+(cnt)+(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
