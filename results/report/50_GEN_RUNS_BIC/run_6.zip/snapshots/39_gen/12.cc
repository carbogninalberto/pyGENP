if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (24.533-(27.75)-(76.457)-(70.455)-(34.523)-(tcb->m_segmentSize)-(6.839)-(18.682));
	tcb->m_cWnd = (int) (cnt+(34.867)+(57.566)+(0.326)+(53.056)+(segmentsAcked)+(segmentsAcked)+(74.247)+(5.495));
	tcb->m_ssThresh = (int) (99.445+(40.124)+(tcb->m_ssThresh)+(35.691)+(49.291)+(86.299));

} else {
	tcb->m_ssThresh = (int) (53.879+(40.555)+(24.676)+(36.187)+(segmentsAcked)+(61.84));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (20.791*(tcb->m_cWnd));

}
tcb->m_segmentSize = (int) (38.812-(tcb->m_cWnd)-(30.541)-(8.55)-(tcb->m_cWnd)-(52.717));
if (segmentsAcked >= segmentsAcked) {
	segmentsAcked = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (19.994*(tcb->m_cWnd)*(20.968)*(30.4)*(93.117)*(41.257)*(52.757)*(68.185)*(segmentsAcked));
	tcb->m_ssThresh = (int) (37.387/86.949);
	cnt = (int) (13.158/63.103);

}
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (69.908-(23.346));
	segmentsAcked = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (12.044+(cnt)+(21.991)+(54.802)+(12.184)+(cnt)+(51.238)+(16.01));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (9.235+(90.524)+(segmentsAcked)+(tcb->m_segmentSize)+(14.715)+(63.407)+(46.845));
ReduceCwnd (tcb);
if (segmentsAcked > cnt) {
	segmentsAcked = (int) (42.853-(19.022)-(94.114)-(tcb->m_segmentSize)-(79.892)-(cnt)-(87.815));

} else {
	segmentsAcked = (int) (11.941-(87.613)-(16.685));

}
