ReduceCwnd (tcb);
if (tcb->m_cWnd != segmentsAcked) {
	segmentsAcked = (int) (94.374*(68.009)*(6.914)*(95.864)*(62.203)*(10.247));

} else {
	segmentsAcked = (int) (cnt*(24.487)*(10.394));
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+((12.157-(78.713)-(68.288)-(21.792)-(92.334)-(3.831)-(25.287)))+(6.152)+(0.1)+(89.192)+(35.534))/((36.44)));

}
if (segmentsAcked != segmentsAcked) {
	tcb->m_segmentSize = (int) (14.924*(5.728)*(38.07)*(83.176)*(tcb->m_ssThresh));
	cnt = (int) (99.626+(47.94)+(33.206)+(69.628)+(81.758)+(71.997)+(38.334)+(5.842));

} else {
	tcb->m_segmentSize = (int) (58.978*(70.781)*(20.148)*(48.913)*(44.267));

}
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (86.974+(98.695)+(16.39)+(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (39.398+(80.273)+(61.697));
	cnt = (int) (29.536-(62.61)-(tcb->m_cWnd)-(94.034)-(78.298)-(68.557)-(20.144)-(51.833));
	cnt = (int) (99.635*(tcb->m_ssThresh)*(segmentsAcked)*(1.424)*(35.18)*(86.279));

}
tcb->m_ssThresh = (int) (76.389*(49.825)*(89.287)*(22.871)*(tcb->m_ssThresh)*(23.13)*(87.231)*(56.814)*(81.43));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	cnt = (int) (tcb->m_ssThresh+(46.243)+(62.423));

} else {
	cnt = (int) (tcb->m_ssThresh*(92.05)*(cnt)*(39.848));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(25.805)+(tcb->m_segmentSize)+(27.316));

}
tcb->m_ssThresh = (int) (14.815*(14.587));
