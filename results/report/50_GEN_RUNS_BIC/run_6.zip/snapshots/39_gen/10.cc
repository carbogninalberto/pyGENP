if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+((10.751*(7.398)))+(40.317)+(0.1))/((43.764)));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (15.946+(46.18)+(tcb->m_cWnd)+(54.581)+(93.888)+(85.934)+(55.582)+(76.994));
	cnt = (int) (((0.1)+(0.1)+(0.1)+(88.992))/((0.1)+(78.983)));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((64.496)+((9.448-(73.593)-(56.154)-(tcb->m_ssThresh)-(65.916)-(33.328)-(tcb->m_segmentSize)))+((1.751+(40.052)+(36.748)))+(30.317))/((29.096)+(0.1)));
if (tcb->m_segmentSize >= cnt) {
	tcb->m_cWnd = (int) (0.1/66.91);

} else {
	tcb->m_cWnd = (int) (67.979+(49.792)+(cnt)+(69.357));

}
