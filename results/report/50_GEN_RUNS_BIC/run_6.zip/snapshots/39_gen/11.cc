ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_ssThresh) {
	segmentsAcked = (int) (41.556-(8.528));

} else {
	segmentsAcked = (int) (4.112-(tcb->m_ssThresh)-(97.697)-(76.872)-(57.232)-(67.966));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (67.024+(tcb->m_ssThresh)+(27.739));

}
tcb->m_segmentSize = (int) (2.729-(73.25)-(17.088)-(23.266));
if (tcb->m_ssThresh > cnt) {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (47.025/21.105);

} else {
	segmentsAcked = (int) (0.1/70.597);
	cnt = (int) (97.155-(64.0)-(segmentsAcked)-(98.173)-(73.509)-(84.128)-(tcb->m_segmentSize)-(3.384)-(94.296));

}
if (tcb->m_cWnd >= cnt) {
	tcb->m_segmentSize = (int) (36.73+(77.849)+(21.078)+(14.037)+(33.784));
	tcb->m_segmentSize = (int) (28.903*(61.655)*(31.972));
	cnt = (int) ((27.017-(57.478)-(6.908)-(94.729)-(cnt)-(29.903)-(cnt)-(91.128)-(54.366))/0.1);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(41.825)-(75.458)-(82.098)-(21.542)-(18.684)-(74.923)-(74.416));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (13.064*(20.732)*(77.701)*(94.11)*(40.953)*(segmentsAcked)*(43.451)*(77.702));
