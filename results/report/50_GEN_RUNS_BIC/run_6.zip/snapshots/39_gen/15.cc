tcb->m_segmentSize = (int) (17.399-(43.22)-(tcb->m_ssThresh)-(69.285));
tcb->m_cWnd = (int) (41.84/23.874);
tcb->m_cWnd = (int) (0.1/0.1);
segmentsAcked = (int) (18.334+(27.915)+(31.685)+(96.087)+(8.149)+(81.136));
ReduceCwnd (tcb);
float xhlIQmOvtESYBths = (float) (0.1/0.1);
if (xhlIQmOvtESYBths >= segmentsAcked) {
	xhlIQmOvtESYBths = (float) (73.238/4.016);
	ReduceCwnd (tcb);

} else {
	xhlIQmOvtESYBths = (float) (35.96*(12.205)*(10.279)*(4.301)*(90.165)*(86.934)*(cnt)*(63.898));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
