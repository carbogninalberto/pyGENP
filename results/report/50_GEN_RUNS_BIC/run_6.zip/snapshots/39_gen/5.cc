tcb->m_segmentSize = (int) (tcb->m_segmentSize+(51.086)+(tcb->m_cWnd));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
float XDJHfTGQqbcVtbin = (float) (60.355*(78.139)*(97.833)*(tcb->m_ssThresh));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int XFDwWDLbHPUbefqL = (int) (92.68*(66.774)*(tcb->m_cWnd));
if (segmentsAcked <= XDJHfTGQqbcVtbin) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(64.941)*(33.932)*(49.006)*(77.21)*(99.611));

} else {
	tcb->m_ssThresh = (int) (92.882+(84.872)+(80.136)+(61.781));
	ReduceCwnd (tcb);

}
