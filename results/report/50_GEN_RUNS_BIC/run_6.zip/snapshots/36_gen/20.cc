if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) ((91.915+(92.003)+(66.65))/14.272);
	segmentsAcked = (int) (27.746+(tcb->m_segmentSize)+(66.35)+(tcb->m_ssThresh)+(87.067)+(tcb->m_ssThresh)+(47.647));

} else {
	tcb->m_ssThresh = (int) (8.452-(5.236)-(tcb->m_cWnd)-(52.979)-(85.313)-(36.586)-(cnt)-(65.744)-(14.798));
	tcb->m_cWnd = (int) (12.483*(97.986)*(tcb->m_ssThresh)*(33.745)*(17.186)*(10.037)*(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (16.366*(73.383)*(85.281)*(99.762)*(95.012));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
