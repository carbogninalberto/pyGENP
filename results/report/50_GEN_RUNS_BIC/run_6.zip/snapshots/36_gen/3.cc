int FFHeiSzTnxSCEKWW = (int) (17.654-(-62.663)-(83.215));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
