float WfaPfGeKrUVdISdx = (float) (78.06/0.1);
if (tcb->m_cWnd == tcb->m_segmentSize) {
	WfaPfGeKrUVdISdx = (float) (segmentsAcked+(26.368)+(6.828));

} else {
	WfaPfGeKrUVdISdx = (float) (63.664+(tcb->m_cWnd)+(4.406)+(63.406));

}
if (tcb->m_segmentSize < WfaPfGeKrUVdISdx) {
	tcb->m_cWnd = (int) (53.475/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (0.1/96.945);
	WfaPfGeKrUVdISdx = (float) (29.824*(67.982)*(27.115)*(99.581)*(tcb->m_ssThresh)*(cnt));
	segmentsAcked = (int) (51.596+(3.996));

}
if (segmentsAcked != WfaPfGeKrUVdISdx) {
	tcb->m_cWnd = (int) (cnt*(7.885)*(61.812)*(81.431)*(84.703));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (55.809+(73.032)+(cnt)+(44.029)+(65.534)+(51.874)+(39.809));

} else {
	tcb->m_cWnd = (int) (67.25-(26.187)-(60.83)-(46.397)-(9.724));

}
if (WfaPfGeKrUVdISdx <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (25.765*(17.035)*(94.496)*(WfaPfGeKrUVdISdx)*(14.868)*(17.609)*(28.964)*(cnt));

} else {
	tcb->m_cWnd = (int) (18.201/0.1);
	tcb->m_ssThresh = (int) (23.652+(23.885)+(14.701)+(17.525)+(tcb->m_segmentSize)+(34.453));
	ReduceCwnd (tcb);

}
