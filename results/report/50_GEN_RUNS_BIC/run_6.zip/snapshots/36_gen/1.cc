int FFHeiSzTnxSCEKWW = (int) (-81.495-(-60.975)-(38.145));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
