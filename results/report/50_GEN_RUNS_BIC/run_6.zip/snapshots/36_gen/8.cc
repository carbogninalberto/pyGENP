if (cnt > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (60.186+(tcb->m_cWnd)+(32.287)+(59.5)+(44.814));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (53.931-(34.482)-(92.872)-(cnt)-(tcb->m_ssThresh)-(37.277)-(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (3.155/0.1);
	tcb->m_cWnd = (int) (76.514-(73.22)-(tcb->m_cWnd)-(53.81)-(cnt));

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	cnt = (int) (80.745+(60.014)+(75.92)+(28.593)+(71.926)+(0.706));
	cnt = (int) ((83.439*(92.114)*(segmentsAcked)*(tcb->m_cWnd))/0.1);
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(47.933)+(58.624)+(57.774)+(27.447)+(81.622)+(92.645)+(33.805));

} else {
	cnt = (int) (7.731/0.1);
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(95.005))/((83.544)+(55.873)+(0.1)));
int XCccAgUvYTVipNfA = (int) (0.1/20.665);
if (cnt >= tcb->m_segmentSize) {
	segmentsAcked = (int) (70.671+(XCccAgUvYTVipNfA)+(51.504)+(63.734)+(segmentsAcked));

} else {
	segmentsAcked = (int) (23.845-(tcb->m_cWnd)-(XCccAgUvYTVipNfA)-(94.279));
	segmentsAcked = (int) (82.25/0.1);

}
