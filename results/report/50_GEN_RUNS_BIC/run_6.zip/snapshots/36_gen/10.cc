int qNibSuvAwwuQCWmI = (int) (12.168-(tcb->m_segmentSize));
if (segmentsAcked > cnt) {
	tcb->m_segmentSize = (int) (0.1/(30.077-(68.194)-(64.383)-(segmentsAcked)-(tcb->m_segmentSize)-(43.014)));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(63.828)-(81.862)-(25.111)-(69.129)-(20.56));
	tcb->m_cWnd = (int) (36.154*(87.624)*(84.089)*(segmentsAcked));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (63.771+(54.234)+(qNibSuvAwwuQCWmI)+(75.966)+(37.127)+(51.055));
if (tcb->m_segmentSize > cnt) {
	tcb->m_cWnd = (int) ((78.35+(6.761)+(55.503)+(23.591)+(4.979)+(95.038)+(63.973)+(tcb->m_segmentSize))/0.1);
	tcb->m_ssThresh = (int) (59.214-(22.999)-(1.752)-(0.902)-(46.344)-(2.214)-(33.807)-(41.377)-(14.4));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (77.999*(96.156)*(98.341)*(55.745)*(59.086)*(76.681)*(33.096));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
qNibSuvAwwuQCWmI = (int) (13.993*(20.738)*(41.672)*(80.778)*(62.479)*(qNibSuvAwwuQCWmI)*(39.995));
