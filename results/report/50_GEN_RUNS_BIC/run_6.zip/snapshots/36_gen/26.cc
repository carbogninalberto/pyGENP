segmentsAcked = (int) (49.859+(tcb->m_cWnd)+(tcb->m_segmentSize));
ReduceCwnd (tcb);
int TvgMnZkbUvEcDlBS = (int) (6.193/0.1);
int CoPWpCMtGoqGJkzT = (int) (25.127-(tcb->m_segmentSize)-(45.845)-(12.82));
if (tcb->m_cWnd >= cnt) {
	tcb->m_segmentSize = (int) (18.0*(67.0)*(14.233)*(89.518));
	tcb->m_cWnd = (int) (TvgMnZkbUvEcDlBS-(13.53)-(16.521)-(33.969)-(6.991)-(55.676)-(51.174)-(tcb->m_ssThresh)-(CoPWpCMtGoqGJkzT));
	cnt = (int) (10.092+(1.171)+(tcb->m_segmentSize)+(3.467)+(3.159)+(98.932)+(8.546)+(35.2)+(28.353));

} else {
	tcb->m_segmentSize = (int) (15.95+(tcb->m_cWnd));

}
TvgMnZkbUvEcDlBS = (int) (39.683-(tcb->m_segmentSize)-(53.979)-(82.997)-(TvgMnZkbUvEcDlBS)-(44.268));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
