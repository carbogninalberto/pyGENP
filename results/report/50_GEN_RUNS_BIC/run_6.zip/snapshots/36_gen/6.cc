if (cnt == cnt) {
	tcb->m_cWnd = (int) (((0.1)+(16.175)+(97.893)+(58.208)+(0.1)+(21.98)+(96.561))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(28.591)-(6.786)-(27.457)-(10.985)-(tcb->m_cWnd)-(70.772)-(61.805)-(13.621));

}
if (tcb->m_segmentSize == cnt) {
	tcb->m_cWnd = (int) (85.644-(86.494)-(1.261)-(78.181)-(23.635)-(12.788)-(82.4)-(19.822)-(tcb->m_segmentSize));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (0.1/11.468);

}
cnt = (int) (89.143/79.302);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) ((((tcb->m_cWnd*(98.464)*(6.286)*(18.282)*(1.952)*(25.738)*(64.849)))+((72.133+(24.152)+(21.678)))+(0.1)+(0.1)+(0.1))/((13.863)));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(tcb->m_ssThresh)*(17.126));

} else {
	tcb->m_cWnd = (int) (31.493-(46.618));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
