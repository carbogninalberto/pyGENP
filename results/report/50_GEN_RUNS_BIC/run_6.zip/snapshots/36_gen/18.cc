if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (cnt-(64.084)-(92.124)-(44.465)-(69.621)-(54.082));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (87.154/0.1);
	tcb->m_segmentSize = (int) (0.1/0.1);

}
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (70.612*(47.678)*(cnt)*(78.719));
	tcb->m_cWnd = (int) (25.497*(segmentsAcked)*(2.804)*(62.536)*(47.094)*(93.98));

} else {
	tcb->m_ssThresh = (int) (13.54-(28.234)-(46.114)-(0.66)-(tcb->m_segmentSize)-(70.34)-(cnt));
	tcb->m_cWnd = (int) (0.1/0.1);
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (56.627*(49.414)*(96.636)*(16.728)*(18.366)*(46.125)*(87.402)*(25.586)*(4.063));
	tcb->m_ssThresh = (int) (57.69-(93.525));

} else {
	segmentsAcked = (int) (36.827/62.783);
	cnt = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((95.181)+(0.1)+(89.406)+(43.247)));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(37.76));

}
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((60.005)+(0.1)+(0.1)+(34.93))/((0.1)+(19.347)+(73.396)));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (44.544+(96.591)+(40.589)+(30.096)+(81.916)+(25.616)+(18.762)+(28.725)+(25.478));

}
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(20.4)+(12.545)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(segmentsAcked)+(27.815)+(20.536)+(24.51));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
