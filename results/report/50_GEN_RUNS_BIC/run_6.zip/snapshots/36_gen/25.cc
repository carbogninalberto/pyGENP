tcb->m_ssThresh = (int) (8.043*(86.969)*(cnt));
if (tcb->m_ssThresh >= cnt) {
	segmentsAcked = (int) (((42.834)+((34.268-(94.958)-(tcb->m_cWnd)))+(13.581)+(34.166)+((59.601*(tcb->m_ssThresh)*(58.306)*(75.378)*(92.186)*(32.078)*(52.721)))+(79.224))/((0.1)+(0.1)+(6.258)));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(28.374)-(61.896)-(24.212)-(81.756));
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (49.715+(30.281)+(cnt)+(tcb->m_ssThresh)+(segmentsAcked)+(72.848)+(35.687)+(tcb->m_cWnd)+(segmentsAcked));

}
cnt = (int) (49.153+(97.723)+(22.259)+(82.31)+(18.931)+(85.37));
tcb->m_cWnd = (int) (62.62-(81.291)-(97.666)-(7.471)-(94.256)-(4.23));
if (tcb->m_ssThresh > cnt) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(95.338)*(0.951)*(66.733)*(28.204)*(49.41));

} else {
	tcb->m_ssThresh = (int) (13.731*(59.595)*(tcb->m_segmentSize)*(67.18)*(76.805)*(23.709));

}
