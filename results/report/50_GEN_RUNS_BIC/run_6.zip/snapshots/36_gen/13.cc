int uXwTQgFZHSHHuHtZ = (int) (42.591+(43.315)+(tcb->m_segmentSize)+(45.591)+(55.869)+(40.038)+(36.511)+(59.589));
tcb->m_segmentSize = (int) (82.449+(33.84)+(0.856)+(60.615)+(tcb->m_cWnd)+(11.008));
int aVCoZFrILkwKfNOl = (int) (45.584-(tcb->m_cWnd)-(23.759)-(tcb->m_segmentSize)-(20.717)-(42.583));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (segmentsAcked-(aVCoZFrILkwKfNOl)-(91.683)-(47.028)-(tcb->m_segmentSize)-(13.763)-(95.17)-(56.138));
int VeylfVzrUqXfIDJM = (int) (69.554+(44.229)+(4.402)+(77.506)+(36.659)+(54.103)+(21.594)+(35.611)+(56.466));
if (tcb->m_cWnd < uXwTQgFZHSHHuHtZ) {
	VeylfVzrUqXfIDJM = (int) (10.667-(47.508)-(37.12)-(cnt)-(31.033));
	VeylfVzrUqXfIDJM = (int) (32.342-(50.58)-(32.14));

} else {
	VeylfVzrUqXfIDJM = (int) (83.823+(9.348)+(7.918)+(46.546)+(61.988));

}
if (uXwTQgFZHSHHuHtZ >= cnt) {
	tcb->m_segmentSize = (int) (39.145+(59.445)+(26.319)+(uXwTQgFZHSHHuHtZ)+(90.029)+(54.523)+(42.942)+(43.099));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (aVCoZFrILkwKfNOl*(15.07)*(47.039)*(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
