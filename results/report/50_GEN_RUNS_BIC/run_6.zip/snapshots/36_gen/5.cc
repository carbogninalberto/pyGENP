ReduceCwnd (tcb);
if (tcb->m_segmentSize < cnt) {
	segmentsAcked = (int) (((0.1)+((99.397*(81.769)*(73.675)))+(95.146)+(76.558)+(0.1))/((23.225)+(62.979)+(99.242)+(99.711)));
	tcb->m_segmentSize = (int) (27.029+(segmentsAcked)+(cnt)+(78.408)+(cnt)+(54.667)+(11.705)+(49.931));

} else {
	segmentsAcked = (int) ((((5.319*(16.224)*(segmentsAcked)*(47.297)*(segmentsAcked)*(2.139)*(34.315)*(78.587)*(tcb->m_segmentSize)))+(0.1)+(54.476)+(0.1)+(0.1)+(5.692))/((0.1)));

}
if (segmentsAcked < tcb->m_cWnd) {
	cnt = (int) (((84.752)+(0.1)+(96.705)+(83.881)+(75.182)+((88.828*(tcb->m_segmentSize)*(90.109)*(45.315)))+(81.187))/((62.966)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (segmentsAcked-(36.121));

} else {
	cnt = (int) (63.03+(61.2)+(43.044)+(85.781)+(tcb->m_cWnd)+(44.827));

}
tcb->m_cWnd = (int) (95.253/96.57);
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (((69.855)+(0.1)+(0.1)+(0.1))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_ssThresh = (int) (74.076*(18.94)*(22.799)*(25.808)*(92.641));
