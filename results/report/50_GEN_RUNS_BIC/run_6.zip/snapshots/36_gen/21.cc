if (cnt <= cnt) {
	cnt = (int) ((46.377*(18.778)*(cnt)*(segmentsAcked))/12.475);

} else {
	cnt = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(35.496)*(69.916)*(14.791)*(tcb->m_ssThresh)*(30.604));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (9.826-(78.134)-(30.916)-(segmentsAcked)-(78.992)-(46.601)-(40.952)-(42.131));
	tcb->m_cWnd = (int) (0.1/0.1);
	cnt = (int) (24.666*(24.345));

} else {
	tcb->m_ssThresh = (int) ((40.221-(tcb->m_ssThresh)-(7.326)-(28.845))/1.501);

}
cnt = (int) (3.978+(34.662)+(19.402)+(segmentsAcked)+(54.937)+(32.289));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
