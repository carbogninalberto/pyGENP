if (cnt != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (4.391+(7.754)+(44.621)+(tcb->m_segmentSize)+(96.504));

} else {
	tcb->m_ssThresh = (int) (20.973*(22.516)*(75.549)*(13.495)*(79.976));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (75.332-(27.156)-(20.614)-(43.31)-(31.045)-(87.532));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (42.554-(24.415)-(9.842)-(48.667)-(6.809)-(tcb->m_ssThresh)-(tcb->m_ssThresh));
cnt = (int) (70.561*(36.577));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (15.209-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(21.734)-(8.807)-(segmentsAcked)-(tcb->m_segmentSize)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (61.145+(93.701)+(6.415)+(65.981)+(58.939)+(92.294));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(4.26)*(48.467));

} else {
	tcb->m_ssThresh = (int) (26.205*(55.584)*(44.757)*(segmentsAcked));

}
int XWmLaeVmCMyjWLbN = (int) (((50.783)+(0.1)+(80.518)+(11.33)+(0.1))/((0.1)+(0.1)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
