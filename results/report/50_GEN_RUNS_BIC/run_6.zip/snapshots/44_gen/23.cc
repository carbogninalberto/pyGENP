if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (69.516*(31.945)*(18.593)*(tcb->m_segmentSize)*(12.513)*(16.856)*(91.336)*(80.208)*(7.464));
	tcb->m_cWnd = (int) ((98.46*(5.126)*(37.678)*(29.686)*(20.077))/0.1);
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(22.311)-(25.679)-(29.176)-(segmentsAcked)-(41.971)-(94.318)-(24.927)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (12.795-(51.129)-(17.989)-(86.358)-(59.232)-(24.004)-(79.162)-(59.321));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (31.411-(63.259)-(63.731)-(50.697)-(60.89)-(83.331));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int IkyxIuXckfnImykG = (int) (27.025+(70.924));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
cnt = (int) (54.184*(68.667)*(6.252)*(76.859)*(4.932)*(61.32)*(42.84)*(58.27)*(32.576));
if (IkyxIuXckfnImykG == tcb->m_ssThresh) {
	cnt = (int) (IkyxIuXckfnImykG*(40.957)*(30.083)*(83.444)*(8.899)*(54.902)*(27.664)*(63.495));

} else {
	cnt = (int) (89.145+(64.256)+(53.795)+(66.574)+(59.846)+(tcb->m_segmentSize)+(99.912)+(70.968)+(52.855));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (46.509-(24.008)-(48.657)-(5.738)-(segmentsAcked)-(22.15)-(10.194));

}
