if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (76.874+(5.371)+(21.832)+(16.411)+(21.708));

} else {
	tcb->m_segmentSize = (int) (36.611+(37.015)+(tcb->m_ssThresh)+(83.138)+(12.848)+(19.54)+(69.447)+(segmentsAcked));
	tcb->m_ssThresh = (int) (55.857-(0.501)-(67.828)-(76.958)-(26.311)-(27.183)-(20.818)-(37.297));
	tcb->m_ssThresh = (int) (7.187+(40.498)+(29.27)+(76.8)+(11.39)+(90.547)+(28.304)+(cnt));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh >= cnt) {
	cnt = (int) (61.92+(78.981)+(tcb->m_ssThresh)+(71.703)+(18.5)+(91.791)+(39.458)+(11.293)+(9.922));
	tcb->m_cWnd = (int) (53.16-(38.428)-(44.606)-(61.129)-(20.881)-(10.808)-(18.966));

} else {
	cnt = (int) ((((tcb->m_segmentSize-(26.988)-(87.918)-(0.428)-(cnt)-(51.419)-(40.061)))+(21.367)+(73.3)+(0.1)+(5.465)+(0.1)+(97.965)+(54.088))/((0.1)));
	tcb->m_ssThresh = (int) (58.339/95.746);
	segmentsAcked = (int) (tcb->m_segmentSize+(48.423));

}
if (tcb->m_cWnd < cnt) {
	tcb->m_ssThresh = (int) (cnt+(87.962));

} else {
	tcb->m_ssThresh = (int) (88.116*(44.707)*(29.089)*(tcb->m_cWnd)*(97.21)*(64.653)*(53.114)*(40.806));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (78.597*(72.947)*(10.264)*(segmentsAcked)*(tcb->m_cWnd)*(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (5.401+(34.791)+(56.545)+(29.816));

} else {
	tcb->m_segmentSize = (int) (87.594-(segmentsAcked)-(62.01)-(64.921)-(34.641)-(tcb->m_cWnd));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (((3.767)+(0.1)+(79.083)+(0.1))/((0.1)));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (cnt <= segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(60.114)*(39.238)*(40.671)*(tcb->m_cWnd)*(93.818)*(22.075)*(56.944));
	segmentsAcked = (int) (23.048/30.543);

} else {
	tcb->m_ssThresh = (int) (66.429+(7.438)+(47.532)+(24.213)+(21.125)+(11.056));

}
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (59.763-(55.631)-(segmentsAcked)-(31.068)-(79.205));

} else {
	tcb->m_ssThresh = (int) (0.1/95.975);
	tcb->m_ssThresh = (int) (44.327-(94.988)-(39.36)-(tcb->m_cWnd)-(72.811)-(59.837)-(84.948)-(3.188));
	ReduceCwnd (tcb);

}
