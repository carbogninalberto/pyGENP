if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (23.901+(85.827));
ReduceCwnd (tcb);
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (71.233*(24.903)*(15.769)*(41.093)*(91.403)*(53.137)*(3.672));

} else {
	tcb->m_ssThresh = (int) ((46.354-(32.22)-(4.641)-(3.681)-(13.608)-(33.865)-(tcb->m_ssThresh)-(14.505))/73.007);
	tcb->m_ssThresh = (int) (5.16*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(segmentsAcked));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
