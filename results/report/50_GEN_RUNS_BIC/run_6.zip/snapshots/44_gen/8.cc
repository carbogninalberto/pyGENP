ReduceCwnd (tcb);
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (34.299-(cnt));
	segmentsAcked = (int) (17.493-(cnt)-(61.941)-(95.924)-(44.821));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked+(74.532)+(13.091));
	tcb->m_ssThresh = (int) (0.1/(59.394*(37.17)*(49.551)*(90.529)*(46.932)*(cnt)*(73.495)*(segmentsAcked)));

}
int jvBJyFxxvSXgucdf = (int) (tcb->m_ssThresh*(2.703)*(7.002)*(39.6)*(64.167));
ReduceCwnd (tcb);
if (cnt > jvBJyFxxvSXgucdf) {
	segmentsAcked = (int) (44.148/0.1);

} else {
	segmentsAcked = (int) (16.38*(90.221)*(9.068)*(segmentsAcked)*(tcb->m_cWnd));
	jvBJyFxxvSXgucdf = (int) (57.226*(17.811)*(25.181)*(38.367)*(cnt)*(3.862)*(24.221)*(51.949)*(28.527));
	cnt = (int) (74.886*(7.49)*(39.432)*(58.755)*(jvBJyFxxvSXgucdf)*(44.917));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (jvBJyFxxvSXgucdf > segmentsAcked) {
	tcb->m_ssThresh = (int) (10.911+(81.029)+(48.966)+(14.112)+(20.981));

} else {
	tcb->m_ssThresh = (int) (5.636+(91.042)+(19.367)+(tcb->m_cWnd)+(jvBJyFxxvSXgucdf)+(29.077)+(tcb->m_segmentSize)+(7.442)+(46.269));
	jvBJyFxxvSXgucdf = (int) (16.098-(28.112)-(39.157)-(23.496)-(jvBJyFxxvSXgucdf)-(66.403)-(57.416));

}
