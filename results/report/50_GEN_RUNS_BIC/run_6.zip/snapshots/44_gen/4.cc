cnt = (int) ((62.488*(61.012)*(47.193)*(70.039)*(65.128)*(8.798)*(89.876)*(tcb->m_cWnd)*(64.263))/0.1);
ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (12.479/33.647);

} else {
	tcb->m_segmentSize = (int) (4.965+(87.894)+(68.465));
	segmentsAcked = (int) (93.434+(56.551)+(12.451)+(32.606)+(77.516)+(tcb->m_cWnd));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (tcb->m_cWnd-(38.177));
cnt = (int) (1.393/37.473);
