if (segmentsAcked > tcb->m_ssThresh) {
	cnt = (int) (21.399*(89.351)*(40.909));
	tcb->m_segmentSize = (int) (12.784*(3.436));
	ReduceCwnd (tcb);

} else {
	cnt = (int) ((((cnt-(56.537)-(37.525)-(80.283)-(tcb->m_cWnd)-(88.765)-(segmentsAcked)-(95.013)))+((80.112-(50.77)))+(0.1)+(54.832)+(94.922)+((tcb->m_segmentSize*(80.173)*(42.3)*(45.897)*(15.37)*(27.543)*(90.656)*(52.397)*(cnt)))+(0.1))/((0.1)));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (66.346-(86.769)-(90.643)-(30.46)-(77.172)-(44.784));

}
int mVPjUuQlQzwjYlZQ = (int) (42.711*(tcb->m_ssThresh)*(6.992));
if (mVPjUuQlQzwjYlZQ < segmentsAcked) {
	mVPjUuQlQzwjYlZQ = (int) (0.1/81.99);

} else {
	mVPjUuQlQzwjYlZQ = (int) (46.072+(85.939)+(22.397));

}
tcb->m_cWnd = (int) (90.229*(72.485)*(tcb->m_segmentSize)*(98.684)*(24.144));
if (tcb->m_ssThresh < mVPjUuQlQzwjYlZQ) {
	cnt = (int) (21.761+(91.158)+(67.265)+(47.093)+(94.478)+(99.401));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (68.832+(23.001)+(45.984)+(90.168)+(50.588)+(tcb->m_segmentSize)+(86.009));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt != mVPjUuQlQzwjYlZQ) {
	cnt = (int) (0.1/44.999);
	tcb->m_segmentSize = (int) (75.719-(32.555));

} else {
	cnt = (int) (70.499+(31.232)+(33.66)+(65.943)+(35.751));
	segmentsAcked = (int) (44.515+(14.825));
	tcb->m_ssThresh = (int) (((38.622)+((8.305-(tcb->m_segmentSize)-(60.341)-(cnt)-(95.971)-(50.001)-(91.983)-(31.38)-(94.586)))+(0.1)+(34.187))/((0.1)+(80.176)+(0.1)+(0.1)+(20.658)));

}
