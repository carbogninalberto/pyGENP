cnt = (int) (78.468-(segmentsAcked)-(63.016)-(65.033)-(86.458)-(6.654)-(7.235)-(13.487)-(72.808));
tcb->m_ssThresh = (int) (((0.1)+((69.848-(44.083)))+(41.828)+((82.536+(20.098)+(93.567)+(55.751)))+(0.1))/((0.1)+(0.1)));
tcb->m_ssThresh = (int) (tcb->m_segmentSize*(98.612)*(segmentsAcked)*(0.721)*(70.937)*(27.637)*(segmentsAcked)*(47.07)*(69.74));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (35.312*(3.115)*(33.636)*(26.751)*(7.693)*(18.441)*(68.616));
