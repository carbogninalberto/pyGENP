if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float WWzhXzVvWnZmwyWx = (float) (tcb->m_ssThresh*(95.622)*(87.29));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float ZWuhyegqXiBLhVet = (float) (74.686-(48.424)-(20.007));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
