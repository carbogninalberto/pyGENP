if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) ((90.53*(67.135)*(38.099)*(49.081)*(20.711))/10.084);

} else {
	segmentsAcked = (int) (32.208-(87.047)-(93.132));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (9.397-(33.896)-(35.429)-(1.53)-(tcb->m_cWnd)-(67.67)-(22.771)-(tcb->m_segmentSize)-(54.215));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_ssThresh = (int) (96.191+(cnt)+(11.155)+(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) ((63.52-(52.04)-(85.863)-(50.058)-(42.643)-(24.318)-(24.289)-(32.823))/63.709);

}
if (cnt <= segmentsAcked) {
	cnt = (int) (segmentsAcked+(tcb->m_ssThresh)+(96.698)+(96.416));

} else {
	cnt = (int) (96.652-(71.154)-(17.426)-(85.587)-(7.636)-(9.446)-(88.788));

}
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_ssThresh = (int) (97.842+(95.01)+(49.625)+(18.779)+(42.341)+(35.217)+(5.851));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (80.845*(segmentsAcked)*(65.647)*(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
