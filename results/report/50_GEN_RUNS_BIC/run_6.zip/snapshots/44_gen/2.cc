ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_cWnd) {
	cnt = (int) (99.9+(62.092));

} else {
	cnt = (int) (46.28+(34.935)+(96.468));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (97.995-(41.975)-(58.254)-(76.403)-(65.001)-(16.016));
if (tcb->m_cWnd < segmentsAcked) {
	cnt = (int) (4.811/0.1);
	cnt = (int) (cnt*(6.391)*(cnt)*(tcb->m_cWnd));
	cnt = (int) (((0.1)+(0.1)+(58.032)+((51.542+(23.093)+(76.968)+(74.52)+(83.544)))+(42.805)+(0.1)+(0.1)+(0.1))/((33.297)));

} else {
	cnt = (int) ((25.33*(75.178)*(69.265)*(segmentsAcked)*(19.683)*(60.542)*(81.33))/(8.664+(70.624)+(segmentsAcked)+(70.479)+(4.44)));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(64.449)+(18.973)+(80.053));
	tcb->m_segmentSize = (int) (cnt+(99.329)+(53.421));

}
tcb->m_segmentSize = (int) (((64.209)+(0.1)+(0.1)+(30.315))/((0.1)+(67.451)+(57.955)));
cnt = (int) (96.163+(8.055)+(42.703)+(segmentsAcked));
tcb->m_segmentSize = (int) (83.223-(60.318)-(10.693)-(37.101)-(cnt)-(51.793)-(36.208)-(17.002)-(11.387));
if (cnt == segmentsAcked) {
	segmentsAcked = (int) (92.656+(24.176)+(6.753)+(63.142)+(16.546));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (70.987-(34.445)-(11.969));

}
ReduceCwnd (tcb);
