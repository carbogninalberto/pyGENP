if (segmentsAcked < cnt) {
	cnt = (int) (tcb->m_cWnd+(62.306)+(33.498)+(29.214)+(82.4));

} else {
	cnt = (int) (71.759+(3.083)+(27.602));

}
tcb->m_cWnd = (int) (tcb->m_cWnd-(59.456)-(5.796)-(62.77)-(40.146)-(89.527)-(16.235)-(cnt)-(27.642));
tcb->m_ssThresh = (int) (36.535/49.776);
float dxClPFiEimwZVatn = (float) (32.834*(73.438)*(cnt));
if (tcb->m_cWnd >= dxClPFiEimwZVatn) {
	cnt = (int) (53.771-(91.119)-(10.631)-(32.448)-(61.616)-(97.39)-(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	cnt = (int) (dxClPFiEimwZVatn+(12.378)+(69.299)+(48.273)+(65.555));

}
