ReduceCwnd (tcb);
segmentsAcked = (int) ((66.514-(71.316)-(58.892)-(47.317)-(tcb->m_segmentSize)-(29.045)-(segmentsAcked))/36.952);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (56.534*(81.697)*(47.884));
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (60.544-(98.093)-(89.023)-(74.179)-(81.237));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (63.751-(24.729)-(47.746)-(tcb->m_segmentSize)-(29.369)-(67.133)-(segmentsAcked)-(12.78)-(94.194));
	tcb->m_segmentSize = (int) (3.441+(segmentsAcked)+(tcb->m_segmentSize)+(37.501)+(9.581)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (12.952-(57.759)-(19.45)-(80.759)-(47.636)-(30.818));

}
