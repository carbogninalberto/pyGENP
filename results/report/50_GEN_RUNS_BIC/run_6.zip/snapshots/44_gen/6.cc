if (tcb->m_cWnd < tcb->m_ssThresh) {
	cnt = (int) (50.307-(tcb->m_segmentSize)-(tcb->m_cWnd)-(17.982)-(16.033)-(86.425)-(44.805)-(66.253));
	cnt = (int) (tcb->m_cWnd+(98.745)+(26.536));

} else {
	cnt = (int) (((36.556)+(0.1)+((85.81*(50.856)*(tcb->m_ssThresh)*(tcb->m_segmentSize)))+(0.1))/((0.1)+(0.1)));
	segmentsAcked = (int) (41.285-(81.373)-(tcb->m_ssThresh)-(2.46)-(tcb->m_segmentSize));
	segmentsAcked = (int) (43.151*(64.216)*(12.607)*(27.054)*(tcb->m_ssThresh)*(0.832)*(55.034)*(59.777));

}
if (tcb->m_ssThresh <= cnt) {
	segmentsAcked = (int) (74.942+(segmentsAcked)+(97.859));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (12.707+(68.447)+(15.116));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (77.24+(35.42)+(62.55)+(18.098)+(49.316)+(87.618)+(tcb->m_cWnd)+(23.795));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (94.368*(22.526)*(84.766)*(84.725)*(65.587)*(40.856));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (50.42+(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(57.953)+((19.075-(segmentsAcked)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(segmentsAcked)-(73.686)-(41.448)))+(0.1)+(0.1)+(0.1))/((0.1)));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (56.102+(63.754)+(31.192)+(66.826)+(65.838)+(88.425)+(68.137));

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (59.625*(20.263)*(tcb->m_cWnd)*(0.652)*(23.826)*(92.562)*(35.531)*(12.511)*(tcb->m_ssThresh));
