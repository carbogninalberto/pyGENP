float MztnvWLjlukKLFnj = (float) (46.533-(35.445)-(24.316)-(cnt)-(48.566)-(79.655));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (segmentsAcked+(75.981)+(74.131));

} else {
	tcb->m_segmentSize = (int) (56.635-(tcb->m_ssThresh)-(89.513)-(cnt)-(90.979)-(68.757)-(63.501));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
