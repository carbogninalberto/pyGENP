tcb->m_segmentSize = (int) (76.771/4.728);
tcb->m_ssThresh = (int) (95.187/73.395);
segmentsAcked = (int) (cnt-(14.061)-(45.087)-(33.594));
int slnDHDcnuNnuGYSU = (int) (tcb->m_cWnd+(76.077)+(69.457)+(segmentsAcked)+(25.342)+(segmentsAcked));
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (66.416-(59.025));

} else {
	tcb->m_segmentSize = (int) (slnDHDcnuNnuGYSU-(slnDHDcnuNnuGYSU));

}
slnDHDcnuNnuGYSU = (int) (27.138-(47.092)-(slnDHDcnuNnuGYSU)-(36.067)-(tcb->m_ssThresh));
