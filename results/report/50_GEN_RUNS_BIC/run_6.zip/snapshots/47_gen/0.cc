float JAwCwgZHmkuAdLav = (float) 74.383;
