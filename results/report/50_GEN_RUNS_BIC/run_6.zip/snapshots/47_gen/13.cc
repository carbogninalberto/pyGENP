if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (72.699+(27.076)+(43.221)+(tcb->m_segmentSize)+(cnt)+(50.264)+(62.843));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (((32.1)+((31.11*(80.284)*(67.407)*(73.979)*(58.472)*(86.733)*(54.065)*(30.685)*(91.435)))+(60.044)+(34.6)+(50.304))/((0.1)+(0.1)));

}
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (76.005*(75.639)*(cnt)*(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (85.484*(28.622)*(83.299));
	segmentsAcked = (int) (56.573+(tcb->m_cWnd)+(tcb->m_ssThresh)+(62.195)+(98.811)+(20.071)+(7.484)+(84.965)+(50.267));
	cnt = (int) (14.974*(87.366)*(30.247));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < segmentsAcked) {
	cnt = (int) (92.307-(segmentsAcked)-(cnt)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (11.678*(13.465)*(10.331)*(52.461));
	tcb->m_ssThresh = (int) (77.344-(97.761)-(97.235)-(63.656)-(tcb->m_ssThresh)-(65.865)-(40.837)-(43.299)-(tcb->m_segmentSize));

} else {
	cnt = (int) (38.192-(69.812)-(23.78)-(14.304)-(21.718)-(54.703)-(78.536)-(9.432));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
int XuTgZiNRTVWEDxKs = (int) (35.577-(33.799)-(65.258)-(24.923)-(tcb->m_cWnd)-(28.13)-(65.153)-(90.364)-(10.248));
