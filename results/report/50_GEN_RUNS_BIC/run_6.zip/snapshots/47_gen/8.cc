int PCrfcUnJWOnnrrMH = (int) (99.119+(83.073)+(43.648));
if (PCrfcUnJWOnnrrMH > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (90.947*(77.738)*(cnt)*(77.923)*(tcb->m_ssThresh));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (37.16*(cnt)*(78.32)*(71.303)*(cnt)*(88.182)*(8.08));

} else {
	tcb->m_segmentSize = (int) (72.008+(75.38)+(29.759)+(33.013)+(47.312)+(1.207));
	tcb->m_cWnd = (int) (60.908*(89.078)*(92.979)*(23.527));

}
PCrfcUnJWOnnrrMH = (int) (11.613+(35.479)+(4.942)+(71.939)+(tcb->m_ssThresh)+(75.861)+(32.993));
cnt = (int) (9.451+(70.185)+(60.006)+(tcb->m_segmentSize)+(80.093)+(24.814)+(44.954)+(15.126)+(30.792));
if (PCrfcUnJWOnnrrMH == tcb->m_cWnd) {
	PCrfcUnJWOnnrrMH = (int) (59.886*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(48.129)*(62.789)*(10.877)*(56.227)*(25.056));

} else {
	PCrfcUnJWOnnrrMH = (int) (18.774+(84.085)+(91.261));

}
ReduceCwnd (tcb);
float XxyovvwqfzjuiSUx = (float) (((0.1)+((34.832*(50.78)*(26.324)*(95.87)*(segmentsAcked)*(75.375)*(27.743)*(68.448)*(15.893)))+(0.1)+((41.962*(74.517)*(96.937)))+((18.628*(tcb->m_cWnd)*(segmentsAcked)*(73.371)))+(0.1))/((56.051)+(71.506)+(39.268)));
float JoDDoXAsplUFpFyi = (float) (tcb->m_cWnd+(42.976)+(78.969));
int pLJKWPVxwguMyPnb = (int) (0.1/(78.548*(63.454)*(tcb->m_ssThresh)*(cnt)*(segmentsAcked)*(22.131)*(37.426)*(XxyovvwqfzjuiSUx)*(XxyovvwqfzjuiSUx)));
