if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (0.1/30.463);
tcb->m_cWnd = (int) ((48.831+(70.758)+(84.948)+(42.839)+(43.137)+(94.904)+(65.712))/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (50.195*(75.776)*(7.125)*(32.133)*(segmentsAcked)*(85.515));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (8.784/0.1);
	tcb->m_ssThresh = (int) (76.686*(36.836)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(67.593));

}
if (segmentsAcked >= cnt) {
	segmentsAcked = (int) (63.843-(38.676)-(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (75.853/97.485);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (84.58*(13.97)*(8.509)*(48.984)*(tcb->m_ssThresh)*(4.165)*(5.462)*(11.387));

}
