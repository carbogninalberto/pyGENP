if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (10.056-(87.925)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (61.615/0.1);
	tcb->m_cWnd = (int) (97.415-(cnt)-(66.424)-(79.326)-(6.31));
	segmentsAcked = (int) ((((91.944+(tcb->m_cWnd)+(50.446)+(tcb->m_segmentSize)+(73.464)+(47.577)+(cnt)+(24.479)))+((8.416-(28.365)-(cnt)-(63.646)))+(0.1)+(31.183))/((0.1)+(0.1)+(87.506)+(75.505)));

}
int iispmhGVTxxLFQCH = (int) (tcb->m_ssThresh+(14.098)+(89.636));
if (iispmhGVTxxLFQCH <= segmentsAcked) {
	tcb->m_segmentSize = (int) (54.266/67.257);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
