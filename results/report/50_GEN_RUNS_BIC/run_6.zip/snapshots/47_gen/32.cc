if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (((32.931)+(18.971)+(62.581)+(0.1))/((66.798)+(0.1)+(0.1)+(27.055)));
segmentsAcked = (int) (7.181*(40.005)*(tcb->m_cWnd)*(55.458)*(9.381)*(85.761)*(38.146));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (57.15-(tcb->m_segmentSize)-(6.835)-(52.041)-(92.32));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (38.562*(69.864)*(83.564)*(34.291)*(tcb->m_cWnd)*(13.405)*(92.936)*(4.32));
	tcb->m_segmentSize = (int) (segmentsAcked-(40.684));

}
