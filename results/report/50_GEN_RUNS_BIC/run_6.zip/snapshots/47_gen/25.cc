cnt = (int) (tcb->m_segmentSize-(99.806)-(56.435)-(45.261)-(tcb->m_cWnd)-(73.833)-(segmentsAcked)-(41.041));
float ByTyewgnRzfUVmJB = (float) (0.1/0.1);
if (tcb->m_ssThresh == cnt) {
	tcb->m_cWnd = (int) (50.485*(98.999)*(93.713)*(47.789));
	ReduceCwnd (tcb);
	cnt = (int) (99.404-(22.847)-(3.737)-(50.374)-(62.641));

} else {
	tcb->m_cWnd = (int) ((((tcb->m_cWnd-(38.964)-(tcb->m_cWnd)-(15.255)-(50.984)-(66.92)-(tcb->m_cWnd)))+(95.162)+(0.1)+(36.583)+(80.442)+(0.1))/((0.1)));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_ssThresh = (int) (74.254-(80.518)-(tcb->m_segmentSize)-(29.973)-(57.805)-(segmentsAcked)-(77.743)-(30.374));
	tcb->m_cWnd = (int) (46.642+(78.355)+(56.5)+(tcb->m_cWnd)+(cnt));

} else {
	tcb->m_ssThresh = (int) (72.309-(45.935)-(74.597)-(41.459)-(4.334)-(48.108)-(91.186)-(cnt));

}
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_ssThresh = (int) (segmentsAcked+(17.998)+(64.705)+(74.127)+(20.323)+(22.649)+(ByTyewgnRzfUVmJB)+(87.045));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(36.627)+(54.594));
	ReduceCwnd (tcb);

}
cnt = (int) (40.35/0.1);
ReduceCwnd (tcb);
