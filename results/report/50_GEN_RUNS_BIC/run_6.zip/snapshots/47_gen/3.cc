float gErPBCaYApTCbCbX = (float) (segmentsAcked*(52.695)*(tcb->m_ssThresh)*(25.964)*(30.973)*(20.466)*(86.85));
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_segmentSize = (int) (22.058+(77.799)+(38.21)+(8.885));

} else {
	tcb->m_segmentSize = (int) (35.687/35.465);
	tcb->m_ssThresh = (int) (0.1/0.1);

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.423*(87.754)*(80.564)*(58.979)*(35.772)*(3.143)*(74.628));

} else {
	tcb->m_cWnd = (int) (0.1/59.062);

}
ReduceCwnd (tcb);
int LUgfmxDHKttENdDD = (int) ((26.774-(62.189)-(41.631)-(40.02))/0.1);
if (LUgfmxDHKttENdDD == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (5.489*(76.343)*(96.984)*(62.31));
	gErPBCaYApTCbCbX = (float) (tcb->m_segmentSize+(75.488));

} else {
	tcb->m_ssThresh = (int) ((((66.635+(72.09)+(70.466)+(82.731)+(53.426)+(66.097)+(23.913)+(91.926)))+((tcb->m_ssThresh*(25.37)*(63.138)*(40.174)*(2.484)*(67.153)*(19.652)*(44.852)*(segmentsAcked)))+(0.1)+(0.1)+(0.1))/((0.1)));
	LUgfmxDHKttENdDD = (int) (cnt-(62.99)-(32.555)-(cnt)-(52.386)-(14.666));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (6.875+(cnt)+(2.798)+(18.123)+(38.996)+(1.528)+(44.975)+(gErPBCaYApTCbCbX));
