if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/39.889);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (43.164+(89.309)+(52.724)+(94.229)+(63.612)+(79.361)+(95.83)+(segmentsAcked)+(34.904));
	tcb->m_ssThresh = (int) (7.016-(38.677)-(90.238)-(31.35));

}
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (71.791+(76.118)+(tcb->m_segmentSize)+(12.531)+(71.29)+(cnt)+(11.009)+(93.842)+(0.934));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (86.181*(69.777)*(95.536)*(segmentsAcked)*(56.527)*(47.355)*(40.323));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (51.291*(44.042)*(77.34)*(51.104)*(38.509)*(82.274));
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(83.193)*(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (13.7+(segmentsAcked)+(83.48));

}
