tcb->m_cWnd = (int) (tcb->m_cWnd-(38.337));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (86.811+(95.321)+(59.091)+(3.926));
ReduceCwnd (tcb);
float AHuAfCpMzvdbTBUI = (float) (74.514+(segmentsAcked)+(17.444)+(14.392)+(75.02)+(77.44)+(35.193)+(63.234));
