ReduceCwnd (tcb);
if (cnt != tcb->m_cWnd) {
	segmentsAcked = (int) (84.676-(36.471)-(91.946)-(cnt));

} else {
	segmentsAcked = (int) ((86.769*(64.461)*(60.955)*(tcb->m_segmentSize)*(43.518)*(83.22))/0.1);
	tcb->m_segmentSize = (int) (1.348-(72.64)-(71.229)-(82.976)-(25.989)-(tcb->m_ssThresh)-(90.777)-(20.773));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd == cnt) {
	tcb->m_ssThresh = (int) (84.788+(22.07)+(80.852)+(90.123)+(cnt)+(98.959)+(tcb->m_ssThresh)+(99.254)+(27.15));
	tcb->m_ssThresh = (int) ((((24.199+(14.314)))+(26.793)+(23.002)+(55.805))/((0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (9.524-(42.939)-(17.536)-(36.598)-(2.706));
	tcb->m_segmentSize = (int) (2.771+(53.39)+(49.211)+(27.521));

}
if (segmentsAcked == cnt) {
	tcb->m_ssThresh = (int) (61.714/15.148);
	tcb->m_cWnd = (int) (32.138*(98.818)*(1.808)*(cnt)*(32.628));
	segmentsAcked = (int) (66.08-(84.318));

} else {
	tcb->m_ssThresh = (int) (47.502/10.367);
	tcb->m_segmentSize = (int) (9.063-(cnt)-(2.077)-(55.868)-(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
float EQbnWeCIchxwlLWI = (float) (45.335+(4.688)+(59.794)+(46.543)+(68.904));
