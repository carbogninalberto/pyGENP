if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(42.229)-(36.261)-(36.376)-(cnt)-(36.753)-(10.387)-(44.398)-(22.647));

} else {
	tcb->m_ssThresh = (int) (70.879+(81.322)+(segmentsAcked));
	tcb->m_cWnd = (int) (65.782+(tcb->m_cWnd)+(22.895)+(45.252)+(73.636));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (59.337-(2.09)-(56.376)-(50.443)-(96.763));
int LtRlHqCYJEtAFIaP = (int) (1.78-(48.248)-(4.042)-(60.509)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(20.037)-(16.285));
