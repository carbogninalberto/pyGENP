ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) ((((cnt*(tcb->m_segmentSize)*(54.455)*(30.86)*(59.347)*(77.352)*(96.771)*(22.055)*(54.412)))+(53.198)+((1.616-(19.957)-(39.642)-(64.89)-(63.096)-(31.803)-(46.131)-(2.43)))+(63.015))/((46.342)+(0.1)));
tcb->m_ssThresh = (int) (54.214-(79.197)-(segmentsAcked)-(33.219));
int PmmNPTEymFBWEzeB = (int) ((46.048-(75.702))/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (65.543+(73.081)+(25.946)+(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
