if (tcb->m_ssThresh == tcb->m_ssThresh) {
	cnt = (int) (62.598-(54.807)-(1.953)-(tcb->m_cWnd)-(86.646)-(83.094)-(98.004)-(18.797));

} else {
	cnt = (int) (16.156-(4.988)-(61.089)-(95.552));
	segmentsAcked = (int) (86.754*(3.738)*(tcb->m_cWnd)*(91.178)*(segmentsAcked)*(62.438));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
float qHNbtnkSPRRVFKed = (float) (((8.386)+(0.1)+(0.1)+(42.215)+(19.586))/((0.1)));
tcb->m_segmentSize = (int) (43.587+(31.555));
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= cnt) {
	tcb->m_segmentSize = (int) (segmentsAcked-(segmentsAcked)-(8.11));
	tcb->m_ssThresh = (int) ((62.795+(70.117)+(cnt)+(14.921))/0.1);

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(83.076)+(12.525));
	segmentsAcked = (int) (5.78-(22.026)-(qHNbtnkSPRRVFKed)-(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (11.867*(39.011)*(40.936)*(74.22)*(tcb->m_segmentSize)*(4.502)*(tcb->m_ssThresh)*(98.691));

}
