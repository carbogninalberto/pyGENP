ReduceCwnd (tcb);
float TwwTvcVbtuoDOTBJ = (float) (tcb->m_ssThresh-(tcb->m_cWnd));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (67.681-(cnt)-(cnt)-(49.541)-(cnt)-(61.156)-(81.447)-(0.067)-(cnt));
cnt = (int) (97.743+(29.341)+(41.46)+(20.367)+(42.829)+(54.276)+(14.274)+(cnt));
