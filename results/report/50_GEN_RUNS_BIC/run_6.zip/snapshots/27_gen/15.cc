float KKYXPiimGeIcdLhM = (float) (segmentsAcked+(tcb->m_segmentSize)+(segmentsAcked)+(1.1)+(16.915)+(10.872)+(46.517));
tcb->m_ssThresh = (int) (KKYXPiimGeIcdLhM+(27.6)+(KKYXPiimGeIcdLhM)+(38.244)+(cnt)+(79.414)+(tcb->m_segmentSize));
if (KKYXPiimGeIcdLhM < cnt) {
	cnt = (int) (17.007-(71.415)-(8.739)-(72.11));

} else {
	cnt = (int) (0.1/(36.493-(27.517)-(3.389)-(31.619)-(tcb->m_ssThresh)-(71.562)-(41.063)-(46.381)-(cnt)));

}
segmentsAcked = (int) (55.895-(13.22)-(75.656)-(76.649)-(8.314)-(tcb->m_ssThresh)-(45.837));
if (tcb->m_cWnd < cnt) {
	segmentsAcked = (int) (55.672+(78.88)+(88.952)+(60.594)+(18.588)+(0.926));

} else {
	segmentsAcked = (int) (26.411+(38.77)+(63.103)+(tcb->m_cWnd));

}
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	cnt = (int) (77.568-(5.033)-(29.621)-(43.28)-(85.437));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (40.047*(39.239)*(tcb->m_segmentSize)*(1.547)*(21.791));
	segmentsAcked = (int) (31.012+(tcb->m_segmentSize)+(63.444)+(4.576)+(20.452)+(52.418)+(cnt)+(88.8));

}
if (KKYXPiimGeIcdLhM == tcb->m_cWnd) {
	KKYXPiimGeIcdLhM = (float) (71.439+(segmentsAcked)+(55.153)+(22.338)+(51.722)+(68.038)+(tcb->m_cWnd));

} else {
	KKYXPiimGeIcdLhM = (float) (45.089*(90.492)*(25.717)*(80.55)*(6.48));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) ((((73.861+(69.801)+(92.798)+(24.264)+(2.73)+(11.129)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(77.723)))+(0.1)+(0.1)+(50.063)+(42.086))/((72.687)+(56.24)+(21.413)+(0.1)));

}
tcb->m_ssThresh = (int) (tcb->m_cWnd+(tcb->m_segmentSize)+(65.356));
