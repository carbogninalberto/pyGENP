ReduceCwnd (tcb);
segmentsAcked = (int) (-15.362*(4.358)*(80.843)*(-79.228)*(9.876));
