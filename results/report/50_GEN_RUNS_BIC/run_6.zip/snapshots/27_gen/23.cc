tcb->m_segmentSize = (int) (23.721+(25.232)+(23.293)+(20.375)+(tcb->m_cWnd)+(50.477));
segmentsAcked = (int) (26.594-(51.364));
tcb->m_ssThresh = (int) (17.389-(40.473)-(4.384)-(13.784)-(70.469)-(45.768)-(58.791));
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/3.729);

} else {
	tcb->m_cWnd = (int) (59.439+(20.376));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (71.735-(tcb->m_ssThresh)-(segmentsAcked));
cnt = (int) (((5.06)+(0.1)+(0.1)+(0.1)+(0.1)+(88.615)+(0.1)+(92.352))/((28.799)));
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((((46.706+(37.022)+(37.16)+(54.346)+(70.998)))+(0.1)+((38.412-(52.524)-(47.159)-(segmentsAcked)-(67.199)-(23.903)-(70.724)-(68.888)))+(0.1))/((76.398)));

} else {
	tcb->m_cWnd = (int) (56.213/0.1);

}
int qRBdpmivXBSzqsSu = (int) (86.109/69.918);
