if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (93.516+(6.338));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
if (segmentsAcked == cnt) {
	tcb->m_segmentSize = (int) (43.513-(44.837)-(98.426)-(48.846)-(tcb->m_segmentSize)-(78.667)-(32.306)-(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (18.49/12.884);

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((68.737)+(65.456)+(34.033)+(30.342)+(25.074)+((67.916+(32.418)))+((82.63*(tcb->m_cWnd)*(79.726)*(15.776)*(49.018)*(69.344)*(tcb->m_ssThresh)))+(0.1))/((38.646)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (3.627+(54.17)+(55.874)+(4.801));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (cnt >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (30.736+(74.802)+(tcb->m_cWnd)+(51.551)+(10.592)+(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (51.504-(53.213)-(52.376));

} else {
	tcb->m_ssThresh = (int) (93.424+(39.983));

}
ReduceCwnd (tcb);
