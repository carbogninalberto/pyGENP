ReduceCwnd (tcb);
if (tcb->m_cWnd >= cnt) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(segmentsAcked)-(89.43)-(tcb->m_cWnd));
	segmentsAcked = (int) (61.484+(9.961)+(71.759)+(87.805)+(71.699)+(76.075)+(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(43.072)-(82.473)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (2.831*(tcb->m_segmentSize)*(tcb->m_cWnd)*(tcb->m_cWnd));
	tcb->m_cWnd = (int) (cnt*(20.999)*(tcb->m_segmentSize)*(51.631)*(cnt)*(segmentsAcked)*(53.398)*(96.971));

}
int KndxQALpIqnRCesA = (int) (55.031+(segmentsAcked)+(75.604)+(cnt)+(14.527));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (32.053/0.1);
	segmentsAcked = (int) (66.874/67.314);

} else {
	tcb->m_segmentSize = (int) (7.076-(tcb->m_cWnd)-(tcb->m_segmentSize)-(33.452)-(97.09)-(segmentsAcked)-(5.848));

}
tcb->m_ssThresh = (int) (-0.063+(81.308)+(43.218)+(94.098)+(79.633)+(52.627)+(74.222)+(67.412)+(78.606));
if (KndxQALpIqnRCesA > tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_ssThresh*(tcb->m_cWnd)*(43.243)*(41.443)*(17.202)*(71.921)*(36.939));

} else {
	segmentsAcked = (int) (43.798-(32.293)-(KndxQALpIqnRCesA)-(78.419)-(tcb->m_segmentSize)-(16.684)-(22.515)-(80.347));
	cnt = (int) (((65.324)+(55.589)+(34.247)+(0.1)+(0.1)+(0.1))/((0.1)+(92.541)));

}
