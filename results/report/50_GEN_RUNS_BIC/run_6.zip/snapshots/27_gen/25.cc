if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((0.1)+((cnt-(7.037)-(31.684)-(1.249)-(41.844)-(2.15)-(segmentsAcked)))+((5.724*(25.567)*(43.6)*(tcb->m_cWnd)*(60.338)*(47.673)*(26.023)*(53.047)*(64.319)))+(0.1))/((66.555)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (77.924+(36.229)+(59.424)+(46.125)+(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd != tcb->m_cWnd) {
	segmentsAcked = (int) (13.019-(96.699)-(8.289)-(36.941)-(52.561)-(tcb->m_ssThresh)-(88.52)-(45.367));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (93.831*(50.595)*(segmentsAcked)*(cnt)*(45.943)*(7.261));
	cnt = (int) (62.423*(17.333)*(55.747));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int bcjtVffIDAwjQQrR = (int) (13.172+(13.525)+(43.328)+(58.491)+(tcb->m_ssThresh));
