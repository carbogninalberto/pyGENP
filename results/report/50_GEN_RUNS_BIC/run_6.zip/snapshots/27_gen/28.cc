if (tcb->m_segmentSize > cnt) {
	cnt = (int) (tcb->m_ssThresh-(70.055)-(34.843)-(73.55)-(5.45)-(99.596));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (13.177+(14.474)+(72.857)+(tcb->m_ssThresh)+(tcb->m_cWnd));

} else {
	cnt = (int) (38.488-(79.132)-(28.832)-(61.829)-(71.477)-(20.141));

}
tcb->m_cWnd = (int) (0.1/64.328);
tcb->m_cWnd = (int) (14.784+(segmentsAcked)+(65.263)+(tcb->m_cWnd)+(10.28)+(14.99));
segmentsAcked = (int) (0.35*(83.24)*(78.396)*(tcb->m_cWnd)*(22.482)*(20.241)*(88.624)*(13.729));
ReduceCwnd (tcb);
if (cnt > cnt) {
	cnt = (int) (((83.951)+(98.987)+(84.55)+(76.996)+((19.914+(90.289)+(78.863)+(tcb->m_cWnd)+(19.898)+(tcb->m_segmentSize)))+(0.1)+(38.789)+(90.369))/((0.1)));

} else {
	cnt = (int) (82.856*(99.77)*(88.866)*(93.533)*(90.113)*(78.616));
	tcb->m_cWnd = (int) (segmentsAcked*(cnt)*(54.482)*(80.816)*(73.494)*(45.043)*(43.273)*(tcb->m_segmentSize)*(95.101));

}
tcb->m_ssThresh = (int) (tcb->m_ssThresh-(11.624)-(93.407)-(1.951)-(tcb->m_segmentSize)-(90.014)-(tcb->m_ssThresh));
