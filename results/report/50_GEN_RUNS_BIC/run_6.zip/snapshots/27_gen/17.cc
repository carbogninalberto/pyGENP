segmentsAcked = (int) (((0.1)+(49.313)+(28.18)+(0.1)+((81.29*(45.873)*(55.745)*(48.246)*(21.792)))+(3.675))/((0.1)+(0.1)+(28.771)));
tcb->m_ssThresh = (int) (23.282*(36.019)*(83.628)*(88.543)*(86.046)*(24.761));
tcb->m_segmentSize = (int) (30.677+(44.678)+(14.497)+(74.715));
tcb->m_ssThresh = (int) (tcb->m_cWnd-(78.762)-(32.675)-(9.714)-(12.652)-(52.424));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (11.457*(tcb->m_cWnd)*(tcb->m_segmentSize)*(segmentsAcked)*(80.351)*(42.305));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
