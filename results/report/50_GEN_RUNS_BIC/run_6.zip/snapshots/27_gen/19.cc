if (segmentsAcked > cnt) {
	tcb->m_segmentSize = (int) ((94.309-(44.051)-(tcb->m_cWnd)-(58.273)-(76.803)-(78.885)-(72.151)-(70.718))/63.073);
	tcb->m_ssThresh = (int) (segmentsAcked+(tcb->m_ssThresh)+(3.916));
	tcb->m_segmentSize = (int) (0.1/41.948);

} else {
	tcb->m_segmentSize = (int) (79.417+(18.145)+(cnt)+(97.751)+(46.923)+(68.204)+(34.165)+(99.327));
	tcb->m_ssThresh = (int) (4.977/16.814);

}
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (80.462+(segmentsAcked)+(12.117));
	tcb->m_cWnd = (int) (56.156*(25.862));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(10.774)*(45.499)*(29.324)*(28.481));

} else {
	tcb->m_cWnd = (int) ((82.229+(tcb->m_segmentSize)+(62.842)+(83.889)+(61.803)+(50.625)+(79.888)+(64.189))/65.379);

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_cWnd) {
	segmentsAcked = (int) (35.26/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (((57.689)+(67.396)+(21.893)+(64.414)+(0.1)+(0.1))/((0.1)+(73.121)+(0.1)));

}
int xVJnprzLPHoxxzjH = (int) (0.1/75.233);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
