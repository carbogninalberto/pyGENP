ReduceCwnd (tcb);
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(32.373)+(36.353));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	segmentsAcked = (int) (49.972+(tcb->m_cWnd)+(cnt));
	cnt = (int) (6.016*(88.924)*(cnt)*(81.202));

}
if (segmentsAcked >= cnt) {
	tcb->m_cWnd = (int) (7.012*(12.151)*(4.239)*(14.932)*(73.049)*(56.808));
	segmentsAcked = (int) (41.196/62.84);

} else {
	tcb->m_cWnd = (int) (60.988+(tcb->m_ssThresh)+(36.594)+(23.771)+(4.876)+(54.073));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (tcb->m_ssThresh-(42.048)-(segmentsAcked)-(61.867)-(38.853)-(tcb->m_segmentSize)-(1.158)-(76.796)-(68.532));

}
segmentsAcked = (int) (96.215*(77.323)*(57.243));
int csplalyIoGbIrTwt = (int) (tcb->m_segmentSize*(41.846)*(tcb->m_ssThresh)*(51.843)*(cnt)*(85.576)*(27.295));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
