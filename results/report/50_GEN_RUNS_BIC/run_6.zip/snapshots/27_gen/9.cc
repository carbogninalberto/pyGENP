tcb->m_segmentSize = (int) (34.457/65.974);
segmentsAcked = (int) (71.313*(-73.237)*(-3.764)*(-9.753)*(-59.487));
