int TPAwBukpSqZmJEud = (int) (18.103/-12.237);
tcb->m_cWnd = (int) (-50.406-(-88.229)-(-20.699));
int PyGVdzPejdbyGSDQ = (int) (-60.58/-91.147);
ReduceCwnd (tcb);
