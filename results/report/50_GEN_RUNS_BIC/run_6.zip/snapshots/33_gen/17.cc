if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (6.258+(31.987)+(94.008)+(63.012)+(23.048)+(13.51)+(30.42));

} else {
	segmentsAcked = (int) (62.118+(3.061)+(72.122)+(12.129));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= cnt) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (99.247+(30.333)+(35.771)+(60.2)+(51.261)+(17.015));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	segmentsAcked = (int) (96.039/2.312);
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(18.576));

} else {
	segmentsAcked = (int) (((72.027)+(0.1)+(0.1)+(33.919))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (78.192-(44.088)-(80.089)-(76.344)-(11.02)-(65.182));

}
int kkfGBOyxbBmNmOmr = (int) (55.023/54.047);
tcb->m_segmentSize = (int) (65.409-(26.351)-(10.053)-(20.683)-(71.728)-(tcb->m_cWnd)-(60.685));
if (kkfGBOyxbBmNmOmr > kkfGBOyxbBmNmOmr) {
	tcb->m_cWnd = (int) (52.346-(50.262));

} else {
	tcb->m_cWnd = (int) (67.306-(36.675));
	tcb->m_segmentSize = (int) (84.133+(2.293)+(51.261)+(85.304));

}
int QJvTNsVIQwXFaoXM = (int) (kkfGBOyxbBmNmOmr-(96.084)-(segmentsAcked)-(61.132)-(32.701)-(48.855));
ReduceCwnd (tcb);
