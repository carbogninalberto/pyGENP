float NuDUTBSqyeXSizpE = (float) (-72.594-(-53.217));
tcb->m_segmentSize = (int) (76.552-(14.419)-(-84.863)-(-37.44)-(95.366));
tcb->m_cWnd = (int) (-83.343+(62.165)+(-1.167)+(8.958)+(-43.115)+(-79.028)+(-69.716)+(4.744)+(93.548));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
