segmentsAcked = (int) (13.947-(44.819));
ReduceCwnd (tcb);
int tielxCrVAzytGhpW = (int) ((69.144*(54.255)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(58.017)*(tcb->m_cWnd))/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tielxCrVAzytGhpW = (int) (13.053*(33.379)*(49.078)*(cnt)*(26.365)*(79.661)*(87.868)*(tcb->m_ssThresh)*(segmentsAcked));
if (tielxCrVAzytGhpW > cnt) {
	tcb->m_ssThresh = (int) (86.8/0.1);

} else {
	tcb->m_ssThresh = (int) (-0.09*(34.276));

}
