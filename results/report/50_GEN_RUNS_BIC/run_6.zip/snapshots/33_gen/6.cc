int TPAwBukpSqZmJEud = (int) (32.895/37.582);
segmentsAcked = (int) (-60.856+(95.131)+(55.594)+(2.795)+(-60.403)+(-43.065));
tcb->m_cWnd = (int) (-30.55-(-44.631)-(-18.864));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TPAwBukpSqZmJEud = (int) (-89.142/31.813);
TPAwBukpSqZmJEud = (int) (9.185/41.777);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
