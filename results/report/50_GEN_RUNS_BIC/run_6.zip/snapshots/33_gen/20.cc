if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked <= tcb->m_cWnd) {
	cnt = (int) (3.262*(21.504)*(95.157)*(51.368)*(63.398));

} else {
	cnt = (int) (cnt-(46.093)-(5.42)-(66.44)-(41.332)-(21.131));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked <= cnt) {
	segmentsAcked = (int) (84.44+(97.471)+(segmentsAcked));
	segmentsAcked = (int) (35.796-(tcb->m_segmentSize)-(cnt));

} else {
	segmentsAcked = (int) (((63.583)+(0.1)+((tcb->m_segmentSize+(69.316)+(cnt)+(46.505)+(segmentsAcked)+(58.553)+(86.326)+(47.999)))+(59.522)+(0.1)+(0.1)+((94.618+(36.631)+(0.808)+(tcb->m_cWnd)))+(0.1))/((0.1)));
	cnt = (int) (9.969+(72.789)+(18.205));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
