ReduceCwnd (tcb);
tcb->m_cWnd = (int) (78.365*(43.857)*(14.233)*(65.479)*(30.032)*(38.347)*(25.24)*(31.215));
if (tcb->m_cWnd != tcb->m_ssThresh) {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (30.12*(19.152)*(31.246)*(39.705)*(41.779)*(39.753)*(tcb->m_cWnd)*(85.456));

} else {
	segmentsAcked = (int) (88.941+(72.041)+(25.29)+(tcb->m_cWnd)+(47.418)+(segmentsAcked)+(59.247)+(93.157)+(89.648));
	tcb->m_segmentSize = (int) (39.084-(7.457)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(40.913)-(tcb->m_segmentSize));

}
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (82.959-(tcb->m_ssThresh)-(12.065)-(86.04));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(tcb->m_cWnd)-(27.503)-(6.508)-(77.497)-(88.057)-(14.542)-(98.502));
	cnt = (int) (62.086+(19.948)+(47.972)+(segmentsAcked)+(37.81)+(tcb->m_segmentSize)+(34.491));

} else {
	tcb->m_segmentSize = (int) (19.591-(22.927)-(78.691)-(63.152)-(tcb->m_segmentSize)-(92.908)-(16.208)-(77.835));
	tcb->m_segmentSize = (int) (98.846-(49.274)-(75.815)-(18.48)-(13.919)-(segmentsAcked)-(5.485)-(74.801));

}
if (segmentsAcked <= segmentsAcked) {
	cnt = (int) ((((88.154*(31.104)*(50.811)*(18.315)*(57.184)*(73.583)*(32.291)*(5.607)*(tcb->m_segmentSize)))+(57.284)+(0.1)+(81.206))/((0.1)));
	cnt = (int) (84.841*(25.712));

} else {
	cnt = (int) (((0.1)+((cnt*(segmentsAcked)*(65.915)*(94.431)*(tcb->m_cWnd)*(84.529)*(tcb->m_cWnd)*(57.982)*(32.843)))+(0.1)+(0.1)+(2.344))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (55.703+(23.461)+(8.872)+(65.091)+(tcb->m_cWnd)+(segmentsAcked)+(cnt)+(76.051)+(tcb->m_ssThresh));
tcb->m_segmentSize = (int) (63.016*(79.358)*(63.217));
int GNEkfvMdeQlOTsCF = (int) (((0.1)+(0.1)+(0.1)+(19.562))/((0.1)+(57.578)));
if (tcb->m_ssThresh > GNEkfvMdeQlOTsCF) {
	GNEkfvMdeQlOTsCF = (int) (0.1/0.1);

} else {
	GNEkfvMdeQlOTsCF = (int) (44.412*(cnt)*(58.362)*(34.854)*(64.511)*(tcb->m_segmentSize)*(56.983)*(GNEkfvMdeQlOTsCF)*(5.265));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
