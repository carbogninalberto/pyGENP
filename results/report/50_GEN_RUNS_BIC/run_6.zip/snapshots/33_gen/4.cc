float sDhDQnwylTqZQsQY = (float) (35.882*(39.967)*(-47.61)*(-1.235)*(83.867));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (57.073*(92.746)*(35.862)*(sDhDQnwylTqZQsQY));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (9.878+(24.715));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-0.698-(5.888)-(-49.617)-(33.563)-(-53.27)-(-22.423)-(11.149));
