if (tcb->m_cWnd < tcb->m_segmentSize) {
	cnt = (int) (0.1/6.674);

} else {
	cnt = (int) (26.844-(76.138)-(22.229)-(55.716)-(17.041)-(cnt)-(88.415)-(67.451));

}
int NIBdQTMaRzYSFtbr = (int) (2.486-(49.236)-(69.886)-(8.472));
NIBdQTMaRzYSFtbr = (int) (4.402-(63.802)-(46.517)-(23.476));
if (cnt >= tcb->m_ssThresh) {
	cnt = (int) (24.167*(41.722)*(40.601)*(78.347)*(55.08)*(66.062)*(NIBdQTMaRzYSFtbr));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (NIBdQTMaRzYSFtbr+(tcb->m_ssThresh));
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(87.831)*(69.301)*(90.862)*(79.98)*(66.307)*(30.291)*(27.876));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (21.026/95.456);
