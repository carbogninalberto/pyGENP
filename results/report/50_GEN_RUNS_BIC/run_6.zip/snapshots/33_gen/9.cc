float UCcXhyuAOfkRyQLT = (float) ((-39.226-(27.592))/-4.946);
float yqjabtKWdhrvqPIa = (float) (-43.477+(-13.452)+(-61.844)+(-14.1)+(-36.663));
tcb->m_segmentSize = (int) (54.465-(68.894)-(-25.684)-(17.002)-(-80.863)-(14.019)-(58.778)-(-64.094));
tcb->m_segmentSize = (int) (-49.371+(86.91)+(-12.61)+(-41.541)+(42.721)+(-1.987)+(-36.004));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-69.541-(67.23)-(-81.762)-(31.751)-(-96.371)-(-18.556)-(26.09)-(57.588));
tcb->m_cWnd = (int) (62.062*(94.601)*(-21.018)*(47.618)*(37.462)*(29.139)*(-5.109)*(71.356)*(98.357));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (44.71*(-16.524)*(77.127)*(29.785)*(83.968)*(-16.447)*(-75.004)*(-88.267)*(95.663));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
