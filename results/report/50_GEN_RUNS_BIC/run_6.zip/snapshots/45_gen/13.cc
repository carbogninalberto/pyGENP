if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (20.462-(60.465)-(tcb->m_segmentSize)-(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (96.382*(45.936)*(tcb->m_cWnd)*(82.756)*(39.863));
	tcb->m_cWnd = (int) ((59.788-(38.752)-(28.4)-(tcb->m_segmentSize))/73.991);

}
float paUDtZDfipjwDwRw = (float) (47.279/8.905);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	cnt = (int) (50.363/33.858);
	paUDtZDfipjwDwRw = (float) (23.878*(tcb->m_ssThresh)*(77.005)*(6.13)*(10.065)*(93.353)*(45.464));
	tcb->m_ssThresh = (int) (88.863*(54.055)*(80.22)*(31.346)*(78.714)*(29.446));

} else {
	cnt = (int) (((14.546)+(0.1)+(0.1)+(17.904)+(49.688))/((51.26)));
	tcb->m_segmentSize = (int) (83.307-(67.511));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
