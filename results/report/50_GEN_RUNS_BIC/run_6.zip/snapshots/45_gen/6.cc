ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (8.474-(12.724)-(61.632)-(tcb->m_segmentSize));
tcb->m_cWnd = (int) ((22.138*(88.534)*(27.591))/0.1);
ReduceCwnd (tcb);
if (cnt == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_cWnd = (int) ((57.281*(54.615))/60.491);

} else {
	tcb->m_segmentSize = (int) (87.077-(64.107));
	cnt = (int) (51.253*(46.964)*(6.7)*(64.058)*(96.54)*(96.0)*(23.052)*(63.319));

}
if (segmentsAcked != cnt) {
	cnt = (int) (69.219-(95.431)-(82.062)-(tcb->m_cWnd)-(62.639)-(cnt)-(76.256)-(37.841));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	cnt = (int) (89.193*(cnt)*(62.432)*(tcb->m_segmentSize)*(37.723)*(tcb->m_cWnd));
	tcb->m_cWnd = (int) (segmentsAcked+(tcb->m_ssThresh)+(tcb->m_cWnd)+(26.865)+(59.822)+(10.335)+(16.664));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (tcb->m_cWnd+(16.546)+(segmentsAcked)+(97.515));
tcb->m_cWnd = (int) (53.939-(92.861)-(51.656)-(97.138)-(93.41));
