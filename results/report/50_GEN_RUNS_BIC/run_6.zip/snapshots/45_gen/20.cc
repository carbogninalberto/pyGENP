if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int ceSYnxZqLzwosveO = (int) (70.899+(tcb->m_segmentSize)+(2.487)+(93.11)+(41.954)+(92.443));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (85.837+(segmentsAcked)+(95.081)+(54.294)+(97.438)+(87.999)+(15.957));
int rvmLFnaONXcOHwxF = (int) (62.417*(70.938)*(10.634)*(93.031)*(13.193)*(4.453));
if (ceSYnxZqLzwosveO == tcb->m_segmentSize) {
	segmentsAcked = (int) (ceSYnxZqLzwosveO*(rvmLFnaONXcOHwxF)*(58.587)*(29.608)*(58.645)*(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (segmentsAcked*(95.357)*(97.397)*(tcb->m_cWnd)*(29.52)*(59.999)*(11.023)*(rvmLFnaONXcOHwxF));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize-(12.36));

}
segmentsAcked = (int) (tcb->m_ssThresh*(87.409));
tcb->m_ssThresh = (int) (8.795-(78.018)-(22.112)-(12.5)-(65.432)-(91.681)-(0.839)-(88.099)-(76.533));
