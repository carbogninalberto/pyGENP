if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (32.653*(83.752)*(24.015)*(tcb->m_segmentSize)*(78.989));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked*(45.052)*(27.122));

}
if (tcb->m_cWnd != tcb->m_cWnd) {
	cnt = (int) (12.959+(65.163)+(52.202)+(cnt)+(15.393));
	tcb->m_segmentSize = (int) (43.32*(39.597)*(36.843)*(29.664));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (63.874*(54.22)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(18.959));
	cnt = (int) (97.937+(60.909)+(39.085));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((1.578)+(0.1)+((85.472-(19.083)-(88.277)-(51.853)-(tcb->m_cWnd)))+(0.1))/((30.349)+(0.1)+(49.937)+(81.825)));
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(79.834)*(46.303)*(46.227)*(71.856)*(62.672));

} else {
	tcb->m_ssThresh = (int) (45.752*(54.068));

}
tcb->m_ssThresh = (int) (3.164+(45.943)+(2.663)+(61.749)+(tcb->m_ssThresh)+(79.705));
