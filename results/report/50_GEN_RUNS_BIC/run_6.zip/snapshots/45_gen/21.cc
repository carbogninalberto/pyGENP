if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (6.154*(8.706)*(92.411)*(15.494)*(0.824)*(12.311)*(cnt)*(61.034)*(69.956));
if (tcb->m_ssThresh <= cnt) {
	cnt = (int) (95.876-(64.266)-(28.365)-(17.286));

} else {
	cnt = (int) (48.17+(50.863)+(81.879)+(36.216));
	tcb->m_segmentSize = (int) (53.693-(87.228)-(25.349)-(66.893)-(73.821));
	tcb->m_ssThresh = (int) (93.71-(25.729)-(88.717)-(58.374)-(49.323)-(43.92)-(47.931));

}
float uFuuiPxBjBRepcJM = (float) (tcb->m_segmentSize-(63.379)-(32.8)-(11.26)-(93.969));
if (segmentsAcked == tcb->m_ssThresh) {
	uFuuiPxBjBRepcJM = (float) (86.109+(tcb->m_segmentSize)+(55.973)+(28.921)+(57.667)+(71.948)+(42.79)+(8.337));

} else {
	uFuuiPxBjBRepcJM = (float) (87.713/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (15.252*(tcb->m_segmentSize)*(tcb->m_cWnd)*(tcb->m_cWnd)*(46.899)*(99.631)*(85.812)*(39.92)*(segmentsAcked));
