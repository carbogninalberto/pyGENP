if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (98.83-(83.577));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (85.797+(56.163));

}
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (32.208-(87.047)-(93.132));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (9.397-(33.896)-(35.429)-(1.53)-(tcb->m_cWnd)-(67.67)-(22.771)-(tcb->m_segmentSize)-(54.215));

} else {
	segmentsAcked = (int) ((90.53*(67.135)*(38.099)*(49.081)*(20.711))/10.084);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
