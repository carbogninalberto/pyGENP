tcb->m_segmentSize = (int) (80.652+(73.405)+(40.061)+(21.2)+(55.138)+(69.005)+(29.305));
tcb->m_cWnd = (int) (tcb->m_segmentSize+(32.818));
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (66.628-(tcb->m_segmentSize)-(48.44)-(tcb->m_segmentSize)-(82.853)-(cnt)-(85.731));
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(66.608)+(0.1))/((72.196)+(0.1)));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(43.821)+(8.847)+(28.224)+(98.423)+(tcb->m_cWnd)+(31.335));

}
tcb->m_cWnd = (int) (29.103*(71.933)*(7.345)*(tcb->m_segmentSize));
if (tcb->m_segmentSize < cnt) {
	tcb->m_ssThresh = (int) (7.493+(43.048)+(38.359)+(89.821)+(82.427)+(2.804)+(tcb->m_cWnd)+(38.042)+(28.333));
	segmentsAcked = (int) (((0.1)+((76.809*(39.917)*(55.609)*(68.598)*(89.607)*(43.654)*(96.743)*(94.241)*(25.09)))+((68.714-(70.503)))+(3.985)+(0.1))/((0.1)+(41.602)+(70.317)));
	tcb->m_segmentSize = (int) (33.093/0.1);

} else {
	tcb->m_ssThresh = (int) (70.56+(86.128)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (cnt-(67.991)-(69.506));
	tcb->m_ssThresh = (int) (45.549*(3.773)*(10.595));

}
float ExglZUatRUyJuhAs = (float) ((60.13+(3.745)+(34.82))/0.1);
ReduceCwnd (tcb);
