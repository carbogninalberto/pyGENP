float VmkxYOCvnBDSTgVh = (float) (72.461+(39.751));
int tPBVEaALpuVwAgsw = (int) (3.648-(1.226)-(segmentsAcked)-(47.45)-(VmkxYOCvnBDSTgVh)-(80.296));
if (tcb->m_cWnd != VmkxYOCvnBDSTgVh) {
	segmentsAcked = (int) (58.403+(58.156)+(19.529)+(61.133)+(64.038));

} else {
	segmentsAcked = (int) (((0.1)+(25.934)+(0.1)+(0.1)+(0.1))/((18.922)));
	cnt = (int) (53.444*(31.828)*(56.957)*(0.356)*(84.063)*(20.026)*(75.331)*(68.352));

}
int yfzZRozZqlaygHDl = (int) (54.518*(38.244)*(58.584)*(2.558)*(tPBVEaALpuVwAgsw)*(23.981)*(24.013));
if (segmentsAcked != yfzZRozZqlaygHDl) {
	tcb->m_cWnd = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (21.077*(51.95)*(70.05)*(6.634)*(69.172));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (yfzZRozZqlaygHDl < tcb->m_cWnd) {
	yfzZRozZqlaygHDl = (int) (((0.1)+(40.163)+(0.1)+(0.1))/((0.1)+(0.1)+(36.402)));
	segmentsAcked = (int) (44.162/70.348);

} else {
	yfzZRozZqlaygHDl = (int) (44.125-(52.137)-(96.431));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
