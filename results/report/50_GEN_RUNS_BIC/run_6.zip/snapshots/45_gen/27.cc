tcb->m_ssThresh = (int) (23.831*(36.152)*(17.969)*(99.227)*(52.646)*(91.975)*(99.501)*(68.987)*(34.76));
int jzoHLxgYOJiMXRss = (int) (38.598-(59.268)-(38.49)-(83.72)-(41.675)-(82.671)-(39.647)-(66.235)-(51.264));
if (cnt < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (81.808*(85.589)*(92.325));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(73.393)+(34.61)+(56.6)+(tcb->m_cWnd)+(37.623)+(segmentsAcked)+(5.417)+(68.223));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
jzoHLxgYOJiMXRss = (int) (47.646*(segmentsAcked)*(32.36)*(81.422)*(17.11)*(96.251)*(77.604));
if (cnt < jzoHLxgYOJiMXRss) {
	tcb->m_ssThresh = (int) (15.955+(16.536)+(24.508));

} else {
	tcb->m_ssThresh = (int) (43.481-(80.285)-(58.279)-(26.514)-(cnt)-(3.686)-(88.034)-(91.186)-(tcb->m_cWnd));
	jzoHLxgYOJiMXRss = (int) (34.289+(96.484)+(0.408)+(73.832)+(tcb->m_cWnd)+(15.795)+(segmentsAcked));

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	cnt = (int) (cnt+(67.831)+(jzoHLxgYOJiMXRss)+(tcb->m_segmentSize));

} else {
	cnt = (int) (35.799*(20.617)*(59.795)*(0.778)*(54.208)*(48.245)*(64.113));
	tcb->m_cWnd = (int) (37.815*(11.162)*(1.199)*(57.086)*(3.347)*(5.081)*(tcb->m_ssThresh)*(cnt)*(87.198));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
int SpldKlWWLMjIcTXQ = (int) (74.693*(69.427)*(26.553));
