ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((0.1)+((74.697+(50.984)+(tcb->m_segmentSize)+(tcb->m_ssThresh)))+(0.1)+(88.659))/((0.1)+(36.375)+(0.1)+(0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (79.358-(65.024));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
if (segmentsAcked >= tcb->m_cWnd) {
	cnt = (int) (96.703+(42.302)+(43.18)+(20.395)+(24.899)+(25.234)+(11.361));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (cnt*(21.536)*(tcb->m_segmentSize));

}
if (tcb->m_ssThresh < cnt) {
	cnt = (int) (21.186*(13.902));
	tcb->m_segmentSize = (int) (23.925-(26.222)-(85.642)-(30.741)-(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (4.533+(47.946)+(tcb->m_ssThresh)+(50.395)+(23.799));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
