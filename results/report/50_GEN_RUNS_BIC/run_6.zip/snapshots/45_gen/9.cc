cnt = (int) (27.619/0.1);
int TAnCheWKhJyzKeMt = (int) (64.405+(46.009)+(37.477)+(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh > TAnCheWKhJyzKeMt) {
	cnt = (int) (tcb->m_ssThresh-(5.413)-(23.713)-(9.375)-(70.815));

} else {
	cnt = (int) ((90.491+(tcb->m_ssThresh))/0.1);

}
segmentsAcked = (int) (43.969*(15.357)*(46.442));
if (cnt != tcb->m_segmentSize) {
	segmentsAcked = (int) (25.784+(79.671));

} else {
	segmentsAcked = (int) (18.311+(tcb->m_cWnd)+(3.048)+(68.658)+(11.534));
	tcb->m_ssThresh = (int) (37.143*(87.002)*(10.951)*(67.585)*(0.001)*(58.391)*(95.136));

}
