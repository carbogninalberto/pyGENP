ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (80.13-(50.196)-(20.444)-(85.73)-(28.248)-(88.358)-(95.523)-(29.942)-(27.191));
tcb->m_cWnd = (int) (2.924-(tcb->m_cWnd)-(83.93)-(12.457)-(81.531)-(7.607)-(4.866)-(74.644)-(95.841));
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) ((((25.036*(3.662)*(55.608)*(segmentsAcked)*(0.611)*(78.878)*(28.029)))+(59.724)+(0.1)+(1.036))/((0.1)+(0.1)+(0.1)+(83.836)));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (7.729/62.127);

} else {
	tcb->m_ssThresh = (int) (5.294-(37.041)-(24.415)-(tcb->m_segmentSize)-(99.426)-(51.846)-(69.629)-(72.032)-(46.884));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
