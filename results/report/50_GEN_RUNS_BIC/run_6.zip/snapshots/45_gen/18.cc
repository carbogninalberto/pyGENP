ReduceCwnd (tcb);
cnt = (int) (10.017*(tcb->m_ssThresh)*(53.302));
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (86.904+(93.121)+(47.39)+(76.52));

} else {
	tcb->m_cWnd = (int) (0.259*(39.256)*(58.614)*(56.804)*(48.658));
	tcb->m_segmentSize = (int) (0.1/0.1);

}
int tIejvMGPpxSOLsmi = (int) (40.296*(10.383)*(tcb->m_ssThresh)*(67.776)*(20.858));
cnt = (int) (((15.584)+(0.1)+(98.533)+(0.1)+(0.1)+(43.492)+(0.1))/((0.1)+(0.1)));
tcb->m_segmentSize = (int) (tcb->m_ssThresh+(79.922)+(7.784)+(50.465)+(31.688)+(tIejvMGPpxSOLsmi)+(62.022));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tIejvMGPpxSOLsmi = (int) (0.1/0.1);
tcb->m_cWnd = (int) (66.58*(tIejvMGPpxSOLsmi)*(tcb->m_cWnd));
