if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (21.433-(48.311)-(segmentsAcked)-(91.946)-(28.837)-(tcb->m_ssThresh)-(7.845)-(tcb->m_cWnd));
tcb->m_cWnd = (int) (63.462+(segmentsAcked)+(21.315)+(cnt)+(30.893)+(27.73)+(53.096)+(75.468));
float atJfESzmouSZALiC = (float) (tcb->m_segmentSize-(1.742)-(52.447)-(8.741)-(45.181)-(68.644));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
