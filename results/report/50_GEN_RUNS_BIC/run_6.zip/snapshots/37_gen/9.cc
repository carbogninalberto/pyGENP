int zPyutVwdAuldLNlh = (int) (0.1/0.1);
int KnjKhIAiKqwqadVq = (int) (97.066+(9.485)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(37.829)+(39.512)+(tcb->m_cWnd)+(segmentsAcked)+(67.833));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
