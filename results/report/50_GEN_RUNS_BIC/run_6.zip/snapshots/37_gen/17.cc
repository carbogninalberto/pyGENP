segmentsAcked = (int) (tcb->m_segmentSize+(82.085)+(14.1)+(tcb->m_cWnd)+(57.461)+(66.44)+(65.855)+(tcb->m_ssThresh)+(cnt));
ReduceCwnd (tcb);
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	cnt = (int) (((46.278)+((76.501-(55.799)-(20.442)-(19.759)-(23.782)-(24.219)))+((68.413*(25.913)))+(95.308))/((89.438)+(24.869)+(0.1)+(0.1)));
	tcb->m_ssThresh = (int) (58.138-(81.444)-(tcb->m_ssThresh));

} else {
	cnt = (int) (16.258*(87.343)*(78.314)*(93.581)*(64.954)*(89.358)*(34.095)*(57.111));
	tcb->m_segmentSize = (int) (64.755-(tcb->m_ssThresh));
	ReduceCwnd (tcb);

}
if (segmentsAcked <= cnt) {
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (69.829/0.1);
	cnt = (int) (68.645*(94.944));

} else {
	tcb->m_cWnd = (int) (80.734-(84.108)-(58.1)-(9.097)-(49.243)-(15.611)-(55.331));

}
cnt = (int) (tcb->m_cWnd+(cnt)+(11.821)+(tcb->m_segmentSize)+(10.249)+(61.074)+(79.864)+(66.568)+(41.958));
tcb->m_ssThresh = (int) (((45.784)+(71.934)+(71.665)+(83.215))/((7.858)+(0.1)));
cnt = (int) (92.292-(36.969)-(tcb->m_ssThresh));
