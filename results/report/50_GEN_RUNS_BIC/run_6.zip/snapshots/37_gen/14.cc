if (tcb->m_ssThresh == tcb->m_segmentSize) {
	cnt = (int) (segmentsAcked*(0.348)*(67.183)*(87.383)*(46.071)*(28.183)*(77.443)*(82.031));

} else {
	cnt = (int) (37.84+(61.993)+(tcb->m_ssThresh)+(88.173)+(tcb->m_ssThresh)+(22.977)+(20.814)+(63.903)+(97.533));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (29.935*(42.94)*(27.896));
	segmentsAcked = (int) (cnt-(85.008)-(tcb->m_segmentSize)-(99.756)-(tcb->m_ssThresh)-(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (95.983-(85.696)-(78.509)-(30.222));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (87.63-(91.527)-(tcb->m_ssThresh)-(72.809));

}
segmentsAcked = (int) (58.422+(35.886)+(80.399)+(95.628)+(51.277)+(27.028)+(60.93)+(0.959));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
