if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_cWnd = (int) (55.735+(0.458)+(31.275)+(17.517)+(72.848)+(98.277)+(95.3)+(63.106)+(73.359));

} else {
	tcb->m_cWnd = (int) (66.335+(96.74)+(cnt)+(46.87)+(4.198)+(tcb->m_ssThresh)+(18.84)+(48.671));
	tcb->m_ssThresh = (int) (54.39*(tcb->m_ssThresh)*(30.299)*(95.818)*(70.871)*(87.348));

}
float BEQQEEpRjFZdfDoY = (float) (11.417-(81.749)-(7.503)-(21.929)-(1.413)-(37.266)-(31.58)-(29.169)-(70.059));
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (73.382+(71.066)+(tcb->m_segmentSize)+(77.28)+(42.792)+(60.45)+(56.787)+(cnt));

} else {
	tcb->m_segmentSize = (int) (70.259-(89.1)-(tcb->m_segmentSize)-(7.629));

}
segmentsAcked = (int) (segmentsAcked*(71.962)*(70.249)*(69.615));
if (BEQQEEpRjFZdfDoY > cnt) {
	cnt = (int) (segmentsAcked+(61.736)+(tcb->m_cWnd)+(BEQQEEpRjFZdfDoY));
	cnt = (int) (62.986-(26.016)-(89.841)-(92.227)-(31.961)-(80.658));

} else {
	cnt = (int) (tcb->m_segmentSize*(segmentsAcked)*(85.994)*(20.244)*(71.606)*(BEQQEEpRjFZdfDoY)*(15.533)*(53.882)*(97.668));

}
cnt = (int) (48.407/0.1);
