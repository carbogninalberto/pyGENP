int kzBXlVVzjohFnRCc = (int) (27.769-(85.618)-(21.256)-(36.712)-(97.986)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(20.879));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(5.63)-(71.757)-(tcb->m_segmentSize)-(8.782));

} else {
	tcb->m_cWnd = (int) (49.249+(91.527)+(86.146)+(12.621)+(segmentsAcked));
	tcb->m_segmentSize = (int) (87.117*(76.774)*(2.687)*(segmentsAcked)*(60.904)*(81.77)*(38.104));
	segmentsAcked = (int) (((30.556)+(38.193)+((55.682-(88.154)))+(0.1)+(57.637)+((39.65*(44.026)*(cnt)*(7.196)*(29.042)*(70.193)*(81.369)*(39.806)))+(0.1))/((0.1)));

}
kzBXlVVzjohFnRCc = (int) (36.519*(77.598));
if (tcb->m_ssThresh > cnt) {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(65.871))/((0.1)+(84.407)+(10.525)));
	tcb->m_cWnd = (int) (51.223+(79.39)+(45.808)+(97.133)+(66.647));
	segmentsAcked = (int) (segmentsAcked-(64.06)-(23.883)-(tcb->m_cWnd)-(36.221)-(72.108));

} else {
	segmentsAcked = (int) ((tcb->m_segmentSize-(84.868)-(21.651)-(26.883)-(41.422)-(74.452))/85.888);

}
ReduceCwnd (tcb);
int scIoIUcLubbNNTIV = (int) (61.122+(59.771)+(26.819)+(61.652)+(19.584));
