float QIGiuNIBkiuUhikT = (float) (0.1/0.1);
QIGiuNIBkiuUhikT = (float) (tcb->m_ssThresh-(93.461)-(11.296)-(tcb->m_cWnd)-(26.206)-(35.246)-(75.986)-(12.078)-(36.202));
float tTSsMtrUAcYJWDAt = (float) (((69.241)+(35.202)+(74.772)+((79.972*(69.527)*(50.556)*(64.874)))+(0.1))/((22.668)+(86.424)));
tcb->m_segmentSize = (int) (9.614+(52.005)+(QIGiuNIBkiuUhikT)+(72.104)+(tcb->m_ssThresh));
float rTglnyxZMeJDroej = (float) (55.708*(61.713)*(55.445)*(7.237)*(74.678)*(2.557)*(30.351)*(6.209));
