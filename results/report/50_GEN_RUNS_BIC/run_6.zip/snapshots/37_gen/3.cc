ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (54.258-(36.942)-(59.057)-(64.724));
	tcb->m_cWnd = (int) ((74.727*(84.911)*(cnt)*(35.2))/92.498);
	cnt = (int) (70.952*(91.252)*(segmentsAcked)*(tcb->m_segmentSize)*(77.751)*(62.996)*(58.594));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(44.068));

}
ReduceCwnd (tcb);
cnt = (int) (0.1/0.1);
tcb->m_segmentSize = (int) (4.784+(67.293)+(26.762)+(72.951)+(cnt)+(82.891)+(tcb->m_ssThresh)+(segmentsAcked));
ReduceCwnd (tcb);
