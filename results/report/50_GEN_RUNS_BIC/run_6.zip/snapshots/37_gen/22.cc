cnt = (int) (((0.1)+((23.551*(57.685)*(39.807)*(32.135)*(50.144)*(cnt)*(cnt)*(79.654)*(43.078)))+(81.273)+((10.159+(66.098)+(2.491)+(41.645)+(36.992)))+(0.1))/((0.1)));
ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (13.852-(cnt)-(28.939)-(29.35)-(70.677));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (((0.1)+(98.163)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (11.169-(cnt)-(82.994)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(34.823));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (87.642+(54.171)+(73.244)+(88.445)+(56.205)+(75.243)+(52.404));
	segmentsAcked = (int) (29.865*(99.338));

} else {
	tcb->m_ssThresh = (int) (72.051+(97.657)+(17.642)+(11.766));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (70.283-(33.326)-(39.437)-(56.849)-(tcb->m_cWnd));
