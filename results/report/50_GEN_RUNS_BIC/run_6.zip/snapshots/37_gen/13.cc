ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	cnt = (int) ((89.004-(57.381)-(26.864)-(tcb->m_ssThresh)-(11.039)-(tcb->m_cWnd)-(89.905)-(53.353)-(49.209))/(tcb->m_ssThresh*(81.904)*(segmentsAcked)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(86.511)*(28.825)*(13.006)));
	tcb->m_cWnd = (int) (36.351-(47.167)-(cnt));
	tcb->m_segmentSize = (int) (54.728*(42.294)*(cnt)*(25.421)*(67.297)*(segmentsAcked)*(33.835)*(cnt)*(38.68));

} else {
	cnt = (int) (66.664+(86.472));

}
tcb->m_ssThresh = (int) (0.1/0.1);
if (segmentsAcked >= segmentsAcked) {
	cnt = (int) (99.802*(0.565)*(72.958)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(96.657)*(segmentsAcked)*(62.387));
	cnt = (int) ((((82.134-(cnt)-(48.626)-(71.301)-(81.737)))+((86.735-(84.261)-(77.365)-(45.856)-(30.227)-(33.728)-(31.318)))+(76.432)+((67.553*(82.874)*(22.479)*(49.527)*(21.434)*(70.438)*(92.372)*(63.615)*(tcb->m_segmentSize)))+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	cnt = (int) (79.068+(3.689)+(68.624)+(segmentsAcked)+(34.26)+(45.924)+(45.253)+(98.344));

}
if (segmentsAcked >= segmentsAcked) {
	cnt = (int) (29.394+(tcb->m_ssThresh)+(56.98)+(64.875)+(22.004)+(40.788));

} else {
	cnt = (int) (61.087+(tcb->m_cWnd));
	segmentsAcked = (int) (0.1/8.39);
	tcb->m_segmentSize = (int) (81.39-(62.079)-(25.667));

}
if (segmentsAcked == segmentsAcked) {
	tcb->m_cWnd = (int) (23.213-(cnt)-(tcb->m_segmentSize)-(67.948)-(14.79)-(tcb->m_segmentSize)-(cnt));
	tcb->m_ssThresh = (int) (74.323-(45.856)-(96.317)-(97.873)-(94.813)-(48.913));

} else {
	tcb->m_cWnd = (int) (69.904*(6.941)*(71.77)*(tcb->m_cWnd)*(cnt));

}
