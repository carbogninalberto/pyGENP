if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (17.408*(95.633)*(97.976)*(66.288)*(54.712));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (tcb->m_ssThresh+(46.843)+(44.239)+(tcb->m_ssThresh)+(88.455)+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (61.369*(tcb->m_ssThresh)*(21.626)*(83.815)*(7.546)*(60.415)*(8.287)*(57.3)*(66.323));
	cnt = (int) (((0.1)+((58.781-(cnt)-(41.365)))+((66.054*(46.417)*(75.178)*(91.578)*(67.879)*(97.125)*(83.698)*(32.12)))+(0.1)+(0.1))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
float lHcobOaHdTRBCftG = (float) (59.73+(tcb->m_segmentSize)+(31.756));
if (lHcobOaHdTRBCftG < segmentsAcked) {
	tcb->m_ssThresh = (int) ((39.429-(83.719)-(57.226)-(50.371))/62.309);

} else {
	tcb->m_ssThresh = (int) (59.737+(lHcobOaHdTRBCftG)+(77.457)+(86.55)+(47.752)+(44.276)+(43.167)+(88.699)+(tcb->m_segmentSize));

}
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(55.716)+(0.1)+(0.1))/((83.865)+(86.342)+(21.27)));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(54.132));
	tcb->m_segmentSize = (int) (lHcobOaHdTRBCftG*(2.573)*(44.986));

}
cnt = (int) (18.65*(69.705)*(segmentsAcked)*(89.872)*(tcb->m_segmentSize)*(92.327)*(58.912)*(23.551)*(59.359));
float ckRobKPCMCMMjCbC = (float) (segmentsAcked*(63.623)*(50.257));
if (ckRobKPCMCMMjCbC >= ckRobKPCMCMMjCbC) {
	segmentsAcked = (int) ((((54.603-(1.265)-(75.5)-(79.938)-(tcb->m_cWnd)))+((77.537+(37.409)+(86.175)+(70.594)))+(0.1)+((53.674+(40.339)+(24.439)+(51.949)+(13.821)))+(12.347)+(0.1))/((22.585)+(0.1)+(10.973)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (35.876-(22.829)-(ckRobKPCMCMMjCbC)-(80.07)-(93.967)-(28.224)-(65.651));

}
