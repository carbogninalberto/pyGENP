if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (23.033/11.118);
	segmentsAcked = (int) (tcb->m_segmentSize+(tcb->m_segmentSize)+(segmentsAcked)+(65.404)+(cnt)+(46.06)+(68.044));

} else {
	tcb->m_ssThresh = (int) (cnt-(61.427));
	tcb->m_cWnd = (int) (((0.1)+(98.228)+(0.1)+(12.96)+(38.794))/((96.808)+(0.1)+(0.1)+(49.132)));

}
tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(42.827)+(69.231)+(26.927)+(0.1))/((28.806)+(0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	segmentsAcked = (int) (56.857-(34.844)-(92.603)-(cnt)-(tcb->m_segmentSize)-(92.203)-(cnt)-(53.394)-(31.6));
	segmentsAcked = (int) (27.261-(93.726)-(36.301)-(23.782));

} else {
	segmentsAcked = (int) (34.322+(7.957)+(tcb->m_segmentSize)+(39.756)+(30.134));
	ReduceCwnd (tcb);

}
