if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
cnt = (int) (segmentsAcked-(47.479)-(35.53)-(segmentsAcked)-(15.236));
if (cnt > tcb->m_segmentSize) {
	cnt = (int) (34.288*(24.055)*(45.063)*(51.658)*(73.217)*(94.809)*(8.064));

} else {
	cnt = (int) (segmentsAcked-(91.105)-(68.207));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (23.195+(34.692)+(tcb->m_cWnd));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_segmentSize) {
	cnt = (int) (77.653/96.525);
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (((57.336)+(66.402)+(35.231)+(93.461)+(97.788))/((0.1)+(0.1)));
	segmentsAcked = (int) (segmentsAcked-(81.541)-(92.018)-(24.908)-(68.516)-(segmentsAcked));

}
