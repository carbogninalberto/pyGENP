tcb->m_cWnd = (int) (24.284-(54.019)-(70.088)-(40.596)-(92.505)-(31.416)-(56.269));
int YhZrjYwgmscAynpX = (int) (73.352+(68.83)+(56.959)+(46.447));
if (cnt == cnt) {
	tcb->m_cWnd = (int) (((0.1)+(62.104)+(85.803)+((tcb->m_ssThresh*(tcb->m_cWnd)))+((63.47*(38.895)*(tcb->m_ssThresh)*(25.649)*(68.619)*(40.65)*(60.206)))+(0.1)+(73.776))/((0.1)));
	tcb->m_cWnd = (int) (80.994*(94.142)*(1.841));
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(55.043)*(15.535)*(cnt)*(74.883)*(12.939)*(tcb->m_ssThresh)*(cnt));

} else {
	tcb->m_cWnd = (int) (90.281*(16.315)*(28.412)*(53.85)*(62.664)*(81.208)*(45.1));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(83.878)+(tcb->m_ssThresh)+(12.673)+(tcb->m_segmentSize)+(70.846)+(30.188));
