int udVxUtRqvcrJtHbu = (int) (98.246-(-56.077)-(17.559));
float IuolVitiOzoYFUVO = (float) 12.065;
