tcb->m_ssThresh = (int) (47.391*(41.394)*(46.761)*(41.738)*(9.371)*(13.363)*(21.857)*(13.991)*(59.665));
if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/12.94);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (19.008-(96.11)-(70.867)-(69.231)-(51.798)-(99.256)-(13.901)-(segmentsAcked)-(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (13.903-(57.187)-(tcb->m_ssThresh)-(80.605)-(cnt)-(62.292)-(cnt)-(67.235)-(cnt));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (49.705*(64.679)*(45.365)*(96.817)*(17.751)*(21.383)*(46.549)*(tcb->m_cWnd));
ReduceCwnd (tcb);
float DwRScAtHkfRrDrYo = (float) (0.1/0.1);
