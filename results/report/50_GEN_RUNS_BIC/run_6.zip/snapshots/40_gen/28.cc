if (tcb->m_segmentSize == cnt) {
	cnt = (int) (87.375*(tcb->m_cWnd)*(10.138)*(47.978));

} else {
	cnt = (int) (tcb->m_segmentSize-(99.928)-(tcb->m_segmentSize)-(29.971));
	tcb->m_ssThresh = (int) (7.003-(15.4)-(44.018)-(27.264));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd == cnt) {
	tcb->m_cWnd = (int) (96.203*(41.233)*(cnt)*(86.621)*(55.807)*(86.669)*(41.664));

} else {
	tcb->m_cWnd = (int) (62.276+(tcb->m_segmentSize)+(8.431)+(58.844)+(77.56));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
cnt = (int) (45.622+(45.217)+(97.149)+(61.417)+(cnt)+(33.212)+(89.742)+(66.038));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (cnt > segmentsAcked) {
	tcb->m_ssThresh = (int) (((34.973)+((segmentsAcked*(93.838)*(12.735)*(tcb->m_segmentSize)*(49.396)*(segmentsAcked)*(62.391)*(20.145)*(44.297)))+(0.1)+(54.079))/((74.886)));
	tcb->m_cWnd = (int) (7.226*(segmentsAcked)*(54.087)*(10.239)*(3.127)*(42.331)*(43.978)*(30.762)*(94.826));
	tcb->m_segmentSize = (int) (93.941*(15.283)*(69.357)*(85.077)*(88.121)*(97.754));

} else {
	tcb->m_ssThresh = (int) (74.278+(4.863)+(29.231)+(9.943)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(31.907)+(49.927));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (0.1/99.377);

}
if (cnt >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (40.967*(tcb->m_segmentSize)*(4.513)*(87.605)*(89.698)*(44.144)*(53.421)*(25.372)*(88.874));
	cnt = (int) (50.489+(segmentsAcked));
	cnt = (int) (tcb->m_segmentSize*(96.051)*(4.12)*(87.602)*(29.905)*(32.379)*(tcb->m_ssThresh)*(25.257));

} else {
	tcb->m_segmentSize = (int) (16.295*(33.85));
	cnt = (int) (33.134+(85.039)+(76.313)+(82.278)+(cnt));

}
