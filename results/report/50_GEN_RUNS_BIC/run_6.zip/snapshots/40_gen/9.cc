if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (0.1/52.046);
float RskYJVDHtBCCYlXq = (float) (tcb->m_segmentSize*(65.582)*(6.12)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(11.363)*(cnt)*(8.645)*(segmentsAcked));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
