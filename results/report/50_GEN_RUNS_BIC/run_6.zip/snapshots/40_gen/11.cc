if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (30.533+(cnt)+(86.506)+(37.966)+(75.844)+(97.442)+(26.425)+(tcb->m_ssThresh)+(76.834));
	tcb->m_segmentSize = (int) (57.728-(39.134)-(9.073)-(26.618)-(98.872)-(96.473)-(tcb->m_ssThresh)-(91.383));

} else {
	tcb->m_cWnd = (int) (89.567-(66.667)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (83.11-(5.624)-(77.997)-(73.867));
	cnt = (int) (segmentsAcked+(87.243));

}
tcb->m_segmentSize = (int) (tcb->m_cWnd+(tcb->m_cWnd)+(4.46));
tcb->m_ssThresh = (int) (((58.453)+(0.1)+(0.1)+(0.1)+(0.1))/((1.265)+(0.1)+(0.1)));
