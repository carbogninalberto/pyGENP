ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (tcb->m_ssThresh*(77.525)*(84.636)*(0.433));
cnt = (int) ((((8.503+(40.96)+(20.729)+(tcb->m_segmentSize)+(13.666)))+(0.1)+(0.1)+(0.1))/((0.1)+(89.798)));
tcb->m_cWnd = (int) (78.177+(tcb->m_segmentSize));
ReduceCwnd (tcb);
if (cnt <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (26.377-(29.554)-(24.487)-(38.773)-(33.618)-(tcb->m_ssThresh)-(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (89.652*(1.855)*(tcb->m_ssThresh)*(segmentsAcked));
	cnt = (int) (tcb->m_ssThresh-(44.273)-(21.566)-(58.809));

} else {
	tcb->m_segmentSize = (int) (97.694-(36.96)-(segmentsAcked)-(78.793)-(tcb->m_ssThresh)-(5.212)-(19.635));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
