if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (segmentsAcked+(segmentsAcked)+(78.366)+(30.324));

} else {
	tcb->m_cWnd = (int) (((0.1)+(34.625)+(0.1)+(87.874))/((97.124)+(56.435)));
	segmentsAcked = (int) (98.337+(41.501)+(tcb->m_segmentSize));
	cnt = (int) (tcb->m_cWnd+(45.832)+(17.655)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(42.538)+(tcb->m_cWnd)+(4.881));

}
cnt = (int) (cnt+(tcb->m_ssThresh)+(40.922));
tcb->m_cWnd = (int) (((0.1)+(0.1)+(72.582)+(0.1))/((0.1)));
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (7.859+(8.577)+(11.906)+(3.539)+(21.743));
	tcb->m_cWnd = (int) (0.1/27.666);
	cnt = (int) (48.561/56.075);

} else {
	tcb->m_segmentSize = (int) (90.171*(segmentsAcked)*(55.745)*(7.652)*(76.72)*(79.79));

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (76.077/70.808);

} else {
	tcb->m_cWnd = (int) (92.949-(10.41)-(11.203)-(85.014));

}
cnt = (int) (tcb->m_segmentSize-(24.454)-(98.728)-(56.355));
ReduceCwnd (tcb);
