segmentsAcked = (int) (47.255*(75.616)*(tcb->m_ssThresh)*(66.719)*(86.28)*(22.207)*(92.81));
if (segmentsAcked >= cnt) {
	cnt = (int) (7.3-(2.449)-(segmentsAcked)-(12.064)-(87.757));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (13.708+(37.596)+(31.385)+(tcb->m_cWnd));

}
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (8.722-(36.193)-(69.878));

} else {
	tcb->m_cWnd = (int) (50.475*(48.815)*(88.467)*(42.849)*(71.829)*(0.141));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (62.379-(39.776));
	tcb->m_ssThresh = (int) (46.017+(26.18)+(33.727)+(tcb->m_ssThresh)+(74.431)+(85.176)+(32.908));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(76.316)-(54.025)-(67.552)-(tcb->m_cWnd));
	segmentsAcked = (int) (0.1/86.256);

}
if (tcb->m_ssThresh < tcb->m_cWnd) {
	segmentsAcked = (int) (23.712*(44.901)*(75.66)*(28.854)*(13.955));
	cnt = (int) (27.61*(92.232)*(cnt)*(70.704)*(cnt)*(2.759)*(89.476)*(22.092)*(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (29.274-(segmentsAcked)-(91.787)-(53.303)-(16.046)-(tcb->m_segmentSize)-(67.561)-(11.46)-(64.848));
	tcb->m_cWnd = (int) (59.023-(20.571)-(78.341)-(71.097)-(18.012));

}
