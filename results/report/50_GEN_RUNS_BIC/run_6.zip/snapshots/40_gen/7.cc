if (cnt > tcb->m_ssThresh) {
	cnt = (int) (84.097-(43.089)-(segmentsAcked)-(tcb->m_segmentSize)-(97.568)-(79.679)-(segmentsAcked)-(94.197));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (59.691/0.1);

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (10.103*(60.064)*(cnt)*(78.546)*(70.458)*(6.924)*(12.496)*(21.164));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (61.221+(3.748)+(51.04)+(37.999)+(73.99)+(tcb->m_cWnd)+(68.363)+(tcb->m_segmentSize));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (93.807+(54.191)+(48.5)+(61.593)+(4.957));

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (2.823*(tcb->m_ssThresh)*(17.131)*(95.653)*(43.125)*(94.127)*(51.283)*(48.629));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (cnt*(61.433)*(55.153)*(7.64)*(99.656)*(cnt)*(74.538));
	tcb->m_cWnd = (int) (0.1/40.466);
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(0.902)*(80.177));

}
if (segmentsAcked < tcb->m_ssThresh) {
	cnt = (int) (83.711*(8.902)*(12.062)*(91.628)*(8.837)*(88.877)*(59.69)*(29.521));

} else {
	cnt = (int) (69.563*(62.466)*(19.662)*(78.409)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(88.688)*(76.938));
	tcb->m_ssThresh = (int) (29.486-(48.53)-(30.738)-(35.715)-(30.291)-(28.076));

}
segmentsAcked = (int) (68.109/66.135);
