if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= cnt) {
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (63.436+(tcb->m_ssThresh)+(44.751));
	segmentsAcked = (int) (tcb->m_cWnd-(26.135)-(37.237)-(93.386)-(tcb->m_ssThresh)-(29.776)-(18.007));

} else {
	tcb->m_cWnd = (int) (26.582*(57.975));
	tcb->m_segmentSize = (int) (86.227*(tcb->m_segmentSize)*(68.861)*(80.458)*(46.825));
	tcb->m_segmentSize = (int) (segmentsAcked*(tcb->m_segmentSize)*(32.785)*(87.304));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	segmentsAcked = (int) (51.332/93.293);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (59.349-(66.963)-(16.264));

} else {
	segmentsAcked = (int) (((0.1)+(88.47)+(35.113)+(0.1)+(0.1)+(13.214)+(65.455))/((39.509)));
	cnt = (int) (91.199*(83.907)*(95.064)*(77.552)*(tcb->m_segmentSize)*(83.816));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
cnt = (int) (((0.1)+((tcb->m_cWnd-(15.386)-(90.739)-(15.38)-(63.043)-(tcb->m_cWnd)-(54.26)))+(70.821)+(0.1))/((43.223)+(0.1)+(0.1)+(29.673)));
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_ssThresh = (int) (43.155*(3.695)*(32.051)*(8.065)*(31.408));
	cnt = (int) (segmentsAcked*(58.068));
	tcb->m_cWnd = (int) (14.822*(14.125)*(70.144)*(14.818)*(54.442)*(69.24)*(segmentsAcked)*(tcb->m_ssThresh)*(87.985));

} else {
	tcb->m_ssThresh = (int) ((11.992+(86.284)+(94.185)+(90.938)+(8.811)+(tcb->m_segmentSize)+(49.895)+(39.627))/61.455);

}
