if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (65.17/74.802);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (56.291+(65.419));
	segmentsAcked = (int) (94.25*(cnt)*(78.345));

}
if (cnt > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((97.361)+(86.635)+(73.079)+(81.052))/((0.1)+(13.063)+(48.043)));
	tcb->m_cWnd = (int) (76.424*(30.933));

} else {
	tcb->m_ssThresh = (int) (26.54/8.801);

}
tcb->m_segmentSize = (int) (27.557-(12.906)-(6.218));
cnt = (int) (cnt+(81.101)+(63.244)+(segmentsAcked)+(cnt)+(tcb->m_cWnd)+(45.136)+(66.986));
cnt = (int) (38.74-(tcb->m_cWnd)-(25.841));
