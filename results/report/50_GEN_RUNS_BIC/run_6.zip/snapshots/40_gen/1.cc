int fWnmgDhLSYwFvwGf = (int) (55.871-(82.419)-(98.08)-(2.786)-(-7.871));
tcb->m_segmentSize = (int) (31.238-(98.369)-(-97.609)-(73.778));
tcb->m_segmentSize = (int) (-84.661/-19.636);
