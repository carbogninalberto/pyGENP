ReduceCwnd (tcb);
if (cnt < cnt) {
	tcb->m_cWnd = (int) (61.943+(31.869));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(segmentsAcked)-(0.469)-(61.391)-(cnt));
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(95.589)+(4.185))/((31.805)+(0.1)));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (27.03-(36.678)-(42.056)-(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (86.781+(50.242));
	cnt = (int) (0.1/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int cPacOsACkGCQCNZn = (int) (63.342*(29.776)*(cnt)*(segmentsAcked)*(36.195)*(37.052)*(41.996)*(29.108)*(51.168));
tcb->m_cWnd = (int) (tcb->m_segmentSize+(44.337)+(44.432)+(88.953)+(39.524));
if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (((0.1)+(49.993)+(55.979)+(0.1)+(0.1)+(24.075)+(0.1))/((40.044)));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (88.366*(cPacOsACkGCQCNZn)*(27.457)*(55.477)*(tcb->m_segmentSize)*(86.666));

}
