if (cnt == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (94.586+(tcb->m_ssThresh)+(2.139)+(segmentsAcked)+(84.596)+(8.289)+(12.186)+(58.363));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(94.554)+(0.1)+(0.1))/((23.853)+(0.1)+(0.1)+(73.259)));
	tcb->m_segmentSize = (int) (57.628+(segmentsAcked)+(47.458)+(33.842));
	cnt = (int) (52.477+(56.593));

}
segmentsAcked = (int) (3.035+(cnt)+(61.817));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (96.859+(27.58)+(3.356)+(tcb->m_cWnd));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/97.912);
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (40.418*(tcb->m_cWnd)*(73.982)*(0.417));

} else {
	tcb->m_cWnd = (int) (8.989*(30.947)*(6.803)*(23.934)*(tcb->m_segmentSize));
	cnt = (int) (44.7-(50.895)-(92.984)-(63.095)-(36.831)-(17.659)-(39.345)-(3.842)-(91.387));
	tcb->m_cWnd = (int) (49.453+(42.882)+(76.528)+(tcb->m_ssThresh)+(59.883)+(3.149));

}
