cnt = (int) (tcb->m_cWnd*(cnt)*(38.751)*(73.378)*(23.872)*(41.922)*(tcb->m_segmentSize)*(76.335)*(68.001));
tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+((70.51+(1.151)+(89.501)))+(43.787))/((0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (tcb->m_cWnd-(83.888)-(10.727)-(61.122)-(cnt)-(37.862)-(78.678)-(94.583)-(47.798));
tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(9.717))/((0.1)+(8.969)));
