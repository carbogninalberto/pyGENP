if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (93.416-(30.732)-(56.495)-(4.271)-(4.111));
ReduceCwnd (tcb);
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_ssThresh = (int) (48.661-(78.931)-(88.802)-(99.645)-(67.756)-(46.553)-(52.51));
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (99.33*(90.173)*(72.04)*(22.787)*(35.97)*(51.84));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(9.458)+(14.613)+(tcb->m_ssThresh));

}
if (cnt != tcb->m_ssThresh) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (28.406*(53.163));
	ReduceCwnd (tcb);

}
if (cnt > cnt) {
	tcb->m_ssThresh = (int) (((46.241)+(8.472)+(0.1)+(0.1)+(0.1)+(0.1)+(0.1)+(48.614))/((45.334)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (62.828-(74.134)-(27.25)-(60.804));

}
tcb->m_segmentSize = (int) (cnt-(58.018)-(33.647)-(tcb->m_cWnd)-(89.173)-(tcb->m_ssThresh)-(11.741));
int xIPMVlISdJPkdwgs = (int) (0.1/13.103);
if (segmentsAcked != segmentsAcked) {
	xIPMVlISdJPkdwgs = (int) (xIPMVlISdJPkdwgs-(57.631)-(tcb->m_ssThresh)-(29.994)-(32.119));
	tcb->m_cWnd = (int) (95.008+(67.599)+(78.236)+(53.966)+(xIPMVlISdJPkdwgs)+(14.769)+(32.575));
	tcb->m_segmentSize = (int) (76.942*(97.054)*(79.228)*(61.048)*(xIPMVlISdJPkdwgs)*(42.314));

} else {
	xIPMVlISdJPkdwgs = (int) (98.055-(45.585)-(90.312)-(70.799)-(12.683)-(30.639)-(tcb->m_cWnd)-(52.423)-(12.893));
	segmentsAcked = (int) (45.643-(94.901)-(73.618)-(7.433)-(tcb->m_segmentSize)-(52.243)-(92.241));
	ReduceCwnd (tcb);

}
