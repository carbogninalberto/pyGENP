int sKMpdAuJPlwKqmcW = (int) (42.571/33.422);
tcb->m_ssThresh = (int) (3.266-(segmentsAcked)-(71.896)-(21.871)-(46.221)-(2.6)-(41.545)-(71.608)-(20.823));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (48.409/36.779);
	cnt = (int) (44.64-(47.743)-(cnt)-(66.218)-(22.97));
	tcb->m_ssThresh = (int) (34.937*(57.025)*(45.73)*(37.849)*(87.43)*(35.971)*(74.583)*(4.813)*(68.844));

} else {
	tcb->m_cWnd = (int) (45.669/1.001);
	tcb->m_cWnd = (int) (21.776+(53.372)+(38.302)+(71.094)+(72.004)+(76.034));
	cnt = (int) (sKMpdAuJPlwKqmcW*(2.311)*(53.574)*(18.114)*(23.896)*(74.187));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
