tcb->m_segmentSize = (int) (67.765+(58.89)+(39.867));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int eTqjYbzHmtXUntoq = (int) (((0.1)+(4.661)+(34.591)+(0.1)+(39.407)+(10.679)+(88.586))/((0.1)+(0.1)));
float YXCMiezOlJihmiNp = (float) (eTqjYbzHmtXUntoq+(tcb->m_cWnd)+(24.947)+(eTqjYbzHmtXUntoq)+(32.098)+(40.097)+(cnt)+(tcb->m_segmentSize)+(46.048));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int mQTDXEsclxGzVqLF = (int) (83.603-(26.124)-(12.094)-(90.456)-(75.834)-(21.395)-(cnt)-(6.047)-(92.674));
if (YXCMiezOlJihmiNp > mQTDXEsclxGzVqLF) {
	cnt = (int) (12.876*(72.357)*(98.456)*(90.961)*(42.186)*(6.235)*(92.892)*(95.335));

} else {
	cnt = (int) (45.858*(48.962)*(77.386)*(55.922)*(52.97));
	eTqjYbzHmtXUntoq = (int) (74.9-(45.103)-(68.956)-(92.301)-(39.675)-(cnt)-(34.285));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize >= cnt) {
	tcb->m_cWnd = (int) (74.453+(56.194)+(4.653)+(79.905)+(76.529)+(83.406));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	eTqjYbzHmtXUntoq = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (29.944/68.453);

}
