tcb->m_cWnd = (int) (97.424+(12.046)+(76.909)+(1.127)+(13.629)+(25.196)+(60.321)+(93.492)+(28.708));
tcb->m_segmentSize = (int) (6.144-(69.129)-(24.541)-(50.513)-(75.993));
if (segmentsAcked == tcb->m_cWnd) {
	segmentsAcked = (int) (26.586*(45.954)*(tcb->m_cWnd)*(50.567)*(99.906)*(30.106)*(38.081)*(64.978)*(9.599));

} else {
	segmentsAcked = (int) ((((tcb->m_ssThresh+(37.717)+(60.606)+(50.672)))+(41.621)+(50.569)+(73.189))/((0.1)));
	tcb->m_cWnd = (int) (39.273-(60.302)-(3.097)-(32.705)-(tcb->m_ssThresh)-(12.439)-(36.896)-(cnt)-(87.534));

}
tcb->m_ssThresh = (int) (94.151+(14.47)+(2.982)+(62.235)+(80.583)+(45.639)+(tcb->m_ssThresh)+(68.898));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((49.624)+(0.1)+((17.662-(69.222)-(4.512)-(40.306)-(51.35)))+(85.858))/((47.82)+(0.1)+(0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (((42.133)+((94.634*(62.011)*(94.357)*(21.937)*(82.272)*(45.771)*(cnt)*(tcb->m_segmentSize)*(24.665)))+(0.1)+(0.1))/((0.1)+(4.503)+(0.1)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
segmentsAcked = (int) ((((68.138*(96.002)*(tcb->m_segmentSize)*(41.607)*(90.0)*(57.209)*(11.811)*(96.155)*(78.761)))+(8.768)+(92.614)+(0.1)+(0.1))/((13.577)+(90.308)+(0.1)));
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_segmentSize = (int) (92.915+(36.764));
	segmentsAcked = (int) (37.042/0.1);

} else {
	tcb->m_segmentSize = (int) (90.164-(21.38)-(23.364)-(tcb->m_ssThresh));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (67.833+(35.561)+(17.851)+(76.067)+(7.061));
