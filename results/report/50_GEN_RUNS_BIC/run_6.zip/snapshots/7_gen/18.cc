tcb->m_cWnd = (int) (-64.715+(69.561)+(-42.119)+(66.086)+(-75.198)+(-44.235)+(75.088));
tcb->m_cWnd = (int) (47.335*(1.178)*(13.499));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (20.67*(-68.719)*(35.847));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-76.718*(-5.902)*(89.18));
tcb->m_cWnd = (int) (-50.301+(-57.309)+(52.243)+(51.598)+(0.846)+(-74.423)+(-87.96));
tcb->m_cWnd = (int) (7.582*(-8.255)*(49.851));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-98.54+(-8.555)+(-88.831)+(35.123)+(-87.839)+(-61.92)+(-78.17));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (78.406*(74.311)*(65.54));
tcb->m_cWnd = (int) (22.801*(-4.514)*(29.766));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
