if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (9.188-(24.559)-(25.631));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(49.91)+(23.196))/((33.906)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (91.772+(42.607)+(76.68)+(tcb->m_cWnd)+(13.309)+(tcb->m_cWnd)+(32.48));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(25.72)-(89.469)-(43.714)-(3.607)-(86.433)-(39.885)-(48.251)-(48.938));

}
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (-93.009+(-99.7)+(-93.745)+(-99.507)+(33.448)+(49.84));
segmentsAcked = (int) (-17.607+(-86.488)+(-7.263)+(13.225)+(-92.549)+(-38.119));
segmentsAcked = (int) (12.657*(49.775)*(56.544)*(2.381)*(-56.039));
segmentsAcked = (int) (-78.485*(88.956)*(-0.511)*(-37.287)*(-3.026));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (68.095+(25.272)+(-3.176)+(72.722)+(22.259)+(83.92));
segmentsAcked = (int) (59.153+(66.188)+(-5.682)+(62.03)+(31.356)+(-63.957));
segmentsAcked = (int) (9.949*(50.528)*(-64.877)*(12.971)*(40.983));
segmentsAcked = (int) (46.998*(-41.874)*(-72.664)*(10.753)*(-78.066));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
