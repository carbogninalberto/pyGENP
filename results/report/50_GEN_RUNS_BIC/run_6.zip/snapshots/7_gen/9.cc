tcb->m_segmentSize = (int) (33.613*(47.198)*(14.822)*(92.872));
tcb->m_cWnd = (int) (-50.648+(-3.698)+(-41.521)+(-53.823)+(51.606)+(-6.129)+(8.332));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-65.537*(-79.334)*(70.433));
tcb->m_cWnd = (int) (10.091*(-85.784)*(-43.072));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-91.739+(-65.64)+(-62.125)+(-25.054)+(69.431)+(82.124)+(94.356));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
