if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-98.04+(-15.825)+(-5.456)+(42.604)+(4.344)+(-78.221)+(64.105));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-66.692*(-86.507)*(-23.038));
tcb->m_cWnd = (int) (-23.055*(-82.673)*(-45.37));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-0.192*(-45.393)*(-68.876));
tcb->m_cWnd = (int) (1.666*(-38.023)*(-31.836));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
