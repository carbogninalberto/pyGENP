segmentsAcked = (int) (-77.888/-8.614);
