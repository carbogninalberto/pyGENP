float ixlmZiThGJlRopld = (float) 64.295;
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(20.334));
	tcb->m_cWnd = (int) (23.868*(68.057)*(79.602)*(75.616)*(60.503)*(4.473)*(-0.026));
	ixlmZiThGJlRopld = (float) (23.095-(8.155));

} else {
	tcb->m_segmentSize = (int) (32.98+(35.573));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_segmentSize = (int) (32.98+(35.573));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(20.334));
	tcb->m_cWnd = (int) (23.868*(68.057)*(79.602)*(75.616)*(60.503)*(4.473)*(-0.026));
	ixlmZiThGJlRopld = (float) (23.095-(8.155));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
