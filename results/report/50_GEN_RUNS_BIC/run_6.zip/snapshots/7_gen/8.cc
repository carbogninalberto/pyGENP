ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (((-27.191)+((cnt+(91.795)+(89.543)+(tcb->m_cWnd)+(73.261)+(-21.785)+(tcb->m_cWnd)+(-99.28)+(-20.125)))+(7.258)+(-76.758)+(-27.836))/((-17.108)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (32.164+(-42.664)+(-13.728)+(9.091)+(61.298)+(-88.344)+(-81.101));
tcb->m_segmentSize = (int) (-17.68+(-43.028)+(96.695)+(85.657)+(-40.486)+(-22.516)+(71.642));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (((-11.907)+((cnt+(-18.753)+(99.436)+(tcb->m_cWnd)+(36.926)+(-62.548)+(tcb->m_cWnd)+(72.74)+(82.158)))+(-64.491)+(32.753)+(52.798))/((-8.92)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
