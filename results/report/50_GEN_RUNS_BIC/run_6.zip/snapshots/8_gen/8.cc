ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (((-82.458)+((cnt+(-29.55)+(8.583)+(tcb->m_cWnd)+(51.759)+(-55.486)+(tcb->m_cWnd)+(28.939)+(-26.498)))+(96.712)+(49.194)+(-90.917))/((-50.873)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (13.683+(-41.724)+(-44.501)+(69.815)+(-57.39)+(-58.256)+(30.446));
tcb->m_segmentSize = (int) (8.899+(-9.518)+(59.785)+(-82.593)+(22.229)+(95.491)+(-55.74));
ReduceCwnd (tcb);
