tcb->m_cWnd = (int) (-88.884*(20.071)*(99.945));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (60.095*(-84.352)*(97.103));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-73.357*(-64.373)*(69.83));
tcb->m_cWnd = (int) (16.827+(-88.381)+(-97.43)+(-26.204)+(79.403)+(27.718)+(51.668));
tcb->m_cWnd = (int) (98.836*(25.005)*(-3.67));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
