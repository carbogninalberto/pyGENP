if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (91.772+(42.607)+(76.68)+(tcb->m_cWnd)+(13.309)+(tcb->m_cWnd)+(32.48));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(25.72)-(89.469)-(43.714)-(3.607)-(86.433)-(39.885)-(48.251)-(48.938));

} else {
	tcb->m_segmentSize = (int) (9.188-(24.559)-(25.631));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(49.91)+(23.196))/((33.906)+(0.1)));

}
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (91.772+(42.607)+(76.68)+(tcb->m_cWnd)+(13.309)+(tcb->m_cWnd)+(32.48));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(25.72)-(89.469)-(43.714)-(3.607)-(86.433)-(39.885)-(48.251)-(48.938));

} else {
	tcb->m_segmentSize = (int) (9.188-(24.559)-(25.631));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(49.91)+(23.196))/((33.906)+(0.1)));

}
segmentsAcked = (int) (-62.069+(1.829)+(-28.217)+(61.148)+(36.623)+(-24.739));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (57.005*(-72.359)*(80.094)*(-8.916)*(15.304));
segmentsAcked = (int) (-93.624+(-84.057)+(87.82)+(46.494)+(-68.704)+(-57.25));
segmentsAcked = (int) (-37.609+(16.941)+(-63.191)+(10.064)+(0.305)+(-77.115));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (9.951*(-48.832)*(-24.676)*(-17.925)*(37.605));
segmentsAcked = (int) (-80.946*(99.942)*(-21.728)*(6.192)*(-97.5));
segmentsAcked = (int) (-84.62+(97.605)+(-53.517)+(71.988)+(43.915)+(-48.028));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-14.44*(38.413)*(26.157)*(63.145)*(-55.183));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
