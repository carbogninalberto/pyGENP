if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (((14.357)+((cnt+(-62.592)+(1.75)+(tcb->m_cWnd)+(-12.778)+(62.322)+(tcb->m_cWnd)+(60.141)+(-65.102)))+(56.739)+(-82.678)+(45.95))/((62.116)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-12.268+(-60.074)+(-14.472)+(69.671)+(-7.853)+(-57.8)+(-41.999));
tcb->m_segmentSize = (int) (1.856+(-75.509)+(-37.471)+(8.67)+(30.01)+(66.856)+(72.724));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (((-80.459)+((cnt+(73.696)+(7.374)+(tcb->m_cWnd)+(31.918)+(-97.37)+(tcb->m_cWnd)+(30.769)+(37.46)))+(-2.452)+(66.208)+(-8.663))/((83.241)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
