int apBomWNMrXbcnTRo = (int) (0.1/61.62);
apBomWNMrXbcnTRo = (int) (38.38+(92.24)+(segmentsAcked)+(tcb->m_segmentSize)+(63.791)+(56.113)+(29.468)+(25.505));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_cWnd+(95.358)+(14.864)+(71.427));
if (segmentsAcked >= cnt) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(tcb->m_cWnd)*(8.677)*(52.087)*(13.729)*(0.2)*(56.926)*(71.062)*(6.674));
	apBomWNMrXbcnTRo = (int) (51.709*(segmentsAcked)*(64.257)*(tcb->m_cWnd)*(57.645)*(segmentsAcked)*(71.253)*(77.248)*(tcb->m_ssThresh));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (segmentsAcked-(30.361)-(52.235)-(21.522)-(40.287));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
