tcb->m_ssThresh = (int) (10.405*(tcb->m_ssThresh)*(78.673)*(tcb->m_segmentSize)*(58.284)*(89.363)*(63.865)*(25.436)*(tcb->m_segmentSize));
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(7.594)+(55.128)+(31.622)+(61.868));
int VTXWTSHSnLzXmXrQ = (int) (64.325-(15.47)-(tcb->m_ssThresh));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (34.287+(68.996));
tcb->m_cWnd = (int) (8.434+(93.93)+(81.425)+(67.246));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
