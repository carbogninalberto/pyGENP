if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (94.876+(15.944)+(-5.161)+(-98.179)+(6.797)+(-57.672)+(22.863));
tcb->m_cWnd = (int) (-30.939*(-78.968)*(72.702)*(-60.201)*(31.715));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-64.558+(-88.651)+(56.027)+(56.34)+(58.14)+(7.625)+(76.922));
tcb->m_cWnd = (int) (16.864*(76.273)*(35.822)*(36.801)*(-29.278));
