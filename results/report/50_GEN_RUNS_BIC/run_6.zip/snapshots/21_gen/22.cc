float uQSsHDEqfvdtVUAY = (float) (6.548+(69.188)+(83.572)+(65.018)+(85.336)+(39.033));
uQSsHDEqfvdtVUAY = (float) (55.944-(tcb->m_segmentSize));
float thDXVUQacCkKhqlB = (float) (18.819*(36.637)*(50.556)*(58.574)*(77.385)*(13.915)*(21.514));
uQSsHDEqfvdtVUAY = (float) (65.893*(82.722)*(segmentsAcked)*(49.983)*(18.327)*(segmentsAcked)*(99.499)*(68.856));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh >= uQSsHDEqfvdtVUAY) {
	cnt = (int) (95.443+(41.67)+(75.34)+(1.96)+(7.635)+(14.21)+(50.073)+(48.101));
	thDXVUQacCkKhqlB = (float) (tcb->m_cWnd-(50.427)-(78.694)-(segmentsAcked));

} else {
	cnt = (int) (((0.1)+((tcb->m_ssThresh-(24.786)-(28.213)-(90.938)-(61.041)-(84.577)-(18.041)-(81.749)-(96.908)))+(60.647)+(22.232)+(21.569))/((59.523)+(0.1)));

}
if (segmentsAcked <= cnt) {
	tcb->m_cWnd = (int) (23.613+(0.972)+(19.563)+(19.509)+(29.667)+(9.623)+(tcb->m_segmentSize)+(cnt)+(71.749));
	cnt = (int) (tcb->m_cWnd-(37.244)-(90.564)-(42.439)-(7.903)-(thDXVUQacCkKhqlB)-(87.724)-(26.946)-(47.223));

} else {
	tcb->m_cWnd = (int) (22.027+(25.824)+(84.648)+(45.95)+(58.535)+(48.643)+(11.371));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	thDXVUQacCkKhqlB = (float) (28.506+(31.383)+(75.213)+(83.304)+(78.445)+(16.227));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	thDXVUQacCkKhqlB = (float) (62.433-(53.727)-(44.874)-(tcb->m_segmentSize));
	cnt = (int) (98.705*(22.81)*(99.648)*(67.442)*(19.271));

}
if (uQSsHDEqfvdtVUAY != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(35.14)*(24.276));
	uQSsHDEqfvdtVUAY = (float) (92.349*(14.853)*(69.318)*(65.332)*(tcb->m_segmentSize)*(98.665));
	tcb->m_segmentSize = (int) (39.94+(68.59)+(tcb->m_cWnd)+(89.364));

} else {
	tcb->m_ssThresh = (int) (50.317-(95.201)-(20.489)-(18.205)-(40.083));

}
