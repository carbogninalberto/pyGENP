int EOHxDsNhgTdIwTZe = (int) 33.085;
