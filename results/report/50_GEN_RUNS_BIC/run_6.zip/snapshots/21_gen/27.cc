cnt = (int) (segmentsAcked-(33.388)-(59.455)-(37.608)-(84.286));
tcb->m_ssThresh = (int) (95.642-(cnt)-(37.286)-(tcb->m_cWnd)-(46.961)-(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (21.048*(43.768)*(98.567)*(44.004)*(67.16)*(82.813));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (tcb->m_segmentSize+(32.421)+(95.466)+(29.676)+(34.119)+(57.191));
