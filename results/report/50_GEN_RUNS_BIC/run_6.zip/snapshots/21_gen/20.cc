cnt = (int) (84.284-(37.293));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (24.036-(68.643)-(35.526)-(60.942));
cnt = (int) (94.178+(49.139)+(32.858));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	cnt = (int) (29.649*(segmentsAcked)*(23.799)*(36.187)*(19.16)*(62.1)*(21.765)*(83.738)*(95.244));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (((78.033)+(74.49)+(0.1)+(0.1))/((0.1)));

} else {
	cnt = (int) (5.748-(51.368)-(37.892)-(36.42)-(52.429)-(cnt)-(0.219)-(44.599));
	segmentsAcked = (int) (70.766-(8.398)-(49.467));
	ReduceCwnd (tcb);

}
float jAzHpmjzCgyRGLVF = (float) (2.628+(cnt));
ReduceCwnd (tcb);
