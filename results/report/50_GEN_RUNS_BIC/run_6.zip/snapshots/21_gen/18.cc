ReduceCwnd (tcb);
if (segmentsAcked < cnt) {
	cnt = (int) (((8.404)+(0.1)+((4.044*(90.008)*(37.313)*(7.149)))+(52.983))/((34.5)+(85.985)));

} else {
	cnt = (int) (24.303+(segmentsAcked)+(12.734)+(4.192)+(41.945)+(7.447)+(92.263)+(9.75));
	segmentsAcked = (int) (21.106-(89.196)-(37.598)-(tcb->m_ssThresh)-(83.153));

}
ReduceCwnd (tcb);
cnt = (int) (0.1/60.153);
segmentsAcked = (int) (segmentsAcked*(6.558)*(33.893)*(tcb->m_ssThresh)*(56.063)*(60.701)*(segmentsAcked)*(86.009));
