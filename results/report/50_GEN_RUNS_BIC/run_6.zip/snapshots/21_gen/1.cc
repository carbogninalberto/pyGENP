if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (16.108+(-79.894)+(81.003)+(95.262)+(24.172)+(7.223)+(85.703));
tcb->m_cWnd = (int) (83.543*(20.143)*(-67.11)*(38.268)*(58.186));
