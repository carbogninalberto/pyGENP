int rqFwjClgyhsPvnNp = (int) (((93.893)+((cnt+(89.531)+(25.517)+(0.302)+(57.066)+(79.322)))+(0.1)+(0.1)+(82.028)+(91.084))/((0.1)+(7.514)+(0.1)));
rqFwjClgyhsPvnNp = (int) (42.994/(28.937*(cnt)*(73.207)*(37.506)*(rqFwjClgyhsPvnNp)*(18.222)*(rqFwjClgyhsPvnNp)*(38.958)));
int ZKQexszTajnEKCrC = (int) (32.801+(tcb->m_segmentSize)+(84.327)+(69.397)+(17.615)+(96.534)+(69.74)+(0.424));
cnt = (int) (segmentsAcked-(88.401)-(43.614)-(55.259)-(53.845)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(ZKQexszTajnEKCrC));
if (segmentsAcked > segmentsAcked) {
	tcb->m_ssThresh = (int) (71.652*(52.478)*(67.25)*(tcb->m_segmentSize)*(13.174)*(1.065)*(70.424)*(25.704)*(86.359));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (82.349*(77.056)*(58.269)*(45.757)*(tcb->m_cWnd)*(tcb->m_ssThresh));
	segmentsAcked = (int) (91.717*(74.456)*(cnt)*(tcb->m_cWnd)*(93.384)*(ZKQexszTajnEKCrC)*(22.425)*(75.782)*(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (62.464-(15.571));
	tcb->m_segmentSize = (int) (57.465/58.683);
	ZKQexszTajnEKCrC = (int) (tcb->m_segmentSize-(47.285)-(64.454));

} else {
	tcb->m_cWnd = (int) (24.071+(rqFwjClgyhsPvnNp));
	cnt = (int) (47.196-(43.301)-(rqFwjClgyhsPvnNp)-(ZKQexszTajnEKCrC)-(55.262));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
