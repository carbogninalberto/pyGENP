if (tcb->m_segmentSize > cnt) {
	tcb->m_ssThresh = (int) (90.613+(62.7)+(tcb->m_cWnd)+(68.71)+(0.896)+(32.494));
	cnt = (int) (91.963+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(68.837)+(50.028)+(36.19)+(78.343)+(34.433)+(80.844));
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(47.564)+(tcb->m_segmentSize)+(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (24.298-(57.041)-(tcb->m_cWnd)-(0.886)-(15.6));
	tcb->m_cWnd = (int) (76.491*(23.304));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(42.405));
	cnt = (int) (((74.41)+(49.868)+(0.1)+(20.957))/((0.1)+(66.639)+(72.289)));

}
float VCHqnkcSmxvonZOK = (float) (67.894-(tcb->m_segmentSize)-(39.424)-(18.212)-(77.349)-(31.045)-(tcb->m_segmentSize)-(tcb->m_ssThresh));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (15.372+(10.146)+(35.783)+(87.396));
	tcb->m_segmentSize = (int) (((17.218)+((VCHqnkcSmxvonZOK*(68.527)*(10.374)*(85.032)*(6.036)*(49.497)*(15.529)))+((56.699+(99.715)))+(83.509)+(0.1)+(21.407))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (((29.476)+(57.931)+(57.645)+(0.1))/((0.1)));
	VCHqnkcSmxvonZOK = (float) (0.1/47.65);

}
tcb->m_ssThresh = (int) (41.856+(63.323)+(tcb->m_ssThresh)+(26.26)+(53.247)+(92.058));
VCHqnkcSmxvonZOK = (float) (((0.1)+(77.021)+(93.871)+((segmentsAcked+(1.114)+(tcb->m_ssThresh)+(92.226)+(4.697)+(43.968)+(0.671)+(VCHqnkcSmxvonZOK)+(61.768)))+(87.858))/((0.1)+(94.91)));
