if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (31.673/0.1);
	tcb->m_cWnd = (int) (0.1/(15.351+(0.768)+(tcb->m_segmentSize)+(7.342)+(1.949)+(61.245)));

} else {
	tcb->m_cWnd = (int) (((72.627)+(0.1)+(93.04)+(13.091)+(0.1))/((96.474)));
	tcb->m_cWnd = (int) (91.755-(segmentsAcked)-(58.46)-(tcb->m_segmentSize)-(31.252));

}
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	segmentsAcked = (int) (30.597+(67.038)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(79.787)+(63.114)+(45.676));
	segmentsAcked = (int) (((0.1)+(0.1)+(54.045)+(0.1))/((0.1)+(0.1)+(0.1)+(8.147)));

} else {
	segmentsAcked = (int) (63.587+(82.385)+(35.094)+(89.658)+(67.443)+(tcb->m_cWnd)+(92.788)+(tcb->m_segmentSize)+(7.571));

}
tcb->m_ssThresh = (int) (42.041-(89.819)-(51.924)-(92.04)-(74.896)-(45.621)-(6.169)-(cnt)-(tcb->m_ssThresh));
if (cnt > segmentsAcked) {
	tcb->m_ssThresh = (int) (70.199-(87.797));

} else {
	tcb->m_ssThresh = (int) (73.777-(49.893)-(38.012));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(1.484));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
