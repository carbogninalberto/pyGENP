if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (56.744+(31.556));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (94.476+(77.881)+(segmentsAcked)+(segmentsAcked)+(32.725)+(25.392));

} else {
	tcb->m_cWnd = (int) ((40.096+(tcb->m_segmentSize)+(92.838)+(29.396)+(8.78)+(72.911)+(0.695))/0.1);
	segmentsAcked = (int) (26.322+(84.787)+(tcb->m_ssThresh)+(6.436));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= cnt) {
	tcb->m_cWnd = (int) (4.658/46.079);

} else {
	tcb->m_cWnd = (int) (28.388*(10.983)*(cnt)*(33.313)*(18.06)*(segmentsAcked)*(31.809)*(0.176));

}
if (cnt > tcb->m_ssThresh) {
	cnt = (int) (20.651*(98.86)*(tcb->m_ssThresh)*(52.514)*(10.275)*(tcb->m_ssThresh)*(35.282));
	segmentsAcked = (int) (tcb->m_ssThresh-(cnt)-(85.77)-(64.231)-(53.718)-(90.962)-(27.635)-(3.017));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (54.089+(89.193)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(14.22));
	tcb->m_segmentSize = (int) (94.011*(34.93)*(47.998)*(23.0)*(segmentsAcked)*(81.406)*(tcb->m_segmentSize)*(51.986)*(11.761));

}
segmentsAcked = (int) (87.791*(73.554)*(22.395)*(79.124)*(segmentsAcked)*(30.602)*(6.439)*(72.032)*(8.811));
