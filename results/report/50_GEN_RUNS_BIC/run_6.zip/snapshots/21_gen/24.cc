cnt = (int) (60.556+(50.065)+(0.345)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(5.833));
segmentsAcked = (int) (19.081*(tcb->m_ssThresh)*(86.73)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(7.917)*(68.035)*(25.84)*(73.296));
segmentsAcked = (int) (tcb->m_segmentSize+(23.148)+(25.454)+(24.968)+(51.478)+(52.221));
int SfpEaGCHcYwwzALH = (int) (((20.014)+(84.739)+(31.83)+(61.872))/((0.1)+(26.244)));
tcb->m_segmentSize = (int) (36.634+(36.429)+(5.339)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(24.221)+(12.614)+(72.164)+(tcb->m_cWnd));
if (tcb->m_segmentSize <= SfpEaGCHcYwwzALH) {
	cnt = (int) (((0.1)+((86.875-(28.363)-(14.65)-(tcb->m_cWnd)-(61.314)-(32.663)-(30.106)))+((segmentsAcked-(37.202)-(56.115)-(44.1)-(63.922)))+(54.256))/((60.426)));

} else {
	cnt = (int) (52.485-(5.244)-(41.987)-(14.998));

}
SfpEaGCHcYwwzALH = (int) (((0.1)+(88.518)+(0.1)+(0.1)+(46.675)+(0.1))/((0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh <= cnt) {
	segmentsAcked = (int) (tcb->m_ssThresh+(tcb->m_segmentSize)+(18.931));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (SfpEaGCHcYwwzALH+(19.195)+(7.105)+(25.332)+(46.076)+(70.58)+(78.714));

}
