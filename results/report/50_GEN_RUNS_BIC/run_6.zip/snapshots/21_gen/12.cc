tcb->m_ssThresh = (int) (95.739*(98.819));
tcb->m_cWnd = (int) (26.461+(44.118)+(22.473)+(55.312)+(tcb->m_segmentSize));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((2.179)+((7.615-(33.183)-(27.956)-(53.442)))+(39.573)+(0.1)+(73.932)+(39.821))/((0.1)));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(24.326)-(95.04)-(36.42));
	tcb->m_segmentSize = (int) (((0.1)+(63.924)+(32.828)+(0.1))/((0.1)+(0.1)+(15.764)+(41.767)));

} else {
	tcb->m_segmentSize = (int) (29.379/62.934);
	tcb->m_ssThresh = (int) (64.379+(11.836)+(77.451)+(19.454)+(78.631)+(66.12)+(8.787)+(tcb->m_cWnd));

}
