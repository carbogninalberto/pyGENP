if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int hsqZiRKfVXbnOQDI = (int) (((92.862)+(86.817)+((tcb->m_cWnd+(8.764)+(35.25)+(34.07)))+(19.306))/((18.918)+(40.967)));
if (tcb->m_ssThresh == hsqZiRKfVXbnOQDI) {
	cnt = (int) (66.939-(51.316)-(72.194)-(32.551)-(92.34));
	tcb->m_cWnd = (int) (87.663/52.635);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (0.1/22.405);

}
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	hsqZiRKfVXbnOQDI = (int) (86.106+(24.128)+(73.374)+(92.478)+(38.719));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	hsqZiRKfVXbnOQDI = (int) (((0.1)+(52.196)+(0.1)+(0.1)+(63.223))/((62.007)+(2.81)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
