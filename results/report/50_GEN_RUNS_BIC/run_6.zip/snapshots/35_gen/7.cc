if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_segmentSize = (int) (41.414+(94.631)+(80.777));
	tcb->m_cWnd = (int) (12.267/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(37.147)-(5.562)-(cnt)-(18.598)-(96.803)-(tcb->m_ssThresh)-(tcb->m_ssThresh));
	ReduceCwnd (tcb);

}
float lacgLqgZwJEePrOj = (float) (tcb->m_cWnd*(30.075));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (12.383/0.1);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
