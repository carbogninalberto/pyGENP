float bDlFpScXJBrFszor = (float) (44.059+(79.974)+(tcb->m_segmentSize)+(segmentsAcked)+(segmentsAcked)+(85.512));
ReduceCwnd (tcb);
if (cnt > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (55.673-(0.774)-(tcb->m_cWnd)-(94.276)-(2.879));

} else {
	tcb->m_segmentSize = (int) (0.1/13.442);
	bDlFpScXJBrFszor = (float) (((35.585)+((1.553*(26.624)*(20.746)*(57.859)*(63.246)))+(0.1)+((83.71+(78.689)))+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));

}
ReduceCwnd (tcb);
bDlFpScXJBrFszor = (float) ((((45.451+(61.661)))+(68.174)+((81.092-(98.582)-(33.588)-(11.429)-(11.822)-(tcb->m_ssThresh)-(49.002)-(10.22)))+(0.1)+(0.1))/((53.135)));
if (tcb->m_segmentSize < cnt) {
	tcb->m_cWnd = (int) (97.044-(87.148)-(48.656)-(tcb->m_ssThresh)-(83.232)-(27.384)-(tcb->m_cWnd));
	cnt = (int) (70.008-(74.827)-(segmentsAcked)-(84.284)-(14.075)-(46.31)-(cnt));

} else {
	tcb->m_cWnd = (int) (cnt-(cnt)-(58.6));

}
