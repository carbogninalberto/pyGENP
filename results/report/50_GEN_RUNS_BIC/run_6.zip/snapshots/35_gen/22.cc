if (tcb->m_cWnd >= cnt) {
	tcb->m_ssThresh = (int) (83.446*(75.642)*(tcb->m_ssThresh)*(60.864)*(tcb->m_segmentSize)*(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (21.096*(71.026)*(76.106)*(14.597)*(32.345)*(49.549)*(36.849)*(64.427));
	tcb->m_segmentSize = (int) (19.251+(tcb->m_cWnd));

}
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (56.025+(30.75)+(96.307)+(tcb->m_segmentSize)+(segmentsAcked)+(66.513));

} else {
	tcb->m_cWnd = (int) (59.345+(9.67)+(70.266)+(43.461));
	segmentsAcked = (int) (78.777-(77.998)-(segmentsAcked)-(24.556)-(61.337)-(71.744)-(9.494)-(23.26)-(22.89));
	cnt = (int) (8.992+(cnt)+(37.13)+(tcb->m_ssThresh)+(8.377)+(72.672)+(70.459));

}
segmentsAcked = (int) ((tcb->m_cWnd+(cnt)+(63.282)+(84.773)+(tcb->m_segmentSize)+(29.057)+(72.439))/0.1);
if (tcb->m_ssThresh > tcb->m_cWnd) {
	segmentsAcked = (int) (2.13*(26.485)*(98.896)*(13.483)*(54.007)*(96.607));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (cnt+(53.189)+(6.15));

} else {
	segmentsAcked = (int) (((0.1)+((63.396-(3.022)-(48.832)-(83.932)-(55.889)-(tcb->m_cWnd)))+(27.888)+(0.1)+(0.1)+(21.471)+(4.204))/((48.425)+(0.1)));

}
tcb->m_cWnd = (int) (37.288+(36.598)+(82.94)+(3.799)+(38.095)+(35.843)+(22.048));
if (tcb->m_cWnd > cnt) {
	tcb->m_segmentSize = (int) (77.455/52.484);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (tcb->m_ssThresh*(65.762)*(60.169)*(8.042)*(83.696)*(97.21)*(3.673)*(cnt)*(97.572));

} else {
	tcb->m_segmentSize = (int) (79.722-(tcb->m_ssThresh));
	segmentsAcked = (int) (((0.1)+(38.004)+(0.1)+(0.1))/((63.785)+(81.811)+(27.718)+(77.362)+(0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
