int ieVqSRINivGlNjPJ = (int) (15.582-(tcb->m_ssThresh)-(80.12)-(13.094)-(tcb->m_segmentSize)-(52.743)-(79.619)-(90.239)-(tcb->m_cWnd));
if (tcb->m_ssThresh <= ieVqSRINivGlNjPJ) {
	ieVqSRINivGlNjPJ = (int) (0.1/70.687);

} else {
	ieVqSRINivGlNjPJ = (int) (42.627/50.721);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((0.1)+((21.543-(25.347)-(segmentsAcked)-(cnt)-(ieVqSRINivGlNjPJ)))+((60.708+(59.711)))+(69.849)+(0.1)+(21.494))/((92.064)+(0.1)+(39.586)));

} else {
	tcb->m_ssThresh = (int) (70.457+(85.424)+(64.658)+(23.269)+(92.558));
	tcb->m_segmentSize = (int) (77.702+(48.717)+(62.783)+(17.411)+(57.558)+(3.918));
	segmentsAcked = (int) (29.228*(7.664)*(78.257)*(42.436)*(49.447)*(53.571)*(tcb->m_ssThresh)*(82.51));

}
