float YCmmvfwBPpCxnJOg = (float) (8.849-(86.041)-(cnt)-(2.276)-(28.747)-(25.599));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	segmentsAcked = (int) (((20.867)+(0.1)+(0.1)+(0.1)+((50.075-(26.279)-(35.145)-(25.271)-(48.019)-(28.008)-(29.903)-(tcb->m_cWnd)-(77.201)))+(0.1)+(1.645)+(80.564))/((6.179)));

} else {
	segmentsAcked = (int) (46.71*(71.972)*(43.774)*(47.664)*(61.154)*(tcb->m_ssThresh)*(20.036)*(53.037)*(73.642));

}
YCmmvfwBPpCxnJOg = (float) (40.412*(62.668)*(1.107)*(90.536)*(segmentsAcked)*(13.582)*(84.685));
ReduceCwnd (tcb);
