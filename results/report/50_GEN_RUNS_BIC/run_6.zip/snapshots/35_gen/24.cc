if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_segmentSize > cnt) {
	tcb->m_cWnd = (int) (16.31+(25.574)+(87.615)+(34.982));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (26.59-(14.075)-(cnt)-(55.634));

}
if (tcb->m_cWnd > segmentsAcked) {
	cnt = (int) (85.692*(cnt));

} else {
	cnt = (int) (((0.1)+(28.683)+(0.1)+(0.1))/((0.1)));
	tcb->m_ssThresh = (int) (55.2+(81.217));

}
if (segmentsAcked > cnt) {
	tcb->m_segmentSize = (int) (11.624+(99.082)+(74.978)+(99.295)+(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (segmentsAcked-(96.027)-(45.376)-(5.463)-(tcb->m_ssThresh)-(46.782)-(tcb->m_cWnd)-(35.321)-(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (75.75-(segmentsAcked)-(31.103)-(7.455)-(segmentsAcked));

}
int NykeGkIxYcQomIuV = (int) (0.1/0.1);
if (tcb->m_ssThresh == NykeGkIxYcQomIuV) {
	tcb->m_segmentSize = (int) (62.142-(91.957)-(28.244));

} else {
	tcb->m_segmentSize = (int) (24.296*(48.633));

}
if (tcb->m_segmentSize != cnt) {
	segmentsAcked = (int) ((tcb->m_segmentSize-(16.103)-(70.252))/0.1);
	NykeGkIxYcQomIuV = (int) (72.279+(81.353)+(90.863));
	cnt = (int) (35.296-(78.246)-(21.748)-(65.445));

} else {
	segmentsAcked = (int) (71.775-(13.691)-(98.405));
	ReduceCwnd (tcb);
	NykeGkIxYcQomIuV = (int) (29.872-(71.894)-(tcb->m_segmentSize)-(75.55)-(42.592)-(37.803)-(26.821)-(16.324)-(33.158));

}
tcb->m_segmentSize = (int) (26.414*(89.231)*(84.572)*(tcb->m_ssThresh)*(98.637));
