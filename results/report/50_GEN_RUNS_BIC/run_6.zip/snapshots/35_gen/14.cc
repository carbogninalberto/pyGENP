tcb->m_ssThresh = (int) (81.444*(70.659)*(segmentsAcked)*(86.463));
int noUHxVMZrzSDTCVF = (int) (61.845*(37.802)*(74.473)*(18.031));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (93.28+(74.582)+(57.943)+(25.882)+(41.507)+(31.49)+(29.461));
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (86.39/0.1);

} else {
	tcb->m_cWnd = (int) (0.1/10.901);
	tcb->m_ssThresh = (int) (((58.7)+(0.1)+(43.543)+((70.477*(85.181)*(segmentsAcked)))+(0.1))/((68.449)+(33.216)));
	noUHxVMZrzSDTCVF = (int) (47.653*(61.207)*(22.652)*(tcb->m_ssThresh)*(97.535)*(noUHxVMZrzSDTCVF)*(59.279));

}
