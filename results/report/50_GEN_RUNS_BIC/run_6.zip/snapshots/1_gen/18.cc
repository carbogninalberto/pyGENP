int sayMEvCdiMCgyNrG = (int) (12.602+(69.185));
if (sayMEvCdiMCgyNrG < segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(23.763)-(sayMEvCdiMCgyNrG)-(47.843)-(62.801));
	tcb->m_segmentSize = (int) ((sayMEvCdiMCgyNrG*(tcb->m_segmentSize)*(39.767)*(51.172))/0.1);
	tcb->m_ssThresh = (int) ((cnt-(9.59)-(55.646)-(21.749)-(28.064)-(76.08)-(segmentsAcked))/25.922);

} else {
	tcb->m_cWnd = (int) (88.628-(54.841));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (segmentsAcked >= segmentsAcked) {
	sayMEvCdiMCgyNrG = (int) (tcb->m_cWnd-(cnt)-(16.66)-(44.876));
	sayMEvCdiMCgyNrG = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (1.372-(91.398)-(43.472)-(52.712)-(cnt)-(61.495)-(67.485)-(44.222));

} else {
	sayMEvCdiMCgyNrG = (int) (75.352-(96.26)-(13.629)-(25.881)-(56.087)-(15.653));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (90.162*(tcb->m_segmentSize));

}
