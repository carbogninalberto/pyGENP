tcb->m_segmentSize = (int) (tcb->m_ssThresh*(32.803)*(tcb->m_segmentSize)*(10.543)*(11.107)*(93.466)*(26.627));
int myiJZVFINIVQBweU = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)));
segmentsAcked = (int) (0.1/32.139);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (tcb->m_cWnd+(22.242)+(30.169)+(76.681)+(65.245)+(61.205)+(36.338)+(77.0));
