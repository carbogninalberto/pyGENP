ReduceCwnd (tcb);
cnt = (int) (67.916+(9.228));
cnt = (int) (65.859-(cnt)-(57.064));
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (segmentsAcked-(tcb->m_cWnd)-(58.514)-(57.205)-(24.871)-(49.516)-(6.527)-(62.624));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(56.912)+(83.426)+(21.213)+(22.44)+(9.079));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
