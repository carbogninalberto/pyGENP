if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(tcb->m_ssThresh)-(60.768)-(78.603)-(59.036)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(66.394)+(0.1))/((0.1)));
	cnt = (int) (63.321+(tcb->m_segmentSize)+(6.212)+(53.838)+(3.711)+(18.77));
	segmentsAcked = (int) (63.075+(segmentsAcked)+(69.737)+(29.473)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(94.56));

}
segmentsAcked = (int) (40.519+(78.309)+(4.441)+(30.827)+(5.324)+(43.707)+(39.228)+(11.469)+(86.75));
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (28.217+(cnt)+(tcb->m_cWnd)+(53.627)+(tcb->m_ssThresh));
	segmentsAcked = (int) (71.447/0.1);

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(87.543)*(70.048)*(77.622)*(tcb->m_ssThresh)*(69.304)*(20.506)*(57.208));
	cnt = (int) (22.199-(71.14)-(35.024)-(30.349)-(32.299));
	ReduceCwnd (tcb);

}
if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) ((23.576+(72.301)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(87.743)+(segmentsAcked)+(76.303))/0.1);

} else {
	segmentsAcked = (int) (tcb->m_ssThresh-(cnt)-(7.595)-(80.968));
	tcb->m_segmentSize = (int) (56.067*(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (73.362-(91.931)-(27.575)-(16.537)-(segmentsAcked)-(26.954));
