tcb->m_cWnd = (int) (38.967*(89.691)*(1.123)*(17.632)*(segmentsAcked)*(2.829)*(94.542)*(53.971));
tcb->m_ssThresh = (int) (((0.1)+(0.1)+((65.736*(tcb->m_ssThresh)*(18.602)*(12.714)*(tcb->m_segmentSize)*(45.415)*(88.376)*(74.912)))+((21.817-(26.455)-(77.806)-(12.788)-(tcb->m_cWnd)-(65.83)-(4.386)-(tcb->m_segmentSize)))+(47.4)+(36.425)+(46.144))/((0.1)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
int VIKvoswBkUFNrblO = (int) (19.926*(20.458)*(75.785));
