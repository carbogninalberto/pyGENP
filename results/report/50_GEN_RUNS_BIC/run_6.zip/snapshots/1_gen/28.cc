ReduceCwnd (tcb);
ReduceCwnd (tcb);
int lNJiIiswfCLecHpd = (int) (38.197-(36.878));
tcb->m_cWnd = (int) (77.572*(-0.08)*(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (lNJiIiswfCLecHpd != lNJiIiswfCLecHpd) {
	segmentsAcked = (int) (lNJiIiswfCLecHpd*(26.832));

} else {
	segmentsAcked = (int) (39.092*(90.971)*(42.823)*(87.36)*(tcb->m_segmentSize)*(11.79)*(75.412)*(70.909)*(55.886));

}
