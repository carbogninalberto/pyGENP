if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (98.028*(63.005)*(17.371)*(73.576)*(89.137)*(65.246)*(44.732)*(57.768)*(cnt));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (13.326-(segmentsAcked)-(segmentsAcked)-(tcb->m_cWnd)-(0.41));

}
float CgznLlrVNIalCuav = (float) (tcb->m_cWnd*(54.181)*(16.292)*(cnt)*(21.893)*(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (tcb->m_segmentSize-(CgznLlrVNIalCuav)-(17.391)-(94.783)-(77.711));
if (tcb->m_cWnd > CgznLlrVNIalCuav) {
	cnt = (int) (tcb->m_cWnd*(53.39)*(69.923));

} else {
	cnt = (int) (73.133*(80.946)*(tcb->m_cWnd)*(19.65)*(76.393)*(44.669)*(65.263)*(39.788)*(81.117));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
