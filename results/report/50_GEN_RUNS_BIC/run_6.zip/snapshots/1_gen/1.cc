if (tcb->m_segmentSize == tcb->m_ssThresh) {
	segmentsAcked = (int) (46.868+(88.772)+(tcb->m_ssThresh)+(44.271)+(69.381)+(41.399)+(segmentsAcked)+(14.113));
	tcb->m_cWnd = (int) (11.784-(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (80.655+(34.052)+(49.814));
	tcb->m_segmentSize = (int) (((0.1)+(39.701)+((tcb->m_cWnd*(33.723)*(14.12)))+(0.1)+(18.372)+(3.688))/((0.1)+(0.1)));
	tcb->m_segmentSize = (int) (0.886+(46.541)+(45.373)+(99.161)+(44.377)+(63.659)+(80.634)+(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (43.239+(14.814)+(61.79)+(62.626));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(72.918)+(3.242)+(88.184)+(29.145)+(56.856));
	tcb->m_segmentSize = (int) (23.866-(94.963)-(56.815)-(80.83)-(tcb->m_ssThresh));

}
tcb->m_ssThresh = (int) (segmentsAcked*(11.767)*(10.246)*(40.341)*(24.75)*(41.803));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
