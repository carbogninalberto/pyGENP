if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (14.871/76.67);
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_segmentSize = (int) (88.267+(53.922)+(segmentsAcked)+(84.551)+(87.827));
	cnt = (int) (20.6*(60.876)*(50.027)*(cnt)*(72.713)*(53.446)*(25.673)*(38.943)*(83.498));
	tcb->m_ssThresh = (int) (88.734+(51.27)+(tcb->m_cWnd)+(65.438)+(55.344)+(24.438)+(38.481));

} else {
	tcb->m_segmentSize = (int) (82.471-(18.503)-(tcb->m_cWnd)-(95.698)-(10.968)-(62.562)-(69.032)-(83.737));
	tcb->m_cWnd = (int) (cnt+(93.478)+(35.333)+(cnt)+(91.944)+(58.446));

}
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(cnt)*(55.878)*(cnt)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
segmentsAcked = (int) (79.491+(63.253)+(38.574)+(cnt)+(0.819)+(53.712));
segmentsAcked = (int) (14.892*(segmentsAcked)*(34.327)*(89.671)*(92.652));
if (segmentsAcked < cnt) {
	cnt = (int) (1.271-(segmentsAcked)-(93.748)-(45.718)-(49.693)-(24.565));

} else {
	cnt = (int) (tcb->m_cWnd-(78.186)-(56.374)-(tcb->m_segmentSize)-(63.311)-(tcb->m_ssThresh));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
