if (cnt >= segmentsAcked) {
	tcb->m_ssThresh = (int) (52.342-(tcb->m_ssThresh)-(87.841));
	segmentsAcked = (int) (45.105*(tcb->m_segmentSize)*(65.458)*(4.612)*(0.746)*(tcb->m_ssThresh)*(59.638));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (cnt-(17.63));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) ((96.698*(18.877))/0.1);

}
ReduceCwnd (tcb);
if (tcb->m_cWnd >= cnt) {
	cnt = (int) (91.678*(68.658)*(tcb->m_segmentSize)*(1.293)*(91.92)*(tcb->m_cWnd)*(67.565));
	segmentsAcked = (int) (33.643-(82.249)-(23.715)-(8.329)-(59.523)-(68.448));
	tcb->m_ssThresh = (int) (65.008*(80.319));

} else {
	cnt = (int) (tcb->m_cWnd+(7.239)+(58.432));
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(51.326)-(97.95)-(tcb->m_segmentSize)-(39.549)-(tcb->m_segmentSize)-(78.239)-(32.488)-(75.245));
	tcb->m_ssThresh = (int) (54.906/0.1);

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (48.289*(64.344)*(23.847)*(49.458));
	tcb->m_ssThresh = (int) (96.622*(62.798)*(26.601)*(80.964)*(87.868)*(tcb->m_segmentSize)*(1.637));
	segmentsAcked = (int) (((63.939)+(28.031)+(49.782)+(66.271)+(0.1)+(78.316))/((94.677)+(14.139)+(27.285)));

} else {
	tcb->m_cWnd = (int) (9.929-(tcb->m_ssThresh)-(82.723)-(83.688)-(6.168)-(cnt)-(22.557));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	cnt = (int) (9.201*(14.833)*(71.269)*(19.938)*(53.665)*(cnt)*(9.45));

} else {
	cnt = (int) (85.822-(17.478)-(28.027)-(43.099)-(84.809)-(38.298));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) ((((93.061+(8.981)+(62.945)+(67.14)+(11.194)+(62.994)))+(0.1)+(15.5)+(2.615)+(0.1))/((28.098)));

}
if (cnt >= tcb->m_segmentSize) {
	segmentsAcked = (int) (((0.1)+(9.554)+(3.623)+(29.25)+(14.4))/((0.1)+(0.1)+(86.802)+(0.1)));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (62.659/0.1);

}
