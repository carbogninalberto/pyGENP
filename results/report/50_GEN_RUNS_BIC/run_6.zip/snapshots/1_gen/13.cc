if (tcb->m_ssThresh > tcb->m_ssThresh) {
	cnt = (int) (59.94/0.1);
	tcb->m_cWnd = (int) (25.401+(24.405)+(88.621)+(75.374)+(7.319)+(62.322)+(78.061)+(85.785)+(86.978));
	tcb->m_segmentSize = (int) ((16.695-(51.539)-(36.964)-(62.485))/57.667);

} else {
	cnt = (int) (0.197*(78.915)*(10.246)*(segmentsAcked)*(49.936)*(91.711)*(tcb->m_cWnd)*(70.116));
	tcb->m_segmentSize = (int) (63.315*(63.727)*(tcb->m_segmentSize)*(86.431));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(16.115)*(12.953));

}
cnt = (int) ((79.871*(18.86))/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked == tcb->m_cWnd) {
	segmentsAcked = (int) (cnt+(1.592));

} else {
	segmentsAcked = (int) (15.577-(50.421)-(tcb->m_cWnd)-(tcb->m_ssThresh));
	segmentsAcked = (int) (4.107-(16.373)-(28.5));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
