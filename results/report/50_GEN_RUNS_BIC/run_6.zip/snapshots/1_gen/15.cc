if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (62.684*(14.786)*(32.166)*(14.647)*(51.85)*(36.237));
	tcb->m_ssThresh = (int) (((22.543)+(94.443)+(0.1)+(31.752))/((97.932)+(0.1)));
	cnt = (int) (19.242+(6.504)+(19.183)+(88.615)+(0.284)+(57.474)+(cnt));

} else {
	tcb->m_cWnd = (int) (64.698+(60.067)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(2.674));
	tcb->m_cWnd = (int) (40.662+(92.734)+(3.725)+(9.499)+(69.169)+(cnt)+(tcb->m_cWnd)+(cnt)+(86.656));
	tcb->m_segmentSize = (int) (16.425+(35.419)+(11.304)+(66.337)+(34.588));

}
segmentsAcked = (int) (63.001-(84.407)-(49.162)-(77.967)-(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt != tcb->m_ssThresh) {
	segmentsAcked = (int) (29.161*(segmentsAcked));
	tcb->m_segmentSize = (int) (67.079-(92.793)-(39.549)-(segmentsAcked)-(38.83)-(41.309)-(79.61));

} else {
	segmentsAcked = (int) (50.729+(segmentsAcked)+(91.055)+(cnt)+(6.897));
	segmentsAcked = (int) (86.18*(10.441)*(96.918)*(segmentsAcked)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(37.617)*(tcb->m_ssThresh));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd > cnt) {
	tcb->m_ssThresh = (int) (45.265+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (8.506*(17.72)*(58.309));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (19.184*(75.102)*(tcb->m_ssThresh)*(54.228)*(12.533)*(tcb->m_segmentSize)*(cnt)*(41.045)*(33.388));
	tcb->m_ssThresh = (int) (0.1/0.1);
	segmentsAcked = (int) (82.187-(65.932)-(52.462)-(40.908)-(90.956));

}
tcb->m_segmentSize = (int) (83.083+(40.898));
segmentsAcked = (int) (31.33*(segmentsAcked)*(51.96)*(20.866)*(1.921));
