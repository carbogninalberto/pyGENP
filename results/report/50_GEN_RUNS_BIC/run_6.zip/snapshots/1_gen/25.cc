ReduceCwnd (tcb);
cnt = (int) (57.543-(tcb->m_segmentSize)-(98.05)-(81.426)-(90.509)-(60.974)-(38.362)-(26.762));
tcb->m_segmentSize = (int) ((((10.924*(7.714)*(42.625)*(59.339)*(tcb->m_ssThresh)*(41.206)*(9.226)))+(0.1)+(84.469)+(0.1)+(0.1))/((28.201)));
if (tcb->m_ssThresh < cnt) {
	tcb->m_cWnd = (int) (71.703*(tcb->m_segmentSize)*(52.196)*(90.657));
	tcb->m_segmentSize = (int) (61.214-(tcb->m_ssThresh)-(13.728)-(15.505)-(49.524)-(17.438)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (57.65-(19.684)-(26.546)-(5.512)-(68.698)-(segmentsAcked)-(89.156)-(26.822)-(tcb->m_cWnd));
	cnt = (int) (56.773-(18.034)-(11.194));
	tcb->m_segmentSize = (int) (20.549*(18.233)*(25.272)*(28.373)*(tcb->m_segmentSize)*(74.994)*(47.614));

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_cWnd*(77.328)*(40.584)*(0.569)*(tcb->m_segmentSize)*(59.338));

} else {
	segmentsAcked = (int) ((((66.428+(74.533)+(tcb->m_cWnd)+(13.696)+(38.901)+(90.478)+(tcb->m_segmentSize)+(10.189)))+(44.288)+(0.1)+(10.38)+(0.1)+(0.1)+(0.1))/((22.312)));
	cnt = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (79.042/0.1);

}
ReduceCwnd (tcb);
