ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (7.779+(54.263)+(74.023)+(tcb->m_cWnd)+(cnt)+(tcb->m_cWnd));
	tcb->m_cWnd = (int) (0.1/21.624);

} else {
	tcb->m_segmentSize = (int) (0.1/69.156);
	tcb->m_ssThresh = (int) ((((92.014+(83.988)+(tcb->m_cWnd)+(22.068)+(cnt)+(cnt)+(86.652)+(46.316)))+(0.1)+(0.1)+((5.68*(55.878)*(77.597)*(85.642)*(15.837)*(73.192)))+(0.1)+(99.959))/((0.1)));
	tcb->m_segmentSize = (int) (11.735+(21.133)+(6.417)+(52.283)+(tcb->m_cWnd)+(7.085)+(34.331));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float XePZcoPYUBPrNFMD = (float) (51.866*(78.513)*(0.079));
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_ssThresh = (int) (63.383*(72.541)*(47.669));

} else {
	tcb->m_ssThresh = (int) (22.052+(90.722)+(99.541));
	tcb->m_segmentSize = (int) (0.1/41.497);
	cnt = (int) (19.247+(67.033));

}
segmentsAcked = (int) (58.269-(tcb->m_segmentSize)-(XePZcoPYUBPrNFMD)-(66.161)-(tcb->m_ssThresh)-(56.236)-(70.001));
if (tcb->m_segmentSize <= cnt) {
	tcb->m_segmentSize = (int) (cnt*(27.545)*(59.735)*(14.967)*(6.472)*(74.52)*(53.584)*(79.734)*(XePZcoPYUBPrNFMD));
	segmentsAcked = (int) (74.452*(52.5)*(24.173)*(87.95)*(tcb->m_cWnd)*(16.232)*(22.075));
	tcb->m_cWnd = (int) (89.017-(96.96));

} else {
	tcb->m_segmentSize = (int) (76.42*(44.413)*(60.765)*(84.477)*(11.261));
	segmentsAcked = (int) (tcb->m_segmentSize+(85.117)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (78.025*(38.492)*(XePZcoPYUBPrNFMD)*(30.351)*(17.779)*(XePZcoPYUBPrNFMD)*(tcb->m_cWnd));

}
if (tcb->m_ssThresh > segmentsAcked) {
	cnt = (int) (14.63+(68.187)+(94.489)+(72.052)+(65.22)+(81.013)+(65.626)+(61.957)+(tcb->m_ssThresh));
	segmentsAcked = (int) (25.045+(68.319)+(segmentsAcked)+(9.174)+(7.97)+(XePZcoPYUBPrNFMD)+(10.547));

} else {
	cnt = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (0.1/5.604);
	XePZcoPYUBPrNFMD = (float) (10.228-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(90.305));

}
ReduceCwnd (tcb);
