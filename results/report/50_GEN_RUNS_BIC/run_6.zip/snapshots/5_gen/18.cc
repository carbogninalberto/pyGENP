ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (84.147-(15.052)-(67.246)-(31.342)-(-70.646));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-84.096-(11.369)-(47.648)-(89.241)-(-55.024));
segmentsAcked = (int) (-19.543-(56.372)-(-56.581)-(-23.668)-(27.677));
