if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (9.188-(24.559)-(25.631));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(49.91)+(23.196))/((33.906)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (91.772+(42.607)+(76.68)+(tcb->m_cWnd)+(13.309)+(tcb->m_cWnd)+(32.48));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(25.72)-(89.469)-(43.714)-(3.607)-(86.433)-(39.885)-(48.251)-(48.938));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (91.772+(42.607)+(76.68)+(tcb->m_cWnd)+(13.309)+(tcb->m_cWnd)+(32.48));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(25.72)-(89.469)-(43.714)-(3.607)-(86.433)-(39.885)-(48.251)-(48.938));

} else {
	tcb->m_segmentSize = (int) (9.188-(24.559)-(25.631));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(49.91)+(23.196))/((33.906)+(0.1)));

}
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (91.772+(42.607)+(76.68)+(tcb->m_cWnd)+(13.309)+(tcb->m_cWnd)+(32.48));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(25.72)-(89.469)-(43.714)-(3.607)-(86.433)-(39.885)-(48.251)-(48.938));

} else {
	tcb->m_segmentSize = (int) (9.188-(24.559)-(25.631));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(49.91)+(23.196))/((33.906)+(0.1)));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (91.772+(42.607)+(76.68)+(tcb->m_cWnd)+(13.309)+(tcb->m_cWnd)+(32.48));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(25.72)-(89.469)-(43.714)-(3.607)-(86.433)-(39.885)-(48.251)-(48.938));

} else {
	tcb->m_segmentSize = (int) (9.188-(24.559)-(25.631));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(49.91)+(23.196))/((33.906)+(0.1)));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (27.199+(31.81)+(-51.102)+(-8.302)+(68.358)+(-21.836));
segmentsAcked = (int) (33.473+(-66.884)+(97.841)+(93.255)+(11.498)+(24.58));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (97.608*(90.78)*(-41.66)*(-35.492)*(-97.512));
segmentsAcked = (int) (-42.472*(-84.088)*(46.315)*(-99.519)*(-58.459));
segmentsAcked = (int) (-24.092+(-43.02)+(-83.438)+(-94.32)+(-68.242)+(-14.367));
segmentsAcked = (int) (71.479+(16.146)+(-69.498)+(18.324)+(28.836)+(78.207));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (45.632*(-35.647)*(61.83)*(-38.201)*(86.956));
segmentsAcked = (int) (83.952*(63.882)*(89.426)*(-43.459)*(72.053));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
