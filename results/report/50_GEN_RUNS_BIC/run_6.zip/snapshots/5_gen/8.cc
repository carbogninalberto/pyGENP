if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (99.557+(-71.968)+(-2.988)+(-61.306)+(96.976)+(-7.527)+(-22.72));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-79.173*(80.118)*(-11.379));
tcb->m_cWnd = (int) (21.026*(-16.773)*(-25.721));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (19.12+(-50.206)+(21.113)+(40.59)+(-95.006)+(-16.784)+(1.801));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-14.729*(88.941)*(23.888));
tcb->m_cWnd = (int) (-45.106*(68.669)*(-86.445));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
