if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (91.772+(42.607)+(76.68)+(tcb->m_cWnd)+(13.309)+(tcb->m_cWnd)+(32.48));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(25.72)-(89.469)-(43.714)-(3.607)-(86.433)-(39.885)-(48.251)-(48.938));

} else {
	tcb->m_segmentSize = (int) (9.188-(24.559)-(25.631));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(49.91)+(23.196))/((33.906)+(0.1)));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (91.772+(42.607)+(76.68)+(tcb->m_cWnd)+(13.309)+(tcb->m_cWnd)+(32.48));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(25.72)-(89.469)-(43.714)-(3.607)-(86.433)-(39.885)-(48.251)-(48.938));

} else {
	tcb->m_segmentSize = (int) (9.188-(24.559)-(25.631));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(49.91)+(23.196))/((33.906)+(0.1)));

}
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (91.772+(42.607)+(76.68)+(tcb->m_cWnd)+(13.309)+(tcb->m_cWnd)+(32.48));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(25.72)-(89.469)-(43.714)-(3.607)-(86.433)-(39.885)-(48.251)-(48.938));

} else {
	tcb->m_segmentSize = (int) (9.188-(24.559)-(25.631));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(49.91)+(23.196))/((33.906)+(0.1)));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (91.772+(42.607)+(76.68)+(tcb->m_cWnd)+(13.309)+(tcb->m_cWnd)+(32.48));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(25.72)-(89.469)-(43.714)-(3.607)-(86.433)-(39.885)-(48.251)-(48.938));

} else {
	tcb->m_segmentSize = (int) (9.188-(24.559)-(25.631));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(49.91)+(23.196))/((33.906)+(0.1)));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-84.595+(-51.937)+(56.435)+(20.185)+(32.768)+(20.397));
segmentsAcked = (int) (84.264*(-74.039)*(-10.209)*(-7.14)*(24.063));
segmentsAcked = (int) (-17.354+(-78.215)+(-22.812)+(-20.055)+(-20.572)+(-58.602));
segmentsAcked = (int) (11.819*(-89.995)*(39.45)*(65.668)*(-7.693));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-22.832*(83.44)*(66.372)*(-62.563)*(94.043));
segmentsAcked = (int) (-47.982*(6.043)*(47.503)*(29.196)*(-63.434));
segmentsAcked = (int) (-66.219+(-50.688)+(-16.729)+(66.713)+(-8.868)+(26.841));
segmentsAcked = (int) (30.404+(9.886)+(-70.801)+(-60.503)+(-34.04)+(-87.175));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (15.901*(-11.856)*(25.753)*(57.817)*(-56.732));
segmentsAcked = (int) (63.879*(59.679)*(-61.703)*(67.903)*(32.616));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
