if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (91.772+(42.607)+(76.68)+(tcb->m_cWnd)+(13.309)+(tcb->m_cWnd)+(32.48));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(25.72)-(89.469)-(43.714)-(3.607)-(86.433)-(39.885)-(48.251)-(48.938));

} else {
	tcb->m_segmentSize = (int) (9.188-(24.559)-(25.631));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(49.91)+(23.196))/((33.906)+(0.1)));

}
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
segmentsAcked = (int) (16.608+(-65.254)+(88.806)+(-19.743)+(-0.693)+(-73.971));
segmentsAcked = (int) (-55.911*(-33.755)*(-13.807)*(-36.99)*(-47.453));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (34.637+(20.308)+(-72.403)+(-13.264)+(76.208)+(-46.606));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (9.188-(24.559)-(25.631));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(49.91)+(23.196))/((33.906)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (91.772+(42.607)+(76.68)+(tcb->m_cWnd)+(13.309)+(tcb->m_cWnd)+(32.48));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(25.72)-(89.469)-(43.714)-(3.607)-(86.433)-(39.885)-(48.251)-(48.938));

}
segmentsAcked = (int) (-96.778*(17.364)*(-32.275)*(-13.996)*(-56.178));
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) ((((54.949+(73.572)+(92.903)+(89.395)))+(0.1)+((tcb->m_segmentSize*(82.328)*(54.832)*(28.242)*(27.435)*(89.063)*(48.013)*(24.119)))+(36.575)+(73.67))/((0.1)+(93.932)));
	segmentsAcked = (int) (15.648-(69.485));

} else {
	segmentsAcked = (int) (81.077*(51.091)*(98.465)*(55.878)*(-90.927)*(37.609));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
segmentsAcked = (int) (-26.571+(-56.313)+(84.808)+(-97.476)+(-2.836)+(18.933));
segmentsAcked = (int) (22.638*(26.218)*(32.874)*(83.796)*(0.317));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (5.211+(-98.937)+(54.187)+(-94.706)+(-46.749)+(-78.931));
segmentsAcked = (int) (-40.945*(-85.21)*(-87.612)*(20.122)*(-83.524));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
