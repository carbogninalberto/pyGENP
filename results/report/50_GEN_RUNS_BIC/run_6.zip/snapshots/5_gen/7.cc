ReduceCwnd (tcb);
int iDbDSqnMKDLEIxKR = (int) (-1.067-(-53.126)-(25.846)-(67.469));
tcb->m_segmentSize = (int) (((98.868)+((cnt+(26.637)+(-59.942)+(tcb->m_cWnd)+(57.394)+(70.148)+(tcb->m_cWnd)+(25.896)+(57.627)))+(-90.928)+(-80.887)+(-12.777))/((48.562)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (50.039+(-14.478)+(-52.934)+(26.11)+(42.888)+(-6.851)+(-1.658));
tcb->m_segmentSize = (int) (21.15+(97.401)+(92.517)+(-79.706)+(94.143)+(68.425)+(90.549));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (((48.467)+((cnt+(-98.891)+(-14.681)+(tcb->m_cWnd)+(-26.163)+(36.286)+(tcb->m_cWnd)+(-95.662)+(-91.638)))+(-24.06)+(-87.572)+(-56.418))/((-22.795)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
