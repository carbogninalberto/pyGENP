tcb->m_cWnd = (int) (((-58.442)+(-66.842)+((-97.652-(-53.829)-(22.708)-(-90.625)-(-78.942)))+(1.753))/((85.723)+(48.362)+(-70.649)+(58.745)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-48.842-(83.306)-(-87.04)-(32.407)-(-55.249));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
