if (tcb->m_segmentSize == tcb->m_cWnd) {
	segmentsAcked = (int) (68.249-(segmentsAcked)-(93.572)-(68.363)-(84.226)-(21.562)-(59.718)-(12.022)-(14.171));

} else {
	segmentsAcked = (int) (80.577+(80.19)+(segmentsAcked)+(65.331)+(94.652)+(48.897));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (43.965+(28.8)+(segmentsAcked)+(41.583)+(48.671)+(7.156)+(82.651));

}
tcb->m_cWnd = (int) (-43.207+(15.812)+(22.209)+(22.012)+(45.205)+(68.342)+(-20.089));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (6.6*(-88.777)*(-7.538));
tcb->m_cWnd = (int) (-66.216*(-70.874)*(-89.571));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (65.344+(15.879)+(44.415)+(-68.935)+(-67.79)+(50.904)+(-67.105));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (69.424*(76.493)*(-92.407));
tcb->m_cWnd = (int) (32.114*(62.821)*(90.76));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
