int AueLlLInxFDbeIxP = (int) (43.66/0.1);
ReduceCwnd (tcb);
if (cnt != tcb->m_segmentSize) {
	cnt = (int) (53.302+(11.198)+(94.646)+(66.728)+(61.856)+(cnt)+(69.351)+(63.897));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (38.645*(73.575)*(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
cnt = (int) (52.457-(tcb->m_cWnd)-(3.586)-(AueLlLInxFDbeIxP)-(81.579)-(20.332)-(36.498)-(92.877)-(93.565));
tcb->m_ssThresh = (int) ((((24.381+(cnt)+(77.309)+(22.686)+(86.908)))+((tcb->m_ssThresh+(tcb->m_cWnd)))+(0.1)+(2.985)+((cnt-(20.04)-(95.422)-(46.699)-(45.029)-(94.553)-(tcb->m_segmentSize)))+(18.985))/((97.273)+(0.1)+(0.1)));
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (86.575*(54.187)*(segmentsAcked)*(54.347)*(19.393)*(52.768));

} else {
	tcb->m_ssThresh = (int) (47.787*(48.439)*(18.768)*(9.1)*(32.998)*(51.578)*(16.406)*(58.717));

}
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	AueLlLInxFDbeIxP = (int) (39.57*(tcb->m_cWnd));

} else {
	AueLlLInxFDbeIxP = (int) (tcb->m_segmentSize-(25.077)-(77.262));
	tcb->m_ssThresh = (int) (2.082*(69.412)*(20.3)*(92.878)*(tcb->m_ssThresh)*(2.535)*(60.726)*(5.09));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
