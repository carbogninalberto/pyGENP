tcb->m_segmentSize = (int) (tcb->m_ssThresh*(19.25)*(91.931));
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/42.81);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (43.167*(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (78.63/79.99);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (cnt-(60.107)-(cnt)-(14.773));
ReduceCwnd (tcb);
segmentsAcked = (int) (83.706-(51.502)-(cnt));
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (segmentsAcked*(tcb->m_ssThresh)*(84.751)*(tcb->m_segmentSize)*(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (90.967+(87.911)+(75.345)+(98.383)+(tcb->m_ssThresh)+(58.226)+(5.715));

}
