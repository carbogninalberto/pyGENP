if (segmentsAcked == tcb->m_segmentSize) {
	cnt = (int) (49.372-(86.464)-(56.713)-(71.206)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(90.235)-(55.609));
	cnt = (int) (16.781*(cnt)*(97.153)*(35.519)*(tcb->m_ssThresh)*(cnt)*(30.855)*(81.843)*(30.807));
	tcb->m_ssThresh = (int) (((91.705)+(73.004)+(0.1)+(45.476)+(96.275)+(0.1)+(69.646))/((73.267)));

} else {
	cnt = (int) (17.572-(76.859)-(87.953)-(4.335)-(59.339));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
float USovSyzXTqmhmaFr = (float) ((2.89-(tcb->m_segmentSize)-(55.119)-(tcb->m_segmentSize)-(84.954)-(40.572))/9.491);
if (USovSyzXTqmhmaFr < segmentsAcked) {
	USovSyzXTqmhmaFr = (float) (67.404/96.875);

} else {
	USovSyzXTqmhmaFr = (float) (tcb->m_ssThresh*(51.569)*(8.926)*(70.435)*(77.937)*(36.303)*(63.026));
	tcb->m_segmentSize = (int) (81.249-(61.241)-(tcb->m_cWnd)-(USovSyzXTqmhmaFr)-(19.636)-(81.083)-(22.443)-(tcb->m_ssThresh));

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_ssThresh = (int) (segmentsAcked+(1.889)+(68.262)+(38.458)+(86.376));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (USovSyzXTqmhmaFr*(tcb->m_cWnd)*(76.082)*(32.491)*(60.209)*(65.428)*(31.94)*(38.344)*(50.32));
	tcb->m_ssThresh = (int) (((0.1)+((93.997+(66.548)+(8.362)+(88.174)+(5.451)))+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(80.003)-(62.02)-(27.322)-(14.012)-(97.789));

}
if (tcb->m_segmentSize > cnt) {
	segmentsAcked = (int) (73.676+(0.488)+(22.717)+(44.669)+(20.784));

} else {
	segmentsAcked = (int) (47.531/0.1);

}
tcb->m_cWnd = (int) ((((64.888*(21.311)*(tcb->m_segmentSize)*(48.515)*(35.348)*(89.687)*(76.59)*(94.396)))+(0.1)+(20.532)+(0.1))/((0.1)+(0.1)+(69.19)+(8.533)+(0.1)));
cnt = (int) (48.096*(69.084)*(39.257)*(tcb->m_cWnd)*(73.694));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
