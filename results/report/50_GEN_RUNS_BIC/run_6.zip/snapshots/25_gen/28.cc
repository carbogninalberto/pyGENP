ReduceCwnd (tcb);
if (cnt < segmentsAcked) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(77.57)+(97.314)+(0.1))/((0.1)));

} else {
	tcb->m_cWnd = (int) (77.742/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (13.624*(8.98)*(88.033)*(74.447)*(3.628)*(95.048));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (tcb->m_cWnd+(21.955)+(63.845)+(3.907)+(24.634));
