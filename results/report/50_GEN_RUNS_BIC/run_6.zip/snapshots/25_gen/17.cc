if (tcb->m_ssThresh != cnt) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(67.342)-(61.669)-(segmentsAcked)-(81.811)-(91.702)-(71.794)-(9.843)-(1.457));

} else {
	tcb->m_cWnd = (int) (80.217*(tcb->m_cWnd)*(tcb->m_cWnd)*(43.072)*(54.485)*(13.95));

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (96.032-(50.454)-(tcb->m_ssThresh)-(segmentsAcked)-(48.727)-(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (0.103*(78.85)*(tcb->m_ssThresh)*(cnt)*(tcb->m_cWnd)*(80.837)*(46.158)*(0.658));
	tcb->m_cWnd = (int) (0.1/18.445);

} else {
	tcb->m_ssThresh = (int) (0.1/48.637);

}
int viNVmklfTeyGleyG = (int) (12.217*(6.844));
if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_cWnd = (int) (92.919-(81.655)-(67.67)-(16.572)-(43.983)-(cnt)-(93.521)-(71.46)-(viNVmklfTeyGleyG));
	ReduceCwnd (tcb);
	viNVmklfTeyGleyG = (int) (10.973+(31.693));

} else {
	tcb->m_cWnd = (int) (0.1/1.467);

}
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (56.966+(66.908)+(cnt)+(54.891)+(97.761)+(28.91)+(30.43));
	viNVmklfTeyGleyG = (int) (71.867+(tcb->m_segmentSize)+(57.768)+(tcb->m_ssThresh)+(95.946));
	tcb->m_cWnd = (int) (92.305*(42.581)*(26.318));

} else {
	tcb->m_ssThresh = (int) (53.173+(33.918)+(8.104));
	tcb->m_ssThresh = (int) (segmentsAcked*(56.845)*(73.985)*(49.753)*(51.257)*(99.202)*(83.466)*(38.311)*(tcb->m_cWnd));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int uFpuxYImwgjgJFkK = (int) (74.597+(62.172)+(6.797)+(78.153)+(33.806));
