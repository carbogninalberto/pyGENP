ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (61.282*(-2.558)*(-76.893)*(79.315)*(-94.557)*(-57.649)*(73.278)*(-54.496));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	segmentsAcked = (int) ((43.096*(cnt)*(tcb->m_cWnd)*(48.935))/0.1);

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(57.787)+(54.413))/((72.152)+(0.1)));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (28.106*(-41.634)*(-97.889)*(34.202)*(53.853));
