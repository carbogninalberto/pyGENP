if (segmentsAcked == cnt) {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (84.885-(19.199)-(tcb->m_segmentSize)-(33.363)-(55.983));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (21.885+(segmentsAcked)+(44.549)+(44.844)+(69.205)+(60.177)+(96.468)+(36.055)+(8.189));

}
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	segmentsAcked = (int) (14.22+(72.366)+(46.443));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (40.365*(5.641));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < cnt) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(cnt)*(94.771));

} else {
	tcb->m_ssThresh = (int) (51.021-(39.326)-(50.769)-(segmentsAcked)-(tcb->m_cWnd));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float zxnoKzrGnFrPAjsl = (float) (33.515+(segmentsAcked));
