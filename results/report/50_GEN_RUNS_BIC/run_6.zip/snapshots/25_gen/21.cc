segmentsAcked = (int) (6.767+(35.636)+(87.564));
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (51.499+(1.22)+(84.383)+(64.151)+(70.605)+(45.58)+(67.249)+(69.414)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) ((84.141+(96.031))/8.817);
	tcb->m_ssThresh = (int) (25.773*(23.91)*(3.622)*(15.802)*(41.025)*(32.043));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(90.59)+(tcb->m_cWnd)+(11.48)+(99.438)+(20.09));
	segmentsAcked = (int) (94.442-(67.527)-(62.681)-(65.248)-(43.479)-(87.717)-(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_ssThresh = (int) (36.759+(segmentsAcked)+(13.688)+(38.507)+(23.331)+(36.742)+(73.785)+(1.402));
cnt = (int) (19.188+(18.484)+(52.769)+(67.89)+(55.746)+(87.111));
tcb->m_segmentSize = (int) (97.579+(36.385)+(55.97));
