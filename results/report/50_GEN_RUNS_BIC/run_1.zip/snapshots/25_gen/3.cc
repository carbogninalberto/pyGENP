float GKdVJwmlRMPhcvmz = (float) (50.897+(-62.006)+(-25.973)+(-43.002)+(7.537)+(-8.521)+(-85.189)+(9.662));
int kCARfgdMriWcoGII = (int) (((32.038)+(66.968)+((88.807+(-34.663)+(70.185)+(56.013)))+(12.167)+((-91.351-(17.852)-(85.935)-(93.88)-(-7.046)))+(2.337))/((-4.572)+(-98.715)));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (kCARfgdMriWcoGII-(41.083)-(tcb->m_segmentSize)-(80.267)-(67.972)-(kCARfgdMriWcoGII)-(94.177)-(12.837));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (((0.1)+(39.505)+(40.565)+(44.363)+(0.1)+(12.873))/((0.1)+(74.337)+(29.808)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
