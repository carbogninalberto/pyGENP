segmentsAcked = (int) (tcb->m_segmentSize-(segmentsAcked)-(36.929));
cnt = (int) (tcb->m_cWnd-(49.556)-(53.27)-(24.12)-(segmentsAcked)-(49.846)-(87.954)-(68.512)-(10.625));
ReduceCwnd (tcb);
segmentsAcked = (int) (0.1/23.002);
cnt = (int) (tcb->m_cWnd*(43.798)*(10.998)*(tcb->m_ssThresh)*(68.877)*(49.875)*(28.252));
if (tcb->m_ssThresh < cnt) {
	segmentsAcked = (int) (segmentsAcked-(tcb->m_segmentSize)-(54.828)-(67.123)-(14.236)-(90.239)-(36.594)-(tcb->m_ssThresh));
	segmentsAcked = (int) ((54.67*(56.646))/0.1);

} else {
	segmentsAcked = (int) (44.199-(15.114)-(37.461)-(61.082)-(cnt)-(48.074)-(1.524)-(53.144));

}
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_ssThresh = (int) (91.44+(53.005)+(tcb->m_cWnd)+(48.365));
	segmentsAcked = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(tcb->m_segmentSize)*(86.131)*(15.026)*(23.54)*(50.932)*(51.645)*(18.841));

}
ReduceCwnd (tcb);
