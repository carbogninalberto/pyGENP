ReduceCwnd (tcb);
float WoMBgIFjBGvIggoX = (float) (13.468+(56.348)+(27.666)+(79.569)+(28.921)+(57.543));
tcb->m_cWnd = (int) (58.091-(cnt));
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	WoMBgIFjBGvIggoX = (float) (WoMBgIFjBGvIggoX-(40.696)-(65.038)-(42.145)-(tcb->m_cWnd)-(54.414)-(14.822)-(51.698));
	tcb->m_segmentSize = (int) (66.253*(cnt)*(44.386)*(77.576)*(14.853)*(21.203)*(54.013)*(13.459)*(59.066));

} else {
	WoMBgIFjBGvIggoX = (float) (30.215-(31.005)-(45.226)-(tcb->m_ssThresh)-(55.803)-(tcb->m_segmentSize)-(56.154));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
