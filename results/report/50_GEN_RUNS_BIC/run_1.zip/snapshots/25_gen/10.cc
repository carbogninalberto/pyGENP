int fosOvHsaAgNhKIqh = (int) (-48.312-(54.97)-(-88.771)-(22.125)-(-50.491)-(88.747)-(58.625)-(-91.89)-(-93.588));
ReduceCwnd (tcb);
segmentsAcked = (int) (99.747/62.118);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
