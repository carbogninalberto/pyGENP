ReduceCwnd (tcb);
tcb->m_cWnd = (int) (45.52+(9.227)+(84.709)+(tcb->m_cWnd)+(42.783)+(3.529)+(45.223));
int PvTExaGRXypijoqR = (int) (88.91+(64.761)+(62.932));
if (cnt == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (99.748+(92.686)+(segmentsAcked)+(11.505)+(12.667)+(segmentsAcked)+(51.513)+(19.457)+(93.175));

} else {
	tcb->m_ssThresh = (int) ((8.899+(tcb->m_ssThresh)+(3.863)+(52.926)+(PvTExaGRXypijoqR)+(30.546)+(41.011))/85.13);
	tcb->m_ssThresh = (int) (32.987-(66.781)-(96.745)-(47.037)-(89.034)-(17.933)-(54.182)-(59.026));

}
PvTExaGRXypijoqR = (int) (69.812*(2.828)*(31.939)*(46.943)*(92.715)*(42.393)*(54.754)*(cnt));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (segmentsAcked-(26.001)-(40.763)-(90.452)-(96.715));
cnt = (int) (((0.1)+((74.334+(67.291)+(58.388)+(16.643)+(tcb->m_segmentSize)+(62.701)+(78.462)+(35.322)+(tcb->m_ssThresh)))+(0.1)+(64.318))/((0.1)+(0.1)+(80.641)+(0.1)+(0.1)));
