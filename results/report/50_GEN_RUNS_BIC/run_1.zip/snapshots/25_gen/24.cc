tcb->m_segmentSize = (int) (94.92*(62.953));
ReduceCwnd (tcb);
float GaSeZhMbBghVJxmT = (float) (99.088*(4.497)*(30.191)*(37.068)*(13.85)*(42.615));
float WeCVdOpLRLpkOIUW = (float) (93.44+(GaSeZhMbBghVJxmT)+(41.478)+(18.703));
tcb->m_cWnd = (int) (44.52-(68.615)-(GaSeZhMbBghVJxmT)-(45.894)-(80.756)-(83.67)-(76.353));
