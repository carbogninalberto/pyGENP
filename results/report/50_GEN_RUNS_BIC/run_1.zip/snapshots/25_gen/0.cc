int fosOvHsaAgNhKIqh = (int) (92.172-(90.112)-(-16.332)-(15.751)-(76.125)-(-95.902)-(18.915)-(-39.812)-(32.985));
ReduceCwnd (tcb);
segmentsAcked = (int) (-85.71/36.869);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
