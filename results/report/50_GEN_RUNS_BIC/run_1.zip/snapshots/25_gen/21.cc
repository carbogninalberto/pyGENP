if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float kSodMAFlbWooXKEx = (float) (tcb->m_ssThresh-(98.548));
segmentsAcked = (int) (0.1/0.1);
if (kSodMAFlbWooXKEx < segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(49.778)*(65.702)*(90.818)*(tcb->m_segmentSize)*(14.382)*(kSodMAFlbWooXKEx));
	tcb->m_cWnd = (int) (kSodMAFlbWooXKEx-(12.255)-(85.728)-(16.368)-(1.78)-(12.842));
	tcb->m_segmentSize = (int) (71.263-(81.722)-(9.889));

} else {
	tcb->m_ssThresh = (int) (0.1/13.879);
	ReduceCwnd (tcb);

}
