if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float ocVwlBrXZzMAnHHN = (float) 10.45;
ocVwlBrXZzMAnHHN = (float) (74.973+(-71.9));
tcb->m_cWnd = (int) (33.863*(48.137)*(10.653)*(-62.036));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
