ReduceCwnd (tcb);
segmentsAcked = (int) (36.719-(segmentsAcked)-(tcb->m_segmentSize));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float YCOTHsWkaLSgSNzu = (float) (tcb->m_segmentSize*(7.725)*(48.018));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
