if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/45.4);
	segmentsAcked = (int) (33.455+(tcb->m_cWnd)+(78.06)+(tcb->m_cWnd)+(61.245)+(67.248)+(29.184));
	cnt = (int) (26.998-(81.041));

} else {
	tcb->m_cWnd = (int) (13.49/91.077);

}
tcb->m_segmentSize = (int) (67.457/15.003);
tcb->m_segmentSize = (int) (0.1/65.875);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	cnt = (int) (41.061+(tcb->m_cWnd)+(tcb->m_ssThresh)+(78.537)+(90.703)+(71.941));
	tcb->m_ssThresh = (int) (63.411+(cnt)+(cnt)+(23.694)+(tcb->m_ssThresh)+(97.745));

} else {
	cnt = (int) (9.147+(27.89)+(48.376)+(32.834)+(61.207));

}
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	cnt = (int) (41.35-(95.051)-(34.308)-(54.514)-(tcb->m_ssThresh)-(82.688));
	tcb->m_cWnd = (int) (40.716-(57.881)-(17.726)-(75.962)-(62.086)-(70.864));

} else {
	cnt = (int) (65.941+(47.594)+(45.058)+(53.175));
	tcb->m_segmentSize = (int) (85.503+(tcb->m_ssThresh)+(38.883)+(69.456)+(46.636));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
