if (tcb->m_segmentSize == cnt) {
	tcb->m_cWnd = (int) (20.549*(76.397)*(32.379)*(segmentsAcked)*(4.185)*(10.793));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (15.735-(25.545)-(tcb->m_cWnd)-(segmentsAcked)-(93.658)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (55.771+(44.775)+(16.626)+(88.613)+(80.147)+(7.785));

}
if (cnt == segmentsAcked) {
	tcb->m_cWnd = (int) (36.193-(4.252)-(28.534)-(40.915)-(0.29)-(54.893)-(41.195));

} else {
	tcb->m_cWnd = (int) (48.463*(26.049)*(45.06)*(68.834));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (86.997-(segmentsAcked));
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_cWnd = (int) (89.537/0.1);

} else {
	tcb->m_cWnd = (int) (54.626+(87.862)+(33.732)+(54.816));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_ssThresh = (int) ((tcb->m_segmentSize-(26.572)-(cnt)-(43.876)-(50.061)-(54.762)-(40.429)-(72.581)-(27.56))/81.282);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (15.489+(44.87)+(27.027)+(20.156));
	tcb->m_cWnd = (int) (17.427+(89.062)+(81.269)+(9.306)+(98.634)+(tcb->m_cWnd)+(83.328));

} else {
	tcb->m_ssThresh = (int) (49.494/0.1);

}
