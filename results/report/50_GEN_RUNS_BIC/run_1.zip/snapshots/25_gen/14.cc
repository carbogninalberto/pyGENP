if (tcb->m_segmentSize == cnt) {
	segmentsAcked = (int) (1.83-(27.385));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(16.115)*(tcb->m_ssThresh)*(cnt)*(49.116));
	tcb->m_cWnd = (int) (64.149+(20.421)+(56.566)+(17.731)+(9.489)+(segmentsAcked)+(77.379));

} else {
	segmentsAcked = (int) (77.947+(18.34)+(44.135)+(47.967)+(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (65.752+(25.159)+(4.36)+(63.124)+(56.368)+(28.761)+(tcb->m_segmentSize));

}
tcb->m_ssThresh = (int) (24.511-(56.543)-(tcb->m_segmentSize));
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	segmentsAcked = (int) (((29.325)+(0.1)+(0.1)+(0.1)+(97.218)+(0.1))/((0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (97.465*(52.024)*(42.417)*(tcb->m_ssThresh)*(6.993)*(segmentsAcked)*(7.338)*(47.921)*(cnt));

}
tcb->m_ssThresh = (int) (44.851-(95.604)-(38.744)-(87.176)-(95.868)-(41.278)-(8.21)-(83.799));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (12.693*(0.682)*(48.782)*(18.122)*(85.114)*(52.821)*(24.925)*(65.978));
