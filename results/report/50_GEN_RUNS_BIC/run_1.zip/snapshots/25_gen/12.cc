float mBxhEWZqrdDMUnOE = (float) (54.37+(92.966)+(62.741)+(81.501)+(-73.945)+(-91.723));
float LryBOafdtZzDCjGb = (float) (68.859+(18.897)+(-76.508)+(-30.116)+(60.194)+(-4.169)+(42.427)+(-23.57)+(-11.459));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (72.701-(98.319)-(-98.789));
tcb->m_cWnd = (int) (6.99-(-51.404)-(44.625));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
