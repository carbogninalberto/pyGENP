int XxubeBlrLxfolFsv = (int) (32.696-(98.835));
