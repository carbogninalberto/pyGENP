float kpwafNkWBjBlbbuz = (float) (-66.068+(-3.249)+(35.326)+(-81.889)+(80.54)+(-97.031)+(23.221)+(-34.516)+(99.813));
int taSbqywLwQaKGICe = (int) (-20.328*(-38.144)*(-42.627));
int FGgjHwpfIkNDEEry = (int) (-42.892*(18.682)*(16.331)*(-32.003)*(33.59)*(-10.13));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (18.025*(41.455)*(-87.444)*(17.153)*(38.354));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (81.86*(96.018)*(0.529)*(72.38)*(76.342)*(-66.306));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-17.354*(-20.65)*(36.867)*(-63.995)*(-78.615));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-29.598*(26.342)*(12.171)*(25.688)*(64.308)*(-50.089));
