if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (43.062-(25.116)-(12.851)-(80.937));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (5.771-(70.548)-(50.537)-(19.441)-(2.989)-(tcb->m_segmentSize)-(segmentsAcked)-(20.429));

}
