segmentsAcked = (int) (64.888-(-6.354)-(57.407));
tcb->m_cWnd = (int) (43.765*(84.814)*(22.336)*(29.979)*(61.424)*(5.041)*(10.325)*(-13.345)*(4.12));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-1.543*(-6.194)*(-80.959)*(66.956)*(-79.718)*(7.596)*(-82.326)*(86.301));
tcb->m_cWnd = (int) (-68.509*(-25.918)*(31.822)*(-6.867)*(82.068)*(-82.159)*(-71.514)*(-57.664));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
