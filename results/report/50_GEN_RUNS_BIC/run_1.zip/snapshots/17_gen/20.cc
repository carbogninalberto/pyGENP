int aDbGhAGeNWxCsQxU = (int) (-22.94+(-63.46)+(-75.128)+(-97.711)+(5.414)+(75.636)+(-67.585)+(-82.339));
int sgGLRmXsItdRCPpB = (int) (-46.99+(-76.228)+(-19.163)+(-65.535)+(-12.551)+(-0.669)+(-92.749)+(36.192)+(-49.297));
float OsQDIAMMNaGmEDzl = (float) (95.357+(-13.876)+(67.689)+(-44.352)+(29.055)+(72.629)+(-21.641)+(-12.522)+(6.832));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
