int fosOvHsaAgNhKIqh = (int) (20.306-(82.956)-(-45.397)-(-72.796)-(81.813)-(73.862)-(34.701)-(-24.17)-(3.874));
ReduceCwnd (tcb);
segmentsAcked = (int) (12.066/32.97);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (76.536/-79.045);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
