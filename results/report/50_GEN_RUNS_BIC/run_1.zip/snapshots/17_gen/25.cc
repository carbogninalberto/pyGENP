float kpwafNkWBjBlbbuz = (float) (24.831+(-49.224)+(87.696)+(-7.764)+(-71.865)+(-99.221)+(40.669)+(-87.998)+(3.719));
int taSbqywLwQaKGICe = (int) (-18.208*(-80.434)*(-26.938));
int FGgjHwpfIkNDEEry = (int) (60.574*(-73.818)*(-68.805)*(72.313)*(-42.148)*(64.012));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (39.141*(-47.115)*(39.078)*(33.717)*(88.837));
tcb->m_cWnd = (int) (-25.673*(20.166)*(7.5)*(-50.552)*(-66.212));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (97.681*(40.609)*(7.864)*(50.138)*(39.52)*(41.825));
segmentsAcked = (int) (61.061*(88.52)*(47.048)*(-99.246)*(-42.841)*(46.034));
