if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int XxubeBlrLxfolFsv = (int) (45.324-(43.56));
tcb->m_cWnd = (int) (-40.576*(-20.815)*(-27.047)*(-5.141)*(-6.404)*(-80.274)*(-38.423)*(-76.467)*(-89.714));
tcb->m_cWnd = (int) (51.738*(-52.235)*(-28.548)*(23.786)*(-11.933)*(61.143)*(-27.116)*(-75.088));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-95.313*(-62.423)*(-67.468)*(-44.166)*(-9.419)*(44.888)*(-34.442)*(-4.834));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-38.684*(74.836)*(90.854)*(-62.977)*(99.897)*(-58.356)*(72.57)*(28.42));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (19.228*(40.462)*(37.502)*(95.305)*(-18.184)*(25.542)*(28.537)*(77.918));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
