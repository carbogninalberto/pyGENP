int aDbGhAGeNWxCsQxU = (int) (56.576+(-92.368)+(-55.639)+(3.399)+(15.835)+(15.886)+(-15.856)+(-74.953));
int sgGLRmXsItdRCPpB = (int) (-77.596+(-9.568)+(-12.805)+(-78.982)+(-65.636)+(-23.685)+(0.996)+(-24.018)+(2.864));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
