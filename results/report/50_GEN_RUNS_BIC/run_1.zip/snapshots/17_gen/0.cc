int fosOvHsaAgNhKIqh = (int) (21.614-(-66.063)-(-66.534)-(9.169)-(6.955)-(79.795)-(4.167)-(89.3)-(-6.135));
ReduceCwnd (tcb);
segmentsAcked = (int) (76.202/-7.965);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
