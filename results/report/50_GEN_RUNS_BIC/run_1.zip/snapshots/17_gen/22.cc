segmentsAcked = (int) (-88.681-(89.108)-(-87.91)-(-99.29)-(-79.955));
segmentsAcked = (int) (51.353-(-59.198)-(49.512)-(-77.4)-(-83.858));
int wmcrfwnAuOzGvMHM = (int) 95.881;
float BzjQHPGbWyhmjFvB = (float) (-62.16+(16.854)+(-31.255)+(-20.441)+(73.926)+(2.229)+(31.3));
