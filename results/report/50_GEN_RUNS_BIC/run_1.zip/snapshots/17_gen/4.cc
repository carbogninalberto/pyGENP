if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-13.877*(-32.482)*(11.622)*(35.967)*(49.255)*(-5.342)*(50.003)*(47.087));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
