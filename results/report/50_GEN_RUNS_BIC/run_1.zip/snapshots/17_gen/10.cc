ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-93.635-(-12.93)-(-82.815)-(-91.172)-(-85.044)-(-11.236));
ReduceCwnd (tcb);
segmentsAcked = (int) (-72.311*(11.213)*(-72.122)*(-20.73)*(36.433)*(48.429)*(83.198)*(-41.057)*(87.153));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
