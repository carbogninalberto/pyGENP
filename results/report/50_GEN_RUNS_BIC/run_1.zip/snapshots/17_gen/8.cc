segmentsAcked = (int) (-69.925+(-15.424)+(48.748)+(-70.046)+(80.215)+(-45.385)+(-99.646)+(41.123));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (45.094*(8.245)*(-49.091)*(0.591)*(-54.485)*(-68.615)*(10.201)*(58.834)*(27.591));
tcb->m_cWnd = (int) (-39.76*(77.806)*(44.991)*(-48.092)*(90.81)*(-84.977)*(0.676)*(-94.805));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-77.671*(-67.913)*(-38.361)*(39.879)*(-44.727)*(79.25)*(-35.35)*(-37.736));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
