int aDbGhAGeNWxCsQxU = (int) (78.971+(-88.077)+(84.41)+(60.777)+(83.435)+(86.618)+(80.106)+(60.7));
int sgGLRmXsItdRCPpB = (int) (69.514+(11.129)+(63.809)+(-61.045)+(71.981)+(31.518)+(-38.3)+(-72.972)+(-70.012));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
