float fdtdzIaMQuJxQWHK = (float) (78.506*(tcb->m_cWnd)*(79.082)*(28.417)*(36.998)*(cnt)*(20.186));
int CJNyRNNuUIFqwdAU = (int) (23.554+(29.837)+(37.601)+(74.894)+(94.347)+(49.547)+(39.286)+(50.966));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
CJNyRNNuUIFqwdAU = (int) (97.781*(59.613)*(70.033)*(59.326));
if (fdtdzIaMQuJxQWHK != fdtdzIaMQuJxQWHK) {
	fdtdzIaMQuJxQWHK = (float) (4.526+(40.848)+(tcb->m_cWnd)+(fdtdzIaMQuJxQWHK)+(94.407)+(86.379)+(52.955)+(10.365)+(84.653));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	fdtdzIaMQuJxQWHK = (float) (0.1/0.1);
	fdtdzIaMQuJxQWHK = (float) (76.584*(CJNyRNNuUIFqwdAU)*(tcb->m_ssThresh)*(6.778)*(10.185)*(71.119));

}
int RpEYXxQFRQwgpMHv = (int) (71.948*(45.927)*(cnt)*(81.478)*(71.232)*(37.282));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
