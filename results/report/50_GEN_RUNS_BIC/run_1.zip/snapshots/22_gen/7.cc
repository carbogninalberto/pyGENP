tcb->m_segmentSize = (int) (-5.296*(91.173)*(74.858)*(-15.172)*(-7.172)*(-94.37));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (31.2*(44.08)*(21.841));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-19.372*(-2.553)*(-44.88));
