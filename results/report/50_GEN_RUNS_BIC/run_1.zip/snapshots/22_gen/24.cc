tcb->m_cWnd = (int) (96.116+(29.826)+(segmentsAcked)+(31.223)+(tcb->m_segmentSize)+(tcb->m_segmentSize));
float gXbxSBANzMNKTqxi = (float) (segmentsAcked*(44.926)*(69.609)*(23.318)*(55.288));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	gXbxSBANzMNKTqxi = (float) (69.681+(50.54)+(68.304)+(43.075)+(58.218)+(57.67)+(19.589)+(74.494)+(65.387));
	tcb->m_segmentSize = (int) (47.439+(46.236));
	ReduceCwnd (tcb);

} else {
	gXbxSBANzMNKTqxi = (float) (tcb->m_segmentSize*(46.767)*(59.082)*(26.523)*(70.581)*(13.068)*(18.15)*(cnt)*(72.471));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (70.287-(59.914));

}
cnt = (int) (12.107+(69.112)+(64.006));
segmentsAcked = (int) (0.1/4.367);
if (gXbxSBANzMNKTqxi == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((97.096)+((28.796+(tcb->m_cWnd)+(35.572)+(68.012)+(8.665)+(11.065)))+(0.1)+(0.1))/((18.51)+(0.1)));
	tcb->m_cWnd = (int) (28.827+(13.301)+(10.446)+(tcb->m_segmentSize)+(13.05));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(71.459)+(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (92.628*(93.196));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (gXbxSBANzMNKTqxi == segmentsAcked) {
	segmentsAcked = (int) (((1.478)+(0.1)+(76.12)+(44.698)+((12.538*(95.958)*(56.745)*(tcb->m_ssThresh)*(19.903)*(24.7)*(14.081)*(3.772)*(53.323)))+(8.156)+(69.041))/((0.1)));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (tcb->m_cWnd+(5.045)+(2.882)+(7.783)+(29.011)+(51.725));

}
