ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (16.208+(74.07));
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (13.41*(81.603)*(21.026)*(9.018)*(67.942)*(59.71)*(8.674)*(20.542));

} else {
	tcb->m_ssThresh = (int) (63.178*(tcb->m_cWnd)*(55.869)*(segmentsAcked)*(89.874)*(59.938));
	tcb->m_segmentSize = (int) (84.608*(73.163)*(cnt));

}
float WrPEPlFtVhweCKVk = (float) (21.445+(90.059)+(38.615)+(87.946)+(52.853)+(86.862));
WrPEPlFtVhweCKVk = (float) (15.277*(90.545)*(cnt)*(60.354)*(4.665)*(21.596)*(2.553)*(tcb->m_cWnd));
tcb->m_ssThresh = (int) (56.766*(29.733)*(53.125)*(72.558)*(28.273));
if (tcb->m_ssThresh > cnt) {
	tcb->m_ssThresh = (int) (39.985+(10.225)+(7.901)+(86.987)+(25.397)+(11.634)+(19.402)+(24.936));
	tcb->m_ssThresh = (int) (34.156-(8.632)-(WrPEPlFtVhweCKVk)-(75.99)-(8.681));
	tcb->m_segmentSize = (int) (79.309-(6.471)-(1.581)-(48.588)-(99.863)-(71.675)-(48.271)-(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (89.684*(33.88)*(83.365)*(17.68)*(63.649)*(tcb->m_ssThresh)*(66.889)*(tcb->m_cWnd)*(66.846));
	tcb->m_cWnd = (int) ((97.466*(92.808)*(8.416)*(29.971)*(12.919)*(82.74)*(40.953))/0.1);

}
