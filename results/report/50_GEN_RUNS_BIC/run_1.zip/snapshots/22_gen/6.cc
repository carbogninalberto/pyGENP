tcb->m_segmentSize = (int) (97.899-(-74.428));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-91.411*(-74.015)*(20.614));
