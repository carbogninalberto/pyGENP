ReduceCwnd (tcb);
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	cnt = (int) (19.481*(3.162)*(37.094)*(13.026));

} else {
	cnt = (int) (tcb->m_segmentSize*(95.759)*(25.804)*(75.745)*(tcb->m_cWnd)*(7.462)*(1.583)*(cnt)*(43.239));

}
int gSflwzsQDxbRFRmL = (int) ((36.036*(69.113)*(84.052)*(tcb->m_segmentSize)*(2.472)*(96.098)*(tcb->m_cWnd)*(tcb->m_cWnd))/0.1);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
