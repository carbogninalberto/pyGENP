float SylLeyeghnYxsCey = (float) 27.483;
float ByGyGExSQqOjUitW = (float) (-22.354*(20.58)*(99.741)*(79.543)*(-38.831)*(2.43)*(-81.646));
tcb->m_segmentSize = (int) ((-74.45-(47.287)-(14.594)-(41.957)-(61.442)-(tcb->m_cWnd)-(64.003)-(-6.443)-(36.314))/-85.017);
