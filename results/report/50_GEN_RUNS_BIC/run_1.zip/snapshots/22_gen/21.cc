float GLBmJFTtReYRoCfJ = (float) (88.634*(28.759)*(92.25)*(segmentsAcked)*(69.572));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (tcb->m_segmentSize*(7.574)*(8.363)*(77.99)*(17.206)*(65.491)*(52.924)*(45.448)*(segmentsAcked));
if (cnt > tcb->m_segmentSize) {
	cnt = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (GLBmJFTtReYRoCfJ+(41.866)+(20.307)+(12.546)+(90.09)+(1.072)+(cnt)+(93.401));

} else {
	cnt = (int) (26.536*(51.932)*(26.925)*(cnt)*(tcb->m_ssThresh)*(cnt));
	tcb->m_cWnd = (int) (37.869*(33.145)*(90.769));
	tcb->m_segmentSize = (int) (61.764-(56.112)-(cnt)-(43.828)-(41.071)-(78.898)-(33.545)-(71.27));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (1.213-(tcb->m_segmentSize)-(1.991)-(42.808)-(38.194)-(61.339));
