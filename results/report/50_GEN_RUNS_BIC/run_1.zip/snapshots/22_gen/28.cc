int yKMpzJgDhGTzqPSu = (int) (52.197-(15.356)-(5.013)-(94.97)-(tcb->m_cWnd)-(30.812)-(68.828));
tcb->m_cWnd = (int) (43.895*(27.631));
if (cnt < yKMpzJgDhGTzqPSu) {
	cnt = (int) (62.497+(99.105)+(34.098)+(77.617)+(98.153)+(tcb->m_cWnd)+(63.259));

} else {
	cnt = (int) (26.533*(25.495)*(27.713)*(28.404)*(cnt)*(0.681));
	segmentsAcked = (int) (84.332+(tcb->m_ssThresh));

}
int zIDjCNWRxVTCFgiZ = (int) (segmentsAcked*(cnt)*(90.744)*(yKMpzJgDhGTzqPSu)*(yKMpzJgDhGTzqPSu)*(66.915)*(tcb->m_segmentSize)*(tcb->m_ssThresh));
ReduceCwnd (tcb);
if (cnt != segmentsAcked) {
	cnt = (int) (((73.113)+(0.1)+(0.1)+((93.933+(82.785)+(yKMpzJgDhGTzqPSu)+(81.463)+(tcb->m_ssThresh)))+(38.623)+(14.034)+(0.1)+(0.1))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (29.347*(84.66)*(tcb->m_ssThresh)*(58.148));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (zIDjCNWRxVTCFgiZ+(33.674)+(48.379)+(16.482)+(47.476)+(58.793)+(9.947));

}
if (yKMpzJgDhGTzqPSu < yKMpzJgDhGTzqPSu) {
	tcb->m_cWnd = (int) (72.994+(76.096)+(55.284)+(42.477));
	tcb->m_segmentSize = (int) (((0.1)+(9.877)+(0.1)+(0.1))/((61.798)+(87.984)+(0.1)+(0.1)));
	yKMpzJgDhGTzqPSu = (int) (5.058*(82.964)*(68.465)*(88.375)*(7.042));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);

}
if (segmentsAcked >= zIDjCNWRxVTCFgiZ) {
	segmentsAcked = (int) (91.487+(42.612)+(95.612)+(0.753)+(97.082)+(97.999));

} else {
	segmentsAcked = (int) (56.308-(88.723)-(3.393)-(42.111)-(14.459)-(74.685)-(30.15)-(30.505));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (25.804+(95.092)+(71.557)+(76.584)+(36.019)+(38.604)+(33.579));

}
float tcaxDVWLoIMdHOTI = (float) (((34.899)+(0.1)+(0.1)+(73.518))/((0.1)+(0.1)+(0.1)));
