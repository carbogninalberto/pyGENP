int fosOvHsaAgNhKIqh = (int) (-25.985-(-64.281)-(95.618)-(63.224)-(-43.227)-(21.195)-(16.963)-(-45.295)-(-12.366));
ReduceCwnd (tcb);
segmentsAcked = (int) (78.311/-17.265);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
