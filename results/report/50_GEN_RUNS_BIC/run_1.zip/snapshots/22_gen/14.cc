int fosOvHsaAgNhKIqh = (int) (-20.958-(88.863)-(38.531)-(18.876)-(73.202)-(-36.2)-(-99.578)-(28.761)-(-69.374));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (35.856/26.938);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
