int fosOvHsaAgNhKIqh = (int) (38.445-(51.128)-(38.108)-(32.728)-(47.762)-(-73.09)-(-94.244)-(-8.457)-(-26.523));
ReduceCwnd (tcb);
segmentsAcked = (int) (67.233/-57.395);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
