float iYaSCGIRGqmBySmm = (float) ((74.865-(48.301)-(67.858)-(85.605))/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (segmentsAcked != segmentsAcked) {
	segmentsAcked = (int) (tcb->m_segmentSize+(82.555));

} else {
	segmentsAcked = (int) (55.248-(42.134));
	segmentsAcked = (int) (tcb->m_segmentSize+(33.119)+(segmentsAcked)+(3.282)+(45.996)+(53.9)+(73.104));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (iYaSCGIRGqmBySmm != tcb->m_segmentSize) {
	cnt = (int) (segmentsAcked*(29.993)*(83.744)*(segmentsAcked)*(tcb->m_cWnd)*(90.408)*(29.131)*(21.969)*(93.99));

} else {
	cnt = (int) (tcb->m_segmentSize+(38.441)+(97.983));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (54.299+(70.708)+(31.282)+(segmentsAcked)+(segmentsAcked));

}
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (14.907+(67.273)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (99.494+(64.166)+(79.594));

} else {
	tcb->m_segmentSize = (int) (41.113/0.1);
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (81.823-(43.972)-(iYaSCGIRGqmBySmm)-(64.975)-(75.228)-(53.012));

}
if (iYaSCGIRGqmBySmm != tcb->m_segmentSize) {
	cnt = (int) (31.808-(5.724)-(83.849)-(69.744)-(41.785)-(tcb->m_segmentSize)-(19.161)-(57.926));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (85.854+(55.767)+(67.955)+(3.441)+(68.613)+(tcb->m_ssThresh)+(tcb->m_segmentSize));

} else {
	cnt = (int) (42.562-(76.626)-(82.024)-(45.71)-(cnt));
	tcb->m_ssThresh = (int) (79.086-(80.18)-(46.595));

}
