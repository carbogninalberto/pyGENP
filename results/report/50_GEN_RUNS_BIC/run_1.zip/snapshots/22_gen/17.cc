if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (95.64+(18.146)+(8.958)+(98.464)+(5.5)+(30.373)+(36.725));
	tcb->m_ssThresh = (int) ((segmentsAcked*(cnt)*(3.747)*(tcb->m_ssThresh)*(20.829)*(segmentsAcked)*(45.118)*(38.844))/7.479);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(51.518)-(5.677)-(45.531));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) ((26.091-(94.944))/0.1);

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= tcb->m_cWnd) {
	cnt = (int) (3.117-(55.948)-(52.338)-(53.122)-(78.391)-(16.189)-(94.491));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (((36.418)+(71.965)+(0.1)+(0.1))/((0.1)+(35.272)+(0.1)));
	cnt = (int) (cnt-(41.384)-(62.755)-(cnt)-(10.3));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float manctWnbpkgRMWDr = (float) ((tcb->m_cWnd+(17.112)+(45.288)+(34.273)+(57.123))/37.239);
if (cnt <= cnt) {
	cnt = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (9.684-(51.564)-(89.671)-(71.343)-(7.82));
	tcb->m_ssThresh = (int) (((15.579)+(0.1)+((16.353*(9.303)*(tcb->m_ssThresh)*(89.281)*(51.291)*(manctWnbpkgRMWDr)*(39.031)*(12.719)))+(0.1))/((0.1)+(54.207)+(0.1)));

} else {
	cnt = (int) (manctWnbpkgRMWDr+(32.129)+(23.526)+(85.092)+(92.152)+(tcb->m_ssThresh));
	manctWnbpkgRMWDr = (float) (26.306*(segmentsAcked));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(29.152));

}
