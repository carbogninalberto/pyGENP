float VlgFondtzslRLrwY = (float) (6.034/0.1);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (43.211+(11.94)+(66.659));
VlgFondtzslRLrwY = (float) (88.932*(segmentsAcked)*(36.575)*(56.201));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (64.424-(31.561)-(24.717)-(94.421)-(63.082)-(25.347)-(81.244)-(tcb->m_cWnd));
