int hduUyvdRlvKpbwYn = (int) (-92.921-(16.716)-(-6.53));
int VCVlTMklABnFashy = (int) (37.72*(3.64)*(46.646)*(52.587)*(97.531)*(-70.192));
float ZBJZDLfLtyPJwBpU = (float) (98.719/-71.22);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (hduUyvdRlvKpbwYn < VCVlTMklABnFashy) {
	hduUyvdRlvKpbwYn = (int) (69.866+(42.079));
	hduUyvdRlvKpbwYn = (int) (83.465*(16.237)*(hduUyvdRlvKpbwYn)*(65.584)*(49.91)*(33.646)*(77.061));

} else {
	hduUyvdRlvKpbwYn = (int) (0.1/0.1);

}
if (hduUyvdRlvKpbwYn < VCVlTMklABnFashy) {
	hduUyvdRlvKpbwYn = (int) (69.866+(42.079));
	hduUyvdRlvKpbwYn = (int) (83.465*(16.237)*(hduUyvdRlvKpbwYn)*(65.584)*(49.91)*(33.646)*(77.061));

} else {
	hduUyvdRlvKpbwYn = (int) (0.1/0.1);

}
