tcb->m_segmentSize = (int) (83.307*(98.451)*(69.352)*(26.045)*(25.105)*(50.864)*(9.871)*(42.168));
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (40.297+(tcb->m_ssThresh)+(99.032));

} else {
	tcb->m_cWnd = (int) (77.737-(52.651)-(38.253)-(42.875)-(72.875));

}
segmentsAcked = (int) (63.174*(segmentsAcked)*(53.728)*(84.898)*(70.004)*(16.669)*(91.589)*(tcb->m_cWnd)*(tcb->m_segmentSize));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (65.369/18.515);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (11.801*(47.819)*(42.565)*(73.819));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
