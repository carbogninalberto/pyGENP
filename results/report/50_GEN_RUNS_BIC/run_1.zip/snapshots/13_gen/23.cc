if (cnt == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (90.176+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(52.703)+(11.592));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (57.125-(68.931)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(96.386)-(13.139)-(57.318)-(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (92.459+(tcb->m_segmentSize)+(84.546)+(74.02)+(tcb->m_ssThresh)+(4.981));
	tcb->m_segmentSize = (int) ((tcb->m_cWnd-(tcb->m_cWnd)-(14.465)-(50.283))/10.498);
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (35.475*(53.04)*(32.162));

} else {
	tcb->m_cWnd = (int) (97.676*(11.187));
	cnt = (int) (99.593*(20.884)*(cnt)*(30.693)*(77.39)*(43.08)*(17.476)*(56.72));

}
ReduceCwnd (tcb);
if (cnt != tcb->m_segmentSize) {
	cnt = (int) (((87.931)+(0.1)+((2.558-(21.779)-(14.449)-(91.308)-(28.351)))+(51.79))/((0.1)+(0.1)+(0.1)+(0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (cnt*(71.105)*(49.684)*(25.777)*(94.823)*(97.987));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (31.524+(17.656)+(69.961)+(34.971)+(64.197)+(tcb->m_ssThresh));

}
