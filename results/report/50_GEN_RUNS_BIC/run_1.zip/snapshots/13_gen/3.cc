float kpwafNkWBjBlbbuz = (float) (-86.991+(-95.554)+(15.846)+(18.095)+(63.214)+(-30.797)+(-40.503)+(-3.46)+(-63.613));
int taSbqywLwQaKGICe = (int) (89.526*(-89.566)*(-68.227));
int FGgjHwpfIkNDEEry = (int) (19.743*(-45.46)*(87.473)*(-23.756)*(-48.518)*(54.81));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (53.901*(81.98)*(17.966)*(48.331)*(17.594));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-10.998*(-93.973)*(-60.062)*(-51.651)*(-82.63)*(-58.33));
tcb->m_cWnd = (int) (23.111*(59.358)*(-53.741)*(15.275)*(35.677));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (14.512*(82.146)*(-23.715)*(-50.014)*(-63.097)*(11.609));
