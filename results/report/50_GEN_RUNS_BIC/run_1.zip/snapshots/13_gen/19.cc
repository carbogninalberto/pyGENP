ReduceCwnd (tcb);
if (cnt >= cnt) {
	tcb->m_cWnd = (int) (56.134/0.1);

} else {
	tcb->m_cWnd = (int) (((0.1)+(39.855)+(17.766)+(82.472)+(24.876)+(41.425))/((39.16)));
	tcb->m_segmentSize = (int) (83.4+(31.599)+(41.827)+(51.652));
	segmentsAcked = (int) (86.231/80.773);

}
int pLJywgVAEegZvddW = (int) (27.92-(75.414)-(66.704)-(cnt));
if (pLJywgVAEegZvddW >= tcb->m_ssThresh) {
	cnt = (int) (4.906/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (0.1/0.1);
	pLJywgVAEegZvddW = (int) (30.566+(80.428)+(31.672)+(40.039)+(58.471)+(28.501)+(96.834)+(13.842));

}
int URsgoaPLggSZSNrd = (int) (17.786*(11.536)*(tcb->m_segmentSize)*(96.119)*(2.08)*(63.959)*(40.296)*(84.453)*(93.121));
