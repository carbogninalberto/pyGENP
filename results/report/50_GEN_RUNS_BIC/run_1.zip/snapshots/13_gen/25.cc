tcb->m_cWnd = (int) (74.839*(13.504)*(83.038)*(10.875)*(38.702)*(51.009)*(30.404)*(97.179));
tcb->m_cWnd = (int) ((17.182+(84.16)+(23.139)+(96.925)+(90.878)+(74.154))/0.1);
cnt = (int) (4.306/93.164);
if (tcb->m_ssThresh != cnt) {
	cnt = (int) (42.709*(67.726)*(cnt));
	segmentsAcked = (int) (0.1/0.1);

} else {
	cnt = (int) (((0.1)+((58.732-(29.614)-(84.774)-(cnt)-(52.149)))+(0.1)+(81.184)+(0.1)+(2.091))/((0.1)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (segmentsAcked-(tcb->m_segmentSize));
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (50.993*(99.208)*(96.795)*(67.743));
	tcb->m_ssThresh = (int) (segmentsAcked+(16.26)+(36.901)+(64.54)+(44.502)+(71.316)+(50.988));

} else {
	tcb->m_segmentSize = (int) (91.044*(segmentsAcked));

}
