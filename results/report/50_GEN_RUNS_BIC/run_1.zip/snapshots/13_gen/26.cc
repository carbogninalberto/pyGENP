if (tcb->m_cWnd != tcb->m_segmentSize) {
	cnt = (int) (38.908*(83.988)*(54.913)*(72.127)*(58.889));

} else {
	cnt = (int) (95.932+(74.89)+(93.179));

}
segmentsAcked = (int) (46.313*(98.109)*(77.932));
tcb->m_cWnd = (int) (2.797-(7.697)-(21.806)-(64.462)-(tcb->m_segmentSize));
cnt = (int) (tcb->m_segmentSize*(segmentsAcked)*(55.705));
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (17.808/0.1);

} else {
	tcb->m_ssThresh = (int) (75.805*(14.175)*(52.532)*(6.723)*(77.86)*(24.468)*(segmentsAcked)*(79.709));
	tcb->m_ssThresh = (int) (47.236+(10.068)+(58.26)+(tcb->m_segmentSize));

}
segmentsAcked = (int) (18.1*(84.137));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
