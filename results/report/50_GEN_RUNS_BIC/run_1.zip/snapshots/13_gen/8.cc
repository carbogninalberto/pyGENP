float kpwafNkWBjBlbbuz = (float) (-71.072+(-11.881)+(73.404)+(-36.016)+(63.864)+(-6.423)+(9.572)+(60.904)+(23.879));
int taSbqywLwQaKGICe = (int) (31.447*(-32.937)*(-78.849));
int FGgjHwpfIkNDEEry = (int) (-34.552*(45.779)*(-31.048)*(-32.181)*(4.315)*(-38.997));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-99.404*(-91.894)*(22.904)*(38.06)*(48.867));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-15.891*(38.362)*(-12.727)*(71.291)*(26.994));
segmentsAcked = (int) (24.239*(-22.76)*(-88.96)*(-54.878)*(48.082)*(-58.213));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-99.408*(-76.978)*(3.984)*(-47.157)*(-51.551)*(71.17));
