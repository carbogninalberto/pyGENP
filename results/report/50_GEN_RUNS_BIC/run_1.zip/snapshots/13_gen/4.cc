float kpwafNkWBjBlbbuz = (float) (-11.115+(-61.235)+(-52.49)+(68.003)+(53.548)+(-39.323)+(-45.446)+(-5.577)+(36.384));
int taSbqywLwQaKGICe = (int) (15.338*(77.364)*(21.517));
int FGgjHwpfIkNDEEry = (int) (36.924*(-27.983)*(9.162)*(-67.145)*(-26.913)*(36.268));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-95.936*(77.765)*(84.395)*(26.608)*(-72.089));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (92.004*(74.237)*(27.781)*(-4.266)*(5.335)*(57.793));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (76.337*(-51.919)*(-42.51)*(-15.558)*(-48.794)*(-45.06));
