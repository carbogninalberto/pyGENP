tcb->m_segmentSize = (int) (39.641-(-61.407)-(-82.259));
