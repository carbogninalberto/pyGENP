segmentsAcked = (int) ((tcb->m_cWnd-(-34.083)-(49.885)-(-21.256))/12.301);
float suLSntRktDiblJKs = (float) (-78.38-(-51.962)-(8.8));
int zJNpYUMzxXAjSyTU = (int) (-4.465+(-21.413)+(-78.5)+(29.902));
