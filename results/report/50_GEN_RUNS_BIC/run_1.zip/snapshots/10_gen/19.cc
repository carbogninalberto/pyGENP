if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (45.033/47.97);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (42.493*(cnt)*(69.5));
	tcb->m_cWnd = (int) (34.33+(96.729)+(tcb->m_segmentSize)+(81.425));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (46.214-(9.367)-(tcb->m_cWnd)-(tcb->m_cWnd)-(86.822)-(76.446)-(44.866));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(52.002)*(97.687)*(tcb->m_ssThresh)*(82.347));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_ssThresh = (int) (52.977-(26.34)-(84.864)-(66.524)-(segmentsAcked)-(13.479)-(tcb->m_ssThresh)-(41.203));
	tcb->m_ssThresh = (int) (73.93*(26.094)*(23.511)*(cnt)*(36.268)*(45.484)*(74.001));

} else {
	tcb->m_ssThresh = (int) (61.028+(segmentsAcked)+(96.506)+(60.996)+(55.331));
	cnt = (int) (0.1/0.1);
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (81.357-(95.838)-(43.181));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	cnt = (int) (90.079*(cnt)*(33.807)*(53.204)*(77.894)*(23.59)*(24.599));

} else {
	cnt = (int) (0.1/69.274);

}
tcb->m_cWnd = (int) (segmentsAcked-(segmentsAcked)-(91.642)-(88.613)-(52.211)-(67.29)-(22.345));
