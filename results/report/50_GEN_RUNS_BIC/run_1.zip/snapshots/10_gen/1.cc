if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int FGgjHwpfIkNDEEry = (int) (-87.372*(-64.415)*(59.279)*(-26.531)*(-83.451)*(-60.98));
tcb->m_cWnd = (int) (-15.533*(-87.233)*(-34.75)*(-92.032)*(-85.559));
int taSbqywLwQaKGICe = (int) (1.089*(15.46)*(-31.09));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float kpwafNkWBjBlbbuz = (float) (-60.778+(-90.955)+(88.211)+(76.998)+(3.89)+(52.274)+(-22.568)+(55.306)+(-25.627));
segmentsAcked = (int) (-65.705*(-5.949)*(-8.965)*(61.717)*(-83.692)*(54.673));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-48.396*(-8.477)*(41.372)*(33.775)*(49.553));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (29.755*(-88.66)*(15.462)*(14.971)*(43.168)*(48.261));
