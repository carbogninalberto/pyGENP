float LCckEJwBgQwtJVpZ = (float) (tcb->m_ssThresh-(88.908)-(34.869)-(42.484)-(23.875)-(cnt)-(22.211));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (cnt*(92.197)*(9.013)*(cnt)*(86.659)*(88.183)*(23.191)*(2.947));
	LCckEJwBgQwtJVpZ = (float) (91.529/0.1);
	cnt = (int) (89.757*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(21.096)*(31.251)*(65.3)*(97.312));

} else {
	tcb->m_ssThresh = (int) (80.383-(cnt));

}
int aQNLFVxXMUttUnJN = (int) (tcb->m_cWnd-(5.397));
if (aQNLFVxXMUttUnJN < cnt) {
	tcb->m_ssThresh = (int) ((tcb->m_segmentSize+(71.583)+(53.783)+(19.226)+(61.765)+(segmentsAcked))/0.1);

} else {
	tcb->m_ssThresh = (int) (84.789+(69.456)+(31.044)+(47.415)+(LCckEJwBgQwtJVpZ)+(23.888));
	ReduceCwnd (tcb);

}
float CYshTHeFLYZsUwJs = (float) (17.795*(51.955)*(62.804)*(3.51)*(segmentsAcked)*(tcb->m_ssThresh)*(95.142)*(29.425)*(66.409));
if (LCckEJwBgQwtJVpZ != CYshTHeFLYZsUwJs) {
	CYshTHeFLYZsUwJs = (float) (68.791+(tcb->m_cWnd)+(27.905)+(63.669)+(CYshTHeFLYZsUwJs)+(8.097)+(cnt)+(68.447));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	CYshTHeFLYZsUwJs = (float) (6.424*(54.491)*(13.982));
	aQNLFVxXMUttUnJN = (int) (76.977*(54.541)*(tcb->m_segmentSize)*(1.127)*(aQNLFVxXMUttUnJN));

}
if (aQNLFVxXMUttUnJN == LCckEJwBgQwtJVpZ) {
	tcb->m_segmentSize = (int) (36.504*(45.955)*(25.721)*(aQNLFVxXMUttUnJN)*(LCckEJwBgQwtJVpZ)*(88.481)*(85.231)*(54.877)*(aQNLFVxXMUttUnJN));
	cnt = (int) (23.8/0.1);

} else {
	tcb->m_segmentSize = (int) (36.342+(66.335)+(58.427)+(93.956)+(tcb->m_cWnd)+(CYshTHeFLYZsUwJs)+(98.017));
	tcb->m_ssThresh = (int) (((66.214)+(0.1)+((74.316*(95.674)*(27.725)*(39.78)*(CYshTHeFLYZsUwJs)*(78.571)*(1.88)*(aQNLFVxXMUttUnJN)))+(0.1)+(0.1)+(0.1)+(70.274)+(47.408))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh == cnt) {
	segmentsAcked = (int) (25.843+(10.394)+(74.199)+(aQNLFVxXMUttUnJN)+(tcb->m_cWnd)+(36.365)+(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (82.348*(31.827)*(76.601)*(CYshTHeFLYZsUwJs)*(tcb->m_cWnd));

}
float jhUVmJNjJGRkHRuM = (float) (0.1/38.825);
