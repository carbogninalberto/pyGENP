float bcMHXpseMRkFbMhS = (float) (tcb->m_cWnd-(23.026)-(59.087)-(cnt));
if (segmentsAcked > tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_ssThresh-(82.457)-(90.192)-(0.511)-(23.647)-(40.431)-(29.528)-(88.66)-(bcMHXpseMRkFbMhS));
	tcb->m_ssThresh = (int) (69.622-(22.367));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (10.791+(54.839));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_cWnd = (int) (15.627-(34.624)-(56.34)-(94.257)-(90.442)-(77.423));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (44.221-(87.955)-(68.356)-(tcb->m_cWnd)-(21.247)-(46.009)-(33.832)-(22.799)-(tcb->m_ssThresh));
