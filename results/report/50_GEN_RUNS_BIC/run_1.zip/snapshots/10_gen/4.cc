if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int FGgjHwpfIkNDEEry = (int) (-37.229*(39.183)*(34.132)*(94.414)*(-44.611)*(8.955));
tcb->m_cWnd = (int) (8.919*(45.612)*(28.737)*(56.785)*(86.573));
int taSbqywLwQaKGICe = (int) (-45.406*(-61.808)*(97.141));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float kpwafNkWBjBlbbuz = (float) (28.58+(36.575)+(-36.369)+(-72.15)+(-31.122)+(-67.341)+(-10.779)+(43.268)+(-53.485));
segmentsAcked = (int) (13.985*(3.191)*(48.077)*(94.079)*(-46.553)*(85.985));
tcb->m_cWnd = (int) (-93.269*(9.325)*(-52.31)*(29.645)*(-58.862));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (62.182*(15.196)*(-72.389)*(2.545)*(84.152)*(-84.262));
segmentsAcked = (int) (13.134*(-0.144)*(-28.587)*(-76.925)*(92.24)*(90.109));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (35.565*(61.617)*(-28.108)*(-60.429)*(-12.852)*(71.0));
