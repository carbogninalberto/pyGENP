if (tcb->m_segmentSize != tcb->m_ssThresh) {
	segmentsAcked = (int) (3.971-(10.514)-(70.077)-(41.627)-(63.795));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (84.232-(43.54)-(tcb->m_cWnd)-(31.484)-(44.903)-(33.006)-(3.564)-(segmentsAcked)-(80.614));
	tcb->m_ssThresh = (int) (16.543*(11.326)*(83.043));
	tcb->m_segmentSize = (int) (29.307*(32.826));

}
cnt = (int) (24.213*(20.024)*(79.714)*(45.603)*(9.247)*(63.092));
tcb->m_segmentSize = (int) (cnt-(77.545)-(86.79)-(11.248));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
