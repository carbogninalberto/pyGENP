int azwkvmhbEiPFFfiV = (int) (84.971+(70.112)+(24.931));
if (segmentsAcked != segmentsAcked) {
	tcb->m_ssThresh = (int) ((((42.87+(6.503)+(49.029)+(67.099)+(6.655)+(16.115)+(68.239)))+(57.897)+(0.1)+((90.071*(cnt)*(54.821)*(91.837)*(cnt)))+(0.1)+(65.619))/((0.1)+(0.1)));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (azwkvmhbEiPFFfiV*(75.686)*(segmentsAcked)*(79.286)*(tcb->m_ssThresh)*(15.547)*(79.066)*(7.625)*(11.146));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
if (segmentsAcked < tcb->m_segmentSize) {
	azwkvmhbEiPFFfiV = (int) (5.435-(96.155)-(78.707)-(63.172)-(6.416));
	tcb->m_segmentSize = (int) (27.828-(segmentsAcked)-(62.91));
	cnt = (int) ((((68.033*(4.512)*(76.581)*(21.852)*(21.068)*(75.055)*(54.485)))+((31.797-(39.724)-(17.494)-(54.545)-(92.838)-(77.108)-(segmentsAcked)))+(0.1)+((85.787+(88.347)+(61.961)+(15.257)+(tcb->m_ssThresh)))+(50.578))/((0.1)+(0.1)));

} else {
	azwkvmhbEiPFFfiV = (int) (93.979*(99.048)*(28.948));
	azwkvmhbEiPFFfiV = (int) (tcb->m_ssThresh*(96.639)*(18.402)*(azwkvmhbEiPFFfiV)*(57.419)*(36.0)*(31.973)*(78.964)*(99.783));
	azwkvmhbEiPFFfiV = (int) (45.672/57.633);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
float AkvBRmMyTlfKRxsg = (float) (0.1/(83.106+(25.058)+(30.053)+(tcb->m_cWnd)+(24.953)));
tcb->m_cWnd = (int) (AkvBRmMyTlfKRxsg*(38.114));
tcb->m_ssThresh = (int) (39.941*(97.295)*(53.839)*(31.711)*(tcb->m_ssThresh));
