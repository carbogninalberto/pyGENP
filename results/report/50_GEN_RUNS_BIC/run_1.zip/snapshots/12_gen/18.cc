int EtNWebHBDMCiFUjA = (int) (62.19*(87.683)*(segmentsAcked)*(56.151)*(25.591)*(10.444)*(22.557));
tcb->m_ssThresh = (int) (81.361-(46.25)-(51.099)-(44.552)-(56.16)-(68.94)-(67.289)-(tcb->m_segmentSize));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
