float tGTnTDIbPSybtDGI = (float) (-18.985+(-98.157)+(-25.631)+(68.482)+(-38.258));
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_segmentSize = (int) (34.901-(47.382)-(72.382)-(1.804)-(87.294)-(87.458));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (0.1/84.878);
	tcb->m_cWnd = (int) (83.322+(5.421)+(29.6)+(72.534)+(26.153)+(53.037)+(-90.125)+(73.376));

}
tcb->m_cWnd = (int) (73.785-(48.54)-(-9.005)-(-40.467));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (43.597-(-96.756)-(-62.873)-(40.728)-(-82.916)-(-17.985)-(78.145)-(27.082)-(67.242));
