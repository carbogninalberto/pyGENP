if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (1.207*(29.697)*(93.336)*(tcb->m_ssThresh)*(12.108)*(56.817)*(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (75.351*(54.872)*(tcb->m_cWnd)*(94.858)*(80.079)*(90.012)*(61.69));
	tcb->m_segmentSize = (int) (64.515-(tcb->m_segmentSize)-(91.2)-(1.686)-(65.748)-(5.257)-(7.447));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (27.507+(tcb->m_segmentSize)+(60.76)+(11.593)+(39.055)+(42.421)+(71.444));
tcb->m_segmentSize = (int) (36.412*(tcb->m_ssThresh)*(82.624)*(63.769)*(13.955)*(78.564)*(tcb->m_ssThresh)*(35.435));
if (cnt == tcb->m_segmentSize) {
	segmentsAcked = (int) (24.098+(18.972)+(31.69)+(tcb->m_cWnd)+(76.588)+(tcb->m_cWnd)+(51.944)+(tcb->m_ssThresh));
	ReduceCwnd (tcb);
	cnt = (int) (cnt-(segmentsAcked)-(cnt)-(30.448)-(62.683)-(87.787)-(cnt)-(77.629));

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(73.558)+(0.1)));

}
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (cnt+(64.233)+(cnt)+(49.198)+(56.316));
	tcb->m_segmentSize = (int) (96.486*(54.995)*(tcb->m_segmentSize)*(69.406));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (71.665-(6.277));

}
int pygKARkLNELeKnji = (int) (44.724*(tcb->m_ssThresh));
