cnt = (int) (2.56*(27.873)*(68.535)*(35.106)*(tcb->m_segmentSize));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < cnt) {
	cnt = (int) (52.155*(95.852)*(6.62)*(segmentsAcked)*(99.961)*(99.034)*(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (88.107-(52.054));

} else {
	cnt = (int) (tcb->m_segmentSize-(81.731)-(50.822)-(80.825)-(23.156)-(36.28));
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (14.315*(10.017));
ReduceCwnd (tcb);
