int xPiaedbKtxnbKVaY = (int) (68.321-(51.423)-(68.311)-(37.863)-(91.444)-(93.961)-(48.893)-(54.515));
if (xPiaedbKtxnbKVaY > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (cnt*(1.839)*(22.743)*(tcb->m_ssThresh)*(7.158)*(70.877)*(33.162)*(99.754));

} else {
	tcb->m_ssThresh = (int) (44.082*(48.472)*(61.298)*(cnt));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < cnt) {
	segmentsAcked = (int) (55.664*(19.592)*(xPiaedbKtxnbKVaY)*(tcb->m_cWnd)*(67.837)*(segmentsAcked)*(67.608)*(xPiaedbKtxnbKVaY)*(segmentsAcked));
	tcb->m_segmentSize = (int) (0.838+(11.83)+(49.041)+(0.86));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (26.724+(78.33)+(6.935));

}
if (xPiaedbKtxnbKVaY >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(3.846));

} else {
	tcb->m_ssThresh = (int) (5.946-(84.408));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < cnt) {
	cnt = (int) (31.794+(86.102)+(31.226));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (0.1/(42.71+(96.748)+(67.357)+(63.14)+(30.608)+(79.858)+(tcb->m_ssThresh)+(98.702)));

} else {
	cnt = (int) (77.733*(5.159)*(20.626)*(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (0.1/80.119);
	cnt = (int) (52.891*(64.668)*(93.092)*(25.208));

}
