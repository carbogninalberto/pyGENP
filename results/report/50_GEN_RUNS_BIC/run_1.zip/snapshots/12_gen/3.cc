float LXGdIeYUODCWlkSs = (float) (((19.674)+(89.918)+(-59.946)+(-20.319))/((-94.885)+(-18.915)+(-32.083)));
tcb->m_segmentSize = (int) (17.075+(66.025)+(84.707)+(-97.555)+(-44.92)+(-86.102)+(-64.335)+(67.886));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (13.312-(14.455)-(-31.762)-(tcb->m_cWnd)-(50.883));

} else {
	tcb->m_segmentSize = (int) (37.992*(97.033)*(tcb->m_cWnd)*(2.619));

}
tcb->m_cWnd = (int) (99.353+(-79.701)+(-78.571)+(-50.552)+(66.902)+(-48.567)+(-43.3)+(-33.534)+(-59.787));
