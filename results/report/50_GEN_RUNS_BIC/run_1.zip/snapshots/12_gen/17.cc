if (cnt <= segmentsAcked) {
	tcb->m_segmentSize = (int) (60.059*(43.551)*(72.515)*(4.325)*(3.845)*(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(26.605)-(96.559));

}
float LQMaxoNUPULohscL = (float) (38.296+(55.128)+(42.468)+(69.523));
tcb->m_segmentSize = (int) ((13.651*(24.61)*(tcb->m_cWnd))/(88.783*(51.078)*(1.935)));
float oBMbBRowfhDOgbVO = (float) (((0.1)+(0.1)+(61.481)+(20.579))/((0.1)));
ReduceCwnd (tcb);
