float LXGdIeYUODCWlkSs = (float) (((-61.086)+(-15.504)+(59.182)+(48.899))/((-19.83)+(31.437)+(-42.733)));
tcb->m_segmentSize = (int) (85.011+(-77.646)+(4.411)+(78.065)+(79.446)+(-77.621));
tcb->m_segmentSize = (int) (-30.674+(99.45)+(-39.151)+(-59.879)+(-92.557)+(52.713)+(50.969)+(4.902));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (13.312-(14.455)-(15.013)-(tcb->m_cWnd)-(50.883));

} else {
	tcb->m_segmentSize = (int) (37.992*(97.033)*(tcb->m_cWnd)*(-63.165));

}
tcb->m_cWnd = (int) (-19.096+(-67.989)+(-54.96)+(2.277)+(47.504)+(-16.597)+(-17.138)+(-29.721)+(48.2));
tcb->m_segmentSize = (int) (56.801+(-41.474)+(-4.819)+(0.46)+(-51.267)+(21.226)+(91.594)+(-11.902));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (13.312-(14.455)-(-91.183)-(tcb->m_cWnd)-(50.883));

} else {
	tcb->m_segmentSize = (int) (37.992*(97.033)*(tcb->m_cWnd)*(97.401));

}
tcb->m_cWnd = (int) (76.376+(-38.371)+(-21.719)+(-68.172)+(-14.838)+(46.593)+(68.732)+(-72.536)+(73.881));
