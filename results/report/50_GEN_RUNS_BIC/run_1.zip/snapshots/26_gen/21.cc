if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (5.956+(8.243)+(14.225)+(51.499)+(30.061));

} else {
	tcb->m_ssThresh = (int) (2.294+(10.752)+(17.839)+(67.783)+(tcb->m_ssThresh)+(cnt)+(tcb->m_segmentSize)+(23.765)+(41.8));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt != segmentsAcked) {
	tcb->m_segmentSize = (int) (58.293-(59.309));
	tcb->m_cWnd = (int) (0.1/64.385);

} else {
	tcb->m_segmentSize = (int) (21.766-(77.104));
	tcb->m_ssThresh = (int) (0.1/47.456);
	segmentsAcked = (int) (45.337+(16.375)+(78.694)+(86.03)+(tcb->m_segmentSize)+(14.813));

}
cnt = (int) (32.368*(63.914)*(41.27)*(73.749)*(99.761));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (39.522-(71.87));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(51.335)*(83.457));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (92.333-(tcb->m_cWnd));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (42.495/0.1);

}
int nSOiczIXWmjJcQXy = (int) (80.225+(69.321)+(82.141)+(7.956)+(48.063));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (0.1/78.257);
	cnt = (int) (18.828-(10.117)-(nSOiczIXWmjJcQXy)-(56.197)-(79.116)-(24.401)-(34.399)-(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
int oVaRNeNZwwYLbJxW = (int) (0.025-(36.283)-(41.48));
