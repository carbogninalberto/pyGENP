if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (78.889-(41.083)-(tcb->m_segmentSize)-(80.267)-(67.972)-(-25.602)-(94.177)-(12.837));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (((0.1)+(39.505)+(40.565)+(44.363)+(0.1)+(12.873))/((0.1)+(74.337)+(29.808)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (14.016-(41.083)-(tcb->m_segmentSize)-(80.267)-(67.972)-(-84.019)-(94.177)-(12.837));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (((0.1)+(39.505)+(40.565)+(44.363)+(0.1)+(12.873))/((0.1)+(74.337)+(29.808)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
int kCARfgdMriWcoGII = (int) (((14.272)+(9.372)+((-72.331+(94.543)+(93.456)+(-23.456)))+(-9.091)+((-11.99-(-20.682)-(60.211)-(54.947)-(-89.849)))+(-49.864))/((-25.382)+(-94.767)));
float fuOpGOWRFbxFHIdD = (float) (-56.519/-23.041);
