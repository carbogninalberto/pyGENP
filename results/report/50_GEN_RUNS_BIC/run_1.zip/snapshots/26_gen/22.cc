tcb->m_ssThresh = (int) ((tcb->m_cWnd+(tcb->m_cWnd)+(0.915)+(54.312)+(73.101)+(66.436))/0.1);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (((75.789)+(39.571)+(0.1)+((58.691+(71.179)+(85.791)+(81.471)+(63.014)+(13.876)+(58.161)))+(0.1)+((tcb->m_ssThresh-(34.092)-(67.29)-(tcb->m_ssThresh)-(13.16)-(84.251)-(cnt)-(4.464)))+(13.498))/((0.1)+(92.104)));
cnt = (int) (58.723+(5.616)+(35.708)+(74.485)+(segmentsAcked));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (86.012-(66.04)-(31.034));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
