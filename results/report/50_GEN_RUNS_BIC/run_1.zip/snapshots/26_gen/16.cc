ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	cnt = (int) (15.257+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(13.372)+(90.559));

} else {
	cnt = (int) (0.1/32.736);

}
int IHPTyyiXjRdybHRB = (int) (42.904*(tcb->m_ssThresh)*(57.61));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
