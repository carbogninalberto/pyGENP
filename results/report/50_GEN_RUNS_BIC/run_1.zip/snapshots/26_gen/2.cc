int kCARfgdMriWcoGII = (int) 80.651;
