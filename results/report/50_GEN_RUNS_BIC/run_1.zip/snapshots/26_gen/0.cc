int fosOvHsaAgNhKIqh = (int) (25.578-(23.89)-(38.919)-(45.762)-(-69.67)-(-17.572)-(-88.743)-(63.563)-(11.23));
ReduceCwnd (tcb);
segmentsAcked = (int) (33.014/83.262);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
