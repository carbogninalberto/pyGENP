ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (cnt == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (cnt+(tcb->m_ssThresh)+(16.895));

} else {
	tcb->m_cWnd = (int) (99.432/0.1);
	tcb->m_segmentSize = (int) ((14.824+(82.822))/77.07);

}
segmentsAcked = (int) (95.267-(81.607)-(tcb->m_ssThresh)-(86.827)-(tcb->m_ssThresh)-(33.871)-(71.357));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
