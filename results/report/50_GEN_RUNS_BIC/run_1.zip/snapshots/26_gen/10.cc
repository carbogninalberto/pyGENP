int fosOvHsaAgNhKIqh = (int) (41.195-(-58.109)-(31.147)-(59.34)-(31.315)-(52.545)-(83.362)-(61.941)-(48.584));
ReduceCwnd (tcb);
segmentsAcked = (int) (10.455/-43.169);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
