int srytcXGxsbviWvhS = (int) (tcb->m_ssThresh+(69.771)+(6.71)+(35.06)+(49.92)+(cnt));
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (57.206*(tcb->m_segmentSize)*(17.906)*(68.187)*(58.141)*(71.5)*(67.537)*(tcb->m_cWnd)*(25.099));
	tcb->m_ssThresh = (int) (87.141*(96.263)*(84.337)*(62.588)*(tcb->m_ssThresh)*(54.416)*(cnt)*(49.671));

} else {
	tcb->m_ssThresh = (int) (78.615+(srytcXGxsbviWvhS)+(40.007)+(84.218));

}
ReduceCwnd (tcb);
srytcXGxsbviWvhS = (int) (67.813+(6.101)+(76.073)+(srytcXGxsbviWvhS)+(65.946)+(34.629));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (47.485*(0.287)*(44.956)*(24.818)*(srytcXGxsbviWvhS)*(tcb->m_segmentSize)*(56.682)*(68.89)*(13.512));
