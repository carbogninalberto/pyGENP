if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (16.88*(49.269)*(20.086)*(51.9)*(91.862)*(10.645)*(7.519)*(57.222));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(37.085)+(59.979)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(63.809)+(85.125)+(47.125)+(43.177));

} else {
	tcb->m_segmentSize = (int) (33.517-(segmentsAcked)-(31.584)-(75.177)-(81.33));
	ReduceCwnd (tcb);
	cnt = (int) (segmentsAcked-(27.416)-(27.062)-(17.106)-(cnt)-(90.73));

}
tcb->m_ssThresh = (int) (1.963*(90.934)*(tcb->m_cWnd)*(94.046));
float nDbuVnSJJlbRNmJD = (float) (55.942+(86.791)+(65.746)+(22.568)+(91.157));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
