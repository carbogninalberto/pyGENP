float VDUuWSKeFiQgpGUW = (float) (-19.044/84.687);
ReduceCwnd (tcb);
segmentsAcked = (int) (-5.393+(21.375)+(-36.371)+(88.056));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
