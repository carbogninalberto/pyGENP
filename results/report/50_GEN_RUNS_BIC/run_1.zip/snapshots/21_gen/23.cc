tcb->m_cWnd = (int) (35.602-(4.712)-(segmentsAcked)-(79.869)-(37.265)-(68.659)-(16.959));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	cnt = (int) ((63.044-(2.07)-(tcb->m_cWnd)-(88.803)-(31.721)-(72.892)-(0.959))/(66.225+(tcb->m_ssThresh)+(96.285)));
	tcb->m_cWnd = (int) (16.539-(77.143));
	cnt = (int) ((35.339-(31.496)-(21.387)-(42.874)-(segmentsAcked)-(3.862)-(51.71)-(segmentsAcked)-(37.255))/(5.5*(56.689)*(tcb->m_segmentSize)*(2.514)*(29.885)));

} else {
	cnt = (int) (tcb->m_cWnd*(82.525)*(51.831)*(94.32)*(78.717));

}
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_ssThresh = (int) (65.181*(88.643)*(33.723)*(39.408)*(14.938)*(75.197)*(2.553)*(tcb->m_segmentSize));
	cnt = (int) (65.603+(41.921));

} else {
	tcb->m_ssThresh = (int) (77.998/0.1);
	tcb->m_segmentSize = (int) (12.236+(33.398)+(45.835)+(67.321)+(tcb->m_segmentSize));

}
if (cnt < cnt) {
	segmentsAcked = (int) (75.725+(91.531)+(13.862)+(25.696)+(17.406));

} else {
	segmentsAcked = (int) (((74.767)+(15.685)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)));
	cnt = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(14.622)+((52.304-(tcb->m_ssThresh)-(tcb->m_cWnd)-(19.665)-(82.452)-(78.749)))+(60.105))/((0.1)));
	tcb->m_ssThresh = (int) (63.227/0.1);

}
tcb->m_segmentSize = (int) (44.882-(47.325)-(cnt)-(38.166));
segmentsAcked = (int) (61.941*(99.325)*(2.305));
