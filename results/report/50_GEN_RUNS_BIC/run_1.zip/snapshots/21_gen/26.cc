segmentsAcked = (int) ((23.913*(75.295)*(segmentsAcked)*(tcb->m_ssThresh))/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh != tcb->m_cWnd) {
	segmentsAcked = (int) (66.216+(87.609)+(68.185)+(tcb->m_ssThresh)+(44.329)+(3.512));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (48.812*(segmentsAcked)*(26.413)*(5.945)*(78.641));

} else {
	segmentsAcked = (int) (9.019+(42.43)+(64.923));
	ReduceCwnd (tcb);

}
int TcKtZHErjSgsUdqy = (int) (87.371-(51.334)-(16.797)-(61.052)-(35.142)-(3.11)-(7.778)-(38.973)-(16.806));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (85.114-(14.446)-(TcKtZHErjSgsUdqy)-(37.279)-(73.055));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
