tcb->m_ssThresh = (int) (((0.1)+((81.91+(86.689)+(50.49)))+(0.1)+(0.1))/((55.285)));
cnt = (int) (57.989*(51.355));
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (44.298-(50.251)-(99.338)-(96.716)-(77.41)-(3.477)-(tcb->m_segmentSize)-(96.73));
	cnt = (int) (59.394-(76.852)-(42.159)-(5.709)-(36.737)-(segmentsAcked));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (95.1+(91.205)+(31.464)+(76.878)+(81.962)+(14.193)+(22.377));
	cnt = (int) (48.96/72.795);

}
tcb->m_cWnd = (int) (0.1/(25.377-(tcb->m_segmentSize)-(35.863)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
