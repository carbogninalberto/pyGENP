ReduceCwnd (tcb);
segmentsAcked = (int) (0.422+(19.591)+(80.339)+(-91.362));
