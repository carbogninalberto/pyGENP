if (cnt >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (5.939*(tcb->m_segmentSize)*(33.048)*(77.651)*(74.182));
	tcb->m_ssThresh = (int) (((49.662)+(0.1)+(32.944)+(51.67))/((78.056)+(75.213)+(0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (98.956-(79.466)-(77.523)-(96.185)-(8.597)-(24.44)-(41.909)-(23.051)-(52.674));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (93.237*(90.58));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) ((((3.971-(98.137)-(68.704)))+(13.868)+(0.1)+(39.569)+(0.1))/((15.23)+(62.872)));
int msjJZGGUOULPvIqS = (int) (31.199-(15.593));
ReduceCwnd (tcb);
msjJZGGUOULPvIqS = (int) (((0.1)+((msjJZGGUOULPvIqS*(33.525)))+(0.1)+(0.1)+((10.958-(52.954)))+(0.1))/((0.1)+(0.1)+(26.435)));
