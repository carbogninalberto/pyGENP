int nrwJTFGbtebbypOW = (int) (45.664-(-26.93)-(2.087)-(-47.64)-(88.296)-(58.613)-(35.271)-(-85.315));
int fygvaMUqYzIwIzbq = (int) (-27.966-(-93.955)-(62.332)-(41.415)-(-23.879)-(-12.66)-(1.723)-(39.094)-(-55.49));
if (tcb->m_segmentSize > fygvaMUqYzIwIzbq) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(54.511)+(1.626)+(0.1))/((0.1)+(67.309)+(0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(83.245)+(34.735)+(-53.869));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
fygvaMUqYzIwIzbq = (int) (71.432+(52.082)+(57.147));
