float rSlGWsmDVWEQXUZG = (float) (-21.773-(76.308)-(83.622)-(71.883)-(16.427)-(-36.182)-(-98.124)-(-64.683)-(-22.371));
tcb->m_cWnd = (int) ((((tcb->m_ssThresh*(10.163)*(tcb->m_segmentSize)*(-79.395)*(94.778)))+(-8.892)+((67.917+(62.6)+(-10.873)))+(-4.401)+(-80.202))/((11.659)));
tcb->m_cWnd = (int) ((((57.846+(-25.47)))+((rSlGWsmDVWEQXUZG*(63.897)*(rSlGWsmDVWEQXUZG)))+(66.9)+(77.542)+(-40.824)+(-56.931))/((-77.612)));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) ((((34.396+(44.778)))+((rSlGWsmDVWEQXUZG*(80.556)*(rSlGWsmDVWEQXUZG)))+(5.377)+(77.405)+(73.406)+(-90.955))/((71.604)));
ReduceCwnd (tcb);
