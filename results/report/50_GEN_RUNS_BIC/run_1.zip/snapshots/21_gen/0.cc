int seOqaohqpLvcDnjn = (int) (81.827+(-46.676)+(-59.378)+(5.079));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
