float sJkbmAbKLQsTOCNt = (float) (48.368+(91.194));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
