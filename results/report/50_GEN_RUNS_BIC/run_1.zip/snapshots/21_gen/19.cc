int sjwAUHbrUuMNNSsw = (int) (8.415-(53.588)-(30.8)-(97.245)-(cnt));
if (segmentsAcked == tcb->m_cWnd) {
	segmentsAcked = (int) (45.758*(75.329)*(28.109));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (11.467-(tcb->m_cWnd));

}
tcb->m_segmentSize = (int) (tcb->m_cWnd+(tcb->m_ssThresh)+(39.244)+(52.215)+(93.288)+(98.471));
if (sjwAUHbrUuMNNSsw >= segmentsAcked) {
	tcb->m_cWnd = (int) (3.675+(40.146));
	tcb->m_cWnd = (int) ((cnt+(tcb->m_cWnd)+(98.811)+(51.134)+(59.477)+(38.409)+(9.921)+(32.509)+(81.32))/19.145);

} else {
	tcb->m_cWnd = (int) (34.18/0.1);
	tcb->m_segmentSize = (int) (77.623-(97.858)-(39.156)-(97.562));
	tcb->m_ssThresh = (int) (((73.373)+(0.1)+(16.325)+(0.1)+((17.969*(60.419)*(39.9)*(0.802)*(43.851)*(segmentsAcked)*(5.534)*(88.546)))+(51.832))/((58.727)));

}
segmentsAcked = (int) (85.54+(tcb->m_segmentSize)+(52.391));
