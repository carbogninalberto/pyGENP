float rSlGWsmDVWEQXUZG = (float) 62.087;
rSlGWsmDVWEQXUZG = (float) (11.55/-70.711);
tcb->m_cWnd = (int) ((((tcb->m_ssThresh*(13.073)*(tcb->m_segmentSize)*(-29.083)*(93.532)))+(-23.991)+((-9.585+(12.617)+(2.021)))+(46.285)+(-56.551))/((-86.154)));
tcb->m_cWnd = (int) ((((89.375+(-29.27)))+((rSlGWsmDVWEQXUZG*(25.248)*(rSlGWsmDVWEQXUZG)))+(-4.91)+(-41.269)+(14.911)+(35.246))/((11.981)));
ReduceCwnd (tcb);
