float WkDRFrmVHlneYhDX = (float) 33.947;
