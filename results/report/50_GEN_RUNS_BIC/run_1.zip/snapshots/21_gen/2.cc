segmentsAcked = (int) (12.677/32.104);
float rSlGWsmDVWEQXUZG = (float) 3.2;
rSlGWsmDVWEQXUZG = (float) (96.113/29.051);
tcb->m_cWnd = (int) ((((tcb->m_ssThresh*(91.143)*(tcb->m_segmentSize)*(-1.453)*(91.693)))+(-59.313)+((31.23+(-60.103)+(14.89)))+(20.164)+(16.834))/((94.29)));
tcb->m_cWnd = (int) ((((-63.15+(61.022)))+((rSlGWsmDVWEQXUZG*(-82.347)*(rSlGWsmDVWEQXUZG)))+(-7.298)+(-80.073)+(99.012)+(96.306))/((-26.974)));
ReduceCwnd (tcb);
