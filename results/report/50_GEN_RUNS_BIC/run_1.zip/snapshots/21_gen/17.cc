cnt = (int) (30.489-(4.393)-(segmentsAcked)-(49.288)-(12.115));
ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (55.302*(94.87)*(85.849)*(92.454)*(91.407)*(segmentsAcked)*(16.499)*(43.959)*(14.182));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (4.481-(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (11.918-(19.077)-(segmentsAcked)-(53.421)-(65.377)-(66.837));
	tcb->m_cWnd = (int) (84.356/43.02);

}
tcb->m_segmentSize = (int) (37.095+(34.318)+(40.884)+(92.632));
tcb->m_cWnd = (int) (((0.1)+(0.1)+(51.459)+(0.1)+(0.1)+(0.1)+((54.37+(48.703)+(segmentsAcked)+(94.656)))+(0.1))/((42.966)));
tcb->m_ssThresh = (int) (11.058+(segmentsAcked)+(52.862));
