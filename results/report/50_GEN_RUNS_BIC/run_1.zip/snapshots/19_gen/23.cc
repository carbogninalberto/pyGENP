ReduceCwnd (tcb);
float APzRuCwhvcLQQwNb = (float) (19.253/44.954);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (APzRuCwhvcLQQwNb == APzRuCwhvcLQQwNb) {
	cnt = (int) (39.413-(32.945)-(31.251)-(26.173)-(85.134)-(48.476)-(81.691)-(tcb->m_segmentSize)-(30.402));

} else {
	cnt = (int) (0.1/22.971);
	segmentsAcked = (int) (98.245*(tcb->m_cWnd)*(38.148)*(segmentsAcked)*(21.688)*(98.98)*(APzRuCwhvcLQQwNb)*(tcb->m_cWnd)*(88.034));

}
int BrNycAcrGjqkdLDq = (int) (segmentsAcked*(53.303)*(95.508)*(97.906)*(66.775)*(47.7)*(49.668)*(17.991));
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	BrNycAcrGjqkdLDq = (int) (0.1/10.658);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (((48.896)+(0.1)+(0.1)+(51.631)+(13.882))/((64.747)+(0.1)));

} else {
	BrNycAcrGjqkdLDq = (int) (87.933+(73.511)+(tcb->m_segmentSize)+(1.953)+(21.482)+(tcb->m_segmentSize)+(5.112));
	BrNycAcrGjqkdLDq = (int) (BrNycAcrGjqkdLDq*(46.397)*(79.468)*(tcb->m_ssThresh));
	APzRuCwhvcLQQwNb = (float) (((66.735)+(4.428)+(0.1)+(13.654)+(0.1))/((0.1)+(0.1)+(0.1)+(27.53)));

}
if (cnt > tcb->m_ssThresh) {
	segmentsAcked = (int) (71.551-(24.875)-(65.531)-(27.132));

} else {
	segmentsAcked = (int) (36.28-(3.473)-(26.076));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked <= segmentsAcked) {
	tcb->m_ssThresh = (int) (94.979-(APzRuCwhvcLQQwNb)-(tcb->m_cWnd)-(tcb->m_cWnd)-(85.67)-(cnt)-(81.312)-(89.823)-(68.234));
	tcb->m_cWnd = (int) (69.306+(34.882)+(88.847)+(83.858)+(83.315)+(29.025)+(45.92)+(8.079)+(tcb->m_cWnd));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (36.132*(73.314)*(81.608)*(59.811)*(APzRuCwhvcLQQwNb)*(35.33)*(BrNycAcrGjqkdLDq)*(94.049));
	ReduceCwnd (tcb);
	BrNycAcrGjqkdLDq = (int) (((57.679)+(74.071)+(0.1)+(0.1)+(0.1))/((74.369)+(0.1)+(4.645)));

}
