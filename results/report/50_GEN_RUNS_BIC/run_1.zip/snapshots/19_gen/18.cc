tcb->m_segmentSize = (int) (99.824-(segmentsAcked));
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_segmentSize = (int) (0.114+(85.251)+(36.103)+(tcb->m_ssThresh)+(63.204)+(81.431)+(17.791)+(tcb->m_ssThresh)+(83.705));
	cnt = (int) (((6.781)+(24.739)+((30.786-(tcb->m_segmentSize)-(27.497)-(cnt)-(7.144)))+(23.438)+(0.1)+(0.1))/((50.108)));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(72.109)+(7.93)+(98.745)+(82.049)+(15.044)+(78.513)+(10.422));

}
int LApaVBvCdjzhOuuk = (int) (cnt+(56.617)+(cnt));
float xZzAjBHRXmRNQOqR = (float) (cnt*(tcb->m_segmentSize)*(68.547));
if (LApaVBvCdjzhOuuk != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (9.248+(cnt)+(36.816)+(tcb->m_segmentSize)+(11.618)+(LApaVBvCdjzhOuuk)+(85.059)+(73.733));
	tcb->m_cWnd = (int) (69.712*(xZzAjBHRXmRNQOqR)*(13.102)*(52.965)*(92.52)*(54.852)*(75.14));

} else {
	tcb->m_ssThresh = (int) ((tcb->m_cWnd*(81.304)*(73.114)*(38.468))/4.701);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= segmentsAcked) {
	LApaVBvCdjzhOuuk = (int) (16.3+(70.093)+(6.618)+(4.728)+(tcb->m_cWnd)+(xZzAjBHRXmRNQOqR)+(18.86)+(92.738));
	cnt = (int) (31.928-(segmentsAcked)-(1.171)-(1.191)-(97.694)-(54.159)-(15.013));

} else {
	LApaVBvCdjzhOuuk = (int) (34.729-(34.917)-(xZzAjBHRXmRNQOqR));
	LApaVBvCdjzhOuuk = (int) ((((xZzAjBHRXmRNQOqR*(72.313)*(79.11)*(28.51)))+(0.1)+((segmentsAcked-(95.432)-(24.362)-(26.77)-(95.846)-(xZzAjBHRXmRNQOqR)))+((LApaVBvCdjzhOuuk+(75.132)+(19.291)))+(61.086)+(0.1))/((12.783)));

}
float siXjhvaHgcRssJBe = (float) (tcb->m_segmentSize*(cnt)*(tcb->m_segmentSize)*(60.61)*(tcb->m_cWnd));
if (tcb->m_ssThresh <= segmentsAcked) {
	cnt = (int) ((tcb->m_cWnd+(90.392)+(82.424)+(60.401)+(86.221)+(20.586))/14.94);
	ReduceCwnd (tcb);
	siXjhvaHgcRssJBe = (float) (((76.22)+(0.1)+((67.1-(93.691)-(60.915)-(LApaVBvCdjzhOuuk)-(52.423)-(41.975)-(85.404)-(61.857)-(33.564)))+((74.78-(55.267)-(21.739)-(74.133)-(tcb->m_cWnd)-(44.825)-(13.775)))+((75.268*(65.891)*(59.918)*(34.419)*(8.118)*(68.143)*(40.898)*(39.299)))+(39.984))/((0.1)+(60.812)));

} else {
	cnt = (int) (LApaVBvCdjzhOuuk-(31.951)-(7.573)-(71.331)-(19.572)-(66.309)-(74.883));
	xZzAjBHRXmRNQOqR = (float) (segmentsAcked*(tcb->m_cWnd));

}
