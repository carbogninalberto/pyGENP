float kpwafNkWBjBlbbuz = (float) (7.708+(54.762)+(40.213)+(80.904)+(-63.833)+(-31.622)+(-23.45)+(42.397)+(-24.611));
int taSbqywLwQaKGICe = (int) (46.424*(19.623)*(-17.158));
int FGgjHwpfIkNDEEry = (int) (-21.424*(-86.09)*(-15.248)*(-49.147)*(8.739)*(-48.959));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-98.371*(80.026)*(-72.355)*(27.332)*(-66.112));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (52.856*(-35.39)*(-76.902)*(-32.1)*(55.055)*(86.682));
tcb->m_cWnd = (int) (51.082*(62.268)*(-99.981)*(-32.139)*(-97.541));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-87.318*(-12.704)*(38.267)*(-78.779)*(98.199)*(22.839));
