int aAeEZdoguFVFGtKZ = (int) (78.49+(69.813)+(80.676)+(86.221)+(tcb->m_ssThresh)+(47.082)+(88.4)+(66.814)+(cnt));
if (tcb->m_cWnd < aAeEZdoguFVFGtKZ) {
	segmentsAcked = (int) (76.989*(58.425)*(86.174)*(86.558)*(99.51)*(51.348));
	segmentsAcked = (int) (aAeEZdoguFVFGtKZ+(31.958)+(75.896)+(segmentsAcked)+(55.198)+(44.675)+(45.172)+(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (1.556/4.317);
	cnt = (int) (27.49-(47.882)-(58.174)-(aAeEZdoguFVFGtKZ)-(cnt));

}
int TgJxDUscrhQzlcOa = (int) (47.542-(9.57)-(1.674)-(64.453)-(6.254)-(tcb->m_segmentSize)-(45.335));
if (tcb->m_ssThresh < TgJxDUscrhQzlcOa) {
	TgJxDUscrhQzlcOa = (int) (23.516*(cnt)*(aAeEZdoguFVFGtKZ)*(80.42));
	tcb->m_segmentSize = (int) (((51.471)+(67.919)+(50.776)+(88.004)+(0.1))/((95.645)));

} else {
	TgJxDUscrhQzlcOa = (int) (94.185*(16.553)*(36.311)*(15.285));

}
TgJxDUscrhQzlcOa = (int) (84.476-(24.294)-(33.241)-(7.878)-(93.965)-(tcb->m_segmentSize)-(55.582)-(5.184)-(tcb->m_ssThresh));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (57.913*(74.455)*(39.143)*(3.288)*(aAeEZdoguFVFGtKZ)*(aAeEZdoguFVFGtKZ)*(89.185));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (67.939-(aAeEZdoguFVFGtKZ)-(95.826)-(27.941)-(93.926)-(TgJxDUscrhQzlcOa)-(47.319)-(62.706));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_segmentSize) {
	cnt = (int) (((41.998)+(93.393)+(0.1)+(0.1))/((0.1)+(92.58)));

} else {
	cnt = (int) (93.061+(21.943));
	tcb->m_cWnd = (int) ((72.178*(53.18)*(81.921)*(72.299)*(54.077)*(42.959)*(21.822)*(17.094))/65.61);
	TgJxDUscrhQzlcOa = (int) (53.935+(tcb->m_segmentSize)+(14.912)+(67.546)+(44.533)+(88.387)+(20.248)+(16.416)+(9.925));

}
ReduceCwnd (tcb);
