float kpwafNkWBjBlbbuz = (float) (-77.467+(92.07)+(-36.588)+(-65.71)+(33.875)+(71.046)+(-60.476)+(-18.79)+(54.318));
int taSbqywLwQaKGICe = (int) (72.351*(80.347)*(-37.031));
int FGgjHwpfIkNDEEry = (int) (-32.39*(-32.693)*(86.291)*(0.664)*(-5.882)*(-34.36));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-7.359*(-98.2)*(-83.432)*(34.838)*(-4.338));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (59.294*(16.329)*(-89.74)*(9.415)*(16.436)*(16.757));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-28.871*(45.448)*(44.171)*(1.049)*(45.111)*(43.441));
segmentsAcked = (int) (-60.152*(-21.132)*(97.445)*(-49.686)*(10.315)*(-84.764));
segmentsAcked = (int) (19.023*(12.752)*(2.587)*(38.366)*(-31.532)*(-13.839));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-68.796*(65.947)*(-58.686)*(-59.555)*(-48.843));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-10.707*(44.086)*(70.232)*(26.094)*(-29.157)*(-79.804));
segmentsAcked = (int) (77.304*(1.453)*(-58.031)*(21.221)*(39.17)*(94.255));
segmentsAcked = (int) (17.033*(-35.128)*(-80.514)*(-68.938)*(56.435)*(6.342));
tcb->m_cWnd = (int) (54.086*(-14.82)*(80.854)*(57.47)*(-52.541));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (54.323*(-42.662)*(55.984)*(66.779)*(53.532)*(67.193));
