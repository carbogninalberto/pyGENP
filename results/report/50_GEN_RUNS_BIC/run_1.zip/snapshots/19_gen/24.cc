if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (50.586-(36.897)-(tcb->m_cWnd)-(11.834)-(62.292)-(1.501));
	cnt = (int) (((82.114)+(0.1)+(89.865)+(0.1)+(38.089)+(80.797))/((0.1)+(67.685)+(0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (49.187-(37.194)-(25.001)-(cnt)-(62.034));
	ReduceCwnd (tcb);

}
cnt = (int) (56.974+(segmentsAcked)+(45.607)+(11.939)+(67.598));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
