if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int wmcrfwnAuOzGvMHM = (int) 95.881;
segmentsAcked = (int) (-41.801-(81.614)-(40.932)-(72.294)-(-30.236));
