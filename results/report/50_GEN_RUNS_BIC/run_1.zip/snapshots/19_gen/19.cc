ReduceCwnd (tcb);
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (71.979-(25.403)-(41.434)-(segmentsAcked)-(tcb->m_cWnd)-(46.136)-(5.91));

} else {
	tcb->m_cWnd = (int) ((tcb->m_cWnd+(65.671)+(tcb->m_ssThresh)+(63.17)+(39.942)+(77.733))/30.578);
	cnt = (int) (83.275+(12.805)+(27.509)+(90.337)+(92.66)+(45.396)+(14.372)+(12.521)+(35.83));
	tcb->m_ssThresh = (int) (0.1/0.1);

}
tcb->m_cWnd = (int) (70.187/90.016);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (tcb->m_ssThresh-(94.751));
int AdKAxnCqiTqCDySQ = (int) (tcb->m_ssThresh*(29.848)*(87.819)*(34.184));
