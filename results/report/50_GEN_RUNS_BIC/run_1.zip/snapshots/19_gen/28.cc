ReduceCwnd (tcb);
float fMQuHdzMZsFjPzDf = (float) (32.402+(64.106)+(tcb->m_segmentSize)+(91.09)+(92.719)+(86.147)+(57.333));
tcb->m_ssThresh = (int) (fMQuHdzMZsFjPzDf-(19.938)-(17.063)-(12.923));
segmentsAcked = (int) (((0.1)+((84.024+(tcb->m_ssThresh)+(tcb->m_cWnd)))+((31.807-(52.525)-(64.215)-(30.344)))+(0.1)+((55.742*(fMQuHdzMZsFjPzDf)*(10.404)*(51.298)))+(94.577)+(40.66))/((90.818)));
ReduceCwnd (tcb);
int shAGtomzzYTFogbu = (int) (((24.358)+(84.942)+(0.1)+(0.1))/((53.328)+(0.1)));
if (cnt > cnt) {
	shAGtomzzYTFogbu = (int) (((91.113)+((93.265-(48.57)-(segmentsAcked)-(9.422)-(shAGtomzzYTFogbu)-(83.143)-(3.374)-(50.235)))+(0.1)+(0.1)+(0.1)+(40.423)+(0.1))/((3.532)+(85.334)));
	tcb->m_segmentSize = (int) (96.764-(tcb->m_ssThresh)-(93.622)-(cnt)-(39.729));

} else {
	shAGtomzzYTFogbu = (int) (29.279-(0.917)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(89.249)-(5.447)-(26.028)-(97.498));

}
