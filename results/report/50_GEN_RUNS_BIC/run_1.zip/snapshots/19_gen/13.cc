float kpwafNkWBjBlbbuz = (float) (-87.594+(-69.871)+(40.447)+(4.848)+(42.776)+(-7.577)+(-17.159)+(93.692)+(-30.688));
int taSbqywLwQaKGICe = (int) (-34.115*(-74.823)*(13.67));
int FGgjHwpfIkNDEEry = (int) (74.059*(-53.338)*(64.655)*(69.4)*(70.111)*(48.969));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (69.01*(66.948)*(-61.023)*(21.493)*(-42.687));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-64.092*(-12.994)*(-44.248)*(-47.159)*(25.294));
segmentsAcked = (int) (43.833*(91.669)*(-84.518)*(56.073)*(-48.034)*(-35.272));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (41.415*(75.55)*(93.724)*(-85.917)*(-24.795)*(-71.75));
