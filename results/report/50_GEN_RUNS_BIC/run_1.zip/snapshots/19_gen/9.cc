if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int FGgjHwpfIkNDEEry = (int) (75.096*(-18.891)*(-33.917)*(-46.257)*(-74.715)*(-49.636));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int taSbqywLwQaKGICe = (int) (-79.999*(80.942)*(-97.304));
tcb->m_cWnd = (int) (99.365*(-56.835)*(-93.644)*(-63.777)*(-7.516));
float kpwafNkWBjBlbbuz = (float) (42.075+(-10.596)+(-36.277)+(4.563)+(-53.221)+(7.55)+(55.942)+(1.38)+(-74.502));
tcb->m_cWnd = (int) (-62.787*(1.695)*(26.489)*(-52.498)*(59.531));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-27.754*(-18.369)*(-66.346)*(38.674)*(-73.63)*(60.438));
segmentsAcked = (int) (12.839*(62.493)*(-76.696)*(-31.708)*(-21.661)*(58.679));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (18.766*(57.792)*(-90.472)*(-25.677)*(78.544)*(-70.919));
segmentsAcked = (int) (40.765*(97.657)*(-61.651)*(30.866)*(66.982)*(-15.437));
