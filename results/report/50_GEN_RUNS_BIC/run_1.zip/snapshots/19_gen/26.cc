if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (45.232+(8.808));
float OTCmmxHWxGTrYsIQ = (float) (18.2+(tcb->m_ssThresh)+(8.988)+(tcb->m_segmentSize)+(83.884)+(23.736)+(63.447));
ReduceCwnd (tcb);
cnt = (int) (84.146*(34.484)*(9.484)*(tcb->m_cWnd)*(51.328)*(85.797)*(12.176));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (12.975/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (73.343*(54.771)*(67.385)*(94.615)*(1.196)*(27.775)*(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (72.64+(cnt)+(69.561)+(54.715)+(74.898)+(segmentsAcked));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (61.35+(33.893)+(segmentsAcked)+(73.862)+(93.988));
