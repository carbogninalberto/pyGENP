tcb->m_cWnd = (int) (-37.491*(-87.928)*(16.731)*(91.072)*(-23.308)*(3.955)*(-4.107)*(43.544)*(-61.902));
tcb->m_cWnd = (int) (-28.251*(78.322)*(-70.727)*(-97.548)*(-15.478)*(60.746)*(4.53)*(13.504));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (54.298*(51.211)*(89.08)*(84.985)*(73.864)*(-66.173)*(41.147)*(42.369));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
