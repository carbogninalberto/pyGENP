float ScpsQYObVPtCEbVO = (float) (-34.811-(-8.778)-(67.817)-(-42.429)-(11.291)-(61.918)-(87.547)-(-94.059));
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (ScpsQYObVPtCEbVO-(45.928));

} else {
	tcb->m_cWnd = (int) (24.768+(74.659)+(72.834)+(26.663));
	ScpsQYObVPtCEbVO = (float) (15.406*(18.836)*(44.73));
	tcb->m_segmentSize = (int) (76.677-(50.481));

}
int kfeXEGlYefstTpJy = (int) (-20.662+(88.48)+(68.746)+(-26.425)+(-72.319)+(-53.343)+(80.149)+(-36.931)+(53.541));
