tcb->m_cWnd = (int) (52.521+(segmentsAcked)+(47.855)+(4.245)+(11.173)+(38.052)+(tcb->m_cWnd)+(48.304)+(13.77));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) (43.576-(61.65)-(tcb->m_cWnd)-(3.767)-(17.403)-(tcb->m_segmentSize)-(cnt)-(24.875));
	ReduceCwnd (tcb);
	cnt = (int) (41.067*(44.806)*(60.992)*(51.546));

} else {
	segmentsAcked = (int) (segmentsAcked*(67.033)*(20.235)*(18.334)*(75.297)*(segmentsAcked)*(77.174)*(tcb->m_cWnd)*(70.916));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (5.037+(tcb->m_segmentSize)+(32.226)+(32.088)+(34.574));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (16.076-(68.613)-(94.668)-(19.954)-(tcb->m_segmentSize)-(92.882));
	tcb->m_cWnd = (int) (42.835*(tcb->m_ssThresh)*(25.688)*(segmentsAcked)*(47.458)*(18.826)*(72.562));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(tcb->m_ssThresh)+(68.678)+(85.343)+(tcb->m_cWnd));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (29.596*(95.043)*(49.02)*(93.821)*(72.239)*(2.191)*(40.359)*(40.701));
tcb->m_segmentSize = (int) (31.912*(67.85)*(72.605)*(tcb->m_segmentSize)*(76.106));
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(27.285)*(78.88)*(tcb->m_segmentSize)*(80.832)*(8.05));

} else {
	tcb->m_segmentSize = (int) (34.992-(87.181)-(62.093)-(59.283));
	tcb->m_cWnd = (int) (22.003-(11.485)-(39.057));

}
