float kpwafNkWBjBlbbuz = (float) (-55.968+(-43.503)+(-6.869)+(-76.423)+(-62.836)+(-47.802)+(-94.181)+(21.569)+(35.145));
int taSbqywLwQaKGICe = (int) (-72.15*(-96.683)*(45.562));
int FGgjHwpfIkNDEEry = (int) (99.894*(1.827)*(81.647)*(-55.046)*(2.8)*(-86.603));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (47.347*(-42.109)*(37.372)*(75.233)*(0.452));
tcb->m_cWnd = (int) (-86.484*(86.612)*(97.734)*(32.001)*(53.442));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-95.118*(96.865)*(5.996)*(99.258)*(-84.795)*(49.215));
segmentsAcked = (int) (-47.163*(-1.767)*(-33.398)*(-65.495)*(55.953)*(67.417));
