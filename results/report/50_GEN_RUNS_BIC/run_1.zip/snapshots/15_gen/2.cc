float kpwafNkWBjBlbbuz = (float) (-58.807+(-64.636)+(20.373)+(18.687)+(-21.333)+(-25.109)+(-44.974)+(-36.817)+(-53.289));
int taSbqywLwQaKGICe = (int) (-61.917*(-48.686)*(58.763));
int FGgjHwpfIkNDEEry = (int) (28.537*(76.819)*(-2.928)*(35.936)*(-99.434)*(-48.219));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-17.376*(35.896)*(0.224)*(94.832)*(20.969));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-25.063*(-81.732)*(-78.189)*(-96.792)*(-53.584)*(91.635));
tcb->m_cWnd = (int) (-45.285*(-7.91)*(61.29)*(18.189)*(76.595));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (67.405*(-78.651)*(67.288)*(-73.187)*(-90.188)*(12.0));
