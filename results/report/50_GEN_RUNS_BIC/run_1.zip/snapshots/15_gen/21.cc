tcb->m_segmentSize = (int) (47.593-(tcb->m_segmentSize)-(56.032)-(17.774)-(cnt)-(segmentsAcked));
float thJvIVsjAoyxqVMj = (float) (tcb->m_segmentSize*(99.051)*(95.99)*(19.755));
cnt = (int) (52.057-(82.556)-(61.182)-(38.633)-(40.511)-(segmentsAcked)-(segmentsAcked)-(90.698));
tcb->m_ssThresh = (int) (0.1/0.1);
tcb->m_cWnd = (int) (0.1/31.592);
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (28.004+(75.475)+(98.209)+(61.979)+(71.454)+(36.223)+(4.945)+(79.496)+(cnt));

} else {
	tcb->m_segmentSize = (int) (37.938-(0.491)-(72.01)-(51.784)-(thJvIVsjAoyxqVMj));
	segmentsAcked = (int) (33.292*(71.611)*(0.749)*(98.622)*(50.115)*(0.715)*(37.817)*(82.7));

}
ReduceCwnd (tcb);
