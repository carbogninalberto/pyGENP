cnt = (int) (25.695-(tcb->m_segmentSize)-(60.138)-(60.261));
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	cnt = (int) (85.982+(46.762)+(segmentsAcked)+(24.387)+(66.454));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (segmentsAcked+(57.302)+(54.14)+(tcb->m_ssThresh)+(18.8));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
float aBvHyhSruMUhXzej = (float) (51.979*(tcb->m_segmentSize)*(segmentsAcked));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (22.07/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (63.587+(20.281)+(tcb->m_ssThresh));
	cnt = (int) (57.51*(38.283)*(74.14)*(tcb->m_ssThresh)*(78.113));
	tcb->m_segmentSize = (int) (97.371*(31.789)*(15.855)*(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(aBvHyhSruMUhXzej)*(39.776));
	tcb->m_ssThresh = (int) (segmentsAcked+(39.176)+(73.647)+(26.875)+(24.244)+(67.093)+(aBvHyhSruMUhXzej)+(48.719)+(28.823));
	ReduceCwnd (tcb);

}
