if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (43.062-(25.116)-(12.851)-(80.937));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (5.771-(70.548)-(50.537)-(19.441)-(2.989)-(tcb->m_segmentSize)-(segmentsAcked)-(20.429));

}
float lzKvmJMwWUvihcfL = (float) (-41.109+(-37.987)+(-60.639)+(-39.899)+(-87.582)+(-15.976)+(-90.959));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
