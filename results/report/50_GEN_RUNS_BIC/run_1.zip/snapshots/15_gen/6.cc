if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	segmentsAcked = (int) (23.021-(70.558)-(7.67)-(25.96));

} else {
	segmentsAcked = (int) (segmentsAcked+(5.859)+(96.513));
	tcb->m_segmentSize = (int) (51.071*(13.764)*(96.616)*(segmentsAcked)*(65.031));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
