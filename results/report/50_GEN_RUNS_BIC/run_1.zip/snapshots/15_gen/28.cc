ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (segmentsAcked-(63.582)-(tcb->m_cWnd)-(86.472)-(91.17));
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (66.209*(32.016)*(8.176)*(87.764));
	segmentsAcked = (int) (((0.1)+((cnt+(47.563)+(segmentsAcked)+(52.138)+(89.108)))+(19.64)+(8.798))/((0.1)+(31.178)));
	tcb->m_cWnd = (int) (((96.359)+(41.789)+(34.215)+(0.1))/((2.222)+(0.1)+(50.016)));

} else {
	tcb->m_cWnd = (int) (66.489*(41.338));
	tcb->m_ssThresh = (int) (((6.941)+(0.1)+(0.1)+(0.1))/((1.779)));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) (((66.325)+(81.872)+(8.837)+(0.1)+(7.335)+(99.873))/((0.1)));
	segmentsAcked = (int) (94.476*(54.152));

} else {
	segmentsAcked = (int) (36.133*(tcb->m_cWnd)*(tcb->m_ssThresh));

}
tcb->m_cWnd = (int) (92.291*(27.591)*(57.135)*(28.954)*(tcb->m_ssThresh)*(27.445)*(tcb->m_ssThresh)*(66.0)*(44.257));
