if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	cnt = (int) (30.67*(tcb->m_cWnd)*(2.711)*(tcb->m_ssThresh)*(50.129)*(75.603)*(10.313)*(32.093)*(57.819));

} else {
	cnt = (int) (65.406+(segmentsAcked)+(tcb->m_segmentSize)+(cnt)+(segmentsAcked)+(tcb->m_cWnd)+(tcb->m_cWnd)+(21.532)+(56.025));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (32.413*(segmentsAcked)*(tcb->m_segmentSize)*(77.726)*(23.834)*(20.481)*(6.477)*(13.288));

}
segmentsAcked = (int) (59.007-(30.496)-(35.964)-(44.398)-(41.398)-(tcb->m_cWnd));
tcb->m_segmentSize = (int) (95.162-(68.779)-(19.497)-(28.239)-(76.457)-(3.198)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(58.772));
if (segmentsAcked < segmentsAcked) {
	cnt = (int) (83.641+(88.92)+(76.042)+(tcb->m_cWnd)+(9.112)+(35.021)+(96.313)+(43.655)+(45.366));

} else {
	cnt = (int) (9.584*(72.833)*(42.88)*(23.972));

}
tcb->m_segmentSize = (int) (73.866+(23.759));
cnt = (int) (46.55+(28.607)+(3.873));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
