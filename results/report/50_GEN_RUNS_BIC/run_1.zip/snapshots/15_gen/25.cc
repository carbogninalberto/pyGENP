ReduceCwnd (tcb);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (31.642-(8.617)-(39.719)-(1.221)-(cnt)-(64.452));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (cnt*(tcb->m_segmentSize)*(cnt)*(87.444)*(cnt)*(22.558)*(10.212)*(55.853));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float TzmRArXnMJHotrjc = (float) (((95.764)+(43.625)+(0.1)+(0.1)+((68.354-(cnt)-(1.972)-(tcb->m_segmentSize)-(11.489)-(8.129)-(13.674)-(tcb->m_ssThresh)))+(0.1))/((0.1)+(0.1)+(0.1)));
