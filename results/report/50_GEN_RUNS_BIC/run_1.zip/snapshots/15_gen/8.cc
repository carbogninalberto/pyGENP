tcb->m_segmentSize = (int) (-58.32/-76.912);
tcb->m_cWnd = (int) (1.712+(-79.993)+(-67.353)+(-30.262)+(-29.625));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
