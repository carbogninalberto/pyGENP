ReduceCwnd (tcb);
tcb->m_cWnd = (int) (71.769-(56.311)-(78.127)-(68.377)-(88.161)-(12.453));
if (tcb->m_cWnd != segmentsAcked) {
	cnt = (int) (69.73*(48.109)*(35.329)*(2.601)*(30.088)*(51.349)*(45.796)*(77.429));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (0.1/45.253);
	tcb->m_cWnd = (int) (93.508+(27.421)+(37.445)+(tcb->m_ssThresh));

}
ReduceCwnd (tcb);
int yxuAoNEqOSVXPEJp = (int) (tcb->m_ssThresh-(36.503)-(50.828)-(67.844));
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_cWnd = (int) (70.747+(segmentsAcked)+(38.684)+(64.825)+(25.363)+(yxuAoNEqOSVXPEJp)+(11.556)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (12.488/0.1);

} else {
	tcb->m_cWnd = (int) (20.295-(71.049)-(48.427)-(segmentsAcked)-(segmentsAcked)-(55.985)-(tcb->m_segmentSize)-(tcb->m_segmentSize));
	segmentsAcked = (int) (39.62*(45.425)*(3.195)*(44.839)*(segmentsAcked));
	segmentsAcked = (int) (39.369+(54.046)+(40.026));

}
