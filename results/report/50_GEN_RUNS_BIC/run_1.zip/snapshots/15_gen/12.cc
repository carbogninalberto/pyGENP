if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-39.915-(97.927)-(95.785)-(-78.913)-(-85.898)-(90.309)-(-97.058)-(-58.202)-(43.339));
segmentsAcked = (int) (-97.225+(-71.597)+(-21.747));
tcb->m_segmentSize = (int) (-11.18-(57.781)-(16.118)-(-25.598));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
