int wmcrfwnAuOzGvMHM = (int) 95.881;
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (64.625-(-15.754)-(81.427)-(-83.858)-(61.317));
