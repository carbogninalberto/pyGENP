float kpwafNkWBjBlbbuz = (float) (-49.59+(-0.938)+(44.124)+(34.789)+(-91.303)+(62.67)+(34.313)+(-82.886)+(-83.906));
int taSbqywLwQaKGICe = (int) (-13.959*(-77.13)*(-15.944));
int FGgjHwpfIkNDEEry = (int) (-96.686*(59.012)*(72.202)*(-21.483)*(59.593)*(-95.897));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-99.01*(80.707)*(-21.781)*(96.471)*(55.041));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-25.329*(97.365)*(-41.442)*(-9.753)*(89.519)*(-59.466));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-72.397*(48.493)*(76.614)*(86.605)*(-33.08)*(-2.567));
