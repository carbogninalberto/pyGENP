int fosOvHsaAgNhKIqh = (int) (42.714-(-18.57)-(-42.011)-(-97.444)-(96.95)-(-5.725)-(79.462)-(-19.504)-(-15.593));
ReduceCwnd (tcb);
segmentsAcked = (int) (-3.771/-25.993);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
