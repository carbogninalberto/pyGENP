if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (51.29*(-14.296)*(-78.883)*(94.972)*(3.163)*(9.551)*(62.351)*(-67.786)*(-24.542));
tcb->m_cWnd = (int) (-25.891*(-6.324)*(61.042)*(2.837)*(85.878)*(-90.847)*(13.402)*(90.657));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-80.509*(-78.335)*(-88.957)*(22.591)*(81.455)*(51.431)*(-96.015)*(-84.957));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
