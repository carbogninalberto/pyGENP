int kfeXEGlYefstTpJy = (int) (7.3+(41.788)+(67.024)+(18.13)+(48.06)+(-40.989)+(-81.448)+(29.058)+(53.0));
float ScpsQYObVPtCEbVO = (float) (-3.628-(86.129)-(-33.512)-(-58.725)-(-12.696)-(-74.762)-(-54.529)-(35.862));
ScpsQYObVPtCEbVO = (float) (25.6/-32.838);
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (ScpsQYObVPtCEbVO-(45.928));

} else {
	tcb->m_cWnd = (int) (24.768+(74.659)+(72.834)+(26.663));
	ScpsQYObVPtCEbVO = (float) (15.406*(18.836)*(44.73));
	tcb->m_segmentSize = (int) (76.677-(50.481));

}
