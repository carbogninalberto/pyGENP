float kpwafNkWBjBlbbuz = (float) (47.894+(-3.655)+(-60.428)+(-17.414)+(94.831)+(-77.428)+(48.867)+(63.907)+(-57.822));
int taSbqywLwQaKGICe = (int) (-39.382*(99.376)*(-29.05));
int FGgjHwpfIkNDEEry = (int) (2.724*(-48.328)*(86.96)*(60.583)*(-5.915)*(-55.144));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (15.504*(-57.887)*(-92.676)*(18.193)*(-52.394));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-77.512*(33.988)*(-15.975)*(1.614)*(16.829)*(-18.584));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-79.832*(-53.902)*(81.451)*(-42.749)*(-21.343));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (74.755*(-39.107)*(5.875)*(48.195)*(-41.737)*(-85.099));
