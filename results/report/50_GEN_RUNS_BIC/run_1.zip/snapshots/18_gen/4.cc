if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (3.177*(-77.085)*(18.337)*(-46.404)*(72.962)*(-98.757)*(95.723)*(-77.438));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
