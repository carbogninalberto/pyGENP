ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (86.031*(42.498)*(-55.529)*(-86.146)*(12.183)*(-24.461)*(-32.132)*(49.369)*(-72.254));
tcb->m_cWnd = (int) (-50.131*(0.431)*(75.672)*(95.738)*(62.068)*(29.729)*(52.184)*(-36.555));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-68.395*(12.196)*(-47.142)*(79.678)*(-31.58)*(56.925)*(-67.494)*(45.922));
tcb->m_cWnd = (int) (-54.716*(-95.566)*(34.384)*(2.609)*(94.692)*(34.878)*(31.952)*(86.856)*(26.922));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-55.752*(26.325)*(98.726)*(18.09)*(-41.016)*(-83.916)*(94.408)*(-54.353));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-32.629*(56.164)*(26.519)*(67.929)*(-17.177)*(1.061)*(-83.996)*(70.203));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
