float kpwafNkWBjBlbbuz = (float) (62.866+(71.322)+(-68.388)+(94.183)+(-17.794)+(-20.258)+(-5.323)+(99.169)+(72.291));
int taSbqywLwQaKGICe = (int) (-42.407*(6.261)*(-61.425));
int FGgjHwpfIkNDEEry = (int) (71.309*(55.773)*(10.885)*(-65.021)*(-88.788)*(39.139));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-55.217*(47.915)*(-66.141)*(-50.157)*(22.236));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-66.151*(8.941)*(39.626)*(82.495)*(-14.79)*(47.236));
segmentsAcked = (int) (63.466*(-56.16)*(49.664)*(-46.612)*(-55.854)*(-19.245));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-83.548*(-92.705)*(24.133)*(-31.715)*(2.898)*(-34.283));
segmentsAcked = (int) (6.224*(-82.728)*(55.106)*(42.624)*(-94.01)*(-85.977));
