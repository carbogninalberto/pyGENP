int fosOvHsaAgNhKIqh = (int) (26.955-(-14.768)-(-63.177)-(-86.682)-(45.543)-(8.562)-(-21.508)-(88.831)-(-72.557));
ReduceCwnd (tcb);
segmentsAcked = (int) (20.095/-39.319);
segmentsAcked = (int) (-54.931/31.811);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
