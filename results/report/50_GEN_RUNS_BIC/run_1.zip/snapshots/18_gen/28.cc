int fosOvHsaAgNhKIqh = (int) (89.609-(-83.844)-(38.346)-(9.905)-(2.77)-(25.889)-(47.089)-(-28.173)-(-65.523));
ReduceCwnd (tcb);
segmentsAcked = (int) (29.073/71.879);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
