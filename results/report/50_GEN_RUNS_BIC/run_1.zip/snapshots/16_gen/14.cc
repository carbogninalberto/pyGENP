if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (cnt*(11.206)*(77.537)*(5.433)*(84.334));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(97.13)*(93.549)*(65.411)*(66.833)*(tcb->m_cWnd)*(71.147)*(99.419)*(24.892));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (62.172-(43.897));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (23.444-(segmentsAcked)-(17.528)-(71.052)-(43.342)-(98.396));
tcb->m_ssThresh = (int) (((95.79)+(0.1)+(61.933)+(2.561)+(65.832))/((0.1)+(0.1)));
ReduceCwnd (tcb);
segmentsAcked = (int) (57.552*(75.154)*(61.829)*(81.91)*(tcb->m_segmentSize)*(33.275)*(29.659)*(84.828)*(68.739));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
