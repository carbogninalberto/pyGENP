if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (67.343+(57.585)+(27.196)+(52.319)+(95.884)+(98.497)+(27.041)+(91.815)+(68.558));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (82.301-(96.713)-(50.833)-(7.05)-(89.18)-(63.648));
if (tcb->m_cWnd < tcb->m_segmentSize) {
	cnt = (int) (68.961+(31.925)+(28.645)+(segmentsAcked)+(60.706)+(tcb->m_cWnd));
	cnt = (int) (59.847/0.1);
	segmentsAcked = (int) (((89.458)+(0.1)+(20.593)+((58.442+(71.56)+(87.009)))+(0.1)+(3.162)+(85.567)+(15.81))/((18.927)));

} else {
	cnt = (int) (60.989-(82.164)-(36.732)-(tcb->m_segmentSize)-(55.558));

}
cnt = (int) (0.1/87.603);
