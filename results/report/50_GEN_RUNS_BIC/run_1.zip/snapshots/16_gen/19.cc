int ClnXMIHDboBwlQEK = (int) ((tcb->m_cWnd*(48.928)*(26.962)*(4.87))/56.276);
if (tcb->m_cWnd < ClnXMIHDboBwlQEK) {
	ClnXMIHDboBwlQEK = (int) (91.1-(12.305)-(91.524)-(2.453));

} else {
	ClnXMIHDboBwlQEK = (int) (66.604+(61.678)+(12.764)+(67.077)+(86.394)+(22.785)+(48.651));
	ClnXMIHDboBwlQEK = (int) (((75.573)+(0.1)+(0.1)+(38.476))/((18.343)));
	cnt = (int) (0.1/0.1);

}
if (ClnXMIHDboBwlQEK >= segmentsAcked) {
	segmentsAcked = (int) (54.097/0.1);

} else {
	segmentsAcked = (int) ((2.086+(99.815)+(segmentsAcked)+(8.576))/0.1);

}
if (tcb->m_cWnd > cnt) {
	tcb->m_segmentSize = (int) (((46.487)+(12.156)+((3.735+(41.537)+(11.79)+(ClnXMIHDboBwlQEK)+(66.777)+(79.801)))+(0.1))/((70.038)+(0.1)+(74.307)));

} else {
	tcb->m_segmentSize = (int) (0.1/62.693);
	tcb->m_cWnd = (int) (31.293+(78.611)+(55.089)+(52.826)+(36.381)+(12.604)+(87.348)+(3.74)+(45.424));

}
int rEGwJBzpqIgNupzp = (int) (8.065/80.465);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
rEGwJBzpqIgNupzp = (int) ((81.652-(tcb->m_segmentSize)-(rEGwJBzpqIgNupzp)-(98.368))/0.1);
