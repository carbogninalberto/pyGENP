ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (52.293*(5.816)*(11.816)*(tcb->m_cWnd)*(tcb->m_cWnd));
if (tcb->m_cWnd != cnt) {
	cnt = (int) (tcb->m_cWnd-(61.452)-(tcb->m_segmentSize)-(68.21)-(27.081)-(tcb->m_segmentSize)-(92.361));
	segmentsAcked = (int) (85.147+(94.63)+(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (tcb->m_segmentSize+(10.332)+(tcb->m_ssThresh)+(59.356)+(2.627)+(50.779)+(16.551)+(46.081));

}
segmentsAcked = (int) (61.465+(44.57)+(34.852)+(33.399));
