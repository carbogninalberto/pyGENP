int XxubeBlrLxfolFsv = (int) (-87.966-(-42.216));
tcb->m_cWnd = (int) (-84.495*(48.455)*(14.073)*(13.934)*(98.725)*(20.63)*(-41.4)*(10.294)*(54.735));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (32.434*(-96.287)*(98.173)*(21.459)*(-31.24)*(73.583)*(42.491)*(-25.771));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
