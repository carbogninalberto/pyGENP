if (cnt < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (32.616/0.1);
	cnt = (int) (94.764*(80.268)*(tcb->m_segmentSize)*(1.215)*(40.376)*(52.266)*(9.265)*(71.266)*(32.767));
	cnt = (int) (99.699+(segmentsAcked)+(93.032)+(20.259));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
int UIpMMtzQJxpWBGCU = (int) (29.853+(90.716));
UIpMMtzQJxpWBGCU = (int) (74.122+(UIpMMtzQJxpWBGCU)+(92.335)+(UIpMMtzQJxpWBGCU)+(99.641));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (cnt+(17.497)+(58.593)+(tcb->m_cWnd)+(UIpMMtzQJxpWBGCU)+(81.035)+(69.226)+(0.219));
if (tcb->m_ssThresh < cnt) {
	tcb->m_segmentSize = (int) (27.646-(25.267)-(77.982)-(15.874)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(71.759)-(26.273));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked-(75.106)-(46.747)-(57.413)-(tcb->m_ssThresh)-(96.887));
	tcb->m_cWnd = (int) (cnt+(97.909)+(92.165)+(72.754)+(30.548)+(74.55)+(75.945)+(23.994));
	segmentsAcked = (int) (3.572*(89.437));

}
