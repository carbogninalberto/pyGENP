float cRYmSjLjtRHdbUWE = (float) (78.532/0.1);
int dVYWVbuJEWTJxBfD = (int) (tcb->m_segmentSize*(51.464)*(16.683)*(59.582)*(70.718)*(30.146)*(8.753)*(cnt));
if (cnt != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (74.339+(cnt)+(tcb->m_cWnd)+(23.803)+(59.585)+(26.831)+(cRYmSjLjtRHdbUWE));
	cRYmSjLjtRHdbUWE = (float) (6.324/0.1);
	cnt = (int) (80.5/33.199);

} else {
	tcb->m_segmentSize = (int) (32.696/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(29.265)*(84.988)*(98.639)*(27.87)*(86.006)*(62.072)*(32.842)*(53.436));

}
segmentsAcked = (int) (((0.1)+(95.188)+(0.1)+((32.424*(99.061)*(56.314)*(97.113)))+(22.728))/((0.1)+(0.1)));
cRYmSjLjtRHdbUWE = (float) (26.028*(tcb->m_ssThresh));
