if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (98.947+(13.897)+(tcb->m_ssThresh)+(64.313)+(68.856)+(91.176)+(19.859)+(tcb->m_ssThresh)+(tcb->m_ssThresh));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(92.24));
	tcb->m_segmentSize = (int) (22.06+(90.461)+(18.404)+(segmentsAcked)+(75.821)+(21.901)+(23.392));
	tcb->m_cWnd = (int) (93.666-(3.787)-(79.827));

}
tcb->m_ssThresh = (int) (16.323*(cnt)*(tcb->m_segmentSize)*(75.893));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (65.374*(tcb->m_ssThresh)*(segmentsAcked)*(39.237)*(tcb->m_ssThresh)*(5.627)*(20.631)*(97.305));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (cnt*(64.763)*(13.675));
