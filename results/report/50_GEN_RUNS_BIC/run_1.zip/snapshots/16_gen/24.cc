float GMLjyvcfeFImBNqX = (float) (22.368+(24.038)+(14.515)+(53.829)+(87.118)+(76.399)+(27.666)+(cnt)+(89.861));
if (tcb->m_segmentSize != GMLjyvcfeFImBNqX) {
	tcb->m_ssThresh = (int) (99.283-(11.857));
	tcb->m_segmentSize = (int) (6.122-(46.771)-(20.517)-(81.844)-(33.73)-(73.5)-(43.344)-(51.942));

} else {
	tcb->m_ssThresh = (int) (GMLjyvcfeFImBNqX+(98.511)+(71.252)+(77.116)+(3.502)+(52.853)+(GMLjyvcfeFImBNqX));
	tcb->m_segmentSize = (int) (92.841+(6.639)+(59.246));
	GMLjyvcfeFImBNqX = (float) (49.871/57.292);

}
if (GMLjyvcfeFImBNqX < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (86.457+(59.288)+(7.735)+(5.306)+(9.161)+(46.484)+(0.459)+(80.831)+(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (31.769-(tcb->m_cWnd)-(28.702)-(86.159));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (2.065*(GMLjyvcfeFImBNqX)*(tcb->m_segmentSize)*(33.42)*(23.569));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (GMLjyvcfeFImBNqX > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (12.141-(47.367)-(99.449)-(35.479)-(81.446));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (GMLjyvcfeFImBNqX+(tcb->m_cWnd)+(84.126)+(27.71)+(38.331));
	GMLjyvcfeFImBNqX = (float) (cnt+(13.723)+(tcb->m_cWnd)+(83.156));

}
