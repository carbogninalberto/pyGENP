float thJvIVsjAoyxqVMj = (float) (-6.241*(-18.344)*(87.557)*(67.627));
segmentsAcked = (int) (-76.099+(-53.974)+(-21.197)+(70.633)+(-26.559));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-12.803/-95.924);
