int XxubeBlrLxfolFsv = (int) (4.125-(-51.973));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (66.246*(83.512)*(-78.099)*(92.084)*(30.835)*(96.043)*(-57.259)*(-47.712)*(62.576));
tcb->m_cWnd = (int) (-79.557*(40.751)*(-14.095)*(44.107)*(6.832)*(18.932)*(55.129)*(34.046));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-31.071*(26.799)*(3.755)*(9.308)*(9.345)*(12.004)*(-76.809)*(-27.254));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
