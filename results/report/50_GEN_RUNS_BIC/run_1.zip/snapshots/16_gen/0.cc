float kpwafNkWBjBlbbuz = (float) (-49.512+(-29.558)+(25.899)+(98.577)+(37.67)+(50.407)+(-40.517)+(18.867)+(-2.662));
int taSbqywLwQaKGICe = (int) (77.425*(-3.251)*(0.154));
int FGgjHwpfIkNDEEry = (int) (-85.334*(-49.076)*(-46.402)*(11.614)*(43.85)*(38.916));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-23.724*(-44.497)*(-38.987)*(-63.832)*(-51.519));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-94.597*(-75.944)*(-82.823)*(-76.051)*(-70.727)*(39.634));
