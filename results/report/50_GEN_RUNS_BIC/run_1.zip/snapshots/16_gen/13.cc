float KarngkanBLXMIoPk = (float) (((0.1)+(0.1)+((72.773-(91.522)-(tcb->m_ssThresh)-(88.342)))+(11.077)+(68.239))/((18.93)+(85.286)+(78.993)));
float cbNRmnIVbrhgXzyJ = (float) (0.1/0.1);
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (cnt*(tcb->m_cWnd)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(cbNRmnIVbrhgXzyJ)*(25.53)*(5.93)*(4.604)*(18.23));

} else {
	tcb->m_cWnd = (int) ((((4.663+(75.974)+(tcb->m_segmentSize)+(96.151)+(71.526)))+(16.302)+(0.1)+(0.1)+(39.517))/((0.1)+(0.1)+(0.1)));
	tcb->m_cWnd = (int) (15.579+(9.536)+(99.5));
	tcb->m_ssThresh = (int) (0.1/0.1);

}
KarngkanBLXMIoPk = (float) (93.601/34.846);
tcb->m_segmentSize = (int) (84.79+(72.575)+(92.499)+(cnt)+(tcb->m_ssThresh)+(9.078)+(40.853)+(89.314)+(98.527));
