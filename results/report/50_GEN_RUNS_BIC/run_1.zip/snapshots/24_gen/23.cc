if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (15.046-(27.924)-(tcb->m_cWnd)-(30.479)-(tcb->m_cWnd)-(46.893)-(99.629)-(87.377)-(1.54));
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_ssThresh = (int) (6.192+(62.422));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(0.465)+(58.607));

} else {
	tcb->m_ssThresh = (int) (80.547*(81.997)*(58.172)*(87.886)*(77.964)*(41.207));

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	segmentsAcked = (int) (15.288+(0.632));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (88.262-(70.46)-(tcb->m_ssThresh)-(14.688)-(48.056)-(tcb->m_ssThresh)-(28.533));

} else {
	segmentsAcked = (int) (tcb->m_cWnd-(70.625)-(79.968)-(17.553));
	segmentsAcked = (int) (90.271-(23.026)-(82.05)-(cnt)-(3.72)-(88.082)-(96.681)-(72.903));
	tcb->m_ssThresh = (int) (43.654*(90.644)*(24.188)*(11.635)*(0.363)*(45.991)*(tcb->m_ssThresh)*(27.877)*(52.96));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (19.001+(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (7.609+(91.652)+(83.714)+(tcb->m_segmentSize)+(20.241));
