if (cnt != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (96.67*(75.963)*(63.582)*(17.17));
	cnt = (int) (65.973*(22.192));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(75.174)-(3.205));

}
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (96.954*(88.603)*(cnt)*(tcb->m_cWnd));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (84.193-(32.317));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (tcb->m_ssThresh-(89.026)-(71.202)-(80.936)-(tcb->m_ssThresh)-(83.094)-(26.048)-(49.946));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (10.154/0.1);
if (tcb->m_cWnd == cnt) {
	tcb->m_segmentSize = (int) (38.393+(72.701)+(89.692)+(55.33)+(88.729)+(28.239));
	cnt = (int) (17.187/31.785);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (0.1/91.724);

}
if (segmentsAcked > segmentsAcked) {
	tcb->m_ssThresh = (int) (43.968-(segmentsAcked)-(44.596)-(32.37)-(segmentsAcked));
	segmentsAcked = (int) (tcb->m_ssThresh-(62.405)-(tcb->m_ssThresh)-(cnt)-(tcb->m_cWnd)-(74.047)-(58.49)-(44.687));
	cnt = (int) ((82.793*(69.908)*(41.039)*(50.754)*(64.359)*(0.14)*(3.118)*(0.532)*(tcb->m_segmentSize))/(30.208+(19.739)+(72.171)+(83.062)+(9.322)));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked*(82.622));

}
if (tcb->m_segmentSize >= segmentsAcked) {
	cnt = (int) (79.294+(71.039)+(55.056)+(1.844)+(94.454)+(19.559)+(tcb->m_ssThresh)+(tcb->m_ssThresh));
	segmentsAcked = (int) (67.772-(tcb->m_segmentSize)-(20.837)-(97.094));

} else {
	cnt = (int) (53.322/0.1);
	ReduceCwnd (tcb);

}
