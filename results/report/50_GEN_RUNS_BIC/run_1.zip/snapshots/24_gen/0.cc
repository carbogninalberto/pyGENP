int fosOvHsaAgNhKIqh = (int) (-80.574-(-5.937)-(37.68)-(23.294)-(94.419)-(-85.481)-(-7.804)-(-63.17)-(25.046));
ReduceCwnd (tcb);
segmentsAcked = (int) (-33.722/-38.123);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
