tcb->m_segmentSize = (int) (24.794*(83.507)*(36.257)*(25.648));
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (47.115*(86.579)*(62.088)*(42.494)*(57.658)*(88.449)*(26.584));
	tcb->m_ssThresh = (int) (segmentsAcked-(91.414)-(11.782)-(99.112)-(9.187)-(67.773)-(tcb->m_ssThresh)-(68.091));

} else {
	tcb->m_ssThresh = (int) (71.25/78.579);
	tcb->m_ssThresh = (int) (35.631*(81.596)*(16.422)*(6.111)*(23.992)*(tcb->m_cWnd)*(28.292)*(95.501)*(cnt));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (1.32+(60.143)+(19.811)+(tcb->m_segmentSize)+(18.557)+(80.127)+(48.865)+(56.754));
ReduceCwnd (tcb);
