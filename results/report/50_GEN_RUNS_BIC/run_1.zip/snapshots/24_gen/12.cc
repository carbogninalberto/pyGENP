float ocVwlBrXZzMAnHHN = (float) 54.317;
ocVwlBrXZzMAnHHN = (float) (16.998+(-32.867));
tcb->m_cWnd = (int) (15.162*(30.988)*(58.924)*(-47.597));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
