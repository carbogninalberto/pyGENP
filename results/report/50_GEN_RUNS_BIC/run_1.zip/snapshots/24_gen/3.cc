float RYhocZiavajVWWYa = (float) (18.254*(30.21)*(-94.356)*(96.01)*(55.659));
