int fosOvHsaAgNhKIqh = (int) (71.457-(89.675)-(-74.839)-(-62.95)-(-15.754)-(-27.966)-(-64.871)-(76.897)-(-17.612));
ReduceCwnd (tcb);
segmentsAcked = (int) (-41.606/27.094);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (62.566/91.086);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
