float ocVwlBrXZzMAnHHN = (float) 17.009;
ocVwlBrXZzMAnHHN = (float) (-21.946+(-23.05));
tcb->m_cWnd = (int) (-73.145*(-25.077)*(-74.141)*(77.198));
