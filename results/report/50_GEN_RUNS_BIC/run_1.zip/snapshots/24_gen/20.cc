if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) ((((51.474+(68.209)+(2.296)+(80.402)+(23.089)))+((94.87*(96.828)*(87.161)*(cnt)*(14.491)))+((6.301+(segmentsAcked)+(57.478)+(24.811)))+(0.1)+(0.1)+((55.53-(65.78)))+(37.183))/((44.144)+(26.222)));
	tcb->m_ssThresh = (int) (39.618-(45.725)-(44.043)-(segmentsAcked)-(48.495)-(94.564));
	tcb->m_segmentSize = (int) (12.366*(30.067));

} else {
	tcb->m_ssThresh = (int) (19.715*(segmentsAcked)*(8.643)*(41.83)*(21.702)*(42.905)*(tcb->m_segmentSize)*(10.282));
	segmentsAcked = (int) (70.465+(tcb->m_cWnd)+(97.72)+(47.517)+(99.049)+(64.917)+(tcb->m_ssThresh));
	segmentsAcked = (int) (19.304+(36.999)+(12.278)+(4.885)+(4.434));

}
if (cnt == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(81.471)-(27.906)-(57.312)-(segmentsAcked)-(2.475)-(tcb->m_ssThresh)-(77.18)-(55.948));
	segmentsAcked = (int) (55.526-(37.219)-(90.284));
	tcb->m_segmentSize = (int) (12.998+(61.36)+(4.119)+(14.763));

} else {
	tcb->m_ssThresh = (int) (41.061*(30.827)*(tcb->m_segmentSize)*(87.478)*(13.013)*(22.63)*(64.891)*(81.85)*(78.258));
	cnt = (int) (50.754-(cnt)-(7.147)-(tcb->m_segmentSize)-(segmentsAcked)-(15.088)-(17.401));

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/75.782);

} else {
	tcb->m_ssThresh = (int) (96.006-(82.278)-(76.066));
	tcb->m_cWnd = (int) (((0.1)+(9.703)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(47.236)));
	cnt = (int) ((((segmentsAcked-(31.695)-(2.492)))+(90.822)+((94.491-(46.499)-(96.727)-(36.297)-(19.728)))+(0.1))/((24.065)+(0.1)+(0.1)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (10.927/0.1);
