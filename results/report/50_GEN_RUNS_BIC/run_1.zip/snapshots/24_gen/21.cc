ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_cWnd <= cnt) {
	segmentsAcked = (int) (50.232+(tcb->m_segmentSize));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (0.1/41.338);
	segmentsAcked = (int) (69.781-(48.873)-(27.152)-(94.217)-(60.963));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (41.888-(segmentsAcked)-(tcb->m_segmentSize)-(29.892)-(segmentsAcked)-(84.942)-(86.569));

} else {
	tcb->m_cWnd = (int) ((28.035+(34.779)+(75.665)+(96.672)+(10.18)+(5.716))/35.02);
	tcb->m_cWnd = (int) (84.832*(segmentsAcked)*(49.233)*(48.451)*(10.462));
	tcb->m_cWnd = (int) (((52.793)+(0.1)+(97.339)+(64.858)+(1.282)+((39.353-(13.111)-(18.232)-(segmentsAcked)-(61.771)-(89.175)-(80.593)-(cnt)))+(42.08))/((0.1)+(0.1)));

}
