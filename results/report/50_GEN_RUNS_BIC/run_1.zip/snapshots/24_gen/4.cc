float ocVwlBrXZzMAnHHN = (float) 0.72;
ocVwlBrXZzMAnHHN = (float) (-78.529+(87.958));
tcb->m_cWnd = (int) (-60.622*(-61.745)*(0.939)*(75.728));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
