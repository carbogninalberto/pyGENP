if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-46.08-(-90.078)-(-27.283));
segmentsAcked = (int) (((79.203)+((34.636*(-88.981)*(tcb->m_ssThresh)))+(62.789)+(-84.487))/((80.353)+(50.844)+(-23.878)+(-11.863)));
