if (cnt >= tcb->m_ssThresh) {
	cnt = (int) (29.276+(74.757)+(13.328)+(58.968)+(21.92)+(97.219)+(48.221)+(cnt)+(cnt));
	tcb->m_cWnd = (int) (93.959+(8.612)+(segmentsAcked)+(86.936)+(24.913)+(30.732)+(cnt)+(3.295));
	tcb->m_ssThresh = (int) (92.85*(37.414)*(65.914)*(tcb->m_segmentSize)*(15.781)*(97.566));

} else {
	cnt = (int) (35.672+(60.15)+(94.554)+(73.337)+(tcb->m_segmentSize)+(63.455)+(tcb->m_segmentSize)+(55.848));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_ssThresh = (int) (42.276-(tcb->m_ssThresh)-(0.457)-(6.281)-(80.824)-(61.229)-(88.18)-(segmentsAcked)-(7.207));
ReduceCwnd (tcb);
float mBxhEWZqrdDMUnOE = (float) (76.697+(54.419)+(91.34)+(37.442)+(95.441)+(segmentsAcked));
tcb->m_cWnd = (int) (70.937-(tcb->m_cWnd)-(tcb->m_segmentSize));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
