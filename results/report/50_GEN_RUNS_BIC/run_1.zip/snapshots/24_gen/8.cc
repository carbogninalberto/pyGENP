int fosOvHsaAgNhKIqh = (int) (-16.9-(43.48)-(-57.31)-(90.855)-(91.507)-(45.817)-(-67.711)-(20.251)-(-85.976));
ReduceCwnd (tcb);
segmentsAcked = (int) (77.839/-52.242);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
