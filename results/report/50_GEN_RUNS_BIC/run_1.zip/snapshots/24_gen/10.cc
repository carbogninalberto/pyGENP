int fosOvHsaAgNhKIqh = (int) (-41.291-(18.383)-(95.813)-(63.029)-(99.883)-(26.976)-(46.336)-(-28.64)-(24.269));
ReduceCwnd (tcb);
segmentsAcked = (int) (77.484/8.605);
segmentsAcked = (int) (77.708/32.463);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
