ReduceCwnd (tcb);
segmentsAcked = (int) (81.756/0.1);
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(3.989)+(25.807)+(34.154)+(71.786));
	segmentsAcked = (int) (33.102*(99.198)*(cnt)*(78.998)*(tcb->m_segmentSize)*(segmentsAcked)*(92.356)*(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (82.696+(3.395)+(66.101)+(42.418)+(26.359)+(2.997)+(84.466)+(20.302));

} else {
	tcb->m_cWnd = (int) (17.148/45.299);

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (10.316/31.986);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(40.935)*(94.36)*(69.087)*(segmentsAcked)*(63.936)*(18.139)*(58.65)*(80.892));
	tcb->m_cWnd = (int) (30.22*(46.04)*(64.464)*(32.717)*(29.017)*(51.135)*(28.834)*(41.384)*(50.612));

}
