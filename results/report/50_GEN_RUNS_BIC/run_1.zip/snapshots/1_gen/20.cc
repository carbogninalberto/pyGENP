float vIrKjoeuTBDpmSvV = (float) (27.413-(43.669));
int iAMcgFgagSeuduRC = (int) (segmentsAcked+(72.41)+(segmentsAcked)+(cnt)+(98.128)+(79.986)+(75.404)+(cnt));
iAMcgFgagSeuduRC = (int) (16.566-(12.136)-(92.878));
ReduceCwnd (tcb);
if (vIrKjoeuTBDpmSvV <= tcb->m_cWnd) {
	vIrKjoeuTBDpmSvV = (float) (((26.761)+(61.792)+(0.1)+(0.1)+(0.1))/((21.775)+(65.482)+(41.07)));

} else {
	vIrKjoeuTBDpmSvV = (float) (tcb->m_segmentSize+(iAMcgFgagSeuduRC)+(59.773)+(66.362));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (32.673-(75.006)-(6.353)-(segmentsAcked)-(48.14)-(6.933)-(64.103)-(17.707));
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	cnt = (int) (90.329*(93.064)*(34.992)*(51.28)*(43.076)*(1.413)*(segmentsAcked)*(89.874)*(41.173));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(69.439));

} else {
	cnt = (int) (0.1/45.439);
	cnt = (int) (76.227+(64.846));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
