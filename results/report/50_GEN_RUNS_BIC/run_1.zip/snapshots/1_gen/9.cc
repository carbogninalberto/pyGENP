if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (80.889-(45.89)-(43.051)-(63.383)-(tcb->m_segmentSize)-(9.396));
	segmentsAcked = (int) (95.918-(tcb->m_segmentSize)-(47.606)-(33.289)-(tcb->m_ssThresh));
	segmentsAcked = (int) (tcb->m_segmentSize-(tcb->m_cWnd)-(76.636)-(65.862)-(34.454)-(tcb->m_segmentSize)-(66.763));

} else {
	tcb->m_ssThresh = (int) (17.197+(segmentsAcked)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(49.093)+(84.953)+(60.764));

}
segmentsAcked = (int) (21.353-(72.808)-(cnt)-(80.705)-(27.267)-(74.845)-(71.18));
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((76.48)+(0.1)+(39.012)+((54.337+(66.692)+(51.929)))+((tcb->m_ssThresh+(33.89)+(71.642)+(61.218)+(5.185)+(2.474)+(86.842)+(48.842)+(56.169)))+(0.1))/((11.418)));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (69.632-(91.479)-(tcb->m_cWnd)-(6.956)-(28.01)-(71.892)-(3.687)-(tcb->m_ssThresh)-(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
