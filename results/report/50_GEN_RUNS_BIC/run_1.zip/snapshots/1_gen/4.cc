cnt = (int) (71.483+(56.167)+(36.373)+(3.941)+(24.299)+(25.185)+(58.936)+(tcb->m_ssThresh));
tcb->m_segmentSize = (int) (59.963-(tcb->m_ssThresh)-(91.206));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (0.1/38.176);
	tcb->m_ssThresh = (int) ((2.607-(segmentsAcked)-(99.772)-(tcb->m_segmentSize)-(13.6)-(89.894)-(93.734)-(tcb->m_cWnd)-(0.076))/94.736);

} else {
	tcb->m_segmentSize = (int) (24.412-(42.695)-(3.875));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
