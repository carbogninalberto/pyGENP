tcb->m_segmentSize = (int) (88.268/0.1);
segmentsAcked = (int) (15.569-(32.163));
if (tcb->m_segmentSize <= cnt) {
	tcb->m_segmentSize = (int) (segmentsAcked*(92.159)*(26.822)*(39.396)*(10.749));
	tcb->m_segmentSize = (int) (73.885-(72.249)-(14.541));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(75.982)+(26.848)+(14.76))/((2.332)+(0.1)));

}
if (cnt != cnt) {
	segmentsAcked = (int) (20.412+(26.865)+(57.345)+(97.013)+(83.579));

} else {
	segmentsAcked = (int) (70.006-(4.17)-(97.076)-(51.993)-(23.002));
	tcb->m_cWnd = (int) (((0.1)+(88.968)+(0.1)+(63.646)+(27.75)+((20.221-(80.858)))+(0.1))/((0.1)));
	segmentsAcked = (int) (30.863*(12.742)*(segmentsAcked)*(85.508)*(23.581)*(tcb->m_segmentSize)*(43.746)*(14.029)*(cnt));

}
cnt = (int) (segmentsAcked*(tcb->m_segmentSize)*(27.986)*(14.405)*(27.201));
ReduceCwnd (tcb);
if (tcb->m_segmentSize < cnt) {
	cnt = (int) ((segmentsAcked+(55.747))/0.1);
	tcb->m_ssThresh = (int) (((0.1)+((97.914-(48.716)-(68.285)))+(99.011)+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));
	tcb->m_segmentSize = (int) (88.59+(23.956)+(72.35)+(75.317)+(68.507)+(tcb->m_segmentSize)+(34.725)+(33.774));

} else {
	cnt = (int) (((0.1)+(15.194)+((40.21-(47.282)-(58.022)-(57.181)-(64.668)))+(94.254)+(0.1)+(67.148)+(29.272))/((18.988)));
	cnt = (int) (68.128+(cnt));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
