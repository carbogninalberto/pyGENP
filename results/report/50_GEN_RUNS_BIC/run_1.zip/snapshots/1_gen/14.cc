if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (81.723+(20.758)+(tcb->m_segmentSize)+(20.55)+(25.082)+(46.223)+(1.889));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (cnt-(79.996)-(15.983)-(33.24)-(82.964)-(tcb->m_ssThresh)-(48.586)-(tcb->m_cWnd)-(46.982));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(95.189)*(14.347)*(85.716)*(15.648));
	tcb->m_cWnd = (int) (15.962*(56.792)*(cnt)*(26.15)*(32.269)*(42.588)*(36.521)*(68.506)*(45.159));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) ((((23.56-(20.551)-(92.582)-(61.754)-(segmentsAcked)-(tcb->m_ssThresh)-(83.256)-(43.629)))+((67.893*(18.033)*(tcb->m_cWnd)*(4.386)*(90.629)*(59.765)))+(83.576)+((74.664*(75.935)*(49.075)))+(74.454))/((0.1)+(0.1)));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (((0.1)+(31.7)+(39.336)+(0.1)+(0.1)+(42.901)+(0.1))/((62.864)+(0.1)));
if (tcb->m_cWnd > cnt) {
	tcb->m_ssThresh = (int) (96.298*(78.94));
	cnt = (int) (71.993*(61.942)*(89.24)*(11.92)*(tcb->m_ssThresh)*(91.189)*(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (6.017*(94.497)*(cnt)*(18.213)*(12.584)*(37.177)*(11.755)*(58.096));

} else {
	tcb->m_ssThresh = (int) (0.1/20.116);
	ReduceCwnd (tcb);
	segmentsAcked = (int) (cnt*(39.897)*(36.952)*(96.775)*(5.371)*(tcb->m_cWnd));

}
tcb->m_ssThresh = (int) (77.737-(20.871)-(32.509)-(22.135)-(68.855)-(4.039)-(18.021)-(cnt));
