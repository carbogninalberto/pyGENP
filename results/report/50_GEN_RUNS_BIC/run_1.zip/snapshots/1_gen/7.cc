cnt = (int) (0.1/24.936);
tcb->m_segmentSize = (int) (((79.892)+(0.1)+((89.48*(1.44)*(63.465)*(segmentsAcked)*(tcb->m_segmentSize)*(31.179)*(76.76)*(33.338)))+(3.627))/((71.884)));
tcb->m_segmentSize = (int) (48.132*(63.844)*(32.109)*(77.598)*(36.463)*(93.728)*(tcb->m_cWnd)*(segmentsAcked)*(segmentsAcked));
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_segmentSize = (int) (cnt*(3.233)*(13.522)*(cnt)*(14.411)*(cnt)*(78.543)*(16.581));
	tcb->m_cWnd = (int) (cnt*(48.522)*(47.995)*(tcb->m_segmentSize)*(27.566)*(87.457)*(31.834)*(76.335));
	cnt = (int) (57.979-(54.211)-(tcb->m_cWnd)-(1.861)-(64.421)-(55.102)-(76.289)-(30.038)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (71.961+(78.568)+(19.051)+(cnt));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (90.971+(10.15)+(68.056));
	tcb->m_cWnd = (int) (39.211-(56.734)-(10.831)-(39.852)-(segmentsAcked));

}
segmentsAcked = (int) ((((cnt*(81.078)*(16.676)*(83.404)*(tcb->m_segmentSize)*(30.064)*(33.586)))+(0.1)+(14.236)+(0.1))/((0.1)+(98.705)+(0.1)));
segmentsAcked = (int) (32.263*(25.313)*(35.582)*(0.522)*(14.652)*(cnt)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(54.923));
