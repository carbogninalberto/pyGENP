float FBkhUyzJPrkoSGXZ = (float) (tcb->m_cWnd-(9.725)-(59.146)-(13.548)-(85.73)-(42.998)-(36.901)-(91.278));
if (tcb->m_ssThresh > cnt) {
	FBkhUyzJPrkoSGXZ = (float) (FBkhUyzJPrkoSGXZ*(FBkhUyzJPrkoSGXZ)*(47.652)*(tcb->m_ssThresh)*(72.078)*(47.24)*(43.25)*(7.404));
	segmentsAcked = (int) (7.567*(73.099)*(41.633)*(20.156)*(segmentsAcked)*(79.502)*(tcb->m_segmentSize)*(60.892));
	ReduceCwnd (tcb);

} else {
	FBkhUyzJPrkoSGXZ = (float) (94.663*(9.134)*(38.729)*(51.657)*(41.991)*(cnt)*(65.533)*(7.733));

}
tcb->m_cWnd = (int) (36.217+(43.016)+(96.23)+(92.001)+(segmentsAcked)+(46.741)+(40.243));
if (tcb->m_segmentSize == cnt) {
	tcb->m_ssThresh = (int) (85.601+(3.281));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (48.281-(52.618)-(87.491)-(80.719)-(segmentsAcked)-(91.241)-(99.949)-(47.696));
	FBkhUyzJPrkoSGXZ = (float) (48.747-(12.194)-(99.516)-(25.396)-(35.385));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
