ReduceCwnd (tcb);
int wXjvKnwDMBaOwuuN = (int) (80.986+(73.919)+(5.328)+(tcb->m_segmentSize)+(16.604)+(segmentsAcked)+(71.942)+(12.292)+(76.63));
tcb->m_cWnd = (int) (0.1/0.1);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (tcb->m_segmentSize*(44.184)*(2.401)*(95.474)*(67.133)*(74.641)*(wXjvKnwDMBaOwuuN)*(tcb->m_ssThresh)*(tcb->m_ssThresh));
wXjvKnwDMBaOwuuN = (int) (68.751+(18.045)+(4.343)+(15.224));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
