if (segmentsAcked > segmentsAcked) {
	tcb->m_cWnd = (int) (50.234*(36.35)*(54.707)*(47.789)*(11.201)*(96.259)*(84.693)*(cnt));
	tcb->m_segmentSize = (int) (81.085/46.252);

} else {
	tcb->m_cWnd = (int) (58.093*(tcb->m_segmentSize)*(89.728)*(69.891)*(0.235)*(15.829)*(42.655));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) ((((79.571+(tcb->m_segmentSize)))+(44.75)+(0.1)+(0.1))/((4.525)));
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	segmentsAcked = (int) (77.132+(89.75)+(cnt)+(tcb->m_segmentSize)+(73.824)+(65.752));

} else {
	segmentsAcked = (int) (49.086+(52.967)+(tcb->m_segmentSize)+(14.925)+(44.172)+(60.21));
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(41.939)+(76.178)+(0.1)));
	tcb->m_segmentSize = (int) (31.158+(85.265)+(97.093));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
