tcb->m_ssThresh = (int) (segmentsAcked+(tcb->m_ssThresh)+(24.893)+(55.825)+(23.281)+(cnt)+(11.657)+(32.123)+(20.643));
if (segmentsAcked > segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(2.894)-(15.924)-(tcb->m_cWnd)-(2.246)-(tcb->m_ssThresh)-(66.429));

} else {
	tcb->m_ssThresh = (int) (67.107*(31.467)*(77.501));

}
if (tcb->m_segmentSize <= cnt) {
	tcb->m_cWnd = (int) (27.351-(9.945)-(45.91)-(tcb->m_cWnd)-(cnt)-(segmentsAcked)-(81.096));

} else {
	tcb->m_cWnd = (int) (59.868+(tcb->m_segmentSize)+(66.321)+(82.179)+(98.152)+(99.742)+(88.512)+(73.704)+(81.145));
	segmentsAcked = (int) (tcb->m_ssThresh-(70.491));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (83.443+(0.13)+(segmentsAcked));
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (53.618-(9.118)-(70.163)-(83.27)-(67.744)-(80.17)-(25.135)-(-0.018));
	tcb->m_cWnd = (int) (10.844-(2.69)-(54.837)-(7.533)-(tcb->m_cWnd));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (30.35-(77.839));

}
