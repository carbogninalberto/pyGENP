if (tcb->m_cWnd == cnt) {
	cnt = (int) (90.105+(5.573)+(45.507)+(tcb->m_ssThresh)+(33.787)+(4.512)+(52.807)+(31.75)+(27.314));

} else {
	cnt = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)));

}
tcb->m_segmentSize = (int) (85.507+(93.437)+(17.941)+(segmentsAcked));
cnt = (int) (((66.934)+((53.437-(92.785)-(58.01)-(87.551)-(92.229)-(88.427)-(53.7)))+((45.425+(47.417)+(95.094)))+(99.384)+(46.709))/((8.485)));
if (cnt <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (36.185-(24.078)-(56.103)-(32.559)-(94.326)-(tcb->m_cWnd)-(7.84)-(68.931));
	cnt = (int) (cnt-(5.087)-(44.81));

} else {
	tcb->m_ssThresh = (int) (29.814-(89.551));

}
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (96.578*(42.663)*(81.939)*(18.187)*(segmentsAcked)*(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (66.984*(19.699)*(52.041)*(43.904)*(40.128)*(51.722)*(3.735)*(segmentsAcked));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (63.453*(52.744)*(cnt)*(41.59)*(18.646)*(3.125));

}
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (94.156-(5.188)-(96.59)-(58.16)-(90.753)-(tcb->m_ssThresh)-(90.896)-(13.978));
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (93.365-(32.019)-(56.37)-(75.007)-(segmentsAcked)-(12.473)-(tcb->m_segmentSize)-(8.545)-(40.301));
	cnt = (int) (((93.025)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	segmentsAcked = (int) (83.569*(37.992)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(76.284)*(7.551)*(89.05));

} else {
	segmentsAcked = (int) (66.546*(tcb->m_cWnd)*(cnt)*(32.616)*(79.473)*(10.501)*(4.457)*(56.991));
	segmentsAcked = (int) (78.525+(11.844)+(30.325)+(tcb->m_cWnd));

}
