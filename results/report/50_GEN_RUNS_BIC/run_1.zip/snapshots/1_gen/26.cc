tcb->m_ssThresh = (int) (28.75+(cnt)+(14.705)+(tcb->m_cWnd)+(cnt)+(44.872));
if (segmentsAcked == cnt) {
	tcb->m_cWnd = (int) (36.24+(93.68)+(84.695)+(cnt)+(15.991)+(38.052)+(70.767)+(15.441));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (cnt*(5.393)*(tcb->m_segmentSize)*(68.498));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
float RHfnltAlWyTPlREf = (float) (39.527+(56.524)+(47.248)+(90.374));
ReduceCwnd (tcb);
