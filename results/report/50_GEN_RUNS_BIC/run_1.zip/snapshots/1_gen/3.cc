int xPwZLVPfduxWcyuo = (int) (91.603*(5.681));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int CeYiDiCGRYLOcJWO = (int) (99.448+(58.408)+(77.076)+(15.157)+(44.616)+(77.314));
xPwZLVPfduxWcyuo = (int) (1.98+(15.046)+(66.335)+(2.806));
float UukprqXvbRPrIqRu = (float) (47.564*(78.365)*(20.739)*(10.214)*(98.625)*(68.766)*(24.611)*(segmentsAcked));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > tcb->m_cWnd) {
	CeYiDiCGRYLOcJWO = (int) (((0.1)+(0.1)+(0.1)+(32.973)+(6.395))/((0.1)+(0.1)+(0.1)+(0.1)));
	cnt = (int) (54.664-(31.373)-(42.314)-(67.866)-(24.592));
	tcb->m_segmentSize = (int) (77.024-(29.642));

} else {
	CeYiDiCGRYLOcJWO = (int) (UukprqXvbRPrIqRu-(50.314)-(tcb->m_segmentSize)-(99.691)-(2.679));

}
if (cnt < segmentsAcked) {
	tcb->m_cWnd = (int) (71.517-(84.286)-(5.604)-(12.009)-(CeYiDiCGRYLOcJWO)-(47.117));

} else {
	tcb->m_cWnd = (int) (40.144-(xPwZLVPfduxWcyuo)-(56.984)-(11.849)-(23.335)-(69.516)-(19.552)-(63.519));
	xPwZLVPfduxWcyuo = (int) ((11.129+(33.252)+(17.93)+(94.109)+(27.578)+(47.068))/29.376);
	tcb->m_segmentSize = (int) (segmentsAcked+(19.403)+(UukprqXvbRPrIqRu));

}
