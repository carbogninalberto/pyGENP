cnt = (int) (0.1/20.561);
tcb->m_ssThresh = (int) (42.087*(3.342)*(2.879)*(18.98)*(tcb->m_ssThresh)*(85.144)*(94.867)*(31.013));
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (86.172/52.689);

} else {
	tcb->m_ssThresh = (int) (47.675+(59.361)+(87.979)+(99.164)+(83.139)+(25.109)+(segmentsAcked)+(75.567));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_ssThresh != segmentsAcked) {
	segmentsAcked = (int) (85.114/45.354);
	tcb->m_ssThresh = (int) (60.969-(tcb->m_ssThresh)-(2.08)-(58.267)-(52.038)-(55.295));

} else {
	segmentsAcked = (int) (99.854/0.1);

}
tcb->m_segmentSize = (int) (cnt-(98.906)-(42.935)-(segmentsAcked)-(tcb->m_cWnd)-(40.265));
