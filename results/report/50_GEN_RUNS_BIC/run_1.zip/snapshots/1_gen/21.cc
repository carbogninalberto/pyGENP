ReduceCwnd (tcb);
int IqpSpotGYRODlGrS = (int) (41.797-(tcb->m_ssThresh));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
