if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.1/65.088);
	cnt = (int) (86.963-(53.258)-(74.366)-(99.457)-(20.394)-(4.656)-(40.839)-(16.388));

} else {
	tcb->m_ssThresh = (int) (51.413*(31.623)*(27.676)*(19.833)*(32.527)*(24.931)*(96.696)*(20.677));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_cWnd = (int) (96.204-(5.557)-(74.173)-(76.593)-(40.773)-(91.478));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (46.034+(84.434)+(35.307)+(67.047)+(26.952));
	tcb->m_ssThresh = (int) (50.338*(28.141)*(26.76));

} else {
	tcb->m_ssThresh = (int) (9.468+(86.096)+(43.441)+(51.419));
	tcb->m_cWnd = (int) (78.621/0.1);
	cnt = (int) (25.382+(35.783)+(94.241)+(45.833)+(50.37)+(85.218));

}
if (segmentsAcked >= tcb->m_cWnd) {
	cnt = (int) (47.01+(24.071)+(33.828)+(0.041));
	cnt = (int) (61.271/76.044);

} else {
	cnt = (int) (68.95*(tcb->m_ssThresh)*(42.466)*(45.009)*(54.294)*(16.397)*(25.485)*(29.927)*(88.442));
	tcb->m_segmentSize = (int) (33.915-(tcb->m_cWnd)-(54.2));

}
ReduceCwnd (tcb);
