float UumkvIUtJBjYtzNx = (float) (((25.269)+((21.285+(95.916)+(59.918)+(23.698)+(tcb->m_segmentSize)))+((21.678*(25.099)))+(0.1)+(71.733))/((84.439)+(81.164)+(54.156)+(26.576)));
ReduceCwnd (tcb);
if (segmentsAcked >= cnt) {
	tcb->m_cWnd = (int) (79.213*(86.538)*(cnt)*(23.589)*(-0.024)*(32.53)*(tcb->m_ssThresh));
	cnt = (int) (5.245-(UumkvIUtJBjYtzNx)-(57.207)-(24.522));

} else {
	tcb->m_cWnd = (int) (93.284*(35.794)*(50.11)*(38.857)*(85.915)*(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (UumkvIUtJBjYtzNx+(UumkvIUtJBjYtzNx)+(68.652)+(80.81)+(6.174)+(24.255)+(59.809)+(37.203)+(74.559));
if (cnt <= cnt) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(tcb->m_cWnd)+(76.594)+(27.571));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (0.1/35.296);

}
