float ByGyGExSQqOjUitW = (float) (70.942*(46.329)*(96.766)*(80.007)*(9.135)*(-38.633)*(-13.181));
float SylLeyeghnYxsCey = (float) 27.483;
