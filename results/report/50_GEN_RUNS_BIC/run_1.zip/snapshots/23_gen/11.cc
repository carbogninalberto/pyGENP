float rClQMtDwsrZATQpu = (float) (42.426-(-71.364)-(44.383)-(-75.09)-(84.976));
int qIdZHOsDleUKtRWz = (int) (-19.22*(-35.145)*(93.839)*(40.598)*(64.02)*(-16.314)*(34.073)*(2.42));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (33.955+(45.243)+(-53.196)+(-49.64)+(-38.181)+(-22.543)+(47.751)+(44.34)+(98.122));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
