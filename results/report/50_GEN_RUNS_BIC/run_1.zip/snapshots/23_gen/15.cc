segmentsAcked = (int) (-49.371*(85.925)*(55.333)*(10.134)*(2.523));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-52.402*(-91.608)*(86.188));
tcb->m_segmentSize = (int) (21.843*(99.623)*(73.893));
