tcb->m_segmentSize = (int) (-72.942*(-44.3)*(4.501));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
