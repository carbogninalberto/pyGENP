ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (42.339-(34.057)-(0.164)-(56.927)-(tcb->m_ssThresh));
	cnt = (int) (30.682*(92.931)*(2.786)*(8.16)*(79.338)*(12.415)*(24.141)*(tcb->m_ssThresh)*(tcb->m_cWnd));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(52.948)+(18.997)+(tcb->m_cWnd)+(85.602)+(25.925));

}
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_ssThresh = (int) (4.777*(94.729));
	tcb->m_ssThresh = (int) (71.817/0.1);

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
cnt = (int) (tcb->m_ssThresh+(2.156)+(26.533)+(38.747));
cnt = (int) (((0.1)+(0.1)+((46.32+(0.73)+(segmentsAcked)+(62.781)+(tcb->m_segmentSize)+(37.32)+(cnt)+(15.679)))+(0.1))/((0.1)));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (15.347/0.1);
	cnt = (int) (31.63*(29.81)*(tcb->m_segmentSize)*(83.884)*(9.846)*(tcb->m_ssThresh)*(62.953)*(9.482));

} else {
	tcb->m_ssThresh = (int) (50.382-(cnt)-(tcb->m_ssThresh));

}
