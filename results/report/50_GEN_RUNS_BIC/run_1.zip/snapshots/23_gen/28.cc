ReduceCwnd (tcb);
segmentsAcked = (int) (54.948/0.1);
if (tcb->m_ssThresh == segmentsAcked) {
	segmentsAcked = (int) (58.799-(89.879)-(68.289)-(tcb->m_cWnd));
	segmentsAcked = (int) (((33.65)+((53.502*(79.208)*(45.916)*(12.814)*(50.691)*(96.091)))+(77.386)+(43.906)+(0.1)+(0.1)+(1.334))/((0.1)+(0.1)));
	tcb->m_segmentSize = (int) (59.632*(tcb->m_segmentSize)*(11.355)*(43.598)*(89.978));

} else {
	segmentsAcked = (int) (52.072-(63.478)-(19.76)-(80.469)-(30.946)-(4.529));
	tcb->m_cWnd = (int) (37.198/91.85);
	tcb->m_segmentSize = (int) (1.461*(50.801)*(tcb->m_segmentSize)*(40.741)*(16.262));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (22.683+(17.396)+(48.483));
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (59.536-(tcb->m_cWnd)-(58.069)-(74.711)-(47.395)-(25.404)-(tcb->m_ssThresh)-(tcb->m_segmentSize));
	cnt = (int) (0.1/5.983);

} else {
	tcb->m_ssThresh = (int) (42.883/0.1);

}
