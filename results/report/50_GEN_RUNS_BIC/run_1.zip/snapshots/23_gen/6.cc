int ymBZvBPqwCBWMpzf = (int) 13.982;
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-89.4*(74.724));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (88.507*(-24.738)*(37.45));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (0.1/91.827);

}
