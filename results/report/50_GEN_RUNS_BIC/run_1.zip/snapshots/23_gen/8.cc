tcb->m_cWnd = (int) (-18.788*(12.232)*(54.267)*(-22.786)*(34.83));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (83.569*(-99.42)*(63.061));
