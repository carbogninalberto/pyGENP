if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) ((32.948*(31.798)*(59.784)*(segmentsAcked)*(21.745)*(19.827)*(22.303))/0.1);
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (79.602-(50.15)-(53.874)-(segmentsAcked)-(72.298));
	tcb->m_segmentSize = (int) ((15.224*(13.701))/94.148);
	tcb->m_ssThresh = (int) ((16.622+(91.88)+(39.044)+(7.674)+(tcb->m_ssThresh)+(32.674)+(94.604))/99.569);

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (53.731-(33.947));
int bfTvrngUJwlhXbby = (int) (76.928-(7.692)-(tcb->m_cWnd)-(66.13)-(89.116));
if (tcb->m_segmentSize > cnt) {
	tcb->m_cWnd = (int) (bfTvrngUJwlhXbby*(15.058));
	tcb->m_ssThresh = (int) (22.773*(81.771)*(70.911)*(45.847)*(6.984));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (17.642*(bfTvrngUJwlhXbby)*(tcb->m_segmentSize)*(11.35));
	ReduceCwnd (tcb);
	cnt = (int) (46.666-(tcb->m_cWnd)-(4.474)-(7.426));

}
tcb->m_segmentSize = (int) (97.338+(78.254)+(30.156));
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (cnt-(25.588));
	bfTvrngUJwlhXbby = (int) (7.963+(cnt)+(0.304)+(6.847)+(70.678));
	bfTvrngUJwlhXbby = (int) (90.603*(12.687)*(12.719)*(54.767)*(34.772)*(tcb->m_segmentSize)*(27.705)*(91.517)*(29.038));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(bfTvrngUJwlhXbby)-(83.153)-(97.883));

}
int NiBsfrqIdFsdBQra = (int) (bfTvrngUJwlhXbby+(48.886)+(75.265)+(80.807)+(17.115)+(96.832)+(64.023));
cnt = (int) (18.122-(41.662));
