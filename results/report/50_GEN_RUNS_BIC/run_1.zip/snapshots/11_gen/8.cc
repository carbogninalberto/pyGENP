tcb->m_cWnd = (int) (-32.06+(-71.354)+(3.246)+(-48.258)+(30.662)+(90.155));
float bcMHXpseMRkFbMhS = (float) 65.484;
tcb->m_cWnd = (int) (-0.377-(30.121)-(-80.19)-(-25.537)-(39.465)-(57.706));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-15.782-(43.121)-(-37.429)-(-59.327)-(93.538)-(-1.319)-(-45.552)-(94.23)-(-65.255));
