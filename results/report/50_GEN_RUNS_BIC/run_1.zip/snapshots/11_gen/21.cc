cnt = (int) (17.676+(71.905));
if (segmentsAcked >= tcb->m_segmentSize) {
	cnt = (int) ((95.261-(36.17)-(80.799)-(51.697)-(tcb->m_cWnd)-(57.918)-(40.812)-(cnt)-(94.915))/0.1);
	segmentsAcked = (int) (tcb->m_segmentSize+(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (44.885+(21.754)+(66.361)+(54.901)+(6.735)+(41.993)+(99.317)+(30.219)+(74.549));

} else {
	cnt = (int) (44.71*(5.922)*(78.139));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(81.754)+(6.118)+(tcb->m_ssThresh)+(91.455)+(95.922)+(56.3));

}
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) ((78.564+(71.925)+(cnt)+(5.236)+(24.194)+(49.505)+(35.53)+(87.799)+(tcb->m_cWnd))/0.1);

} else {
	tcb->m_ssThresh = (int) (80.916/0.1);
	tcb->m_cWnd = (int) (7.86-(cnt)-(3.731)-(47.52));

}
if (cnt >= cnt) {
	tcb->m_cWnd = (int) ((72.64-(9.61)-(91.247))/0.1);
	tcb->m_segmentSize = (int) (57.241/42.212);

} else {
	tcb->m_cWnd = (int) (((0.1)+((cnt+(62.908)+(13.835)+(87.369)+(85.395)+(5.098)+(25.194)+(27.339)+(2.445)))+(23.931)+((83.491-(27.484)-(33.762)-(37.875)-(11.514)-(59.035)))+(0.1))/((84.148)+(7.797)));

}
tcb->m_segmentSize = (int) (segmentsAcked+(tcb->m_cWnd)+(76.723)+(71.13)+(83.565)+(94.022)+(78.338)+(43.118));
tcb->m_segmentSize = (int) (72.69*(88.849));
ReduceCwnd (tcb);
