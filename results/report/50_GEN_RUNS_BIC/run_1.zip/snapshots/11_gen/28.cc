segmentsAcked = (int) (46.093+(41.911)+(58.73)+(85.559));
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	cnt = (int) (30.121-(9.754)-(58.324)-(3.056)-(0.835));
	cnt = (int) (0.692+(25.14)+(96.776)+(tcb->m_segmentSize)+(79.309)+(16.785)+(5.782)+(tcb->m_ssThresh));

} else {
	cnt = (int) (((64.364)+(0.1)+(38.328)+(70.541))/((0.1)+(0.1)+(0.1)+(0.1)));
	tcb->m_segmentSize = (int) (49.511-(16.115)-(tcb->m_ssThresh)-(48.643)-(tcb->m_cWnd)-(14.431)-(16.864));
	tcb->m_segmentSize = (int) (((0.1)+(77.454)+(53.759)+(0.1)+(0.1)+(0.1)+(85.671))/((0.1)));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (79.484+(tcb->m_ssThresh));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (cnt*(81.215)*(58.07));

} else {
	segmentsAcked = (int) ((85.842-(tcb->m_segmentSize))/41.978);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(tcb->m_cWnd)*(13.468)*(tcb->m_segmentSize)*(14.991)*(tcb->m_cWnd));
int pfZUYQOWfJYvrbFN = (int) (36.738*(23.483)*(4.516));
if (pfZUYQOWfJYvrbFN > pfZUYQOWfJYvrbFN) {
	tcb->m_cWnd = (int) (74.15*(97.886)*(46.525));
	cnt = (int) (54.115*(60.835));
	segmentsAcked = (int) (31.531-(90.853)-(8.008)-(33.975)-(14.776)-(pfZUYQOWfJYvrbFN)-(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (42.265+(95.592)+(39.738)+(71.859));

}
if (segmentsAcked <= tcb->m_segmentSize) {
	pfZUYQOWfJYvrbFN = (int) (49.952*(56.329)*(59.54)*(cnt)*(tcb->m_segmentSize)*(89.369)*(14.316));
	tcb->m_cWnd = (int) (75.424-(60.842)-(34.062)-(27.597)-(66.594)-(56.823)-(51.568)-(87.178)-(99.319));
	cnt = (int) (tcb->m_cWnd+(24.828)+(44.896)+(51.594)+(cnt)+(94.901)+(52.517));

} else {
	pfZUYQOWfJYvrbFN = (int) (51.08+(13.136)+(tcb->m_segmentSize)+(76.758)+(39.168)+(52.451)+(4.828)+(43.832));

}
if (cnt <= segmentsAcked) {
	segmentsAcked = (int) (1.161*(52.102)*(87.757)*(9.339)*(2.381)*(25.549));
	cnt = (int) (55.527*(56.743)*(73.475)*(tcb->m_segmentSize)*(65.315)*(tcb->m_cWnd)*(15.494)*(16.212));
	tcb->m_ssThresh = (int) (36.349+(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) (91.186*(50.896)*(9.867)*(segmentsAcked));

}
ReduceCwnd (tcb);
