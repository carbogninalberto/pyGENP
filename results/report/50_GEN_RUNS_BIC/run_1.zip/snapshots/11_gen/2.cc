float kpwafNkWBjBlbbuz = (float) (-78.004+(18.996)+(23.697)+(-21.117)+(90.018)+(34.759)+(76.348)+(-85.628)+(-51.722));
int taSbqywLwQaKGICe = (int) (80.106*(-4.612)*(-95.392));
int FGgjHwpfIkNDEEry = (int) (-93.257*(97.061)*(19.442)*(-98.876)*(-99.059)*(-38.771));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-87.742*(95.288)*(-0.763)*(-52.109)*(56.073));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (24.792*(81.234)*(-83.712)*(2.411)*(10.635)*(-20.211));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (90.337*(-5.716)*(-88.873)*(65.94)*(50.337));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-78.337*(-35.808)*(14.496)*(-30.135)*(-23.655)*(-81.521));
