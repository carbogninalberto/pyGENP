int WvAocKeZcUnOyXWt = (int) (47.91*(10.203)*(58.951)*(-49.607));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
