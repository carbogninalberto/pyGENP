float tqvaivcHoCtIBkyJ = (float) (-81.769+(-45.258)+(47.588)+(53.091)+(19.167)+(1.608));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (14.01-(-85.797)-(75.72)-(57.405)-(-30.753)-(75.123)-(-11.387)-(38.241));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
