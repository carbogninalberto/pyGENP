float kpwafNkWBjBlbbuz = (float) (70.145+(-19.026)+(40.654)+(84.889)+(4.315)+(72.515)+(-49.062)+(-84.668)+(-63.778));
int taSbqywLwQaKGICe = (int) (-96.994*(60.451)*(-26.243));
int FGgjHwpfIkNDEEry = (int) (79.085*(-90.364)*(37.676)*(-82.141)*(-47.026)*(-88.39));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-42.759*(-6.116)*(6.2)*(-52.475)*(-51.619));
segmentsAcked = (int) (-4.118*(-20.786)*(10.337)*(15.848)*(-17.765)*(60.876));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-89.082*(-46.826)*(-18.194)*(-86.167)*(43.604)*(-53.473));
