ReduceCwnd (tcb);
segmentsAcked = (int) (-70.219+(54.686)+(82.312)+(94.039)+(-17.706)+(9.694)+(-18.614)+(-87.249)+(87.942));
segmentsAcked = (int) (-40.366+(-2.044)+(43.014)+(-63.423)+(2.078)+(-57.855)+(47.309)+(61.753)+(-62.757));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
