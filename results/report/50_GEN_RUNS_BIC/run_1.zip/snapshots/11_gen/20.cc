tcb->m_cWnd = (int) (56.31-(segmentsAcked)-(72.64)-(87.02)-(72.912)-(70.475)-(44.363)-(31.644));
tcb->m_cWnd = (int) (73.529-(cnt)-(tcb->m_cWnd)-(5.613)-(segmentsAcked)-(tcb->m_cWnd)-(segmentsAcked));
segmentsAcked = (int) (cnt+(1.1));
if (cnt < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (76.468+(17.98));

} else {
	tcb->m_ssThresh = (int) (68.848*(49.312)*(87.554)*(segmentsAcked));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((38.255*(25.198))/74.617);
ReduceCwnd (tcb);
