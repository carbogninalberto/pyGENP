float kpwafNkWBjBlbbuz = (float) (28.852+(-91.168)+(54.346)+(50.935)+(-74.64)+(62.375)+(-37.187)+(-80.914)+(82.667));
int taSbqywLwQaKGICe = (int) (4.987*(28.731)*(65.607));
int FGgjHwpfIkNDEEry = (int) (-90.221*(-92.836)*(36.277)*(-5.593)*(23.018)*(-52.135));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (66.821*(-86.551)*(56.114)*(32.851)*(-84.872));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-55.051*(34.567)*(-34.937)*(-52.965)*(32.291)*(-42.862));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-65.66*(46.83)*(-13.551)*(-50.224)*(-55.943));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-76.214*(-6.568)*(71.406)*(98.613)*(25.409));
segmentsAcked = (int) (-17.061*(-77.162)*(-74.256)*(35.114)*(-66.614)*(-70.957));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-88.892*(-75.065)*(-63.656)*(71.438)*(-51.612)*(-37.19));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (87.525*(41.895)*(-75.149)*(93.802)*(-66.993));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (96.883*(45.183)*(61.024)*(-17.303)*(91.757)*(85.949));
