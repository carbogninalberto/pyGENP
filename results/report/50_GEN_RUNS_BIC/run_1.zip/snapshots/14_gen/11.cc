if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (28.924*(10.995));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (11.602*(18.036)*(100.0));

}
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (28.521-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(82.208)-(55.602));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(19.506)*(18.647));
	tcb->m_ssThresh = (int) (83.945+(61.264)+(73.424)+(0.856)+(54.334)+(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (47.96+(86.989)+(58.272)+(67.648)+(21.494));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	cnt = (int) (76.528+(6.224)+(94.668)+(11.343)+(87.736)+(3.335)+(90.277)+(16.876)+(89.726));
	segmentsAcked = (int) (0.1/0.1);

} else {
	cnt = (int) (56.978+(80.733)+(5.894)+(50.319));

}
