ReduceCwnd (tcb);
if (cnt != segmentsAcked) {
	tcb->m_segmentSize = (int) (cnt*(88.742));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (14.101*(1.316)*(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (43.48*(41.927)*(66.974)*(14.996)*(tcb->m_segmentSize)*(42.598));
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (15.497*(tcb->m_segmentSize)*(segmentsAcked)*(tcb->m_cWnd)*(74.359)*(54.602));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize >= cnt) {
	tcb->m_cWnd = (int) (59.291*(6.494)*(42.813)*(95.958)*(53.831)*(49.708)*(28.506)*(25.972)*(63.272));

} else {
	tcb->m_cWnd = (int) (53.786*(13.1)*(49.699));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
