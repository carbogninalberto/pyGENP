if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_cWnd = (int) (38.218-(84.249)-(85.229)-(47.33)-(tcb->m_ssThresh)-(8.938));

} else {
	tcb->m_cWnd = (int) (87.144-(49.894)-(67.751)-(19.354)-(99.417)-(74.911)-(70.017)-(29.49));
	segmentsAcked = (int) (73.985*(60.52)*(18.748)*(96.114)*(74.934)*(66.017));

}
float rpZTELjWZQdkSHcN = (float) ((((79.098-(14.443)-(21.064)-(tcb->m_segmentSize)-(50.552)-(82.639)-(33.317)))+((tcb->m_ssThresh-(3.574)-(42.302)-(57.047)))+(0.1)+(0.1))/((0.1)+(26.953)));
if (rpZTELjWZQdkSHcN > tcb->m_ssThresh) {
	segmentsAcked = (int) (86.314*(18.949)*(cnt)*(tcb->m_segmentSize)*(cnt));
	rpZTELjWZQdkSHcN = (float) (72.148*(34.341)*(33.309)*(98.813)*(segmentsAcked)*(tcb->m_cWnd)*(61.999)*(cnt)*(90.397));

} else {
	segmentsAcked = (int) (51.738*(94.524)*(76.549));
	tcb->m_segmentSize = (int) (7.567-(98.616));
	cnt = (int) (43.19+(88.35)+(tcb->m_segmentSize));

}
int fmsCrVzdlQXAsTAb = (int) ((92.218+(tcb->m_cWnd)+(72.571)+(tcb->m_segmentSize))/0.1);
fmsCrVzdlQXAsTAb = (int) (tcb->m_segmentSize-(94.008)-(92.977)-(22.446)-(tcb->m_ssThresh));
tcb->m_cWnd = (int) ((49.991+(60.074)+(fmsCrVzdlQXAsTAb)+(25.313)+(49.93)+(1.325)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(47.184))/65.735);
