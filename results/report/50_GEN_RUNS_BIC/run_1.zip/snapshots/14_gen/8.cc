cnt = (int) (99.525*(20.62)*(33.037));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	segmentsAcked = (int) (23.021-(70.558)-(7.67)-(25.96));

} else {
	segmentsAcked = (int) (segmentsAcked+(5.859)+(96.513));
	tcb->m_segmentSize = (int) (51.071*(13.764)*(96.616)*(segmentsAcked)*(65.031));

}
if (tcb->m_cWnd < segmentsAcked) {
	cnt = (int) (segmentsAcked+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(39.403)-(cnt)-(55.767)-(69.247)-(13.419)-(23.048)-(segmentsAcked));
	ReduceCwnd (tcb);

} else {
	cnt = (int) ((20.043+(50.927))/0.1);
	tcb->m_ssThresh = (int) (((0.1)+(56.696)+(74.683)+(0.1)+(0.1)+(56.045))/((23.584)+(77.659)));

}
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (56.048-(19.784)-(79.654));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
