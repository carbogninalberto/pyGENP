if (tcb->m_ssThresh > segmentsAcked) {
	cnt = (int) (80.871*(2.798)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(57.226));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (91.939*(69.723)*(tcb->m_segmentSize)*(57.296));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((43.033)+(0.1)+(0.1)+(98.614)+(0.1)+(54.469)+(99.343)+(0.1))/((39.481)));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(32.995)*(29.022)*(80.638)*(84.882)*(46.194)*(93.711)*(77.167));
	tcb->m_ssThresh = (int) ((40.394+(21.905)+(cnt)+(tcb->m_cWnd)+(17.915))/4.038);

}
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (35.394+(cnt)+(43.451)+(59.592)+(tcb->m_cWnd)+(44.177)+(26.992)+(3.143));

} else {
	tcb->m_ssThresh = (int) (7.478*(75.262)*(50.223)*(90.476)*(58.156)*(37.641));
	tcb->m_cWnd = (int) (18.284-(4.693)-(45.954)-(43.785)-(30.887)-(53.102)-(77.416)-(32.819));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < cnt) {
	cnt = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(7.759)));
	tcb->m_cWnd = (int) (81.932*(4.01)*(68.934)*(14.209)*(39.458));

} else {
	cnt = (int) (tcb->m_cWnd+(72.188)+(85.796)+(tcb->m_cWnd)+(12.364));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) ((46.214+(tcb->m_segmentSize))/46.765);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (12.004*(37.93)*(78.646)*(2.189)*(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (62.546/0.1);
	cnt = (int) (((0.1)+((44.8+(tcb->m_segmentSize)+(65.898)+(61.28)+(26.463)))+(0.1)+(0.1))/((0.1)+(71.272)+(0.1)+(24.683)+(8.75)));
	cnt = (int) (49.952*(52.884)*(85.264)*(95.753)*(79.675)*(94.883)*(18.887));

}
