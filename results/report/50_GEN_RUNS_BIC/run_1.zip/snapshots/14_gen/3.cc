if (tcb->m_segmentSize < segmentsAcked) {
	segmentsAcked = (int) (57.733*(46.914)*(68.571));
	segmentsAcked = (int) (6.124-(74.139)-(tcb->m_cWnd)-(71.939)-(tcb->m_segmentSize)-(31.469)-(93.856));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (-35.278+(95.571)+(9.551)+(67.761));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (96.277+(tcb->m_segmentSize)+(59.087)+(segmentsAcked)+(88.098)+(10.726)+(75.899)+(90.325)+(tcb->m_cWnd));

}
segmentsAcked = (int) (-77.374*(44.616)*(-89.191)*(-69.563)*(59.65));
tcb->m_cWnd = (int) (-50.245*(-15.927)*(58.983)*(8.37)*(-3.94));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
