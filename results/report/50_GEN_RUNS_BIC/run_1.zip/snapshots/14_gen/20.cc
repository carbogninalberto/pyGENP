int WrtxaaMExvfRnLMU = (int) (28.832+(43.421)+(16.89)+(84.919)+(39.722)+(44.97)+(22.178)+(70.773)+(cnt));
if (WrtxaaMExvfRnLMU > tcb->m_ssThresh) {
	cnt = (int) (((0.1)+(19.21)+((7.802+(11.227)+(cnt)+(WrtxaaMExvfRnLMU)+(49.682)+(68.91)+(10.653)+(14.884)))+(39.329))/((0.1)));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (cnt*(98.629)*(84.56)*(89.685)*(37.981)*(39.01));

} else {
	cnt = (int) (39.702+(99.492)+(36.15)+(18.227)+(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (cnt*(76.178)*(tcb->m_segmentSize)*(2.595));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (WrtxaaMExvfRnLMU >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (81.822*(segmentsAcked)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (39.691+(90.135)+(tcb->m_ssThresh)+(cnt)+(80.939)+(46.188)+(66.13));
	cnt = (int) (75.855-(81.891)-(94.395)-(60.671)-(39.292));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (95.532*(73.153)*(tcb->m_ssThresh)*(cnt)*(55.849)*(cnt)*(75.347)*(tcb->m_segmentSize)*(18.847));
ReduceCwnd (tcb);
cnt = (int) (0.1/80.344);
ReduceCwnd (tcb);
