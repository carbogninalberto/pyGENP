if (tcb->m_ssThresh != cnt) {
	tcb->m_segmentSize = (int) (39.141-(94.435)-(tcb->m_ssThresh)-(1.859));

} else {
	tcb->m_segmentSize = (int) (78.355+(83.891)+(15.833)+(6.792)+(20.468)+(34.104)+(2.904)+(cnt)+(tcb->m_segmentSize));
	segmentsAcked = (int) (23.517+(segmentsAcked)+(71.456));

}
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (43.062-(25.116)-(12.851)-(80.937));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (5.771-(70.548)-(50.537)-(cnt)-(2.989)-(tcb->m_segmentSize)-(segmentsAcked)-(20.429));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((13.13)+(30.641)+(88.204)+(0.1)+(0.1)+(10.34)+(0.1))/((0.1)+(0.1)));
