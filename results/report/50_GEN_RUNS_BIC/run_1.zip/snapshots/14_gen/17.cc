if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (71.15+(37.051)+(68.119)+(48.556));
ReduceCwnd (tcb);
float wGgjgoytCtaLITSe = (float) (13.196*(15.063)*(16.977)*(1.204)*(19.081)*(segmentsAcked)*(21.45)*(52.203));
ReduceCwnd (tcb);
wGgjgoytCtaLITSe = (float) (((19.089)+(0.1)+((49.844-(tcb->m_segmentSize)-(80.625)-(91.561)-(segmentsAcked)))+(1.866))/((99.336)));
