ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (30.996*(48.563)*(78.247));
	tcb->m_segmentSize = (int) (2.755+(70.892)+(81.341)+(61.579)+(21.382)+(3.943)+(tcb->m_segmentSize)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (segmentsAcked-(35.043));

} else {
	tcb->m_segmentSize = (int) (19.309+(72.059)+(2.354)+(77.578)+(32.469));
	tcb->m_segmentSize = (int) (0.538-(71.863)-(86.641)-(68.84));

}
