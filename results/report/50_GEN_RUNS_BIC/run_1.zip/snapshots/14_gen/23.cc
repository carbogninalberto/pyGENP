ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (cnt > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (91.448-(18.193)-(tcb->m_ssThresh)-(24.043));
	cnt = (int) ((((26.931-(40.758)-(61.823)-(57.028)-(tcb->m_segmentSize)-(segmentsAcked)-(18.607)-(95.851)-(33.644)))+(82.641)+(12.17)+(85.315))/((86.914)+(0.1)+(0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (0.1/(85.916+(27.379)+(tcb->m_cWnd)+(36.257)+(70.367)+(tcb->m_segmentSize)));

}
if (tcb->m_ssThresh >= cnt) {
	tcb->m_segmentSize = (int) (18.555+(10.262)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (81.263-(11.101)-(99.323)-(81.038)-(96.28)-(71.168)-(tcb->m_segmentSize)-(24.52));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(44.973)-(59.801)-(6.842)-(13.129));
	tcb->m_segmentSize = (int) (87.284*(segmentsAcked)*(24.404)*(94.58));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
