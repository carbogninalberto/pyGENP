float jfyfzppYSVknOqjz = (float) (24.235-(-83.909)-(-90.682)-(-12.173));
jfyfzppYSVknOqjz = (float) (90.917-(-46.26)-(-37.102)-(19.35)-(-25.039)-(-13.286)-(-21.801)-(-41.252)-(-38.181));
ReduceCwnd (tcb);
segmentsAcked = (int) (14.435-(-88.995)-(1.552)-(-60.525)-(-50.199)-(19.345)-(-36.508));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (84.07-(-53.427)-(73.068)-(9.967)-(51.609)-(28.26)-(-4.729));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
