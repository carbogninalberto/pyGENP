tcb->m_cWnd = (int) (55.835-(11.115));
if (tcb->m_ssThresh == cnt) {
	tcb->m_segmentSize = (int) (58.403+(55.41)+(cnt)+(43.224)+(62.373)+(96.858)+(48.375)+(28.609));

} else {
	tcb->m_segmentSize = (int) (13.178*(44.587)*(cnt));
	segmentsAcked = (int) (10.448*(29.778)*(17.246)*(31.195)*(10.22)*(49.996));
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (39.171+(72.647)+(36.518)+(57.916)+(56.981));
cnt = (int) (57.886-(6.261)-(51.972)-(5.976)-(67.212)-(59.389)-(29.162)-(6.89)-(99.74));
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (44.668*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) ((tcb->m_cWnd+(23.062)+(76.265)+(17.796)+(tcb->m_segmentSize))/(9.448+(21.967)+(30.748)+(67.093)+(tcb->m_segmentSize)));
	tcb->m_ssThresh = (int) (93.361*(3.499)*(tcb->m_cWnd)*(35.996));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
