tcb->m_cWnd = (int) ((((38.063+(41.66)+(98.251)))+(0.1)+(58.81)+(39.099))/((0.1)+(53.528)+(0.1)));
cnt = (int) (89.19-(tcb->m_cWnd)-(46.03));
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	segmentsAcked = (int) ((((80.461+(tcb->m_ssThresh)+(17.103)+(14.591)))+(54.594)+(84.722)+(19.801))/((0.1)+(30.964)+(19.973)));

} else {
	segmentsAcked = (int) (17.15-(81.9)-(26.946)-(tcb->m_cWnd)-(61.908)-(78.683)-(segmentsAcked));

}
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (84.514/93.404);
	tcb->m_cWnd = (int) (segmentsAcked-(31.346)-(44.772)-(37.919)-(97.921)-(65.062)-(tcb->m_cWnd)-(16.611));
	cnt = (int) (58.784-(tcb->m_cWnd)-(33.535)-(31.786)-(85.803)-(91.618));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (70.925*(84.493)*(cnt)*(23.595)*(10.683)*(36.314));
