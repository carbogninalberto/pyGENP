float EZsoOlqAgwPgRLld = (float) (8.795*(7.668)*(tcb->m_segmentSize));
if (cnt != segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(58.13)*(94.639));

} else {
	tcb->m_segmentSize = (int) (14.131+(67.484)+(77.881)+(45.375)+(16.265)+(47.903)+(19.854)+(2.038));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (17.553+(27.535)+(28.16)+(82.313)+(51.627)+(89.751)+(12.244)+(75.543)+(51.112));

} else {
	tcb->m_segmentSize = (int) (38.803+(66.326));

}
tcb->m_cWnd = (int) (21.789-(46.858)-(37.755)-(EZsoOlqAgwPgRLld)-(94.825)-(20.099)-(20.759)-(29.088));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
