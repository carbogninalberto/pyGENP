tcb->m_cWnd = (int) (39.223+(40.855)+(17.336));
tcb->m_segmentSize = (int) (17.804+(2.066)+(45.093));
if (tcb->m_ssThresh == segmentsAcked) {
	cnt = (int) ((9.062+(28.467)+(65.711))/0.1);

} else {
	cnt = (int) (7.39+(94.793)+(54.243)+(cnt)+(52.416)+(53.418)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(23.313));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= cnt) {
	segmentsAcked = (int) (86.13+(15.502)+(2.989)+(67.741)+(68.061)+(31.021)+(73.944));
	tcb->m_cWnd = (int) (31.984/22.935);

} else {
	segmentsAcked = (int) (69.091-(71.564)-(71.42)-(56.754)-(45.284));

}
