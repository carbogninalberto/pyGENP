ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (32.377*(cnt)*(4.573)*(51.201)*(79.655)*(3.237)*(32.295)*(segmentsAcked));
tcb->m_cWnd = (int) (66.97+(39.803)+(53.357));
segmentsAcked = (int) (70.113*(90.514)*(25.167)*(cnt)*(63.871)*(tcb->m_cWnd)*(94.906)*(83.416)*(57.739));
ReduceCwnd (tcb);
if (cnt <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (96.194*(78.022)*(33.11)*(5.096)*(89.781)*(6.178));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(43.435)*(88.183)*(95.892)*(32.149)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (41.179+(37.241)+(14.769));

}
