tcb->m_cWnd = (int) (7.715-(32.29)-(0.806));
tcb->m_ssThresh = (int) (5.025-(tcb->m_segmentSize)-(13.876)-(96.634)-(73.42)-(81.436)-(tcb->m_cWnd)-(62.718)-(49.971));
segmentsAcked = (int) (64.977-(segmentsAcked)-(37.599));
int HbHLrvqaZvJvJhKl = (int) (tcb->m_ssThresh+(64.854));
ReduceCwnd (tcb);
