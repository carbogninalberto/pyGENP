float kpwafNkWBjBlbbuz = (float) (50.78+(23.116)+(-25.631)+(-94.064)+(86.201)+(-8.574)+(55.144)+(26.644)+(39.869));
int taSbqywLwQaKGICe = (int) (33.856*(3.434)*(1.865));
int FGgjHwpfIkNDEEry = (int) (-91.821*(-85.965)*(-43.759)*(14.642)*(49.946)*(-6.311));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (41.938*(35.684)*(-38.594)*(12.956)*(62.888));
tcb->m_cWnd = (int) (-76.957*(43.409)*(-52.577)*(40.899)*(-4.066));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-19.907*(-43.794)*(-85.075)*(-14.701)*(27.644)*(-12.508));
segmentsAcked = (int) (64.784*(46.442)*(-34.892)*(27.994)*(88.58)*(11.356));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-31.078*(-6.991)*(98.818)*(45.934)*(28.837)*(29.568));
segmentsAcked = (int) (91.144*(-86.63)*(16.523)*(14.995)*(4.506)*(54.992));
