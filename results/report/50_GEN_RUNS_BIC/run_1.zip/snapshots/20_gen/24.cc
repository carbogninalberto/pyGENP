if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_cWnd = (int) (42.284-(1.803)-(80.207)-(39.338)-(50.912));

} else {
	tcb->m_cWnd = (int) (88.871/66.084);
	ReduceCwnd (tcb);

}
if (segmentsAcked <= cnt) {
	tcb->m_cWnd = (int) (13.724*(70.457));
	tcb->m_cWnd = (int) (45.602-(tcb->m_cWnd)-(79.867)-(17.363)-(7.619)-(26.587));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(cnt)*(52.209)*(cnt)*(tcb->m_segmentSize)*(18.663)*(cnt)*(92.628)*(96.359));
	tcb->m_segmentSize = (int) (((65.891)+(76.271)+((tcb->m_cWnd-(96.9)-(85.56)-(66.122)-(87.762)-(29.422)))+((tcb->m_segmentSize*(13.864)))+(0.1)+(20.893))/((0.1)+(0.1)+(0.1)));
	tcb->m_segmentSize = (int) (35.341*(76.034)*(57.993));

}
tcb->m_cWnd = (int) (85.453+(38.151)+(99.543)+(91.588)+(21.337)+(78.809)+(43.256)+(49.941));
tcb->m_segmentSize = (int) (14.052/0.1);
tcb->m_segmentSize = (int) (10.094-(36.544)-(6.892)-(tcb->m_segmentSize)-(99.995)-(73.563));
cnt = (int) (7.805*(19.381)*(66.75));
tcb->m_segmentSize = (int) (76.592*(69.344));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
