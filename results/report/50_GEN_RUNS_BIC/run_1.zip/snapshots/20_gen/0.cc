int fosOvHsaAgNhKIqh = (int) (95.371-(-96.233)-(-77.37)-(-90.946)-(-54.197)-(41.211)-(-32.364)-(72.642)-(72.202));
ReduceCwnd (tcb);
segmentsAcked = (int) (-25.403/-88.598);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
