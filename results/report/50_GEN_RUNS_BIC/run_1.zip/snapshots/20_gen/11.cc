int TgJxDUscrhQzlcOa = (int) (38.963-(-57.567)-(17.813)-(-38.374)-(85.238)-(-87.522)-(81.0));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int aAeEZdoguFVFGtKZ = (int) 88.2;
TgJxDUscrhQzlcOa = (int) (31.544-(-86.765)-(-17.245)-(-4.172)-(-96.819)-(-63.846)-(0.78)-(-20.623)-(-7.239));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (57.913*(74.455)*(39.143)*(3.288)*(aAeEZdoguFVFGtKZ)*(aAeEZdoguFVFGtKZ)*(89.185));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (67.939-(aAeEZdoguFVFGtKZ)-(95.826)-(27.941)-(93.926)-(TgJxDUscrhQzlcOa)-(47.319)-(62.706));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
