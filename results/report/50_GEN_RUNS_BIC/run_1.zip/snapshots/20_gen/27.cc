cnt = (int) (89.131/0.1);
float ByGyGExSQqOjUitW = (float) (62.073*(98.114)*(tcb->m_cWnd)*(83.467)*(26.111)*(segmentsAcked)*(92.068));
int hSvXnnjGcztCVslb = (int) (63.995-(23.552)-(29.328)-(70.677)-(41.462)-(37.527));
tcb->m_ssThresh = (int) ((((93.116-(tcb->m_segmentSize)-(tcb->m_cWnd)-(69.807)-(8.898)-(33.597)-(23.027)-(98.815)-(79.141)))+(0.1)+(0.1)+(13.574))/((23.809)));
float SylLeyeghnYxsCey = (float) (cnt+(47.822)+(96.122)+(ByGyGExSQqOjUitW)+(23.223)+(tcb->m_cWnd));
