tcb->m_segmentSize = (int) ((83.738-(tcb->m_segmentSize)-(tcb->m_cWnd)-(22.377)-(49.527))/0.1);
if (cnt != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/21.62);
	segmentsAcked = (int) (38.768-(99.651)-(22.063)-(64.682)-(34.731)-(segmentsAcked)-(56.296)-(29.397)-(23.185));

} else {
	tcb->m_ssThresh = (int) (0.1/74.069);

}
ReduceCwnd (tcb);
int shHBTVPzrBIPoCrx = (int) (segmentsAcked+(12.303)+(60.374)+(42.931)+(5.784));
tcb->m_cWnd = (int) (cnt*(38.616)*(93.274)*(63.049)*(78.611)*(shHBTVPzrBIPoCrx));
if (shHBTVPzrBIPoCrx == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (67.217*(80.22));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (96.35+(68.613)+(35.673));
	tcb->m_segmentSize = (int) (0.1/87.246);
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh < cnt) {
	tcb->m_ssThresh = (int) (((32.522)+(0.1)+((55.063*(1.938)*(5.421)*(cnt)*(4.461)))+(63.755)+((tcb->m_ssThresh-(6.258)-(72.461)-(65.38)-(64.465)-(tcb->m_ssThresh)))+(0.1)+(0.1)+(0.1))/((30.691)));
	cnt = (int) (tcb->m_cWnd+(65.728));

} else {
	tcb->m_ssThresh = (int) (34.428-(tcb->m_cWnd)-(83.008)-(tcb->m_segmentSize)-(9.263));
	tcb->m_segmentSize = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
