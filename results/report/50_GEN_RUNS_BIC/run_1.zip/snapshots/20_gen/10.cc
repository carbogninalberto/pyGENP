int LDyGISmCFmLdFfke = (int) (-50.958-(74.123));
tcb->m_segmentSize = (int) (67.057*(-89.63)*(-9.949));
segmentsAcked = (int) (64.783-(-66.399));
