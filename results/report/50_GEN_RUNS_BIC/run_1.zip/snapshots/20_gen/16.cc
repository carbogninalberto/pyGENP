cnt = (int) (tcb->m_segmentSize-(37.954)-(8.117)-(5.94)-(0.664)-(98.176)-(58.781)-(cnt)-(59.416));
segmentsAcked = (int) (16.455+(39.959)+(tcb->m_cWnd)+(80.148)+(24.525)+(85.039)+(46.746));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_segmentSize = (int) (11.974*(47.836)*(99.799)*(27.293)*(81.997)*(tcb->m_ssThresh)*(8.699));

} else {
	tcb->m_segmentSize = (int) (24.789+(72.737)+(4.598)+(31.432)+(81.381)+(48.337)+(tcb->m_segmentSize)+(15.266));

}
int WhhDzWMhWySsIzPI = (int) (0.1/14.471);
