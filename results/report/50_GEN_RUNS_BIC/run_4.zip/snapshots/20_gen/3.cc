ReduceCwnd (tcb);
int weJPkFwyPcequUBr = (int) 60.846;
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

}
segmentsAcked = (int) (28.492-(-70.857)-(75.288)-(-25.262)-(-67.241)-(-90.235)-(-48.161)-(66.24)-(-54.123));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (66.518-(71.711)-(39.143)-(64.249)-(82.219)-(2.145)-(-21.655)-(70.145)-(-18.036));
segmentsAcked = (int) (18.586-(-71.618)-(66.522)-(86.778)-(-7.504)-(31.484)-(-59.893)-(-25.803)-(85.141));
segmentsAcked = (int) (26.54-(97.45)-(-88.274)-(76.198)-(48.543)-(23.795)-(76.963)-(-92.442)-(44.387));
segmentsAcked = (int) (58.688-(-94.368)-(86.877)-(69.566)-(-39.674)-(-99.083)-(-44.942)-(90.494)-(14.728));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-96.499-(-44.407)-(35.456)-(13.139)-(-53.507)-(12.102)-(21.206)-(-38.123)-(90.943));
segmentsAcked = (int) (84.157-(-6.789)-(71.235)-(47.137)-(-6.808)-(-44.731)-(1.971)-(49.586)-(75.335));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

}
segmentsAcked = (int) (55.541-(-43.836)-(-57.94)-(-0.238)-(-94.392)-(97.627)-(-34.458)-(71.716)-(-49.043));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-50.797-(22.296)-(-41.275)-(-30.128)-(-75.108)-(76.419)-(80.009)-(25.134)-(17.69));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-75.382-(51.331)-(-29.884)-(30.752)-(79.139)-(60.345)-(70.439)-(51.736)-(-50.051));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (99.451-(30.277)-(-49.175)-(-42.477)-(-95.509)-(-14.637)-(41.096)-(12.792)-(-20.348));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (65.965-(-47.626)-(54.018)-(81.033)-(7.543)-(6.182)-(-55.789)-(-17.179)-(49.523));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-48.395-(93.739)-(-13.787)-(16.025)-(71.612)-(21.88)-(69.004)-(-51.844)-(-54.9));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-99.872-(-8.99)-(8.035)-(-96.769)-(-91.498)-(16.867)-(58.669)-(15.981)-(41.037));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
