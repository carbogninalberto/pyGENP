tcb->m_cWnd = (int) (-20.41+(63.1)+(3.149));
float HIzLWXbkcRJeOHHQ = (float) (4.11+(-85.169)+(-72.151));
tcb->m_cWnd = (int) (-38.723*(50.002));
int rBemAXgUhFjBNhgn = (int) (-30.453+(-54.939)+(72.323)+(15.23)+(60.571)+(-0.706)+(52.544)+(-34.132)+(-80.581));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (60.397*(-86.819));
tcb->m_segmentSize = (int) (36.91+(-65.073)+(-72.837)+(-59.861)+(0.262)+(-39.28)+(70.696));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (24.767+(20.063)+(-90.67)+(93.77)+(-34.103)+(84.959)+(96.839));
