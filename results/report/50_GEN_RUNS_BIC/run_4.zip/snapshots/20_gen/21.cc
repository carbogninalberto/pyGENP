tcb->m_segmentSize = (int) (-75.167*(54.236)*(4.734)*(90.941)*(76.656));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
int HopDHElqlBhbfUsj = (int) (17.578+(59.677)+(-34.128)+(76.839)+(-88.927));
int MRWyGXOyFlgriPig = (int) (22.823+(19.907));
