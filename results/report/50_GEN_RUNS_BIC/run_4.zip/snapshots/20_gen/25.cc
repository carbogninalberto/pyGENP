float oWvzdQndsvZmWwrn = (float) (79.858-(0.935)-(-66.279)-(45.551)-(-64.961)-(94.805)-(19.01));
float ekaxfSCCObIAwCul = (float) (-1.567*(-43.019)*(-33.511)*(42.606)*(-97.44)*(69.545)*(-11.56)*(25.775));
segmentsAcked = (int) (73.559*(-3.447)*(47.703)*(-49.965)*(68.69)*(-20.448)*(-6.666)*(38.247));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-82.737*(-96.135)*(-50.603)*(15.877));
tcb->m_segmentSize = (int) (20.877*(24.145)*(39.877)*(-86.324));
