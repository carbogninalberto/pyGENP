float bWLLtidqwsKdssKQ = (float) 99.954;
tcb->m_cWnd = (int) (((97.328)+(80.304)+(14.927)+(6.422))/((-31.459)+(71.781)+(62.525)+(91.664)+(22.311)));
tcb->m_segmentSize = (int) (-68.123-(33.714)-(-62.819)-(88.174)-(2.728)-(80.082)-(99.8));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
