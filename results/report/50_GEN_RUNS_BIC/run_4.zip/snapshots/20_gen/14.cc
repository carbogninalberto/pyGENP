int riyNRSEtlNcLmbcs = (int) (-99.889+(92.288));
segmentsAcked = (int) (70.677*(6.955)*(-46.41)*(-79.561));
if (segmentsAcked > riyNRSEtlNcLmbcs) {
	tcb->m_segmentSize = (int) (93.069+(51.292)+(19.337)+(segmentsAcked)+(-1.706)+(tcb->m_cWnd)+(65.697));

} else {
	tcb->m_segmentSize = (int) (46.781*(tcb->m_cWnd));

}
ReduceCwnd (tcb);
