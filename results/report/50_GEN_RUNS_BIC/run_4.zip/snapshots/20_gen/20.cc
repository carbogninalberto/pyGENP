ReduceCwnd (tcb);
int MRWyGXOyFlgriPig = (int) (-77.068+(14.159));
tcb->m_segmentSize = (int) (68.8*(-24.525)*(-70.507)*(32.779)*(6.009));
tcb->m_segmentSize = (int) (18.578*(-66.531)*(36.939)*(-14.232)*(40.033));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
