float ekaxfSCCObIAwCul = (float) (19.818*(-82.51)*(27.119)*(75.59)*(58.679)*(-78.446)*(5.343)*(75.585));
float ovhazqaaCchFcUhn = (float) (44.069-(54.969)-(-9.54)-(70.475));
