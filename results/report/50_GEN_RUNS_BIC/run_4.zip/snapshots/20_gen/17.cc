ReduceCwnd (tcb);
float bWLLtidqwsKdssKQ = (float) 43.848;
tcb->m_cWnd = (int) (((-82.461)+(-8.856)+(8.957)+(27.545))/((51.401)+(-57.307)+(79.124)+(-10.75)+(-18.102)));
tcb->m_segmentSize = (int) (-15.193-(26.915)-(-18.362)-(71.149)-(8.8)-(52.565)-(48.785));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
