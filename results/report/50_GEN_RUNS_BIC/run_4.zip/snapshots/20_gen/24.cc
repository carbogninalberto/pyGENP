float oWvzdQndsvZmWwrn = (float) (23.266-(-1.979)-(56.269)-(57.191)-(43.45)-(-35.559)-(0.276));
float ekaxfSCCObIAwCul = (float) (-12.567*(-30.846)*(15.685)*(-11.172)*(-14.085)*(-8.865)*(-31.639)*(92.152));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-53.918*(-37.945)*(-16.403)*(-43.833));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
