float NPRwagzOvzHFwTuX = (float) (30.261-(46.776)-(95.53));
int MnlxgQkFRflpGsUg = (int) (33.581*(-82.258)*(89.073)*(-87.849)*(22.572)*(98.99));
tcb->m_segmentSize = (int) (72.913-(-31.882)-(13.381)-(-37.504)-(-86.247)-(-10.66));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
