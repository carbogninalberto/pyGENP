if (segmentsAcked <= segmentsAcked) {
	segmentsAcked = (int) ((59.247-(tcb->m_segmentSize)-(78.494)-(segmentsAcked)-(tcb->m_segmentSize)-(cnt)-(cnt))/0.1);
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(24.948));

} else {
	segmentsAcked = (int) (36.67*(7.084));

}
tcb->m_segmentSize = (int) (-47.13*(98.154)*(-77.633)*(-86.981)*(-25.491));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (97.333*(-9.517)*(58.174)*(-70.278)*(89.54));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
