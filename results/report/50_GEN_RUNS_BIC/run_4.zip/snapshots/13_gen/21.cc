ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (23.538/0.1);
	cnt = (int) (56.823-(54.794)-(87.278)-(85.133)-(48.803)-(47.456)-(77.807));

} else {
	tcb->m_cWnd = (int) (69.462-(55.37)-(11.79)-(71.985)-(97.341)-(92.573));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(86.806)*(9.656)*(90.999)*(90.222)*(67.715)*(22.576)*(35.872)*(tcb->m_cWnd));

}
if (tcb->m_cWnd < cnt) {
	tcb->m_ssThresh = (int) (87.897+(54.403)+(25.053)+(41.717)+(1.902));
	segmentsAcked = (int) (tcb->m_ssThresh-(34.576)-(17.664)-(12.649));
	tcb->m_segmentSize = (int) (11.295+(70.593)+(66.134)+(90.422)+(7.724)+(44.616)+(tcb->m_segmentSize)+(49.696)+(73.985));

} else {
	tcb->m_ssThresh = (int) (54.776-(54.201)-(tcb->m_ssThresh)-(23.467));
	tcb->m_cWnd = (int) (65.523*(84.04));

}
if (tcb->m_cWnd <= cnt) {
	tcb->m_segmentSize = (int) (29.249+(30.157)+(59.35)+(tcb->m_cWnd)+(77.937)+(23.778));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (56.815-(75.219)-(97.526)-(91.093)-(cnt)-(tcb->m_segmentSize)-(14.326));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (tcb->m_segmentSize-(38.84)-(64.144)-(69.356)-(72.809)-(86.111)-(65.314)-(4.884));
