if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_ssThresh = (int) (33.443+(tcb->m_ssThresh)+(0.724)+(tcb->m_segmentSize)+(segmentsAcked)+(53.353));

} else {
	tcb->m_ssThresh = (int) (33.393-(segmentsAcked)-(tcb->m_cWnd)-(79.323)-(19.383)-(1.123));
	cnt = (int) (80.913-(tcb->m_segmentSize)-(63.315)-(8.965)-(tcb->m_segmentSize)-(cnt)-(17.652)-(35.936)-(34.357));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= tcb->m_segmentSize) {
	segmentsAcked = (int) (((0.1)+(93.319)+(0.1)+(42.155))/((0.1)));
	tcb->m_segmentSize = (int) (0.1/11.6);

} else {
	segmentsAcked = (int) ((((tcb->m_cWnd+(81.945)+(47.549)+(tcb->m_segmentSize)+(47.952)+(52.241)+(70.431)))+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)));
	tcb->m_segmentSize = (int) (50.52+(17.332)+(41.305)+(47.035)+(12.558));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_segmentSize-(23.383)-(36.673));
segmentsAcked = (int) (((64.676)+(16.292)+(0.1)+(0.1)+(0.1))/((23.433)));
