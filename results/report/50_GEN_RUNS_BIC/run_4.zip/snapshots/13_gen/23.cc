if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_cWnd*(16.601)*(35.237));
	tcb->m_cWnd = (int) (40.098+(cnt)+(17.435)+(56.145)+(26.196)+(11.908)+(8.202));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (53.518+(94.842)+(80.26)+(71.182));
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (((71.674)+(0.1)+(0.1)+((66.532*(75.635)*(66.763)*(61.068)*(25.979)*(12.793)))+(23.356)+(43.081)+(0.1))/((6.409)+(57.746)));

}
tcb->m_ssThresh = (int) (((42.464)+(0.1)+(69.182)+(0.1))/((0.1)+(0.1)+(0.1)+(69.558)+(9.195)));
ReduceCwnd (tcb);
int NjfXMmQmVzTmJxJc = (int) (98.133*(30.655)*(44.712)*(13.276)*(57.491)*(segmentsAcked)*(76.888)*(7.788));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= cnt) {
	NjfXMmQmVzTmJxJc = (int) (4.4*(35.129)*(cnt)*(29.87)*(75.268)*(9.532)*(86.638)*(46.709)*(40.284));
	tcb->m_cWnd = (int) (81.722-(98.798)-(tcb->m_cWnd)-(28.136)-(26.635));

} else {
	NjfXMmQmVzTmJxJc = (int) (96.685*(79.632)*(96.624)*(25.388)*(58.537));
	tcb->m_ssThresh = (int) (86.346+(segmentsAcked)+(22.878)+(41.78)+(tcb->m_ssThresh)+(49.145)+(82.967)+(27.551));

}
segmentsAcked = (int) (11.944-(85.068));
