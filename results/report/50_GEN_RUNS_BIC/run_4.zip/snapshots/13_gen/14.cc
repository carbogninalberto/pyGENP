tcb->m_segmentSize = (int) (41.964-(-35.814)-(58.709)-(55.867)-(-84.589)-(50.063)-(78.231)-(-31.017));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (4.302+(-98.975)+(29.297)+(-95.191)+(-63.073)+(-73.681)+(-37.334)+(-71.428));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
