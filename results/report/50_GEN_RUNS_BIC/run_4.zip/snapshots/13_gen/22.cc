if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (28.848+(tcb->m_segmentSize)+(84.822)+(segmentsAcked)+(20.406));

} else {
	tcb->m_segmentSize = (int) (((9.678)+(0.1)+((82.638-(37.543)-(52.772)-(97.509)-(54.928)-(24.91)-(57.88)-(35.005)-(46.073)))+((62.467*(13.151)*(cnt)))+(0.1))/((72.153)));
	segmentsAcked = (int) (tcb->m_ssThresh-(tcb->m_segmentSize)-(46.699)-(30.454)-(28.769)-(6.121)-(28.935)-(71.852)-(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (87.483-(segmentsAcked)-(11.706)-(98.952)-(71.743)-(26.235)-(74.329)-(17.656)-(13.513));
tcb->m_segmentSize = (int) (0.1/64.756);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
