tcb->m_ssThresh = (int) (segmentsAcked-(62.897)-(54.815)-(tcb->m_segmentSize));
cnt = (int) (83.041+(87.109)+(51.391)+(13.391)+(tcb->m_ssThresh));
int HzvrSnlkKNJARLrq = (int) (9.469-(47.97)-(11.829));
if (segmentsAcked < tcb->m_cWnd) {
	HzvrSnlkKNJARLrq = (int) (((32.051)+(50.328)+(0.1)+(83.238)+(0.1)+(84.102))/((72.91)+(23.445)));
	tcb->m_segmentSize = (int) (95.313-(63.515)-(cnt)-(66.088)-(89.919));
	segmentsAcked = (int) (((0.1)+(0.1)+(60.578)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(37.474)));

} else {
	HzvrSnlkKNJARLrq = (int) (54.81+(87.409));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (((84.317)+(0.1)+(88.258)+(0.1)+((88.369+(47.994)+(61.715)+(73.485)+(44.109)+(12.718)))+(29.05))/((22.851)));
tcb->m_cWnd = (int) (95.862*(segmentsAcked)*(96.856)*(2.857)*(62.824));
ReduceCwnd (tcb);
