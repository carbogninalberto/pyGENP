if (segmentsAcked == cnt) {
	cnt = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (54.434*(16.108)*(13.705)*(57.773)*(tcb->m_cWnd)*(30.893)*(tcb->m_segmentSize));

} else {
	cnt = (int) (19.91+(13.321)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(82.248)+(tcb->m_segmentSize)+(59.637));

}
tcb->m_segmentSize = (int) (96.434-(38.785)-(27.878)-(86.19)-(tcb->m_cWnd)-(32.244)-(tcb->m_ssThresh)-(33.976));
if (tcb->m_ssThresh < tcb->m_cWnd) {
	cnt = (int) (tcb->m_ssThresh+(12.644)+(tcb->m_segmentSize)+(21.513));
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (4.475-(segmentsAcked));

} else {
	cnt = (int) (93.301/0.1);

}
ReduceCwnd (tcb);
if (segmentsAcked != cnt) {
	segmentsAcked = (int) (tcb->m_segmentSize+(tcb->m_ssThresh)+(73.876)+(tcb->m_segmentSize)+(92.989)+(segmentsAcked)+(tcb->m_ssThresh)+(2.319)+(34.541));

} else {
	segmentsAcked = (int) (21.857+(tcb->m_ssThresh)+(27.304)+(39.188)+(32.726)+(72.74)+(37.019)+(11.62));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (97.494*(5.251)*(89.741));

}
tcb->m_cWnd = (int) (78.354+(20.589)+(85.151)+(36.109)+(tcb->m_ssThresh)+(79.089));
tcb->m_ssThresh = (int) (33.544+(segmentsAcked)+(69.078)+(45.466)+(49.923)+(9.077));
