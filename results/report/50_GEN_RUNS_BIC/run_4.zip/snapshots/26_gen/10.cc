if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_cWnd = (int) (85.734*(tcb->m_segmentSize)*(34.837)*(14.024)*(24.036)*(55.276)*(68.934)*(cnt));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (56.778/(42.556-(69.283)-(40.359)-(37.699)-(34.624)-(9.287)-(19.419)-(53.505)-(tcb->m_cWnd)));

} else {
	tcb->m_cWnd = (int) (77.368+(21.195)+(22.648)+(70.903)+(48.163)+(80.345)+(18.936)+(85.864));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (82.627+(cnt)+(40.941)+(86.503)+(95.719)+(83.82)+(tcb->m_cWnd));

}
if (tcb->m_segmentSize > cnt) {
	tcb->m_segmentSize = (int) (51.986+(78.977)+(38.353)+(48.128)+(18.889)+(89.959));

} else {
	tcb->m_segmentSize = (int) (69.922+(63.174)+(19.643)+(17.086)+(40.176)+(tcb->m_ssThresh)+(segmentsAcked)+(62.711));
	tcb->m_cWnd = (int) (1.863/0.1);
	tcb->m_ssThresh = (int) ((((segmentsAcked-(57.96)-(42.882)-(12.825)-(24.303)-(97.338)-(69.288)))+(40.261)+(0.1)+(0.1)+(0.1)+((44.577*(47.698)*(32.823)))+(0.1))/((20.355)));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (segmentsAcked >= cnt) {
	segmentsAcked = (int) ((((36.009-(40.05)-(tcb->m_cWnd)))+(0.1)+(64.798)+(0.1))/((22.143)+(0.1)+(0.1)));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) ((((93.819+(85.501)+(14.19)+(32.02)))+(86.394)+(0.1)+((10.083-(tcb->m_ssThresh)-(cnt)-(45.301)-(14.442)-(80.474)-(tcb->m_ssThresh)))+(96.135)+(92.021))/((0.1)));

}
if (cnt >= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (50.538*(tcb->m_cWnd)*(23.11)*(9.14)*(17.117));
	tcb->m_cWnd = (int) (39.824-(31.203)-(22.666)-(99.543)-(56.531));
	tcb->m_cWnd = (int) (((2.013)+((92.991+(tcb->m_cWnd)+(9.105)+(tcb->m_segmentSize)+(tcb->m_ssThresh)))+(39.778)+(99.45))/((0.1)+(11.013)+(0.1)+(39.015)+(96.36)));

}
