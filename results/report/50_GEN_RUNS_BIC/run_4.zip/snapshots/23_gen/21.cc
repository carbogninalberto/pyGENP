ReduceCwnd (tcb);
cnt = (int) (50.144-(tcb->m_cWnd)-(cnt)-(20.042));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
int UDxsxmIlkmmkSgiN = (int) (36.4-(37.549)-(tcb->m_cWnd)-(10.092)-(41.53));
float aCkqbmrgixINfkxM = (float) (73.167+(UDxsxmIlkmmkSgiN));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
