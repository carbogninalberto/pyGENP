tcb->m_ssThresh = (int) (tcb->m_segmentSize*(25.204)*(tcb->m_ssThresh)*(22.442)*(7.89));
cnt = (int) (21.268+(66.772)+(83.168)+(47.807)+(86.429));
if (cnt >= segmentsAcked) {
	segmentsAcked = (int) (tcb->m_ssThresh+(90.939)+(tcb->m_cWnd)+(51.39)+(74.216)+(54.071)+(cnt)+(91.91)+(56.713));

} else {
	segmentsAcked = (int) (tcb->m_cWnd+(21.385)+(71.186)+(66.476));
	tcb->m_cWnd = (int) (77.023-(41.426)-(4.401)-(65.176)-(55.691));

}
int upddBJgjPkfZbUXq = (int) (39.688*(97.6)*(56.976)*(18.497)*(tcb->m_ssThresh)*(21.086)*(5.177));
segmentsAcked = (int) (31.452+(85.022)+(73.864)+(tcb->m_cWnd)+(94.272)+(74.028));
