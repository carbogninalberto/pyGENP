int fnVkghPfeovZMRSd = (int) (68.811*(56.276)*(11.109)*(cnt)*(24.091)*(86.498));
ReduceCwnd (tcb);
if (tcb->m_ssThresh == cnt) {
	tcb->m_cWnd = (int) (12.857/44.975);
	tcb->m_cWnd = (int) (13.951+(97.557)+(87.594)+(6.984)+(14.987)+(13.767)+(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (16.118*(55.433)*(61.648)*(tcb->m_segmentSize)*(30.785)*(31.048));

}
tcb->m_cWnd = (int) (9.546-(9.156)-(56.448));
if (cnt > fnVkghPfeovZMRSd) {
	fnVkghPfeovZMRSd = (int) (45.553-(57.486)-(36.677)-(46.919)-(segmentsAcked)-(26.359)-(66.002)-(98.962)-(7.203));

} else {
	fnVkghPfeovZMRSd = (int) (51.547*(25.566)*(33.443)*(69.969)*(69.851)*(70.853)*(tcb->m_segmentSize));

}
if (tcb->m_ssThresh == fnVkghPfeovZMRSd) {
	tcb->m_ssThresh = (int) (73.776*(tcb->m_ssThresh)*(52.461)*(53.315)*(17.722)*(98.642)*(38.318)*(60.058));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (79.292+(49.689)+(57.9)+(25.201)+(7.115)+(99.354));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
