tcb->m_segmentSize = (int) (-39.849*(71.651)*(-70.158)*(-61.262)*(-47.144));
ReduceCwnd (tcb);
