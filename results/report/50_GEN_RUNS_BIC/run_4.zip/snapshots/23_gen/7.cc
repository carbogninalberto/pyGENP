int suwTABCcTwKmpDqe = (int) (69.727-(3.003)-(-5.196)-(91.451)-(-53.258));
