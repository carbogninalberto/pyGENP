float rwMLUdeeGUnomjAc = (float) (((0.1)+(24.333)+(93.813)+(0.1)+(97.057)+(0.1)+(0.1))/((0.1)));
if (tcb->m_segmentSize != cnt) {
	segmentsAcked = (int) (73.609/0.1);
	cnt = (int) (segmentsAcked*(71.572)*(5.095)*(18.075)*(rwMLUdeeGUnomjAc)*(13.587));

} else {
	segmentsAcked = (int) (22.396+(88.825));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) ((23.741-(9.771)-(11.968)-(50.958))/67.806);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((95.193+(rwMLUdeeGUnomjAc)+(13.124)+(37.478)+(tcb->m_ssThresh)+(42.911)+(segmentsAcked)+(66.534)+(42.764))/81.614);
	segmentsAcked = (int) ((((28.63+(85.209)+(64.397)+(79.263)+(30.725)+(44.368)+(21.888)+(segmentsAcked)))+(42.537)+(86.877)+(44.04))/((82.37)+(0.1)+(38.798)+(0.1)+(98.5)));

} else {
	tcb->m_cWnd = (int) (18.53*(97.327)*(40.534)*(75.627)*(75.765)*(segmentsAcked)*(44.679)*(70.957)*(rwMLUdeeGUnomjAc));
	tcb->m_segmentSize = (int) (segmentsAcked+(cnt)+(21.531)+(32.656)+(97.81)+(20.417)+(38.231));
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh == cnt) {
	tcb->m_ssThresh = (int) (63.309+(42.839)+(70.119)+(59.78)+(31.747)+(32.215)+(34.185));
	tcb->m_segmentSize = (int) (52.032*(tcb->m_ssThresh)*(11.176));

} else {
	tcb->m_ssThresh = (int) (83.075/0.1);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) ((98.334-(24.767))/0.1);

}
int gKhmPSALubndUiRy = (int) (tcb->m_ssThresh-(82.412)-(95.728)-(31.305)-(81.851)-(20.133)-(14.358)-(14.045));
