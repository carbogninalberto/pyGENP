if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > segmentsAcked) {
	segmentsAcked = (int) (98.727-(3.015)-(40.484)-(74.372)-(68.994));

} else {
	segmentsAcked = (int) (48.003-(85.742)-(85.727)-(15.185)-(91.455)-(65.745));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	segmentsAcked = (int) ((87.322-(70.139))/53.243);
	tcb->m_cWnd = (int) (74.78-(78.457)-(0.67)-(87.57)-(68.916)-(82.403)-(57.126)-(4.723));

} else {
	segmentsAcked = (int) (67.031-(cnt)-(tcb->m_cWnd)-(40.352));
	cnt = (int) (97.511/0.1);
	tcb->m_ssThresh = (int) (89.805*(48.957)*(3.192)*(99.883)*(37.789)*(27.192)*(40.785)*(99.219));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (27.883+(11.151)+(83.76)+(2.41)+(83.812)+(16.098)+(79.99));
	cnt = (int) (85.01/30.56);

} else {
	tcb->m_ssThresh = (int) (cnt+(tcb->m_cWnd)+(64.557)+(77.56)+(14.749)+(60.351));
	segmentsAcked = (int) (((0.1)+(7.244)+((9.466+(cnt)+(6.959)+(52.702)+(cnt)+(67.672)))+(91.625))/((60.315)));

}
