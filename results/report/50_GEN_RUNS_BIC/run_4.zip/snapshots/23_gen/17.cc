if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (75.17-(35.62)-(75.602)-(2.904)-(82.737)-(87.64)-(tcb->m_segmentSize));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (46.456*(33.053)*(13.36)*(cnt)*(9.043)*(segmentsAcked)*(67.628));
