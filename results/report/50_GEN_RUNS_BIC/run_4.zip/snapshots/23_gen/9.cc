int KCLKunIpGyXNrVId = (int) (69.534*(-90.757)*(-20.177)*(86.828)*(-68.751)*(-24.833)*(-48.379)*(-22.015));
int xLqerYcFgXUuxcDT = (int) (12.372*(-72.271)*(46.795)*(40.113)*(69.631)*(-39.263)*(16.482)*(-39.576)*(96.728));
int qdYiNDNqqTGEwIqV = (int) (-29.953*(65.113));
if (qdYiNDNqqTGEwIqV <= segmentsAcked) {
	xLqerYcFgXUuxcDT = (int) (70.004-(37.742)-(59.13));

} else {
	xLqerYcFgXUuxcDT = (int) (70.139-(7.706));
	qdYiNDNqqTGEwIqV = (int) (59.871+(58.004)+(3.311)+(51.838));
	tcb->m_cWnd = (int) (0.1/0.1);

}
segmentsAcked = (int) ((71.629+(87.499)+(62.747))/21.926);
qdYiNDNqqTGEwIqV = (int) (27.48/-75.682);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
