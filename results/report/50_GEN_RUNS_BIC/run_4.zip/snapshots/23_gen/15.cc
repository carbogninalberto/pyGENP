tcb->m_segmentSize = (int) (2.037*(1.889)*(21.209)*(11.955)*(22.512)*(69.92)*(37.05)*(46.601)*(69.271));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (segmentsAcked+(72.63)+(0.924)+(59.451)+(cnt)+(65.177));
tcb->m_ssThresh = (int) (73.641-(98.616)-(98.424));
