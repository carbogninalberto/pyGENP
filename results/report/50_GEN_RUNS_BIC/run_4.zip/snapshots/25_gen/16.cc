if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= cnt) {
	tcb->m_segmentSize = (int) (44.895*(95.71)*(6.802)*(23.968)*(9.301)*(45.644));

} else {
	tcb->m_segmentSize = (int) (6.748-(tcb->m_segmentSize)-(12.287)-(77.09)-(12.764)-(69.109)-(cnt)-(52.376));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(99.294));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (94.014*(94.452)*(72.384));
tcb->m_segmentSize = (int) (79.737*(tcb->m_cWnd)*(2.281)*(38.071)*(34.311)*(32.156));
