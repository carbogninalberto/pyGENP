int rPbeKeXDuLBChKYL = (int) (39.686-(84.406)-(21.539)-(tcb->m_ssThresh)-(55.679)-(6.616)-(6.675)-(55.556));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (38.685-(90.349)-(tcb->m_segmentSize)-(40.901)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(64.704));
segmentsAcked = (int) (48.503-(15.236)-(48.306));
float ZIfIxosUpevjeIoJ = (float) (((0.1)+(0.1)+(0.1)+(41.605))/((89.727)+(0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
