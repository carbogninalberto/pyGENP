float dgSPWOPXczhKOQfZ = (float) 21.48;
