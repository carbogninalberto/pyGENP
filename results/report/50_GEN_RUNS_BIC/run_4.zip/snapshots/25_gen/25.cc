tcb->m_ssThresh = (int) (55.136*(cnt)*(48.033)*(20.166)*(80.781)*(74.569)*(29.504)*(63.463)*(tcb->m_segmentSize));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked != tcb->m_ssThresh) {
	segmentsAcked = (int) (92.58*(cnt)*(17.31)*(67.549));
	segmentsAcked = (int) (94.991-(66.529)-(1.475));
	tcb->m_cWnd = (int) (segmentsAcked-(14.352)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh*(43.694)*(30.059)*(75.599)*(tcb->m_segmentSize)*(26.398)*(87.124)*(67.721));
	tcb->m_ssThresh = (int) (89.385+(93.204)+(47.052)+(11.602));
	segmentsAcked = (int) (11.004+(84.039)+(66.756)+(5.882)+(14.536));

}
if (segmentsAcked > tcb->m_segmentSize) {
	segmentsAcked = (int) (63.095*(7.285)*(85.054)*(55.004)*(33.838)*(92.334));
	cnt = (int) (1.113+(43.348)+(84.279)+(87.786)+(7.081)+(71.479)+(tcb->m_cWnd)+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (72.602*(82.087)*(segmentsAcked));
	ReduceCwnd (tcb);

}
if (cnt <= segmentsAcked) {
	cnt = (int) (94.924*(32.93)*(95.702)*(58.007)*(tcb->m_segmentSize)*(67.238)*(tcb->m_cWnd)*(52.254));
	tcb->m_ssThresh = (int) (((0.1)+((14.496-(73.095)))+((35.099-(37.837)-(tcb->m_segmentSize)-(99.816)-(65.104)-(88.808)-(segmentsAcked)-(35.427)-(63.454)))+(0.1)+((96.617*(37.903)*(55.093)))+(0.1))/((65.19)));

} else {
	cnt = (int) (78.977-(20.217)-(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_cWnd = (int) ((((37.04+(41.574)+(22.925)))+(8.928)+((67.732*(20.863)*(tcb->m_cWnd)*(segmentsAcked)*(36.173)*(71.619)*(82.377)*(23.416)))+(70.03))/((19.144)));
