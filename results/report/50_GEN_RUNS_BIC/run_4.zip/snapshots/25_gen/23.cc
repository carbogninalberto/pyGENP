tcb->m_ssThresh = (int) (72.937+(9.42)+(69.296)+(11.761)+(tcb->m_segmentSize)+(67.097));
float HqeVbdeSZUvONsRD = (float) (0.1/31.839);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
float CqRAyXWcaaXhfxLt = (float) ((((51.246*(82.799)*(44.113)*(10.784)*(4.198)*(tcb->m_segmentSize)))+(4.965)+(14.631)+(53.734)+(56.592)+((79.633*(cnt)*(68.001)*(78.782)*(11.336)*(76.734)))+(0.1))/((22.58)));
if (cnt > segmentsAcked) {
	tcb->m_ssThresh = (int) (74.41+(98.527)+(46.437)+(cnt)+(98.076)+(cnt)+(18.111)+(51.645));
	CqRAyXWcaaXhfxLt = (float) (32.95-(96.694)-(76.803)-(46.906)-(41.194)-(60.676)-(81.393)-(90.398));

} else {
	tcb->m_ssThresh = (int) (9.463+(47.48)+(38.02)+(89.888)+(23.63)+(73.98)+(72.945)+(38.839)+(CqRAyXWcaaXhfxLt));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	CqRAyXWcaaXhfxLt = (float) (91.498-(57.267)-(tcb->m_cWnd)-(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	CqRAyXWcaaXhfxLt = (float) (0.1/53.184);
	tcb->m_ssThresh = (int) (41.321+(tcb->m_cWnd)+(76.378)+(52.065)+(91.067)+(72.408)+(cnt)+(63.842)+(CqRAyXWcaaXhfxLt));

}
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (87.199*(68.471)*(40.703)*(50.076)*(90.94)*(tcb->m_cWnd));
	CqRAyXWcaaXhfxLt = (float) (13.579-(CqRAyXWcaaXhfxLt));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (46.615-(4.273)-(tcb->m_ssThresh)-(15.551)-(76.961)-(40.733)-(HqeVbdeSZUvONsRD)-(26.533)-(71.716));

}
