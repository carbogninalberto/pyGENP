cnt = (int) (33.677-(tcb->m_segmentSize)-(68.528)-(54.715)-(21.41)-(71.257)-(96.64)-(96.723));
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	cnt = (int) (8.488+(17.235)+(1.936)+(40.48)+(51.173)+(19.561)+(tcb->m_segmentSize)+(71.399)+(20.028));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (segmentsAcked-(77.713)-(82.428)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(16.246)-(27.425));
	tcb->m_segmentSize = (int) (20.906+(56.39));
	tcb->m_ssThresh = (int) (76.777+(17.812));

}
int SDmgWwWFbUzNptoZ = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((90.266)+(0.1)+(75.443)+(76.724)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (((17.185)+(19.318)+(0.1)+(15.227)+(0.1))/((66.699)+(0.1)));
cnt = (int) (0.1/(tcb->m_cWnd*(tcb->m_segmentSize)*(10.186)));
