ReduceCwnd (tcb);
int cPOoCKHxrmCpgFtS = (int) (2.459-(79.216)-(tcb->m_cWnd));
tcb->m_segmentSize = (int) (92.636-(tcb->m_segmentSize)-(32.273)-(88.116)-(40.276)-(12.653)-(45.602)-(segmentsAcked));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (cPOoCKHxrmCpgFtS != tcb->m_cWnd) {
	cPOoCKHxrmCpgFtS = (int) (segmentsAcked+(15.308)+(30.579)+(7.823)+(59.26)+(69.911));
	cnt = (int) (97.857*(66.877));

} else {
	cPOoCKHxrmCpgFtS = (int) (80.077+(tcb->m_cWnd)+(52.136)+(cnt)+(18.261)+(33.506));
	cnt = (int) (72.908+(28.887)+(96.391)+(60.205)+(78.823)+(36.647));
	ReduceCwnd (tcb);

}
