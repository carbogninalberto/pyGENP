if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (24.818*(64.929)*(58.651)*(cnt)*(tcb->m_cWnd)*(8.425)*(segmentsAcked)*(82.112));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (51.028-(52.83)-(67.911)-(68.363)-(41.351)-(70.27));

} else {
	tcb->m_segmentSize = (int) (55.194*(21.213)*(segmentsAcked)*(58.799));

}
float SFvjjqKBaVXdlXdk = (float) (20.094+(80.14)+(tcb->m_ssThresh)+(cnt)+(85.647)+(tcb->m_cWnd)+(12.778)+(35.71)+(segmentsAcked));
cnt = (int) (0.1/0.1);
tcb->m_cWnd = (int) (((62.042)+(0.1)+((66.598+(segmentsAcked)+(54.196)+(12.665)+(93.964)))+(90.916))/((0.1)));
ReduceCwnd (tcb);
cnt = (int) (0.1/16.814);
SFvjjqKBaVXdlXdk = (float) (segmentsAcked-(93.579)-(86.617)-(87.201)-(segmentsAcked)-(82.778)-(69.807)-(17.615)-(90.982));
