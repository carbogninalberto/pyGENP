tcb->m_cWnd = (int) (51.425+(89.865));
float QqzMtfaWFInpzmPs = (float) (-78.199*(61.663)*(-14.609)*(8.306));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (-43.014-(94.763)-(36.372)-(45.539)-(30.067)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (99.667*(19.392)*(63.214)*(21.509)*(9.248)*(tcb->m_cWnd)*(61.702)*(68.485)*(43.368));
	tcb->m_segmentSize = (int) (34.052-(51.144)-(37.048)-(67.127));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
