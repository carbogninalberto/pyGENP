int pxgCOLRpECxerTEK = (int) (0.1/0.1);
ReduceCwnd (tcb);
int ieLDnBGNXrKmZMTv = (int) (tcb->m_segmentSize+(18.968)+(13.088)+(40.692)+(96.658));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (52.928/0.1);
pxgCOLRpECxerTEK = (int) (97.518/51.611);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
