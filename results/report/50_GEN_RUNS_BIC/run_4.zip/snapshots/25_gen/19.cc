cnt = (int) (30.784+(cnt)+(13.941)+(62.059)+(41.585)+(69.529));
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (67.045/(49.156*(cnt)*(2.943)*(85.114)));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (((0.1)+(99.894)+(13.272)+(0.1)+(17.727))/((0.1)+(0.1)+(16.879)+(20.382)));
	segmentsAcked = (int) (tcb->m_ssThresh*(5.583)*(35.468)*(17.414));
	tcb->m_cWnd = (int) (55.236+(45.344)+(28.54)+(26.469)+(63.427)+(69.401)+(59.254)+(97.471));

}
if (cnt != tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd*(21.57)*(segmentsAcked)*(10.601)*(44.974));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (segmentsAcked*(77.162)*(52.423)*(40.405)*(20.863));

} else {
	segmentsAcked = (int) (43.662+(57.049)+(80.406)+(40.91)+(29.047)+(tcb->m_cWnd)+(68.305)+(40.453));
	segmentsAcked = (int) (((84.96)+(0.1)+(77.706)+(0.1))/((28.311)+(0.1)+(0.1)+(0.1)+(0.1)));

}
tcb->m_ssThresh = (int) (tcb->m_segmentSize+(0.574)+(92.391)+(34.445)+(3.906)+(tcb->m_cWnd)+(91.936));
int tOGmagUtkNVQALZz = (int) (cnt*(segmentsAcked)*(37.949)*(70.152)*(88.868));
segmentsAcked = (int) (50.174+(69.943)+(37.974)+(tcb->m_ssThresh)+(28.688)+(segmentsAcked)+(94.553)+(47.501)+(tcb->m_segmentSize));
int HHBbPxXyIsfdCWiU = (int) (60.88*(cnt)*(83.831)*(tOGmagUtkNVQALZz)*(19.954)*(53.993));
