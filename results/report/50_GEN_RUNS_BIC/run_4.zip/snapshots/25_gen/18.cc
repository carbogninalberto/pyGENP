int yJOKZIgxZULGMxkA = (int) (6.617+(tcb->m_segmentSize)+(segmentsAcked));
if (yJOKZIgxZULGMxkA < cnt) {
	tcb->m_segmentSize = (int) (97.609*(24.191)*(61.112)*(53.842)*(21.883));

} else {
	tcb->m_segmentSize = (int) (51.284+(cnt)+(40.827)+(75.415)+(segmentsAcked)+(53.93)+(81.04));
	tcb->m_cWnd = (int) (98.813*(66.404)*(39.682)*(7.899)*(cnt)*(tcb->m_ssThresh)*(59.037)*(73.591));
	segmentsAcked = (int) (39.766*(70.176)*(93.934)*(51.509)*(96.858)*(47.086)*(86.115)*(17.293));

}
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (69.192+(66.869)+(44.56)+(80.205)+(91.703)+(95.546)+(95.619));
	yJOKZIgxZULGMxkA = (int) (2.68-(19.2)-(66.495)-(86.499));

}
if (tcb->m_ssThresh > cnt) {
	cnt = (int) (71.884-(79.301)-(yJOKZIgxZULGMxkA)-(13.217));
	tcb->m_ssThresh = (int) (65.4+(tcb->m_segmentSize)+(yJOKZIgxZULGMxkA)+(77.044));
	tcb->m_cWnd = (int) (((0.1)+(81.922)+(0.1)+(0.1)+(0.1)+(33.827))/((0.1)+(0.1)));

} else {
	cnt = (int) (54.343-(81.85)-(94.471)-(70.849)-(26.968));

}
if (tcb->m_segmentSize < yJOKZIgxZULGMxkA) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(91.263)+(0.1)+(83.887)));

} else {
	tcb->m_cWnd = (int) ((((45.453-(58.155)-(42.054)-(12.731)-(73.845)))+(67.668)+(0.1)+(0.1)+(0.1))/((0.1)+(99.742)+(26.814)+(0.1)));
	cnt = (int) (30.256-(53.285)-(84.926)-(85.443)-(40.877)-(22.265)-(tcb->m_segmentSize));
	cnt = (int) (10.306+(39.063)+(87.362)+(97.962)+(yJOKZIgxZULGMxkA)+(segmentsAcked)+(cnt));

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	cnt = (int) (80.271*(tcb->m_cWnd)*(94.35));

} else {
	cnt = (int) (31.02*(78.559)*(62.884)*(tcb->m_ssThresh)*(89.934)*(93.653)*(73.368));

}
