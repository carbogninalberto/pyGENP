float YgMXjolQouawGDTc = (float) 13.74;
