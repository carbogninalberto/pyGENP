int HHPTMdykeDTODocu = (int) (34.429*(-3.472)*(-41.235)*(-96.246));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
int lKvfNTOGFQYBamCq = (int) (-49.3/99.467);
int pZGGTCEtJHsmmPvl = (int) (-55.557-(18.716)-(-85.284)-(-73.98)-(1.786)-(-33.486));
lKvfNTOGFQYBamCq = (int) (54.738+(-9.745)+(71.904)+(-94.849)+(83.251)+(-53.665)+(85.008)+(-63.845)+(-51.401));
lKvfNTOGFQYBamCq = (int) ((((tcb->m_cWnd+(32.474)))+(-16.325)+(65.173)+(-76.531)+(44.443)+(-77.03)+(-42.849)+(-45.042))/((-1.155)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
