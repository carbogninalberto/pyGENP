ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh > segmentsAcked) {
	cnt = (int) (27.411+(90.75)+(76.156)+(31.824)+(23.915)+(32.134));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (40.564+(84.562)+(69.098)+(36.69)+(tcb->m_cWnd));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (28.499-(68.128)-(78.648)-(tcb->m_ssThresh));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > cnt) {
	tcb->m_ssThresh = (int) (5.749+(1.735)+(54.151)+(42.633)+(3.21));
	tcb->m_cWnd = (int) (52.894-(tcb->m_cWnd)-(4.074)-(26.793));
	tcb->m_segmentSize = (int) (36.646+(cnt)+(tcb->m_ssThresh)+(18.028));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked*(13.475)*(9.721)*(5.997)*(tcb->m_segmentSize)*(60.402)*(cnt)*(72.059)*(43.534));
	tcb->m_ssThresh = (int) (((15.443)+(70.929)+(0.1)+(0.1)+(22.347))/((72.06)+(0.1)+(93.287)+(28.551)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
float ScMBYjYpKiUkpSqP = (float) (18.857-(tcb->m_ssThresh));
tcb->m_cWnd = (int) (58.261/0.1);
