tcb->m_cWnd = (int) (21.929*(cnt)*(96.982)*(38.627)*(8.84)*(tcb->m_segmentSize)*(5.397));
cnt = (int) (31.693*(40.112)*(50.249));
int mhgYANKEOPUaivGD = (int) (((0.1)+((48.204+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(20.951)+(72.908)))+(0.1)+(21.583))/((0.1)));
tcb->m_cWnd = (int) (55.327-(cnt));
tcb->m_segmentSize = (int) (((67.247)+(0.1)+(0.1)+(5.892)+(0.1)+(0.1))/((0.1)));
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	mhgYANKEOPUaivGD = (int) (86.343-(-0.029)-(tcb->m_cWnd));

} else {
	mhgYANKEOPUaivGD = (int) (cnt+(58.585)+(35.376)+(segmentsAcked)+(mhgYANKEOPUaivGD)+(91.312)+(segmentsAcked)+(65.985));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (5.035+(29.607));

}
