int ZtFYSHfaugsRBjvg = (int) (-17.571+(-57.123)+(94.594)+(-49.192)+(-71.75)+(-63.09)+(38.615));
float eoDOIiErcBTnpuJX = (float) (-81.217+(-40.877)+(-83.092)+(-38.979)+(82.102)+(-23.94)+(-42.17)+(60.904));
ZtFYSHfaugsRBjvg = (int) (-20.322+(49.377));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (tcb->m_cWnd+(48.66)+(4.46));

} else {
	segmentsAcked = (int) (88.03-(11.256)-(52.257));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ZtFYSHfaugsRBjvg = (int) (57.28*(-27.158)*(63.424)*(37.121)*(3.207)*(75.039)*(-20.671)*(63.25));
