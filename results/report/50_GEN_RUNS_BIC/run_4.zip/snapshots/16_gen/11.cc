if (cnt < segmentsAcked) {
	tcb->m_cWnd = (int) (14.723/0.1);
	cnt = (int) (79.526+(23.007)+(98.615)+(32.478)+(1.491)+(tcb->m_cWnd)+(39.433)+(43.612)+(9.034));
	cnt = (int) (77.072*(95.736)*(tcb->m_ssThresh)*(9.708)*(tcb->m_segmentSize)*(95.313)*(78.208)*(11.601));

} else {
	tcb->m_cWnd = (int) ((50.772*(segmentsAcked)*(63.889)*(segmentsAcked)*(64.455)*(86.524)*(28.136)*(26.221)*(33.687))/0.1);
	tcb->m_segmentSize = (int) (94.884+(tcb->m_cWnd)+(74.002)+(48.746)+(2.746)+(20.386)+(54.663)+(tcb->m_ssThresh)+(34.916));

}
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked-(cnt)-(62.799));
	tcb->m_cWnd = (int) (((0.1)+((73.267-(21.444)-(25.308)-(5.062)-(20.259)))+(71.761)+(64.0)+(0.1)+(11.887))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) ((tcb->m_ssThresh+(96.988)+(79.503)+(2.474)+(66.452))/86.501);
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (21.587-(4.894)-(21.991)-(30.616)-(43.337)-(29.562)-(88.821)-(22.782));
if (tcb->m_ssThresh != cnt) {
	cnt = (int) (47.698-(67.525)-(80.196)-(52.561)-(23.148));
	cnt = (int) (56.42-(14.615)-(cnt)-(tcb->m_cWnd)-(8.452)-(80.22)-(36.318)-(28.031)-(28.401));
	cnt = (int) (((24.929)+(57.527)+(0.1)+(24.722))/((0.1)+(0.1)));

} else {
	cnt = (int) (6.259*(90.072)*(23.572)*(59.51)*(cnt)*(0.98)*(46.088)*(3.969)*(segmentsAcked));
	ReduceCwnd (tcb);

}
if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(29.014)-(84.685)-(segmentsAcked)-(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (18.25+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (80.552-(65.841)-(42.137)-(56.117)-(47.993));

}
tcb->m_ssThresh = (int) (0.1/63.148);
if (tcb->m_segmentSize <= cnt) {
	cnt = (int) ((((40.994*(tcb->m_ssThresh)*(97.568)*(84.242)*(tcb->m_ssThresh)*(73.387)*(34.819)*(tcb->m_segmentSize)*(segmentsAcked)))+(0.1)+(40.978)+(17.996))/((0.1)+(0.1)+(0.1)));
	segmentsAcked = (int) (83.169/78.422);
	tcb->m_ssThresh = (int) ((6.274*(89.771)*(segmentsAcked)*(29.664))/0.1);

} else {
	cnt = (int) (0.1/1.798);

}
