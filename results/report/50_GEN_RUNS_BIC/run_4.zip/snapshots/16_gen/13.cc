ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (57.932*(56.949)*(tcb->m_ssThresh)*(segmentsAcked));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (19.798+(15.153)+(0.266)+(19.465)+(94.104)+(31.16)+(47.978));

} else {
	tcb->m_cWnd = (int) (19.901*(15.766)*(73.147)*(72.585)*(49.174)*(80.007));
	tcb->m_ssThresh = (int) (62.199*(4.945)*(87.036)*(84.462)*(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
float tMEnSlrmVpUhqyXv = (float) (65.081*(1.039)*(73.068)*(55.277)*(84.105)*(86.182));
ReduceCwnd (tcb);
