segmentsAcked = (int) ((35.946*(68.157)*(23.782)*(9.241)*(tcb->m_ssThresh))/18.283);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (81.859+(6.096)+(72.252)+(tcb->m_ssThresh)+(49.314)+(37.208)+(70.355)+(69.528)+(19.414));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (68.68*(87.407)*(tcb->m_cWnd));
segmentsAcked = (int) (53.024/0.1);
