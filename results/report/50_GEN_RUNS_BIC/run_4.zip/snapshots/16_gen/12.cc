tcb->m_cWnd = (int) (tcb->m_segmentSize-(98.625)-(67.651));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((0.1)+(0.1)+(56.383)+(0.1))/((52.93)+(53.725)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
