tcb->m_cWnd = (int) (8.384/0.1);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (51.785/0.1);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
