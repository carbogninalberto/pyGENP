if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (tcb->m_segmentSize-(94.041)-(8.984)-(92.818)-(9.879)-(segmentsAcked)-(32.408));
ReduceCwnd (tcb);
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_ssThresh = (int) (76.343*(56.394)*(34.621)*(87.663));
	tcb->m_cWnd = (int) (cnt-(19.25)-(55.45)-(65.814)-(15.379)-(69.456)-(87.632)-(tcb->m_segmentSize)-(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (53.54-(22.843)-(22.076));
	tcb->m_segmentSize = (int) (77.248*(63.74)*(92.58)*(28.295)*(94.784)*(75.106)*(23.327));

}
if (tcb->m_ssThresh == cnt) {
	tcb->m_ssThresh = (int) (49.534+(20.786)+(5.4)+(48.479)+(4.227));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
