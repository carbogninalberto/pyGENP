ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (87.311+(segmentsAcked)+(89.086));
	tcb->m_cWnd = (int) (86.142/66.809);

} else {
	tcb->m_cWnd = (int) (0.1/21.218);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (((48.046)+(63.097)+((40.317*(19.071)*(46.555)*(84.584)*(27.165)*(90.564)))+(0.1))/((22.791)));

}
int PlrBTUigZpvtvvqK = (int) (96.437*(81.288)*(1.722)*(74.113)*(68.03)*(17.779)*(tcb->m_segmentSize)*(segmentsAcked)*(98.611));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
