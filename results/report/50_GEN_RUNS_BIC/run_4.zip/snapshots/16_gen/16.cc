ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
float pSjPLVBjlErIHaml = (float) (67.48-(91.987)-(81.434)-(tcb->m_ssThresh)-(71.397)-(45.45));
float ULyMYCnIAkUNpGPn = (float) (68.727-(89.383)-(15.192)-(10.885)-(56.633)-(91.468)-(44.738));
cnt = (int) ((51.346*(62.426)*(15.775)*(38.351)*(1.911)*(60.033)*(66.485)*(85.769)*(97.341))/0.1);
if (tcb->m_segmentSize > pSjPLVBjlErIHaml) {
	tcb->m_ssThresh = (int) (91.998*(40.451)*(18.669)*(40.276)*(pSjPLVBjlErIHaml));

} else {
	tcb->m_ssThresh = (int) (15.392*(95.529)*(44.035)*(7.496)*(57.407)*(94.711)*(47.317)*(25.299)*(38.387));
	tcb->m_cWnd = (int) (46.794+(50.61)+(94.411)+(32.361));

}
cnt = (int) (68.265+(segmentsAcked)+(66.195));
