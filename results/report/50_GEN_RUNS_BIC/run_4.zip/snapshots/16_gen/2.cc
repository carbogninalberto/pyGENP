int IBMgeEClpnxAGXrK = (int) (-42.062+(91.537)+(52.066));
