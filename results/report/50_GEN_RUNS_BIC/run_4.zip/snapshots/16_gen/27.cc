ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_cWnd) {
	cnt = (int) (53.672*(75.504)*(65.235)*(39.275)*(54.862)*(55.763)*(94.117)*(87.381)*(31.347));
	tcb->m_segmentSize = (int) (29.547+(cnt)+(segmentsAcked));

} else {
	cnt = (int) (7.264-(14.293));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (91.892*(0.471)*(85.83)*(52.167)*(67.455));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (((62.663)+((segmentsAcked+(93.657)+(tcb->m_segmentSize)+(72.0)+(57.897)))+(74.888)+(0.1)+((segmentsAcked-(84.256)-(segmentsAcked)))+(10.041))/((0.1)));

} else {
	tcb->m_ssThresh = (int) ((((93.175+(tcb->m_segmentSize)+(81.32)+(80.191)+(6.683)+(93.089)+(segmentsAcked)))+((98.815*(21.545)*(cnt)*(tcb->m_cWnd)*(64.576)*(9.795)*(25.808)*(56.424)*(68.583)))+(0.1)+(79.502))/((0.1)+(76.282)));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= cnt) {
	tcb->m_ssThresh = (int) (57.644*(18.228)*(83.871)*(tcb->m_ssThresh)*(cnt)*(62.548)*(50.671)*(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (0.537*(segmentsAcked)*(cnt)*(63.845)*(tcb->m_cWnd)*(89.548)*(29.93));

}
