ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	cnt = (int) (44.078+(85.681)+(99.887)+(tcb->m_ssThresh)+(4.806)+(segmentsAcked)+(67.637));
	tcb->m_segmentSize = (int) (50.154+(22.132)+(31.762)+(30.604)+(53.305)+(25.37)+(37.418)+(83.63));
	cnt = (int) (47.609*(tcb->m_segmentSize)*(41.944)*(42.947)*(87.544)*(14.938));

} else {
	cnt = (int) (62.976+(tcb->m_segmentSize)+(88.477)+(79.225)+(10.536)+(3.644));

}
segmentsAcked = (int) (40.052*(24.238)*(63.957)*(36.744)*(70.222)*(tcb->m_cWnd));
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_cWnd = (int) (67.819*(tcb->m_segmentSize)*(52.013)*(65.183)*(8.478)*(27.511)*(76.331)*(cnt)*(46.212));
	tcb->m_segmentSize = (int) (7.064*(29.164)*(8.547)*(44.862)*(22.154)*(57.5)*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (76.242+(tcb->m_segmentSize)+(72.514)+(88.617)+(segmentsAcked));
	segmentsAcked = (int) (72.476-(73.396)-(19.941)-(41.711)-(53.346));

}
if (segmentsAcked == segmentsAcked) {
	tcb->m_cWnd = (int) (96.594*(tcb->m_segmentSize)*(89.409));
	tcb->m_cWnd = (int) (91.524+(43.643)+(76.2)+(cnt));

} else {
	tcb->m_cWnd = (int) (12.809-(cnt));
	segmentsAcked = (int) (9.531*(65.865)*(36.233)*(92.803)*(tcb->m_cWnd)*(87.144)*(29.248)*(cnt)*(68.235));
	tcb->m_segmentSize = (int) (48.813-(28.528)-(19.704)-(4.355));

}
segmentsAcked = (int) (70.436+(67.73)+(66.479));
