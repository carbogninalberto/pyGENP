float UvmTpmHzYaVodfna = (float) (-52.877-(8.881)-(-34.529)-(-45.476)-(17.839)-(-11.696));
float rBwdjfiqwnvrsANi = (float) (-29.276+(95.397)+(-35.594)+(-76.61)+(-90.914));
ReduceCwnd (tcb);
UvmTpmHzYaVodfna = (float) (84.839+(63.337)+(91.966)+(-46.489)+(32.255)+(-12.219)+(-3.556)+(23.458));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
