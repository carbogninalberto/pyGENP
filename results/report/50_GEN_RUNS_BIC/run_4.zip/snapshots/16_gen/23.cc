if (segmentsAcked == cnt) {
	tcb->m_cWnd = (int) (21.943-(54.91)-(35.511)-(43.863)-(32.102)-(95.868));

} else {
	tcb->m_cWnd = (int) (3.176-(85.43)-(88.991)-(tcb->m_segmentSize)-(32.951)-(77.578)-(tcb->m_ssThresh)-(55.257)-(79.29));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
cnt = (int) (15.966+(55.557)+(27.13)+(73.075)+(segmentsAcked)+(84.597)+(41.49)+(22.27));
if (cnt > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (46.114*(71.835));

} else {
	tcb->m_cWnd = (int) (71.936-(4.119));
	tcb->m_segmentSize = (int) ((((23.872-(85.847)-(98.394)))+((86.519*(43.37)))+(26.489)+(33.014)+(0.1))/((29.172)+(81.209)+(0.1)));

}
cnt = (int) (63.303/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
int CHLbZdOsDRrloGzC = (int) (54.385-(79.111)-(25.37));
float QYvhsWlWebyoLDjI = (float) ((segmentsAcked-(CHLbZdOsDRrloGzC)-(21.887)-(0.894)-(tcb->m_segmentSize))/60.691);
if (QYvhsWlWebyoLDjI < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (60.377+(65.322));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (69.43/0.1);
	ReduceCwnd (tcb);

}
