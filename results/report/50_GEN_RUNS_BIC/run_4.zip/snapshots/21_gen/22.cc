ReduceCwnd (tcb);
segmentsAcked = (int) (-33.645*(84.943)*(82.122)*(-87.233)*(49.818)*(92.512)*(-82.832));
float MIwhmTmAfwfwvmwF = (float) (3.573+(47.746)+(49.604)+(82.71)+(26.473)+(-54.782));
ReduceCwnd (tcb);
int riyNRSEtlNcLmbcs = (int) 49.703;
ReduceCwnd (tcb);
