int riyNRSEtlNcLmbcs = (int) 49.021;
segmentsAcked = (int) (-62.674*(41.861)*(99.285)*(94.951)*(81.823)*(-75.399)*(-28.65));
if (segmentsAcked > riyNRSEtlNcLmbcs) {
	tcb->m_segmentSize = (int) (93.069+(51.292)+(19.337)+(segmentsAcked)+(-63.453)+(tcb->m_cWnd)+(65.697));

} else {
	tcb->m_segmentSize = (int) (46.781*(tcb->m_cWnd));

}
ReduceCwnd (tcb);
if (segmentsAcked > riyNRSEtlNcLmbcs) {
	tcb->m_segmentSize = (int) (93.069+(51.292)+(19.337)+(segmentsAcked)+(-16.862)+(tcb->m_cWnd)+(65.697));

} else {
	tcb->m_segmentSize = (int) (46.781*(tcb->m_cWnd));

}
ReduceCwnd (tcb);
