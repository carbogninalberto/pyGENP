float ekaxfSCCObIAwCul = (float) (-41.257*(-28.472)*(41.792)*(75.787)*(22.068)*(-91.07)*(-78.751)*(94.503));
ReduceCwnd (tcb);
segmentsAcked = (int) (-58.179*(3.652)*(97.74)*(84.349)*(-45.371)*(84.545)*(-26.712)*(53.858));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (4.819*(-82.642)*(81.287)*(-14.899));
tcb->m_segmentSize = (int) (25.089*(-24.634)*(-44.045)*(25.259));
