int riyNRSEtlNcLmbcs = (int) 74.11;
segmentsAcked = (int) (-72.852*(-89.786)*(-91.189)*(55.623));
if (segmentsAcked > riyNRSEtlNcLmbcs) {
	tcb->m_segmentSize = (int) (46.781*(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (93.069+(51.292)+(19.337)+(segmentsAcked)+(-1.706)+(tcb->m_cWnd)+(65.697));

}
ReduceCwnd (tcb);
