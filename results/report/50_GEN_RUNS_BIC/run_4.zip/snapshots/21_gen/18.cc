int MnlxgQkFRflpGsUg = (int) (90.888*(26.648)*(10.018)*(89.308)*(-77.709)*(-75.807));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-31.896-(50.737)-(-81.972)-(-77.803)-(64.544)-(-89.843));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
