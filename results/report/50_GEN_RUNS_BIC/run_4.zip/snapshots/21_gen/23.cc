if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
int riyNRSEtlNcLmbcs = (int) 41.164;
segmentsAcked = (int) (-46.454*(47.39)*(93.929)*(-30.348));
ReduceCwnd (tcb);
if (segmentsAcked > riyNRSEtlNcLmbcs) {
	tcb->m_segmentSize = (int) (46.781*(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (93.069+(51.292)+(19.337)+(segmentsAcked)+(-1.706)+(tcb->m_cWnd)+(65.697));

}
