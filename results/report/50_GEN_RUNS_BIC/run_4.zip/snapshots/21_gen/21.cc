ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (86.699*(-56.327)*(91.47)*(46.889)*(82.267));
tcb->m_segmentSize = (int) (-17.754*(67.311)*(60.076)*(93.394)*(-95.249));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
