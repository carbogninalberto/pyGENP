int rBemAXgUhFjBNhgn = (int) (-64.999+(-70.778)+(-23.125)+(54.613)+(42.771)+(58.147)+(-0.613)+(34.475)+(-73.56));
float HIzLWXbkcRJeOHHQ = (float) (-40.3+(-80.422)+(-53.194));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (80.712*(-66.31));
tcb->m_cWnd = (int) (5.365*(-87.274));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-80.988*(-77.659));
tcb->m_cWnd = (int) (-73.121*(10.977));
tcb->m_segmentSize = (int) (7.101+(-69.605)+(34.64)+(23.922)+(-37.176)+(54.336)+(58.165));
tcb->m_segmentSize = (int) (14.201+(82.83)+(-31.762)+(48.423)+(-68.628)+(7.363)+(32.156));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-80.121+(52.859)+(-57.23)+(-50.947)+(93.193)+(36.685)+(79.652));
tcb->m_segmentSize = (int) (-64.968+(-59.399)+(72.154)+(-61.264)+(-96.237)+(-62.561)+(32.647));
