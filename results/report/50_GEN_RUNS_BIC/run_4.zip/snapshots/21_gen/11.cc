int MRWyGXOyFlgriPig = (int) (-78.633+(-10.403));
int HopDHElqlBhbfUsj = (int) (-54.678+(-52.754)+(-21.485)+(-42.137)+(-14.901));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (-18.429+(34.68)+(68.045));
	segmentsAcked = (int) (36.559*(92.959)*(tcb->m_segmentSize)*(69.189));

} else {
	tcb->m_cWnd = (int) (87.503*(33.557)*(64.405)*(56.451));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
