if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (88.314*(16.219)*(-38.28)*(59.739)*(46.504)*(85.333)*(87.283)*(82.318)*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) ((30.201+(20.334))/0.1);

}
tcb->m_segmentSize = (int) (69.151*(-7.365)*(91.473)*(-78.993)*(70.945));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-26.549*(-86.685)*(99.721)*(-40.513)*(97.077));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
