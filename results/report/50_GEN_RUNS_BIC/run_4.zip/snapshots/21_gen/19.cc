int rBemAXgUhFjBNhgn = (int) (-33.044+(-63.095)+(33.533)+(-51.061)+(-15.88)+(-28.296)+(44.075)+(-29.228)+(77.2));
float HIzLWXbkcRJeOHHQ = (float) (-94.126+(17.393)+(-24.297));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-29.068*(59.279));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
