int MRWyGXOyFlgriPig = (int) (60.971+(-14.398));
tcb->m_cWnd = (int) (26.397+(95.967)+(18.471)+(-54.606)+(25.42));
tcb->m_segmentSize = (int) (44.443*(-67.949)*(-14.392)*(77.454)*(-42.787));
tcb->m_segmentSize = (int) (13.495*(48.671)*(-82.852)*(71.543)*(90.803));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
