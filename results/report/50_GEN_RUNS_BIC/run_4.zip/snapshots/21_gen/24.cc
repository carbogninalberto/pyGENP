int riyNRSEtlNcLmbcs = (int) 20.928;
segmentsAcked = (int) (-74.995*(19.319)*(-58.352)*(-80.511)*(6.623)*(36.07)*(7.484));
if (segmentsAcked > riyNRSEtlNcLmbcs) {
	tcb->m_segmentSize = (int) (93.069+(51.292)+(19.337)+(segmentsAcked)+(-63.453)+(tcb->m_cWnd)+(65.697));

} else {
	tcb->m_segmentSize = (int) (46.781*(tcb->m_cWnd));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (segmentsAcked > riyNRSEtlNcLmbcs) {
	tcb->m_segmentSize = (int) (93.069+(51.292)+(19.337)+(segmentsAcked)+(-16.862)+(tcb->m_cWnd)+(65.697));

} else {
	tcb->m_segmentSize = (int) (46.781*(tcb->m_cWnd));

}
if (segmentsAcked > riyNRSEtlNcLmbcs) {
	tcb->m_segmentSize = (int) (93.069+(51.292)+(19.337)+(segmentsAcked)+(-16.862)+(tcb->m_cWnd)+(65.697));

} else {
	tcb->m_segmentSize = (int) (46.781*(tcb->m_cWnd));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
