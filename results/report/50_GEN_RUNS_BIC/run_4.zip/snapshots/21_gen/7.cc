int gCJXEVbqfNAUUkjQ = (int) (0.067*(72.488)*(-54.08));
if (segmentsAcked <= segmentsAcked) {
	segmentsAcked = (int) (36.67*(7.084));

} else {
	segmentsAcked = (int) ((59.247-(tcb->m_segmentSize)-(78.494)-(segmentsAcked)-(tcb->m_segmentSize)-(cnt)-(cnt))/0.1);
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(24.948));

}
ReduceCwnd (tcb);
