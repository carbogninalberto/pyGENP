int MnlxgQkFRflpGsUg = (int) (86.258*(-51.574)*(-11.558)*(64.046)*(-52.43)*(82.483));
segmentsAcked = (int) (-92.291-(40.493)-(84.943)-(35.025)-(0.723));
tcb->m_segmentSize = (int) (52.286-(-40.475)-(0.976)-(-98.04)-(45.048)-(79.692));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
