ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (39.817-(52.27)-(9.325)-(69.935)-(58.087)-(tcb->m_segmentSize)-(50.757));
	cnt = (int) (segmentsAcked*(24.341)*(10.566));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (80.139+(12.896)+(87.031)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (((0.1)+(25.697)+(0.1)+(0.1)+(0.1))/((45.336)+(0.1)+(75.948)));
	segmentsAcked = (int) (tcb->m_cWnd*(81.767)*(6.535)*(29.479)*(10.607));

}
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (33.01+(78.022)+(34.356)+(15.51)+(32.506)+(36.233)+(tcb->m_cWnd)+(57.063)+(42.702));
	tcb->m_ssThresh = (int) (97.358*(27.966));

} else {
	tcb->m_cWnd = (int) (61.653/0.1);
	tcb->m_segmentSize = (int) ((((4.535+(54.67)+(cnt)+(cnt)+(29.882)))+((segmentsAcked*(54.178)*(28.413)*(81.433)*(95.716)*(29.995)*(tcb->m_segmentSize)))+(68.13)+(70.836)+(90.567))/((83.055)+(0.1)+(0.1)+(87.247)));

}
ReduceCwnd (tcb);
int gUJRRvkJvVFxAbbK = (int) (tcb->m_ssThresh+(91.557)+(cnt)+(81.188)+(97.443));
tcb->m_cWnd = (int) (95.019+(97.272)+(31.929)+(16.98)+(66.698)+(tcb->m_segmentSize)+(39.149)+(95.984));
if (cnt == gUJRRvkJvVFxAbbK) {
	segmentsAcked = (int) (35.032-(87.15));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (69.296*(49.496)*(42.643)*(59.321)*(63.481)*(14.198)*(gUJRRvkJvVFxAbbK)*(tcb->m_cWnd)*(96.875));
	cnt = (int) (((0.1)+(5.045)+(83.862)+(75.754)+(0.1)+(0.1))/((19.407)+(0.1)+(84.233)));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
