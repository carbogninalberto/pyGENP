float UANoxlPVwvJNyhXD = (float) (25.868-(30.113)-(-68.282)-(-95.738)-(15.197)-(-74.053)-(97.04));
int ZXDxxhvXGbQDkzgb = (int) (80.576+(78.313)+(-14.467)+(88.408)+(4.864)+(-86.444)+(43.221)+(63.582)+(-33.627));
segmentsAcked = (int) (-96.986+(67.385)+(67.788)+(-84.073)+(-85.876)+(54.259)+(45.142));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (81.384-(42.441)-(-58.798));
