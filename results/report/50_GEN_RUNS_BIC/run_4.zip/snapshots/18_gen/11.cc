ReduceCwnd (tcb);
int weJPkFwyPcequUBr = (int) 60.846;
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

}
segmentsAcked = (int) (-40.694-(-95.949)-(58.188)-(51.824)-(-59.789)-(74.013)-(-38.78)-(-93.536)-(-30.026));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (38.603-(-78.175)-(97.56)-(-85.064)-(22.288)-(51.26)-(46.256)-(-64.43)-(-37.095));
segmentsAcked = (int) (-21.343-(-95.15)-(-13.327)-(-63.803)-(-12.639)-(83.488)-(-90.383)-(87.047)-(73.407));
segmentsAcked = (int) (83.585-(-28.461)-(-65.867)-(4.923)-(77.691)-(-11.058)-(27.128)-(13.926)-(16.671));
segmentsAcked = (int) (-72.591-(37.71)-(58.142)-(-49.249)-(99.315)-(58.921)-(-53.88)-(-95.765)-(-3.878));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-67.572-(81.806)-(-55.979)-(73.805)-(-46.093)-(37.19)-(33.855)-(-45.862)-(-65.748));
segmentsAcked = (int) (-65.837-(-37.857)-(-72.027)-(-65.607)-(57.045)-(-64.022)-(-72.645)-(-2.853)-(-13.471));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

}
segmentsAcked = (int) (31.331-(7.366)-(95.184)-(-22.2)-(84.324)-(-28.755)-(-26.658)-(13.009)-(-83.282));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-84.267-(21.646)-(-12.696)-(-45.521)-(-64.2)-(93.822)-(-6.228)-(69.484)-(-39.151));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-3.997-(91.197)-(9.451)-(78.135)-(12.281)-(-92.293)-(34.802)-(47.506)-(-15.464));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-45.209-(36.641)-(-60.998)-(-70.742)-(43.123)-(-76.045)-(-25.782)-(84.68)-(-28.231));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-55.244-(-4.153)-(-87.052)-(90.661)-(-5.726)-(82.013)-(91.797)-(48.031)-(44.13));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-9.084-(96.632)-(-34.656)-(21.65)-(62.803)-(54.676)-(74.123)-(62.797)-(-2.872));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (74.896-(-49.728)-(9.4)-(4.059)-(82.474)-(-27.383)-(36.847)-(-53.545)-(96.713));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
