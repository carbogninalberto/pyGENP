float vOoQcQShEYGgexAa = (float) (57.165-(14.167)-(-84.38)-(-76.696)-(57.646)-(-68.58)-(-4.255));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
