int zUiTbMyOtavltjAS = (int) (-23.543/74.918);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
