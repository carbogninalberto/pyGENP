ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (37.53*(40.889)*(82.719)*(74.273)*(92.13)*(51.074));

} else {
	tcb->m_ssThresh = (int) (14.734-(77.604)-(56.457)-(65.962)-(64.223)-(74.628));
	tcb->m_ssThresh = (int) (0.1/0.1);
	ReduceCwnd (tcb);

}
int zfOUfgIFnXyuMtpH = (int) (45.04-(12.568)-(40.65)-(tcb->m_ssThresh));
ReduceCwnd (tcb);
cnt = (int) (28.879+(32.743)+(14.868)+(segmentsAcked)+(4.784)+(57.231)+(38.651)+(tcb->m_cWnd)+(20.572));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
