if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-16.967*(-44.971)*(56.154));
tcb->m_segmentSize = (int) (21.411*(48.027)*(59.89));
segmentsAcked = (int) (-2.855/-8.655);
segmentsAcked = (int) (52.395/-71.444);
