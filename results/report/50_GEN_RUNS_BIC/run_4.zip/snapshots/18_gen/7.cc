tcb->m_segmentSize = (int) (-64.351-(-3.883)-(-7.667));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (0.023+(-2.515)+(95.091)+(2.63)+(-61.166)+(59.326)+(-80.984));
