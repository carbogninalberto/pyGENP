tcb->m_cWnd = (int) (34.609-(0.818)-(56.267));
tcb->m_segmentSize = (int) (-91.947-(26.342)-(56.31)-(-66.622)-(32.097));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
