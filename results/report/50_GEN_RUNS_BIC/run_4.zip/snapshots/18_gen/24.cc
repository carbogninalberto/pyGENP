tcb->m_ssThresh = (int) (67.503-(97.39)-(99.726)-(10.095));
int SFLEecvmVXLTGnAd = (int) (78.946+(18.672)+(46.815)+(29.231)+(24.111)+(cnt)+(42.474)+(16.517)+(segmentsAcked));
if (tcb->m_segmentSize == cnt) {
	SFLEecvmVXLTGnAd = (int) (33.926*(86.653));

} else {
	SFLEecvmVXLTGnAd = (int) (26.607*(63.568)*(58.745)*(91.589)*(40.889)*(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (42.139-(84.505)-(37.109)-(cnt)-(69.827)-(tcb->m_cWnd)-(59.963)-(78.491)-(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
SFLEecvmVXLTGnAd = (int) (11.531*(tcb->m_cWnd)*(10.425)*(97.09));
tcb->m_segmentSize = (int) (88.337-(tcb->m_cWnd)-(66.225)-(27.191)-(41.166));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked > segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(21.67)-(11.232)-(97.044)-(83.239)-(68.11)-(8.534)-(81.516));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (12.473*(81.082)*(tcb->m_segmentSize)*(29.042));

}
