tcb->m_cWnd = (int) (80.492+(2.787)+(6.116)+(20.431)+(76.032)+(segmentsAcked)+(26.695)+(92.459));
ReduceCwnd (tcb);
if (segmentsAcked != cnt) {
	tcb->m_ssThresh = (int) (68.211*(tcb->m_ssThresh)*(cnt)*(51.948)*(19.302)*(47.289));

} else {
	tcb->m_ssThresh = (int) (61.125-(16.331)-(34.708)-(40.153)-(54.316)-(16.679)-(67.473)-(93.221)-(30.854));
	segmentsAcked = (int) (cnt+(61.219)+(40.023));

}
int wSuFHpfvxAIOpSfH = (int) (16.6+(93.725)+(28.337)+(75.423)+(tcb->m_cWnd));
if (segmentsAcked < cnt) {
	wSuFHpfvxAIOpSfH = (int) ((((62.391+(17.858)+(57.207)+(32.641)+(wSuFHpfvxAIOpSfH)+(tcb->m_cWnd)+(segmentsAcked)+(18.985)))+(0.1)+(0.1)+(58.64)+(0.1))/((29.55)+(69.486)));

} else {
	wSuFHpfvxAIOpSfH = (int) (17.939-(3.33)-(50.009)-(0.809)-(86.687)-(96.085)-(97.439)-(1.869)-(50.58));
	tcb->m_ssThresh = (int) ((1.28*(22.6)*(75.431)*(57.917)*(72.499)*(34.091))/0.1);
	wSuFHpfvxAIOpSfH = (int) (61.227*(tcb->m_segmentSize)*(wSuFHpfvxAIOpSfH)*(9.874)*(7.832));

}
ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_segmentSize) {
	wSuFHpfvxAIOpSfH = (int) (44.778*(66.3)*(40.161)*(38.316)*(51.596)*(29.505));

} else {
	wSuFHpfvxAIOpSfH = (int) (tcb->m_ssThresh-(33.543)-(tcb->m_segmentSize)-(6.906)-(tcb->m_cWnd)-(41.148)-(11.68));
	wSuFHpfvxAIOpSfH = (int) (70.181/0.1);

}
