int HopDHElqlBhbfUsj = (int) (-9.244+(5.404)+(17.737)+(-18.296)+(37.906));
tcb->m_segmentSize = (int) (19.894-(83.713)-(-4.985)-(1.416)-(-45.409)-(53.172)-(-67.053)-(10.133)-(-24.816));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (87.503*(33.557)*(64.405)*(56.451));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (-18.429+(34.68)+(68.045));
	segmentsAcked = (int) (36.559*(92.959)*(tcb->m_segmentSize)*(69.189));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (-18.429+(34.68)+(68.045));
	segmentsAcked = (int) (36.559*(92.959)*(tcb->m_segmentSize)*(69.189));

} else {
	tcb->m_cWnd = (int) (87.503*(33.557)*(64.405)*(56.451));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
