if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (61.055-(tcb->m_segmentSize)-(65.217)-(27.471));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
float feNOgSFhJumdrQto = (float) (tcb->m_segmentSize-(35.632)-(19.52)-(tcb->m_cWnd)-(63.444)-(80.299));
