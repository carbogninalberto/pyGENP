segmentsAcked = (int) (-86.51-(2.626)-(3.398)-(68.236)-(-36.853));
tcb->m_segmentSize = (int) (-43.122-(32.532)-(2.248)-(-26.464)-(-18.428)-(12.289));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
