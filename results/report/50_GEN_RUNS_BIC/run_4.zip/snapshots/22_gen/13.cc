segmentsAcked = (int) (-96.368*(-55.75)*(-33.072)*(31.043)*(-29.81)*(-12.868)*(-32.826));
float QzDRSkvDGLvsUrQL = (float) (32.009*(-96.067)*(54.592)*(55.895)*(-78.753));
int riyNRSEtlNcLmbcs = (int) 61.849;
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (segmentsAcked > riyNRSEtlNcLmbcs) {
	tcb->m_segmentSize = (int) (93.069+(51.292)+(19.337)+(segmentsAcked)+(-16.862)+(tcb->m_cWnd)+(65.697));

} else {
	tcb->m_segmentSize = (int) (46.781*(tcb->m_cWnd));

}
