ReduceCwnd (tcb);
float kkfBdSQCAEpeWihu = (float) ((-71.976+(87.144)+(55.576)+(64.521)+(-67.656)+(38.06))/-80.611);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (72.485*(-7.116)*(43.139)*(46.773)*(-42.241)*(-44.249)*(-68.413)*(39.651));
