segmentsAcked = (int) (62.976*(88.829)*(76.953)*(-54.337)*(-90.63));
segmentsAcked = (int) (-1.555-(-6.96)-(29.17)-(25.857)-(16.722));
tcb->m_segmentSize = (int) (54.454-(8.905)-(-23.502)-(-46.228)-(-6.304)-(-13.077));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
