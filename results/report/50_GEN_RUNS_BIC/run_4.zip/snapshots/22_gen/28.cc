if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (53.099-(tcb->m_cWnd)-(47.335)-(50.399)-(segmentsAcked)-(72.903)-(tcb->m_segmentSize));
if (tcb->m_ssThresh != segmentsAcked) {
	cnt = (int) (86.898+(61.243)+(21.405)+(84.851)+(segmentsAcked)+(40.716)+(7.77)+(19.64));

} else {
	cnt = (int) (12.33+(93.809)+(85.902)+(cnt)+(tcb->m_cWnd)+(39.746)+(25.566)+(1.251));

}
ReduceCwnd (tcb);
cnt = (int) (0.1/83.157);
int jHvevocvljJzZQOH = (int) (80.498-(87.736)-(0.235)-(tcb->m_segmentSize)-(9.193)-(59.323)-(88.434)-(71.926));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
