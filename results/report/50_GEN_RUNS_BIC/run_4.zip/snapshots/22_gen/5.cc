tcb->m_cWnd = (int) (-13.836+(-6.458)+(32.294)+(55.683)+(-2.603));
tcb->m_segmentSize = (int) (75.391*(17.541)*(-97.712)*(76.87)*(-5.099));
tcb->m_segmentSize = (int) (-17.3*(85.767)*(64.068)*(-65.364)*(-28.127));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
