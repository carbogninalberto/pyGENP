ReduceCwnd (tcb);
segmentsAcked = (int) (-8.247*(-57.969)*(7.853)*(-32.803)*(-11.821)*(-25.465)*(93.845)*(76.391));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-16.035*(4.374)*(-94.858)*(-48.171));
tcb->m_segmentSize = (int) (90.383*(-36.665)*(-72.231)*(67.1));
