ReduceCwnd (tcb);
segmentsAcked = (int) (-89.916*(-85.121)*(-70.654)*(48.651)*(-67.258)*(-0.942)*(-68.077)*(-48.252));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (25.863*(31.042)*(76.411)*(-1.748));
tcb->m_segmentSize = (int) (46.88*(-87.907)*(-80.402)*(-29.6));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (72.769*(20.715)*(-89.419)*(-45.876));
tcb->m_segmentSize = (int) (-94.162*(20.498)*(50.055)*(96.726));
