float mIkKJIYITbeFGqHx = (float) (-3.46+(15.222)+(38.903)+(20.73)+(-39.083)+(33.757)+(-28.556));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (65.755*(-83.098));
mIkKJIYITbeFGqHx = (float) (-37.155/-62.785);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (48.114*(25.028));
mIkKJIYITbeFGqHx = (float) (10.162/90.417);
ReduceCwnd (tcb);
