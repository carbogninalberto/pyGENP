if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (64.366+(89.442)+(tcb->m_ssThresh)+(tcb->m_ssThresh));
tcb->m_ssThresh = (int) ((53.592-(17.96))/73.196);
cnt = (int) (60.656*(83.569)*(0.486)*(91.071)*(97.184));
if (cnt == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (97.341-(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (90.468-(21.472)-(23.057));
	cnt = (int) (72.108-(54.808)-(11.782)-(70.17)-(tcb->m_cWnd)-(79.966));

} else {
	tcb->m_segmentSize = (int) (52.341*(tcb->m_ssThresh)*(89.027)*(82.259)*(89.416)*(81.786));
	tcb->m_segmentSize = (int) (5.495/0.1);
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) (55.5-(8.928)-(51.082)-(51.193)-(82.314)-(20.089)-(tcb->m_ssThresh)-(45.192));
	tcb->m_segmentSize = (int) (91.66-(23.367)-(78.131)-(75.839)-(87.16)-(62.564));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (30.45-(tcb->m_cWnd)-(55.591)-(50.887)-(99.318)-(cnt)-(4.921)-(87.058)-(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
cnt = (int) ((86.899-(segmentsAcked)-(8.452)-(6.066)-(89.08)-(34.093)-(58.036)-(93.418))/90.018);
