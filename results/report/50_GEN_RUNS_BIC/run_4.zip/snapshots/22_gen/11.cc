ReduceCwnd (tcb);
float HIzLWXbkcRJeOHHQ = (float) (11.625+(40.714)+(-49.647));
tcb->m_cWnd = (int) (-98.974*(16.328));
int rBemAXgUhFjBNhgn = (int) (3.358+(70.391)+(89.586)+(5.567)+(77.737)+(86.91)+(-51.547)+(-35.941)+(41.817));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
