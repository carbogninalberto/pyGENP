cnt = (int) (18.86*(87.683)*(0.986));
segmentsAcked = (int) (tcb->m_segmentSize-(tcb->m_ssThresh)-(32.307)-(cnt));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (41.85*(79.203)*(37.056)*(19.544));
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (26.076-(44.015)-(57.946)-(30.846)-(33.582)-(22.736)-(48.152)-(34.479));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (((92.626)+((18.16*(tcb->m_cWnd)*(87.024)*(86.633)*(cnt)*(cnt)))+((44.174*(78.931)*(65.812)*(30.785)*(89.869)*(19.309)))+(51.007))/((40.502)+(59.387)));

}
tcb->m_segmentSize = (int) (26.913/39.111);
