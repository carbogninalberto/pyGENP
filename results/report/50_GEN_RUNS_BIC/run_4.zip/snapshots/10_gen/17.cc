cnt = (int) (40.259-(42.975)-(22.334));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (79.729*(44.07)*(86.106)*(49.453)*(80.357)*(55.445)*(9.367)*(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (61.636-(2.908)-(92.589)-(cnt)-(tcb->m_segmentSize)-(5.987)-(32.472));
	tcb->m_cWnd = (int) (8.468-(49.193)-(71.784)-(23.795)-(segmentsAcked)-(43.208)-(62.283)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (68.386*(39.041)*(tcb->m_segmentSize)*(76.176));
	segmentsAcked = (int) (tcb->m_cWnd*(5.973));

}
if (tcb->m_ssThresh > cnt) {
	tcb->m_cWnd = (int) (92.281+(82.252)+(24.397));

} else {
	tcb->m_cWnd = (int) (0.712*(4.093)*(cnt)*(28.711)*(24.308)*(93.231)*(32.64));

}
tcb->m_segmentSize = (int) (((37.503)+(0.1)+(38.116)+((9.452-(cnt)-(94.924)-(68.79)))+(0.1)+(0.1)+(77.529))/((82.314)+(19.745)));
