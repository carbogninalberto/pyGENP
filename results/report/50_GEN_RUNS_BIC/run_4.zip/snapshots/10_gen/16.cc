if (cnt <= cnt) {
	cnt = (int) (84.696/57.279);
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (95.636-(50.873)-(tcb->m_ssThresh)-(2.695)-(83.171)-(tcb->m_cWnd)-(cnt));
	tcb->m_cWnd = (int) (86.663-(83.429)-(cnt)-(11.742));

}
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	cnt = (int) (3.352/67.982);
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(1.102)*(64.077)*(cnt)*(71.925)*(90.457)*(96.545)*(92.646)*(83.764));

} else {
	cnt = (int) (32.965+(24.108)+(92.552)+(tcb->m_segmentSize)+(85.183));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh == cnt) {
	cnt = (int) (79.932/(85.794*(tcb->m_segmentSize)*(81.175)*(24.37)));

} else {
	cnt = (int) (73.133-(90.921));
	tcb->m_segmentSize = (int) (0.1/55.003);

}
ReduceCwnd (tcb);
segmentsAcked = (int) (45.13/0.1);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (41.904-(12.677));

} else {
	segmentsAcked = (int) (15.115+(49.977));
	tcb->m_cWnd = (int) (1.977*(tcb->m_segmentSize)*(28.957));

}
tcb->m_segmentSize = (int) (61.589-(27.86)-(tcb->m_cWnd)-(tcb->m_cWnd)-(49.964)-(30.609)-(96.497)-(3.802));
