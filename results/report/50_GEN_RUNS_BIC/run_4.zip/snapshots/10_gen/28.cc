if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((11.12*(97.212))/0.1);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(80.157)+(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(80.416)*(4.299)*(73.865));
	tcb->m_cWnd = (int) (58.878+(6.927)+(70.006));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (51.223+(32.155)+(52.5)+(31.813));
tcb->m_cWnd = (int) (85.937+(21.567)+(75.248)+(70.054)+(35.651)+(95.708)+(56.004));
tcb->m_cWnd = (int) (58.237-(50.669)-(78.442)-(44.53));
tcb->m_cWnd = (int) (segmentsAcked+(58.273)+(tcb->m_ssThresh));
