if (tcb->m_cWnd <= segmentsAcked) {
	segmentsAcked = (int) (59.782-(55.554)-(segmentsAcked)-(3.841)-(cnt)-(65.398)-(48.155)-(45.579)-(73.198));

} else {
	segmentsAcked = (int) (10.652+(67.56)+(53.462)+(29.936)+(11.64)+(tcb->m_segmentSize)+(55.559)+(60.179));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (tcb->m_cWnd*(95.737));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_cWnd = (int) (7.377-(76.414)-(53.545));
	tcb->m_segmentSize = (int) ((((30.248+(95.141)))+(0.1)+((52.249*(98.337)*(segmentsAcked)*(58.396)*(42.549)))+(66.938)+((21.277-(cnt)-(34.577)-(91.903)-(tcb->m_ssThresh)-(88.884)-(20.404)))+(0.1)+(0.1))/((0.1)));
	cnt = (int) (43.89+(54.956)+(74.752)+(95.437));

} else {
	tcb->m_cWnd = (int) (43.353*(cnt)*(72.653)*(tcb->m_segmentSize)*(98.133)*(tcb->m_segmentSize)*(60.139));
	tcb->m_ssThresh = (int) (53.654+(tcb->m_cWnd)+(58.132)+(tcb->m_cWnd)+(2.822)+(23.91)+(78.004));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > segmentsAcked) {
	cnt = (int) (89.341-(60.615)-(0.73)-(cnt)-(cnt)-(52.099)-(82.045));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(24.679)-(tcb->m_cWnd)-(75.876)-(18.38));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (67.425/0.1);
	segmentsAcked = (int) (43.803*(19.424));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (95.479*(21.141));
if (segmentsAcked == cnt) {
	cnt = (int) (80.481+(73.955));

} else {
	cnt = (int) (34.165-(29.428)-(60.753)-(96.115)-(34.247)-(64.513)-(tcb->m_ssThresh)-(5.722)-(25.993));
	segmentsAcked = (int) (tcb->m_ssThresh-(tcb->m_segmentSize)-(20.258)-(9.322)-(37.127)-(9.257));

}
