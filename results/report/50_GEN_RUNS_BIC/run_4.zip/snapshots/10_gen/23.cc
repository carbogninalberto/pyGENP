if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (99.569+(22.537)+(63.297));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (39.349-(83.805)-(42.235)-(23.414)-(90.733)-(79.842)-(34.109)-(61.109));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(cnt)*(cnt)*(53.377)*(segmentsAcked)*(tcb->m_cWnd)*(32.771)*(75.337)*(6.692));
	segmentsAcked = (int) (57.754-(41.076)-(3.207));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_cWnd) {
	cnt = (int) ((24.802*(12.807)*(70.731)*(99.315)*(0.525)*(tcb->m_segmentSize))/0.1);
	tcb->m_segmentSize = (int) (75.701-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(71.384)-(tcb->m_segmentSize));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (((0.1)+(45.488)+(82.412)+(0.1))/((0.1)));

}
