int yrUmATYDFNLUsRJv = (int) (21.352*(-50.519)*(-27.941)*(32.612)*(-64.897)*(88.078)*(55.252));
tcb->m_segmentSize = (int) (-24.957-(-96.755)-(74.281)-(-38.609)-(-82.509));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
