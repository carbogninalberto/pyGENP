ReduceCwnd (tcb);
if (segmentsAcked > tcb->m_ssThresh) {
	segmentsAcked = (int) (47.049-(12.173));

} else {
	segmentsAcked = (int) (71.815*(1.796)*(18.532)*(44.35)*(40.535)*(27.016)*(2.309)*(52.963));

}
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_segmentSize = (int) (32.996-(40.96)-(42.389)-(77.028)-(10.495)-(85.254));

} else {
	tcb->m_segmentSize = (int) (14.063+(segmentsAcked)+(43.338)+(tcb->m_cWnd)+(26.947));
	cnt = (int) (((0.1)+((67.977*(segmentsAcked)*(85.152)*(51.454)*(segmentsAcked)))+(0.1)+(50.751))/((0.1)+(40.144)));
	tcb->m_cWnd = (int) (67.549-(7.156)-(61.807)-(71.739)-(14.592)-(0.339)-(tcb->m_segmentSize));

}
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (21.297+(91.887));
	tcb->m_cWnd = (int) (0.1/78.168);

} else {
	tcb->m_segmentSize = (int) (67.876+(60.469));

}
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	cnt = (int) (86.201-(4.868)-(58.276)-(76.74)-(33.44)-(66.907)-(83.6));
	tcb->m_ssThresh = (int) (58.341-(65.389)-(93.963)-(segmentsAcked)-(65.506));
	tcb->m_ssThresh = (int) (4.416+(43.809)+(2.941)+(cnt)+(73.201));

} else {
	cnt = (int) (tcb->m_segmentSize+(39.449)+(23.564)+(77.224)+(97.763)+(97.453)+(26.829));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (segmentsAcked+(31.53)+(70.202)+(69.618));
