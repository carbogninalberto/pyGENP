tcb->m_cWnd = (int) ((17.048*(tcb->m_ssThresh)*(4.158)*(16.39)*(39.468)*(41.317)*(82.313))/0.1);
ReduceCwnd (tcb);
if (cnt == tcb->m_ssThresh) {
	segmentsAcked = (int) (81.639-(44.903)-(71.199));

} else {
	segmentsAcked = (int) (39.183-(53.932));

}
int ReToPMxyhOHDHXIx = (int) (21.313/0.1);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (0.1/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh == ReToPMxyhOHDHXIx) {
	ReToPMxyhOHDHXIx = (int) (18.153*(tcb->m_cWnd)*(87.599)*(67.34)*(14.879)*(tcb->m_segmentSize)*(50.43)*(30.042));

} else {
	ReToPMxyhOHDHXIx = (int) (91.364-(cnt)-(98.487)-(25.121)-(60.946)-(tcb->m_ssThresh)-(65.197));
	segmentsAcked = (int) (79.751+(54.735)+(57.358)+(82.315)+(73.14)+(6.102));
	cnt = (int) (51.91+(96.677)+(12.135)+(32.757)+(69.345)+(ReToPMxyhOHDHXIx)+(62.334)+(14.397));

}
