ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= tcb->m_segmentSize) {
	cnt = (int) (60.683-(62.59)-(46.786)-(89.061)-(tcb->m_segmentSize)-(90.433));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (37.285-(23.964)-(80.083));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (tcb->m_cWnd+(7.43)+(10.627));

}
segmentsAcked = (int) (79.813-(tcb->m_cWnd)-(3.017)-(59.143)-(5.361));
if (cnt <= segmentsAcked) {
	tcb->m_ssThresh = (int) (30.499+(8.777));
	cnt = (int) (43.371+(64.882)+(tcb->m_cWnd)+(59.63)+(99.544)+(76.52));

} else {
	tcb->m_ssThresh = (int) (62.825-(tcb->m_segmentSize)-(20.047)-(71.638)-(39.657)-(79.12)-(30.157));
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (75.895-(tcb->m_cWnd)-(tcb->m_segmentSize)-(63.292)-(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (40.198*(55.882)*(60.092)*(93.482)*(56.0)*(39.857)*(54.494)*(65.623)*(tcb->m_segmentSize));
if (cnt < cnt) {
	segmentsAcked = (int) (2.128*(50.935)*(41.038)*(75.137)*(85.498)*(67.577)*(11.628)*(tcb->m_ssThresh)*(27.645));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (4.265-(44.865)-(tcb->m_ssThresh)-(46.138)-(97.735)-(94.304));

} else {
	segmentsAcked = (int) (51.198-(segmentsAcked)-(segmentsAcked)-(63.099)-(69.203)-(55.652)-(84.388));

}
