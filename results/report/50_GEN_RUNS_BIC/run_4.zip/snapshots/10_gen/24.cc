int iAHVGvohdyEVbxzy = (int) (1.176-(40.006));
tcb->m_cWnd = (int) (61.103*(72.642)*(14.628)*(62.611)*(segmentsAcked)*(segmentsAcked));
if (iAHVGvohdyEVbxzy > tcb->m_segmentSize) {
	cnt = (int) (0.1/94.946);
	tcb->m_cWnd = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (((49.117)+(0.1)+(12.768)+(72.67))/((0.1)));

}
int CIhWFkikeXhwCryo = (int) ((((76.074*(15.664)*(21.394)*(cnt)*(68.134)*(14.197)*(27.429)*(tcb->m_segmentSize)*(51.244)))+(0.1)+(0.1)+(17.426)+(71.081))/((0.1)+(97.815)+(0.1)));
cnt = (int) (58.205+(72.186));
float PvOvOuqdcXJEQVDO = (float) (5.506*(96.375)*(tcb->m_segmentSize)*(98.084)*(tcb->m_cWnd)*(tcb->m_segmentSize));
tcb->m_cWnd = (int) (61.99*(40.576)*(1.351)*(68.694)*(55.198)*(iAHVGvohdyEVbxzy)*(92.095)*(17.22));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (13.821*(64.776)*(65.02)*(26.017)*(2.205)*(0.065)*(13.522)*(95.117)*(95.439));
