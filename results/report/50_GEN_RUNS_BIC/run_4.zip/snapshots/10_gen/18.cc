if (cnt >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (71.93+(44.707)+(cnt)+(99.298)+(54.18)+(tcb->m_cWnd));
	tcb->m_cWnd = (int) (((0.1)+(9.753)+(67.679)+(0.1)+(12.76)+(66.395))/((10.829)+(0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(tcb->m_cWnd)+(81.267)+(37.519)+(20.79)+(32.123));
	cnt = (int) (0.1/66.104);
	tcb->m_cWnd = (int) (56.129*(7.422)*(16.737)*(19.763)*(tcb->m_ssThresh)*(45.034));

}
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (17.141*(0.435)*(segmentsAcked)*(10.033));

} else {
	tcb->m_cWnd = (int) (30.792-(cnt)-(71.487)-(14.389)-(88.659)-(87.663)-(14.224)-(segmentsAcked));

}
tcb->m_cWnd = (int) (82.73+(73.201)+(91.49)+(tcb->m_cWnd)+(74.053)+(cnt)+(tcb->m_segmentSize)+(30.77)+(cnt));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (81.078-(28.571)-(12.647));
tcb->m_cWnd = (int) (45.808+(72.341)+(82.457)+(22.452)+(3.346)+(98.967)+(46.361)+(36.984));
segmentsAcked = (int) (tcb->m_ssThresh*(77.551)*(11.763)*(94.452)*(34.426));
