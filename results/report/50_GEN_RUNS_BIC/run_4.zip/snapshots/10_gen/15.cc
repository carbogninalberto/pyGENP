tcb->m_segmentSize = (int) (tcb->m_cWnd-(tcb->m_segmentSize)-(72.623)-(77.528));
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	cnt = (int) (21.772+(tcb->m_cWnd)+(73.526)+(13.894)+(25.976)+(8.554));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (60.965-(51.219)-(63.872)-(32.794)-(89.875)-(59.21)-(8.25)-(44.895));

}
tcb->m_ssThresh = (int) (56.665/72.014);
segmentsAcked = (int) (0.1/2.796);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(36.881)-(89.921)-(84.382)-(44.983)-(81.158)-(23.445));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (3.886-(95.889)-(20.037)-(42.691)-(tcb->m_ssThresh));

}
ReduceCwnd (tcb);
