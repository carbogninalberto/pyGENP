int epouXPYWwigDnpIn = (int) (90.673*(26.074)*(-73.863)*(40.894)*(-36.706)*(50.975)*(37.608)*(-95.048));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-44.911+(-87.977)+(-79.155)+(68.098)+(93.406)+(-43.62)+(17.448)+(-27.029));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
