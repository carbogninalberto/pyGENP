ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	cnt = (int) (52.093-(tcb->m_cWnd)-(14.294)-(47.751)-(40.419)-(57.586)-(99.487)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) ((((tcb->m_ssThresh*(97.576)*(94.283)*(43.896)*(74.592)*(65.026)*(88.577)))+(37.977)+(0.1)+(51.941)+(97.95)+(40.474))/((86.894)));

} else {
	cnt = (int) (tcb->m_segmentSize-(3.113));

}
int GuWWjsXLYbxvQmRD = (int) (0.1/0.1);
cnt = (int) (((0.1)+(0.1)+(0.1)+((56.652+(0.076)+(8.099)+(24.433)+(32.217)+(tcb->m_segmentSize)+(14.641)+(GuWWjsXLYbxvQmRD)))+(0.1)+(98.505))/((13.692)+(47.366)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
GuWWjsXLYbxvQmRD = (int) (25.634+(95.874)+(15.268)+(99.842)+(91.982)+(54.254)+(segmentsAcked)+(47.789)+(segmentsAcked));
