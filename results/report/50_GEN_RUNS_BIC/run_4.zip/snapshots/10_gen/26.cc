if (tcb->m_segmentSize != tcb->m_cWnd) {
	cnt = (int) (25.267-(tcb->m_ssThresh)-(38.003));
	cnt = (int) (62.019*(63.279)*(73.297)*(99.462));

} else {
	cnt = (int) (36.414/0.1);
	segmentsAcked = (int) (75.888*(segmentsAcked));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (99.264-(tcb->m_cWnd)-(93.986)-(96.197));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (((0.1)+(60.674)+((6.067+(33.246)+(tcb->m_cWnd)+(70.453)))+(0.1)+(0.1))/((79.275)+(0.1)));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (cnt*(88.757)*(52.919)*(89.741)*(tcb->m_cWnd)*(53.111)*(97.239));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
