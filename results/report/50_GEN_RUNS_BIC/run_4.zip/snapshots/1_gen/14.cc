int xTGBxEABsJcjODqb = (int) (23.075-(43.056)-(26.082)-(37.804));
if (cnt < segmentsAcked) {
	segmentsAcked = (int) (85.463-(52.882));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(41.978));

} else {
	segmentsAcked = (int) (xTGBxEABsJcjODqb*(90.928)*(31.766)*(87.752)*(98.393)*(82.8));
	xTGBxEABsJcjODqb = (int) (83.756*(3.31)*(segmentsAcked));
	segmentsAcked = (int) (1.018-(63.786)-(5.128)-(58.98)-(56.382)-(xTGBxEABsJcjODqb)-(93.609)-(18.614));

}
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	xTGBxEABsJcjODqb = (int) (((75.466)+(0.1)+(65.689)+(0.1)+((51.053+(tcb->m_segmentSize)+(6.703)+(xTGBxEABsJcjODqb)+(39.892)+(2.392)+(12.186)))+(0.1)+(0.1)+(0.1))/((0.1)));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	xTGBxEABsJcjODqb = (int) (tcb->m_segmentSize-(xTGBxEABsJcjODqb)-(22.638)-(13.804)-(39.047)-(42.184)-(57.194)-(74.834));
	tcb->m_ssThresh = (int) (85.309*(14.477)*(85.885));

}
tcb->m_segmentSize = (int) (93.902-(57.454));
ReduceCwnd (tcb);
if (cnt != segmentsAcked) {
	cnt = (int) (0.1/73.009);

} else {
	cnt = (int) (37.632*(segmentsAcked)*(6.625)*(91.036)*(33.885));
	cnt = (int) (0.1/5.775);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (2.318/67.252);
