tcb->m_segmentSize = (int) ((14.522+(48.771)+(55.684)+(46.165)+(52.157)+(69.719)+(78.886)+(segmentsAcked)+(22.958))/0.1);
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (11.877+(39.964)+(tcb->m_segmentSize)+(0.388)+(65.405)+(9.154)+(tcb->m_cWnd)+(3.678));
	tcb->m_segmentSize = (int) (7.28/(tcb->m_ssThresh*(95.766)*(83.991)*(84.771)*(24.736)*(84.79)*(60.77)));

} else {
	tcb->m_ssThresh = (int) ((((5.699*(51.738)*(11.917)))+(62.658)+(0.1)+(0.1)+(0.1)+(92.646))/((0.1)));
	tcb->m_segmentSize = (int) (35.306+(47.157)+(90.909)+(23.304)+(77.281));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < cnt) {
	cnt = (int) (((0.1)+(50.795)+(0.1)+((91.479*(92.494)*(tcb->m_segmentSize)*(99.436)*(30.177)*(tcb->m_segmentSize)*(12.346)*(53.634)))+(0.1))/((0.1)));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (((0.1)+(0.1)+(5.123)+(72.579))/((99.337)));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) ((((96.31+(tcb->m_ssThresh)+(segmentsAcked)+(86.438)+(54.397)+(85.879)+(59.195)+(tcb->m_segmentSize)))+((37.873-(cnt)-(cnt)-(43.401)-(16.224)-(55.315)-(3.35)))+(89.141)+(51.688)+(99.745))/((95.173)+(0.1)+(91.665)));
