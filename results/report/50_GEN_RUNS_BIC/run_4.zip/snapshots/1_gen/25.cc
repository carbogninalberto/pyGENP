if (tcb->m_segmentSize < cnt) {
	tcb->m_ssThresh = (int) (85.664*(58.795)*(tcb->m_segmentSize)*(3.707)*(42.652)*(65.23)*(31.223)*(21.217));
	ReduceCwnd (tcb);
	cnt = (int) (45.228*(12.275));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(tcb->m_segmentSize)-(25.701)-(62.767)-(77.56)-(49.658));
	tcb->m_segmentSize = (int) (60.501-(80.792)-(tcb->m_cWnd)-(62.055));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (cnt < tcb->m_segmentSize) {
	cnt = (int) (89.992-(41.677)-(71.963)-(83.366)-(1.244)-(94.902)-(17.497)-(88.467));
	segmentsAcked = (int) (67.057-(4.464)-(16.062));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (tcb->m_ssThresh*(42.321)*(10.916));
	segmentsAcked = (int) ((73.392-(segmentsAcked))/0.1);
	segmentsAcked = (int) (97.725/(41.987+(27.518)+(49.848)+(tcb->m_ssThresh)+(34.628)));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
