float FhhlOpMzRNUhiVtu = (float) (40.065/0.1);
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	FhhlOpMzRNUhiVtu = (float) (90.072-(64.859)-(tcb->m_cWnd)-(99.138)-(0.967)-(tcb->m_ssThresh)-(62.876)-(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	FhhlOpMzRNUhiVtu = (float) (14.302+(11.352)+(82.802)+(62.771)+(cnt)+(39.51)+(7.345));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked != cnt) {
	tcb->m_cWnd = (int) (39.709*(tcb->m_cWnd));
	cnt = (int) (((0.1)+(95.311)+(0.1)+((1.781-(9.169)))+(0.1)+(0.1))/((0.1)+(0.1)+(47.455)));

} else {
	tcb->m_cWnd = (int) (32.781/0.1);

}
if (cnt != cnt) {
	tcb->m_cWnd = (int) ((44.592*(93.235)*(29.968)*(29.591)*(78.186))/0.1);

} else {
	tcb->m_cWnd = (int) (cnt-(95.615)-(89.832)-(24.186));

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	cnt = (int) (0.1/67.126);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (89.009/0.1);

}
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((0.1)+((99.967*(42.997)*(63.432)*(71.582)))+(20.949)+(85.394))/((0.1)+(0.1)));
	tcb->m_ssThresh = (int) (50.747+(16.488)+(87.226)+(66.262)+(99.587)+(segmentsAcked)+(56.706)+(10.1));
	tcb->m_cWnd = (int) (86.305*(71.327)*(82.069)*(88.684)*(84.915)*(35.092)*(81.548)*(70.62));

} else {
	tcb->m_cWnd = (int) (84.095+(94.075)+(49.306));

}
ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (cnt+(29.795)+(17.163)+(57.338)+(FhhlOpMzRNUhiVtu)+(78.819)+(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	FhhlOpMzRNUhiVtu = (float) (FhhlOpMzRNUhiVtu-(86.745));

} else {
	tcb->m_segmentSize = (int) ((((93.789-(63.308)-(tcb->m_cWnd)-(11.036)-(segmentsAcked)-(94.015)-(cnt)-(49.533)-(61.476)))+((37.374*(45.534)*(88.062)*(77.954)))+(26.664)+(55.754)+(94.178)+(88.955))/((35.444)+(0.1)+(0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(39.964)+((79.958*(91.238)*(4.149)*(95.386)*(94.117)))+(0.1))/((0.1)));

}
if (segmentsAcked > tcb->m_segmentSize) {
	FhhlOpMzRNUhiVtu = (float) (10.918+(tcb->m_cWnd)+(9.004));
	tcb->m_ssThresh = (int) (23.477/0.1);

} else {
	FhhlOpMzRNUhiVtu = (float) (36.729+(58.95)+(tcb->m_cWnd)+(75.256)+(23.882)+(1.659)+(99.502)+(95.696));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (((0.1)+(0.1)+((77.547+(71.355)+(78.994)))+(0.1)+(0.1))/((95.106)));

}
