cnt = (int) (64.875/0.1);
if (tcb->m_cWnd < tcb->m_ssThresh) {
	cnt = (int) (cnt+(45.114)+(29.04)+(tcb->m_cWnd)+(51.258)+(53.313)+(0.428));

} else {
	cnt = (int) (cnt-(17.436)-(72.796)-(6.259)-(tcb->m_ssThresh));

}
float mnDrvoUzqcRfZkwz = (float) (42.968*(60.218)*(55.008));
int KzCdbjtcnYWPnxua = (int) (1.82*(38.867)*(tcb->m_cWnd));
float PBiipTWAKdUNeHWs = (float) (71.968/0.1);
if (tcb->m_ssThresh <= KzCdbjtcnYWPnxua) {
	segmentsAcked = (int) (57.007+(74.145)+(KzCdbjtcnYWPnxua)+(75.444));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (84.195-(44.019));
	tcb->m_segmentSize = (int) (78.924*(43.212));

}
