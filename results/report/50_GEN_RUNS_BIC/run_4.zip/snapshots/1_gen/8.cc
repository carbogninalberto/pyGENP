if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (49.57-(38.846)-(72.377)-(37.42)-(86.179)-(14.166)-(29.409)-(95.896)-(62.558));
	cnt = (int) (((74.374)+(0.1)+(0.1)+(52.582)+(40.642))/((28.679)+(39.7)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (46.981*(98.478)*(20.754)*(84.347)*(35.767)*(63.11)*(11.796)*(4.761)*(cnt));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((0.1)+((79.287+(93.422)+(32.188)+(61.406)+(69.245)))+(0.1)+(50.783))/((47.214)+(0.1)+(0.1)+(16.439)+(48.276)));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (24.587+(tcb->m_cWnd)+(tcb->m_ssThresh));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (18.9+(47.523)+(tcb->m_segmentSize)+(cnt)+(69.447)+(15.686));

} else {
	tcb->m_segmentSize = (int) (50.12+(50.252));
	tcb->m_ssThresh = (int) (3.666+(74.965)+(8.187)+(15.595)+(26.1)+(30.867));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
float VCTwGKRBGNqvsfTh = (float) (22.983+(cnt)+(tcb->m_cWnd)+(13.46)+(9.549)+(34.79));
