if (segmentsAcked < cnt) {
	tcb->m_segmentSize = (int) (10.427*(77.418)*(76.635)*(19.193)*(37.161)*(88.607)*(72.787));
	tcb->m_cWnd = (int) (19.321+(29.852)+(tcb->m_segmentSize)+(98.753)+(29.075)+(46.427)+(1.896)+(31.492)+(27.502));

} else {
	tcb->m_segmentSize = (int) (68.993+(cnt)+(36.109)+(61.527)+(86.97)+(31.34));
	tcb->m_cWnd = (int) (47.851+(3.939)+(47.584)+(tcb->m_ssThresh)+(15.338));
	cnt = (int) (57.019*(79.318)*(0.358)*(24.91)*(11.727)*(26.318)*(67.744));

}
tcb->m_cWnd = (int) ((36.722+(7.868)+(47.107)+(96.433))/63.993);
tcb->m_ssThresh = (int) (57.286*(80.787)*(8.78));
if (cnt >= segmentsAcked) {
	tcb->m_segmentSize = (int) (((0.1)+((76.398+(59.081)+(13.774)+(73.816)+(tcb->m_ssThresh)+(66.366)+(26.523)+(4.108)+(41.583)))+(87.778)+(31.532)+(56.426)+(0.1)+(7.007)+(42.302))/((86.267)));
	tcb->m_cWnd = (int) (15.911+(tcb->m_ssThresh)+(30.837)+(97.187)+(16.206));

} else {
	tcb->m_segmentSize = (int) (96.705+(segmentsAcked)+(tcb->m_ssThresh)+(38.356)+(cnt)+(tcb->m_cWnd));

}
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_segmentSize+(50.645)+(87.567)+(38.209)+(segmentsAcked)+(68.824));

} else {
	segmentsAcked = (int) (85.563+(55.289)+(25.672)+(82.367));

}
cnt = (int) (4.318+(segmentsAcked)+(0.692)+(91.23)+(46.212));
