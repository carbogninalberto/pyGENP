tcb->m_ssThresh = (int) (0.1/78.025);
if (cnt <= segmentsAcked) {
	cnt = (int) (76.144*(4.699)*(68.879));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (66.378-(8.614)-(9.389)-(59.563));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (90.577-(87.69));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < segmentsAcked) {
	cnt = (int) (65.93/74.833);

} else {
	cnt = (int) (24.738-(3.898)-(16.198)-(65.14)-(tcb->m_ssThresh)-(34.92));

}
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (0.1/31.71);
	tcb->m_ssThresh = (int) (71.561+(82.225)+(tcb->m_ssThresh)+(2.658)+(32.314));

} else {
	tcb->m_ssThresh = (int) (23.617*(30.744)*(67.061)*(86.49));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
