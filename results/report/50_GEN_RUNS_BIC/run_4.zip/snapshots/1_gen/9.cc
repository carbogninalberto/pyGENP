if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (80.904*(14.932)*(3.313)*(76.673)*(71.179)*(59.582));

} else {
	tcb->m_segmentSize = (int) (18.37-(62.138)-(89.452)-(tcb->m_cWnd)-(tcb->m_cWnd));
	segmentsAcked = (int) (94.095+(41.508)+(cnt)+(85.241)+(44.404));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (62.53-(38.521)-(49.157)-(tcb->m_ssThresh)-(60.643)-(42.731)-(94.278)-(35.759)-(25.711));
	segmentsAcked = (int) (64.653+(tcb->m_cWnd)+(92.912)+(10.56)+(92.406)+(62.028)+(61.931)+(tcb->m_ssThresh)+(1.491));
	tcb->m_cWnd = (int) (cnt-(58.887)-(tcb->m_ssThresh)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (19.199/0.1);
	tcb->m_segmentSize = (int) (((1.267)+(0.1)+(16.858)+((63.295-(segmentsAcked)))+(0.1))/((0.1)+(4.855)));
	tcb->m_ssThresh = (int) (22.995*(71.005));

}
float cNIxHqbdgoNgIKEw = (float) (36.039*(12.178)*(39.22)*(tcb->m_segmentSize));
ReduceCwnd (tcb);
if (cNIxHqbdgoNgIKEw >= tcb->m_ssThresh) {
	cNIxHqbdgoNgIKEw = (float) (47.886-(42.776)-(27.527)-(1.177)-(86.658)-(56.53));

} else {
	cNIxHqbdgoNgIKEw = (float) (tcb->m_cWnd+(91.789)+(94.662));
	segmentsAcked = (int) (0.457+(77.316)+(90.965));
	cNIxHqbdgoNgIKEw = (float) (0.1/16.764);

}
int GUfiOqVQyTRrWQTL = (int) (((0.1)+((tcb->m_ssThresh+(89.717)+(21.355)+(17.309)+(tcb->m_ssThresh)))+(0.1)+(0.1))/((87.171)+(0.1)+(4.539)+(0.1)+(0.1)));
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_segmentSize = (int) (43.284+(GUfiOqVQyTRrWQTL)+(59.829)+(cnt)+(54.594)+(37.565)+(70.822)+(40.169));

} else {
	tcb->m_segmentSize = (int) (75.59+(GUfiOqVQyTRrWQTL));

}
