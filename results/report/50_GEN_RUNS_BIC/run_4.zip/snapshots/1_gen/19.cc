ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(34.026)+(tcb->m_ssThresh)+(54.737)+(84.035)+(28.17)+(47.241)+(43.237));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (((11.043)+(97.991)+(0.1)+(0.1)+(14.116))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (tcb->m_segmentSize*(31.621)*(80.047)*(98.301)*(18.004));
tcb->m_segmentSize = (int) (45.396+(53.241)+(89.278)+(59.596)+(45.745)+(12.701)+(25.189));
ReduceCwnd (tcb);
