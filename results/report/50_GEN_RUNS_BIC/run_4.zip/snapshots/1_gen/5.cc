if (tcb->m_segmentSize >= cnt) {
	tcb->m_ssThresh = (int) ((((94.306+(25.655)+(tcb->m_cWnd)+(5.076)+(39.852)+(69.412)+(50.5)))+((43.909-(93.575)-(89.435)-(10.766)-(6.622)-(73.618)))+(0.1)+(10.563))/((19.388)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (83.984*(19.178)*(47.063)*(48.388)*(32.659)*(43.115)*(56.685)*(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (52.908-(48.575));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (cnt+(69.574)+(15.679)+(86.539)+(99.09));
ReduceCwnd (tcb);
int bIHOgajFzkMYAyBl = (int) (((12.366)+((47.636+(segmentsAcked)+(36.768)+(segmentsAcked)))+(0.1)+(8.552)+(0.1)+(0.1))/((0.1)+(0.1)));
cnt = (int) (79.502-(77.098)-(21.038)-(86.705)-(94.559)-(23.189)-(28.642)-(57.086));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (bIHOgajFzkMYAyBl == segmentsAcked) {
	bIHOgajFzkMYAyBl = (int) (0.1/62.844);
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(tcb->m_ssThresh)+(78.918)+(74.362)+(61.435)+(31.355));

} else {
	bIHOgajFzkMYAyBl = (int) (67.749+(tcb->m_cWnd)+(bIHOgajFzkMYAyBl)+(36.128)+(94.053)+(47.748)+(84.997)+(80.01));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (51.876/8.605);

}
