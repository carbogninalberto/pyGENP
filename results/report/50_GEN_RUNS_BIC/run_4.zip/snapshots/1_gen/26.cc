if (tcb->m_cWnd <= tcb->m_ssThresh) {
	segmentsAcked = (int) ((((12.886-(cnt)-(19.605)-(86.508)))+(0.1)+(0.1)+(94.691)+(55.212)+(0.1))/((0.1)));
	cnt = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (26.387-(78.801)-(75.247)-(33.989));

} else {
	segmentsAcked = (int) (51.789+(tcb->m_cWnd)+(tcb->m_segmentSize)+(31.04)+(tcb->m_ssThresh)+(7.81)+(91.69)+(71.131)+(tcb->m_segmentSize));
	cnt = (int) (cnt+(tcb->m_cWnd)+(67.118));
	tcb->m_cWnd = (int) (9.64*(35.093)*(cnt)*(65.091)*(74.994)*(segmentsAcked)*(65.551));

}
int aqEXfZTMjsYgcjBp = (int) (73.562/29.814);
ReduceCwnd (tcb);
int DApwQnuYkcDjxksv = (int) (cnt*(30.718)*(70.224));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
