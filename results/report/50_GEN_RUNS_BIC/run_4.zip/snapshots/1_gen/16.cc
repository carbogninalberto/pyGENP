ReduceCwnd (tcb);
cnt = (int) (34.826+(34.32)+(21.986)+(31.939)+(51.17));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (43.758+(tcb->m_cWnd)+(87.275)+(41.786)+(49.776)+(cnt));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (5.669-(-0.048)-(tcb->m_cWnd));
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_ssThresh = (int) (12.637*(segmentsAcked));
	tcb->m_segmentSize = (int) (0.1/6.809);

} else {
	tcb->m_ssThresh = (int) (67.536-(11.439));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
