tcb->m_ssThresh = (int) (18.147*(30.526)*(17.343));
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	cnt = (int) (99.287*(97.712)*(48.392));
	tcb->m_segmentSize = (int) (66.983-(segmentsAcked)-(99.65)-(68.735));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (45.559*(56.534));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) ((cnt+(18.866)+(15.821)+(1.29)+(cnt))/0.1);
int sGrOrJERMqoHCjoa = (int) (50.684-(segmentsAcked)-(77.929)-(46.536)-(63.35)-(56.719)-(tcb->m_ssThresh)-(12.229)-(90.215));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
