if (segmentsAcked == cnt) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (97.321+(49.061)+(10.313)+(51.607)+(cnt)+(57.162));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
int IAjCEbwKSgiXzqeE = (int) (tcb->m_segmentSize+(71.438)+(5.455)+(67.596)+(tcb->m_ssThresh)+(37.294)+(13.552));
cnt = (int) (58.185+(15.252));
