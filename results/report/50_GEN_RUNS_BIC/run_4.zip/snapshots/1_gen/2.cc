segmentsAcked = (int) ((((97.172-(tcb->m_ssThresh)-(17.9)-(segmentsAcked)-(29.877)-(10.902)-(19.522)))+((39.765+(69.958)+(39.395)+(tcb->m_ssThresh)+(18.575)+(27.607)+(65.676)+(99.024)))+(0.1)+(42.573)+(0.1))/((0.1)+(25.423)+(70.834)+(0.1)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (86.462+(69.455)+(6.208));

} else {
	tcb->m_cWnd = (int) (segmentsAcked+(19.976));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= segmentsAcked) {
	tcb->m_ssThresh = (int) (61.808-(8.698)-(9.726)-(43.839)-(58.051)-(52.884)-(8.117)-(51.561)-(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (31.255+(4.182));
	cnt = (int) (1.323+(segmentsAcked)+(1.486)+(28.77)+(71.398)+(61.5));
	tcb->m_segmentSize = (int) (60.41-(49.029)-(64.87)-(42.297)-(segmentsAcked)-(31.45)-(tcb->m_segmentSize)-(12.598)-(41.923));

}
segmentsAcked = (int) (45.224/(38.892+(9.926)+(12.001)+(94.725)+(23.73)+(segmentsAcked)+(segmentsAcked)+(81.026)));
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (61.83*(46.917)*(cnt)*(4.374)*(27.918));

} else {
	tcb->m_ssThresh = (int) (93.255*(62.854)*(tcb->m_cWnd)*(10.05));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (92.421*(tcb->m_ssThresh)*(18.889)*(54.153)*(cnt)*(66.095)*(79.121));

}
