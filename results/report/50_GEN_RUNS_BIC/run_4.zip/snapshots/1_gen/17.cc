float JzrWiPtWlfJbFRIV = (float) (0.1/69.901);
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_cWnd = (int) (63.896+(65.652)+(11.855)+(tcb->m_segmentSize)+(32.168));
	tcb->m_cWnd = (int) (57.473+(22.726)+(93.614)+(3.228));
	cnt = (int) (71.525+(tcb->m_cWnd)+(40.557));

} else {
	tcb->m_cWnd = (int) (14.017+(86.157)+(39.887)+(32.951)+(81.508)+(7.405));
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(53.234))/((0.1)+(0.1)+(0.1)+(0.1)+(99.377)));
	tcb->m_cWnd = (int) (31.24*(77.759)*(37.653)*(segmentsAcked)*(4.444));

}
float APYHJLqMUuQsHGwF = (float) (13.505+(83.262)+(49.161)+(95.079)+(32.216)+(60.57)+(92.323)+(14.213)+(29.01));
if (APYHJLqMUuQsHGwF < cnt) {
	segmentsAcked = (int) (19.326+(82.581)+(45.691)+(tcb->m_cWnd)+(81.633)+(tcb->m_segmentSize));
	cnt = (int) (68.549-(32.915)-(98.407)-(79.946)-(43.881)-(68.45)-(90.099)-(segmentsAcked));
	tcb->m_ssThresh = (int) (83.298+(55.321)+(72.161)+(tcb->m_cWnd)+(62.741)+(43.02)+(63.099));

} else {
	segmentsAcked = (int) (24.54+(segmentsAcked)+(55.607)+(74.4)+(81.18)+(48.669));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
