if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	cnt = (int) (54.508+(42.863)+(76.963)+(47.152)+(57.679)+(99.567)+(cnt)+(tcb->m_segmentSize));
	segmentsAcked = (int) (0.1/0.1);

} else {
	cnt = (int) (0.1/0.1);
	cnt = (int) (19.85*(68.692)*(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (74.598-(cnt)-(cnt)-(tcb->m_segmentSize));
