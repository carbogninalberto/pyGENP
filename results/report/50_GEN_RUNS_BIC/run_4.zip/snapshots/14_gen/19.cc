float iYhrInYiScxqYLcv = (float) (0.1/(63.212+(48.591)+(28.889)));
tcb->m_segmentSize = (int) (((0.1)+(0.1)+(98.565)+(0.1))/((0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (82.239-(62.611));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	cnt = (int) (66.998*(57.189)*(27.826)*(90.982)*(66.963)*(47.296)*(35.2)*(tcb->m_cWnd));
	cnt = (int) (((0.1)+(90.422)+((55.39-(11.05)-(37.848)-(44.431)-(81.683)-(0.253)-(86.021)-(34.539)-(iYhrInYiScxqYLcv)))+((78.567-(47.449)-(79.026)-(cnt)-(82.447)-(20.587)-(cnt)-(62.383)))+(67.766))/((91.004)));
	cnt = (int) (0.1/0.1);

} else {
	cnt = (int) (0.1/0.1);

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (33.194*(tcb->m_ssThresh)*(89.895)*(84.258)*(89.937)*(88.082)*(tcb->m_segmentSize)*(17.275));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (cnt-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(27.367)-(89.651)-(33.247)-(17.884)-(37.732));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (39.109+(65.87));

}
