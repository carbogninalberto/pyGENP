tcb->m_segmentSize = (int) (13.596+(17.949));
int MfYlrFeWeLuTSLft = (int) (63.898+(71.212));
tcb->m_cWnd = (int) (79.852+(92.309)+(3.791)+(82.121)+(91.95)+(63.064)+(54.368));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) ((((18.477+(44.847)+(59.357)+(92.232)+(43.739)))+(0.1)+(0.1)+((44.337*(8.083)))+(2.929))/((0.1)));
