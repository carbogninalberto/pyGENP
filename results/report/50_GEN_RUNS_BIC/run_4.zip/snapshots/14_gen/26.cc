tcb->m_cWnd = (int) (tcb->m_cWnd+(46.084)+(78.042)+(91.347)+(21.375));
float IwiyPZeMycxZPHYE = (float) (((0.1)+(76.5)+(33.59)+(0.1)+(0.1)+(0.1)+((56.199+(2.433)+(93.983)+(6.859)+(93.443)))+(0.1))/((0.1)));
if (tcb->m_ssThresh > cnt) {
	tcb->m_ssThresh = (int) (0.369+(93.657)+(tcb->m_ssThresh)+(IwiyPZeMycxZPHYE)+(97.256)+(90.991)+(27.918)+(59.355));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(65.248)+(tcb->m_ssThresh)+(71.492)+(45.674)+(10.415)+(15.124)+(93.69)+(73.306));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
tcb->m_ssThresh = (int) (((0.1)+(55.641)+(64.179)+((5.069*(19.338)*(48.221)*(77.574)*(cnt)))+(37.223)+(0.1))/((23.895)));
float NZVAydAlAvmkYErN = (float) (33.164*(82.743)*(70.162)*(tcb->m_cWnd)*(28.709)*(26.691)*(15.277));
ReduceCwnd (tcb);
if (cnt != NZVAydAlAvmkYErN) {
	tcb->m_ssThresh = (int) (44.442/0.1);

} else {
	tcb->m_ssThresh = (int) (1.934/0.1);

}
