if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
float upCFWXTGJvSPMrHN = (float) (cnt+(30.792)+(92.418)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(23.183));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
upCFWXTGJvSPMrHN = (float) (((97.594)+((91.962-(49.129)-(tcb->m_segmentSize)-(96.579)-(70.105)))+((cnt*(96.43)*(59.472)*(49.464)*(95.721)*(75.409)*(43.572)*(67.593)))+(0.1))/((0.1)+(56.263)+(53.245)+(91.648)+(56.364)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
