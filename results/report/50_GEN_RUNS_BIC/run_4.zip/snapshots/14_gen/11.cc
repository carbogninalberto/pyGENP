int NjfXMmQmVzTmJxJc = (int) (-17.421*(35.63)*(37.255)*(86.469)*(7.553)*(-83.686)*(-42.872)*(-7.826));
tcb->m_segmentSize = (int) (-90.366-(-35.781)-(-79.909)-(-62.92));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-73.816-(-96.297));
