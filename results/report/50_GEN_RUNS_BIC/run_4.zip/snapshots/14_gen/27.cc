tcb->m_ssThresh = (int) (0.1/77.376);
if (cnt != cnt) {
	tcb->m_ssThresh = (int) (((0.1)+(15.588)+((79.686-(91.091)-(tcb->m_cWnd)))+(0.1))/((92.134)));
	cnt = (int) (99.766-(30.422));

} else {
	tcb->m_ssThresh = (int) (((39.387)+((67.878*(89.095)*(93.587)))+(36.246)+((16.747-(24.41)-(tcb->m_cWnd)-(tcb->m_segmentSize)-(61.483)-(71.045)-(5.226)-(tcb->m_cWnd)-(32.875)))+(42.789)+(0.1))/((31.239)+(0.1)));
	segmentsAcked = (int) (97.731*(73.938));

}
segmentsAcked = (int) (41.738+(83.075)+(cnt)+(62.888)+(39.67)+(29.046)+(94.123));
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (72.843+(60.106)+(0.383)+(86.517));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (cnt-(tcb->m_segmentSize)-(8.54));

} else {
	tcb->m_segmentSize = (int) (38.916*(15.471)*(19.95)*(83.801)*(28.5)*(segmentsAcked)*(tcb->m_ssThresh));
	segmentsAcked = (int) (23.072*(16.185)*(61.266)*(21.236)*(51.843)*(17.273)*(tcb->m_cWnd)*(95.561));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
float oaFtusDoeYLMkKKP = (float) (81.89-(56.089)-(12.937)-(53.549)-(92.669)-(47.896)-(tcb->m_cWnd)-(17.28)-(19.702));
ReduceCwnd (tcb);
if (cnt <= tcb->m_ssThresh) {
	segmentsAcked = (int) (((0.1)+(36.896)+(13.381)+(99.472))/((0.1)+(0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((72.389)+(0.1)+(50.83)+(33.707)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)));

} else {
	segmentsAcked = (int) (51.312+(43.212)+(95.961)+(segmentsAcked)+(63.479)+(45.77));
	oaFtusDoeYLMkKKP = (float) (((91.467)+(58.647)+((47.482+(53.805)+(14.011)))+((48.397+(oaFtusDoeYLMkKKP)))+(0.1)+(0.1))/((25.71)+(84.032)+(0.1)));

}
oaFtusDoeYLMkKKP = (float) (49.536+(41.654)+(oaFtusDoeYLMkKKP)+(tcb->m_segmentSize)+(67.687)+(87.77)+(51.635)+(tcb->m_ssThresh)+(segmentsAcked));
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (oaFtusDoeYLMkKKP-(90.388)-(40.117)-(21.621)-(oaFtusDoeYLMkKKP)-(85.392));
	segmentsAcked = (int) (0.1/74.159);

} else {
	tcb->m_segmentSize = (int) (76.688-(36.6)-(93.754)-(22.367)-(17.74)-(38.167)-(tcb->m_cWnd)-(78.961)-(15.592));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (25.983-(40.732));

}
