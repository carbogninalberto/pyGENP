float ufEBfbSqHYELUALs = (float) (50.97-(92.826)-(47.265)-(58.979)-(tcb->m_cWnd)-(24.861)-(14.503)-(59.952));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ufEBfbSqHYELUALs = (float) (cnt-(4.071));
if (ufEBfbSqHYELUALs <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/56.011);
	segmentsAcked = (int) (segmentsAcked*(17.637)*(57.316)*(5.584)*(19.818)*(50.619));
	tcb->m_cWnd = (int) (((84.248)+(53.361)+(26.471)+(0.1)+(78.79)+(0.1))/((24.05)+(92.951)+(0.1)));

} else {
	tcb->m_cWnd = (int) (61.825-(66.336)-(tcb->m_ssThresh)-(69.924));
	cnt = (int) (ufEBfbSqHYELUALs-(60.904));
	tcb->m_cWnd = (int) (84.613+(63.163)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(66.731)+(91.445)+(62.032)+(73.195)+(47.979));

}
segmentsAcked = (int) (ufEBfbSqHYELUALs-(97.462)-(97.286)-(segmentsAcked)-(23.73));
