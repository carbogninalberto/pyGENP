int SUKLETBbNWpsbVFE = (int) (-74.327/-73.239);
float oeEkCjzUSZYbjTSU = (float) (53.375+(-17.031)+(-9.489)+(56.475)+(-41.149)+(7.171)+(67.289)+(-20.451));
