ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_ssThresh-(74.889)-(32.179)-(78.105)-(91.743)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(tcb->m_cWnd)+(72.845));

} else {
	segmentsAcked = (int) (50.161-(22.674)-(82.821)-(71.105)-(77.269)-(segmentsAcked)-(8.66)-(68.439));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (47.674-(tcb->m_ssThresh)-(49.321)-(56.17)-(8.112));

}
if (tcb->m_cWnd <= segmentsAcked) {
	segmentsAcked = (int) (39.445+(77.102)+(32.472)+(33.791)+(0.952));

} else {
	segmentsAcked = (int) (44.869*(cnt)*(98.596)*(5.47)*(20.189)*(72.37)*(10.133));
	tcb->m_ssThresh = (int) (86.356-(86.723)-(99.271)-(54.143)-(cnt));
	tcb->m_cWnd = (int) (22.185-(61.712));

}
tcb->m_segmentSize = (int) (0.1/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_cWnd > segmentsAcked) {
	cnt = (int) (46.224*(28.037)*(59.194));

} else {
	cnt = (int) (78.828/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (21.21+(11.477)+(69.123));

}
