ReduceCwnd (tcb);
int weJPkFwyPcequUBr = (int) 60.846;
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

}
segmentsAcked = (int) (-74.187-(92.359)-(-98.157)-(77.648)-(-25.978)-(13.635)-(27.617)-(-19.352)-(14.504));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-26.345-(55.603)-(32.535)-(-30.277)-(-63.161)-(30.894)-(95.64)-(-40.189)-(29.637));
segmentsAcked = (int) (96.302-(-3.695)-(-61.89)-(94.822)-(-95.243)-(78.9)-(40.154)-(68.665)-(26.533));
segmentsAcked = (int) (8.043-(-15.348)-(-8.56)-(-34.159)-(18.128)-(11.305)-(73.773)-(-79.558)-(65.76));
segmentsAcked = (int) (20.707-(80.77)-(-18.997)-(-84.995)-(-77.633)-(-76.783)-(96.887)-(-37.361)-(87.066));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

}
segmentsAcked = (int) (99.237-(-56.847)-(82.896)-(-80.638)-(69.19)-(-94.024)-(76.539)-(6.181)-(75.407));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-61.157-(27.989)-(-94.772)-(-96.818)-(-13.812)-(-8.876)-(-19.289)-(53.464)-(15.558));
segmentsAcked = (int) (-90.858-(66.693)-(-17.273)-(-61.082)-(58.198)-(31.02)-(71.086)-(-10.698)-(60.842));
segmentsAcked = (int) (-54.887-(-48.389)-(10.729)-(93.212)-(-99.51)-(-65.179)-(81.087)-(85.611)-(-71.353));
segmentsAcked = (int) (16.23-(-78.198)-(-18.65)-(-10.536)-(2.024)-(4.599)-(34.474)-(-53.717)-(58.183));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
