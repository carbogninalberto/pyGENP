ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (32.275*(25.952)*(35.158)*(72.762)*(23.43));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (99.546-(24.085)-(84.687)-(tcb->m_cWnd)-(21.051)-(94.081));

} else {
	tcb->m_cWnd = (int) (98.006-(12.162)-(9.171));
	tcb->m_ssThresh = (int) (15.576/0.1);

}
if (segmentsAcked < cnt) {
	segmentsAcked = (int) (28.931+(cnt)+(38.538)+(19.442));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (59.539+(segmentsAcked)+(23.242)+(tcb->m_cWnd)+(81.972));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(31.131)*(32.279)*(56.728)*(23.728)*(tcb->m_cWnd));

}
ReduceCwnd (tcb);
