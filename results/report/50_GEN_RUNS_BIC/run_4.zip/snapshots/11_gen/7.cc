if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (33.571-(35.63));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (98.359-(1.071));

}
