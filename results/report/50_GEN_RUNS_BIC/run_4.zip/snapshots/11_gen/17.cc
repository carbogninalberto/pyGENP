int rJTXZkFeyTBCsUwQ = (int) (((-54.616)+(-60.134)+(64.757)+(-65.812))/((-61.857)+(-41.206)));
segmentsAcked = (int) (14.748-(-20.577)-(-73.995)-(1.169)-(11.291)-(17.619)-(-2.114));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
