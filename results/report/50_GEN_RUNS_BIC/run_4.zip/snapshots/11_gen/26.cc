ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (99.338-(-12.401)-(-85.64)-(-90.481)-(-42.032)-(-97.979)-(-84.739)-(77.537));
ReduceCwnd (tcb);
segmentsAcked = (int) (77.595/-19.502);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (41.904-(12.677));

} else {
	segmentsAcked = (int) (15.115+(49.977));
	tcb->m_cWnd = (int) (1.977*(tcb->m_segmentSize)*(28.957));

}
tcb->m_segmentSize = (int) (-47.445-(-93.252)-(-82.399)-(18.742)-(40.784)-(99.508)-(59.03)-(-1.324));
