tcb->m_segmentSize = (int) (60.424+(-65.024)+(97.477));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (-76.824/31.064);
if (tcb->m_cWnd > segmentsAcked) {
	segmentsAcked = (int) (41.904-(12.677));

} else {
	segmentsAcked = (int) (15.115+(49.977));
	tcb->m_cWnd = (int) (1.977*(tcb->m_segmentSize)*(28.957));

}
tcb->m_segmentSize = (int) (-43.832-(57.74)-(-52.22)-(-51.362)-(87.734)-(-86.288)-(6.727)-(96.104));
