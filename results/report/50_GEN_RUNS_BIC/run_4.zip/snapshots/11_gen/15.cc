if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((11.12*(97.212))/0.1);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(80.157)+(35.681));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(80.416)*(4.299)*(73.865));
	tcb->m_cWnd = (int) (58.878+(6.927)+(70.006));

}
