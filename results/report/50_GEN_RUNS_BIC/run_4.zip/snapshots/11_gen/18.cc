segmentsAcked = (int) (41.293-(-64.794)-(62.745));
