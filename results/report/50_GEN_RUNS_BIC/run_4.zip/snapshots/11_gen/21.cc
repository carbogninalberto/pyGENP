int epouXPYWwigDnpIn = (int) (-56.944*(-28.987)*(-81.584)*(-35.858)*(80.479)*(-30.544)*(22.081)*(-76.544));
tcb->m_segmentSize = (int) (((-64.393)+(-82.486)+((57.967+(19.636)+(71.893)+(38.571)+(-98.185)+(tcb->m_ssThresh)+(-54.285)+(-3.96)+(-77.781)))+(75.558))/((2.67)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-69.799+(67.508)+(50.742)+(30.456)+(-44.455)+(35.026)+(25.908)+(-91.415));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
