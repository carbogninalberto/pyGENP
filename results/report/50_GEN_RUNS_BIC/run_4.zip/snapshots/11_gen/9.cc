segmentsAcked = (int) (((84.166)+(48.22)+(26.069)+(-78.842)+(16.262))/((-25.336)+(43.537)+(-13.303)));
segmentsAcked = (int) (56.948/-74.713);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
