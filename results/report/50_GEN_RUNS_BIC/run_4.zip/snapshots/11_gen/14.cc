if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (((0.1)+(53.979)+(0.1)+(0.1)+(0.1)+(0.1))/((82.905)+(51.071)+(0.1)));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (76.722-(70.428)-(57.98)-(segmentsAcked)-(84.605));
	tcb->m_cWnd = (int) (63.93-(45.103)-(99.796)-(62.402)-(tcb->m_cWnd)-(97.605)-(57.225)-(84.602));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (6.471*(-21.532)*(-9.426)*(83.379)*(-87.331)*(70.751)*(-77.128));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
