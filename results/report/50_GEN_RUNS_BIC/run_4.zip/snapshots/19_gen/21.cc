float bWLLtidqwsKdssKQ = (float) (segmentsAcked-(11.755)-(54.962)-(71.262)-(68.846)-(tcb->m_cWnd)-(tcb->m_segmentSize));
tcb->m_cWnd = (int) (((0.1)+(47.86)+(8.804)+(0.1))/((19.219)+(0.1)+(0.1)+(0.1)+(0.1)));
tcb->m_segmentSize = (int) (42.588-(70.157)-(92.731)-(90.571)-(7.06)-(84.925)-(3.446));
cnt = (int) (87.976*(20.176)*(85.778)*(13.361)*(69.595)*(98.31)*(tcb->m_ssThresh)*(16.955));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize != tcb->m_cWnd) {
	bWLLtidqwsKdssKQ = (float) (79.566-(4.793)-(99.643)-(22.269)-(98.489)-(23.865));
	ReduceCwnd (tcb);
	cnt = (int) (0.1/8.409);

} else {
	bWLLtidqwsKdssKQ = (float) (((2.436)+(0.1)+(0.1)+(50.49)+(6.801))/((0.1)+(0.1)+(0.1)));
	bWLLtidqwsKdssKQ = (float) (0.1/52.608);

}
if (tcb->m_segmentSize != segmentsAcked) {
	cnt = (int) (40.052+(76.042)+(8.34)+(15.983)+(cnt)+(17.446)+(15.372)+(51.877));

} else {
	cnt = (int) (26.952-(49.311)-(33.376)-(74.605)-(81.998)-(17.4)-(segmentsAcked)-(22.579));
	cnt = (int) (58.514+(81.405)+(30.012));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
