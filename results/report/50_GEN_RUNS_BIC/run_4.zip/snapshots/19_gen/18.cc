if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (63.445+(31.343)+(8.305)+(41.418)+(49.553)+(cnt)+(74.219)+(86.768)+(30.607));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (21.247*(35.958)*(35.468)*(77.695)*(67.811));

} else {
	tcb->m_segmentSize = (int) (87.202-(44.282)-(7.837)-(86.754));
	segmentsAcked = (int) (tcb->m_ssThresh+(tcb->m_cWnd)+(46.952)+(tcb->m_ssThresh)+(cnt)+(67.51)+(28.006)+(tcb->m_ssThresh)+(88.157));
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (11.398-(tcb->m_cWnd)-(15.536)-(76.04)-(18.297)-(65.651)-(32.23)-(32.201));
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(87.915)+(87.86)+(60.679)+(tcb->m_ssThresh));
ReduceCwnd (tcb);
if (tcb->m_segmentSize > cnt) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (cnt*(3.737)*(17.471)*(cnt)*(10.291));
	cnt = (int) (2.505-(71.658));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (85.816*(61.187)*(8.469));
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (40.377/0.1);
	ReduceCwnd (tcb);
	cnt = (int) (27.121+(3.983)+(tcb->m_ssThresh)+(94.838)+(segmentsAcked)+(50.064)+(37.993)+(segmentsAcked)+(42.524));

} else {
	segmentsAcked = (int) (95.301+(47.636)+(tcb->m_segmentSize)+(segmentsAcked));

}
