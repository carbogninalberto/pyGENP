tcb->m_ssThresh = (int) (((0.1)+(52.331)+(0.1)+(38.448)+(63.051)+(0.1))/((0.1)));
if (tcb->m_segmentSize <= cnt) {
	tcb->m_cWnd = (int) ((61.291+(31.672)+(70.956)+(88.901)+(26.84)+(50.991))/65.593);
	segmentsAcked = (int) (82.151*(24.942)*(82.655)*(42.263)*(78.206)*(97.826));

} else {
	tcb->m_cWnd = (int) (((63.187)+((41.519+(tcb->m_segmentSize)+(tcb->m_cWnd)+(52.327)+(97.422)+(97.691)+(10.727)))+(25.153)+(56.359))/((31.521)));
	segmentsAcked = (int) (21.046-(segmentsAcked));

}
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (10.788*(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (13.121*(70.238)*(1.784)*(tcb->m_cWnd)*(cnt)*(25.823));

} else {
	tcb->m_segmentSize = (int) (34.261*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(36.764)*(81.589)*(57.381));
	tcb->m_cWnd = (int) (44.528-(tcb->m_ssThresh)-(22.763)-(tcb->m_segmentSize)-(tcb->m_segmentSize));

}
tcb->m_ssThresh = (int) (((37.206)+((87.789*(tcb->m_segmentSize)))+(32.586)+(62.701)+(0.1))/((44.895)+(0.1)));
