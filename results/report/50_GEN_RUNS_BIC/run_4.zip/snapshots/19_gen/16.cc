if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (36.667+(83.218));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (tcb->m_cWnd*(tcb->m_ssThresh)*(16.806));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(71.419)*(38.344)*(77.201)*(cnt));
	tcb->m_cWnd = (int) ((2.072+(65.62))/6.022);

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= tcb->m_segmentSize) {
	segmentsAcked = (int) (((0.1)+(65.6)+(86.419)+(0.1))/((39.724)+(0.1)));
	tcb->m_segmentSize = (int) (0.1/0.1);
	cnt = (int) (70.212-(30.289)-(14.352)-(cnt)-(4.153));

} else {
	segmentsAcked = (int) (7.654+(96.922)+(0.227)+(14.487)+(tcb->m_segmentSize));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (0.1/4.998);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (43.948*(86.19)*(7.731)*(83.358)*(24.466)*(tcb->m_cWnd)*(75.104)*(27.964)*(70.817));
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (7.408/0.1);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (0.1/81.39);

} else {
	tcb->m_cWnd = (int) (57.498/0.1);

}
