if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(93.668)+(tcb->m_cWnd)+(5.378)+(23.447));
	cnt = (int) (26.961+(38.677)+(81.536)+(23.599)+(33.574)+(tcb->m_cWnd)+(cnt)+(73.222)+(49.056));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(65.329)*(7.295));

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (73.499+(tcb->m_cWnd)+(cnt)+(28.841)+(96.965)+(60.893)+(71.456));
	segmentsAcked = (int) (17.902+(65.981)+(37.742)+(tcb->m_cWnd)+(98.02)+(cnt)+(7.685)+(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (0.1/(segmentsAcked+(57.655)+(7.156)+(82.001)+(45.643)));
	tcb->m_cWnd = (int) (19.537*(52.728)*(85.545)*(77.608)*(tcb->m_cWnd)*(segmentsAcked)*(tcb->m_cWnd)*(49.011)*(97.813));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) (62.039+(27.696)+(73.167)+(77.898)+(tcb->m_cWnd)+(62.965)+(89.54)+(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (70.358*(30.106)*(91.138)*(12.642)*(tcb->m_cWnd)*(74.158)*(37.732));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
