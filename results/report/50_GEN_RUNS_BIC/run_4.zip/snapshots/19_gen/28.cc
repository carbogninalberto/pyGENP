if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (88.501+(98.855)+(97.807)+(4.677)+(79.452)+(60.479)+(99.842)+(54.604));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (46.876*(17.094)*(78.874)*(74.532)*(75.325)*(88.252));

}
if (tcb->m_ssThresh != segmentsAcked) {
	cnt = (int) (0.1/7.071);
	cnt = (int) (tcb->m_cWnd+(58.9)+(36.24)+(74.325)+(18.909)+(45.726));

} else {
	cnt = (int) (65.545+(20.022)+(61.396)+(tcb->m_ssThresh)+(69.35)+(42.526)+(51.865)+(43.24)+(23.879));
	tcb->m_ssThresh = (int) (80.475*(tcb->m_segmentSize)*(29.75)*(64.203)*(17.718)*(tcb->m_ssThresh)*(2.987)*(22.096)*(44.463));
	tcb->m_cWnd = (int) (11.091/4.244);

}
ReduceCwnd (tcb);
cnt = (int) (80.275-(0.682));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
