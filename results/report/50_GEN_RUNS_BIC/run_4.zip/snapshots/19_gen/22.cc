cnt = (int) (tcb->m_cWnd+(40.099)+(93.571)+(50.123)+(31.5)+(28.326)+(cnt)+(0.803));
ReduceCwnd (tcb);
float mIkKJIYITbeFGqHx = (float) (83.194+(51.438)+(67.522)+(32.378)+(cnt)+(tcb->m_segmentSize)+(13.146));
ReduceCwnd (tcb);
if (cnt > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (cnt*(91.296)*(59.534)*(37.132)*(87.885)*(35.217)*(75.617));
	tcb->m_segmentSize = (int) (18.766-(46.402)-(tcb->m_cWnd)-(97.598)-(tcb->m_segmentSize)-(4.367)-(41.731)-(12.999));
	tcb->m_ssThresh = (int) (50.559*(cnt)*(45.242)*(37.04)*(27.997)*(44.432));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	segmentsAcked = (int) (43.019-(tcb->m_cWnd)-(0.422)-(43.889)-(28.39)-(68.824)-(88.982)-(51.465));
	segmentsAcked = (int) (segmentsAcked*(31.198));

}
tcb->m_cWnd = (int) (58.958*(37.638));
mIkKJIYITbeFGqHx = (float) (0.1/47.645);
ReduceCwnd (tcb);
