int TSEfYXrLUdOcgGFz = (int) (36.308/45.785);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (27.46*(-44.486)*(-86.413)*(-19.922)*(70.044)*(-74.528)*(10.479)*(-10.501));
