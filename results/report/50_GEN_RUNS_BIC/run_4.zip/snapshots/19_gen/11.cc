segmentsAcked = (int) (-52.348+(89.321)+(-76.342)+(96.116));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-38.323*(-56.15)*(24.431)*(-2.103)*(44.1)*(-32.148)*(-11.858)*(97.558));
