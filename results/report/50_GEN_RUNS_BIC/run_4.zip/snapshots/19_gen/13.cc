int MRWyGXOyFlgriPig = (int) (-97.955+(55.976));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-78.187*(-61.914)*(-41.843)*(-55.134)*(-49.083));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
