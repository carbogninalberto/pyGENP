int weJPkFwyPcequUBr = (int) 60.846;
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

}
segmentsAcked = (int) (-54.582-(46.192)-(73.069)-(-15.536)-(-4.99)-(28.515)-(67.561)-(-40.597)-(15.114));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-10.558-(74.358)-(-8.742)-(98.629)-(-3.764)-(-55.33)-(50.862)-(-85.735)-(54.347));
segmentsAcked = (int) (-27.345-(7.159)-(5.881)-(-27.239)-(94.142)-(85.903)-(72.333)-(-81.405)-(-18.303));
segmentsAcked = (int) (8.577-(-78.876)-(92.986)-(-66.745)-(-64.896)-(8.611)-(-9.018)-(57.141)-(64.928));
segmentsAcked = (int) (73.89-(32.698)-(15.373)-(-64.121)-(-17.465)-(-93.329)-(2.556)-(54.632)-(34.26));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-9.479-(24.415)-(-23.499)-(-12.179)-(-17.581)-(-22.274)-(3.679)-(-72.692)-(45.001));
segmentsAcked = (int) (24.246-(0.16)-(-29.544)-(-42.941)-(-52.7)-(69.246)-(74.957)-(62.296)-(78.072));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

}
segmentsAcked = (int) (-14.483-(-2.694)-(89.636)-(-31.102)-(24.422)-(-48.231)-(88.525)-(12.896)-(-52.185));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-72.311-(80.55)-(-90.509)-(25.395)-(58.326)-(32.841)-(-57.424)-(95.216)-(62.356));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-16.497-(-84.479)-(-4.178)-(80.85)-(76.074)-(-13.217)-(87.094)-(14.641)-(-22.936));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-65.681-(15.814)-(-79.59)-(-10.651)-(-95.996)-(-14.773)-(31.025)-(-38.317)-(-94.925));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-61.577-(-54.971)-(-10.39)-(38.263)-(74.457)-(62.22)-(40.398)-(-87.945)-(-6.406));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (4.733-(80.232)-(-7.683)-(83.455)-(-41.79)-(-32.016)-(-81.464)-(-61.582)-(72.574));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-80.448-(-55.472)-(-17.966)-(50.996)-(-24.475)-(71.781)-(21.76)-(-97.169)-(46.649));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
