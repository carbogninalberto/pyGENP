int MRWyGXOyFlgriPig = (int) (-6.935+(3.656));
int HopDHElqlBhbfUsj = (int) (-24.092+(76.0)+(-38.597)+(-95.683)+(2.581));
tcb->m_segmentSize = (int) (45.612*(98.479)*(73.328)*(76.531)*(10.173));
ReduceCwnd (tcb);
