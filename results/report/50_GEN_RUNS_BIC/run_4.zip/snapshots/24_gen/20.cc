float YgMXjolQouawGDTc = (float) (4.278+(72.09)+(75.893)+(23.341)+(20.906));
if (tcb->m_segmentSize != segmentsAcked) {
	cnt = (int) (0.1/0.1);
	segmentsAcked = (int) ((16.438-(44.551)-(19.659)-(YgMXjolQouawGDTc)-(41.927)-(39.76)-(21.311))/76.489);

} else {
	cnt = (int) (tcb->m_segmentSize+(tcb->m_cWnd)+(29.863)+(30.002));

}
if (segmentsAcked >= tcb->m_ssThresh) {
	YgMXjolQouawGDTc = (float) (50.504*(YgMXjolQouawGDTc));
	tcb->m_cWnd = (int) (((0.1)+(60.186)+(62.851)+(0.1))/((0.1)+(0.1)+(0.1)+(11.181)));
	tcb->m_cWnd = (int) (YgMXjolQouawGDTc-(32.214)-(70.279)-(99.271)-(YgMXjolQouawGDTc));

} else {
	YgMXjolQouawGDTc = (float) (69.092-(0.795)-(66.964)-(46.875)-(tcb->m_ssThresh));

}
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (5.696+(50.063)+(YgMXjolQouawGDTc)+(90.591)+(46.238));
	tcb->m_cWnd = (int) (67.241-(68.162)-(67.139)-(31.381)-(cnt)-(21.816)-(YgMXjolQouawGDTc));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (93.409-(tcb->m_cWnd)-(31.091)-(tcb->m_cWnd)-(38.882)-(63.929)-(27.277));

}
ReduceCwnd (tcb);
float VlXNmWtkUbSAuupY = (float) (16.399*(YgMXjolQouawGDTc)*(90.005)*(tcb->m_segmentSize)*(56.08));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < YgMXjolQouawGDTc) {
	tcb->m_cWnd = (int) (0.1/6.208);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	YgMXjolQouawGDTc = (float) (58.777*(78.543)*(56.697)*(81.358)*(35.917)*(cnt));

} else {
	tcb->m_cWnd = (int) (70.547*(85.997)*(80.419)*(tcb->m_segmentSize)*(16.736)*(19.939)*(tcb->m_cWnd)*(9.287)*(53.552));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
