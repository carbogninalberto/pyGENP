ReduceCwnd (tcb);
ReduceCwnd (tcb);
int GtysAdOLhGGPtWgh = (int) (14.558+(57.288)+(82.802)+(39.361)+(tcb->m_ssThresh)+(34.969)+(cnt));
tcb->m_cWnd = (int) (13.87-(43.032)-(68.937));
if (segmentsAcked <= cnt) {
	tcb->m_segmentSize = (int) (((76.665)+((segmentsAcked*(segmentsAcked)*(85.318)*(90.984)*(45.892)*(segmentsAcked)*(18.422)))+(0.1)+(36.648))/((0.1)+(0.1)));
	segmentsAcked = (int) (7.675*(90.889)*(65.784)*(GtysAdOLhGGPtWgh)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(90.17)*(71.15)*(56.776));

} else {
	tcb->m_segmentSize = (int) (16.522*(27.194)*(84.92)*(66.497)*(68.339));
	segmentsAcked = (int) (tcb->m_ssThresh*(tcb->m_ssThresh)*(26.527)*(57.955)*(87.096)*(cnt));
	cnt = (int) (36.388+(tcb->m_cWnd)+(25.065)+(48.165)+(tcb->m_ssThresh));

}
if (tcb->m_cWnd < cnt) {
	GtysAdOLhGGPtWgh = (int) (3.263+(19.589));
	GtysAdOLhGGPtWgh = (int) (GtysAdOLhGGPtWgh*(tcb->m_ssThresh)*(GtysAdOLhGGPtWgh));

} else {
	GtysAdOLhGGPtWgh = (int) (63.528-(62.176)-(38.618));

}
ReduceCwnd (tcb);
