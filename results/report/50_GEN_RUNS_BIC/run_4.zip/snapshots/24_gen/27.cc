if (cnt > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (cnt-(31.908)-(11.249)-(56.143)-(tcb->m_cWnd)-(47.882)-(23.589)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) ((((21.802+(95.226)+(22.682)+(89.825)+(1.53)+(26.559)+(48.118)))+((90.295+(31.033)+(58.961)+(31.207)+(39.438)+(22.529)+(91.827)))+((45.502+(65.06)+(cnt)+(80.94)+(50.875)+(58.261)+(segmentsAcked)))+(0.1))/((24.119)));

} else {
	tcb->m_ssThresh = (int) (90.436/75.151);
	tcb->m_ssThresh = (int) (78.475+(segmentsAcked)+(tcb->m_cWnd)+(45.605)+(49.468)+(19.915)+(9.462));
	segmentsAcked = (int) (91.164+(49.629)+(19.791)+(35.007));

}
int bcZTWjHnLXCfPByG = (int) (77.32*(tcb->m_ssThresh)*(70.453));
ReduceCwnd (tcb);
if (cnt >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (43.266*(48.803)*(tcb->m_cWnd)*(7.647));
	tcb->m_ssThresh = (int) (bcZTWjHnLXCfPByG-(77.664)-(87.6)-(9.874)-(89.957)-(85.335)-(73.676));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (38.368-(16.931)-(bcZTWjHnLXCfPByG)-(bcZTWjHnLXCfPByG)-(bcZTWjHnLXCfPByG)-(bcZTWjHnLXCfPByG)-(28.217));
	tcb->m_segmentSize = (int) (43.706-(0.557));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (48.786*(31.9)*(0.997)*(1.982));
	segmentsAcked = (int) (1.959-(43.2)-(bcZTWjHnLXCfPByG)-(34.998)-(bcZTWjHnLXCfPByG)-(7.66)-(cnt));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(10.313)+(0.1)+((92.774*(tcb->m_ssThresh)*(92.099)*(46.617)*(60.472)*(91.364)*(53.648)*(66.01)*(bcZTWjHnLXCfPByG)))+(15.182)+(0.1)+(41.45)+(0.1))/((0.1)));

}
