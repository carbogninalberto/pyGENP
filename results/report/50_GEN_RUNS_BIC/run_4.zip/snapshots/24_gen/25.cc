if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (3.747-(tcb->m_cWnd)-(tcb->m_cWnd)-(25.909)-(24.139)-(1.905));
ReduceCwnd (tcb);
if (tcb->m_cWnd != cnt) {
	tcb->m_segmentSize = (int) (15.313-(93.112)-(39.543)-(80.582)-(tcb->m_ssThresh)-(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (14.484+(52.914)+(42.169)+(tcb->m_segmentSize)+(76.865)+(42.47));

} else {
	tcb->m_segmentSize = (int) (63.958-(57.431)-(29.065)-(77.438)-(70.497)-(cnt)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (71.823-(cnt)-(59.752)-(69.082));
	tcb->m_cWnd = (int) (0.1/3.321);

}
tcb->m_segmentSize = (int) (9.946*(49.901)*(59.33)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(48.532)*(tcb->m_cWnd));
