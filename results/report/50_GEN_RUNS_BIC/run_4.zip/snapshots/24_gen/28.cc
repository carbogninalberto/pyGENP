float UnoMwcnpFiBTYJfg = (float) (38.299*(74.223)*(14.549)*(78.139)*(tcb->m_segmentSize)*(61.811)*(33.181)*(21.228));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (segmentsAcked*(segmentsAcked)*(62.572)*(53.353)*(tcb->m_ssThresh));
if (tcb->m_ssThresh >= segmentsAcked) {
	cnt = (int) (55.611+(58.151));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (37.306+(99.944)+(65.662)+(51.991)+(86.033)+(84.32)+(36.023));

}
