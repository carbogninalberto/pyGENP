if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (71.736*(87.872)*(13.811)*(22.463)*(segmentsAcked)*(96.774)*(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(81.386)+(77.972)+(71.533)+(92.697)+(64.567));
	segmentsAcked = (int) (99.567+(51.762)+(64.824));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(47.474)*(2.771)*(segmentsAcked)*(42.442)*(tcb->m_ssThresh)*(cnt)*(tcb->m_segmentSize)*(5.591));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_cWnd = (int) (72.054*(83.035)*(80.083)*(5.402)*(tcb->m_cWnd)*(92.509)*(55.715));
	tcb->m_cWnd = (int) (14.926/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(95.411)+(segmentsAcked)+(36.658)+(52.718));

}
cnt = (int) (71.452*(71.562)*(12.816)*(48.077)*(50.696)*(54.883)*(96.892)*(70.694));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (88.747+(12.35));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (2.805-(69.157));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (70.129+(50.891)+(17.328)+(38.311)+(75.714)+(75.875));

}
