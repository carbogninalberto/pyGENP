tcb->m_segmentSize = (int) (27.702-(23.316)-(tcb->m_ssThresh)-(11.921));
tcb->m_ssThresh = (int) (62.158+(33.153)+(79.52)+(85.103)+(36.837)+(15.32));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (51.813*(3.384)*(segmentsAcked)*(47.796)*(38.853)*(24.15)*(tcb->m_cWnd)*(29.895));
	segmentsAcked = (int) (68.909-(2.239)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (((0.1)+((segmentsAcked-(tcb->m_cWnd)))+(0.1)+(0.1)+(65.9))/((54.505)));
	segmentsAcked = (int) (44.873-(tcb->m_ssThresh));

}
segmentsAcked = (int) (73.406-(2.104)-(85.176)-(tcb->m_segmentSize)-(51.297)-(25.666)-(tcb->m_cWnd));
tcb->m_ssThresh = (int) (tcb->m_segmentSize*(0.262)*(78.757)*(segmentsAcked)*(38.528)*(34.809)*(41.005)*(tcb->m_segmentSize)*(8.631));
ReduceCwnd (tcb);
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((99.977+(53.92)+(61.11))/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_ssThresh = (int) (7.438+(98.193)+(tcb->m_segmentSize)+(43.234)+(77.177)+(13.851)+(15.18)+(28.61));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
