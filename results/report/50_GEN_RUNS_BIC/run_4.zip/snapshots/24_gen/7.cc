int gKhmPSALubndUiRy = (int) (-87.66-(-10.025)-(9.402)-(-48.2)-(31.442)-(47.552)-(-66.919)-(-42.23));
int IgkQzNsngcWnAaUK = (int) (2.374-(-50.58)-(16.373)-(-0.718)-(6.262)-(-12.664)-(39.804)-(-81.29)-(-5.951));
ReduceCwnd (tcb);
float rwMLUdeeGUnomjAc = (float) 52.807;
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((95.193+(rwMLUdeeGUnomjAc)+(13.124)+(37.478)+(tcb->m_ssThresh)+(42.911)+(segmentsAcked)+(66.534)+(42.764))/81.614);
	segmentsAcked = (int) ((((28.63+(85.209)+(64.397)+(79.263)+(30.725)+(44.368)+(21.888)+(segmentsAcked)))+(42.537)+(86.877)+(44.04))/((82.37)+(0.1)+(38.798)+(0.1)+(98.5)));

} else {
	tcb->m_cWnd = (int) (18.53*(97.327)*(40.534)*(75.627)*(75.765)*(segmentsAcked)*(44.679)*(70.957)*(rwMLUdeeGUnomjAc));
	tcb->m_segmentSize = (int) (segmentsAcked+(0.353)+(21.531)+(32.656)+(97.81)+(20.417)+(38.231));
	ReduceCwnd (tcb);

}
