tcb->m_cWnd = (int) (88.205-(91.03)-(98.743)-(tcb->m_ssThresh)-(91.711)-(55.402)-(73.753)-(16.686)-(94.987));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
float wQPzTZKzVqMrNdeS = (float) (tcb->m_ssThresh*(26.408)*(39.611)*(96.039)*(11.12));
wQPzTZKzVqMrNdeS = (float) (cnt+(2.264)+(66.278)+(24.156)+(81.928)+(88.703)+(wQPzTZKzVqMrNdeS)+(5.318)+(tcb->m_segmentSize));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
segmentsAcked = (int) (segmentsAcked*(16.242)*(19.389)*(segmentsAcked)*(tcb->m_segmentSize)*(41.325)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(tcb->m_cWnd));
if (tcb->m_ssThresh == wQPzTZKzVqMrNdeS) {
	wQPzTZKzVqMrNdeS = (float) (23.853*(69.352)*(27.343));
	tcb->m_segmentSize = (int) (27.293+(59.803)+(55.927)+(5.537)+(tcb->m_cWnd)+(30.489)+(tcb->m_segmentSize)+(1.091));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	wQPzTZKzVqMrNdeS = (float) (8.851+(39.027)+(16.817));
	wQPzTZKzVqMrNdeS = (float) (5.524/92.934);
	tcb->m_cWnd = (int) (54.157*(89.987)*(85.163)*(12.375)*(73.016)*(59.85)*(36.158)*(95.656)*(8.684));

}
ReduceCwnd (tcb);
