ReduceCwnd (tcb);
tcb->m_cWnd = (int) (76.812+(66.679));
cnt = (int) (92.5+(54.673)+(98.465)+(tcb->m_ssThresh)+(1.358)+(tcb->m_ssThresh)+(tcb->m_cWnd));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (cnt-(94.763)-(36.372)-(45.539)-(30.067)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (cnt*(19.392)*(63.214)*(21.509)*(9.248)*(tcb->m_cWnd)*(61.702)*(68.485)*(43.368));
	tcb->m_segmentSize = (int) (34.052-(51.144)-(37.048)-(67.127));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (((0.1)+(0.1)+((33.836*(50.464)*(13.638)*(82.673)*(segmentsAcked)*(20.115)*(22.018)*(71.964)*(69.265)))+(58.457))/((0.1)+(26.353)));
int IEalPbLbtErcxwPH = (int) (0.1/69.888);
ReduceCwnd (tcb);
