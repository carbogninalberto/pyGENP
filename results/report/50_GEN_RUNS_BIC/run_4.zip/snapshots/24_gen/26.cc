if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (39.664-(tcb->m_segmentSize)-(11.523)-(77.212)-(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (segmentsAcked-(14.664)-(24.681)-(72.328)-(65.812)-(46.419)-(94.131));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(51.994)-(segmentsAcked)-(66.829));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(cnt)*(32.948)*(94.927)*(-0.05)*(4.062)*(70.461)*(tcb->m_cWnd)*(60.432));

} else {
	tcb->m_cWnd = (int) (24.724-(segmentsAcked)-(99.347)-(17.149)-(75.875));
	tcb->m_ssThresh = (int) (68.937-(14.858));

}
tcb->m_ssThresh = (int) ((((67.379-(21.299)))+(0.1)+(0.1)+(0.1)+(65.091))/((0.1)+(0.1)+(0.1)+(30.573)));
ReduceCwnd (tcb);
float MEvEvkgmwQUjdJxN = (float) (((0.1)+(0.1)+(0.1)+(0.1))/((24.958)+(42.82)+(71.648)+(0.1)));
