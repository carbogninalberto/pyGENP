ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (16.582+(64.874)+(-93.331)+(-67.681)+(56.104)+(-88.887));
