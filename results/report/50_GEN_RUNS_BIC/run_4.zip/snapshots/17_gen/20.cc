if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (segmentsAcked*(42.962)*(79.561));
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd*(cnt)*(64.89)*(59.806)*(cnt)*(32.625));

} else {
	segmentsAcked = (int) (82.42-(44.263)-(48.289)-(1.324));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
