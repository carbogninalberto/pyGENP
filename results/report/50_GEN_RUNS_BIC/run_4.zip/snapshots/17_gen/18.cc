if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (segmentsAcked*(80.256)*(84.929)*(34.246)*(63.537));

} else {
	tcb->m_segmentSize = (int) (33.868/(72.554-(tcb->m_ssThresh)-(39.393)-(59.902)-(16.994)));

}
if (tcb->m_cWnd <= cnt) {
	cnt = (int) (76.546*(17.05)*(segmentsAcked)*(tcb->m_cWnd)*(35.781)*(13.556)*(5.674)*(70.735));
	tcb->m_cWnd = (int) (0.1/33.056);
	tcb->m_segmentSize = (int) (63.073+(52.102)+(66.697));

} else {
	cnt = (int) (25.997/93.782);

}
tcb->m_cWnd = (int) (6.881-(66.04)-(1.276));
tcb->m_segmentSize = (int) (2.092-(37.879)-(18.836)-(segmentsAcked)-(20.043));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > tcb->m_segmentSize) {
	segmentsAcked = (int) (85.645*(49.555));
	cnt = (int) (37.306/0.1);
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (40.813+(98.203)+(tcb->m_segmentSize)+(58.729));
	tcb->m_segmentSize = (int) (24.999-(78.227)-(58.483));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
