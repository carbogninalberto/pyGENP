float UvmTpmHzYaVodfna = (float) (-21.387-(-18.188)-(47.813)-(-24.47)-(-68.528)-(63.541));
UvmTpmHzYaVodfna = (float) (-64.943+(-93.54)+(18.268)+(54.659)+(37.492)+(-18.82)+(-54.297)+(-92.578));
float rBwdjfiqwnvrsANi = (float) 21.466;
