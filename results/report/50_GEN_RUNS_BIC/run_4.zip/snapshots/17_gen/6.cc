ReduceCwnd (tcb);
int YDQGbFOnMVtJbLBK = (int) (62.668*(-60.07)*(2.374)*(34.099)*(67.715)*(-6.179)*(55.177)*(-59.161)*(-78.658));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
