ReduceCwnd (tcb);
ReduceCwnd (tcb);
float vOoQcQShEYGgexAa = (float) (70.599-(17.395)-(85.205)-(tcb->m_cWnd)-(29.954)-(28.446)-(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (((77.406)+(0.1)+(23.574)+(92.008)+((92.88-(42.56)))+((9.45-(tcb->m_cWnd)-(69.625)-(39.937)-(78.123)-(31.53)-(9.094)-(18.411)-(36.624)))+(63.359))/((0.1)));
if (tcb->m_segmentSize < segmentsAcked) {
	cnt = (int) (0.1/(20.577-(80.257)-(53.092)-(65.973)-(segmentsAcked)-(97.315)));

} else {
	cnt = (int) (tcb->m_ssThresh+(42.464)+(tcb->m_segmentSize)+(12.325)+(37.865)+(93.27));
	tcb->m_ssThresh = (int) (0.1/0.1);
	cnt = (int) (cnt-(29.846)-(40.663));

}
segmentsAcked = (int) (43.569*(tcb->m_ssThresh)*(89.767));
