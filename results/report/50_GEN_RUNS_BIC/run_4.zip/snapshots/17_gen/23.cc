tcb->m_cWnd = (int) (46.128-(79.267)-(segmentsAcked)-(cnt)-(tcb->m_segmentSize)-(cnt)-(91.126));
if (tcb->m_ssThresh < tcb->m_cWnd) {
	segmentsAcked = (int) (98.146*(30.791)*(49.606)*(95.859)*(19.127)*(cnt)*(50.376)*(7.016)*(36.599));
	tcb->m_cWnd = (int) (0.348*(6.588));

} else {
	segmentsAcked = (int) (81.628-(tcb->m_ssThresh)-(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) ((65.418+(tcb->m_segmentSize)+(31.068))/51.045);

}
if (tcb->m_cWnd < segmentsAcked) {
	cnt = (int) (34.318*(segmentsAcked)*(89.651)*(cnt)*(90.626));
	segmentsAcked = (int) (89.814-(73.041)-(51.777)-(37.364)-(27.212)-(segmentsAcked)-(49.526)-(91.868)-(62.817));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (65.039-(tcb->m_segmentSize)-(87.509));
	tcb->m_segmentSize = (int) ((72.758*(36.048)*(14.084)*(cnt)*(0.644)*(10.036))/0.1);
	tcb->m_segmentSize = (int) (56.825*(3.631)*(tcb->m_cWnd)*(31.086)*(27.103)*(59.794)*(42.474));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (88.283+(17.309)+(4.221)+(9.912)+(17.498)+(80.042)+(10.137));
