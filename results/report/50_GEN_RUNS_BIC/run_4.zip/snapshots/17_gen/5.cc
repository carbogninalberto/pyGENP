tcb->m_segmentSize = (int) (((48.632)+(51.491)+(-1.25)+(-57.113)+(82.108)+(86.94)+(11.248))/((96.111)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
