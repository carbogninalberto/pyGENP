float ujtCeBayOxRRPUlQ = (float) 5.577;
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
