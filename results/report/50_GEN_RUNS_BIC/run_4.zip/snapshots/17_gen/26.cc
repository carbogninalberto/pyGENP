if (cnt <= tcb->m_cWnd) {
	cnt = (int) (61.46*(93.57)*(tcb->m_ssThresh)*(53.817));
	tcb->m_cWnd = (int) (72.489*(31.22)*(48.225)*(86.335)*(tcb->m_segmentSize)*(31.595)*(56.943)*(43.422));

} else {
	cnt = (int) (72.927*(35.954)*(tcb->m_segmentSize));
	segmentsAcked = (int) (30.584+(16.448)+(45.234)+(13.887)+(cnt)+(tcb->m_cWnd)+(13.405)+(76.113));
	segmentsAcked = (int) (1.668+(cnt)+(92.222)+(70.756)+(23.529)+(31.205)+(segmentsAcked));

}
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/0.1);
	segmentsAcked = (int) (88.28-(87.065)-(98.708)-(49.343)-(tcb->m_cWnd)-(cnt));
	cnt = (int) (18.853+(tcb->m_ssThresh)+(88.58)+(67.068)+(20.464)+(27.605));

} else {
	tcb->m_cWnd = (int) (36.852-(12.222)-(70.133)-(tcb->m_cWnd)-(85.949));
	cnt = (int) (5.532-(23.961)-(66.715)-(tcb->m_ssThresh));

}
tcb->m_segmentSize = (int) (39.022+(32.99)+(77.734)+(75.46));
tcb->m_ssThresh = (int) (0.1/69.533);
tcb->m_ssThresh = (int) (0.1/0.1);
tcb->m_ssThresh = (int) (8.519-(24.115)-(8.609)-(61.723));
