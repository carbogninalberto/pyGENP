if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (92.181-(tcb->m_ssThresh)-(20.198)-(14.775)-(34.424)-(42.974)-(90.695));
	segmentsAcked = (int) (tcb->m_cWnd*(70.884)*(4.939)*(90.692)*(73.001)*(51.623));
	tcb->m_segmentSize = (int) (33.248-(7.691)-(60.575)-(82.85)-(60.249)-(1.645)-(77.826)-(tcb->m_segmentSize)-(73.344));

} else {
	tcb->m_cWnd = (int) (47.678+(96.805)+(71.672)+(5.02)+(segmentsAcked)+(37.089));
	segmentsAcked = (int) (21.662+(84.119)+(10.891)+(5.891)+(tcb->m_cWnd)+(84.646)+(39.617)+(segmentsAcked));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	cnt = (int) (((0.1)+(0.1)+(46.164)+(0.1)+((97.752+(78.638)+(43.404)+(40.676)+(43.583)+(55.217)))+(0.1)+(83.979))/((74.99)+(0.1)));
	tcb->m_segmentSize = (int) (30.227*(tcb->m_cWnd)*(21.582)*(10.183)*(78.166)*(67.564)*(tcb->m_segmentSize)*(53.897)*(63.672));

} else {
	cnt = (int) (cnt+(38.56));
	cnt = (int) (((0.1)+((66.369+(60.111)+(3.062)+(3.997)+(tcb->m_cWnd)+(49.435)+(33.689)+(22.544)))+((40.758-(94.352)-(17.933)-(52.051)-(47.001)-(tcb->m_ssThresh)))+(43.3))/((0.1)));

}
tcb->m_ssThresh = (int) ((98.821-(23.181)-(6.889)-(67.968))/27.462);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) ((85.884+(43.798)+(35.189)+(28.88))/0.1);
if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (49.883-(11.588)-(5.406)-(52.868)-(52.297)-(11.448));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (0.1/95.718);

} else {
	segmentsAcked = (int) (37.026+(46.2)+(62.105)+(87.016)+(0.694)+(13.823));

}
ReduceCwnd (tcb);
