if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (14.619*(-92.091)*(18.348));
tcb->m_segmentSize = (int) (-31.42*(-78.127)*(67.647));
segmentsAcked = (int) (27.304/-17.667);
segmentsAcked = (int) (-67.089/5.755);
