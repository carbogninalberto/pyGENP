ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= cnt) {
	cnt = (int) (76.766-(64.506));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (49.449*(21.849)*(13.012)*(25.513)*(93.987));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (89.397+(34.982)+(32.644)+(cnt)+(27.099)+(1.072)+(84.93)+(75.579));

}
if (tcb->m_ssThresh == segmentsAcked) {
	cnt = (int) ((((tcb->m_cWnd*(18.297)*(42.127)*(2.032)*(tcb->m_segmentSize)*(56.915)*(segmentsAcked)))+(0.1)+((5.571*(94.614)*(9.77)*(17.197)*(tcb->m_ssThresh)*(46.964)*(76.1)*(segmentsAcked)))+(3.98))/((54.503)+(0.1)+(26.456)+(0.1)));

} else {
	cnt = (int) (65.541+(51.757)+(96.099)+(5.328)+(30.646)+(94.35)+(23.29)+(tcb->m_cWnd)+(60.022));

}
cnt = (int) (60.313*(54.042)*(82.979)*(28.58));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (84.976*(0.417)*(15.03)*(cnt)*(10.524)*(74.286));
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_segmentSize*(35.539)*(66.317)*(58.558)*(92.811)*(33.109)*(66.007));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (38.036*(7.307)*(72.75)*(55.599)*(98.97));
	tcb->m_segmentSize = (int) (17.362/0.1);
	segmentsAcked = (int) (10.946-(42.804)-(61.456)-(58.798)-(tcb->m_cWnd)-(cnt));

}
