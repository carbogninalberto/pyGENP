if (cnt < cnt) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(82.508)*(10.127)*(93.746));

} else {
	tcb->m_segmentSize = (int) (51.116*(15.937)*(5.41)*(48.962)*(57.544));
	segmentsAcked = (int) (12.012-(94.612)-(10.656)-(33.521)-(70.653));
	tcb->m_ssThresh = (int) (0.1/0.1);

}
if (tcb->m_segmentSize <= segmentsAcked) {
	cnt = (int) (92.074-(tcb->m_segmentSize)-(22.464)-(55.352)-(29.445)-(22.648)-(82.184)-(40.676)-(7.244));
	cnt = (int) (28.97+(segmentsAcked)+(tcb->m_cWnd)+(52.194)+(cnt)+(tcb->m_ssThresh)+(65.301));

} else {
	cnt = (int) (99.127+(44.984)+(tcb->m_cWnd)+(84.067)+(38.055)+(35.516)+(tcb->m_ssThresh)+(98.902)+(89.387));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
int NgNwrzLbSzzfIobZ = (int) (((0.1)+((95.313*(11.931)*(88.041)*(tcb->m_ssThresh)*(tcb->m_ssThresh)))+((5.327*(65.97)*(96.083)*(tcb->m_segmentSize)*(58.627)*(46.427)*(71.206)*(8.453)*(tcb->m_cWnd)))+(86.18))/((0.1)));
