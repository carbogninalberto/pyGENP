tcb->m_segmentSize = (int) (93.07+(tcb->m_ssThresh)+(cnt)+(89.692)+(1.857)+(22.647)+(92.828));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt <= tcb->m_ssThresh) {
	cnt = (int) (37.767-(segmentsAcked)-(76.294)-(27.635)-(29.396)-(49.149)-(80.61)-(56.636));

} else {
	cnt = (int) (tcb->m_segmentSize*(62.176)*(24.914));

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	cnt = (int) (segmentsAcked-(87.745)-(tcb->m_cWnd)-(73.555)-(71.211)-(80.838)-(62.699)-(8.212));
	cnt = (int) (26.627+(tcb->m_ssThresh)+(28.189));

} else {
	cnt = (int) (43.035-(25.165)-(57.155));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize != segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked-(42.118)-(5.392)-(segmentsAcked)-(86.708));

} else {
	segmentsAcked = (int) (95.205-(64.029)-(21.649)-(89.938)-(7.519));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (24.969-(31.228)-(tcb->m_cWnd)-(94.967)-(94.62)-(54.696)-(26.777)-(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (94.658*(1.239)*(94.568)*(39.926)*(68.36)*(tcb->m_cWnd)*(cnt));
ReduceCwnd (tcb);
