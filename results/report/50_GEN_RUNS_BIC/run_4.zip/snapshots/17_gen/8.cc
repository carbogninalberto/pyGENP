segmentsAcked = (int) ((-53.567*(38.781)*(76.465)*(87.305)*(tcb->m_ssThresh))/-45.794);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-23.41*(-53.081)*(3.633));
segmentsAcked = (int) (-2.037/31.37);
