segmentsAcked = (int) (-89.599-(-6.875)-(75.056)-(57.301)-(-30.547)-(-92.284)-(-52.558));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
