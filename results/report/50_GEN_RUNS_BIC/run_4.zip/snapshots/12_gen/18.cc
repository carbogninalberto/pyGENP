tcb->m_segmentSize = (int) (((-38.243)+(51.164)+((-23.152+(-82.449)+(-96.507)+(11.682)+(61.482)+(tcb->m_ssThresh)+(-1.52)+(15.89)+(68.9)))+(-5.499))/((70.044)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (42.518+(67.756)+(-23.758)+(78.255)+(-12.629)+(-10.288)+(98.436)+(-60.943));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
