segmentsAcked = (int) (-41.784/-28.096);
tcb->m_segmentSize = (int) (((98.349)+(80.486)+((82.575+(65.15)+(58.527)+(-69.697)+(21.02)+(tcb->m_ssThresh)+(60.631)+(45.79)+(83.6)))+(-60.397))/((-58.226)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-6.232+(43.499)+(-81.282)+(-65.719)+(-4.196)+(34.092)+(96.288)+(-34.726));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
