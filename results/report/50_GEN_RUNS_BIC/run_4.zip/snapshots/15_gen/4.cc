ReduceCwnd (tcb);
int weJPkFwyPcequUBr = (int) 60.846;
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

}
segmentsAcked = (int) (-86.678-(22.354)-(62.461)-(9.412)-(-56.32)-(-0.445)-(57.736)-(-61.114)-(-90.486));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (96.334+(94.418)+(19.008)+(-80.246)+(50.139)+(92.446)+(51.147)+(43.245)+(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(45.018)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

} else {
	segmentsAcked = (int) (94.034+(62.242));
	weJPkFwyPcequUBr = (int) (95.435+(80.446));
	tcb->m_segmentSize = (int) (71.449-(28.574)-(96.978)-(96.261)-(15.226)-(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (44.392-(51.242)-(-27.288)-(17.517)-(30.7)-(-70.153)-(97.671)-(83.135)-(-50.653));
segmentsAcked = (int) (-86.494-(43.2)-(-44.277)-(-43.272)-(-95.361)-(-14.015)-(-52.229)-(-8.793)-(-87.435));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
