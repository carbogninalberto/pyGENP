tcb->m_segmentSize = (int) (8.208/0.1);
tcb->m_segmentSize = (int) (80.666+(4.55)+(26.592)+(23.714)+(31.896)+(tcb->m_cWnd)+(61.458));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (11.527-(81.151)-(51.146)-(66.132)-(41.803));
