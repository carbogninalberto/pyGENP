float HwNtqlxUEPRmHABP = (float) (26.109*(9.686)*(tcb->m_ssThresh)*(88.849)*(98.174)*(tcb->m_cWnd)*(61.144));
if (tcb->m_cWnd <= cnt) {
	tcb->m_ssThresh = (int) (88.341-(87.839)-(21.127)-(77.442)-(10.184));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked*(8.972)*(60.986)*(98.696)*(tcb->m_segmentSize)*(60.025));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
float IFHJleMaqFVgKqxl = (float) (91.695*(5.56)*(HwNtqlxUEPRmHABP)*(54.54)*(49.781)*(17.608)*(76.888)*(86.534));
tcb->m_segmentSize = (int) (24.411-(24.853)-(25.976)-(65.01)-(14.249)-(59.256)-(16.755)-(95.648));
if (tcb->m_segmentSize > IFHJleMaqFVgKqxl) {
	HwNtqlxUEPRmHABP = (float) (85.41+(10.176)+(73.468));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	HwNtqlxUEPRmHABP = (float) (17.627-(88.053)-(38.908));
	cnt = (int) (52.135+(81.049));
	tcb->m_ssThresh = (int) (20.553-(34.584)-(76.521));

}
tcb->m_cWnd = (int) (65.512+(segmentsAcked)+(74.665)+(70.529)+(HwNtqlxUEPRmHABP)+(44.645));
ReduceCwnd (tcb);
