if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (83.091*(-34.269)*(-79.151)*(-17.618)*(50.96));
ReduceCwnd (tcb);
