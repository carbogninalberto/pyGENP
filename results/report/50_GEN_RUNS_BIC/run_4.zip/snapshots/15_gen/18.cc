cnt = (int) (tcb->m_segmentSize+(15.09)+(29.954)+(segmentsAcked)+(63.231)+(96.514)+(53.576));
if (cnt <= segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(98.106)*(66.738)*(27.24)*(54.782)*(0.98)*(16.615));
	segmentsAcked = (int) (3.301/0.1);

} else {
	tcb->m_segmentSize = (int) (17.45+(33.175)+(95.079)+(41.41)+(39.307)+(50.555)+(53.852)+(tcb->m_cWnd)+(85.446));
	tcb->m_ssThresh = (int) ((58.001+(cnt)+(tcb->m_cWnd)+(37.085))/78.968);

}
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (89.585*(48.904)*(47.881)*(2.836)*(53.654));

} else {
	tcb->m_cWnd = (int) (((0.1)+(31.822)+(80.018)+(0.1))/((70.094)+(0.1)+(41.484)));

}
cnt = (int) (50.997/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
