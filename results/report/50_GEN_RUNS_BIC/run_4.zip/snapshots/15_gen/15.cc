if (tcb->m_cWnd <= cnt) {
	tcb->m_cWnd = (int) (55.677-(2.561)-(71.886)-(41.785)-(47.448)-(3.513));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (91.26-(18.318)-(37.764)-(4.36)-(2.101)-(30.68));

}
cnt = (int) (1.992+(42.375)+(cnt)+(48.597)+(98.8)+(19.008)+(15.963)+(37.364));
int RbTPwxiKKEqtFJuz = (int) (((6.282)+(74.979)+((6.791+(14.654)+(73.477)+(69.329)))+(0.1)+(78.51)+(24.463))/((0.1)+(36.026)+(0.1)));
segmentsAcked = (int) (6.37*(0.577)*(77.881)*(51.309)*(19.025)*(17.382)*(87.664)*(9.451)*(tcb->m_ssThresh));
if (RbTPwxiKKEqtFJuz == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(76.762))/((0.1)+(0.1)+(22.112)+(0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (2.815-(11.996)-(tcb->m_cWnd)-(58.175)-(92.551)-(19.688)-(28.205));
	tcb->m_cWnd = (int) (44.157-(93.529)-(56.951)-(tcb->m_ssThresh)-(50.376));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (52.746-(47.081)-(82.285));
if (tcb->m_ssThresh < cnt) {
	cnt = (int) (tcb->m_ssThresh+(5.302)+(77.814)+(30.427)+(69.371));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (97.274-(53.758)-(88.739)-(20.973)-(42.26)-(22.342)-(58.067));
	cnt = (int) (45.917/30.215);

}
