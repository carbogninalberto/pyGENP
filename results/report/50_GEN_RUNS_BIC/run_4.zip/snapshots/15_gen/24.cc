cnt = (int) (39.104+(81.992)+(16.636)+(65.257)+(31.73)+(74.518)+(9.669)+(tcb->m_ssThresh));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
float XHyfhDWDiBFYtlhh = (float) (59.921+(28.59)+(30.811)+(tcb->m_cWnd)+(60.052)+(14.863));
cnt = (int) (84.511/0.1);
cnt = (int) (cnt-(18.027)-(57.703)-(22.104)-(cnt)-(tcb->m_segmentSize)-(29.79));
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (16.573*(tcb->m_ssThresh));
XHyfhDWDiBFYtlhh = (float) (11.217*(28.813)*(tcb->m_cWnd)*(64.833)*(segmentsAcked));
