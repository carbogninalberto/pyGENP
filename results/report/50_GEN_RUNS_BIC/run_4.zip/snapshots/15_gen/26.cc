if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (42.622+(15.489));
cnt = (int) (tcb->m_segmentSize-(47.956)-(cnt)-(98.914));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (78.829+(19.929)+(13.014));

} else {
	tcb->m_segmentSize = (int) (61.65+(0.064));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (0.1/0.1);
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= cnt) {
	cnt = (int) (69.79-(70.247)-(27.638)-(70.588)-(30.788)-(1.445));
	tcb->m_segmentSize = (int) ((85.52+(tcb->m_ssThresh)+(tcb->m_cWnd)+(20.471)+(69.148)+(11.458))/42.251);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (52.826*(22.449));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (34.422+(75.563)+(85.558));

}
if (cnt <= tcb->m_cWnd) {
	segmentsAcked = (int) ((cnt-(80.167))/77.728);
	tcb->m_cWnd = (int) (34.852*(cnt)*(tcb->m_segmentSize)*(segmentsAcked)*(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (96.455+(10.018)+(77.136)+(67.065)+(tcb->m_cWnd)+(88.43));

}
