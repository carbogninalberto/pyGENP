if (cnt < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (80.927+(4.371));

} else {
	tcb->m_segmentSize = (int) (78.179-(74.989)-(2.885));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd  = tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (tcb->m_ssThresh+(11.642)+(26.972));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (88.239/77.183);
	tcb->m_ssThresh = (int) (62.823*(98.255)*(39.628)*(tcb->m_cWnd));
	cnt = (int) (44.191-(12.107)-(95.621)-(86.794)-(cnt)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(46.363)-(cnt));

} else {
	tcb->m_ssThresh = (int) (0.1/74.54);
	cnt = (int) (98.199*(cnt)*(segmentsAcked)*(12.931)*(49.713)*(tcb->m_segmentSize)*(44.308)*(cnt));

}
tcb->m_segmentSize = (int) (cnt*(86.781));
