tcb->m_cWnd = (int)(tcb->m_segmentSize * (58.472));
if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
if (segmentsAcked == tcb->m_cWnd) {
    cnt = (int)(54.968 + (55.346) + (41.561) + (67.775));
    tcb->m_ssThresh = (int)(93.85 - (segmentsAcked) - (28.779) - (45.297));

} else {
    cnt = (int)(cnt - (89.603) - (91.174) - (23.429));
    segmentsAcked = (int)(70.556 * (tcb->m_segmentSize) * (86.483) * (3.499) * (88.93) * (86.648) * (59.407));
}
if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
ReduceCwnd(tcb);
