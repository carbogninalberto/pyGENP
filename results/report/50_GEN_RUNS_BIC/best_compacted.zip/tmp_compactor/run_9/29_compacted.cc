tcb->m_cWnd = (int)(tcb->m_segmentSize * 58.472);
if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
if (segmentsAcked == tcb->m_cWnd) {
    cnt = (int)219.65;
    tcb->m_ssThresh = (int)(93.85 - (segmentsAcked) - (28.779) - (45.297));
} else {
    cnt = (int)(cnt-- 25.0);
    segmentsAcked = (int)(70.556 * (tcb->m_segmentSize) * (86.483) * (3.499) * (88.93) * (86.648) * (59.407));
}
if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
ReduceCwnd(tcb);
