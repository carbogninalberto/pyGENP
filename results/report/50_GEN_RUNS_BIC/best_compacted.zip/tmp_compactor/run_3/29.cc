ReduceCwnd (tcb);
if (tcb->m_cWnd > tcb->m_ssThresh) {
	cnt = (int) (48.527-(20.334)-(tcb->m_ssThresh)-(36.39)-(cnt)-(98.299)-(tcb->m_ssThresh)-(77.262)-(-0.088));
	tcb->m_ssThresh = (int) (cnt+(68.504)+(57.028));
	segmentsAcked = (int) (35.14*(57.595)*(53.424)*(90.723)*(87.214)*(30.69));

} else {
	cnt = (int) (53.632*(tcb->m_cWnd));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(cnt)-(33.958)-(tcb->m_ssThresh)-(81.654)-(74.585)-(76.675));
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	cnt = (int) (tcb->m_ssThresh-(18.202)-(44.673)-(14.754)-(segmentsAcked)-(cnt));
	tcb->m_ssThresh = (int) (64.556-(95.78)-(58.424)-(99.969)-(10.285)-(64.562)-(cnt)-(4.014));

} else {
	cnt = (int) (37.568*(85.684)*(22.499));
	cnt = (int) (cnt+(tcb->m_ssThresh)+(42.246)+(segmentsAcked)+(36.694));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
