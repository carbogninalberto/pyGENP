if (cnt != segmentsAcked) {
tcb->m_segmentSize = (int) (13.704*(53.117)*(74.527)*(segmentsAcked)*(61.69)*(17.898));
} else {
tcb->m_segmentSize = (int) -352.836;
tcb->m_ssThresh = (int) 1.1327758420441347;
}
int MkycqeZLOKenojJc = (int) (((0.1)+(0.1)+(30.086)+(0.1)+(49.155)+(0.1)+(0.1))/((0.1)+(51.392)));
cnt = (int) (94.326*(89.844)*(7.283)*(47.081)*(tcb->m_ssThresh)*(94.293)*(segmentsAcked)*(72.366)*(25.407));
ReduceCwnd (tcb);
if (tcb->m_ssThresh > cnt) {
tcb->m_cWnd = (int) (segmentsAcked+(68.779)+(83.102)+(85.846)+(cnt)+(9.069));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
MkycqeZLOKenojJc = (int) (23.82-(79.771)-(14.523)-(27.086)-(65.009)-(0.513)-(49.232)-(tcb->m_ssThresh));
} else {
tcb->m_cWnd = (int) (52.023-(70.074)-(19.636)-(tcb->m_ssThresh)-(47.417)-(55.579)-(MkycqeZLOKenojJc));
}
ReduceCwnd (tcb);
