ReduceCwnd(tcb);
float zAvMWbweoJSMqeZX = (float)386.509;
if (zAvMWbweoJSMqeZX <= tcb->m_ssThresh) {
    zAvMWbweoJSMqeZX = (float)(78.398 - (tcb->m_cWnd) - (7.063) - (segmentsAcked) - (50.406) - (12.175) - (zAvMWbweoJSMqeZX) - (59.863));
} else {
    zAvMWbweoJSMqeZX = (float)(18.859 - (31.536) - (4.134) - (cnt));
    segmentsAcked = (int)(5.811 - (91.324) - (8.273) - (zAvMWbweoJSMqeZX) - (31.662) - (45.991) - (56.763) - (45.774) - (43.493));
}
if (segmentsAcked == tcb->m_cWnd) {
    cnt = (int)60.466;
} else {
    cnt = (int)(segmentsAcked - 28.556999999999995);
}
if (zAvMWbweoJSMqeZX < tcb->m_cWnd) {
    cnt = (int)(38.864 - (cnt) - (4.5) - (42.343) - (tcb->m_ssThresh));
    tcb->m_segmentSize = (int)6203995419.251839;
} else {
    cnt = (int)(cnt + (49.211) + (tcb->m_ssThresh) + (9.538) + (50.35) + (56.26) + (zAvMWbweoJSMqeZX) + (cnt));
}
zAvMWbweoJSMqeZX = (float)0.0011299435028248588;
