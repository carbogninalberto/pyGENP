ReduceCwnd(tcb);
if (tcb->m_cWnd < segmentsAcked) {
    segmentsAcked = (int)(69.259 - (19.93) - (cnt) - (52.735) - (77.74) - (18.338) - (segmentsAcked));
} else {
    segmentsAcked = (int)-100.24799999999999;
}
float PaAzklzbfYAfGtWa = (float)1.0;
if (PaAzklzbfYAfGtWa != segmentsAcked) {
    tcb->m_cWnd = (int)(55.003 + (PaAzklzbfYAfGtWa) + (42.554) + (27.921));
    tcb->m_ssThresh = (int)348.919;
    cnt = (int)64389.432012525;
} else {
    tcb->m_cWnd = (int)(((0.1) + ((46.275 * (52.805) * (9.314) * (tcb->m_cWnd) * (40.692) * (tcb->m_ssThresh))) + ((15.807 * (76.058) * (tcb->m_cWnd) * (81.292) * (29.01) * (45.484) * (24.727) * (PaAzklzbfYAfGtWa))) + (19.61) + (0.1)) / ((56.963) + (55.877) + (0.1) + (0.1)));
    tcb->m_cWnd = (int)(tcb->m_cWnd + (18.996) + (97.146) + (27.727) + (92.182) + (1.493) + (segmentsAcked) + (48.025) + (tcb->m_cWnd));
}
tcb->m_cWnd = (int)(43.43 + (tcb->m_cWnd) + (31.627) + (60.55) + (77.922) + (6.591) + (37.427) + (57.513) + (cnt));
if (m_cWndCnt > cnt) {
    tcb->m_cWnd = tcb->m_segmentSize;
    m_cWndCnt = 0;
}
