int MmlyEIPxHKbjXuiM = (int)(51.763 - (tcb->m_ssThresh) - (2.64) - (93.107) - (68.088));
if (tcb->m_ssThresh == MmlyEIPxHKbjXuiM) {
    MmlyEIPxHKbjXuiM = (int)2.494;
} else {
    MmlyEIPxHKbjXuiM = (int)1.0;
    if (m_cWndCnt > cnt) {
        tcb->m_cWnd += tcb->m_segmentSize;
        m_cWndCnt = 0;
    }
    tcb->m_ssThresh = (int)286.296;
}
ReduceCwnd(tcb);
if (tcb->m_cWnd != MmlyEIPxHKbjXuiM) {
    cnt = (int)(segmentsAcked + (tcb->m_cWnd) + 291.407);
    MmlyEIPxHKbjXuiM = (int)164.775;
    segmentsAcked = (int)4604.865;
} else {
    cnt = (int)(tcb->m_segmentSize * (tcb->m_cWnd) * 8.93);
    if (m_cWndCnt > cnt) {
        tcb->m_cWnd += tcb->m_segmentSize;
        m_cWndCnt = 0;
    }
    tcb->m_cWnd = (int)-32.213;
}
if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
tcb->m_cWnd = (int)259.1;
if (segmentsAcked > cnt) {
    MmlyEIPxHKbjXuiM = (int)327.238;
} else {
    MmlyEIPxHKbjXuiM = (int)0.18;
    MmlyEIPxHKbjXuiM = (int)(55.277 + (tcb->m_segmentSize) + (7.161) + (84.048) + (43.97));
    MmlyEIPxHKbjXuiM = (int)(61.829 + (66.973) + (40.639) + (44.274) + (46.431) + (MmlyEIPxHKbjXuiM));
}
