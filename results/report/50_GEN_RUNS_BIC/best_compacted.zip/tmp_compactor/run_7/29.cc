int MmlyEIPxHKbjXuiM = (int)(51.763 - (tcb->m_ssThresh) - (2.64) - (93.107) - (68.088));
if (tcb->m_ssThresh == MmlyEIPxHKbjXuiM) {
    MmlyEIPxHKbjXuiM = (int)(((0.1) + (77.062) + (21.34) + (0.1) + (0.1) + (0.1) + (0.1) + (18.805)) / ((47.194)));

} else {
    MmlyEIPxHKbjXuiM = (int)(0.1 / 0.1);
    if (m_cWndCnt > cnt) {
        tcb->m_cWnd += tcb->m_segmentSize;
        m_cWndCnt = 0;
    }
    tcb->m_ssThresh = (int)(90.898 + (70.258) + (69.917) + (55.223));
}
ReduceCwnd(tcb);
if (tcb->m_cWnd != MmlyEIPxHKbjXuiM) {
    cnt = (int)(segmentsAcked + (tcb->m_cWnd) + (70.281) + (36.772) + (83.304) + (74.467) + (4.773) + (21.81));
    MmlyEIPxHKbjXuiM = (int)(((0.1) + (0.1) + (0.1) + (0.1) + (32.355) + (0.1) + (0.1)) / ((0.1) + (0.1)));
    segmentsAcked = (int)(48.073 * (95.789));

} else {
    cnt = (int)(tcb->m_segmentSize * (tcb->m_cWnd) * (8.93));
    if (m_cWndCnt > cnt) {
        tcb->m_cWnd += tcb->m_segmentSize;
        m_cWndCnt = 0;
    }
    tcb->m_cWnd = (int)(58.832 - (91.045));
}
if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
tcb->m_cWnd = (int)(25.91 / 0.1);
if (segmentsAcked > cnt) {
    MmlyEIPxHKbjXuiM = (int)(99.646 + (10.715) + (95.802) + (37.385) + (83.69));

} else {
    MmlyEIPxHKbjXuiM = (int)(9.807 / 54.497);
    MmlyEIPxHKbjXuiM = (int)(55.277 + (tcb->m_segmentSize) + (7.161) + (84.048) + (43.97));
    MmlyEIPxHKbjXuiM = (int)(61.829 + (66.973) + (40.639) + (44.274) + (46.431) + (MmlyEIPxHKbjXuiM));
}
