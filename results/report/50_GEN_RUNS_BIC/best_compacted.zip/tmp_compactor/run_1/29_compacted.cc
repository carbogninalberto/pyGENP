if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
if (cnt != segmentsAcked) {
    tcb->m_cWnd = (int)120494.383;
} else {
    tcb->m_cWnd = (int)-199.723;
}
if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
ReduceCwnd(tcb);
