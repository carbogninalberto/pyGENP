if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
if (cnt != segmentsAcked) {
    tcb->m_cWnd = (int)((((37.177 + (14.08) + (39.77))) + (9.465) + ((28.38 + (33.705))) + ((74.057 * (41.363) * (84.148) * (56.919))) + (26.314) + (0.1) + (30.713)) / ((45.478) + (76.286)));
} else {
    tcb->m_cWnd = (int)-199.723;
}
if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
ReduceCwnd(tcb);
