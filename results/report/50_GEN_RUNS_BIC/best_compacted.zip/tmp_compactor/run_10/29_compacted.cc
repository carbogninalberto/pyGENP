ReduceCwnd(tcb);
if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
ReduceCwnd(tcb);
if (cnt == tcb->m_cWnd) {
    cnt = (int)(73.949 - (cnt) - (46.095) - (99.977) - (82.89) - (54.344) - (99.948) - (63.338));
    segmentsAcked = (int)(84.968 + (12.269) + (94.576) + (69.448) + (tcb->m_segmentSize) + (27.938) + (segmentsAcked) + (tcb->m_ssThresh) + (89.861));
    if (m_cWndCnt > cnt) {
        tcb->m_cWnd += tcb->m_segmentSize;
        m_cWndCnt = 0;
    }
} else {
    cnt = (int)-345.259;
    if (m_cWndCnt > cnt) {
        tcb->m_cWnd += tcb->m_segmentSize;
        m_cWndCnt = 0;
    }
}
if (tcb->m_segmentSize >= cnt) {
    tcb->m_cWnd = (int)1.0;
} else {
    tcb->m_cWnd = (int)66567.6078248664;
}
ReduceCwnd(tcb);
