if (tcb->m_ssThresh == tcb->m_ssThresh) {
    cnt = (int)975.08;
} else {
    cnt = (int)22727434813.706;
}
ReduceCwnd(tcb);
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
    tcb->m_cWnd = (int)120.01;
} else {
    tcb->m_cWnd = (int)(87.868 + (43.625) + (66.049) + (tcb->m_cWnd) + (44.21) + (tcb->m_ssThresh));
    if (m_cWndCnt > cnt) {
        tcb->m_cWnd += tcb->m_segmentSize;
        m_cWndCnt = 0;
    }
}
tcb->m_cWnd = (int)41906.251;
