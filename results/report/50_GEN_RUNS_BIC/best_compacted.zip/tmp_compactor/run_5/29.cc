if (tcb->m_ssThresh == tcb->m_ssThresh) {
    cnt = (int)(97.508 / 0.1);

} else {
    cnt = (int)(5.871 * (4.539) * (75.691) * (97.028) * (30.45) * (39.941) * (95.484));
}
ReduceCwnd(tcb);
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
    tcb->m_cWnd = (int)(18.178 + (7.311) + (0.084) + (75.062) + (19.375));

} else {
    tcb->m_cWnd = (int)(87.868 + (43.625) + (66.049) + (tcb->m_cWnd) + (44.21) + (tcb->m_ssThresh));
    if (m_cWndCnt > cnt) {
        tcb->m_cWnd += tcb->m_segmentSize;
        m_cWndCnt = 0;
    }
}
float JjknBaQPOFuoqmnx = (float)(86.484 + (53.412) + (cnt));
tcb->m_cWnd = (int)(95.996 * (48.656) * (8.972));
