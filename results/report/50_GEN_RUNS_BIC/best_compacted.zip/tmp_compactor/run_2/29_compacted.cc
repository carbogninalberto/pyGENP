if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
if (tcb->m_cWnd >= segmentsAcked) {
    segmentsAcked = (int)-2.5460000000000065;
    ReduceCwnd(tcb);
    segmentsAcked = (int)11.065664314206813;
} else {
    segmentsAcked = (int)13953.13437556;
    cnt = (int)(75.543 - (58.348) - (66.019) - (tcb->m_cWnd) - (39.143) - (30.801) - (55.39) - (68.035) - (tcb->m_segmentSize));
}
if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
tcb->m_cWnd = (int)(segmentsAcked - (47.737) - (34.522) - (62.265) - (67.195) - (tcb->m_ssThresh));
if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
if (tcb->m_segmentSize != tcb->m_cWnd) {
    segmentsAcked = (int)(((86.801) + (53.357) + (21.778) + (0.1) + (30.347)) / ((0.1) + (37.232)));
    tcb->m_cWnd = (int)50309.972856;
    segmentsAcked = (int)(2667.81);
} else {
    segmentsAcked = (int)(55.228 - (41.347) - (89.556) - (24.773) - (24.989) - (tcb->m_cWnd) - (33.413));
    cnt = (int)(79.009 - (99.994) - (59.05) - (42.886) - (85.132) - (33.192) - (tcb->m_ssThresh) - (57.025) - (15.053));
    segmentsAcked = (int)101212.49306658;
}
if (m_cWndCnt > cnt) {
    tcb->m_cWnd += tcb->m_segmentSize;
    m_cWndCnt = 0;
}
segmentsAcked = (int)1.166;
