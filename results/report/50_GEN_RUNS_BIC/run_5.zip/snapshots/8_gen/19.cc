ReduceCwnd (tcb);
int fanYLqXvWAnzwDEa = (int) (((0.1)+(0.1)+(59.419)+(0.1)+(0.1))/((0.1)));
ReduceCwnd (tcb);
if (tcb->m_ssThresh != tcb->m_cWnd) {
	cnt = (int) (86.68+(98.576)+(tcb->m_cWnd)+(69.147)+(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (65.661+(24.261)+(74.428)+(4.017)+(1.754));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > fanYLqXvWAnzwDEa) {
	tcb->m_segmentSize = (int) (69.148*(14.711)*(56.361));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (6.291-(93.141)-(48.392)-(35.475)-(segmentsAcked)-(1.939)-(63.454)-(24.388));

}
