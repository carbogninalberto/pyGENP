int kfACynbzsPXTmFre = (int) (-16.581*(-19.684)*(-24.307)*(10.704)*(78.553));
int nnfiNMmrRptHKWlC = (int) (-40.335/(15.497+(42.414)));
tcb->m_segmentSize = (int) (70.716*(55.701)*(12.811)*(64.434));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (85.671-(-98.963)-(68.05)-(28.92)-(-3.899)-(48.742)-(25.174)-(45.696));
segmentsAcked = (int) (75.084*(74.406)*(93.552)*(-92.507)*(-80.107)*(-95.184)*(-36.186));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
nnfiNMmrRptHKWlC = (int) (-64.468-(-53.642)-(-95.497)-(-74.168)-(15.4)-(22.459)-(-77.914)-(-52.778));
