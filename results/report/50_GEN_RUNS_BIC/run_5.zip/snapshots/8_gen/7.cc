if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int jGzTGguLRlhyYbUB = (int) (-66.861-(-29.012)-(-99.532)-(53.158)-(81.065)-(-28.15)-(52.61)-(-50.611));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-28.94-(94.487)-(34.034)-(-46.847)-(-88.212)-(-93.201)-(12.449));
tcb->m_segmentSize = (int) (17.866-(9.349)-(97.631)-(57.266)-(37.966)-(64.251)-(22.276));
