int mmRTjEdqUBjPczuq = (int) ((88.354-(-95.306)-(-34.913)-(-62.087))/40.736);
float zDBQbrbeLXEGxdnQ = (float) (-38.096+(51.461)+(-65.104));
tcb->m_cWnd = (int) (-16.328/(50.216-(-98.576)-(-59.985)-(tcb->m_ssThresh)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (27.25-(-99.27)-(-64.999)-(-27.344)-(-87.774)-(-31.152)-(46.765));
tcb->m_segmentSize = (int) (-57.41-(-55.212)-(-78.404)-(-40.342)-(-95.159)-(-94.53)-(28.975));
