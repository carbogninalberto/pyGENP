if (tcb->m_segmentSize > cnt) {
	segmentsAcked = (int) (72.434+(segmentsAcked)+(72.519));
	segmentsAcked = (int) (55.83-(8.169)-(44.867)-(61.041)-(68.457));
	tcb->m_segmentSize = (int) (35.685+(30.181)+(tcb->m_ssThresh)+(95.29)+(6.694)+(86.331));

} else {
	segmentsAcked = (int) (tcb->m_cWnd-(47.636));

}
tcb->m_segmentSize = (int) (55.737-(89.055)-(34.714)-(39.329)-(95.082));
ReduceCwnd (tcb);
if (cnt >= tcb->m_cWnd) {
	segmentsAcked = (int) (72.303+(0.091)+(tcb->m_cWnd)+(33.154)+(41.186)+(96.237)+(50.922)+(39.496));
	tcb->m_ssThresh = (int) (14.748+(tcb->m_cWnd)+(36.63)+(60.205));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (20.343+(57.02)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(57.927)+(83.818));
	tcb->m_ssThresh = (int) (57.984/0.1);
	tcb->m_ssThresh = (int) (91.567/73.444);

}
tcb->m_ssThresh = (int) (27.696*(83.638)*(65.321)*(12.507)*(tcb->m_cWnd)*(45.61)*(72.725)*(tcb->m_segmentSize)*(66.732));
ReduceCwnd (tcb);
