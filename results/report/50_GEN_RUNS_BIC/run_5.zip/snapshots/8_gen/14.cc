int mmRTjEdqUBjPczuq = (int) ((19.138-(-85.543)-(-62.939)-(21.659))/36.252);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float zDBQbrbeLXEGxdnQ = (float) (-50.695+(65.79)+(-20.396));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float mVaUeoGcxrNhQpmD = (float) (-29.107*(-97.231));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (99.923-(-82.349)-(-86.499)-(16.286)-(74.777)-(-51.113)-(50.593));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-68.424-(72.065)-(-10.832)-(0.727)-(11.304)-(-93.264)-(82.763));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (96.478-(62.742)-(-7.787)-(-13.083)-(38.334)-(-99.696)-(-98.157));
tcb->m_segmentSize = (int) (35.924-(72.54)-(67.178)-(1.397)-(-50.756)-(13.153)-(2.065));
