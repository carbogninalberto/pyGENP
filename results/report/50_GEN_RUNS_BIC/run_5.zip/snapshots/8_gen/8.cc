if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-95.321-(-3.919)-(84.804)-(85.9)-(-66.892)-(-41.672)-(44.262));
