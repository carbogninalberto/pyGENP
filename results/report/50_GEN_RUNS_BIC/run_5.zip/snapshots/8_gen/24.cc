if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (96.52*(48.901)*(71.386)*(65.814)*(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (57.041+(95.762)+(40.755)+(66.15)+(89.613)+(40.876)+(76.484));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float buxaxlcmvJlzrvCv = (float) (39.737-(tcb->m_segmentSize)-(41.641)-(44.813)-(42.998)-(64.577));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
