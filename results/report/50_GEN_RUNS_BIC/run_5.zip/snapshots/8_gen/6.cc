tcb->m_segmentSize = (int) (-39.12-(-71.594)-(-28.375)-(-55.995)-(-51.386)-(-85.383)-(-92.095));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-4.591-(9.355)-(-75.979)-(-29.696)-(-85.461)-(-67.421)-(12.056));
