ReduceCwnd (tcb);
segmentsAcked = (int) ((22.765*(71.995)*(90.182))/0.1);
segmentsAcked = (int) (((0.1)+((47.145-(20.435)-(35.548)-(45.796)-(88.875)-(tcb->m_cWnd)))+(98.297)+((50.225*(36.946)*(0.848)*(80.235)*(45.151)*(tcb->m_segmentSize)*(37.678)*(69.016)*(3.265)))+(0.1))/((0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (0.1/0.1);
