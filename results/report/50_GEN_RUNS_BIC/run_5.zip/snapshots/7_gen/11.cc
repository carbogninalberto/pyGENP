if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float zDBQbrbeLXEGxdnQ = (float) (-55.311+(-11.323)+(-77.21));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int mmRTjEdqUBjPczuq = (int) ((-8.082-(-44.0)-(-29.933)-(-20.443))/-27.178);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (59.357-(5.232)-(36.716)-(-2.188)-(30.363)-(-36.966)-(13.31));
tcb->m_segmentSize = (int) (-2.465-(-64.971)-(95.316)-(-67.858)-(-44.774)-(14.504)-(-63.066));
