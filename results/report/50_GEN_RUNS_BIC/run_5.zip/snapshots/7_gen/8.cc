float kbkIxTGsUtFFHtBu = (float) (86.421/24.911);
float YzHEWkrNQdeCFvaj = (float) (28.248+(83.902)+(-13.662));
