tcb->m_segmentSize = (int) (((89.997)+((45.866*(-76.357)*(-70.696)*(-29.701)))+(64.997)+(-27.212)+(-10.135)+((-36.732-(tcb->m_cWnd)-(cnt)-(-61.731)-(-55.183)-(64.337)-(21.419)-(segmentsAcked)))+(27.65))/((78.514)+(59.223)));
tcb->m_cWnd = (int) (65.011-(30.678)-(-76.352)-(-3.784)-(-97.998)-(-63.572));
tcb->m_segmentSize = (int) (-91.564-(-77.15));
tcb->m_segmentSize = (int) (((61.141)+((47.959*(88.618)*(13.567)*(94.322)))+(9.87)+(46.3)+(-86.332)+((20.29-(tcb->m_cWnd)-(cnt)-(61.725)-(91.753)-(-64.598)-(-11.537)-(segmentsAcked)))+(-92.687))/((-67.398)+(34.013)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (86.563-(41.637)-(19.278)-(-98.681)-(-91.427)-(-84.254));
tcb->m_cWnd = (int) (71.893-(80.665)-(11.75)-(-36.199)-(98.787)-(-69.623));
tcb->m_segmentSize = (int) (28.878-(66.85));
tcb->m_segmentSize = (int) (((-6.249)+((-70.578*(-82.007)*(20.741)*(19.581)))+(54.497)+(-25.636)+(-26.133)+((-12.319-(tcb->m_cWnd)-(cnt)-(-64.917)-(-55.69)-(-80.238)-(18.337)-(segmentsAcked)))+(39.034))/((76.146)+(-92.185)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-83.626-(40.172));
tcb->m_cWnd = (int) (34.824-(8.711)-(5.618)-(8.004)-(-23.024)-(11.339));
tcb->m_segmentSize = (int) (70.088-(-93.891));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (53.461-(45.415));
