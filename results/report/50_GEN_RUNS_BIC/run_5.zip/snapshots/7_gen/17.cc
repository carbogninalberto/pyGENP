tcb->m_segmentSize = (int) (-66.155-(-22.806)-(26.594));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-65.684-(54.522)-(75.844)-(-9.064)-(-54.781)-(-3.731)-(82.019));
tcb->m_segmentSize = (int) (-2.995-(45.741)-(-99.623)-(-61.681)-(-48.163)-(23.201)-(56.531));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-92.701-(-19.504)-(-48.378)-(48.25)-(-55.514)-(72.539)-(36.798));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-18.696-(-55.595)-(85.851)-(95.915)-(-80.749)-(48.096)-(-37.973));
tcb->m_segmentSize = (int) (-40.693-(49.532)-(-71.731)-(50.41)-(7.82)-(-67.04)-(-13.322));
