tcb->m_ssThresh = (int) (cnt+(segmentsAcked)+(45.877));
ReduceCwnd (tcb);
float FqxTXsHYpVpvmmDE = (float) (73.11*(8.945)*(41.365)*(39.262));
cnt = (int) (13.03/0.1);
if (cnt <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (16.277+(21.91)+(41.649)+(segmentsAcked)+(95.22)+(tcb->m_segmentSize)+(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (93.996+(tcb->m_segmentSize)+(91.247)+(71.485)+(80.419));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(tcb->m_ssThresh)-(95.06)-(42.194)-(67.636));

}
