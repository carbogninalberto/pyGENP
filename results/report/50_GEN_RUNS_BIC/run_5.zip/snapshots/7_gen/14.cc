tcb->m_segmentSize = (int) (((-28.876)+((-31.219*(-71.575)*(56.608)*(98.795)))+(85.412)+(-85.709)+(33.922)+((-43.055-(tcb->m_cWnd)-(cnt)-(53.637)-(-64.329)-(26.437)-(-73.801)-(segmentsAcked)))+(-73.109))/((-25.827)+(-76.714)));
tcb->m_cWnd = (int) (-86.756-(-47.197)-(-74.217)-(25.592)-(-80.75)-(45.18));
tcb->m_cWnd = (int) (90.449-(84.8)-(26.039)-(-11.735)-(14.648)-(-11.181));
tcb->m_segmentSize = (int) (((80.776)+((18.468*(48.529)*(-65.435)*(-47.915)))+(66.255)+(-78.787)+(-15.411)+((46.95-(tcb->m_cWnd)-(cnt)-(-0.634)-(81.093)-(-25.619)-(55.136)-(segmentsAcked)))+(79.506))/((-33.481)+(58.982)));
tcb->m_segmentSize = (int) (((60.017)+((-97.147*(-45.589)*(42.429)*(1.02)))+(-66.242)+(9.968)+(76.556)+((-1.657-(tcb->m_cWnd)-(cnt)-(-3.828)-(71.79)-(35.617)-(27.138)-(segmentsAcked)))+(-39.657))/((-82.541)+(62.577)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (39.304-(44.576)-(-67.51)-(-22.246)-(-70.212)-(2.289));
tcb->m_cWnd = (int) (18.653-(88.668)-(97.434)-(-36.722)-(38.567)-(68.836));
tcb->m_segmentSize = (int) (-47.581-(-5.235));
tcb->m_segmentSize = (int) (76.423-(69.723));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (1.834-(31.628));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (41.613-(19.36));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-24.353-(88.445));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-82.446-(76.788));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-10.51-(61.877));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-91.024-(-33.67));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (39.833-(-23.003));
tcb->m_segmentSize = (int) (30.547-(92.316));
tcb->m_segmentSize = (int) (-51.618-(-75.911));
tcb->m_segmentSize = (int) (99.948-(21.684));
tcb->m_segmentSize = (int) (23.411-(3.825));
