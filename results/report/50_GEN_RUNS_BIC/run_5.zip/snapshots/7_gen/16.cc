float PqLMbaobVzZmFTWt = (float) (((-42.093)+(68.088)+(-66.886)+((64.882-(87.857)-(-19.737)))+(-39.455)+(63.307))/((-18.192)+(-28.434)+(-68.02)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-28.879-(1.839)-(-33.436)-(58.259)-(-51.028)-(-81.543)-(-20.478));
