float uUAFgaaPdKvZhytb = (float) (29.379-(cnt)-(54.385)-(66.425)-(87.362));
cnt = (int) (0.1/0.1);
int zgaGoqeKrQPtdgrs = (int) ((2.334*(71.451)*(uUAFgaaPdKvZhytb))/94.476);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (tcb->m_cWnd*(13.356)*(71.459)*(8.732)*(71.497)*(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int tyKpIhftASvUfwnb = (int) (uUAFgaaPdKvZhytb-(tcb->m_ssThresh)-(20.222)-(16.913)-(19.491)-(80.899));
if (cnt < tcb->m_segmentSize) {
	zgaGoqeKrQPtdgrs = (int) (57.365-(46.274)-(segmentsAcked)-(82.379)-(cnt));

} else {
	zgaGoqeKrQPtdgrs = (int) ((17.926-(20.478)-(38.671))/44.654);
	tcb->m_segmentSize = (int) (segmentsAcked+(87.824));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
