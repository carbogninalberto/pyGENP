tcb->m_ssThresh = (int) (27.246-(18.163));
if (segmentsAcked < tcb->m_ssThresh) {
	segmentsAcked = (int) ((63.563-(26.56)-(3.761)-(segmentsAcked)-(0.416)-(77.232)-(tcb->m_ssThresh)-(cnt)-(38.458))/3.774);
	tcb->m_cWnd = (int) (40.186+(10.233)+(19.189)+(tcb->m_segmentSize)+(53.621)+(tcb->m_cWnd)+(47.87));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((23.152)+((73.099-(79.942)-(14.825)-(8.764)))+(79.938)+(67.941))/((0.1)));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (32.421-(16.623)-(53.5));
	tcb->m_cWnd = (int) (82.818*(17.567)*(41.338)*(53.617)*(tcb->m_cWnd));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (60.619/0.1);

}
tcb->m_segmentSize = (int) (81.053+(93.121)+(98.985)+(55.362)+(35.339));
