tcb->m_segmentSize = (int) (89.91-(-15.626)-(74.143)-(-88.422)-(-96.595)-(32.125)-(-92.479));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-86.825-(-2.597)-(92.479)-(-59.937)-(28.911)-(-97.55)-(39.685));
tcb->m_segmentSize = (int) (25.349-(60.602)-(-0.478)-(79.457)-(-13.099)-(-66.007)-(-43.719));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-92.117-(-29.782)-(64.972)-(-10.926)-(75.865)-(-16.722)-(64.103));
