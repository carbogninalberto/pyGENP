tcb->m_segmentSize = (int) (segmentsAcked*(62.594)*(40.505)*(65.314)*(47.784));
float fCcTNJqxKjkikYJX = (float) (87.959+(tcb->m_segmentSize)+(25.459)+(84.272)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(94.325));
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	cnt = (int) (3.422*(3.166)*(fCcTNJqxKjkikYJX)*(43.627)*(fCcTNJqxKjkikYJX)*(fCcTNJqxKjkikYJX)*(15.029)*(79.72)*(88.393));
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(tcb->m_cWnd)+(53.7));

} else {
	cnt = (int) (97.955+(26.559)+(2.633)+(31.648));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (56.982*(92.795)*(62.723)*(73.414));
tcb->m_cWnd = (int) (56.863-(fCcTNJqxKjkikYJX)-(tcb->m_segmentSize)-(52.48)-(66.61)-(23.183)-(49.836));
segmentsAcked = (int) (61.675+(91.114)+(24.819));
cnt = (int) (7.9-(24.894));
