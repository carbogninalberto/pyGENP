cnt = (int) (0.1/0.1);
int nnfiNMmrRptHKWlC = (int) (0.1/(22.517+(20.314)));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (45.239-(1.381)-(14.368)-(tcb->m_segmentSize)-(cnt)-(86.086)-(90.065)-(6.725));
segmentsAcked = (int) (22.097*(tcb->m_cWnd)*(50.489)*(1.669)*(33.885)*(61.221)*(98.672));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int kfACynbzsPXTmFre = (int) (90.901*(tcb->m_ssThresh)*(30.838)*(72.406)*(70.099));
cnt = (int) (nnfiNMmrRptHKWlC+(3.872)+(segmentsAcked)+(21.127)+(nnfiNMmrRptHKWlC));
nnfiNMmrRptHKWlC = (int) (tcb->m_segmentSize-(63.709)-(nnfiNMmrRptHKWlC)-(kfACynbzsPXTmFre)-(nnfiNMmrRptHKWlC)-(59.977)-(41.987)-(35.194));
