if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float nuwJCuXCsGZncnMC = (float) (((0.1)+((89.283-(17.803)-(72.224)-(3.192)-(68.237)-(44.474)-(12.438)-(55.073)))+(15.01)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));
int PYwhbsbTUePSpxMG = (int) (80.244+(98.177)+(16.285)+(75.001)+(3.94)+(tcb->m_cWnd));
tcb->m_ssThresh = (int) (PYwhbsbTUePSpxMG-(44.782)-(93.599)-(PYwhbsbTUePSpxMG)-(31.107)-(12.925)-(59.697));
ReduceCwnd (tcb);
PYwhbsbTUePSpxMG = (int) (cnt*(63.363)*(55.209)*(25.412));
