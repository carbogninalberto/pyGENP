if (segmentsAcked < tcb->m_ssThresh) {
	cnt = (int) (cnt*(84.143)*(77.25)*(6.177));
	cnt = (int) (49.851-(tcb->m_cWnd));

} else {
	cnt = (int) (cnt*(52.636)*(65.243)*(1.214)*(tcb->m_segmentSize)*(59.013)*(1.978)*(1.289)*(19.214));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (tcb->m_segmentSize*(88.256)*(tcb->m_segmentSize)*(9.773)*(88.273)*(segmentsAcked)*(tcb->m_ssThresh)*(52.305)*(18.181));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt != tcb->m_ssThresh) {
	segmentsAcked = (int) (96.119+(62.538)+(27.705)+(cnt)+(cnt)+(87.457)+(59.205));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (81.112+(segmentsAcked)+(57.988)+(83.522)+(53.647)+(85.191)+(38.498)+(19.768));

}
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	segmentsAcked = (int) (88.053-(cnt)-(cnt)-(58.494)-(86.21)-(88.766)-(59.777)-(tcb->m_cWnd)-(15.729));

} else {
	segmentsAcked = (int) (10.016+(69.634)+(13.849)+(8.26)+(95.425)+(9.775)+(tcb->m_ssThresh)+(38.58)+(cnt));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
