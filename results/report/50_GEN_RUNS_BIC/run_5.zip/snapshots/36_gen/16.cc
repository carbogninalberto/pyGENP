tcb->m_ssThresh = (int) (55.347*(segmentsAcked)*(3.798));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int JLVkVFJJXXGsDCyQ = (int) (32.059-(41.719)-(66.999)-(25.557)-(cnt)-(73.055)-(58.97)-(90.005)-(2.156));
segmentsAcked = (int) (20.309*(12.35));
if (cnt <= JLVkVFJJXXGsDCyQ) {
	JLVkVFJJXXGsDCyQ = (int) (JLVkVFJJXXGsDCyQ+(87.583)+(83.571)+(49.62)+(segmentsAcked));
	tcb->m_segmentSize = (int) (87.146+(4.393)+(89.672)+(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (57.53*(36.116)*(84.539)*(34.389)*(59.482)*(50.297)*(77.476)*(54.527));

} else {
	JLVkVFJJXXGsDCyQ = (int) (4.483*(22.922)*(66.298));
	tcb->m_segmentSize = (int) ((19.257-(23.695)-(39.897)-(30.834)-(72.218)-(38.669)-(JLVkVFJJXXGsDCyQ))/95.75);

}
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	JLVkVFJJXXGsDCyQ = (int) (cnt*(26.327)*(62.361)*(69.063)*(23.907)*(19.526)*(39.886)*(JLVkVFJJXXGsDCyQ)*(39.921));

} else {
	JLVkVFJJXXGsDCyQ = (int) (81.563-(JLVkVFJJXXGsDCyQ));
	tcb->m_segmentSize = (int) (36.119/5.382);

}
JLVkVFJJXXGsDCyQ = (int) (((0.1)+((99.227+(39.965)+(81.078)+(65.723)+(38.076)+(segmentsAcked)+(77.085)+(80.99)+(77.862)))+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(67.302)));
