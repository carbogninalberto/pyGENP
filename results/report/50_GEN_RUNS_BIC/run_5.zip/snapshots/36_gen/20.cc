if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((0.1)+(53.957)+((tcb->m_segmentSize*(59.053)*(5.165)*(cnt)*(26.428)*(46.952)))+(21.568)+(74.692))/((20.916)+(52.372)+(99.117)));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (43.432*(90.324)*(cnt));
	segmentsAcked = (int) (21.394*(49.045)*(tcb->m_ssThresh)*(1.226)*(50.337)*(50.184)*(segmentsAcked)*(cnt));
	tcb->m_segmentSize = (int) (((0.1)+(16.1)+(0.1)+((4.768+(70.976)+(tcb->m_segmentSize)))+(10.608)+(28.078))/((75.228)));

}
if (segmentsAcked >= segmentsAcked) {
	tcb->m_ssThresh = (int) (27.643-(tcb->m_ssThresh)-(segmentsAcked)-(73.092)-(14.806)-(26.283)-(58.624));

} else {
	tcb->m_ssThresh = (int) (63.083-(43.929)-(41.531)-(30.235)-(tcb->m_ssThresh)-(55.353)-(segmentsAcked));
	tcb->m_cWnd = (int) (78.099+(53.325));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (90.521*(segmentsAcked)*(29.685)*(83.676));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) ((((14.056+(38.947)+(tcb->m_segmentSize)+(60.968)+(87.883)))+((38.98+(39.002)+(32.331)+(45.536)+(91.692)))+((tcb->m_ssThresh+(61.186)+(40.591)+(61.235)+(tcb->m_segmentSize)))+(11.813)+(61.418)+(0.1))/((64.548)));

} else {
	tcb->m_cWnd = (int) (17.316*(98.259)*(tcb->m_cWnd)*(segmentsAcked)*(80.104)*(97.668)*(91.808)*(12.99));
	tcb->m_cWnd = (int) (77.11*(33.646)*(17.487)*(19.743)*(15.538)*(45.539)*(tcb->m_cWnd)*(41.68));
	tcb->m_ssThresh = (int) (40.926+(82.269)+(45.912)+(8.064)+(55.466)+(81.271)+(75.343)+(13.358)+(46.318));

}
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((86.109)+(0.1)+((67.608*(65.809)*(9.176)*(92.988)))+(69.31))/((24.543)));

} else {
	tcb->m_ssThresh = (int) (0.391-(54.668)-(98.777)-(42.403)-(97.881)-(91.758)-(75.266));
	tcb->m_cWnd = (int) (86.626+(87.645)+(70.293)+(55.502)+(tcb->m_cWnd)+(45.777)+(45.727)+(30.166));

}
tcb->m_segmentSize = (int) (88.007+(53.095)+(42.159));
if (cnt == cnt) {
	cnt = (int) (0.1/0.1);

} else {
	cnt = (int) (61.728*(cnt)*(96.304)*(18.649)*(cnt));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
