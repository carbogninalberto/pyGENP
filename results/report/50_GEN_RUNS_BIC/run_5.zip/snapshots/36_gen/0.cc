float lhnqVfCWdodQVsAu = (float) (-2.708-(-15.711)-(49.717)-(-7.296)-(-44.265));
