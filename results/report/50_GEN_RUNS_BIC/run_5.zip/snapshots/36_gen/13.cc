tcb->m_cWnd = (int) (tcb->m_segmentSize+(84.094)+(tcb->m_segmentSize)+(16.956)+(88.374)+(76.096)+(85.816)+(9.774));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(30.29)+(39.179)+(22.669)+(12.676)+(1.12));

} else {
	tcb->m_segmentSize = (int) ((39.835-(tcb->m_segmentSize)-(cnt)-(48.422)-(29.412)-(84.902))/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_cWnd = (int) (88.367*(82.718)*(34.511)*(68.152)*(tcb->m_segmentSize)*(15.045));
	tcb->m_cWnd = (int) (50.155/88.113);

} else {
	tcb->m_cWnd = (int) (76.488+(46.017)+(93.177));
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (50.778-(61.558)-(73.759));

}
tcb->m_segmentSize = (int) (((0.1)+(37.44)+(0.1)+(0.1)+(0.1)+(0.1)+(41.638))/((5.735)));
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (23.461*(89.349)*(9.57)*(1.255)*(81.767)*(tcb->m_ssThresh)*(69.76)*(85.029));
	tcb->m_cWnd = (int) (((0.1)+(67.208)+(55.929)+(82.703))/((89.71)+(18.977)));

} else {
	tcb->m_cWnd = (int) (46.512+(40.752)+(47.581)+(9.826)+(39.555)+(5.564));
	tcb->m_cWnd = (int) (69.915+(60.046)+(39.949)+(45.627)+(1.746));
	tcb->m_ssThresh = (int) (0.219*(23.324));

}
ReduceCwnd (tcb);
if (segmentsAcked != tcb->m_segmentSize) {
	cnt = (int) (81.209+(46.91)+(25.203)+(1.609));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (62.947/0.1);
	ReduceCwnd (tcb);

}
