ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_segmentSize) {
	cnt = (int) (59.175+(20.044)+(83.025));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (54.328+(tcb->m_ssThresh)+(cnt)+(30.31)+(18.13)+(37.118)+(34.309)+(70.327));

}
segmentsAcked = (int) (tcb->m_segmentSize+(15.844)+(24.191)+(7.777)+(86.03)+(50.865)+(32.221)+(54.522));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((44.617)+((2.571*(77.183)*(83.241)*(55.631)*(93.26)*(15.768)))+(72.842)+(3.349)+(0.1))/((0.1)+(78.757)+(32.333)+(0.1)));
	tcb->m_ssThresh = (int) (54.147/0.1);

} else {
	tcb->m_ssThresh = (int) (37.06+(32.819));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (49.442-(54.11)-(83.141)-(31.085));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
