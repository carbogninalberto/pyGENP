int wuRNGltWRIWKqEQh = (int) (cnt*(73.843)*(tcb->m_cWnd)*(cnt)*(20.887)*(91.353));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
wuRNGltWRIWKqEQh = (int) (89.386+(cnt)+(85.929)+(85.978)+(82.034)+(47.497)+(41.925)+(51.711));
