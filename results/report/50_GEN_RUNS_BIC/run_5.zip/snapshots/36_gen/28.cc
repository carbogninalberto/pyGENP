if (tcb->m_segmentSize < tcb->m_cWnd) {
	cnt = (int) (10.02+(70.953)+(tcb->m_ssThresh)+(99.776));

} else {
	cnt = (int) (49.226+(79.096)+(62.281)+(0.224)+(tcb->m_cWnd)+(cnt));
	tcb->m_cWnd = (int) (60.681-(30.085));

}
tcb->m_segmentSize = (int) (67.345+(17.685)+(66.479)+(73.114)+(2.076)+(68.598)+(tcb->m_cWnd)+(cnt));
tcb->m_ssThresh = (int) (25.092+(40.614));
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/0.1);
	cnt = (int) (82.086+(73.363)+(cnt)+(74.199));

} else {
	tcb->m_segmentSize = (int) (21.972+(tcb->m_segmentSize)+(segmentsAcked));
	segmentsAcked = (int) (0.352+(99.434)+(66.929)+(53.487));
	tcb->m_segmentSize = (int) (63.334+(tcb->m_cWnd)+(51.542)+(tcb->m_cWnd)+(71.962)+(5.205)+(72.317)+(26.573)+(87.829));

}
if (tcb->m_cWnd >= cnt) {
	tcb->m_ssThresh = (int) (((32.882)+(44.957)+(26.882)+(0.1)+(0.1)+(79.566)+(51.472)+(0.1))/((11.355)));
	tcb->m_segmentSize = (int) (90.892+(87.795)+(67.281)+(80.37)+(68.79)+(54.857)+(87.139)+(56.68)+(77.295));

} else {
	tcb->m_ssThresh = (int) (58.508-(47.713)-(87.399)-(tcb->m_ssThresh)-(92.262)-(tcb->m_segmentSize)-(cnt));
	segmentsAcked = (int) (60.671-(46.123)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(86.038));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > cnt) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(20.732)-(82.601)-(63.641)-(30.082)-(68.189));

} else {
	tcb->m_segmentSize = (int) (2.109+(70.744)+(tcb->m_ssThresh)+(tcb->m_ssThresh));

}
if (cnt >= segmentsAcked) {
	cnt = (int) (87.221-(50.648)-(0.363)-(tcb->m_cWnd)-(35.977)-(77.513));

} else {
	cnt = (int) (tcb->m_segmentSize-(37.56)-(87.378)-(72.313)-(87.112)-(83.25));

}
