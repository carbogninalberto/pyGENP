if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (42.181-(40.995)-(22.745));

} else {
	tcb->m_cWnd = (int) (63.982-(38.16)-(3.269)-(95.881)-(tcb->m_segmentSize)-(37.8)-(4.457));

}
if (cnt <= segmentsAcked) {
	cnt = (int) (53.165-(19.728)-(65.572)-(82.574)-(90.376)-(81.84)-(45.396)-(cnt)-(72.9));

} else {
	cnt = (int) (tcb->m_segmentSize*(52.866)*(58.626)*(9.306)*(65.777)*(95.577)*(63.473)*(29.806));

}
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (9.04-(74.173)-(tcb->m_ssThresh)-(40.121)-(98.004)-(cnt)-(47.868)-(53.157));
	segmentsAcked = (int) (0.085*(44.04)*(67.16)*(67.863));
	tcb->m_ssThresh = (int) (33.857+(8.987)+(1.623)+(22.289));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(30.053)*(97.577)*(47.714)*(86.504)*(92.884));
	cnt = (int) (7.503*(47.729)*(29.878)*(21.356)*(99.742)*(38.3));

}
cnt = (int) (1.759+(84.456)+(22.489)+(tcb->m_segmentSize)+(segmentsAcked)+(36.789)+(19.524)+(10.86)+(70.359));
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (88.552+(24.187)+(72.047)+(tcb->m_segmentSize)+(86.578));
	segmentsAcked = (int) (37.393-(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (((0.1)+((60.429+(44.465)+(3.804)+(75.407)+(84.878)+(64.537)))+(0.1)+((60.835+(67.154)+(tcb->m_cWnd)+(48.678)+(cnt)+(93.475)+(76.996)+(30.489)))+(0.1)+(92.626))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (55.019-(94.926)-(17.202)-(tcb->m_segmentSize)-(segmentsAcked)-(44.558)-(38.26)-(26.958)-(98.014));

} else {
	tcb->m_ssThresh = (int) (81.215+(tcb->m_ssThresh));
	cnt = (int) (12.29/(21.721-(75.827)-(60.113)-(3.717)));
	tcb->m_ssThresh = (int) (50.252+(7.549)+(85.38));

}
tcb->m_cWnd = (int) (33.887-(62.023)-(26.319)-(98.843)-(85.51));
tcb->m_ssThresh = (int) (0.1/4.492);
