if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/(99.603+(4.8)+(cnt)+(65.095)+(66.875)+(20.72)+(90.031)));
	tcb->m_segmentSize = (int) (40.153*(6.062)*(20.386)*(44.698)*(69.153)*(86.879)*(28.063)*(tcb->m_cWnd)*(56.376));
	tcb->m_ssThresh = (int) (89.041+(67.39)+(83.89)+(27.212)+(18.677)+(21.822)+(40.057)+(46.712));

} else {
	tcb->m_ssThresh = (int) (98.632-(3.892)-(segmentsAcked)-(cnt)-(26.705));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (75.52-(cnt)-(tcb->m_cWnd)-(93.276)-(cnt));

} else {
	tcb->m_ssThresh = (int) (6.274+(73.196)+(95.94)+(22.06)+(segmentsAcked)+(11.232)+(48.056));

}
if (tcb->m_cWnd < segmentsAcked) {
	cnt = (int) (12.934/40.021);

} else {
	cnt = (int) (76.849/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (81.047+(13.004)+(40.816)+(71.536)+(45.898)+(43.815));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
