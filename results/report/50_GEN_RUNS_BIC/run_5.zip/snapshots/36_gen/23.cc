ReduceCwnd (tcb);
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	segmentsAcked = (int) (16.853+(2.621)+(cnt)+(87.837)+(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (76.231+(15.246)+(35.312)+(tcb->m_ssThresh)+(75.364)+(segmentsAcked));
	tcb->m_cWnd = (int) (29.33-(80.967));

}
ReduceCwnd (tcb);
if (cnt == cnt) {
	segmentsAcked = (int) ((tcb->m_ssThresh-(75.288)-(23.759)-(29.361)-(16.986))/35.137);

} else {
	segmentsAcked = (int) (86.546-(24.97)-(segmentsAcked)-(tcb->m_segmentSize)-(tcb->m_cWnd));

}
segmentsAcked = (int) (82.728*(50.005)*(33.008)*(53.38)*(29.584));
