if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_ssThresh = (int) (segmentsAcked-(1.331)-(tcb->m_ssThresh)-(65.735)-(17.062)-(37.116)-(30.695));
	segmentsAcked = (int) (25.744+(99.839)+(57.452)+(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (29.656/14.297);
	segmentsAcked = (int) (83.876*(83.311)*(47.916)*(tcb->m_ssThresh));

}
float vTwcncfeaoEYvTOY = (float) ((58.698*(97.847)*(32.296))/94.79);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt <= vTwcncfeaoEYvTOY) {
	tcb->m_ssThresh = (int) (14.936+(cnt)+(91.768)+(59.022));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(56.304));

} else {
	tcb->m_ssThresh = (int) (82.438*(22.038)*(10.61)*(58.623)*(tcb->m_segmentSize)*(55.494)*(21.977)*(76.874));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
