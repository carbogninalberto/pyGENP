tcb->m_ssThresh = (int) (segmentsAcked-(56.289)-(57.776)-(0.841)-(64.344)-(tcb->m_segmentSize)-(13.642)-(88.042));
tcb->m_segmentSize = (int) (77.66-(segmentsAcked)-(21.891)-(9.875)-(86.15));
int fhQkhGZVIUqSHJFc = (int) (94.472-(0.223)-(tcb->m_cWnd)-(38.271)-(19.722)-(66.897));
if (tcb->m_ssThresh == fhQkhGZVIUqSHJFc) {
	tcb->m_cWnd = (int) (45.429*(43.328)*(79.273)*(fhQkhGZVIUqSHJFc)*(50.008)*(92.917)*(97.399)*(82.639)*(68.43));

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)));
	tcb->m_ssThresh = (int) (32.159*(33.926)*(8.598)*(47.025)*(55.497));

}
if (tcb->m_ssThresh != tcb->m_cWnd) {
	fhQkhGZVIUqSHJFc = (int) (90.037+(5.932)+(56.066)+(49.897)+(97.151)+(67.183)+(49.797));

} else {
	fhQkhGZVIUqSHJFc = (int) (9.963/43.522);
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (65.544*(28.366)*(84.758)*(tcb->m_cWnd)*(79.004)*(56.875)*(38.936));
fhQkhGZVIUqSHJFc = (int) (76.5+(99.705)+(tcb->m_segmentSize)+(74.675));
tcb->m_cWnd = (int) (39.418-(39.25)-(45.862)-(fhQkhGZVIUqSHJFc));
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	segmentsAcked = (int) (fhQkhGZVIUqSHJFc-(10.404)-(0.934)-(48.237)-(segmentsAcked));
	tcb->m_ssThresh = (int) (96.59*(71.128));

} else {
	segmentsAcked = (int) (55.302*(3.467));

}
