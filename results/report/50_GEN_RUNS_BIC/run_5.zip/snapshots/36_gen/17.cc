ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_segmentSize+(69.319));
tcb->m_ssThresh = (int) (((0.1)+(18.384)+(52.914)+(57.61))/((91.48)+(44.202)+(80.705)+(0.1)));
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (39.936+(45.189)+(segmentsAcked)+(19.376)+(93.097)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(81.73));
	cnt = (int) (((0.1)+(6.939)+(0.1)+(0.1))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (0.1/30.618);
	tcb->m_cWnd = (int) (45.075-(cnt)-(27.161)-(27.79));
	segmentsAcked = (int) (54.905*(46.819)*(tcb->m_ssThresh));

}
