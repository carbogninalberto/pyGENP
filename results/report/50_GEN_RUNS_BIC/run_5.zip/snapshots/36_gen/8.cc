if (cnt != tcb->m_segmentSize) {
	segmentsAcked = (int) (30.785*(26.411)*(tcb->m_cWnd)*(25.013));
	cnt = (int) (39.614+(26.807)+(25.804)+(36.812)+(tcb->m_ssThresh)+(71.709)+(70.957)+(39.626)+(1.01));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (78.175*(1.514)*(61.747)*(59.931)*(47.745));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (0.771-(tcb->m_cWnd)-(68.551)-(50.373)-(64.225)-(27.475)-(29.784));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (32.554-(40.073)-(22.661)-(98.813)-(tcb->m_ssThresh)-(72.862)-(tcb->m_ssThresh)-(79.993)-(39.9));
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	cnt = (int) (29.223-(72.639)-(94.133)-(cnt)-(94.892)-(90.828));
	ReduceCwnd (tcb);

} else {
	cnt = (int) ((1.115-(22.353)-(cnt)-(53.288)-(72.658)-(44.566))/64.006);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (cnt+(97.956)+(11.607)+(60.537)+(20.09)+(53.873)+(71.081));

}
