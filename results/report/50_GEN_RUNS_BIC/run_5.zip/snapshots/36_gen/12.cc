if (tcb->m_ssThresh != tcb->m_cWnd) {
	cnt = (int) (14.7+(9.758)+(64.043)+(27.982)+(84.046));
	tcb->m_segmentSize = (int) (((93.358)+(0.1)+(0.1)+(78.099)+(3.999))/((0.1)));

} else {
	cnt = (int) (86.094+(10.137));
	tcb->m_segmentSize = (int) (27.253-(20.901)-(52.268)-(91.405)-(40.866)-(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (82.182-(45.51)-(17.08)-(segmentsAcked)-(93.039)-(29.736)-(cnt)-(40.65));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((0.1)+((98.205+(segmentsAcked)+(67.656)+(96.692)+(tcb->m_cWnd)+(80.034)+(59.886)))+(0.1)+(93.007)+(0.1))/((0.1)+(0.1)+(0.1)));

} else {
	tcb->m_cWnd = (int) (57.21+(60.52)+(44.792)+(76.134)+(32.985)+(59.59)+(segmentsAcked)+(24.341));

}
int TVEikVIslExaPYUz = (int) (23.123*(tcb->m_segmentSize)*(10.333)*(cnt)*(73.975));
segmentsAcked = (int) (66.635-(50.849));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
TVEikVIslExaPYUz = (int) (TVEikVIslExaPYUz-(87.706));
