ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (((0.1)+((3.768+(54.174)+(66.461)))+(0.1)+((98.741*(75.455)*(5.191)*(51.123)*(0.294)*(83.919)*(79.487)))+(15.357)+((25.273*(57.141)*(18.651)*(7.388)*(tcb->m_segmentSize)*(68.659)))+(21.334))/((16.897)));
if (cnt <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (66.779-(84.313)-(8.88)-(59.58)-(13.267));
	tcb->m_cWnd = (int) (55.323-(tcb->m_segmentSize)-(98.117)-(segmentsAcked)-(13.619)-(segmentsAcked));
	cnt = (int) (49.026+(73.947)+(56.557)+(tcb->m_ssThresh)+(3.99)+(96.613)+(segmentsAcked)+(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (0.1/43.228);
	tcb->m_ssThresh = (int) (75.629+(52.953)+(3.805));

}
tcb->m_cWnd = (int) (87.138-(tcb->m_cWnd)-(49.262));
