segmentsAcked = (int) (28.34+(46.944)+(52.904)+(6.493)+(-10.711)+(29.667)+(36.025)+(-27.241));
tcb->m_segmentSize = (int) (-67.687-(-80.294)-(-31.197)-(68.241));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (22.48-(-92.95)-(-98.188)-(-61.043));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
