float yjQihEqFHHzqyfUy = (float) (-0.404*(-21.245)*(13.936)*(26.945)*(67.853)*(-38.169)*(19.421)*(-98.724));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-8.323*(-77.975)*(-61.571)*(-3.185));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (82.202+(-84.928)+(6.965));
tcb->m_segmentSize = (int) (-26.923+(-81.089)+(20.812));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
