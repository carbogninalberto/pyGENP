float JjknBaQPOFuoqmnx = (float) (7.404+(-68.052)+(-92.042));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (2.463*(-68.098)*(0.424));
tcb->m_cWnd = (int) (-21.235*(-48.808)*(24.563));
