segmentsAcked = (int) (84.632*(15.102)*(17.744)*(-78.183)*(-41.52)*(-79.532)*(50.101));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
