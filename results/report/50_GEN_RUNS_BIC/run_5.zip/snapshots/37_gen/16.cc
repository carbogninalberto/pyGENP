float DPrzRkIHQtYlEtpX = (float) 52.525;
tcb->m_segmentSize = (int) (-31.875+(1.155)+(-14.714)+(-23.265)+(-48.155)+(93.106));
