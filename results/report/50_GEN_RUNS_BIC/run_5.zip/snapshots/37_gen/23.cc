float DPrzRkIHQtYlEtpX = (float) (86.392-(7.84));
tcb->m_segmentSize = (int) (64.039+(-85.534)+(73.341)+(43.75)+(5.996)+(33.539));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
