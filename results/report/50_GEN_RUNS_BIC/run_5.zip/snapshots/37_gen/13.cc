if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float vTwcncfeaoEYvTOY = (float) ((91.278*(77.092)*(15.872))/-13.405);
ReduceCwnd (tcb);
float usRheiLNxFxGaPjb = (float) (54.513-(5.45)-(80.42)-(8.24));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
