float PQlWgppgeVjGsSxG = (float) (75.74/-99.496);
float wzFGJrTpHHhAgCKk = (float) (12.625*(19.446)*(8.225)*(-15.849)*(-60.609)*(-9.581));
if (tcb->m_segmentSize >= wzFGJrTpHHhAgCKk) {
	wzFGJrTpHHhAgCKk = (float) (47.779-(71.339)-(46.075));
	segmentsAcked = (int) (5.64+(segmentsAcked)+(59.471)+(36.412)+(32.694));

} else {
	wzFGJrTpHHhAgCKk = (float) (28.309+(8.704)+(54.468)+(23.013)+(22.415)+(94.903)+(44.088)+(13.891)+(45.946));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	wzFGJrTpHHhAgCKk = (float) (34.861/47.676);

}
tcb->m_cWnd = (int) (-60.498-(28.141)-(83.282)-(17.993)-(3.791)-(-42.266)-(-82.839)-(95.104));
