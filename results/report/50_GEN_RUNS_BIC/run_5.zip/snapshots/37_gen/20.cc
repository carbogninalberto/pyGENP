if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (42.181-(40.995)-(22.745));

} else {
	tcb->m_cWnd = (int) (63.982-(38.16)-(3.269)-(95.881)-(tcb->m_segmentSize)-(37.8)-(4.457));

}
tcb->m_cWnd = (int) (-67.005-(43.906)-(-66.653)-(-15.943)-(-37.458));
