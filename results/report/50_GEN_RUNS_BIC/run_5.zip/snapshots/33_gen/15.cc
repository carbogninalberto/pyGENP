if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (50.29-(69.577)-(87.337)-(23.706)-(1.287)-(94.697)-(85.818)-(36.908));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	segmentsAcked = (int) (41.924-(10.847)-(41.179)-(10.267)-(58.04)-(23.517)-(62.069));
	tcb->m_ssThresh = (int) (15.427-(21.035)-(28.927)-(cnt)-(70.206)-(30.229)-(67.591)-(8.967)-(tcb->m_segmentSize));

}
if (cnt < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (16.256*(95.264)*(3.484)*(37.131)*(segmentsAcked)*(81.073));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(cnt)+(72.384)+(tcb->m_segmentSize)+(segmentsAcked)+(tcb->m_ssThresh)+(95.695)+(66.65));

} else {
	tcb->m_ssThresh = (int) (cnt*(40.147)*(67.224)*(73.434)*(tcb->m_cWnd)*(2.487));
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(cnt)*(segmentsAcked)*(83.437)*(tcb->m_cWnd)*(15.708)*(3.193));
	cnt = (int) (86.948-(cnt)-(tcb->m_ssThresh)-(12.207)-(90.808)-(24.882)-(segmentsAcked));

}
if (cnt >= cnt) {
	tcb->m_ssThresh = (int) (segmentsAcked+(57.018)+(98.038)+(7.671)+(segmentsAcked)+(11.39));

} else {
	tcb->m_ssThresh = (int) (((52.46)+(69.946)+(86.621)+(0.1))/((0.1)));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (66.878/0.1);
	tcb->m_cWnd = (int) (cnt+(segmentsAcked)+(6.756)+(cnt)+(92.397)+(cnt));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(60.303)-(tcb->m_segmentSize)-(51.223));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(71.71)+(tcb->m_ssThresh)+(97.249)+(75.694)+(34.748)+(46.103)+(44.126)+(segmentsAcked));
	tcb->m_cWnd = (int) (44.626*(62.073)*(94.845)*(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (94.775-(segmentsAcked)-(63.286)-(69.536)-(84.735)-(cnt)-(33.818)-(22.314)-(tcb->m_ssThresh));

}
