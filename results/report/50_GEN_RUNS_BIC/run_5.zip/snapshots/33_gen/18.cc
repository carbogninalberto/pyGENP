cnt = (int) (24.629+(segmentsAcked)+(55.013)+(57.267)+(20.807)+(68.529)+(segmentsAcked));
segmentsAcked = (int) (58.809-(tcb->m_segmentSize)-(49.677)-(75.955)-(segmentsAcked)-(88.782)-(tcb->m_cWnd)-(41.14));
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_cWnd) {
	segmentsAcked = (int) (((36.335)+((11.413+(20.211)))+((7.602-(2.937)))+(14.063)+(0.1))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (54.169*(4.523)*(65.259)*(26.354)*(81.144)*(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (52.385*(tcb->m_cWnd)*(tcb->m_cWnd)*(62.47)*(10.09)*(16.384)*(71.864)*(95.84));
	tcb->m_cWnd = (int) (30.631/29.475);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (48.413*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(12.835)*(40.641)*(83.35)*(83.057)*(82.142));
tcb->m_cWnd = (int) (56.548-(52.869)-(76.647)-(40.117)-(cnt)-(5.583)-(tcb->m_cWnd)-(82.259));
if (cnt != tcb->m_ssThresh) {
	segmentsAcked = (int) ((47.627-(48.248)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(18.084))/0.1);
	cnt = (int) ((92.876*(84.547)*(64.498)*(20.969)*(tcb->m_ssThresh)*(8.13)*(54.932))/0.1);

} else {
	segmentsAcked = (int) (66.301-(6.213)-(cnt)-(76.035)-(96.34)-(tcb->m_ssThresh)-(56.728));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
