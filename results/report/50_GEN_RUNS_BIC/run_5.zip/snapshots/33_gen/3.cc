if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	segmentsAcked = (int) (38.429*(34.315));

} else {
	segmentsAcked = (int) (14.788-(68.8)-(tcb->m_segmentSize)-(60.251)-(89.845)-(44.352)-(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (45.7-(1.337));

}
tcb->m_segmentSize = (int) (84.211+(80.622)+(18.932));
tcb->m_cWnd = (int) (78.099+(45.044)+(29.105)+(49.339));
tcb->m_segmentSize = (int) (cnt*(59.396)*(83.51));
int MyUCzAZaaqZHKcut = (int) (17.693-(6.395)-(17.495)-(97.545));
