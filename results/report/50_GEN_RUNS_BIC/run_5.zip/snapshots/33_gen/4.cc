segmentsAcked = (int) (64.024-(cnt)-(cnt)-(83.778));
int mqYFFyRBgXQxwrhj = (int) (46.11*(15.926)*(1.677)*(81.128)*(85.672)*(34.35)*(33.387)*(96.739)*(tcb->m_ssThresh));
tcb->m_cWnd = (int) (74.561/0.1);
cnt = (int) ((((12.936+(86.631)+(segmentsAcked)+(33.451)+(6.187)+(97.427)+(34.825)))+(0.1)+(18.702)+(55.131)+(93.424)+(22.852)+(0.1))/((0.1)));
ReduceCwnd (tcb);
if (tcb->m_segmentSize > segmentsAcked) {
	cnt = (int) (0.1/0.1);
	segmentsAcked = (int) ((((23.358+(64.988)+(59.158)+(18.987)+(26.532)+(tcb->m_cWnd)+(18.959)))+(33.813)+(62.763)+((92.42+(80.104)+(90.693)+(45.578)+(59.898)+(84.464)))+(0.1)+(0.1)+(0.1))/((67.881)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (80.288-(71.037)-(35.249)-(37.546)-(42.987)-(89.744)-(52.999)-(12.943)-(78.726));
	tcb->m_cWnd = (int) (30.212-(16.991));

}
if (mqYFFyRBgXQxwrhj != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.753+(tcb->m_ssThresh)+(48.86)+(tcb->m_segmentSize)+(25.43)+(77.148)+(90.93)+(24.436)+(17.689));
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (((83.683)+(7.28)+((31.07+(12.9)+(28.359)+(21.973)+(9.711)+(48.603)+(38.013)))+(53.083)+(32.633)+(0.1))/((0.1)+(0.1)));
	tcb->m_segmentSize = (int) (mqYFFyRBgXQxwrhj-(43.439)-(45.602)-(5.742)-(29.383)-(tcb->m_ssThresh)-(63.834)-(48.088));
	segmentsAcked = (int) (94.469+(2.336)+(tcb->m_ssThresh)+(45.879)+(mqYFFyRBgXQxwrhj)+(55.125)+(54.476));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (93.628/0.1);
