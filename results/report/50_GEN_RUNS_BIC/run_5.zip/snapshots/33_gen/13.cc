segmentsAcked = (int) (((80.99)+(34.18)+(0.1)+(0.1))/((0.1)));
tcb->m_ssThresh = (int) (11.853-(20.538));
if (tcb->m_cWnd != cnt) {
	tcb->m_ssThresh = (int) (7.734*(3.164)*(43.253)*(88.205)*(43.747)*(40.989)*(91.803));
	cnt = (int) (9.671*(63.113)*(68.08)*(cnt)*(50.376));

} else {
	tcb->m_ssThresh = (int) (4.043*(83.894)*(61.195)*(28.384)*(11.782));
	tcb->m_ssThresh = (int) (((0.1)+((92.519+(28.628)))+(24.799)+((70.063-(94.008)-(76.511)-(57.877)))+(0.1)+(0.1))/((70.79)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (46.62+(segmentsAcked)+(45.747)+(13.777)+(57.169)+(80.084)+(tcb->m_segmentSize));
ReduceCwnd (tcb);
