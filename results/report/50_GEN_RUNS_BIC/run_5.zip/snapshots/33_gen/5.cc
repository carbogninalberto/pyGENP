float yRJvFUSqRktzQBJK = (float) (87.535-(46.65)-(99.37)-(46.463)-(tcb->m_ssThresh)-(8.9)-(72.789)-(27.147)-(44.276));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float jzXOXTqAzlQkJPzW = (float) (65.529-(3.402)-(11.71)-(66.166)-(64.788)-(99.544)-(tcb->m_segmentSize));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	segmentsAcked = (int) (52.799-(82.187)-(5.109)-(14.872)-(83.005));
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+((25.154-(84.536)-(tcb->m_segmentSize)))+(30.821)+(89.719)+(0.1)+(0.1)+(0.1))/((12.494)));

} else {
	segmentsAcked = (int) (89.035*(72.543)*(77.392));
	jzXOXTqAzlQkJPzW = (float) (15.476-(94.994)-(29.147)-(59.643)-(68.835)-(79.597)-(53.948)-(55.515));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (tcb->m_cWnd-(44.039)-(98.629)-(36.504)-(cnt)-(93.486)-(13.151));
if (tcb->m_ssThresh > jzXOXTqAzlQkJPzW) {
	segmentsAcked = (int) (83.735+(3.807)+(jzXOXTqAzlQkJPzW));
	cnt = (int) (tcb->m_segmentSize*(69.035));

} else {
	segmentsAcked = (int) (((62.208)+(30.022)+(80.102)+(0.1)+(28.56))/((0.1)+(72.124)+(87.733)+(0.1)));
	tcb->m_cWnd = (int) (((0.1)+((49.786-(tcb->m_segmentSize)-(tcb->m_cWnd)-(92.667)-(11.011)-(99.679)-(segmentsAcked)))+(94.427)+(0.1))/((0.1)));

}
float cWusUMdzSfHBCowG = (float) (76.23*(63.532)*(yRJvFUSqRktzQBJK)*(76.201)*(75.584)*(60.15)*(26.653)*(tcb->m_cWnd)*(14.321));
yRJvFUSqRktzQBJK = (float) ((1.302-(81.865)-(26.35))/79.465);
