ReduceCwnd (tcb);
if (tcb->m_ssThresh != cnt) {
	tcb->m_cWnd = (int) (0.1/(29.147-(56.477)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(7.631)));

} else {
	tcb->m_cWnd = (int) (0.1/50.091);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
float aKHFwWOIVrRzQPbc = (float) (89.637/0.1);
int hsyWHVEXvGTWfjsQ = (int) ((((95.162-(57.334)-(tcb->m_ssThresh)))+(0.1)+((45.077*(tcb->m_segmentSize)*(segmentsAcked)*(66.601)*(29.894)))+(4.93)+(0.1)+((96.94*(0.395)*(cnt)*(95.426)*(25.061)))+(0.1)+(28.153))/((0.1)));
if (hsyWHVEXvGTWfjsQ >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (11.508-(51.564)-(77.221));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (6.392-(89.174)-(92.735)-(hsyWHVEXvGTWfjsQ)-(98.037)-(75.698)-(5.151)-(cnt));

}
