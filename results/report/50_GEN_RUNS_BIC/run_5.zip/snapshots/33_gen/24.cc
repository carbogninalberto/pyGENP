if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(28.261)-(tcb->m_ssThresh)-(tcb->m_cWnd));
	segmentsAcked = (int) (75.238+(95.263)+(36.398)+(tcb->m_segmentSize)+(30.83));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (23.315/39.37);
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_ssThresh = (int) (35.721*(90.803)*(3.215)*(34.775)*(tcb->m_ssThresh)*(75.229));
tcb->m_segmentSize = (int) (cnt-(15.07)-(42.966)-(92.81)-(73.288)-(2.624));
ReduceCwnd (tcb);
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (79.024*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(85.865)*(84.804));
	tcb->m_segmentSize = (int) ((((5.729-(33.25)-(85.319)-(16.284)))+(0.1)+(0.1)+(0.1)+(0.1)+(87.42))/((32.381)+(3.705)));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(30.929)+(77.592));
	cnt = (int) (tcb->m_cWnd-(38.564)-(72.738)-(1.45)-(8.86)-(23.755)-(32.232)-(segmentsAcked)-(21.015));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (64.433-(39.751)-(46.578)-(30.169)-(48.775));
	tcb->m_cWnd = (int) (40.836*(12.273)*(83.203)*(81.699)*(92.79));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (((61.573)+(83.225)+(39.386)+(41.506)+(0.1))/((0.1)+(63.064)+(75.472)));

}
