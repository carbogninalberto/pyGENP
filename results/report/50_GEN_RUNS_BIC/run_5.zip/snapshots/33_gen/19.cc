if (segmentsAcked != cnt) {
	tcb->m_cWnd = (int) (26.532+(18.753)+(15.083)+(32.521)+(46.284)+(tcb->m_cWnd)+(96.325));

} else {
	tcb->m_cWnd = (int) (98.292-(59.811)-(4.802)-(48.043)-(3.868)-(39.28)-(13.435)-(40.165)-(46.517));
	segmentsAcked = (int) (27.879+(23.001)+(78.349)+(72.782)+(49.378)+(68.048)+(cnt));

}
tcb->m_ssThresh = (int) (44.071*(30.579)*(26.499)*(17.716)*(11.344)*(29.298)*(64.393));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked != cnt) {
	tcb->m_ssThresh = (int) (46.841+(97.149)+(96.899)+(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (14.389*(67.292)*(39.778)*(61.206)*(tcb->m_ssThresh)*(77.22)*(33.007)*(tcb->m_segmentSize)*(tcb->m_ssThresh));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
