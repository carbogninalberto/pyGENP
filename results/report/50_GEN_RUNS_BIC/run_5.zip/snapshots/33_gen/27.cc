int wBcCAdNDxiYClPiT = (int) (tcb->m_cWnd+(6.872)+(46.393)+(82.316)+(segmentsAcked)+(42.033));
if (tcb->m_ssThresh == cnt) {
	tcb->m_segmentSize = (int) ((((82.851+(64.697)+(35.363)))+(74.002)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(30.428)));

} else {
	tcb->m_segmentSize = (int) (78.083/0.1);

}
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (21.299-(tcb->m_cWnd)-(segmentsAcked)-(tcb->m_segmentSize)-(66.227));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (86.205-(18.267)-(34.354)-(68.838)-(78.204));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float asGLRuoowEJKmrxJ = (float) (80.011-(37.058)-(47.993)-(56.107)-(78.323)-(57.289));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	segmentsAcked = (int) (segmentsAcked+(76.799)+(37.883)+(60.419)+(84.413)+(29.589)+(87.299)+(60.705));

} else {
	segmentsAcked = (int) ((74.806+(35.255)+(81.131)+(44.94))/0.1);

}
if (tcb->m_cWnd >= cnt) {
	segmentsAcked = (int) (wBcCAdNDxiYClPiT*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (((35.836)+((96.165-(44.356)-(32.495)-(51.115)))+(0.1)+(0.1)+((asGLRuoowEJKmrxJ-(55.535)))+(6.798))/((99.028)+(0.1)));

} else {
	segmentsAcked = (int) (0.1/26.574);

}
