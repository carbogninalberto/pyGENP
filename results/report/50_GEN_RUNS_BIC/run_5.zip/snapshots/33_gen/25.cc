if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float OHWKCpMYaFDFGWGu = (float) (90.174/85.376);
if (tcb->m_segmentSize == OHWKCpMYaFDFGWGu) {
	tcb->m_segmentSize = (int) (80.122+(58.12));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (0.1/41.059);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (17.538*(77.788)*(tcb->m_segmentSize)*(33.287)*(17.934));
