tcb->m_ssThresh = (int) ((tcb->m_segmentSize*(cnt))/90.78);
if (cnt < tcb->m_ssThresh) {
	cnt = (int) (26.387-(segmentsAcked)-(85.253)-(85.933)-(77.7)-(cnt)-(tcb->m_cWnd)-(35.994)-(57.884));
	tcb->m_cWnd = (int) (78.275/28.938);
	cnt = (int) (74.564+(58.387)+(tcb->m_ssThresh)+(41.135));

} else {
	cnt = (int) (53.563-(10.298));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (1.556-(80.525));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((0.1)+((46.85-(61.924)-(36.729)-(83.688)-(49.451)-(78.993)-(tcb->m_cWnd)-(90.531)-(78.533)))+(96.2)+(6.985))/((25.546)+(33.869)+(0.1)));
if (cnt <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(11.5)*(16.111)*(79.425)*(tcb->m_ssThresh)*(63.223)*(8.42));
	cnt = (int) (95.061*(58.573)*(49.823)*(91.663)*(91.997)*(18.673)*(67.637)*(46.429));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(64.895)*(17.034)*(cnt)*(13.097)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(61.951));
	cnt = (int) (33.282*(8.809)*(99.023));
	segmentsAcked = (int) (42.166+(92.963)+(10.948)+(65.262)+(tcb->m_segmentSize)+(44.289)+(81.215)+(41.936));

}
tcb->m_cWnd = (int) (40.317-(52.276)-(43.894)-(99.664)-(18.626)-(tcb->m_segmentSize));
segmentsAcked = (int) (15.196-(tcb->m_segmentSize)-(64.078)-(42.616)-(tcb->m_cWnd)-(80.521)-(3.982)-(81.581)-(7.536));
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (12.829-(tcb->m_ssThresh)-(45.164)-(33.997)-(92.344)-(49.138)-(tcb->m_cWnd)-(67.274));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (74.078+(11.508)+(94.754)+(2.355)+(41.858)+(11.993)+(43.595)+(54.54)+(51.387));
	tcb->m_segmentSize = (int) (7.179*(5.986)*(59.912)*(63.364)*(41.936)*(24.731)*(1.361)*(35.52)*(17.612));
	cnt = (int) (66.198*(74.196)*(35.494)*(32.588));

}
