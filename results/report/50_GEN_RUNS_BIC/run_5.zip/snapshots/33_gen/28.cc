cnt = (int) (35.174*(6.869)*(tcb->m_cWnd)*(54.01)*(92.702)*(80.986)*(70.215)*(13.218)*(tcb->m_ssThresh));
ReduceCwnd (tcb);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (17.698*(44.266)*(85.811)*(22.002));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (20.444*(56.312)*(44.382)*(38.546)*(73.653)*(cnt)*(81.294)*(segmentsAcked)*(segmentsAcked));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd <= cnt) {
	tcb->m_segmentSize = (int) (12.477+(tcb->m_ssThresh)+(41.063));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (62.954*(41.523)*(81.132)*(tcb->m_ssThresh)*(96.387));
	segmentsAcked = (int) (19.113-(tcb->m_cWnd)-(71.48)-(segmentsAcked)-(27.808)-(5.432)-(11.993)-(6.889));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
