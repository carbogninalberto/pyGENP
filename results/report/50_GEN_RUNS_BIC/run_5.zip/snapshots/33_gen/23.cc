if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (78.263*(40.065)*(70.843)*(22.756)*(tcb->m_segmentSize)*(63.471)*(63.467));
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) ((cnt-(68.202)-(cnt)-(49.701)-(56.632)-(44.331)-(36.076)-(80.132))/29.266);

}
tcb->m_segmentSize = (int) (53.058+(63.0)+(29.281)+(98.378)+(67.966)+(50.799)+(segmentsAcked)+(tcb->m_cWnd)+(80.781));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize < cnt) {
	tcb->m_cWnd = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (85.025+(tcb->m_cWnd)+(79.317)+(17.235)+(76.999)+(82.403));

}
tcb->m_ssThresh = (int) (5.175+(tcb->m_ssThresh)+(34.368));
tcb->m_cWnd = (int) (22.39*(93.839)*(15.074));
ReduceCwnd (tcb);
