int KzYGrLzGYDMzxoSR = (int) (25.051-(74.699));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (13.674+(80.254));
if (cnt != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(43.4)-(26.481)-(69.085));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (15.786+(cnt)+(80.92));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (82.471+(9.207)+(50.909)+(28.938)+(14.814)+(20.232)+(9.192)+(segmentsAcked));
if (tcb->m_segmentSize < KzYGrLzGYDMzxoSR) {
	tcb->m_ssThresh = (int) (24.422+(KzYGrLzGYDMzxoSR)+(cnt)+(69.401)+(12.774)+(39.395)+(47.736));
	cnt = (int) (81.76*(8.513)*(35.999)*(22.494)*(9.091)*(13.933));
	tcb->m_segmentSize = (int) (98.11+(84.692)+(50.449)+(7.834)+(31.666)+(KzYGrLzGYDMzxoSR)+(58.697)+(57.922));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	ReduceCwnd (tcb);

}
if (segmentsAcked >= segmentsAcked) {
	tcb->m_cWnd = (int) (KzYGrLzGYDMzxoSR-(30.067)-(13.259)-(73.531)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (88.662-(24.333)-(87.241));
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(76.041)+(53.577)+(53.966)+(70.691)+(58.937)+(95.195)+(0.391));
	tcb->m_segmentSize = (int) (7.441-(9.926)-(79.278)-(34.027)-(40.043)-(65.132)-(6.133)-(6.709));

}
