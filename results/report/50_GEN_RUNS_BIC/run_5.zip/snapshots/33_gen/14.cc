tcb->m_ssThresh = (int) ((((9.127+(89.006)))+(0.1)+(0.1)+((65.105-(19.497)-(tcb->m_segmentSize)-(44.963)-(15.153)-(76.991)-(segmentsAcked)))+(97.29)+(45.188))/((53.541)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= tcb->m_cWnd) {
	segmentsAcked = (int) (74.973*(12.897)*(73.087)*(39.344)*(tcb->m_ssThresh)*(70.177)*(22.409)*(8.588));
	cnt = (int) (92.373-(tcb->m_segmentSize)-(70.218)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (96.246*(40.905)*(75.774)*(81.557)*(59.65)*(tcb->m_ssThresh)*(55.97)*(18.312)*(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (63.041*(43.275));

}
segmentsAcked = (int) (0.1/0.1);
tcb->m_cWnd = (int) (((69.624)+(0.1)+(0.1)+(0.1)+(0.1)+(28.894))/((0.1)+(38.396)+(62.076)));
