int lCYIZGTmfyeftBtG = (int) (-83.547+(-67.04)+(-37.112)+(-88.828)+(88.998)+(-88.995)+(-32.019)+(47.449));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
