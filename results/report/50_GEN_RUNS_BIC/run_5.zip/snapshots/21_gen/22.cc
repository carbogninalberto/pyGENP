if (tcb->m_ssThresh != tcb->m_ssThresh) {
	cnt = (int) (87.268-(83.953)-(51.934)-(53.87)-(77.756)-(98.164)-(84.81));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (69.692-(76.402));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > tcb->m_segmentSize) {
	segmentsAcked = (int) ((14.01-(tcb->m_cWnd))/0.1);
	tcb->m_segmentSize = (int) (33.416+(89.316)+(34.173)+(98.414)+(0.316)+(4.893)+(20.259)+(23.207));

} else {
	segmentsAcked = (int) (50.999+(segmentsAcked)+(74.239)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(43.789)+(89.006)+(57.142)+(0.236));

}
tcb->m_cWnd = (int) (72.059*(78.448)*(tcb->m_cWnd)*(tcb->m_cWnd)*(16.772)*(5.496)*(51.118)*(78.137)*(90.717));
ReduceCwnd (tcb);
