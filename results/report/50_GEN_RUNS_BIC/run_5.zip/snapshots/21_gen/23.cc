float GCTuABasmFQqEwuq = (float) (1.822+(tcb->m_cWnd));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (18.977+(31.923));
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (61.016*(78.507)*(74.965)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (28.939+(93.58)+(60.115)+(1.224));
	tcb->m_segmentSize = (int) ((tcb->m_ssThresh-(33.086)-(37.16)-(tcb->m_cWnd)-(29.799)-(2.0))/63.877);
	ReduceCwnd (tcb);

}
