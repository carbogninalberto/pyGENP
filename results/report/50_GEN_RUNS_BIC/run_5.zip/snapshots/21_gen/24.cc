ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	cnt = (int) (40.172+(2.403)+(2.203)+(cnt)+(25.804));

} else {
	cnt = (int) (70.844+(66.5)+(70.257)+(49.453));
	cnt = (int) (cnt-(tcb->m_segmentSize)-(28.215));
	tcb->m_cWnd = (int) (0.1/78.632);

}
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (73.161-(12.865)-(0.717)-(58.402)-(50.312)-(69.535)-(6.829)-(tcb->m_segmentSize)-(47.091));
	tcb->m_ssThresh = (int) ((13.75-(42.624))/79.134);
	segmentsAcked = (int) (70.13*(tcb->m_ssThresh)*(2.48)*(34.434)*(98.846)*(cnt)*(cnt));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(cnt)-(98.966)-(27.758)-(11.846)-(1.639)-(18.777));
	tcb->m_cWnd = (int) (2.964+(78.859));

}
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	segmentsAcked = (int) (2.177-(17.765));

} else {
	segmentsAcked = (int) (19.753+(79.88)+(89.437));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
