float aXzapkuHtCHLzwGM = (float) (8.227+(93.359)+(-79.979)+(-96.042)+(25.885)+(67.287)+(95.028)+(46.187));
float stPXyRJrfyHbQOLH = (float) 30.83;
stPXyRJrfyHbQOLH = (float) (((24.378)+(37.541)+((-24.204*(-0.735)*(-80.143)*(tcb->m_segmentSize)*(91.354)))+(5.154)+(44.761)+(-14.245))/((71.847)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < aXzapkuHtCHLzwGM) {
	tcb->m_cWnd = (int) (((0.1)+(86.486)+(10.616)+(8.145)+(26.974)+(0.1))/((0.1)));
	tcb->m_cWnd = (int) (72.287+(65.919));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (35.614*(43.828)*(-5.373)*(stPXyRJrfyHbQOLH)*(70.692)*(tcb->m_segmentSize)*(12.245)*(79.741));
	tcb->m_cWnd = (int) (46.479-(35.679)-(95.761)-(tcb->m_segmentSize)-(aXzapkuHtCHLzwGM));

}
ReduceCwnd (tcb);
