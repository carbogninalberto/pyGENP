if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_segmentSize = (int) (68.756+(77.075)+(segmentsAcked)+(90.625)+(16.512));
	tcb->m_ssThresh = (int) (85.147*(96.178)*(32.84)*(53.282));

} else {
	tcb->m_segmentSize = (int) (5.314-(80.752)-(80.883)-(31.053)-(20.954));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(cnt)*(91.783)*(74.982)*(25.935)*(52.544)*(cnt)*(20.008));

}
tcb->m_cWnd = (int) (67.481-(52.974)-(45.733)-(68.91)-(98.918)-(8.637)-(76.697)-(53.317)-(89.003));
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/25.864);

} else {
	tcb->m_cWnd = (int) (50.573-(70.822)-(0.084)-(30.252));
	segmentsAcked = (int) (8.325-(tcb->m_cWnd)-(60.764)-(31.068)-(tcb->m_segmentSize));
	segmentsAcked = (int) (50.409*(97.301)*(42.072)*(43.279)*(60.01)*(91.9)*(38.697));

}
tcb->m_cWnd = (int) (59.531*(61.965));
tcb->m_segmentSize = (int) (71.298*(97.922)*(29.95)*(32.732)*(74.603)*(12.599));
