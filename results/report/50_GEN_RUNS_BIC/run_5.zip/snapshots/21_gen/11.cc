segmentsAcked = (int) (11.763*(53.25)*(5.075));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (segmentsAcked != tcb->m_segmentSize) {
	cnt = (int) (57.348+(27.945)+(36.552)+(88.408)+(16.421)+(6.777));

} else {
	cnt = (int) (27.482-(35.059)-(9.226)-(16.796)-(40.151));
	segmentsAcked = (int) ((((57.156+(65.644)+(tcb->m_cWnd)))+(40.222)+(53.198)+(0.1)+(69.186)+(0.1)+(77.479)+(0.1))/((2.124)));
	tcb->m_cWnd = (int) (58.902+(35.878)+(46.196)+(80.204)+(tcb->m_segmentSize)+(80.223)+(99.372)+(61.296));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (5.04+(45.777)+(cnt)+(65.724)+(1.805)+(19.847));
segmentsAcked = (int) (76.717-(18.539)-(17.1));
