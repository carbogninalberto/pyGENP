if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (76.006*(23.639)*(cnt)*(89.522)*(45.483));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float pWGNyjwZJzhJEIdQ = (float) (0.1/0.1);
tcb->m_ssThresh = (int) (39.18*(24.702)*(51.717)*(26.036));
