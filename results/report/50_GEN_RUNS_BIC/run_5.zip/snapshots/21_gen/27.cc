ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (63.337-(37.013)-(73.424)-(66.963)-(69.808)-(91.592)-(83.553)-(tcb->m_cWnd)-(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (40.089*(99.608)*(93.776)*(77.151)*(22.796));

}
tcb->m_segmentSize = (int) ((((13.35*(tcb->m_cWnd)*(46.749)*(tcb->m_segmentSize)*(10.322)*(64.067)*(75.059)*(13.922)*(tcb->m_segmentSize)))+((tcb->m_cWnd+(tcb->m_cWnd)+(83.861)+(85.937)+(cnt)))+(70.798)+(78.948))/((0.1)));
segmentsAcked = (int) (8.903/(tcb->m_segmentSize+(35.477)+(tcb->m_segmentSize)+(60.957)));
