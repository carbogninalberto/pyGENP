if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (86.516+(cnt));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (92.491*(48.947));
	cnt = (int) (4.983*(22.056)*(98.82)*(cnt));

}
if (cnt == segmentsAcked) {
	tcb->m_ssThresh = (int) (49.646*(segmentsAcked)*(14.028)*(36.668)*(8.201));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) ((21.693-(12.294)-(tcb->m_segmentSize)-(70.999)-(28.267)-(8.245)-(95.745))/78.901);
	cnt = (int) (2.052/0.1);
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/40.399);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (35.33*(77.323)*(69.764)*(62.776));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (23.609+(49.799)+(79.064));
	segmentsAcked = (int) (26.781*(47.913)*(29.994)*(79.079)*(segmentsAcked)*(81.859));

}
