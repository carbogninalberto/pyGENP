if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (98.086+(tcb->m_segmentSize)+(98.791));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize <= cnt) {
	tcb->m_cWnd = (int) (86.197+(91.276)+(46.564)+(21.113)+(46.548)+(cnt)+(47.112)+(50.146));

} else {
	tcb->m_cWnd = (int) (22.347*(78.341)*(79.601)*(segmentsAcked)*(6.008)*(35.873)*(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
