ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (tcb->m_ssThresh*(46.285)*(34.143));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (tcb->m_cWnd*(tcb->m_ssThresh)*(61.738)*(cnt)*(62.715)*(77.992)*(86.811));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(56.156))/((0.1)+(30.907)+(53.979)));

} else {
	segmentsAcked = (int) (cnt*(38.815)*(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(77.595)-(56.03)-(15.441)-(91.628)-(77.244)-(21.247));

}
