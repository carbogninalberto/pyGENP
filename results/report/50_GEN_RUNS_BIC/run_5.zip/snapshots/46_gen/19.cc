ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (11.608-(72.193)-(48.372)-(39.206)-(tcb->m_ssThresh)-(48.423)-(82.105)-(42.79)-(24.154));
float CVZlBKZPbFPHutKR = (float) (91.365+(cnt)+(85.446));
int wrWtFMTLqKAYITvr = (int) (((61.223)+((54.925-(51.136)-(63.344)-(27.922)-(87.171)-(10.56)))+(83.71)+(0.1))/((22.034)+(0.1)));
tcb->m_cWnd = (int) ((((62.633*(tcb->m_segmentSize)*(segmentsAcked)*(38.961)))+((56.563+(tcb->m_cWnd)+(tcb->m_ssThresh)+(65.97)+(31.39)+(wrWtFMTLqKAYITvr)))+(64.502)+(48.597)+(61.015)+(0.1))/((46.373)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (wrWtFMTLqKAYITvr == wrWtFMTLqKAYITvr) {
	CVZlBKZPbFPHutKR = (float) (84.496+(35.427)+(88.898)+(53.05)+(95.978)+(69.232));

} else {
	CVZlBKZPbFPHutKR = (float) (89.605+(63.435)+(36.191)+(28.426)+(tcb->m_cWnd)+(22.267)+(37.108));
	tcb->m_ssThresh = (int) (15.477-(66.478)-(tcb->m_ssThresh)-(49.229)-(64.949)-(8.634)-(cnt));

}
