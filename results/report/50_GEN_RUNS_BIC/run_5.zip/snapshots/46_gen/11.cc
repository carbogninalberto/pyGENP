if (tcb->m_segmentSize <= tcb->m_cWnd) {
	segmentsAcked = (int) (20.611*(tcb->m_ssThresh)*(11.937));

} else {
	segmentsAcked = (int) (37.742/19.811);

}
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(2.411)+(56.045))/((0.1)));
	tcb->m_ssThresh = (int) ((48.705*(64.907)*(tcb->m_segmentSize)*(segmentsAcked)*(83.545)*(24.025)*(73.935)*(71.21)*(92.198))/22.945);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (((32.258)+(58.314)+((23.077-(8.326)-(11.108)-(tcb->m_segmentSize)-(4.452)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(tcb->m_segmentSize)-(29.52)))+(36.781)+(44.728))/((0.1)+(31.15)+(54.984)));

}
int nBwsDihVCrKJqcAE = (int) (tcb->m_segmentSize*(96.027)*(37.477));
segmentsAcked = (int) (8.158*(10.983)*(tcb->m_cWnd)*(9.919));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (40.803+(36.761)+(56.847)+(33.583)+(tcb->m_ssThresh)+(97.162)+(70.095));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
