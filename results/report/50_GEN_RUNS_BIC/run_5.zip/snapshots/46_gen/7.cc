int llhBQZlChycNnyiV = (int) (49.943*(6.623)*(27.496));
ReduceCwnd (tcb);
segmentsAcked = (int) (13.674+(72.821)+(34.564)+(89.744)+(45.673)+(-36.622)+(76.94));
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (7.08*(5.676)*(12.507)*(66.957)*(26.836)*(57.237)*(segmentsAcked)*(54.352)*(45.321));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (((65.033)+((segmentsAcked+(31.084)+(tcb->m_ssThresh)+(54.754)))+((27.346+(4.191)+(48.655)+(38.256)+(71.695)+(33.656)+(93.585)))+(2.736))/((31.873)+(0.1)+(0.1)+(0.1)+(31.889)));

}
ReduceCwnd (tcb);
if (llhBQZlChycNnyiV != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(99.781)+((57.342*(18.849)*(57.254)))+(72.17))/((0.1)+(64.378)));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (80.456*(35.841)*(88.547)*(73.486)*(52.142)*(94.42)*(41.174)*(30.618));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (-81.1+(47.624)+(-44.457)+(57.281)+(-27.088)+(63.867)+(-65.848));
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (7.08*(5.676)*(12.507)*(66.957)*(26.836)*(57.237)*(segmentsAcked)*(54.352)*(45.321));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (((65.033)+((segmentsAcked+(31.084)+(tcb->m_ssThresh)+(54.754)))+((27.346+(4.191)+(48.655)+(38.256)+(71.695)+(33.656)+(93.585)))+(2.736))/((31.873)+(0.1)+(0.1)+(0.1)+(31.889)));

}
if (llhBQZlChycNnyiV != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(99.781)+((57.342*(18.849)*(57.254)))+(72.17))/((0.1)+(64.378)));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (80.456*(35.841)*(88.547)*(95.069)*(52.142)*(50.307)*(41.174)*(30.618));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
