if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (32.782-(-7.757)-(-32.554)-(-30.843)-(-23.767)-(32.946)-(30.135)-(89.241)-(14.633));
