float wXlEIneDOoMlURQC = (float) (96.259/-39.49);
float NZZUpyHBqneUsPUc = (float) (((47.879)+(77.407)+(93.945)+((98.017-(-36.975)-(-3.703)-(31.241)))+(-50.762))/((-85.068)+(67.801)+(46.953)));
int hlLKKJDPkHpSUOqD = (int) 4.938;
if (wXlEIneDOoMlURQC > hlLKKJDPkHpSUOqD) {
	segmentsAcked = (int) ((((26.85*(65.261)*(70.081)*(78.261)))+((tcb->m_segmentSize+(73.473)+(80.136)+(90.257)+(16.413)+(46.934)+(5.143)))+(0.1)+(0.1))/((30.272)));

} else {
	segmentsAcked = (int) (73.118-(72.415)-(44.063)-(8.81)-(77.073)-(28.442)-(12.776)-(78.718)-(56.405));
	segmentsAcked = (int) (0.1/0.1);

}
