ReduceCwnd (tcb);
segmentsAcked = (int) (98.686*(tcb->m_ssThresh)*(10.077)*(segmentsAcked)*(79.875)*(tcb->m_ssThresh)*(17.049)*(81.018));
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_ssThresh = (int) (3.982*(89.187)*(48.068)*(8.465)*(0.49)*(83.145)*(51.162)*(80.647));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(88.648)-(3.763)-(13.416)-(80.534)-(41.385));

}
float CGlQzvBQWpIuaxzj = (float) (31.104-(25.397)-(63.323)-(26.799)-(89.081)-(50.834));
cnt = (int) (24.943+(77.237)+(19.115)+(63.827)+(8.508)+(segmentsAcked)+(75.553)+(58.057)+(0.712));
tcb->m_segmentSize = (int) ((((15.103*(16.951)*(6.684)*(23.769)*(90.103)))+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(76.162)+(52.45)));
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_cWnd = (int) (39.012-(42.282)-(34.428)-(36.744));

} else {
	tcb->m_cWnd = (int) (29.888+(83.512));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_ssThresh = (int) (80.919+(31.293)+(74.386)+(tcb->m_cWnd)+(38.314)+(39.225)+(tcb->m_ssThresh));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (58.155*(cnt)*(54.509));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
