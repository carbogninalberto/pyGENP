int llhBQZlChycNnyiV = (int) (49.52*(-44.554)*(-47.731));
ReduceCwnd (tcb);
segmentsAcked = (int) (-96.156+(-58.643)+(-73.301)+(-77.363)+(4.456)+(-88.86)+(-20.143));
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (7.08*(5.676)*(12.507)*(66.957)*(26.836)*(57.237)*(segmentsAcked)*(54.352)*(45.321));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (((65.033)+((segmentsAcked+(31.084)+(tcb->m_ssThresh)+(54.754)))+((27.346+(4.191)+(48.655)+(38.256)+(71.695)+(33.656)+(93.585)))+(2.736))/((31.873)+(0.1)+(0.1)+(0.1)+(31.889)));

}
if (llhBQZlChycNnyiV != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(99.781)+((57.342*(18.849)*(57.254)))+(72.17))/((0.1)+(64.378)));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (80.456*(35.841)*(88.547)*(-97.65)*(52.142)*(69.291)*(41.174)*(30.618));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
