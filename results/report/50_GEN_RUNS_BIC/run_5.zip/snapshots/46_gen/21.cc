tcb->m_cWnd = (int) (20.751*(48.611)*(95.767)*(68.204)*(38.128)*(10.658));
if (tcb->m_cWnd > segmentsAcked) {
	cnt = (int) (89.99-(tcb->m_segmentSize)-(9.898)-(segmentsAcked)-(tcb->m_ssThresh)-(40.176));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (8.63+(64.844)+(12.521)+(13.806)+(tcb->m_cWnd)+(76.824)+(41.849));

} else {
	cnt = (int) (57.446+(27.032)+(11.932)+(86.872)+(59.839)+(89.467)+(21.426));
	segmentsAcked = (int) (tcb->m_cWnd+(tcb->m_segmentSize)+(tcb->m_ssThresh));

}
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	cnt = (int) (36.909*(27.899)*(21.941)*(tcb->m_cWnd)*(77.094)*(75.14)*(26.671));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (19.209-(7.87)-(57.557)-(42.91)-(67.959));

} else {
	cnt = (int) (61.857-(10.154)-(tcb->m_cWnd)-(57.916)-(77.445));

}
tcb->m_cWnd = (int) (cnt+(segmentsAcked)+(74.071)+(6.696)+(11.212)+(2.285));
tcb->m_cWnd = (int) (26.179-(29.596)-(43.814)-(33.513)-(87.503));
tcb->m_segmentSize = (int) (43.412+(segmentsAcked)+(82.836)+(41.225)+(70.696));
segmentsAcked = (int) (82.688*(0.208)*(71.551)*(tcb->m_ssThresh));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (79.088*(6.911));
	tcb->m_ssThresh = (int) (61.297+(45.062)+(42.8)+(8.866));

} else {
	tcb->m_cWnd = (int) (49.767+(62.993)+(43.048)+(tcb->m_ssThresh)+(96.753)+(98.118)+(tcb->m_cWnd)+(13.837)+(cnt));
	ReduceCwnd (tcb);

}
