float zXijaMieDWdLxYwd = (float) (19.983+(65.361)+(75.489)+(tcb->m_ssThresh)+(94.145)+(57.95));
if (tcb->m_cWnd < zXijaMieDWdLxYwd) {
	tcb->m_cWnd = (int) (77.338*(33.036)*(82.779)*(70.868)*(54.44)*(18.895)*(71.519)*(19.878)*(68.121));

} else {
	tcb->m_cWnd = (int) (44.434*(51.986)*(86.046)*(14.446)*(17.01));
	cnt = (int) (53.641-(40.664)-(5.036)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(52.84)-(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (0.722*(14.462)*(7.767)*(cnt)*(tcb->m_cWnd)*(19.377));

}
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	zXijaMieDWdLxYwd = (float) (tcb->m_segmentSize+(44.326)+(72.874)+(segmentsAcked)+(28.156)+(62.462)+(10.256)+(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (42.004-(41.274)-(59.94)-(95.688)-(17.434)-(37.224)-(40.334)-(6.341)-(98.366));

} else {
	zXijaMieDWdLxYwd = (float) (55.736-(75.638)-(zXijaMieDWdLxYwd)-(93.195)-(44.295));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
if (zXijaMieDWdLxYwd < cnt) {
	tcb->m_cWnd = (int) (66.87/33.636);
	ReduceCwnd (tcb);
	zXijaMieDWdLxYwd = (float) (20.96-(49.224)-(segmentsAcked)-(67.435)-(52.706)-(49.199));

} else {
	tcb->m_cWnd = (int) (zXijaMieDWdLxYwd+(37.5)+(18.297)+(8.628)+(56.753)+(tcb->m_ssThresh)+(88.706));
	tcb->m_segmentSize = (int) (zXijaMieDWdLxYwd*(30.291));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
