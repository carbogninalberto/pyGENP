if (tcb->m_cWnd < cnt) {
	tcb->m_ssThresh = (int) (67.455/0.1);
	tcb->m_segmentSize = (int) ((62.11*(16.519)*(segmentsAcked)*(93.539)*(94.698)*(4.59)*(cnt)*(12.123))/63.59);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (41.33-(71.353)-(cnt)-(68.238)-(75.245)-(58.244)-(36.67)-(93.398)-(59.433));

}
tcb->m_cWnd = (int) (86.038-(70.084)-(83.257)-(cnt)-(8.084)-(54.078));
ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (50.296-(75.341)-(49.639)-(tcb->m_ssThresh)-(25.766)-(4.176)-(2.625)-(17.927));

} else {
	tcb->m_ssThresh = (int) (3.398*(89.32)*(21.885)*(tcb->m_ssThresh));

}
if (tcb->m_cWnd < segmentsAcked) {
	cnt = (int) (18.623-(25.574)-(segmentsAcked)-(40.453)-(70.351)-(59.629)-(16.08)-(97.671));
	segmentsAcked = (int) (segmentsAcked*(20.361));

} else {
	cnt = (int) (51.215-(tcb->m_ssThresh)-(tcb->m_cWnd)-(33.786)-(27.761)-(42.251)-(74.993)-(tcb->m_cWnd)-(30.834));

}
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_cWnd = (int) (0.1/59.643);

} else {
	tcb->m_cWnd = (int) (45.32*(52.067)*(cnt)*(cnt)*(cnt)*(cnt));
	tcb->m_ssThresh = (int) (35.677*(tcb->m_ssThresh)*(94.537)*(66.905)*(39.542));
	tcb->m_cWnd = (int) (((37.274)+((12.447*(94.177)*(64.811)*(8.669)*(37.0)*(0.587)*(tcb->m_ssThresh)*(17.74)))+(91.736)+(15.719))/((66.209)));

}
tcb->m_ssThresh = (int) (37.593*(91.968));
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(73.678)-(68.684));
