if (tcb->m_segmentSize != segmentsAcked) {
	segmentsAcked = (int) ((56.036-(32.713)-(56.71)-(34.003)-(19.957)-(63.808))/0.1);
	tcb->m_cWnd = (int) (99.399+(93.396)+(94.517)+(segmentsAcked)+(tcb->m_cWnd)+(43.059)+(tcb->m_ssThresh)+(19.502)+(6.997));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (2.052-(tcb->m_ssThresh)-(12.929)-(76.127)-(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (51.687-(tcb->m_cWnd)-(17.203)-(43.372)-(72.88)-(49.756)-(17.553)-(tcb->m_segmentSize)-(53.028));
if (cnt == tcb->m_cWnd) {
	cnt = (int) (tcb->m_segmentSize-(tcb->m_ssThresh)-(15.798)-(tcb->m_cWnd)-(tcb->m_cWnd)-(93.796)-(52.542));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (72.508/0.1);
	cnt = (int) (tcb->m_cWnd*(7.654)*(54.994)*(7.973)*(38.308)*(31.992)*(96.835)*(tcb->m_segmentSize)*(tcb->m_cWnd));

}
