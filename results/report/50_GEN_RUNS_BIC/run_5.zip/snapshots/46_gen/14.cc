if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (segmentsAcked-(75.025)-(44.103)-(42.723));
segmentsAcked = (int) ((73.821*(22.551)*(tcb->m_cWnd)*(96.476)*(tcb->m_segmentSize)*(66.631)*(31.669)*(26.481)*(tcb->m_ssThresh))/0.1);
tcb->m_segmentSize = (int) (segmentsAcked-(9.291));
cnt = (int) (tcb->m_cWnd-(tcb->m_segmentSize)-(85.198));
