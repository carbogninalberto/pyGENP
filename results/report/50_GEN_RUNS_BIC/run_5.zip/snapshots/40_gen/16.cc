if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+(71.542)+(71.019)+(0.1)+(0.1))/((73.962)));
	tcb->m_cWnd = (int) (14.932-(cnt)-(2.453)-(13.898));

} else {
	tcb->m_segmentSize = (int) (cnt-(20.357)-(56.218));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(58.058));
	tcb->m_segmentSize = (int) (1.148/0.1);
	cnt = (int) (27.017-(4.773));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(segmentsAcked)+(97.01));
	tcb->m_segmentSize = (int) (0.1/(79.037+(cnt)));
	tcb->m_ssThresh = (int) (44.454+(12.249)+(37.735)+(97.078)+(50.206));

}
if (segmentsAcked != tcb->m_cWnd) {
	cnt = (int) (26.462-(90.674)-(66.241)-(39.728)-(0.683));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (27.081*(cnt)*(42.465));

}
segmentsAcked = (int) (segmentsAcked+(20.506)+(2.763)+(22.423)+(69.187)+(54.267));
