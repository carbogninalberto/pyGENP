ReduceCwnd (tcb);
ReduceCwnd (tcb);
float arZSRvMnaPFohkLK = (float) (90.96/0.1);
cnt = (int) (arZSRvMnaPFohkLK+(91.898)+(cnt)+(76.786)+(49.877));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float LMqMmnsEQNTmBIcs = (float) (22.789-(51.775)-(tcb->m_segmentSize)-(58.635)-(95.821)-(26.062)-(86.942)-(11.337)-(53.175));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
