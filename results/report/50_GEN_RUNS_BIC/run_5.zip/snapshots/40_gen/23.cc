ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_cWnd-(35.811));
int PZxLTSIgUOboYYDk = (int) (53.285-(86.785)-(tcb->m_segmentSize)-(87.614));
float UXvIEmisUzkkJoLG = (float) (4.074-(7.369));
if (segmentsAcked >= UXvIEmisUzkkJoLG) {
	tcb->m_cWnd = (int) (24.268-(74.199)-(PZxLTSIgUOboYYDk)-(34.374)-(6.276)-(79.461));
	tcb->m_cWnd = (int) (0.18+(28.941)+(17.764));

} else {
	tcb->m_cWnd = (int) (99.917-(87.419)-(71.352)-(tcb->m_segmentSize)-(79.845)-(tcb->m_cWnd)-(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (0.1/0.1);

}
PZxLTSIgUOboYYDk = (int) (cnt-(28.243)-(70.832)-(9.335)-(85.75));
