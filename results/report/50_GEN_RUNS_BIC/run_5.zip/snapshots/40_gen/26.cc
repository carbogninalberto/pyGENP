if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < cnt) {
	tcb->m_ssThresh = (int) (0.1/61.635);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(1.005)-(6.546)-(21.895)-(57.75)-(10.362)-(90.155)-(42.366));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= cnt) {
	tcb->m_ssThresh = (int) (99.25-(47.872));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (20.733+(60.714)+(20.991)+(3.487)+(21.004));
	ReduceCwnd (tcb);
	cnt = (int) (cnt*(48.807));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt <= cnt) {
	tcb->m_ssThresh = (int) (75.69-(tcb->m_segmentSize)-(21.742));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) ((23.636+(87.596)+(75.83)+(segmentsAcked)+(62.988)+(32.301))/0.1);

} else {
	tcb->m_ssThresh = (int) (0.1/2.374);
	segmentsAcked = (int) (87.612*(75.914)*(50.299)*(20.706)*(10.837)*(15.98)*(11.666)*(92.157));
	ReduceCwnd (tcb);

}
if (segmentsAcked >= tcb->m_segmentSize) {
	cnt = (int) (tcb->m_ssThresh+(42.307)+(segmentsAcked)+(11.661)+(54.345)+(29.935));

} else {
	cnt = (int) (tcb->m_ssThresh*(83.797)*(49.418)*(cnt)*(1.648)*(97.422)*(80.482));

}
tcb->m_cWnd = (int) (78.278*(5.071)*(tcb->m_ssThresh)*(54.156)*(97.452)*(70.06));
