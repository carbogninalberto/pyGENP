ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	cnt = (int) (79.517-(94.231)-(50.489)-(85.103)-(62.106)-(tcb->m_segmentSize)-(46.649)-(17.764));
	tcb->m_ssThresh = (int) (31.599*(42.201)*(50.102)*(21.605));
	tcb->m_segmentSize = (int) (((0.1)+((segmentsAcked+(44.851)+(tcb->m_ssThresh)+(36.91)+(75.76)+(19.13)))+(11.548)+(23.286))/((84.435)+(0.1)+(0.1)+(0.1)));

} else {
	cnt = (int) (71.183*(82.465)*(69.928)*(92.14)*(tcb->m_cWnd)*(97.031));

}
tcb->m_segmentSize = (int) (10.063-(4.749)-(77.208)-(26.325)-(87.35)-(34.218)-(39.415)-(12.94)-(52.217));
cnt = (int) (5.385-(35.352));
segmentsAcked = (int) (tcb->m_segmentSize-(cnt)-(35.22)-(61.395));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (88.169-(18.102));
float uDRpfUeUfoYhQwwG = (float) (92.917-(68.108)-(tcb->m_cWnd)-(97.001));
if (tcb->m_cWnd <= uDRpfUeUfoYhQwwG) {
	tcb->m_segmentSize = (int) (92.977+(33.126)+(16.195)+(38.475)+(80.654)+(96.29)+(8.07)+(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (90.373/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (83.352+(75.978)+(tcb->m_cWnd)+(54.659)+(32.168)+(94.306));

}
