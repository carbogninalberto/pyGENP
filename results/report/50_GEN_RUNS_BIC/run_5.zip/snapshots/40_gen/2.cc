ReduceCwnd (tcb);
float JjknBaQPOFuoqmnx = (float) (28.433+(-4.92)+(16.109));
tcb->m_cWnd = (int) (3.078*(50.095)*(-78.757));
