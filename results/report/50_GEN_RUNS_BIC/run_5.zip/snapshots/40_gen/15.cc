ReduceCwnd (tcb);
float JjknBaQPOFuoqmnx = (float) (79.318+(-25.078)+(-56.119));
tcb->m_cWnd = (int) (54.698*(6.001)*(36.887));
tcb->m_cWnd = (int) (61.496*(-76.186)*(-12.398));
tcb->m_cWnd = (int) (45.046*(13.619)*(26.376));
tcb->m_cWnd = (int) (-85.049*(50.879)*(55.982));
tcb->m_cWnd = (int) (-0.028*(4.955)*(-70.965));
