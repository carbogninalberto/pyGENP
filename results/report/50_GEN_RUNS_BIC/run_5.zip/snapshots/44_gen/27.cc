if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float bJirNeERzDyfLgUp = (float) (tcb->m_cWnd-(91.897)-(3.03));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (bJirNeERzDyfLgUp >= bJirNeERzDyfLgUp) {
	tcb->m_segmentSize = (int) (72.995*(83.769)*(tcb->m_cWnd)*(17.865)*(28.496)*(tcb->m_ssThresh)*(61.948));
	bJirNeERzDyfLgUp = (float) (64.698*(95.169)*(76.892)*(tcb->m_cWnd)*(75.539)*(17.999)*(11.315)*(80.495));

} else {
	tcb->m_segmentSize = (int) (37.978-(81.468)-(cnt)-(61.941)-(59.481));

}
float kUEenfcaEpReFcgQ = (float) (89.142-(bJirNeERzDyfLgUp)-(53.138)-(tcb->m_cWnd)-(tcb->m_cWnd)-(57.221)-(38.665));
kUEenfcaEpReFcgQ = (float) (tcb->m_cWnd+(25.396)+(42.891));
