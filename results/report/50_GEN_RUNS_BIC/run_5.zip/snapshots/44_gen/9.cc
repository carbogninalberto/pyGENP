tcb->m_cWnd = (int) (48.321*(-71.718)*(-85.082));
ReduceCwnd (tcb);
float JjknBaQPOFuoqmnx = (float) (-94.818+(-1.453)+(86.035));
tcb->m_cWnd = (int) (-21.819*(-75.189)*(45.752));
tcb->m_cWnd = (int) (-45.024*(-77.608)*(28.913));
tcb->m_cWnd = (int) (42.194*(-3.354)*(28.651));
