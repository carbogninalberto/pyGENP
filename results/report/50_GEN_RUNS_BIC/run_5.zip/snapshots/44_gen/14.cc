cnt = (int) (((0.1)+(0.1)+((33.103+(85.12)+(34.974)+(tcb->m_cWnd)+(tcb->m_cWnd)+(63.875)))+(46.351)+((63.231+(13.093)+(83.435)+(tcb->m_cWnd)+(53.652)))+(84.324))/((0.1)+(0.1)));
cnt = (int) (13.489-(22.552)-(tcb->m_segmentSize)-(47.526)-(48.758)-(tcb->m_ssThresh)-(cnt));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (11.197-(28.143)-(12.272)-(71.177));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (45.166-(87.896));

} else {
	tcb->m_cWnd = (int) (30.693-(4.197)-(segmentsAcked)-(83.316)-(98.48)-(64.069)-(89.971)-(60.557)-(cnt));
	tcb->m_segmentSize = (int) (0.1/0.1);

}
tcb->m_ssThresh = (int) (11.857+(70.99)+(1.109)+(4.966)+(10.357)+(98.776)+(segmentsAcked)+(81.687)+(10.971));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
