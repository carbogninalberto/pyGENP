float TmqaOgXnPVgKUssF = (float) (cnt+(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (90.718-(75.732)-(tcb->m_ssThresh)-(13.457)-(74.087)-(79.534)-(tcb->m_cWnd)-(96.32)-(tcb->m_cWnd));
if (segmentsAcked == tcb->m_segmentSize) {
	TmqaOgXnPVgKUssF = (float) (0.1/82.469);
	tcb->m_segmentSize = (int) ((72.776+(80.234)+(8.321))/40.759);

} else {
	TmqaOgXnPVgKUssF = (float) (57.371+(78.836)+(77.854)+(19.312)+(8.017)+(67.846));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_cWnd <= TmqaOgXnPVgKUssF) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(90.573)-(69.474)-(17.574));

} else {
	tcb->m_ssThresh = (int) (88.394-(segmentsAcked)-(73.065)-(86.029));

}
segmentsAcked = (int) (tcb->m_ssThresh-(14.44)-(95.558)-(71.638)-(34.349)-(tcb->m_ssThresh));
if (segmentsAcked < TmqaOgXnPVgKUssF) {
	tcb->m_cWnd = (int) (24.881+(tcb->m_ssThresh)+(25.519)+(segmentsAcked)+(61.982)+(tcb->m_cWnd)+(TmqaOgXnPVgKUssF)+(40.701));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (30.977-(5.988));
	TmqaOgXnPVgKUssF = (float) (tcb->m_segmentSize+(segmentsAcked)+(TmqaOgXnPVgKUssF));
	ReduceCwnd (tcb);

}
