tcb->m_cWnd = (int) (-10.572*(14.639)*(-7.367)*(-31.79)*(49.274)*(30.689)*(81.436)*(-65.383));
tcb->m_cWnd = (int) (63.645*(-69.938)*(-92.052)*(-28.678)*(81.035)*(-1.373)*(29.951)*(-74.003));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
