if (segmentsAcked >= tcb->m_ssThresh) {
	segmentsAcked = (int) (85.25/0.1);
	tcb->m_ssThresh = (int) (9.62*(21.319)*(15.183)*(89.66)*(55.546)*(69.727)*(15.863)*(68.353));

} else {
	segmentsAcked = (int) (12.325-(62.239)-(62.64)-(51.216)-(98.744)-(17.503));
	tcb->m_cWnd = (int) (72.144/12.189);
	segmentsAcked = (int) (79.716*(tcb->m_segmentSize)*(cnt));

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (46.501/0.1);
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (70.791-(9.572)-(60.07)-(2.394)-(23.01)-(35.882)-(68.585)-(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) ((34.679*(segmentsAcked)*(27.541))/0.1);

}
if (segmentsAcked == cnt) {
	tcb->m_cWnd = (int) (1.989*(50.799));
	tcb->m_ssThresh = (int) (((89.14)+(80.147)+((99.075+(89.135)+(81.541)+(cnt)+(tcb->m_segmentSize)+(89.581)))+(0.1)+(0.1)+(69.953))/((0.1)+(0.1)));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(13.338)*(81.34)*(tcb->m_cWnd)*(55.887)*(segmentsAcked)*(75.661)*(2.074));
	segmentsAcked = (int) (26.903+(65.906));

}
if (cnt > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (91.281/9.404);

} else {
	tcb->m_ssThresh = (int) (85.344+(26.863)+(14.611)+(tcb->m_segmentSize)+(30.887)+(50.278));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (tcb->m_ssThresh*(11.179)*(tcb->m_cWnd)*(segmentsAcked)*(tcb->m_ssThresh)*(25.284)*(tcb->m_cWnd)*(36.172)*(34.931));
