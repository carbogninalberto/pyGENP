if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (6.887+(tcb->m_segmentSize)+(30.431)+(24.15));
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(20.138)+(14.261))/((96.726)));

} else {
	tcb->m_ssThresh = (int) (97.273-(31.606)-(56.66));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (94.227-(94.526)-(36.466)-(80.399)-(97.795)-(98.663)-(73.851)-(70.572)-(94.593));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
segmentsAcked = (int) (79.124-(77.097));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
