if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (95.938*(59.607)*(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (70.046+(segmentsAcked)+(33.034)+(tcb->m_segmentSize)+(63.42)+(tcb->m_ssThresh));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd != segmentsAcked) {
	segmentsAcked = (int) (81.39-(81.933)-(72.301)-(82.009)-(cnt));

} else {
	segmentsAcked = (int) (10.044+(99.516));

}
segmentsAcked = (int) (92.667+(31.867)+(91.733)+(49.03)+(2.033)+(88.046));
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(6.652)+(cnt));

} else {
	tcb->m_ssThresh = (int) (42.928-(6.643)-(45.225)-(88.129)-(99.765)-(24.243)-(56.782)-(83.3));

}
cnt = (int) (13.146+(cnt)+(86.796)+(tcb->m_ssThresh)+(22.741)+(48.369)+(65.647)+(27.491)+(0.754));
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(94.966)+(25.637))/((91.964)+(81.567)+(61.312)+(20.517)+(98.65)));

} else {
	tcb->m_cWnd = (int) (segmentsAcked*(tcb->m_segmentSize)*(38.897)*(19.916));
	tcb->m_ssThresh = (int) (cnt*(35.987)*(86.936)*(33.473)*(38.237));

}
ReduceCwnd (tcb);
