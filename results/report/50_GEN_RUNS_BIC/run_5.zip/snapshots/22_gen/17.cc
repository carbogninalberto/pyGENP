ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked <= tcb->m_ssThresh) {
	segmentsAcked = (int) (93.384/0.1);
	tcb->m_segmentSize = (int) (((27.007)+(44.205)+(86.998)+(40.638)+(0.1))/((0.1)));

} else {
	segmentsAcked = (int) (cnt+(tcb->m_ssThresh)+(91.004)+(cnt)+(64.964)+(43.077));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
