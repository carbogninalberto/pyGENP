if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (42.488+(66.183)+(67.686)+(tcb->m_segmentSize)+(10.169)+(tcb->m_segmentSize)+(63.657)+(tcb->m_cWnd));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(37.466)+(74.178));
	cnt = (int) (tcb->m_segmentSize*(10.315));
	tcb->m_ssThresh = (int) (4.982-(54.257)-(59.143)-(84.736)-(26.989)-(5.554)-(68.437)-(16.032));

}
segmentsAcked = (int) (87.387+(74.513)+(15.933)+(68.072)+(tcb->m_cWnd)+(tcb->m_cWnd)+(8.874)+(tcb->m_segmentSize));
tcb->m_segmentSize = (int) ((0.12*(cnt)*(15.068)*(tcb->m_segmentSize)*(83.858)*(tcb->m_cWnd)*(8.406)*(64.685)*(13.296))/(tcb->m_cWnd*(cnt)*(61.074)*(55.014)*(36.937)*(73.347)*(21.369)*(77.806)));
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/45.533);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (32.531+(99.132)+(37.353)+(59.195)+(14.733)+(50.065));
	tcb->m_segmentSize = (int) ((15.517*(3.761)*(tcb->m_cWnd)*(88.687))/89.021);

}
int WzWNtdOzFaMpSLqW = (int) (56.958+(78.09)+(79.062)+(cnt)+(36.376));
