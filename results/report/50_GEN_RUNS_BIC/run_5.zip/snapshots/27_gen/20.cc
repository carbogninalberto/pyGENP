if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float kHksptkSjXrTLkyT = (float) (13.156*(28.221)*(99.022));
segmentsAcked = (int) (64.843+(38.881)+(tcb->m_segmentSize)+(80.3)+(tcb->m_segmentSize));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
kHksptkSjXrTLkyT = (float) (75.926/(38.13*(80.893)*(2.923)*(19.152)*(61.149)));
