ReduceCwnd (tcb);
cnt = (int) (tcb->m_ssThresh+(21.281));
tcb->m_cWnd = (int) (65.897*(91.001)*(4.384));
if (cnt > cnt) {
	cnt = (int) (22.826+(84.803)+(35.087)+(22.443)+(81.63)+(23.44));

} else {
	cnt = (int) (89.018*(tcb->m_ssThresh)*(segmentsAcked)*(65.291)*(52.854)*(tcb->m_segmentSize)*(85.786)*(64.815));
	segmentsAcked = (int) (tcb->m_segmentSize+(59.712)+(cnt)+(5.245)+(81.499)+(9.158));

}
if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_segmentSize-(cnt)-(56.283));
	segmentsAcked = (int) (79.81+(95.845));

} else {
	segmentsAcked = (int) (59.635/0.1);

}
if (cnt != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.1/38.965);

} else {
	tcb->m_ssThresh = (int) (cnt+(tcb->m_cWnd)+(24.446)+(88.492)+(12.242));
	cnt = (int) (97.149-(18.071)-(83.552)-(tcb->m_cWnd)-(0.889));

}
