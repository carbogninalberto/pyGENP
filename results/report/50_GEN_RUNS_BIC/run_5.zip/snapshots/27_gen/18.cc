ReduceCwnd (tcb);
if (tcb->m_ssThresh < cnt) {
	cnt = (int) (0.1/0.1);

} else {
	cnt = (int) (77.688*(tcb->m_segmentSize)*(88.227)*(20.416)*(5.118)*(78.689)*(14.482)*(cnt)*(80.806));
	tcb->m_cWnd = (int) (cnt-(segmentsAcked)-(58.158)-(54.082));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= cnt) {
	cnt = (int) (5.428-(47.485)-(83.049)-(36.391)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(48.703));

} else {
	cnt = (int) (tcb->m_segmentSize+(24.521)+(39.556)+(23.494)+(tcb->m_segmentSize)+(99.641)+(31.377)+(11.196));
	cnt = (int) (((0.1)+(5.389)+(0.1)+(83.975)+(14.933)+(0.1))/((0.1)+(0.1)));

}
segmentsAcked = (int) (69.566-(18.234)-(cnt)-(86.362)-(84.591));
segmentsAcked = (int) (50.378/13.931);
ReduceCwnd (tcb);
