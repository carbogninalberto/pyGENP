if (tcb->m_ssThresh == cnt) {
	tcb->m_ssThresh = (int) (0.1/76.814);

} else {
	tcb->m_ssThresh = (int) (((0.1)+(33.627)+(0.1)+(0.1))/((0.1)));
	tcb->m_cWnd = (int) (((0.1)+(96.376)+(0.1)+(1.527))/((36.999)+(91.125)));

}
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((0.1)+((13.064*(87.857)))+(66.963)+(18.752)+(0.1)+(71.144)+(7.518))/((0.1)+(0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (15.408*(36.737)*(85.765)*(7.713)*(80.054)*(72.442)*(17.829));

}
if (segmentsAcked <= cnt) {
	tcb->m_ssThresh = (int) (67.496*(52.274)*(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (69.301+(41.586)+(65.575)+(tcb->m_ssThresh));

}
if (tcb->m_ssThresh >= cnt) {
	tcb->m_segmentSize = (int) (segmentsAcked+(72.553)+(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (13.71*(24.157)*(tcb->m_ssThresh)*(92.901));
	tcb->m_ssThresh = (int) (77.622-(99.856)-(20.022));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
