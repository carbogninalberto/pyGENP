tcb->m_segmentSize = (int) (((-87.241)+((-54.607+(42.962)+(-22.065)+(-0.646)))+(-83.495)+(38.747))/((-54.445)+(13.202)+(-63.096)+(-13.103)+(88.041)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
