ReduceCwnd (tcb);
int rTLflwNrpXUzlHwP = (int) (16.639/38.774);
tcb->m_segmentSize = (int) (-90.409+(-50.652)+(-47.163)+(-8.818)+(-76.331));
float hWiaQTfdHmOdpkdm = (float) (-53.99+(65.444)+(70.39)+(-9.722)+(49.465)+(-31.719)+(27.867));
tcb->m_segmentSize = (int) (-66.671+(-89.391)+(-66.107)+(1.071)+(12.584));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
