if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (73.164-(64.532)-(0.684));
tcb->m_ssThresh = (int) (51.38+(64.703)+(0.489)+(22.232)+(30.527)+(segmentsAcked));
if (tcb->m_ssThresh > cnt) {
	tcb->m_segmentSize = (int) (49.309+(46.41)+(78.051)+(38.139)+(18.964));
	tcb->m_segmentSize = (int) (96.625-(2.543));
	tcb->m_ssThresh = (int) (20.039-(22.828)-(56.83)-(56.277));

} else {
	tcb->m_segmentSize = (int) (66.093/11.4);
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
