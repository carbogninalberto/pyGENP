if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float dkzDgMLcEozLhLpf = (float) (81.856/93.552);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_ssThresh = (int) (21.629*(47.427)*(tcb->m_segmentSize));
	segmentsAcked = (int) (68.958*(5.155));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(96.74)+(50.096)+((91.186+(95.457)+(cnt)+(6.709)))+(26.307))/((0.1)));
	cnt = (int) (84.346-(dkzDgMLcEozLhLpf));

}
if (tcb->m_ssThresh <= dkzDgMLcEozLhLpf) {
	cnt = (int) (39.927/0.1);

} else {
	cnt = (int) (72.69-(81.682)-(72.163)-(7.344)-(73.441)-(79.323)-(29.458)-(98.383)-(96.136));
	tcb->m_segmentSize = (int) (63.655-(5.943)-(0.835));
	segmentsAcked = (int) (88.163+(87.948));

}
segmentsAcked = (int) (14.63*(75.753)*(7.833)*(70.904)*(33.032)*(40.767)*(38.033)*(90.974)*(87.459));
segmentsAcked = (int) (0.1/0.1);
if (dkzDgMLcEozLhLpf != cnt) {
	segmentsAcked = (int) (49.667*(83.041)*(41.545)*(67.404)*(83.692)*(80.68));
	segmentsAcked = (int) (27.202-(segmentsAcked)-(dkzDgMLcEozLhLpf)-(65.753)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(0.933)-(58.78)-(8.746));

} else {
	segmentsAcked = (int) (70.479-(tcb->m_ssThresh)-(43.997));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (28.831+(27.438)+(24.919)+(tcb->m_cWnd));

}
