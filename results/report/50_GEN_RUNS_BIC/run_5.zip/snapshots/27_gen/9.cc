tcb->m_segmentSize = (int) (tcb->m_cWnd*(26.039)*(segmentsAcked)*(22.6)*(tcb->m_ssThresh)*(87.951)*(46.246)*(7.14));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (0.1/0.1);
tcb->m_ssThresh = (int) (87.216+(14.636)+(83.648)+(26.115)+(48.489)+(62.796)+(cnt)+(24.176)+(86.872));
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (19.06*(segmentsAcked)*(36.655)*(39.637)*(51.725));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(7.847));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(49.825)+(0.1)+(0.1)+(86.824))/((0.1)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (66.179+(98.769)+(85.617)+(4.076)+(tcb->m_ssThresh)+(20.529)+(42.074)+(segmentsAcked));
