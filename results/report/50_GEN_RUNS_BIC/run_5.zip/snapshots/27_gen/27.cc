if (tcb->m_cWnd < tcb->m_cWnd) {
	cnt = (int) (70.501*(45.967)*(80.476)*(6.601));

} else {
	cnt = (int) (36.504*(66.042));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (30.731-(tcb->m_segmentSize)-(segmentsAcked)-(55.992)-(58.183)-(6.014));
	tcb->m_ssThresh = (int) ((95.143+(82.13)+(segmentsAcked)+(58.972))/0.1);

} else {
	tcb->m_segmentSize = (int) (85.882+(9.012)+(97.559)+(32.789)+(89.632)+(tcb->m_segmentSize));

}
tcb->m_ssThresh = (int) (22.549/54.494);
if (cnt < cnt) {
	tcb->m_cWnd = (int) (((94.295)+(72.361)+(0.1)+(0.1))/((65.013)));
	tcb->m_segmentSize = (int) (65.37*(88.84)*(72.377));
	segmentsAcked = (int) (segmentsAcked*(75.162)*(94.403));

} else {
	tcb->m_cWnd = (int) (90.405*(52.891)*(97.125)*(segmentsAcked)*(89.757)*(49.832)*(65.864));
	segmentsAcked = (int) (((68.484)+((76.053-(20.341)-(50.372)-(6.27)-(cnt)))+(21.521)+(0.1))/((79.348)+(97.483)+(0.1)+(77.672)));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	segmentsAcked = (int) (98.756-(tcb->m_cWnd)-(tcb->m_segmentSize)-(92.228)-(66.823)-(60.276));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(58.988)+(77.438)+(90.281)+(16.832)+(78.445)+(54.515)+(81.236)+(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
