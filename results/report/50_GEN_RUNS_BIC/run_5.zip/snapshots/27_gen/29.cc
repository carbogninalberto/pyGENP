if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (73.834*(22.517)*(tcb->m_segmentSize)*(21.949)*(87.666));

} else {
	tcb->m_segmentSize = (int) ((((38.114+(54.395)+(28.973)+(44.913)+(cnt)))+(0.1)+(0.1)+(79.973))/((0.1)+(0.1)));
	tcb->m_ssThresh = (int) (37.003-(97.162)-(7.861)-(62.552)-(20.473));
	segmentsAcked = (int) (9.28+(28.595)+(79.157));

}
float LLhOzbvEPMgaOyJH = (float) (39.726-(36.759));
if (tcb->m_ssThresh < cnt) {
	cnt = (int) (cnt-(57.846)-(5.81)-(31.206)-(tcb->m_ssThresh)-(73.808)-(segmentsAcked));

} else {
	cnt = (int) (0.1/75.988);
	cnt = (int) (9.461/35.126);
	tcb->m_ssThresh = (int) (78.877-(46.527)-(77.327)-(5.273)-(73.9)-(17.341)-(89.334));

}
tcb->m_ssThresh = (int) (75.005*(25.807));
tcb->m_ssThresh = (int) (LLhOzbvEPMgaOyJH+(72.262)+(16.273)+(21.557)+(59.975)+(39.403)+(tcb->m_cWnd)+(60.963)+(1.155));
if (segmentsAcked != segmentsAcked) {
	segmentsAcked = (int) (48.088+(46.136)+(cnt)+(52.338)+(segmentsAcked)+(17.246)+(tcb->m_ssThresh)+(28.455));

} else {
	segmentsAcked = (int) (96.178*(65.659)*(tcb->m_cWnd));

}
