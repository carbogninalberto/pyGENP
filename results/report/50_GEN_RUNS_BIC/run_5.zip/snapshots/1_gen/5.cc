float RnToTmHOpGSGzDXk = (float) ((((1.651*(13.308)*(16.309)))+((60.213*(74.502)))+(0.1)+(45.028))/((94.739)+(0.1)+(50.9)+(4.916)));
float cTGvDmXUsMFheSuu = (float) (0.1/0.1);
if (tcb->m_segmentSize > cnt) {
	RnToTmHOpGSGzDXk = (float) (63.123/0.1);
	tcb->m_segmentSize = (int) (88.353-(51.019)-(33.237)-(86.367));

} else {
	RnToTmHOpGSGzDXk = (float) (89.174+(31.351)+(21.472)+(36.997)+(15.054));
	cTGvDmXUsMFheSuu = (float) (0.1/94.063);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (RnToTmHOpGSGzDXk > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (98.702+(34.369)+(42.164)+(10.773)+(93.561)+(5.652)+(segmentsAcked)+(11.141)+(segmentsAcked));
	tcb->m_ssThresh = (int) (((0.1)+((89.236*(71.159)*(37.138)*(segmentsAcked)*(62.299)))+(21.732)+(0.1))/((85.579)+(0.1)+(76.737)));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked-(57.601)-(66.841)-(52.522)-(cnt)-(34.937));
	RnToTmHOpGSGzDXk = (float) (47.576-(RnToTmHOpGSGzDXk)-(61.813)-(cTGvDmXUsMFheSuu)-(24.89)-(48.151));
	cTGvDmXUsMFheSuu = (float) (48.174-(42.354)-(26.779)-(64.857)-(9.304)-(91.941)-(42.084));

}
cTGvDmXUsMFheSuu = (float) (RnToTmHOpGSGzDXk+(17.057)+(3.164)+(67.08));
ReduceCwnd (tcb);
