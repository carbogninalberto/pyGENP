ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (71.751+(5.436)+(34.222)+(24.138)+(37.241));
tcb->m_segmentSize = (int) (24.894+(20.684)+(61.787)+(44.652)+(32.379)+(36.187)+(90.276)+(63.078)+(42.492));
if (cnt <= tcb->m_ssThresh) {
	segmentsAcked = (int) (36.742*(24.1)*(1.6)*(79.628)*(19.482)*(tcb->m_segmentSize)*(23.918)*(60.166)*(86.917));

} else {
	segmentsAcked = (int) (48.565+(55.942)+(0.948)+(74.15)+(42.379));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (39.446*(26.888)*(71.65)*(43.964));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (segmentsAcked+(22.34)+(53.705)+(14.403)+(75.251)+(8.572));

} else {
	tcb->m_segmentSize = (int) (50.06+(75.176)+(76.797)+(4.883)+(21.281)+(47.189)+(3.853)+(82.312)+(90.927));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(2.145)+(68.128));

}
