ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
int ZSmYjzaqRDsEWlgy = (int) (42.885-(tcb->m_cWnd));
float rqxGXTLGghabESvs = (float) ((77.349+(tcb->m_ssThresh)+(64.492)+(4.842)+(30.742)+(60.826)+(ZSmYjzaqRDsEWlgy))/0.1);
int fPDTnZdtXUGVbqwX = (int) (cnt*(62.886)*(60.396)*(15.771));
ZSmYjzaqRDsEWlgy = (int) (66.868+(84.21)+(ZSmYjzaqRDsEWlgy)+(36.794)+(86.983)+(cnt));
