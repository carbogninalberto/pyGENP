if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (60.089-(42.191)-(segmentsAcked)-(cnt)-(47.456)-(75.27)-(43.87));
int JHgEdRmDngdrmTfa = (int) (9.749*(1.81));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (tcb->m_ssThresh-(42.245)-(25.758)-(94.847)-(14.198)-(29.399)-(61.652)-(6.976)-(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
