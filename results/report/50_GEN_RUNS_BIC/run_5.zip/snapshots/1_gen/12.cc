ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int lDOnfIpGcbkPXQGs = (int) (97.746*(52.205)*(89.899));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((0.1)+(20.357)+((tcb->m_segmentSize*(51.272)*(49.114)*(78.014)*(76.427)))+(13.834)+(49.058)+(41.74))/((59.717)+(0.1)+(67.333)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (24.676+(segmentsAcked)+(48.964)+(57.293)+(84.99)+(cnt)+(95.647));
	lDOnfIpGcbkPXQGs = (int) (14.282/0.1);

} else {
	tcb->m_segmentSize = (int) (94.312+(42.485));
	cnt = (int) (16.954*(28.609)*(90.999)*(65.187));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
