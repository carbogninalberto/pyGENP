segmentsAcked = (int) (segmentsAcked*(36.433)*(50.036)*(45.868)*(99.594)*(65.162)*(76.321)*(59.221));
segmentsAcked = (int) (cnt+(87.404)+(42.864)+(tcb->m_segmentSize)+(94.305)+(56.406)+(63.087)+(83.176)+(tcb->m_segmentSize));
int ISmUIJtyPIpVNHTP = (int) (48.004-(3.746)-(48.09)-(85.017)-(tcb->m_ssThresh)-(66.292));
ISmUIJtyPIpVNHTP = (int) (59.293/40.248);
segmentsAcked = (int) (26.696*(26.339)*(23.178));
