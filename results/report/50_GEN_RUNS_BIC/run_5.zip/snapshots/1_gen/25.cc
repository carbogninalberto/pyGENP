float WSOlcogiXneHxWvo = (float) (0.1/72.743);
int NuzxPdyEmMoJmroa = (int) (65.728-(78.576)-(82.865)-(37.288)-(segmentsAcked)-(18.522)-(tcb->m_ssThresh));
if (segmentsAcked >= WSOlcogiXneHxWvo) {
	tcb->m_cWnd = (int) (53.877+(26.902)+(WSOlcogiXneHxWvo));
	tcb->m_ssThresh = (int) (26.089-(53.346));
	tcb->m_ssThresh = (int) (86.912+(67.376)+(65.693)+(77.966)+(44.441)+(95.89)+(76.85)+(tcb->m_ssThresh)+(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (48.122-(35.5)-(39.743)-(31.396)-(83.756)-(32.936)-(60.946)-(58.876));

}
if (NuzxPdyEmMoJmroa <= tcb->m_segmentSize) {
	segmentsAcked = (int) (23.871*(29.102)*(18.281));
	NuzxPdyEmMoJmroa = (int) (17.895/78.136);
	tcb->m_cWnd = (int) (15.884-(34.405)-(68.089)-(44.184)-(82.268)-(WSOlcogiXneHxWvo)-(33.631)-(48.581)-(49.048));

} else {
	segmentsAcked = (int) (cnt+(tcb->m_segmentSize)+(11.129)+(43.603));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (0.827+(34.184)+(WSOlcogiXneHxWvo)+(32.498)+(53.971)+(93.589));

}
WSOlcogiXneHxWvo = (float) (36.685-(tcb->m_segmentSize)-(61.05)-(7.011)-(tcb->m_ssThresh)-(60.383));
