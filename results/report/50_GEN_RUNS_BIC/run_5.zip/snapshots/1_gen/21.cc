if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_cWnd = (int) (cnt-(15.245)-(31.914)-(tcb->m_ssThresh)-(91.304)-(26.72));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (cnt+(48.948)+(45.604)+(93.593));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	segmentsAcked = (int) ((22.717-(segmentsAcked)-(75.587)-(91.828)-(40.147)-(59.582)-(27.096))/0.1);

} else {
	segmentsAcked = (int) (26.741-(99.228)-(27.731)-(77.36)-(13.247)-(65.087)-(69.76)-(38.794));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) ((tcb->m_segmentSize*(30.749)*(tcb->m_cWnd)*(61.448)*(tcb->m_cWnd))/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
