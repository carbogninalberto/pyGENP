ReduceCwnd (tcb);
if (cnt == cnt) {
	tcb->m_cWnd = (int) (segmentsAcked+(42.618)+(61.417)+(82.807)+(76.596)+(13.112));
	cnt = (int) (85.302*(48.949));
	cnt = (int) (52.485*(55.073)*(56.724)*(79.927)*(3.326)*(segmentsAcked)*(83.727)*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) ((((19.813+(15.471)+(27.034)+(31.873)+(18.083)))+((segmentsAcked-(25.259)-(4.537)-(53.836)-(75.205)-(8.634)))+(0.1)+(35.927))/((52.574)+(0.1)+(47.764)+(0.1)+(5.708)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	cnt = (int) (4.48*(70.65)*(14.618)*(tcb->m_segmentSize));
	segmentsAcked = (int) (tcb->m_cWnd*(54.549)*(75.242)*(30.494)*(86.504)*(tcb->m_cWnd)*(35.197)*(3.073));
	segmentsAcked = (int) (54.825-(92.744)-(83.574)-(tcb->m_ssThresh)-(67.794)-(cnt)-(tcb->m_cWnd));

} else {
	cnt = (int) (83.767*(73.655)*(38.922)*(93.814)*(60.8)*(tcb->m_segmentSize)*(89.575)*(21.378)*(tcb->m_segmentSize));
	segmentsAcked = (int) (7.848+(31.854)+(40.696)+(28.451)+(47.375)+(64.714)+(95.727));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (39.757*(53.192)*(52.515));
	tcb->m_cWnd = (int) (20.281*(0.544)*(13.898)*(77.762)*(61.924));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(tcb->m_segmentSize)-(3.825)-(17.796)-(tcb->m_ssThresh)-(24.891)-(43.571));

}
