if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(76.582)+(5.326)+(79.368)+(cnt)+(18.136)+(24.085)+(6.297)+(97.37));

} else {
	tcb->m_ssThresh = (int) (14.802-(75.405)-(80.599)-(73.126));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > cnt) {
	tcb->m_cWnd = (int) (87.328/62.239);
	tcb->m_ssThresh = (int) (24.457/0.1);
	tcb->m_segmentSize = (int) (92.047+(66.309)+(8.562)+(tcb->m_cWnd)+(80.522)+(78.912));

} else {
	tcb->m_cWnd = (int) (38.626-(18.13)-(54.133)-(45.064)-(segmentsAcked));
	segmentsAcked = (int) (15.197-(4.932)-(24.209)-(84.839)-(cnt)-(95.059)-(73.851));

}
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (81.569/98.366);

} else {
	tcb->m_cWnd = (int) (41.898*(44.29)*(43.759));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(tcb->m_segmentSize)-(29.972)-(34.861)-(82.027));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (segmentsAcked*(44.341)*(60.176));
	tcb->m_segmentSize = (int) (68.878/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (68.708+(tcb->m_segmentSize)+(segmentsAcked)+(35.93)+(88.057)+(72.668)+(83.083)+(23.871));

}
