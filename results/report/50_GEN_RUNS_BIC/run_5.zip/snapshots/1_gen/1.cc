if (cnt == segmentsAcked) {
	tcb->m_ssThresh = (int) (((61.403)+(62.039)+(33.589)+(11.592)+(0.1)+(60.944))/((0.1)+(11.615)));
	tcb->m_cWnd = (int) (42.179-(segmentsAcked)-(26.157)-(39.962)-(4.923)-(26.903)-(33.441));
	segmentsAcked = (int) (tcb->m_ssThresh+(68.07)+(68.172));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked+(83.656)+(76.53)+(51.655)+(74.993)+(34.251)+(69.999)+(57.795)+(79.509));
	tcb->m_cWnd = (int) (61.845-(41.104));

}
tcb->m_segmentSize = (int) (((5.05)+((71.926*(67.344)*(0.276)*(57.34)))+(0.1)+(0.1)+(93.222)+((17.434-(tcb->m_cWnd)-(cnt)-(34.761)-(72.983)-(86.962)-(45.739)-(segmentsAcked)))+(0.1))/((92.482)+(70.223)));
if (segmentsAcked >= cnt) {
	segmentsAcked = (int) (segmentsAcked*(37.597)*(59.299)*(13.995));

} else {
	segmentsAcked = (int) (87.478/16.916);
	tcb->m_segmentSize = (int) (segmentsAcked-(52.195)-(tcb->m_cWnd)-(11.962)-(tcb->m_cWnd)-(19.372)-(69.887)-(54.016));

}
tcb->m_cWnd = (int) (85.973-(tcb->m_cWnd)-(54.68)-(26.949)-(58.692)-(55.454));
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (1.255-(31.556)-(37.613)-(71.778)-(28.516)-(41.82));
	segmentsAcked = (int) (27.107-(60.866)-(tcb->m_cWnd)-(2.184)-(59.612)-(62.935)-(54.026)-(8.647)-(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (50.988*(44.403)*(tcb->m_cWnd)*(76.974)*(71.935)*(28.552)*(38.205)*(9.832));
	cnt = (int) (tcb->m_ssThresh+(12.144)+(93.231)+(81.195)+(68.48));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (23.09-(32.874));
if (cnt > segmentsAcked) {
	segmentsAcked = (int) (58.397-(35.183));

} else {
	segmentsAcked = (int) (34.918+(tcb->m_segmentSize));

}
