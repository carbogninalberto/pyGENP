if (cnt >= tcb->m_cWnd) {
	segmentsAcked = (int) (67.757/0.1);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (29.748+(83.687)+(segmentsAcked));
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (16.206*(63.3)*(cnt)*(98.905)*(82.17)*(79.827));

}
int qPGYJnAIWbyABfpq = (int) (82.632-(30.35));
tcb->m_cWnd = (int) (segmentsAcked-(qPGYJnAIWbyABfpq)-(37.531)-(69.122)-(18.22)-(91.228)-(76.791));
float iXNCPoqZjHDwOart = (float) (95.607-(28.494)-(7.701)-(segmentsAcked)-(32.897)-(52.454));
ReduceCwnd (tcb);
if (segmentsAcked == iXNCPoqZjHDwOart) {
	iXNCPoqZjHDwOart = (float) (24.134*(77.268)*(83.644));

} else {
	iXNCPoqZjHDwOart = (float) (65.135+(90.99)+(qPGYJnAIWbyABfpq)+(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (80.538+(qPGYJnAIWbyABfpq)+(29.919)+(segmentsAcked)+(84.652)+(29.718));

}
float vbJyijtbUXKSYeLI = (float) (93.503-(46.047));
if (vbJyijtbUXKSYeLI <= cnt) {
	vbJyijtbUXKSYeLI = (float) (0.1/(tcb->m_cWnd+(86.757)+(98.713)+(segmentsAcked)+(78.39)));
	ReduceCwnd (tcb);

} else {
	vbJyijtbUXKSYeLI = (float) (8.41-(49.361));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (92.323/88.342);

}
