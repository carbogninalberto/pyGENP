int HuXkVRvPdXVyfQMw = (int) (93.813-(20.719)-(92.458)-(84.603));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (tcb->m_segmentSize+(88.394)+(63.707)+(76.657)+(44.734)+(29.058)+(10.982));
ReduceCwnd (tcb);
int DRmjDjskUrbCVkKB = (int) (cnt*(49.2)*(tcb->m_cWnd)*(31.845)*(HuXkVRvPdXVyfQMw)*(39.781)*(tcb->m_segmentSize));
