if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (46.91-(0.228)-(segmentsAcked)-(67.199)-(17.05)-(32.844)-(47.105)-(22.44)-(21.458));
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (43.514*(67.458)*(15.449)*(65.19)*(53.007)*(65.88)*(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (0.1/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (2.051+(61.068)+(61.118)+(8.769)+(99.805)+(95.77)+(34.549)+(71.044)+(21.636));
tcb->m_ssThresh = (int) ((85.362-(64.918)-(24.512)-(cnt))/(45.041-(6.627)-(60.443)-(57.274)-(2.369)-(40.439)-(21.58)-(94.169)-(32.072)));
ReduceCwnd (tcb);
if (tcb->m_ssThresh != cnt) {
	segmentsAcked = (int) (29.447+(15.5)+(32.968)+(segmentsAcked)+(8.89)+(24.983)+(39.349)+(58.757));

} else {
	segmentsAcked = (int) (80.251-(85.014)-(46.869)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(71.544)-(29.536)-(35.64)-(8.024));
	cnt = (int) (((0.1)+(0.1)+((tcb->m_segmentSize+(19.683)+(42.892)+(1.003)+(83.546)+(57.178)+(96.385)+(93.934)))+(82.256))/((0.1)+(0.1)+(0.1)));

}
tcb->m_ssThresh = (int) (34.543-(62.266)-(83.976));
int jgENeQoCRCypazaO = (int) (tcb->m_ssThresh+(11.303)+(17.772)+(tcb->m_segmentSize)+(segmentsAcked)+(5.27)+(87.423)+(77.663));
