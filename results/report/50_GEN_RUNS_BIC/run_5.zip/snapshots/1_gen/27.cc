ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
cnt = (int) (95.09/23.196);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_segmentSize = (int) (14.15+(64.007)+(segmentsAcked));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (17.375-(tcb->m_segmentSize)-(40.438)-(76.223)-(3.744));

}
