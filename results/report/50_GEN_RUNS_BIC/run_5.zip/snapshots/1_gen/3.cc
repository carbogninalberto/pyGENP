tcb->m_ssThresh = (int) (tcb->m_cWnd+(cnt)+(65.143));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_segmentSize != cnt) {
	cnt = (int) (10.053/0.1);

} else {
	cnt = (int) (51.942/20.862);

}
tcb->m_cWnd = (int) (50.219+(43.521)+(81.91));
