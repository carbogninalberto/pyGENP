tcb->m_ssThresh = (int) (65.619*(87.29)*(85.392)*(29.521));
tcb->m_ssThresh = (int) (18.482/0.1);
tcb->m_cWnd = (int) (64.055+(70.328)+(14.969)+(16.322)+(33.856)+(segmentsAcked)+(8.276)+(34.805));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
