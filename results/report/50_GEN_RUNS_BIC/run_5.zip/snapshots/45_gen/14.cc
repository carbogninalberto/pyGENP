ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) ((11.927-(tcb->m_segmentSize)-(64.777)-(70.354)-(32.543)-(cnt)-(63.838)-(57.089)-(19.842))/55.098);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (46.005*(tcb->m_segmentSize)*(10.728));
	tcb->m_segmentSize = (int) (((0.1)+((49.917-(tcb->m_ssThresh)-(22.154)-(segmentsAcked)-(33.794)-(54.784)))+(0.1)+(12.641))/((57.574)+(0.1)+(0.1)+(77.92)));

}
segmentsAcked = (int) (60.931+(71.926)+(cnt)+(53.657)+(68.933)+(tcb->m_cWnd)+(78.539));
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (7.08*(5.676)*(12.507)*(66.957)*(26.836)*(57.237)*(segmentsAcked)*(54.352)*(45.321));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (((65.033)+((segmentsAcked+(31.084)+(tcb->m_ssThresh)+(54.754)))+((27.346+(4.191)+(48.655)+(38.256)+(71.695)+(33.656)+(93.585)))+(2.736))/((31.873)+(0.1)+(0.1)+(0.1)+(31.889)));

}
int llhBQZlChycNnyiV = (int) (21.111*(85.018)*(76.984));
if (llhBQZlChycNnyiV != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(99.781)+((57.342*(18.849)*(57.254)))+(72.17))/((0.1)+(64.378)));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (80.456*(35.841)*(88.547)*(cnt)*(52.142)*(cnt)*(41.174)*(30.618));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
