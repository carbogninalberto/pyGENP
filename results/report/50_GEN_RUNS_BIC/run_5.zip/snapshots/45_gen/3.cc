tcb->m_cWnd = (int) (-64.39*(97.578)*(36.415)*(71.448)*(-41.636)*(25.369)*(-30.197)*(-24.303));
tcb->m_cWnd = (int) (23.449*(-75.81)*(93.5)*(37.602)*(-55.247)*(56.999)*(-84.788)*(72.528));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
