ReduceCwnd (tcb);
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	cnt = (int) (15.116-(53.423)-(95.414)-(8.41)-(29.469)-(segmentsAcked)-(12.178)-(3.698)-(tcb->m_ssThresh));

} else {
	cnt = (int) (0.966+(9.666)+(tcb->m_segmentSize)+(53.917)+(tcb->m_ssThresh)+(61.378)+(tcb->m_segmentSize)+(99.874)+(cnt));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (59.029-(45.706)-(tcb->m_segmentSize));
float kueATmWpPFsesXVV = (float) (0.1/0.1);
