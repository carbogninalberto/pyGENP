ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (segmentsAcked > tcb->m_segmentSize) {
	segmentsAcked = (int) (((0.1)+((75.308*(cnt)))+(0.1)+(44.183))/((21.312)+(66.695)));
	tcb->m_cWnd = (int) (-70.52+(tcb->m_cWnd)+(16.514)+(71.407)+(7.717)+(76.092));

} else {
	segmentsAcked = (int) (19.458-(48.246)-(70.495)-(40.545)-(-71.62)-(39.14)-(86.244)-(60.333)-(60.186));
	segmentsAcked = (int) (-37.117+(25.809)+(segmentsAcked)+(segmentsAcked)+(77.698)+(27.947)+(49.91));

}
if (segmentsAcked < segmentsAcked) {
	segmentsAcked = (int) (85.767*(38.186)*(68.917)*(51.195)*(92.849)*(-63.649));
	tcb->m_cWnd = (int) (((24.097)+(55.358)+(62.538)+(0.1))/((71.525)+(0.1)));

} else {
	segmentsAcked = (int) (85.802-(87.446)-(90.946)-(59.065)-(segmentsAcked));
	tcb->m_segmentSize = (int) (81.776+(tcb->m_segmentSize)+(56.063)+(31.208)+(segmentsAcked)+(88.946)+(25.404)+(tcb->m_segmentSize)+(92.791));

}
