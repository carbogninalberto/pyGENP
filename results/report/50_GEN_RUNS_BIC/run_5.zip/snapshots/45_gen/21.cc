tcb->m_segmentSize = (int) (61.131/26.851);
segmentsAcked = (int) ((cnt-(77.808)-(17.812)-(tcb->m_cWnd)-(4.928)-(18.119)-(34.191)-(31.604))/49.846);
float qqfqhgGtwjOzBkym = (float) (39.021*(tcb->m_cWnd)*(40.56));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
