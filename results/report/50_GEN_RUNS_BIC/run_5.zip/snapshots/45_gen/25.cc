tcb->m_cWnd = (int) (tcb->m_cWnd+(77.563)+(57.741)+(76.938)+(4.545)+(17.19)+(34.848)+(4.899));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (((0.1)+(17.243)+(18.414)+(0.1)+(0.1)+(59.344))/((28.139)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (35.938-(54.733)-(90.189)-(52.197)-(54.339)-(87.47)-(cnt)-(33.423)-(cnt));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (42.821*(97.217)*(4.335));

}
if (tcb->m_segmentSize > segmentsAcked) {
	cnt = (int) (62.301*(87.304)*(31.096)*(3.479)*(40.502));
	tcb->m_ssThresh = (int) (30.245-(74.285)-(19.476)-(13.045)-(68.049));

} else {
	cnt = (int) (cnt+(cnt)+(75.201)+(33.513)+(cnt)+(63.268)+(21.721)+(66.351)+(1.487));
	cnt = (int) (11.317-(40.578)-(67.867)-(segmentsAcked)-(51.144)-(segmentsAcked)-(1.635)-(36.043)-(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
