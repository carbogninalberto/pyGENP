int eAktgyAlIzXdjphO = (int) (((29.602)+(7.289)+(0.1)+(25.439)+(41.991))/((0.1)));
tcb->m_segmentSize = (int) (32.054+(82.481));
cnt = (int) ((tcb->m_segmentSize-(43.675)-(14.688)-(68.716)-(segmentsAcked)-(22.447)-(50.223)-(segmentsAcked)-(77.744))/26.077);
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_ssThresh = (int) (73.179*(32.628)*(52.721)*(35.932)*(tcb->m_cWnd));
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(tcb->m_cWnd)+(69.192)+(segmentsAcked)+(19.746)+(66.324)+(66.904)+(24.341));
	eAktgyAlIzXdjphO = (int) (40.275-(24.798)-(71.086)-(19.249)-(74.055)-(24.518)-(93.623));

} else {
	tcb->m_ssThresh = (int) (35.788-(4.084));
	tcb->m_segmentSize = (int) (80.897+(85.412)+(77.862)+(3.505)+(16.601)+(44.226)+(25.893));
	segmentsAcked = (int) (94.222-(16.417)-(tcb->m_ssThresh)-(18.607));

}
ReduceCwnd (tcb);
if (cnt < cnt) {
	cnt = (int) ((((53.994*(cnt)*(86.553)))+(0.1)+(40.175)+(0.1))/((6.78)));
	tcb->m_cWnd = (int) (61.617+(59.286)+(eAktgyAlIzXdjphO)+(3.55));

} else {
	cnt = (int) (48.435*(14.098)*(cnt)*(89.068)*(79.609)*(27.929)*(94.782));
	ReduceCwnd (tcb);

}
int yDrMdYcKMLyDrVww = (int) (tcb->m_segmentSize+(0.492)+(36.633)+(51.899)+(84.319)+(35.463)+(35.327)+(tcb->m_segmentSize)+(60.065));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
