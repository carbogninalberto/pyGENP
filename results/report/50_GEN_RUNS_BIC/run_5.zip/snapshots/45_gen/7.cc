if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-6.0-(83.494)-(-32.397)-(97.248)-(83.724)-(8.156)-(83.585)-(-31.851)-(-47.701));
