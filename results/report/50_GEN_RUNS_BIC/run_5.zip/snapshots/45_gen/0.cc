float JjknBaQPOFuoqmnx = (float) (80.811+(-7.599)+(-6.21));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (41.437*(43.459)*(30.954));
