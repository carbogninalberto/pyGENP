int hsbcXxcUaELsBHIt = (int) (-36.741*(14.545)*(14.284));
tcb->m_cWnd = (int) (((-48.573)+((tcb->m_segmentSize+(-62.445)+(-67.904)))+(-12.695)+(-18.435))/((-5.848)+(74.353)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
