float iMnLAXLyGHeSmHkO = (float) (((76.767)+((39.334*(68.748)*(37.059)*(segmentsAcked)*(85.267)))+(88.954)+(72.552)+(0.1)+(98.05))/((0.1)+(0.1)));
ReduceCwnd (tcb);
float xddMeyayRsNCpzES = (float) (((0.1)+(4.006)+((tcb->m_cWnd+(73.778)+(66.413)+(95.389)+(9.444)+(61.853)+(34.17)))+(0.1))/((0.1)+(0.1)+(68.11)+(9.166)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (iMnLAXLyGHeSmHkO+(31.922)+(52.249)+(tcb->m_ssThresh)+(68.782));
	tcb->m_segmentSize = (int) (60.157*(94.768)*(40.151)*(iMnLAXLyGHeSmHkO)*(1.837)*(85.038)*(49.816));

} else {
	tcb->m_cWnd = (int) (97.438+(4.068)+(44.333)+(66.646)+(24.951)+(38.83));
	tcb->m_ssThresh = (int) (10.84-(90.302)-(43.41)-(30.073)-(11.506));

}
