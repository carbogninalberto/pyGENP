int ZJLIxENLPmNJdXjH = (int) (9.556+(82.581));
segmentsAcked = (int) (21.866/17.796);
if (tcb->m_cWnd == segmentsAcked) {
	cnt = (int) (tcb->m_ssThresh-(85.056)-(63.282)-(34.328)-(71.731));
	tcb->m_cWnd = (int) (cnt+(tcb->m_segmentSize));

} else {
	cnt = (int) (7.588-(77.479)-(53.101));
	segmentsAcked = (int) (26.613+(9.411)+(tcb->m_ssThresh)+(segmentsAcked)+(4.476)+(tcb->m_ssThresh)+(67.925)+(75.386));

}
cnt = (int) (70.92*(segmentsAcked)*(96.33)*(tcb->m_cWnd)*(42.479)*(ZJLIxENLPmNJdXjH)*(20.444));
ReduceCwnd (tcb);
