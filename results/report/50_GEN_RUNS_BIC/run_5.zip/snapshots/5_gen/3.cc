tcb->m_segmentSize = (int) (((-4.137)+((-2.578*(-84.406)*(14.38)*(62.84)))+(1.782)+(94.01)+(-99.861)+((63.158-(tcb->m_cWnd)-(cnt)-(-41.805)-(-14.639)-(19.59)-(69.076)-(segmentsAcked)))+(41.863))/((15.318)+(-7.384)));
tcb->m_cWnd = (int) (-56.754-(-57.338)-(-15.813)-(23.745)-(37.194)-(-55.842));
tcb->m_segmentSize = (int) (((-26.823)+((-98.266*(-52.135)*(1.497)*(-96.746)))+(-71.369)+(-18.497)+(44.314)+((-82.197-(tcb->m_cWnd)-(cnt)-(26.497)-(29.969)-(70.343)-(44.842)-(segmentsAcked)))+(77.685))/((-55.434)+(-45.817)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-56.689-(-56.673)-(6.855)-(48.104)-(1.773)-(-46.845));
tcb->m_cWnd = (int) (-88.018-(-56.369)-(-13.743)-(-99.798)-(78.771)-(-63.6));
tcb->m_segmentSize = (int) (-81.903-(-71.935));
tcb->m_segmentSize = (int) (((44.421)+((-21.798*(95.891)*(-5.893)*(20.729)))+(-55.529)+(87.373)+(0.905)+((-51.12-(tcb->m_cWnd)-(cnt)-(-15.928)-(-88.454)-(77.698)-(23.44)-(segmentsAcked)))+(-21.223))/((94.321)+(25.052)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-48.628-(45.403));
tcb->m_cWnd = (int) (-64.989-(81.526)-(-14.274)-(-88.319)-(9.962)-(-13.695));
tcb->m_segmentSize = (int) (-92.445-(-89.693));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (96.819-(30.451));
