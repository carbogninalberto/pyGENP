int PXcMPzGDdzDRaqas = (int) (31.215*(-49.741)*(32.567)*(-48.533)*(-98.787)*(68.584)*(2.788)*(63.74));
tcb->m_cWnd = (int) (-0.186*(-50.197)*(0.195)*(13.967)*(-98.834));
segmentsAcked = (int) (0.574/26.517);
tcb->m_cWnd = (int) (-26.216/(cnt*(16.577)*(34.465)*(46.455)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
