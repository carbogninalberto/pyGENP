tcb->m_segmentSize = (int) (-7.045*(65.005)*(80.941)*(-30.766)*(-62.463)*(-99.986)*(26.681)*(-58.642));
segmentsAcked = (int) (-35.255*(91.263)*(-21.878)*(39.938)*(-14.295));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
