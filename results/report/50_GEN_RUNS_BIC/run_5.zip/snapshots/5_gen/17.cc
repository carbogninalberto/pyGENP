float gcKlzTmowCEyfLLi = (float) (-79.555-(-19.199)-(-73.886));
int HwnZBFIptgpnRMze = (int) (31.079*(-39.876)*(36.771));
float ndNiFwRMZeJutmSY = (float) (26.245-(-34.277));
ReduceCwnd (tcb);
