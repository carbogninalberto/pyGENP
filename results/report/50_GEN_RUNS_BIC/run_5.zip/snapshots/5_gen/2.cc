tcb->m_segmentSize = (int) (((-72.176)+((54.962*(54.421)*(45.557)*(-15.476)))+(60.234)+(-54.964)+(-28.588)+((-31.085-(tcb->m_cWnd)-(cnt)-(-63.905)-(-17.994)-(-24.543)-(-41.471)-(segmentsAcked)))+(51.446))/((-26.158)+(-97.576)));
tcb->m_cWnd = (int) (-30.801-(-5.375)-(-94.776)-(69.498)-(59.399)-(-14.346));
tcb->m_segmentSize = (int) (((-4.206)+((-15.101*(29.672)*(77.058)*(-97.501)))+(-6.962)+(20.635)+(6.175)+((-48.911-(tcb->m_cWnd)-(cnt)-(64.746)-(-26.726)-(-59.89)-(-69.664)-(segmentsAcked)))+(-16.48))/((-56.384)+(-4.49)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-83.053-(-66.933)-(-52.616)-(-44.691)-(-66.235)-(1.332));
tcb->m_segmentSize = (int) (66.332-(-57.335));
tcb->m_segmentSize = (int) (37.893-(1.768));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (88.726-(8.487));
tcb->m_segmentSize = (int) (-83.887-(97.238));
