tcb->m_segmentSize = (int) (((-88.254)+((-41.602*(-89.665)*(40.283)*(13.069)))+(28.584)+(14.909)+(51.053)+((-98.114-(tcb->m_cWnd)-(cnt)-(95.356)-(-68.929)-(20.021)-(-96.707)-(segmentsAcked)))+(92.726))/((-15.953)+(-87.11)));
tcb->m_cWnd = (int) (97.016-(-55.497)-(-30.35)-(58.384)-(-0.146)-(-77.18));
tcb->m_cWnd = (int) (22.714-(96.538)-(-12.615)-(-13.753)-(89.977)-(-22.985));
tcb->m_segmentSize = (int) (((0.727)+((4.629*(-36.974)*(-18.006)*(32.181)))+(-36.93)+(-94.514)+(14.073)+((43.506-(tcb->m_cWnd)-(cnt)-(-48.036)-(50.066)-(64.396)-(-47.887)-(segmentsAcked)))+(2.755))/((95.671)+(16.535)));
tcb->m_segmentSize = (int) (((98.576)+((84.962*(-57.003)*(-45.557)*(97.383)))+(17.09)+(26.788)+(61.837)+((67.526-(tcb->m_cWnd)-(cnt)-(-29.286)-(-80.81)-(-64.057)-(-82.223)-(segmentsAcked)))+(41.931))/((-51.763)+(-46.937)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (15.815-(63.611)-(30.051)-(69.103)-(8.343)-(-81.711));
tcb->m_cWnd = (int) (-12.105-(-57.952)-(27.568)-(-48.757)-(71.083)-(37.137));
tcb->m_segmentSize = (int) (-27.635-(-49.073));
tcb->m_segmentSize = (int) (71.755-(-4.886));
tcb->m_segmentSize = (int) (-67.053-(64.358));
tcb->m_segmentSize = (int) (-18.329-(-92.022));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (9.213-(-79.802));
tcb->m_segmentSize = (int) (-47.049-(-38.267));
tcb->m_segmentSize = (int) (-37.185-(-2.296));
tcb->m_segmentSize = (int) (16.551-(94.35));
