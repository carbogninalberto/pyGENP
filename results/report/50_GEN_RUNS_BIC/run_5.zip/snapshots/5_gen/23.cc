tcb->m_segmentSize = (int) (((-53.533)+((-88.898*(89.74)*(-85.602)*(98.07)))+(10.581)+(-56.076)+(-34.769)+((-83.774-(tcb->m_cWnd)-(cnt)-(49.887)-(55.353)-(56.605)-(-92.411)-(segmentsAcked)))+(-15.141))/((66.349)+(97.178)));
tcb->m_cWnd = (int) (79.205-(-33.384)-(28.176)-(50.278)-(22.963)-(14.885));
tcb->m_segmentSize = (int) (((62.536)+((31.733*(73.469)*(-44.449)*(-42.78)))+(72.867)+(40.398)+(60.058)+((34.432-(tcb->m_cWnd)-(cnt)-(59.701)-(33.232)-(-78.447)-(-20.968)-(segmentsAcked)))+(-33.406))/((-95.463)+(-58.397)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-4.171-(-49.436)-(-56.803)-(-33.164)-(-9.765)-(81.337));
tcb->m_segmentSize = (int) (-49.68-(-8.046));
tcb->m_segmentSize = (int) (4.205-(4.708));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (17.977-(45.902));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-94.524-(4.032));
tcb->m_segmentSize = (int) (26.649-(-74.654));
tcb->m_segmentSize = (int) (96.789-(-75.385));
