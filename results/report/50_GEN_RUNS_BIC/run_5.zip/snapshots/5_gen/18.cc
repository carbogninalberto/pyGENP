tcb->m_segmentSize = (int) (((-60.701)+((-65.362*(-28.478)*(-74.008)*(-32.648)))+(-52.606)+(9.348)+(-20.511)+((57.787-(tcb->m_cWnd)-(cnt)-(57.224)-(-76.816)-(-83.537)-(4.239)-(segmentsAcked)))+(-60.627))/((20.736)+(0.124)));
tcb->m_cWnd = (int) (-54.902-(-51.084)-(-39.292)-(-68.011)-(-4.697)-(63.761));
tcb->m_segmentSize = (int) (((-90.439)+((-51.573*(-55.898)*(66.245)*(-64.009)))+(40.524)+(80.917)+(-14.424)+((11.815-(tcb->m_cWnd)-(cnt)-(74.961)-(97.979)-(55.03)-(-49.345)-(segmentsAcked)))+(-52.016))/((-30.862)+(25.704)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (47.639-(90.667)-(19.999)-(-11.258)-(-5.431)-(-20.081));
tcb->m_cWnd = (int) (83.3-(-27.976)-(48.047)-(-61.586)-(-88.112)-(2.842));
tcb->m_segmentSize = (int) (25.061-(20.982));
tcb->m_segmentSize = (int) (((83.319)+((23.611*(5.984)*(-69.897)*(44.65)))+(-36.328)+(44.528)+(2.133)+((-37.436-(tcb->m_cWnd)-(cnt)-(-65.495)-(40.554)-(-31.557)-(-2.98)-(segmentsAcked)))+(75.281))/((-88.91)+(92.528)));
tcb->m_cWnd = (int) (55.969-(25.16)-(-56.892)-(68.717)-(11.446)-(67.419));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-89.258-(-17.364)-(60.187)-(58.982)-(15.615)-(-16.818));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-81.127-(34.52));
tcb->m_segmentSize = (int) (90.204-(-48.466));
tcb->m_segmentSize = (int) (((28.641)+((25.032*(44.965)*(-63.181)*(-22.429)))+(32.752)+(-5.244)+(68.525)+((29.753-(tcb->m_cWnd)-(cnt)-(0.359)-(-7.783)-(-49.763)-(-30.277)-(segmentsAcked)))+(-51.583))/((-72.033)+(30.199)));
tcb->m_cWnd = (int) (-31.42-(63.812)-(-63.173)-(-99.521)-(-75.939)-(-30.152));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-18.458-(35.312));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (59.751-(-27.553));
tcb->m_segmentSize = (int) (64.18-(38.282));
tcb->m_cWnd = (int) (64.178-(82.329)-(-61.056)-(-37.416)-(-98.584)-(31.126));
tcb->m_segmentSize = (int) (80.694-(46.727));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (93.959-(12.435));
