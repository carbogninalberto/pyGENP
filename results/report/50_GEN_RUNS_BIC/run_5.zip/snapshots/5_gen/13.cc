tcb->m_segmentSize = (int) (-65.053-(-31.719)-(-30.635)-(-93.107)-(70.167)-(65.795)-(32.601));
float YzHEWkrNQdeCFvaj = (float) (60.069+(92.055)+(83.142));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
