tcb->m_segmentSize = (int) (-88.193/83.237);
