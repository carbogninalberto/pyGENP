int kUTndqECByoYAulL = (int) (87.922-(50.681)-(36.457)-(57.04));
segmentsAcked = (int) (11.568*(49.606)*(-58.712));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
