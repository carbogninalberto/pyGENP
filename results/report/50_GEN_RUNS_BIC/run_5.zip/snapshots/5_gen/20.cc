tcb->m_segmentSize = (int) (((39.042)+((91.446*(-40.33)*(99.8)*(-92.429)))+(-2.366)+(-43.43)+(-85.827)+((41.942-(tcb->m_cWnd)-(cnt)-(76.706)-(24.235)-(24.978)-(14.96)-(segmentsAcked)))+(15.357))/((-27.05)+(-87.359)));
tcb->m_cWnd = (int) (90.747-(-73.455)-(-86.997)-(9.249)-(-19.817)-(-40.087));
tcb->m_segmentSize = (int) (((78.842)+((-55.139*(-3.51)*(38.493)*(-73.96)))+(-22.192)+(-42.11)+(52.381)+((-84.855-(tcb->m_cWnd)-(cnt)-(96.241)-(-79.74)-(11.267)-(-84.809)-(segmentsAcked)))+(-6.211))/((-78.386)+(-72.271)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-0.615-(-55.062)-(-37.811)-(-58.864)-(-10.21)-(-68.146));
tcb->m_segmentSize = (int) (75.315-(63.948));
tcb->m_segmentSize = (int) (-72.605-(42.181));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-43.818-(-86.07));
tcb->m_segmentSize = (int) (30.76-(55.519));
tcb->m_segmentSize = (int) (65.449-(-59.644));
tcb->m_segmentSize = (int) (-2.485-(0.909));
