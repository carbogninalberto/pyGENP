tcb->m_segmentSize = (int) (((55.834)+(27.293)+(-94.541)+(-47.194)+(-61.762))/((39.408)+(61.462)+(-87.604)+(-60.689)));
tcb->m_segmentSize = (int) (-57.282-(-4.641)-(53.175)-(37.993)-(-39.94)-(13.758)-(-2.529));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-35.491-(28.944)-(95.504)-(8.703)-(65.84)-(22.369)-(-63.806));
