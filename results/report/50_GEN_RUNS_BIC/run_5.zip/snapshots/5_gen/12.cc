int qPGYJnAIWbyABfpq = (int) (-44.888-(-68.792));
float CSASbPxmoCqglirj = (float) (-54.26-(69.967)-(-48.643));
