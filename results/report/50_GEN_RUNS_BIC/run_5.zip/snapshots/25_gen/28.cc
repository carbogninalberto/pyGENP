int bfxOmENFeJAOOZFg = (int) (6.824*(73.713)*(46.377)*(1.794));
ReduceCwnd (tcb);
float ohrxikFMoHJhaLFF = (float) (64.977*(91.357)*(54.191)*(bfxOmENFeJAOOZFg)*(45.818)*(87.319));
ohrxikFMoHJhaLFF = (float) (28.66-(tcb->m_ssThresh)-(32.196)-(67.927)-(17.459)-(tcb->m_cWnd)-(tcb->m_segmentSize)-(tcb->m_ssThresh));
if (bfxOmENFeJAOOZFg <= segmentsAcked) {
	cnt = (int) (bfxOmENFeJAOOZFg-(6.117)-(8.531)-(6.985)-(86.641)-(9.298)-(12.014)-(79.989)-(31.981));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (40.962-(23.355)-(77.088)-(62.851)-(49.303)-(42.215)-(90.929)-(tcb->m_cWnd)-(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (86.532*(19.818)*(55.882)*(37.272)*(ohrxikFMoHJhaLFF)*(29.968)*(45.014)*(28.029));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (56.363+(tcb->m_ssThresh)+(bfxOmENFeJAOOZFg)+(10.177)+(80.375)+(ohrxikFMoHJhaLFF));
	cnt = (int) (tcb->m_cWnd-(60.306)-(29.613)-(tcb->m_ssThresh)-(50.496)-(75.431)-(3.809)-(14.881)-(18.504));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) ((18.916-(69.908))/95.397);

}
if (ohrxikFMoHJhaLFF < cnt) {
	cnt = (int) (73.75*(bfxOmENFeJAOOZFg));
	segmentsAcked = (int) (63.786+(tcb->m_cWnd)+(85.507)+(92.505)+(71.122)+(57.329)+(37.358)+(71.763)+(tcb->m_segmentSize));

} else {
	cnt = (int) (91.072*(27.357));
	tcb->m_ssThresh = (int) (52.67-(89.729)-(17.488));
	ReduceCwnd (tcb);

}
