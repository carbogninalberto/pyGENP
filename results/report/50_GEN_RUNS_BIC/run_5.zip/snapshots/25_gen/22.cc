tcb->m_ssThresh = (int) (tcb->m_ssThresh+(38.565)+(58.313)+(68.699));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	segmentsAcked = (int) (80.1+(67.12)+(24.643)+(4.92)+(40.063));
	cnt = (int) (21.266*(51.273)*(24.654)*(29.488)*(72.022));

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+(17.7)+(93.603)+(81.334))/((0.1)+(45.489)+(0.1)+(70.549)));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
