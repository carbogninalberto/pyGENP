if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (95.912*(90.372)*(24.462)*(tcb->m_segmentSize)*(cnt)*(25.347)*(46.154));

} else {
	tcb->m_cWnd = (int) (cnt+(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (0.1/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	cnt = (int) (62.085/88.519);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (22.436+(77.345)+(98.525)+(3.792)+(31.043)+(51.448)+(91.892)+(tcb->m_segmentSize)+(38.251));
	tcb->m_cWnd = (int) (4.932-(17.963)-(77.691)-(cnt)-(tcb->m_segmentSize)-(54.082)-(53.53)-(segmentsAcked)-(segmentsAcked));

}
if (segmentsAcked < segmentsAcked) {
	tcb->m_segmentSize = (int) (94.327+(84.766)+(38.922));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (60.422-(tcb->m_cWnd)-(22.302)-(cnt)-(tcb->m_ssThresh)-(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (52.681*(38.35)*(0.324)*(32.906)*(31.943));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (79.149-(51.595)-(15.213)-(39.024)-(46.496)-(cnt)-(32.865)-(85.736));
