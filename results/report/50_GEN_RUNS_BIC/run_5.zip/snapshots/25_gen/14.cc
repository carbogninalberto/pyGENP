ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (62.542/0.1);
tcb->m_ssThresh = (int) (tcb->m_ssThresh-(46.729)-(48.143)-(70.32)-(96.562)-(76.476)-(90.101));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int OVTiIIuROljYcsPa = (int) (65.692+(87.237)+(61.659)+(54.749)+(73.285)+(29.88)+(74.129));
if (OVTiIIuROljYcsPa == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (1.812+(36.227)+(segmentsAcked)+(34.79)+(84.667));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (22.305-(cnt)-(tcb->m_segmentSize)-(28.962)-(31.806)-(6.075));
	tcb->m_segmentSize = (int) (segmentsAcked+(65.778)+(68.483)+(tcb->m_cWnd));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
