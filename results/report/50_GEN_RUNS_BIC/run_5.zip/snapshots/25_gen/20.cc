if (cnt == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (59.443*(98.021)*(69.805)*(75.065)*(56.51)*(87.849)*(10.122)*(22.209));

} else {
	tcb->m_segmentSize = (int) (61.012-(87.478)-(37.339)-(53.916)-(47.174)-(segmentsAcked)-(tcb->m_ssThresh)-(53.736)-(52.929));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (51.139*(35.348)*(80.663)*(12.822)*(22.524)*(tcb->m_ssThresh)*(tcb->m_cWnd));

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	cnt = (int) (tcb->m_segmentSize*(67.173)*(28.633)*(segmentsAcked)*(6.803)*(55.083)*(tcb->m_segmentSize));

} else {
	cnt = (int) (segmentsAcked*(16.99));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.1/29.074);
	segmentsAcked = (int) (tcb->m_cWnd-(98.462)-(40.29)-(67.069)-(56.068));
	segmentsAcked = (int) (35.285-(50.359)-(4.199));

} else {
	tcb->m_segmentSize = (int) (47.388*(84.025)*(2.063)*(88.801)*(96.67)*(44.195));
	tcb->m_cWnd = (int) (26.135*(83.03)*(93.809)*(88.526)*(89.151)*(6.714));

}
tcb->m_segmentSize = (int) (((0.1)+((53.874-(26.046)-(9.384)-(64.292)))+(1.976)+(0.1))/((0.1)+(97.172)));
int IKQwFFhBBVtcRKUV = (int) (29.595*(6.907)*(81.465)*(segmentsAcked)*(62.406)*(54.343));
if (IKQwFFhBBVtcRKUV >= segmentsAcked) {
	tcb->m_segmentSize = (int) (88.393*(63.974)*(IKQwFFhBBVtcRKUV)*(71.501)*(77.315)*(48.116)*(83.816)*(93.251));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(15.6));

}
tcb->m_ssThresh = (int) (39.992-(18.13)-(14.065)-(78.118));
cnt = (int) (96.0+(1.522)+(tcb->m_segmentSize)+(segmentsAcked));
