cnt = (int) (93.344+(65.688)+(61.546)+(64.782)+(65.922));
tcb->m_cWnd = (int) (95.38-(segmentsAcked)-(segmentsAcked)-(segmentsAcked)-(73.278)-(29.77)-(34.581));
float LfSBOcfLSmpCkqKr = (float) (42.019+(tcb->m_ssThresh)+(44.573)+(13.872)+(31.037)+(tcb->m_ssThresh));
if (tcb->m_cWnd > LfSBOcfLSmpCkqKr) {
	cnt = (int) (59.363-(4.068)-(68.247)-(tcb->m_ssThresh)-(37.481)-(84.8));

} else {
	cnt = (int) (89.32*(LfSBOcfLSmpCkqKr)*(75.539)*(92.245));
	LfSBOcfLSmpCkqKr = (float) (segmentsAcked*(10.491)*(58.329)*(0.639)*(70.633)*(25.958));
	segmentsAcked = (int) (tcb->m_segmentSize-(7.721)-(73.625)-(68.708)-(tcb->m_ssThresh)-(55.142)-(86.477));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (segmentsAcked > segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(LfSBOcfLSmpCkqKr)*(77.836)*(LfSBOcfLSmpCkqKr)*(70.12)*(30.001)*(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (52.255*(52.389)*(segmentsAcked)*(74.414));
	segmentsAcked = (int) (LfSBOcfLSmpCkqKr*(57.967)*(47.239)*(10.693)*(50.347)*(40.248));
	tcb->m_cWnd = (int) (74.346+(17.05)+(81.203));

}
cnt = (int) (segmentsAcked+(60.427)+(34.49)+(51.768));
