segmentsAcked = (int) (48.934*(28.468)*(94.027)*(20.184));
float oWFvnLqrFRuTvAJs = (float) (((96.249)+(12.727)+((tcb->m_cWnd-(35.62)-(segmentsAcked)-(95.953)))+(56.89)+(12.211)+(0.1))/((81.813)+(0.1)+(0.1)));
if (tcb->m_segmentSize <= oWFvnLqrFRuTvAJs) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(67.887)-(49.176)-(81.264)-(31.099)-(87.548)-(61.87)-(78.474)-(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (79.841*(84.717)*(47.017)*(21.472)*(47.028)*(13.533));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (57.625-(14.096));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (80.03-(99.183)-(22.105));
