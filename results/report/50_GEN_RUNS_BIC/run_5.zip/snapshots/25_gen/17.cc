if (tcb->m_ssThresh != cnt) {
	tcb->m_segmentSize = (int) (((73.382)+((2.616+(91.181)+(52.089)+(95.289)+(tcb->m_ssThresh)))+(0.1)+(0.1))/((0.1)));
	cnt = (int) (23.681-(84.29)-(21.782)-(37.069)-(65.533)-(15.698)-(88.044));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(65.44));

}
float fHXhhNmLyuowvhoB = (float) (68.076*(cnt)*(4.165)*(89.319)*(40.722)*(66.777));
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	cnt = (int) (fHXhhNmLyuowvhoB+(90.926)+(23.208)+(segmentsAcked)+(75.203)+(44.29)+(39.263)+(segmentsAcked));
	fHXhhNmLyuowvhoB = (float) (19.886*(cnt)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(74.228));

} else {
	cnt = (int) (0.1/0.1);
	segmentsAcked = (int) (10.748*(98.457)*(7.22)*(41.295)*(54.023)*(52.528));

}
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((56.374-(82.322)-(73.819)-(22.499)-(80.397)-(tcb->m_ssThresh)-(20.237)-(43.878))/18.165);

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(tcb->m_segmentSize)-(cnt));

}
segmentsAcked = (int) (14.047+(84.447)+(tcb->m_cWnd)+(9.211)+(87.953));
if (fHXhhNmLyuowvhoB != segmentsAcked) {
	fHXhhNmLyuowvhoB = (float) (92.218-(94.935)-(tcb->m_cWnd)-(46.523)-(87.32)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(tcb->m_segmentSize));

} else {
	fHXhhNmLyuowvhoB = (float) (11.644*(30.959)*(fHXhhNmLyuowvhoB)*(fHXhhNmLyuowvhoB)*(tcb->m_segmentSize));

}
segmentsAcked = (int) (0.1/92.208);
