ReduceCwnd (tcb);
tcb->m_cWnd = (int) (0.1/0.1);
float IEjomNVNRraXNMuX = (float) (65.529+(74.936)+(18.339)+(84.375)+(21.558));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float dWtoWvkFmPtnJVXf = (float) (9.577*(10.953)*(27.076)*(29.496)*(IEjomNVNRraXNMuX)*(11.498));
tcb->m_ssThresh = (int) (0.1/11.539);
