if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (((10.428)+((41.77-(tcb->m_cWnd)-(37.52)-(88.983)-(68.451)-(cnt)-(56.73)-(93.851)))+((86.941*(segmentsAcked)*(46.523)))+(0.1)+(0.1))/((0.1)));
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (32.438+(11.684)+(15.065)+(75.223)+(35.334)+(tcb->m_ssThresh)+(26.552)+(68.666));
	cnt = (int) (35.862-(84.437)-(cnt)-(67.02)-(43.689)-(87.847)-(29.943)-(37.762));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (68.095-(89.839)-(60.775)-(tcb->m_segmentSize)-(3.302)-(94.757));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt != tcb->m_ssThresh) {
	cnt = (int) (36.458-(35.697)-(65.673)-(17.429)-(81.245)-(57.126)-(38.893)-(72.251)-(88.59));
	cnt = (int) (66.139+(49.433)+(cnt)+(13.94)+(69.973));
	segmentsAcked = (int) (98.183-(segmentsAcked)-(75.849));

} else {
	cnt = (int) ((95.156+(11.799)+(42.022)+(tcb->m_cWnd)+(46.918)+(cnt)+(64.093))/0.1);
	tcb->m_ssThresh = (int) (57.192/25.466);
	tcb->m_ssThresh = (int) (59.126-(52.206)-(tcb->m_ssThresh)-(58.26));

}
