tcb->m_segmentSize = (int) (11.609*(87.408)*(tcb->m_cWnd)*(16.672)*(tcb->m_ssThresh)*(tcb->m_ssThresh));
ReduceCwnd (tcb);
int clWLslEpjUqryVGw = (int) (tcb->m_ssThresh*(37.804));
if (clWLslEpjUqryVGw > tcb->m_cWnd) {
	segmentsAcked = (int) (58.214+(81.332)+(cnt)+(9.76)+(82.748)+(27.383));
	tcb->m_cWnd = (int) (79.464-(16.121)-(26.344)-(50.508)-(93.59)-(tcb->m_cWnd)-(16.646));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((67.128)+(0.1)+((47.065+(96.728)))+(38.195)+(53.585)+(68.655))/((55.497)+(0.1)+(0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (10.835+(cnt)+(62.169)+(61.029)+(19.459)+(73.944));

}
ReduceCwnd (tcb);
