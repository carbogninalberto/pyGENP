tcb->m_ssThresh = (int) (28.058+(88.298)+(tcb->m_cWnd)+(segmentsAcked)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(70.545)+(33.458));
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= cnt) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(tcb->m_ssThresh)+(95.528));

} else {
	tcb->m_cWnd = (int) (0.1/50.823);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (cnt*(88.912));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (21.168+(71.97)+(60.11)+(99.399)+(85.807)+(33.429));

} else {
	tcb->m_segmentSize = (int) (72.966-(70.078)-(17.581)-(tcb->m_segmentSize)-(segmentsAcked));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
