tcb->m_segmentSize = (int) (segmentsAcked+(57.88)+(1.468)+(68.805)+(cnt));
tcb->m_ssThresh = (int) (0.1/78.642);
if (tcb->m_segmentSize == segmentsAcked) {
	cnt = (int) (cnt-(92.061));
	tcb->m_segmentSize = (int) ((46.663-(44.96)-(55.884)-(53.725)-(20.93)-(72.997)-(cnt)-(10.654)-(68.092))/0.1);
	ReduceCwnd (tcb);

} else {
	cnt = (int) (4.482-(tcb->m_segmentSize)-(73.528)-(75.65)-(87.466)-(46.555)-(tcb->m_cWnd)-(67.787));
	segmentsAcked = (int) (42.977+(5.985)+(57.605)+(tcb->m_cWnd)+(8.026)+(68.767)+(58.746));
	segmentsAcked = (int) (10.618+(94.257)+(cnt));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (22.756*(tcb->m_cWnd)*(86.894));
	tcb->m_cWnd = (int) (41.957+(1.04)+(65.627)+(35.29)+(96.577)+(4.399)+(78.63)+(73.135)+(62.236));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (31.532*(70.855));

}
