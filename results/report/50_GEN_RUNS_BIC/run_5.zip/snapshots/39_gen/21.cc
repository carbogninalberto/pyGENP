float JjknBaQPOFuoqmnx = (float) (16.384+(89.564)+(-50.749));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-86.463*(67.908)*(61.436));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (33.052*(-26.956)*(27.165));
