float JjknBaQPOFuoqmnx = (float) (-42.821+(80.667)+(13.928));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (64.41*(66.144)*(-55.781));
tcb->m_cWnd = (int) (96.259*(61.985)*(54.921));
