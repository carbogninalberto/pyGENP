float JjknBaQPOFuoqmnx = (float) (19.895+(-77.456)+(67.901));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (83.929*(-31.387)*(86.909));
