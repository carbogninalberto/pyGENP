float JjknBaQPOFuoqmnx = (float) (-60.828+(8.87)+(-11.561));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (68.162*(-73.077)*(-4.649));
tcb->m_cWnd = (int) (38.062*(77.489)*(-51.467));
