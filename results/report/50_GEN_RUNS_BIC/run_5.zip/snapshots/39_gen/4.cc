float JjknBaQPOFuoqmnx = (float) (-53.792+(50.7)+(96.316));
tcb->m_cWnd = (int) (-63.667*(-79.618)*(78.417));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-72.619*(-13.355)*(80.462));
tcb->m_cWnd = (int) (-21.884*(1.49)*(-82.19));
