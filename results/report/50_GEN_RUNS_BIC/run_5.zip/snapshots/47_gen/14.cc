float kliRqPOSEVEeXCCm = (float) (99.416-(58.242)-(53.412)-(90.99)-(16.433)-(99.175));
cnt = (int) (22.639*(tcb->m_ssThresh)*(39.306)*(50.28)*(tcb->m_cWnd)*(34.349));
int lZxQqrNhbFvWstpb = (int) ((63.158+(3.399)+(tcb->m_segmentSize)+(71.412)+(15.364)+(6.082)+(81.983)+(23.235)+(55.281))/69.122);
if (tcb->m_cWnd < lZxQqrNhbFvWstpb) {
	kliRqPOSEVEeXCCm = (float) (segmentsAcked-(25.201)-(84.579));

} else {
	kliRqPOSEVEeXCCm = (float) (85.917-(lZxQqrNhbFvWstpb)-(14.103)-(13.454)-(segmentsAcked)-(27.354)-(18.631));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (64.766+(7.611)+(kliRqPOSEVEeXCCm)+(26.8)+(79.017)+(62.02)+(91.676));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
