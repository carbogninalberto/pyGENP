float vMCCbVegKPajFwBb = (float) (-88.888-(96.966)-(9.993)-(17.318)-(-97.325));
float nfBHJcczSZaIXxbC = (float) (74.706-(78.898)-(80.576)-(-94.835)-(51.773)-(-75.143)-(-9.846));
if (tcb->m_segmentSize == vMCCbVegKPajFwBb) {
	nfBHJcczSZaIXxbC = (float) (0.1/(87.378-(9.636)-(10.245)-(cnt)-(23.833)-(36.629)-(83.362)));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	nfBHJcczSZaIXxbC = (float) (53.824*(84.039)*(58.115)*(46.219)*(77.426)*(65.084)*(-80.34)*(74.142)*(79.784));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	vMCCbVegKPajFwBb = (float) (52.662*(88.962)*(33.601)*(27.952)*(51.127)*(3.143)*(4.17)*(3.265)*(81.395));

}
ReduceCwnd (tcb);
vMCCbVegKPajFwBb = (float) (66.322*(-11.154)*(48.47)*(42.576)*(-14.421)*(89.496)*(-23.646)*(50.535));
ReduceCwnd (tcb);
vMCCbVegKPajFwBb = (float) (-12.914*(76.804)*(-11.995)*(-7.878)*(74.025)*(-67.836)*(-40.471)*(-83.66));
ReduceCwnd (tcb);
