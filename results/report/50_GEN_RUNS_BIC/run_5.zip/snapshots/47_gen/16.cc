float hJQiDYRLsquwyxQE = (float) (0.586+(33.649)+(1.5));
cnt = (int) (30.998-(22.887)-(43.826)-(hJQiDYRLsquwyxQE)-(12.826));
int sMOhmSOESxqjilmi = (int) (segmentsAcked-(6.394)-(25.31));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	sMOhmSOESxqjilmi = (int) (((0.1)+(0.1)+(95.531)+(0.1)+(22.665)+(82.337))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	sMOhmSOESxqjilmi = (int) (hJQiDYRLsquwyxQE-(90.017)-(5.101)-(0.321)-(cnt)-(segmentsAcked)-(82.997)-(52.98));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (37.724/2.115);

}
tcb->m_ssThresh = (int) (tcb->m_cWnd-(cnt)-(18.083)-(48.129)-(8.621)-(42.809)-(70.892));
if (segmentsAcked != tcb->m_cWnd) {
	sMOhmSOESxqjilmi = (int) (20.097*(67.064)*(78.919)*(hJQiDYRLsquwyxQE)*(90.788));

} else {
	sMOhmSOESxqjilmi = (int) (0.1/0.1);

}
