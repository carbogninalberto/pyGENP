if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize == segmentsAcked) {
	cnt = (int) (73.485*(tcb->m_ssThresh)*(82.161));
	tcb->m_segmentSize = (int) (segmentsAcked*(14.619)*(76.78));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (5.094-(segmentsAcked));
	cnt = (int) (49.456*(7.09)*(40.879)*(41.725)*(30.185)*(99.27)*(tcb->m_ssThresh)*(58.388)*(40.614));
	tcb->m_segmentSize = (int) (11.041*(tcb->m_cWnd)*(95.634)*(tcb->m_segmentSize)*(27.452));

}
tcb->m_ssThresh = (int) (((17.661)+(0.1)+(8.009)+((67.365*(65.782)*(86.579)*(17.868)))+(41.216))/((0.1)+(36.914)+(9.065)+(0.1)));
if (cnt < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (45.212+(22.976)+(36.722));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(24.687)*(cnt)*(3.055)*(82.314)*(60.768));

}
int iAiLycAPSOsrelWS = (int) (88.969-(69.022)-(12.591));
