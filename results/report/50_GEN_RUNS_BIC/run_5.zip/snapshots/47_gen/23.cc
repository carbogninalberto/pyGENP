int quzzwRuZRViRJQBl = (int) (86.572/0.1);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (61.662+(15.294)+(77.09)+(cnt)+(61.309)+(tcb->m_segmentSize)+(79.164)+(quzzwRuZRViRJQBl));
tcb->m_segmentSize = (int) ((tcb->m_cWnd*(38.758)*(11.284)*(51.531)*(96.347))/2.015);
int EPUdfciNQditDGec = (int) ((91.467*(46.866)*(16.015))/0.1);
EPUdfciNQditDGec = (int) (21.069+(tcb->m_cWnd)+(87.8)+(14.621)+(50.337)+(7.082)+(1.932)+(92.113));
