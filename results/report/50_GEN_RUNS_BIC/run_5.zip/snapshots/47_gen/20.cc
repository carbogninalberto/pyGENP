float WtsAHFQvztTjTTtC = (float) (segmentsAcked+(98.224)+(78.354)+(37.078)+(62.048));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (17.613-(82.481)-(tcb->m_segmentSize)-(79.534)-(28.645)-(18.68)-(46.827));
int wZZGhxfysZLRpnEh = (int) (tcb->m_ssThresh+(81.701)+(16.03)+(97.168)+(94.147));
tcb->m_ssThresh = (int) (25.469+(98.814)+(89.496)+(81.596)+(50.374)+(74.116)+(segmentsAcked));
