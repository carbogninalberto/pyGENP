tcb->m_ssThresh = (int) (89.277+(86.45)+(22.87)+(87.525)+(tcb->m_segmentSize)+(7.363)+(66.381)+(62.003)+(segmentsAcked));
segmentsAcked = (int) ((2.04*(94.563)*(75.102)*(96.23)*(83.839)*(38.148)*(8.321)*(74.741)*(65.646))/0.1);
cnt = (int) (9.083*(7.585)*(37.387)*(69.734));
segmentsAcked = (int) (tcb->m_ssThresh-(29.076)-(95.208)-(30.326)-(37.438));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (67.955-(29.483));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
