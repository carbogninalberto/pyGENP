int osbAxjUYElFntUAn = (int) (-33.126*(6.141)*(11.962)*(-36.593));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-72.42*(-67.449)*(73.613)*(86.865)*(-40.219)*(30.927)*(20.506)*(82.724));
tcb->m_cWnd = (int) (29.482*(-27.916)*(95.169)*(17.607)*(76.548)*(-45.579)*(52.95)*(31.68));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
