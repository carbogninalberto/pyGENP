if (tcb->m_cWnd < tcb->m_cWnd) {
	cnt = (int) (((84.567)+(0.1)+(0.1)+(17.756))/((0.1)+(0.1)+(0.1)));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (11.054+(73.949)+(29.549)+(24.91)+(21.912)+(segmentsAcked)+(20.569));
	tcb->m_ssThresh = (int) (56.604-(55.415));

}
tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(0.1)+(3.406))/((62.987)+(0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (1.106/63.048);
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (8.089*(73.462)*(97.119)*(tcb->m_ssThresh)*(cnt)*(57.764)*(95.028));

} else {
	tcb->m_segmentSize = (int) (cnt+(85.308)+(72.731)+(cnt)+(9.026));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
