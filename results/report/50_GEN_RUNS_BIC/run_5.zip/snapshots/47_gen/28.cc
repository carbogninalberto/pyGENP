if (cnt <= segmentsAcked) {
	tcb->m_cWnd = (int) (((18.779)+(0.1)+((49.609-(93.446)-(19.312)-(75.343)-(25.319)-(11.184)))+(81.151))/((0.1)+(66.242)+(0.1)+(38.518)));

} else {
	tcb->m_cWnd = (int) (59.939*(18.148)*(56.892)*(52.244)*(0.106)*(0.133)*(segmentsAcked)*(89.494)*(19.513));
	tcb->m_cWnd = (int) (32.859-(34.588)-(8.465)-(93.846)-(cnt)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(49.413));

}
int hXzqIGoDLahESZEZ = (int) (52.967*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(74.991)*(14.877)*(30.93)*(19.839));
ReduceCwnd (tcb);
cnt = (int) (58.938+(4.329)+(27.224));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (93.302*(19.876));
tcb->m_segmentSize = (int) (hXzqIGoDLahESZEZ-(39.023)-(46.546)-(61.372)-(47.845)-(61.948)-(segmentsAcked));
