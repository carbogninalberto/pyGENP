if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((98.213)+(0.1)+(0.1)+(69.388))/((72.586)));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (12.067+(tcb->m_segmentSize)+(segmentsAcked));
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh < tcb->m_cWnd) {
	cnt = (int) (0.1/64.238);

} else {
	cnt = (int) (36.751*(95.276)*(segmentsAcked));

}
segmentsAcked = (int) (60.608/77.752);
tcb->m_cWnd = (int) (((0.1)+((82.086+(64.123)+(34.854)+(74.402)+(19.924)+(cnt)))+(0.1)+(5.146))/((29.733)));
tcb->m_cWnd = (int) (69.489-(44.902)-(cnt)-(67.566)-(93.096)-(segmentsAcked)-(93.009));
tcb->m_cWnd = (int) (0.1/64.463);
