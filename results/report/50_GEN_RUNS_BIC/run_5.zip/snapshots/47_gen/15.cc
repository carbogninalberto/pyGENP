if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((91.376)+(34.625)+(0.1)+((9.648-(tcb->m_cWnd)-(32.192)-(90.92)-(56.946)-(61.627)))+(13.937))/((84.931)));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (13.982+(16.879)+(25.138)+(38.508)+(75.939)+(94.263)+(9.928));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (28.551*(33.758)*(segmentsAcked)*(cnt)*(cnt)*(48.58));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (99.445-(cnt)-(34.523)-(tcb->m_segmentSize)-(76.848));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (12.076*(tcb->m_ssThresh)*(62.572)*(91.036)*(30.338)*(26.785)*(segmentsAcked)*(48.098)*(24.691));
	tcb->m_ssThresh = (int) (20.732-(72.309)-(88.402)-(74.179)-(31.167)-(88.75)-(32.375));
	tcb->m_ssThresh = (int) (66.382*(97.732)*(93.389));

}
ReduceCwnd (tcb);
