float vMCCbVegKPajFwBb = (float) (18.906-(-5.498)-(-81.596)-(-27.087)-(32.338));
float nfBHJcczSZaIXxbC = (float) (-97.008-(-19.54)-(-9.951)-(-54.637)-(24.318)-(-79.62)-(-86.902));
ReduceCwnd (tcb);
vMCCbVegKPajFwBb = (float) (-52.501*(-32.47)*(-38.162)*(-12.032)*(21.119)*(63.754)*(26.025)*(70.11));
ReduceCwnd (tcb);
