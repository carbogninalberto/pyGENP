ReduceCwnd (tcb);
segmentsAcked = (int) (segmentsAcked*(tcb->m_cWnd)*(segmentsAcked)*(50.465)*(84.623)*(50.463)*(tcb->m_cWnd)*(cnt));
segmentsAcked = (int) (tcb->m_segmentSize+(43.737)+(17.273));
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (83.338*(55.839)*(86.037)*(72.501)*(31.823)*(79.831)*(88.594));

} else {
	tcb->m_segmentSize = (int) (16.98*(33.659)*(84.931)*(cnt)*(86.489));

}
tcb->m_segmentSize = (int) (((40.932)+(0.1)+((93.921+(31.103)))+(48.295))/((0.1)+(22.782)+(85.473)+(3.86)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked != tcb->m_segmentSize) {
	cnt = (int) (66.092+(34.838)+(tcb->m_cWnd)+(82.228)+(95.049)+(30.609)+(95.24));

} else {
	cnt = (int) (tcb->m_ssThresh-(72.578)-(16.877)-(44.481)-(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(43.147));

}
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(91.985)*(78.93));
	segmentsAcked = (int) (segmentsAcked*(16.344)*(39.252)*(82.849)*(5.434)*(tcb->m_ssThresh)*(90.615)*(94.42)*(60.375));

} else {
	tcb->m_segmentSize = (int) (69.238+(cnt)+(61.066)+(cnt)+(49.761)+(43.907)+(segmentsAcked)+(4.615)+(76.506));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (58.223-(12.153)-(58.036)-(90.812));
