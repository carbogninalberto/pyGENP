ReduceCwnd (tcb);
tcb->m_ssThresh = (int) ((9.993*(71.063)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(3.156)*(53.691)*(63.772)*(cnt))/26.586);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	cnt = (int) (63.168+(tcb->m_ssThresh)+(20.874)+(16.109)+(76.505)+(36.675)+(96.126));
	tcb->m_cWnd = (int) (69.855/0.1);

} else {
	cnt = (int) (48.065-(15.286)-(63.451)-(28.866)-(81.448)-(80.946)-(8.394)-(38.644)-(48.103));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
