if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int MDxQbCPnHJCLTvjN = (int) (79.697*(67.727)*(47.725)*(63.445));
tcb->m_segmentSize = (int) (34.357*(11.076)*(12.06)*(8.416)*(54.0));
