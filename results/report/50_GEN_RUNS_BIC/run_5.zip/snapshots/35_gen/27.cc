if (segmentsAcked == segmentsAcked) {
	tcb->m_cWnd = (int) (5.782/0.1);
	tcb->m_segmentSize = (int) (76.03-(54.914)-(1.654)-(99.57)-(tcb->m_ssThresh)-(16.632)-(60.699));

} else {
	tcb->m_cWnd = (int) (24.849/(20.095*(52.274)));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) ((((tcb->m_segmentSize+(24.607)+(36.676)+(91.253)+(94.12)+(53.427)))+((77.359*(66.216)*(52.35)*(segmentsAcked)*(17.564)*(38.139)))+(0.1)+(44.931))/((66.789)+(0.1)+(18.316)));
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	cnt = (int) (46.0-(4.985)-(71.823));

} else {
	cnt = (int) ((tcb->m_ssThresh*(25.897)*(47.857)*(10.441)*(55.7)*(98.83)*(0.334)*(87.723)*(tcb->m_cWnd))/57.192);

}
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (cnt-(9.974)-(82.449)-(cnt));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(27.739)-(83.422)-(98.499)-(73.708)-(tcb->m_cWnd)-(14.536)-(83.301)-(5.827));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
