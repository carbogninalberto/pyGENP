if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int hszqQCHUVGTeZZZi = (int) (((-18.411)+(24.718)+(-59.78)+(-57.919)+(26.998)+(63.498)+(-71.424))/((-23.079)));
tcb->m_segmentSize = (int) (-47.294*(-40.317)*(76.109)*(75.507)*(-43.366));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (43.299*(-98.171)*(91.621)*(-76.753)*(80.814));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (18.542*(85.555)*(-23.38)*(17.687)*(-30.518));
