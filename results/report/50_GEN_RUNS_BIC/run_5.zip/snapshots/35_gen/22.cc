if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (71.932*(5.706)*(51.83)*(46.362)*(tcb->m_ssThresh)*(50.857)*(60.819));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(96.691)+(84.688)+(3.219)+(84.027)+(6.568)+(28.591));
	tcb->m_cWnd = (int) (94.028+(7.329)+(26.214)+(30.656)+(18.074)+(2.363)+(14.972));

} else {
	tcb->m_ssThresh = (int) (3.607*(20.193)*(68.113)*(9.029)*(49.792)*(92.74)*(91.495));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(43.774)+(9.924)+(3.267)+(tcb->m_ssThresh)+(68.284));
	segmentsAcked = (int) (39.355+(83.448)+(35.164));

}
tcb->m_cWnd = (int) (24.95+(3.917)+(4.788));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (0.579-(50.498)-(46.322)-(41.951));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (39.929-(80.98)-(90.461));
	tcb->m_ssThresh = (int) (12.097+(54.067)+(21.211)+(segmentsAcked)+(36.821)+(80.01)+(72.457)+(63.647));
	segmentsAcked = (int) (62.891+(94.557)+(segmentsAcked)+(12.395)+(23.864)+(6.674)+(14.193)+(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (49.918*(63.348)*(segmentsAcked)*(88.587)*(tcb->m_segmentSize)*(5.67)*(53.732)*(34.861));

}
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (segmentsAcked+(cnt)+(70.419)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (((89.61)+(19.562)+(0.1)+(0.1))/((0.1)+(77.972)+(0.1)+(73.247)));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (27.462/10.471);
	tcb->m_segmentSize = (int) (((27.773)+(44.54)+((22.862-(65.447)-(86.346)-(14.26)-(89.583)-(52.576)-(95.059)-(86.579)-(44.051)))+(0.1))/((34.86)));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(97.147)*(56.121)*(3.32)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (74.556*(67.753)*(54.451)*(18.445)*(38.7)*(84.811)*(90.812)*(43.89));

}
tcb->m_ssThresh = (int) (21.893*(tcb->m_cWnd));
