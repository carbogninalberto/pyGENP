int wctxOoybmwVvOTZn = (int) (21.208-(69.693)-(74.118)-(89.49)-(84.392)-(segmentsAcked)-(8.92)-(60.82)-(45.836));
tcb->m_cWnd = (int) (38.18+(10.258)+(62.33)+(88.231));
float szrnZgqIfVannLue = (float) (((15.772)+((5.8*(22.234)*(84.971)*(90.153)*(34.266)*(tcb->m_segmentSize)*(83.536)*(3.779)*(89.53)))+(0.1)+(0.1))/((0.1)+(0.1)+(42.499)+(0.1)+(75.519)));
tcb->m_segmentSize = (int) (24.934*(wctxOoybmwVvOTZn)*(47.443)*(17.052)*(84.377)*(wctxOoybmwVvOTZn)*(wctxOoybmwVvOTZn)*(35.783)*(96.148));
segmentsAcked = (int) (30.096*(56.455)*(11.983)*(2.443));
