ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
cnt = (int) (((0.1)+(27.426)+(15.628)+(56.762)+(0.1)+(31.603))/((58.955)));
tcb->m_segmentSize = (int) (40.754/0.1);
tcb->m_ssThresh = (int) ((62.392+(tcb->m_ssThresh)+(94.314)+(tcb->m_segmentSize)+(64.197)+(cnt)+(tcb->m_segmentSize)+(64.584))/68.256);
ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	cnt = (int) (39.394-(4.762)-(tcb->m_cWnd)-(90.323)-(4.304)-(tcb->m_ssThresh)-(89.977)-(71.139)-(76.214));
	tcb->m_cWnd = (int) (87.918+(13.633)+(47.574));

} else {
	cnt = (int) (segmentsAcked+(46.914)+(55.72)+(tcb->m_ssThresh)+(69.024)+(tcb->m_ssThresh)+(cnt)+(79.409)+(3.871));

}
ReduceCwnd (tcb);
