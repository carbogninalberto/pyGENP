if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (46.76*(83.673)*(0.406)*(89.633)*(65.052));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (57.256+(79.473)+(tcb->m_cWnd)+(36.976)+(61.008)+(16.413)+(42.035)+(83.197)+(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (41.849-(57.571)-(56.829)-(25.767)-(91.059)-(19.47)-(70.302));
	segmentsAcked = (int) (segmentsAcked-(8.795));

}
tcb->m_ssThresh = (int) (37.825*(50.131)*(segmentsAcked));
if (segmentsAcked >= cnt) {
	tcb->m_cWnd = (int) (17.952/0.1);
	tcb->m_ssThresh = (int) (50.147*(60.411)*(tcb->m_ssThresh)*(47.94)*(69.77));

} else {
	tcb->m_cWnd = (int) (83.551+(39.364)+(84.59)+(11.736)+(34.404)+(55.267)+(segmentsAcked));

}
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((66.939*(segmentsAcked))/0.1);
	ReduceCwnd (tcb);
	cnt = (int) (93.266/0.1);

} else {
	tcb->m_cWnd = (int) (0.4-(segmentsAcked)-(16.69)-(33.073)-(44.111)-(segmentsAcked));

}
tcb->m_segmentSize = (int) (68.259*(cnt));
