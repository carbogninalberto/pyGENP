tcb->m_cWnd = (int) ((29.34-(-6.445)-(cnt)-(67.405)-(-97.829)-(-9.274)-(56.809)-(-25.301)-(-2.027))/-86.85);
float wAeSGeNYwHsridMl = (float) (-18.432/(-57.55*(-23.656)*(96.558)*(-69.378)*(67.62)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (67.725*(86.81)*(-76.807)*(72.293)*(-61.059));
