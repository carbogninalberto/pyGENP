tcb->m_segmentSize = (int) (((33.201)+(0.1)+((60.98+(95.26)+(69.219)+(42.867)+(36.727)+(3.909)+(cnt)+(72.521)+(74.152)))+(39.028))/((0.1)+(0.1)));
tcb->m_ssThresh = (int) ((((tcb->m_ssThresh-(82.792)-(77.999)-(tcb->m_ssThresh)-(68.878)-(3.598)-(tcb->m_cWnd)-(93.161)))+(0.1)+(0.1)+(0.1)+((36.52-(15.885)-(34.884)-(72.921)-(24.811)-(82.573)-(76.394)-(57.126)-(32.705)))+(45.156)+(50.293)+(1.571))/((39.198)));
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (49.662/0.1);

} else {
	tcb->m_ssThresh = (int) (45.11*(74.879)*(32.37)*(70.016)*(9.65)*(78.263)*(48.258)*(90.137));
	segmentsAcked = (int) ((((13.577+(95.06)+(69.352)+(65.117)+(tcb->m_segmentSize)))+(0.1)+(91.525)+(0.1))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (7.036+(2.149)+(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(44.222)-(tcb->m_cWnd)-(tcb->m_segmentSize)-(53.429)-(57.729)-(segmentsAcked));

}
tcb->m_cWnd = (int) (38.044*(13.852)*(54.415)*(38.615)*(91.605)*(40.651)*(85.549));
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_ssThresh = (int) (46.909+(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(63.622)-(tcb->m_segmentSize)-(88.899));
	tcb->m_cWnd = (int) (83.458+(16.976)+(69.703)+(28.473)+(98.667));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float rxIElZYYdPhbmYFp = (float) (tcb->m_segmentSize-(89.256)-(23.167));
