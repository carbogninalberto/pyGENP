if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (94.494+(22.366)+(39.041)+(6.055));
	tcb->m_ssThresh = (int) (4.979-(62.213)-(40.316)-(7.791)-(77.834)-(58.407)-(35.729));
	tcb->m_cWnd = (int) (16.199-(tcb->m_ssThresh)-(36.964));

}
cnt = (int) (63.845*(33.805)*(tcb->m_segmentSize));
int agWzLvmgJyiktaUn = (int) (8.515*(99.469)*(95.878)*(91.155)*(tcb->m_ssThresh)*(96.066)*(2.672)*(76.079));
ReduceCwnd (tcb);
