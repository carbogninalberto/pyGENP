segmentsAcked = (int) (73.257*(57.95)*(84.736));
segmentsAcked = (int) (((0.1)+((16.05*(74.028)*(segmentsAcked)*(tcb->m_ssThresh)*(43.618)*(94.259)*(94.787)))+(0.1)+(0.1)+(65.445)+(0.1))/((85.162)+(51.387)+(0.1)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
cnt = (int) (5.876-(49.49)-(93.038)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(2.381));
tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+((69.178-(74.491)-(13.841)-(90.046)-(64.008)))+(92.485)+(41.835))/((0.1)));
