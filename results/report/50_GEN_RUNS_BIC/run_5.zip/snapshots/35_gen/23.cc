if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float uhYGvEgsuNhguqpG = (float) (33.755*(6.918)*(90.708)*(44.328)*(80.292));
float bSbXTLRbHHJuxUrW = (float) (81.549-(29.568)-(34.819)-(59.324)-(11.207)-(44.638)-(2.033)-(cnt));
if (segmentsAcked >= segmentsAcked) {
	cnt = (int) (98.467/0.1);

} else {
	cnt = (int) (78.255*(25.121)*(17.586)*(14.608)*(62.536)*(71.67));
	cnt = (int) (tcb->m_cWnd-(5.159)-(uhYGvEgsuNhguqpG)-(tcb->m_ssThresh));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
