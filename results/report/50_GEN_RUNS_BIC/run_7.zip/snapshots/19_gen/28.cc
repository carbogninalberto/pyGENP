tcb->m_cWnd = (int) (tcb->m_segmentSize-(20.536));
tcb->m_cWnd = (int) (29.676/15.564);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
segmentsAcked = (int) (94.467-(38.626));
int IcbjtXaqYQuQqCEH = (int) (47.92/22.855);
