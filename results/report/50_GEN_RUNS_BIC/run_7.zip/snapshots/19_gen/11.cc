int xivmrmUZerpyhgPc = (int) (((89.302)+(90.576)+(99.404)+((61.425+(59.081)+(-93.987)+(-59.966)+(-1.209)+(50.636)+(-64.481)))+(-87.03)+(88.537)+((53.963+(-86.141)+(63.355)+(44.593)))+(11.594))/((-84.343)));
segmentsAcked = (int) (((-13.564)+(-58.409)+(-79.873)+(-76.402))/((-19.063)));
int hLmsRzabmouoaUzp = (int) (-12.486-(-60.698)-(-77.741)-(98.601)-(-92.088)-(-42.646)-(-77.077)-(7.105)-(6.019));
tcb->m_cWnd = (int) (-10.936*(28.809)*(-36.18));
segmentsAcked = (int) (((-63.928)+(86.462)+(82.86)+(-15.41))/((-17.039)));
tcb->m_cWnd = (int) (20.22*(80.536)*(-68.707));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-31.341*(-25.963)*(-42.286));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
