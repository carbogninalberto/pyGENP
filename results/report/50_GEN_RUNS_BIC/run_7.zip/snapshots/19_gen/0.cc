int xivmrmUZerpyhgPc = (int) (((-98.609)+(2.386)+(48.575)+((18.796+(95.763)+(92.659)+(85.779)+(-78.182)+(-36.46)+(-48.853)))+(-20.962)+(-1.438)+((39.194+(-84.153)+(94.847)+(51.777)))+(68.883))/((-99.864)));
segmentsAcked = (int) (((-39.369)+(28.212)+(-54.892)+(-58.229))/((-92.703)));
int hLmsRzabmouoaUzp = (int) (-3.773-(-35.499)-(28.012)-(13.862)-(49.742)-(51.236)-(-4.066)-(-20.075)-(-37.247));
tcb->m_cWnd = (int) (-61.188*(85.631)*(-89.607));
segmentsAcked = (int) (((12.629)+(-15.931)+(2.247)+(65.219))/((70.697)));
tcb->m_cWnd = (int) (-15.893*(39.818)*(85.558));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-82.362*(-0.472)*(40.419));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
