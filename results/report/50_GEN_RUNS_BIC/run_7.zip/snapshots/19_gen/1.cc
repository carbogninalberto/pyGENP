int xivmrmUZerpyhgPc = (int) (((75.769)+(96.098)+(37.772)+((-34.614+(-97.762)+(65.652)+(90.81)+(69.662)+(52.402)+(-43.409)))+(2.088)+(-98.176)+((-17.516+(-99.077)+(34.783)+(-42.758)))+(53.724))/((34.365)));
segmentsAcked = (int) (((-98.817)+(-40.842)+(-21.561)+(21.132))/((-74.665)));
int hLmsRzabmouoaUzp = (int) (-66.648-(28.281)-(29.522)-(-16.98)-(66.689)-(79.219)-(88.084)-(80.263)-(46.169));
tcb->m_cWnd = (int) (31.268*(74.355)*(93.186));
segmentsAcked = (int) (((-81.402)+(-74.127)+(-67.274)+(23.181))/((3.49)));
tcb->m_cWnd = (int) (-80.943*(-74.816)*(-25.87));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (21.241*(-51.617)*(-30.619));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
