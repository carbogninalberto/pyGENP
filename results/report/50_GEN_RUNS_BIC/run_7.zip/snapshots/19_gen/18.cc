float eYCttdEQBnMtJYcm = (float) (18.491+(97.629)+(89.176)+(97.518)+(87.274)+(20.851));
float crpzzxeqbKIBvUdq = (float) (81.753-(17.531)-(tcb->m_segmentSize)-(92.091));
if (tcb->m_cWnd >= cnt) {
	tcb->m_cWnd = (int) (39.811*(50.623)*(85.354)*(cnt)*(19.085)*(68.795));
	crpzzxeqbKIBvUdq = (float) (10.822+(89.239)+(98.579)+(66.262)+(64.8)+(80.898));
	tcb->m_cWnd = (int) (eYCttdEQBnMtJYcm+(18.778)+(96.86)+(58.878)+(90.835)+(24.826)+(64.427)+(67.3));

} else {
	tcb->m_cWnd = (int) (41.959/7.287);
	eYCttdEQBnMtJYcm = (float) (24.864+(tcb->m_ssThresh)+(37.164)+(crpzzxeqbKIBvUdq)+(28.136)+(23.456)+(tcb->m_cWnd));

}
int pctlVvWmaeCDBNSj = (int) (84.902-(15.354)-(17.639)-(7.485));
tcb->m_segmentSize = (int) (17.649+(79.728)+(59.297)+(3.892)+(22.626)+(18.73));
if (pctlVvWmaeCDBNSj == eYCttdEQBnMtJYcm) {
	tcb->m_ssThresh = (int) (6.905-(crpzzxeqbKIBvUdq)-(86.984)-(11.919)-(84.347)-(32.541)-(30.25));
	tcb->m_cWnd = (int) (48.857-(66.934)-(71.595)-(36.255)-(83.198)-(8.293)-(28.237)-(21.942)-(40.666));

} else {
	tcb->m_ssThresh = (int) (82.433*(54.127)*(51.846)*(0.341)*(28.855)*(cnt)*(25.088)*(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (9.357*(60.101)*(cnt)*(tcb->m_cWnd)*(5.991)*(55.453)*(94.292)*(99.131)*(pctlVvWmaeCDBNSj));
ReduceCwnd (tcb);
if (tcb->m_cWnd <= cnt) {
	tcb->m_ssThresh = (int) (9.553-(55.743));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (pctlVvWmaeCDBNSj+(61.025)+(33.687)+(crpzzxeqbKIBvUdq)+(13.754)+(21.687));

} else {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(60.841)+(91.359))/((68.505)+(0.1)+(0.1)+(0.1)+(97.402)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (12.415+(97.498)+(17.88)+(96.089)+(crpzzxeqbKIBvUdq));

}
