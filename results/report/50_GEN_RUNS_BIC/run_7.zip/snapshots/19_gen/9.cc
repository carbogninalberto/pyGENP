int xivmrmUZerpyhgPc = (int) (((-36.792)+(-42.717)+(43.302)+((97.712+(40.854)+(-97.227)+(94.791)+(49.947)+(-79.296)+(68.082)))+(14.234)+(-82.22)+((92.092+(-70.818)+(-56.943)+(4.263)))+(-48.876))/((-31.734)));
segmentsAcked = (int) (((-44.323)+(42.311)+(-97.798)+(88.479))/((-14.145)));
int hLmsRzabmouoaUzp = (int) (-18.163-(-66.846)-(29.355)-(-75.125)-(79.083)-(84.53)-(-22.364)-(93.24)-(-98.635));
tcb->m_cWnd = (int) (-97.051*(-53.499)*(50.387));
segmentsAcked = (int) (((13.378)+(-35.12)+(-88.665)+(55.076))/((-54.304)));
tcb->m_cWnd = (int) (-75.146*(98.976)*(17.011));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-4.582*(-16.593)*(-12.101));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
