cnt = (int) ((((81.802+(24.321)+(77.681)+(30.962)+(66.85)+(81.675)))+(30.2)+(67.039)+(0.1)+(21.727)+(0.1))/((0.1)));
if (tcb->m_ssThresh >= cnt) {
	segmentsAcked = (int) (tcb->m_segmentSize*(48.588)*(63.04)*(59.192)*(51.645)*(segmentsAcked)*(10.286));
	cnt = (int) (46.518+(64.536)+(12.659)+(tcb->m_ssThresh)+(94.174)+(81.781)+(cnt)+(30.476));
	tcb->m_cWnd = (int) (73.166-(96.677)-(53.278)-(64.146)-(89.689)-(30.396)-(44.094)-(72.027)-(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (tcb->m_cWnd-(tcb->m_ssThresh)-(70.447)-(20.336)-(72.189)-(42.053)-(97.99)-(tcb->m_ssThresh));

}
tcb->m_ssThresh = (int) (40.086-(47.479)-(16.132)-(73.815)-(51.776)-(74.848)-(54.342)-(segmentsAcked)-(10.226));
segmentsAcked = (int) (51.314-(tcb->m_cWnd)-(34.002));
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (14.51+(tcb->m_ssThresh)+(93.596));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (56.283-(53.186)-(63.164)-(29.86)-(46.637)-(tcb->m_cWnd)-(13.285)-(71.094));

} else {
	tcb->m_cWnd = (int) (89.862-(segmentsAcked)-(tcb->m_ssThresh)-(37.005)-(segmentsAcked)-(44.73)-(52.797)-(59.628)-(23.078));
	cnt = (int) (84.001*(segmentsAcked)*(segmentsAcked)*(78.407)*(20.851)*(segmentsAcked)*(7.617)*(20.206));
	cnt = (int) (tcb->m_cWnd+(43.832));

}
tcb->m_segmentSize = (int) (20.309-(7.906));
segmentsAcked = (int) (5.795-(tcb->m_ssThresh)-(22.019)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(50.773));
ReduceCwnd (tcb);
