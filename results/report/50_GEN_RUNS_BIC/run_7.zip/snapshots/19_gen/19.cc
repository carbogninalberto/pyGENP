ReduceCwnd (tcb);
float yLDFTDAXpeIqVtRV = (float) (tcb->m_cWnd-(35.323)-(tcb->m_segmentSize)-(57.201));
if (cnt < yLDFTDAXpeIqVtRV) {
	cnt = (int) (76.049*(69.644)*(16.292)*(8.636)*(36.78));

} else {
	cnt = (int) (1.996+(41.293)+(33.677)+(73.588)+(cnt)+(49.694)+(67.146)+(36.784));
	tcb->m_segmentSize = (int) (85.024-(98.484));

}
segmentsAcked = (int) (63.84/35.835);
yLDFTDAXpeIqVtRV = (float) (50.34+(15.99)+(65.822)+(20.715)+(78.159)+(tcb->m_segmentSize)+(85.034)+(tcb->m_segmentSize)+(segmentsAcked));
if (segmentsAcked < yLDFTDAXpeIqVtRV) {
	tcb->m_segmentSize = (int) (70.476+(9.888)+(tcb->m_segmentSize)+(42.282)+(cnt)+(96.935));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	yLDFTDAXpeIqVtRV = (float) ((90.954*(86.841)*(54.284)*(92.415))/0.1);

} else {
	tcb->m_segmentSize = (int) (segmentsAcked-(94.403)-(27.127)-(tcb->m_segmentSize)-(73.288)-(33.361)-(yLDFTDAXpeIqVtRV)-(tcb->m_cWnd));

}
ReduceCwnd (tcb);
