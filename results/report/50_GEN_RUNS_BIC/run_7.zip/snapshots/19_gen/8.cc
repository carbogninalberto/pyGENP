int UOqkqkekxXSXudEh = (int) (-16.613+(24.736)+(-80.746));
ReduceCwnd (tcb);
segmentsAcked = (int) (30.257-(5.011)-(21.463)-(-5.263)-(-28.504)-(-55.564));
