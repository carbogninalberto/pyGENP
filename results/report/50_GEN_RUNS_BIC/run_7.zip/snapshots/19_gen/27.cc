int exlYwlXsQMrjCLpk = (int) (66.087+(35.779));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (23.145-(98.913));
tcb->m_segmentSize = (int) (0.1/55.809);
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (80.657+(20.85));
	segmentsAcked = (int) (59.602-(tcb->m_ssThresh)-(35.315)-(66.184)-(62.377)-(36.386)-(23.852));

} else {
	tcb->m_ssThresh = (int) ((35.089-(tcb->m_segmentSize)-(46.602)-(38.248)-(10.393)-(61.723)-(23.805))/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (80.51-(51.495)-(32.757)-(45.695)-(tcb->m_cWnd)-(92.945)-(22.261)-(48.39)-(46.332));
	tcb->m_ssThresh = (int) (6.317-(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (6.981/0.1);
	cnt = (int) (41.797*(tcb->m_ssThresh)*(cnt));

}
tcb->m_cWnd = (int) (69.941-(12.412)-(21.422));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
