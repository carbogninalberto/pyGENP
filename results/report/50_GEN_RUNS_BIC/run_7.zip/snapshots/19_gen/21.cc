tcb->m_segmentSize = (int) ((62.085-(22.373)-(57.758)-(24.605)-(53.534))/0.1);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (63.449+(97.153)+(99.501)+(14.02)+(tcb->m_ssThresh)+(17.328)+(77.448)+(45.417)+(cnt));

} else {
	tcb->m_segmentSize = (int) (64.945+(43.995));
	cnt = (int) (54.21+(12.408)+(19.655)+(72.291)+(43.849)+(cnt)+(11.032)+(33.054));

}
cnt = (int) (96.785*(tcb->m_segmentSize)*(80.173)*(14.457)*(23.768));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	cnt = (int) (92.658-(31.578));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	cnt = (int) (83.401-(82.528)-(21.265)-(79.405)-(cnt)-(41.915));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	segmentsAcked = (int) ((((62.528+(58.094)+(tcb->m_ssThresh)+(82.472)+(46.71)+(90.903)))+(31.465)+(22.561)+(0.1))/((0.1)));
	tcb->m_segmentSize = (int) (12.844*(15.756)*(segmentsAcked)*(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (53.842*(87.34)*(segmentsAcked)*(5.842)*(23.388));

} else {
	segmentsAcked = (int) (69.434-(59.774)-(segmentsAcked)-(38.824));

}
