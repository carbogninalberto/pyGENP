tcb->m_ssThresh = (int) (0.1/23.405);
ReduceCwnd (tcb);
if (segmentsAcked != segmentsAcked) {
	tcb->m_segmentSize = (int) (36.178+(cnt)+(43.243)+(99.381)+(19.361));

} else {
	tcb->m_segmentSize = (int) (82.167*(57.937)*(tcb->m_ssThresh)*(42.412)*(segmentsAcked)*(80.051));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
