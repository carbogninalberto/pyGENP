if (cnt <= tcb->m_segmentSize) {
	segmentsAcked = (int) (((26.814)+((89.186+(84.351)+(81.897)+(51.082)+(tcb->m_ssThresh)))+(33.164)+(37.562)+((89.085*(3.784)*(tcb->m_segmentSize)*(15.057)*(cnt)*(23.872)*(69.972)*(88.034)*(tcb->m_cWnd)))+(92.541))/((47.853)));

} else {
	segmentsAcked = (int) (15.726*(10.334)*(14.264)*(51.264)*(48.557)*(46.824)*(69.096)*(63.81)*(66.795));
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (85.282*(87.164)*(47.011)*(segmentsAcked)*(96.306)*(27.946)*(78.424)*(64.574));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (73.781-(38.104)-(44.181)-(53.631)-(89.177)-(90.338)-(8.092)-(7.636)-(36.688));

} else {
	tcb->m_cWnd = (int) (83.456-(98.01)-(48.852));

}
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	segmentsAcked = (int) ((((13.357+(69.335)+(24.831)+(5.806)+(42.06)+(tcb->m_cWnd)))+(21.488)+(22.147)+((42.388-(27.346)))+(83.925))/((0.1)));

} else {
	segmentsAcked = (int) (27.179-(1.441)-(14.306));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
