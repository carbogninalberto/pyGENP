if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (cnt+(3.782)+(32.408)+(5.313)+(30.822));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (42.79*(76.778)*(86.278));

} else {
	tcb->m_segmentSize = (int) (20.25+(96.218)+(37.215)+(16.834));
	tcb->m_cWnd = (int) (36.456-(69.566)-(39.345)-(78.43)-(6.525)-(16.335)-(tcb->m_cWnd)-(53.959)-(45.402));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float ABMfzBEknhlCjWhP = (float) (90.099+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(88.401));
if (ABMfzBEknhlCjWhP != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (86.509-(58.169)-(25.512)-(30.839)-(28.951)-(cnt)-(16.718)-(53.512));
	tcb->m_cWnd = (int) (88.809+(19.915)+(15.684)+(91.161));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (8.78/0.1);

}
segmentsAcked = (int) (88.696-(segmentsAcked)-(40.993)-(70.79)-(53.546));
if (cnt == cnt) {
	tcb->m_ssThresh = (int) (44.353*(24.365)*(42.431)*(30.777)*(75.306)*(97.025)*(62.254)*(52.162)*(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (97.241/15.392);
	tcb->m_segmentSize = (int) (69.394-(28.636)-(14.855)-(segmentsAcked)-(47.852));

} else {
	tcb->m_ssThresh = (int) (72.059-(45.208)-(75.919));

}
ABMfzBEknhlCjWhP = (float) (tcb->m_ssThresh+(tcb->m_segmentSize)+(12.5)+(68.482)+(64.801));
int kYIxyfArosgWaYSs = (int) (26.202+(17.726)+(74.608)+(50.77)+(97.027)+(72.916)+(60.749)+(10.246));
