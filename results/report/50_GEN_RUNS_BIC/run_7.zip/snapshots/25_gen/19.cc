if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
cnt = (int) (((51.346)+(50.975)+(0.1)+(0.1)+(0.1))/((0.1)));
tcb->m_cWnd = (int) (tcb->m_cWnd*(3.312)*(53.939)*(40.538)*(84.017)*(4.985)*(56.706));
ReduceCwnd (tcb);
