ReduceCwnd (tcb);
int ymwnmJmLGhvyxscn = (int) (24.671-(tcb->m_segmentSize)-(44.715)-(tcb->m_segmentSize)-(65.905)-(68.946)-(46.16));
segmentsAcked = (int) (ymwnmJmLGhvyxscn+(cnt)+(90.464)+(39.842)+(8.797)+(ymwnmJmLGhvyxscn)+(tcb->m_ssThresh));
ymwnmJmLGhvyxscn = (int) (19.042-(92.988));
tcb->m_ssThresh = (int) (51.407*(tcb->m_ssThresh)*(94.612)*(22.765)*(99.414));
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(8.118)+(segmentsAcked)+(18.062)+(82.27)+(97.552)+(1.466));

} else {
	tcb->m_cWnd = (int) (cnt+(19.62)+(segmentsAcked)+(44.819)+(76.698)+(71.377)+(86.91));
	tcb->m_segmentSize = (int) (14.707+(2.167)+(91.025)+(22.723)+(46.577)+(45.465)+(tcb->m_ssThresh));
	segmentsAcked = (int) (76.508*(69.693)*(tcb->m_cWnd));

}
