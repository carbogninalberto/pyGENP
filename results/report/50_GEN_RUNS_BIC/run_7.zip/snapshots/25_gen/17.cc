ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (94.263-(75.956)-(82.233)-(tcb->m_cWnd));
if (tcb->m_ssThresh < cnt) {
	tcb->m_segmentSize = (int) (94.137+(53.644)+(55.923)+(25.27)+(67.683)+(46.919)+(22.216));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (39.325+(58.325)+(44.525)+(57.645)+(31.279)+(36.096)+(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(58.416)+(41.168)+(59.977)+(91.741)+(79.021));
cnt = (int) (((90.831)+(0.1)+(0.1)+((62.476+(91.084)+(19.536)+(8.412)+(65.682)+(segmentsAcked)+(46.18)+(77.268)+(15.656)))+(39.375)+(45.551)+(0.1))/((18.204)+(0.1)));
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_segmentSize = (int) ((21.287-(71.65)-(16.458)-(47.692)-(segmentsAcked)-(24.233)-(46.162)-(segmentsAcked))/0.1);
	tcb->m_cWnd = (int) (51.925*(tcb->m_ssThresh)*(86.399)*(34.261)*(55.324)*(94.384)*(tcb->m_ssThresh)*(66.19)*(50.249));

} else {
	tcb->m_segmentSize = (int) (43.526*(84.512));

}
