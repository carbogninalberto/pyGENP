if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (84.782+(cnt)+(19.051)+(tcb->m_segmentSize)+(16.972)+(71.278));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (65.019-(tcb->m_ssThresh)-(94.75)-(52.169)-(34.224)-(60.173)-(80.175)-(36.457)-(56.468));

}
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (34.507+(55.378)+(34.834)+(79.3)+(cnt)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(67.36));
	tcb->m_cWnd = (int) (66.053/54.721);
	tcb->m_cWnd = (int) (77.493*(22.305)*(62.447)*(85.453)*(56.925)*(36.754)*(tcb->m_segmentSize)*(79.873)*(37.103));

} else {
	tcb->m_ssThresh = (int) (0.1/27.393);
	cnt = (int) (43.583*(69.809)*(cnt)*(95.767)*(37.083)*(66.339));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (10.87*(35.959)*(70.86)*(tcb->m_ssThresh)*(97.336)*(91.185)*(segmentsAcked));
	segmentsAcked = (int) (9.977-(95.905)-(2.116));

} else {
	tcb->m_ssThresh = (int) (79.624*(78.546));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (39.114*(25.173)*(20.337));

}
