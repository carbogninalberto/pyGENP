segmentsAcked = (int) (77.286-(66.338));
int UpotoVFCpWqNdbaM = (int) (39.484+(segmentsAcked)+(19.182)+(cnt)+(75.532)+(segmentsAcked));
float qLSlkjMmwkyplSte = (float) (37.61+(UpotoVFCpWqNdbaM)+(24.078)+(94.92)+(tcb->m_segmentSize)+(96.693)+(cnt)+(UpotoVFCpWqNdbaM)+(97.372));
tcb->m_segmentSize = (int) (60.689*(tcb->m_cWnd)*(39.21)*(tcb->m_cWnd)*(18.783));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
