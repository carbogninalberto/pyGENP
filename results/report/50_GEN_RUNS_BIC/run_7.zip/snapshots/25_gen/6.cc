if (segmentsAcked > segmentsAcked) {
	tcb->m_ssThresh = (int) (47.976*(59.783)*(36.805)*(47.682)*(71.483)*(27.071)*(cnt));
	tcb->m_cWnd = (int) (83.163*(18.362)*(59.774)*(55.019));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (20.243*(81.592)*(tcb->m_ssThresh)*(42.465)*(97.157)*(cnt));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) ((41.992+(85.289)+(67.371))/0.1);
if (cnt <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((44.198)+(0.1)+((79.877-(25.468)-(tcb->m_segmentSize)-(65.54)-(71.733)-(46.033)))+(15.617)+((18.102*(95.852)*(tcb->m_cWnd)*(3.081)*(59.234)*(tcb->m_cWnd)*(92.411)*(26.922)*(79.415)))+(0.1)+(0.1))/((21.662)));
	cnt = (int) (51.433*(11.778)*(79.98)*(87.441)*(0.119)*(73.589)*(63.469)*(32.74));

} else {
	tcb->m_segmentSize = (int) (60.949-(99.909)-(45.332)-(10.724)-(8.868)-(32.55)-(20.654)-(58.354));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (48.797+(66.327)+(tcb->m_segmentSize)+(41.736)+(99.368)+(18.701));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
