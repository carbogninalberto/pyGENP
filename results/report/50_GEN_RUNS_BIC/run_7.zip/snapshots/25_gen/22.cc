ReduceCwnd (tcb);
if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (61.245+(1.442)+(87.373)+(27.004)+(26.308)+(tcb->m_cWnd)+(95.343)+(tcb->m_segmentSize)+(6.43));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (81.829-(29.046)-(57.874)-(77.886)-(35.088)-(92.562));
	tcb->m_cWnd = (int) (92.743/0.1);

}
cnt = (int) (97.917-(27.728));
tcb->m_ssThresh = (int) (0.1/(74.53+(26.736)+(79.304)));
tcb->m_cWnd = (int) (61.066*(53.377)*(42.231)*(95.57)*(59.455)*(19.02));
ReduceCwnd (tcb);
