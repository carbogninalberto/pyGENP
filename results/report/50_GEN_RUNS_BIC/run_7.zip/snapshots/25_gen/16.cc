if (cnt <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (42.591/0.1);
	cnt = (int) (47.275-(24.107)-(2.622)-(cnt)-(6.616)-(55.949)-(72.409)-(64.777));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(23.616));
	tcb->m_ssThresh = (int) (segmentsAcked*(29.804)*(56.67)*(tcb->m_ssThresh)*(94.74)*(71.501)*(90.23));
	tcb->m_cWnd = (int) (42.835*(2.877)*(58.935)*(48.822)*(7.755)*(69.641)*(77.488));

}
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (72.379-(98.989)-(20.062)-(segmentsAcked)-(69.134)-(42.685)-(98.677)-(tcb->m_cWnd)-(43.401));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (67.909-(10.046)-(49.507)-(99.979)-(35.035)-(86.479)-(53.306)-(76.261));
	tcb->m_cWnd = (int) (85.031-(22.642)-(15.794)-(9.372)-(82.071)-(93.192));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(segmentsAcked)*(segmentsAcked)*(66.133)*(90.572)*(tcb->m_cWnd)*(0.073)*(83.15)*(17.27));

}
tcb->m_ssThresh = (int) (tcb->m_segmentSize+(segmentsAcked)+(segmentsAcked)+(29.279)+(0.137)+(7.01)+(82.432)+(13.009));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
