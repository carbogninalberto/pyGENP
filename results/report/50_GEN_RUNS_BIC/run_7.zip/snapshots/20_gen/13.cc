cnt = (int) (27.482+(21.538)+(96.945));
tcb->m_cWnd = (int) (10.784+(20.785)+(77.899)+(15.966)+(cnt));
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_segmentSize = (int) (15.728-(71.726));

} else {
	tcb->m_segmentSize = (int) (16.225-(72.212)-(51.635)-(55.543)-(17.808)-(7.821)-(92.625)-(6.201)-(37.147));
	tcb->m_segmentSize = (int) (35.15+(80.967)+(49.247)+(tcb->m_cWnd)+(32.523));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	segmentsAcked = (int) (45.998*(58.295)*(85.301)*(70.786)*(66.752)*(59.32));
	tcb->m_segmentSize = (int) (42.234-(19.759)-(18.081));
	cnt = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (tcb->m_ssThresh-(18.936)-(segmentsAcked)-(90.907)-(16.692)-(4.919)-(41.713)-(39.12)-(tcb->m_ssThresh));

}
