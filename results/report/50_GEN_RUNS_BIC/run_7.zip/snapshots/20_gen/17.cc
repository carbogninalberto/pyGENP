if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_segmentSize = (int) (41.623-(32.092)-(1.206)-(segmentsAcked)-(35.985)-(43.13)-(88.271)-(30.933));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (62.859-(26.619)-(cnt)-(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (32.848+(5.085)+(67.737));
	tcb->m_ssThresh = (int) (42.441+(48.861)+(cnt)+(84.872));
	cnt = (int) (69.028-(93.858)-(81.285)-(55.097)-(tcb->m_segmentSize)-(39.014));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (86.359*(38.824)*(54.739));
tcb->m_cWnd = (int) (69.684+(27.919));
tcb->m_segmentSize = (int) (74.462-(cnt));
cnt = (int) (44.274+(59.766)+(70.984)+(43.113)+(24.048)+(70.135)+(tcb->m_segmentSize));
