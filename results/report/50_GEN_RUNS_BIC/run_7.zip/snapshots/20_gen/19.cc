if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked-(91.569)-(74.228)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(13.786));
	segmentsAcked = (int) (tcb->m_cWnd*(92.78)*(16.264)*(11.216));

} else {
	tcb->m_cWnd = (int) (77.907/80.891);

}
ReduceCwnd (tcb);
int jszQIdwRrltgCtPu = (int) (36.203-(23.757)-(40.811)-(6.097)-(93.649)-(40.526)-(segmentsAcked)-(48.052)-(11.809));
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (71.697-(99.587)-(jszQIdwRrltgCtPu)-(84.477));

} else {
	tcb->m_segmentSize = (int) (48.306+(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (0.1/70.979);
	segmentsAcked = (int) (34.662+(cnt)+(tcb->m_cWnd)+(74.549)+(jszQIdwRrltgCtPu)+(35.481)+(98.323));

}
tcb->m_ssThresh = (int) (0.1/0.1);
