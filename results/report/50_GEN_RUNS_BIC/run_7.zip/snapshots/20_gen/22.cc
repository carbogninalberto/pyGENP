tcb->m_cWnd = (int) (1.564-(tcb->m_ssThresh));
segmentsAcked = (int) (71.716+(tcb->m_ssThresh)+(48.603)+(16.028)+(60.817)+(48.461)+(tcb->m_cWnd)+(cnt));
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (68.636-(25.396)-(22.585));
	tcb->m_cWnd = (int) (7.839-(61.788)-(36.398)-(tcb->m_cWnd)-(93.962)-(11.439)-(44.769));
	tcb->m_ssThresh = (int) (23.942*(80.412)*(77.379)*(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (75.792+(70.738));
	segmentsAcked = (int) (15.423-(29.997)-(87.498)-(17.055)-(11.155));
	tcb->m_segmentSize = (int) (58.417-(44.688)-(37.706)-(59.523)-(cnt));

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (99.21/0.1);
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(48.69)*(57.724)*(68.083)*(32.225)*(13.158)*(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (48.404-(52.405)-(tcb->m_cWnd)-(cnt));

} else {
	tcb->m_cWnd = (int) (81.799*(26.675)*(81.318)*(72.594));
	segmentsAcked = (int) (((68.236)+(0.1)+(0.1)+(0.1)+(74.327))/((0.1)));

}
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (88.244*(89.029)*(tcb->m_ssThresh)*(54.442)*(30.772)*(16.62)*(30.507));

} else {
	tcb->m_segmentSize = (int) (71.416*(84.886)*(tcb->m_segmentSize)*(17.999)*(66.637));
	cnt = (int) (48.555*(49.622)*(45.216)*(80.958)*(9.138));

}
tcb->m_ssThresh = (int) (((34.251)+((11.972*(0.599)))+((54.151-(cnt)-(57.007)-(57.743)-(61.911)))+(0.1)+(26.988))/((0.1)));
segmentsAcked = (int) (29.98-(33.631)-(2.587)-(90.117)-(62.512)-(60.825)-(tcb->m_segmentSize)-(19.634)-(45.967));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (72.84+(93.35)+(63.61)+(44.588)+(98.853)+(3.166)+(7.055));
	cnt = (int) (22.484*(tcb->m_segmentSize)*(segmentsAcked)*(38.151)*(91.076)*(28.01)*(43.853)*(segmentsAcked)*(11.828));

} else {
	tcb->m_ssThresh = (int) (66.739*(91.443)*(40.804)*(28.168));

}
