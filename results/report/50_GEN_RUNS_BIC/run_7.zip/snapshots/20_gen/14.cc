if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (80.46+(52.566)+(tcb->m_cWnd)+(76.598)+(tcb->m_cWnd)+(17.412)+(56.238)+(28.919));
	cnt = (int) (27.977*(61.894));

} else {
	tcb->m_ssThresh = (int) (25.963+(83.542)+(47.702)+(35.345)+(34.978)+(0.813)+(7.506));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (55.592/0.1);
segmentsAcked = (int) (95.102*(31.454)*(tcb->m_cWnd)*(tcb->m_cWnd));
tcb->m_segmentSize = (int) (86.161*(84.888)*(97.669));
ReduceCwnd (tcb);
