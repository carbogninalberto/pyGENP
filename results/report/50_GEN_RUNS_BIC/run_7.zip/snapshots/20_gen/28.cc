if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (93.708+(46.717)+(8.101)+(cnt)+(tcb->m_segmentSize)+(segmentsAcked)+(53.56)+(46.766));
	cnt = (int) (89.464/55.656);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (38.737*(3.818)*(29.495));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd > tcb->m_segmentSize) {
	cnt = (int) (83.046-(77.204)-(24.657)-(7.585)-(0.178));

} else {
	cnt = (int) (((50.826)+(22.921)+(0.1)+(87.307))/((0.1)+(0.1)+(0.1)+(0.1)));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
float mQsLacthwZKvllid = (float) (cnt-(5.767)-(76.227));
