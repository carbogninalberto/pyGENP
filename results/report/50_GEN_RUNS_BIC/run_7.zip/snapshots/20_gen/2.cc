if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_cWnd <= tcb->m_cWnd) {
	segmentsAcked = (int) ((((62.528+(58.094)+(tcb->m_ssThresh)+(82.472)+(46.71)+(90.903)))+(31.465)+(22.561)+(0.1))/((0.1)));
	tcb->m_segmentSize = (int) (12.844*(15.756)*(segmentsAcked)*(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (53.842*(87.34)*(segmentsAcked)*(5.842)*(23.388));

} else {
	segmentsAcked = (int) (69.434-(59.774)-(segmentsAcked)-(38.824));

}
