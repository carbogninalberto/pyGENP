ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-6.037+(56.815)+(54.348)+(19.792)+(45.255)+(8.597)+(15.417)+(-51.162)+(48.537));
segmentsAcked = (int) (-93.736+(89.828)+(-15.374)+(-49.677));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-8.312+(-85.479)+(-11.007)+(96.904)+(72.897)+(85.563)+(-83.218)+(76.355)+(4.292));
segmentsAcked = (int) (51.639+(-5.738)+(-33.6)+(-64.25));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
