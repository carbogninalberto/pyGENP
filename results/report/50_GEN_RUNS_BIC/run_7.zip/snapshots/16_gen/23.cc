if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked+(97.048)+(47.323));

} else {
	tcb->m_segmentSize = (int) (59.299+(3.869)+(tcb->m_segmentSize)+(33.842));
	tcb->m_segmentSize = (int) (0.833*(tcb->m_ssThresh)*(37.755)*(47.249));
	tcb->m_cWnd = (int) (95.778*(60.105)*(14.442)*(87.337));

}
tcb->m_cWnd = (int) (((0.1)+((68.705*(cnt)*(5.26)*(58.255)*(62.019)*(30.454)*(tcb->m_segmentSize)*(91.261)*(62.761)))+((51.682*(61.959)))+((11.216*(44.519)*(29.918)*(53.816)*(39.241)*(68.032)*(88.649)*(tcb->m_segmentSize)))+(0.1))/((33.806)+(59.3)+(47.941)));
tcb->m_cWnd = (int) (14.574-(15.128)-(9.345)-(52.497)-(66.064));
cnt = (int) (0.1/79.161);
ReduceCwnd (tcb);
float CpwPoqmNJQQpBMcF = (float) (59.726*(82.268)*(88.768));
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_ssThresh = (int) (27.84-(52.033)-(66.457)-(segmentsAcked)-(93.053)-(cnt)-(54.611)-(71.94));
	CpwPoqmNJQQpBMcF = (float) (83.67-(98.642)-(tcb->m_cWnd)-(CpwPoqmNJQQpBMcF)-(86.627));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
