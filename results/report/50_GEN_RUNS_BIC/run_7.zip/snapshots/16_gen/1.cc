int hLmsRzabmouoaUzp = (int) (27.613-(-7.997)-(10.685)-(-3.421)-(-78.709)-(-0.337)-(-51.642)-(75.62)-(95.181));
segmentsAcked = (int) (((15.537)+(72.11)+(-86.057)+(-28.324))/((-81.228)));
int xivmrmUZerpyhgPc = (int) (((29.438)+(24.187)+(45.69)+((-59.547+(48.039)+(-52.643)+(-2.984)+(-27.563)+(38.818)+(54.316)))+(69.988)+(67.333)+((-53.368+(56.16)+(-21.351)+(-92.498)))+(-21.543))/((-46.057)));
tcb->m_cWnd = (int) (-65.323*(-75.928)*(16.229));
segmentsAcked = (int) (((-69.565)+(53.208)+(-83.44)+(-71.762))/((-89.243)));
tcb->m_cWnd = (int) (-27.004*(-2.727)*(-43.85));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((-55.681)+(13.926)+(-6.544)+(55.699))/((-61.178)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-23.129*(-66.196)*(17.866));
tcb->m_cWnd = (int) (-89.391*(-50.089)*(-81.571));
segmentsAcked = (int) (((-38.964)+(-7.007)+(-46.511)+(-47.68))/((-81.562)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (19.934*(47.035)*(-54.954));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-49.152*(-54.44)*(-73.93));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
