float vnmrBxBHUDrIvXay = (float) ((-70.94-(75.21)-(76.729)-(-31.164))/83.551);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
