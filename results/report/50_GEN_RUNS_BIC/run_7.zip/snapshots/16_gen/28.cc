tcb->m_ssThresh = (int) ((((segmentsAcked*(60.663)*(21.505)*(cnt)*(10.327)*(8.837)*(35.203)*(25.903)))+(0.1)+((tcb->m_ssThresh*(segmentsAcked)*(10.54)*(61.924)*(3.973)*(tcb->m_ssThresh)*(36.439)*(53.14)))+((66.773+(cnt)+(98.498)+(49.329)+(42.828)+(4.51)+(43.693)+(20.909)))+(42.079))/((0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((92.593-(0.237)-(60.904))/0.1);
tcb->m_segmentSize = (int) (47.238*(10.816)*(53.571)*(43.98));
float lUgJCGdyBFGIjmiW = (float) (((37.074)+(0.1)+((48.894+(36.802)+(11.351)+(49.875)+(tcb->m_segmentSize)+(62.316)))+(0.1)+(0.1))/((7.315)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
