ReduceCwnd (tcb);
cnt = (int) (51.541+(78.856)+(64.485)+(tcb->m_segmentSize)+(9.586)+(21.091)+(23.991)+(tcb->m_cWnd));
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (49.376+(55.694)+(83.217)+(61.407)+(43.765)+(43.364)+(88.255));

} else {
	tcb->m_ssThresh = (int) (82.808-(segmentsAcked)-(23.818));
	tcb->m_segmentSize = (int) (69.726*(43.668)*(87.107)*(79.352)*(48.353));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh < tcb->m_cWnd) {
	segmentsAcked = (int) (85.417+(99.001));

} else {
	segmentsAcked = (int) (16.873-(6.489)-(12.134)-(47.724)-(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (cnt-(35.804));
	tcb->m_segmentSize = (int) (57.961-(36.889)-(22.578)-(92.559)-(tcb->m_cWnd)-(0.1)-(19.588));

}
segmentsAcked = (int) (33.486-(12.689)-(49.775)-(tcb->m_cWnd)-(49.698)-(72.067)-(42.361)-(segmentsAcked));
ReduceCwnd (tcb);
