ReduceCwnd (tcb);
int AkfbqdPuDggjKzQt = (int) 11.417;
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
AkfbqdPuDggjKzQt = (int) (((-30.162)+(79.515)+(73.103)+(61.504))/((53.875)));
