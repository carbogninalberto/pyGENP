cnt = (int) (48.705*(84.581)*(cnt)*(65.978)*(41.208)*(44.355)*(66.135)*(13.067)*(18.277));
cnt = (int) (0.1/83.581);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	cnt = (int) (10.972-(34.404)-(tcb->m_cWnd));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (80.79-(39.19)-(tcb->m_ssThresh)-(70.989)-(23.079)-(62.869)-(tcb->m_ssThresh)-(39.095));
	tcb->m_ssThresh = (int) (35.554*(43.942)*(tcb->m_ssThresh)*(77.836)*(67.483));

}
cnt = (int) (15.599+(7.539)+(tcb->m_ssThresh)+(82.294));
