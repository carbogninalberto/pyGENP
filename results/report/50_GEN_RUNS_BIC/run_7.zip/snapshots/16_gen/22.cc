cnt = (int) (94.795+(36.11)+(3.166)+(24.116)+(64.071)+(80.928));
ReduceCwnd (tcb);
if (tcb->m_segmentSize == cnt) {
	tcb->m_ssThresh = (int) (0.1/41.756);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (26.788-(6.077)-(tcb->m_segmentSize)-(63.487)-(26.832));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (35.573*(42.43)*(39.215)*(92.776)*(33.324)*(25.809));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (72.848*(55.111)*(43.24)*(85.913)*(45.018)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(4.618)*(9.282));
tcb->m_ssThresh = (int) (1.437-(20.209)-(32.609)-(tcb->m_segmentSize)-(4.775)-(76.371)-(9.375)-(9.234));
tcb->m_cWnd = (int) (((0.1)+(0.1)+((83.0*(98.757)*(65.025)*(cnt)*(12.405)))+(0.1)+(0.1)+(0.1)+(62.201))/((0.1)));
