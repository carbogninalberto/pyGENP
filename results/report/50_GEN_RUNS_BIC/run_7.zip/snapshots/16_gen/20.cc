if (tcb->m_segmentSize != tcb->m_ssThresh) {
	segmentsAcked = (int) (50.571-(37.104)-(segmentsAcked)-(4.971)-(51.032));
	segmentsAcked = (int) (59.97-(tcb->m_cWnd)-(25.27)-(72.413)-(64.885)-(39.652)-(cnt));

} else {
	segmentsAcked = (int) (31.583-(18.043)-(63.227)-(21.009)-(95.423)-(21.924)-(81.503)-(56.872)-(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (50.078-(14.879)-(42.584)-(40.298)-(22.611)-(31.71));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_cWnd = (int) (((9.244)+(63.082)+(67.101)+(45.855)+(0.1)+(0.1))/((66.744)));
	tcb->m_ssThresh = (int) (74.175-(60.381)-(48.483)-(95.733)-(83.851)-(41.987)-(76.726)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (((0.1)+(91.22)+(43.968)+(52.156)+(93.332))/((40.268)));

}
tcb->m_segmentSize = (int) (78.068*(47.269)*(76.463)*(tcb->m_ssThresh)*(51.953)*(77.324)*(79.155));
if (cnt > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (68.706*(50.327));
	tcb->m_cWnd = (int) (90.649-(92.779));
	tcb->m_ssThresh = (int) (13.482+(88.279)+(44.67)+(41.238)+(92.867));

} else {
	tcb->m_segmentSize = (int) (99.288*(28.35)*(0.782)*(83.786)*(43.993)*(78.117)*(78.211)*(segmentsAcked)*(54.294));

}
ReduceCwnd (tcb);
