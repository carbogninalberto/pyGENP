int hLmsRzabmouoaUzp = (int) (-44.805-(25.098)-(-16.295)-(39.193)-(-75.451)-(97.916)-(64.446)-(37.202)-(-65.217));
segmentsAcked = (int) (((-80.704)+(-87.944)+(-76.705)+(-56.271))/((-20.58)));
int xivmrmUZerpyhgPc = (int) (((92.448)+(32.974)+(-8.896)+((-56.002+(84.085)+(-81.882)+(-89.365)+(44.691)+(31.737)+(39.392)))+(90.827)+(-7.964)+((7.241+(-12.722)+(-13.784)+(-91.315)))+(-76.598))/((-25.292)));
tcb->m_cWnd = (int) (-36.949*(-62.533)*(-65.956));
segmentsAcked = (int) (((34.272)+(-21.641)+(73.012)+(-9.804))/((38.652)));
tcb->m_cWnd = (int) (46.491*(62.727)*(44.017));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (44.758*(-79.135)*(82.857));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
