ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) ((tcb->m_cWnd-(49.153)-(tcb->m_segmentSize)-(-21.642)-(-53.512))/-9.136);
