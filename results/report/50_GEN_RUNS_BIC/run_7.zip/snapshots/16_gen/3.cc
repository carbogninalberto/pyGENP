if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (26.926/14.876);
	tcb->m_cWnd = (int) (81.495*(76.917));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (56.7+(42.512)+(18.034)+(22.516));

}
tcb->m_cWnd = (int) (58.711+(3.978)+(17.435)+(13.648)+(-61.024)+(-83.199)+(-91.636)+(19.06)+(-27.073));
segmentsAcked = (int) (50.611+(-10.775)+(-21.897)+(-98.336));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
