tcb->m_ssThresh = (int) (0.1/29.78);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (77.31*(27.484)*(tcb->m_cWnd)*(76.44)*(31.604)*(97.608)*(cnt)*(37.774)*(tcb->m_ssThresh));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (32.801-(33.652)-(51.128));
tcb->m_segmentSize = (int) (((78.643)+(34.88)+(0.1)+(0.1))/((93.912)+(24.855)+(75.198)+(0.1)+(99.138)));
