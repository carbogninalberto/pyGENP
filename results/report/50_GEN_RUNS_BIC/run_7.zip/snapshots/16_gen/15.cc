if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (72.308+(tcb->m_ssThresh)+(95.268)+(segmentsAcked)+(89.92)+(83.119)+(84.601));
if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (33.222-(tcb->m_ssThresh)-(81.698)-(27.722)-(68.358)-(95.459)-(95.992)-(14.571)-(16.429));
	tcb->m_cWnd = (int) (38.228/9.293);

} else {
	tcb->m_ssThresh = (int) (65.968*(tcb->m_ssThresh)*(72.74)*(39.18)*(89.087)*(90.484));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(tcb->m_cWnd)+(59.093)+(99.228)+(25.084)+(22.672)+(32.979));
	tcb->m_cWnd = (int) (3.718*(61.974)*(31.838)*(60.912)*(32.313)*(60.667)*(tcb->m_cWnd)*(tcb->m_cWnd));
	cnt = (int) (10.037*(26.882)*(42.668)*(tcb->m_cWnd)*(12.188)*(10.612)*(43.461)*(98.122));

} else {
	tcb->m_segmentSize = (int) (97.181+(17.604)+(tcb->m_segmentSize)+(48.783)+(20.76)+(7.446)+(12.595)+(cnt)+(87.007));

}
tcb->m_segmentSize = (int) (91.35-(86.893)-(30.437)-(61.785)-(78.169)-(62.686));
ReduceCwnd (tcb);
