tcb->m_segmentSize = (int) (0.1/0.1);
tcb->m_cWnd = (int) (37.351-(38.976));
segmentsAcked = (int) (0.1/0.1);
float PhcUrJaJfMjGUqfp = (float) (23.259/0.1);
segmentsAcked = (int) (58.061/62.146);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float jbMvLgzieGPAQoba = (float) (17.922-(76.782));
