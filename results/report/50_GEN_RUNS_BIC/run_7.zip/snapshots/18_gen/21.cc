tcb->m_cWnd = (int) ((4.58*(segmentsAcked)*(47.168)*(13.322)*(43.233)*(98.532)*(61.141))/60.496);
tcb->m_cWnd = (int) (50.457/0.1);
tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+((77.034+(62.601)+(48.673)+(tcb->m_cWnd)+(55.622)+(tcb->m_cWnd)+(50.223)))+((4.244*(60.986)*(90.276)*(89.085)*(45.342)*(61.265)*(96.618)))+(2.243))/((31.84)));
tcb->m_cWnd = (int) (80.154*(83.151)*(18.419)*(segmentsAcked)*(12.896)*(cnt));
if (cnt == tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((68.615*(tcb->m_ssThresh)*(cnt)*(60.501)*(tcb->m_segmentSize)*(1.286)*(tcb->m_segmentSize))/28.2);

} else {
	tcb->m_cWnd = (int) (78.995-(cnt)-(61.874)-(14.753)-(85.809)-(87.062)-(37.674)-(14.369));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_cWnd = (int) (cnt*(78.862)*(25.075)*(57.62)*(cnt));
