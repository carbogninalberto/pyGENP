int CUCCxdotfPUZMkeb = (int) (((37.875)+(91.388)+(-35.596)+(23.693))/((54.223)));
tcb->m_segmentSize = (int) (-69.988-(-40.003));
segmentsAcked = (int) (-42.963*(3.751)*(37.7)*(91.701)*(78.577)*(-29.482)*(-84.058)*(-57.618));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
