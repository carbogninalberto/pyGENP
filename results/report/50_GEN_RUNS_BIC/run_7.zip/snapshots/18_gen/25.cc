ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt == tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/42.604);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (33.106*(23.417)*(15.102)*(98.797)*(50.398));
	tcb->m_cWnd = (int) (20.351+(90.921));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd <= segmentsAcked) {
	segmentsAcked = (int) (0.1/5.971);
	cnt = (int) (14.597-(segmentsAcked)-(35.418)-(tcb->m_ssThresh)-(90.235)-(segmentsAcked)-(36.606));
	tcb->m_ssThresh = (int) (99.498+(92.375)+(40.973));

} else {
	segmentsAcked = (int) (86.256+(40.789)+(tcb->m_segmentSize)+(93.198)+(segmentsAcked)+(61.913));
	segmentsAcked = (int) ((((tcb->m_ssThresh*(87.189)*(tcb->m_ssThresh)*(78.369)*(54.243)))+(32.072)+(9.333)+(0.1))/((0.1)+(92.524)+(37.216)+(76.69)));

}
segmentsAcked = (int) (1.595-(76.776)-(69.74)-(73.176)-(15.971)-(tcb->m_segmentSize));
