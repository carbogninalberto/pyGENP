ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/(5.422-(93.25)-(tcb->m_ssThresh)-(21.785)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (33.269*(33.39)*(39.906)*(cnt)*(22.481));

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(96.012)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(30.999)-(50.494));
	tcb->m_segmentSize = (int) ((((2.855-(53.837)-(3.322)-(59.817)-(83.599)-(34.285)-(27.654)-(70.3)))+(65.689)+(0.1)+(0.1))/((0.1)));

}
if (cnt < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (9.876-(37.672)-(36.948)-(35.424)-(39.822)-(14.319)-(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (37.523/16.287);

} else {
	tcb->m_ssThresh = (int) (31.134+(68.139)+(tcb->m_cWnd)+(85.69));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
int UOqkqkekxXSXudEh = (int) (6.699+(37.751)+(tcb->m_cWnd));
segmentsAcked = (int) (29.212-(cnt)-(90.644)-(22.823)-(64.693)-(26.661));
if (UOqkqkekxXSXudEh >= UOqkqkekxXSXudEh) {
	segmentsAcked = (int) (86.761+(tcb->m_segmentSize)+(39.814)+(41.343)+(tcb->m_ssThresh)+(segmentsAcked));
	cnt = (int) (85.089+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(13.532)+(UOqkqkekxXSXudEh)+(9.779)+(tcb->m_segmentSize)+(tcb->m_segmentSize));
	UOqkqkekxXSXudEh = (int) (58.216-(UOqkqkekxXSXudEh)-(16.41)-(50.202)-(34.681)-(UOqkqkekxXSXudEh)-(7.588)-(45.956));

} else {
	segmentsAcked = (int) (((0.1)+(1.917)+(0.1)+(30.93))/((97.385)+(42.551)));

}
cnt = (int) (((48.892)+(0.1)+(0.1)+(94.613)+(36.933)+(53.822)+(0.1)+(22.144))/((0.1)));
