segmentsAcked = (int) (-5.008*(-78.625)*(-58.851)*(-81.984)*(-73.096)*(13.278)*(24.422)*(-65.321));
int HUfieJxTDmWktmGA = (int) (9.849*(-51.214)*(-15.961)*(28.687));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
