int JhKjLgckPYlBMFJB = (int) (29.033+(50.715)+(97.871)+(41.865)+(97.202)+(71.103)+(25.592));
int vRfFtOnlGRYkjHoQ = (int) (18.862+(13.442)+(23.518)+(43.522));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (vRfFtOnlGRYkjHoQ == segmentsAcked) {
	cnt = (int) (31.337*(86.195)*(59.031));
	cnt = (int) (54.027-(40.83)-(23.983)-(11.677)-(58.098)-(33.141)-(74.938)-(vRfFtOnlGRYkjHoQ)-(51.18));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (5.65+(54.918)+(58.997)+(tcb->m_segmentSize)+(62.461)+(68.134)+(83.563));
	JhKjLgckPYlBMFJB = (int) (8.557*(94.376)*(95.244)*(7.302)*(75.664)*(31.905)*(tcb->m_segmentSize)*(2.702));

}
if (tcb->m_segmentSize > vRfFtOnlGRYkjHoQ) {
	tcb->m_ssThresh = (int) (97.898-(tcb->m_segmentSize)-(94.447)-(70.997)-(75.842)-(83.302)-(24.018)-(45.909)-(82.471));
	vRfFtOnlGRYkjHoQ = (int) (3.157*(0.296)*(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) ((49.017+(82.415))/35.207);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (12.144-(55.861)-(vRfFtOnlGRYkjHoQ));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt <= tcb->m_cWnd) {
	segmentsAcked = (int) (((47.385)+(0.1)+((cnt+(49.794)+(29.975)+(53.203)+(47.104)+(59.732)))+(35.213)+(0.1)+(5.95))/((3.403)));
	tcb->m_segmentSize = (int) (24.085+(12.603));
	tcb->m_cWnd = (int) (93.396-(75.73)-(90.714)-(45.008)-(53.861)-(67.703)-(27.407));

} else {
	segmentsAcked = (int) (vRfFtOnlGRYkjHoQ*(92.982)*(84.071)*(20.624)*(71.642)*(1.927)*(66.687)*(39.63)*(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
