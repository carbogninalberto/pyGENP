cnt = (int) (53.171*(67.895)*(tcb->m_segmentSize));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < cnt) {
	tcb->m_ssThresh = (int) (50.275-(cnt)-(92.342)-(52.639)-(67.031)-(segmentsAcked)-(93.007)-(54.767)-(85.518));

} else {
	tcb->m_ssThresh = (int) (80.791*(cnt)*(95.371)*(25.585)*(6.901)*(94.734));
	cnt = (int) (48.737-(96.331)-(76.257)-(20.199)-(35.624)-(58.168));

}
tcb->m_ssThresh = (int) (30.302*(tcb->m_ssThresh)*(55.222)*(11.612));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (16.364+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(49.086));
	segmentsAcked = (int) (82.26-(24.399));
	tcb->m_ssThresh = (int) (63.577*(24.039)*(segmentsAcked)*(72.742)*(20.589)*(10.962)*(22.475)*(tcb->m_cWnd)*(94.572));

}
