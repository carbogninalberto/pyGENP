tcb->m_ssThresh = (int) (30.277/29.758);
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (52.312+(51.888)+(92.567)+(65.875)+(93.937));
	tcb->m_ssThresh = (int) (21.812+(31.125)+(tcb->m_cWnd)+(80.256)+(25.273)+(segmentsAcked));

} else {
	tcb->m_segmentSize = (int) (74.64-(69.587)-(36.925)-(99.506)-(cnt)-(10.206));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(53.729)*(9.525)*(29.02)*(77.04)*(52.152)*(tcb->m_cWnd)*(49.355));
	tcb->m_ssThresh = (int) (0.1/38.965);

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (32.337-(7.637)-(69.146)-(1.466)-(41.811)-(94.466)-(69.059)-(55.625)-(35.008));
	cnt = (int) ((((85.595*(71.699)*(31.361)*(cnt)*(9.245)*(75.656)*(tcb->m_segmentSize)))+((cnt*(tcb->m_segmentSize)*(cnt)*(62.172)))+(0.1)+(71.153)+(36.535)+(40.329)+(0.1)+(63.129))/((19.502)));

} else {
	tcb->m_cWnd = (int) (71.812+(41.892)+(91.422)+(11.79)+(68.792)+(84.365)+(47.36)+(85.431));
	tcb->m_segmentSize = (int) ((((74.581*(80.349)*(16.11)*(cnt)*(cnt)))+(0.1)+(0.1)+(0.1)+(37.849))/((0.1)));
	cnt = (int) (tcb->m_segmentSize*(62.357)*(79.03)*(13.248)*(80.062)*(37.422));

}
float tTnSGbmPWvlqNYFC = (float) (34.98/0.1);
tTnSGbmPWvlqNYFC = (float) (65.797*(79.31)*(80.337)*(tcb->m_cWnd)*(cnt)*(tcb->m_ssThresh)*(42.592));
tTnSGbmPWvlqNYFC = (float) (15.385+(38.587)+(87.805)+(99.617)+(7.347)+(tcb->m_segmentSize)+(59.877));
ReduceCwnd (tcb);
