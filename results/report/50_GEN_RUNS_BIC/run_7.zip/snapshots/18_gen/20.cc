if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (85.686*(80.63)*(80.869)*(55.169)*(segmentsAcked)*(71.729)*(46.68)*(74.259));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(77.386)-(tcb->m_segmentSize)-(42.472));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(58.62)*(90.95)*(94.903)*(53.487)*(39.047)*(tcb->m_segmentSize)*(20.292)*(80.613));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked != cnt) {
	tcb->m_cWnd = (int) (16.095*(27.15)*(94.43)*(24.261)*(81.822)*(37.92)*(89.119)*(29.795));
	tcb->m_segmentSize = (int) (6.099-(55.031)-(29.617));

} else {
	tcb->m_cWnd = (int) (87.898-(84.411)-(38.942)-(52.346)-(95.297)-(22.302));
	tcb->m_cWnd = (int) (59.155*(81.868)*(tcb->m_cWnd)*(78.71)*(78.272)*(2.742)*(57.859)*(69.144)*(12.079));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/0.1);
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) ((86.226-(77.096)-(44.551))/61.171);
	tcb->m_segmentSize = (int) (76.667/25.294);

}
tcb->m_cWnd = (int) ((((tcb->m_cWnd*(67.221)*(2.382)*(85.443)*(92.441)*(32.25)*(segmentsAcked)*(97.126)))+((segmentsAcked+(62.783)+(85.652)))+(37.38)+(97.606)+(0.1)+(30.625))/((0.1)));
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (72.252+(26.482)+(14.223));
	cnt = (int) (53.601+(cnt));

} else {
	tcb->m_ssThresh = (int) (69.85+(46.218)+(45.279)+(35.881)+(52.162)+(12.057)+(95.267));
	tcb->m_ssThresh = (int) ((((41.372*(30.519)*(45.817)))+(0.1)+(0.1)+(94.898)+((43.321+(48.028)+(64.45)+(46.924)))+(60.807))/((0.1)));

}
