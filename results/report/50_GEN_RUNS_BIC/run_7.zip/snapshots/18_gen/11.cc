if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > cnt) {
	cnt = (int) (10.499/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (65.982-(22.219)-(0.802)-(segmentsAcked));

} else {
	cnt = (int) (40.896-(38.951));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (61.114-(54.245)-(38.461)-(39.062));

} else {
	tcb->m_cWnd = (int) (21.019/(11.925-(29.417)-(19.44)-(24.421)-(76.665)-(54.935)-(88.527)-(tcb->m_cWnd)-(71.614)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(32.371)*(84.089)*(3.467)*(80.39)*(70.526));
	segmentsAcked = (int) (43.839*(44.818)*(10.81)*(1.377)*(13.138)*(25.219)*(24.312)*(11.429)*(48.94));

}
tcb->m_segmentSize = (int) (52.261+(84.342)+(46.21)+(61.368));
