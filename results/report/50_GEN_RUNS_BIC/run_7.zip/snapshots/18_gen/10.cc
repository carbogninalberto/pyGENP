ReduceCwnd (tcb);
tcb->m_cWnd = (int) (66.195/50.254);
segmentsAcked = (int) (87.455+(54.02)+(51.134)+(6.183)+(10.613)+(28.299)+(59.191));
tcb->m_ssThresh = (int) (66.074+(64.784)+(87.564)+(73.028)+(tcb->m_segmentSize)+(45.679)+(3.509)+(45.062));
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (87.778-(99.425)-(cnt)-(14.988)-(27.584));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (0.1/64.122);
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(tcb->m_ssThresh));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= cnt) {
	tcb->m_ssThresh = (int) (70.291+(tcb->m_ssThresh)+(32.398)+(44.724)+(tcb->m_cWnd));
	segmentsAcked = (int) (tcb->m_segmentSize-(8.514)-(58.888)-(tcb->m_ssThresh));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(70.559));
	cnt = (int) (53.807-(39.628)-(72.696)-(93.872)-(58.193)-(12.265)-(80.525)-(55.054));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((0.1)+((70.309+(92.634)+(21.508)+(cnt)))+(85.862)+(0.1))/((0.1)+(52.293)+(0.1)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (13.303+(81.951)+(39.955)+(35.458)+(segmentsAcked)+(tcb->m_ssThresh)+(10.901));

}
