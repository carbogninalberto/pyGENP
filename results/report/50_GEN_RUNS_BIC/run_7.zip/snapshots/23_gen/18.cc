tcb->m_cWnd = (int) (43.665*(43.956)*(39.875)*(56.824)*(41.967)*(30.507)*(32.977)*(40.408));
int ypagcpOfPNSSdTRW = (int) (10.418-(99.459)-(6.091)-(25.795));
int DsQVRNisNconzNOX = (int) (96.189/28.776);
tcb->m_ssThresh = (int) (tcb->m_cWnd*(84.631));
if (cnt >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (84.049+(26.296)+(54.945)+(86.492)+(92.693)+(60.957)+(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (20.503/0.1);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
