tcb->m_cWnd = (int) (71.349-(84.553)-(62.796)-(8.464)-(27.515)-(49.415)-(24.992)-(38.466));
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_cWnd = (int) (52.351*(33.689)*(cnt)*(53.178)*(15.828)*(41.832));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (65.753*(52.001)*(63.543)*(cnt));

} else {
	tcb->m_cWnd = (int) (0.1/29.828);
	tcb->m_cWnd = (int) (tcb->m_cWnd-(98.475)-(88.023)-(cnt)-(71.174));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) (((86.005)+(57.11)+(0.1)+(25.308)+(0.1)+((34.307+(29.364)+(94.206)))+(28.33))/((0.1)+(0.1)));
	tcb->m_cWnd = (int) (78.365*(36.121)*(35.472));
	tcb->m_cWnd = (int) (77.589-(6.102)-(98.789)-(67.311)-(95.769)-(segmentsAcked)-(90.174)-(99.477)-(74.725));

} else {
	segmentsAcked = (int) (91.64/(11.734-(51.653)));
	segmentsAcked = (int) (tcb->m_cWnd*(88.901)*(68.857)*(tcb->m_segmentSize)*(63.914)*(73.495));

}
if (cnt >= tcb->m_cWnd) {
	segmentsAcked = (int) (98.977+(tcb->m_cWnd)+(segmentsAcked)+(74.108)+(26.034)+(cnt));
	tcb->m_ssThresh = (int) (24.617/0.1);

} else {
	segmentsAcked = (int) (71.729+(50.591)+(segmentsAcked));
	tcb->m_cWnd = (int) (segmentsAcked-(31.998)-(25.476)-(19.972)-(21.961)-(22.119));

}
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_ssThresh = (int) (98.559-(cnt)-(77.847)-(99.905)-(13.086)-(86.43)-(1.209)-(54.223));
	tcb->m_ssThresh = (int) (78.656-(48.753)-(70.902)-(cnt));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (8.104-(segmentsAcked)-(33.668)-(89.301)-(18.094)-(53.636)-(33.251)-(91.049)-(74.778));

}
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	segmentsAcked = (int) (((0.1)+(0.1)+(41.008)+(24.723)+(65.097))/((5.481)+(0.1)));

} else {
	segmentsAcked = (int) (94.051-(39.879)-(76.616)-(42.31)-(47.921)-(91.366)-(tcb->m_segmentSize));

}
tcb->m_cWnd = (int) (66.288*(97.991)*(70.413)*(21.917)*(84.68));
tcb->m_ssThresh = (int) (85.38/0.1);
