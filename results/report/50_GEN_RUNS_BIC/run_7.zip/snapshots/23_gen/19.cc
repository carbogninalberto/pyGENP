if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= tcb->m_cWnd) {
	cnt = (int) (82.87+(tcb->m_cWnd)+(tcb->m_ssThresh)+(97.369)+(40.571));
	cnt = (int) (52.622+(tcb->m_ssThresh)+(35.819));

} else {
	cnt = (int) (94.112*(97.256)*(99.369)*(61.611)*(90.344)*(0.817)*(70.147));
	tcb->m_cWnd = (int) (((4.157)+(0.1)+(0.1)+(0.1))/((0.1)+(86.167)));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_segmentSize = (int) (52.936-(28.409)-(tcb->m_cWnd)-(80.766)-(tcb->m_cWnd)-(65.203)-(33.227));

} else {
	tcb->m_segmentSize = (int) (46.008/(2.271*(87.339)*(59.104)));

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh == cnt) {
	tcb->m_segmentSize = (int) (95.245+(78.012)+(24.824)+(63.144)+(7.875)+(67.673)+(segmentsAcked)+(18.612)+(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (35.611/0.1);

} else {
	tcb->m_segmentSize = (int) (0.1/40.417);

}
