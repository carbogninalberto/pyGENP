int FjggPeSMLGKkCNSh = (int) (53.378+(53.828)+(tcb->m_segmentSize)+(28.014)+(tcb->m_cWnd)+(21.012)+(segmentsAcked)+(40.193));
tcb->m_cWnd = (int) (FjggPeSMLGKkCNSh-(39.916)-(34.324)-(97.381));
ReduceCwnd (tcb);
int EhFpcWJWZQsqTDdP = (int) (0.1/0.1);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (78.247/56.307);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (24.176-(29.611)-(85.947)-(segmentsAcked)-(82.516)-(13.91)-(8.398)-(15.466)-(39.02));
	tcb->m_segmentSize = (int) (45.202*(47.088));

}
