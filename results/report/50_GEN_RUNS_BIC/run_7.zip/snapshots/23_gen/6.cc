int xivmrmUZerpyhgPc = (int) (((59.589)+(-77.456)+(-8.764)+((-36.223+(51.597)+(-49.08)+(97.618)+(54.376)+(12.066)+(-36.689)))+(22.993)+(59.39)+((97.299+(56.05)+(-16.367)+(25.968)))+(-20.265))/((-14.927)));
segmentsAcked = (int) (((-74.995)+(-30.022)+(-38.5)+(-47.069))/((-66.763)));
int hLmsRzabmouoaUzp = (int) (-4.006-(58.931)-(-74.996)-(-46.043)-(62.4)-(33.364)-(96.737)-(-28.332)-(19.872));
tcb->m_cWnd = (int) (92.015*(-3.271)*(-9.81));
segmentsAcked = (int) (((-10.714)+(9.857)+(14.041)+(2.449))/((98.911)));
tcb->m_cWnd = (int) (-48.284*(76.381)*(-63.67));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (33.255*(-73.552)*(-45.045));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
