ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (88.881+(84.829)+(tcb->m_ssThresh));
cnt = (int) (cnt+(94.853)+(28.939)+(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (93.504-(10.054)-(7.25)-(34.545)-(7.065)-(78.073)-(10.126));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int FWkbKsTYvSTQTCpg = (int) (70.418+(97.634));
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (47.246+(74.245)+(tcb->m_cWnd)+(30.047)+(47.406)+(99.525));
	tcb->m_segmentSize = (int) (56.717+(tcb->m_segmentSize)+(72.231)+(57.275)+(55.801)+(26.592)+(78.199));

} else {
	tcb->m_segmentSize = (int) (72.31-(29.662)-(13.541)-(39.885));
	ReduceCwnd (tcb);

}
