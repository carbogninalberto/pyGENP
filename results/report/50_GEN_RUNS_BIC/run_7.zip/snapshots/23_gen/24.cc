if (tcb->m_segmentSize < tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_cWnd*(80.67)*(58.804)*(tcb->m_cWnd)*(50.34));
	tcb->m_ssThresh = (int) (39.447+(segmentsAcked)+(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) (cnt*(16.72)*(72.245)*(8.799)*(57.696)*(73.531)*(segmentsAcked));
	tcb->m_cWnd = (int) (61.455*(tcb->m_cWnd)*(51.49)*(60.902)*(cnt)*(tcb->m_segmentSize)*(90.816)*(34.401));
	tcb->m_segmentSize = (int) ((35.871*(5.181)*(1.475)*(18.882)*(cnt))/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (47.78-(87.9)-(27.484)-(15.116)-(84.542)-(79.862)-(77.717)-(60.378));
	segmentsAcked = (int) (tcb->m_segmentSize+(71.709)+(75.016)+(4.829)+(91.279)+(21.944)+(38.702)+(36.776));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (18.774+(95.433)+(75.514)+(3.879)+(25.776)+(segmentsAcked)+(79.569)+(5.331)+(segmentsAcked));
	tcb->m_cWnd = (int) (64.916+(48.141)+(cnt)+(59.999)+(99.955));

}
if (tcb->m_cWnd != segmentsAcked) {
	segmentsAcked = (int) (0.1/37.913);
	tcb->m_cWnd = (int) (7.858*(tcb->m_ssThresh)*(6.445)*(7.133));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (35.786+(tcb->m_ssThresh)+(49.815)+(5.125)+(69.456)+(segmentsAcked)+(32.537));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) ((((48.45-(17.017)))+((80.284-(30.913)-(78.956)))+((segmentsAcked-(68.966)-(26.108)-(86.881)))+(86.538)+((tcb->m_cWnd-(30.544)-(19.5)-(45.539)-(11.874)-(tcb->m_cWnd)-(52.971)))+((99.99*(tcb->m_cWnd)*(9.47)*(73.274)*(cnt)))+(0.1)+(60.294))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (31.088+(38.074)+(31.415)+(29.117)+(11.321)+(40.534)+(31.934));

}
