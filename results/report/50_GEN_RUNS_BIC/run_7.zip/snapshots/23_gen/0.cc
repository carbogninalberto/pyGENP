int xivmrmUZerpyhgPc = (int) (((-74.68)+(25.853)+(35.875)+((-35.883+(78.598)+(5.469)+(-59.489)+(70.937)+(-51.207)+(39.22)))+(80.112)+(-27.986)+((55.381+(-18.568)+(30.532)+(51.951)))+(-64.273))/((-1.107)));
segmentsAcked = (int) (((-16.574)+(-68.608)+(5.306)+(-8.83))/((77.709)));
int hLmsRzabmouoaUzp = (int) (85.914-(22.577)-(47.935)-(-38.46)-(-45.057)-(-46.678)-(-38.931)-(30.155)-(11.364));
tcb->m_cWnd = (int) (-46.338*(-71.296)*(57.644));
segmentsAcked = (int) (((78.985)+(-84.022)+(25.096)+(24.28))/((-53.052)));
tcb->m_cWnd = (int) (-89.402*(-46.658)*(-68.76));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-7.006*(-33.069)*(-8.591));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
