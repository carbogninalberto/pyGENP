int GNctEYdUuGDDzMYR = (int) -0.033;
