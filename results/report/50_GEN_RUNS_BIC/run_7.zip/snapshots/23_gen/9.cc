if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	cnt = (int) (((0.1)+((tcb->m_cWnd*(74.008)*(tcb->m_ssThresh)*(83.247)*(28.008)*(14.852)))+((24.305*(35.622)))+(0.1))/((94.308)+(60.765)+(0.1)+(53.164)+(71.626)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (9.636+(tcb->m_cWnd)+(26.055)+(54.71));

} else {
	cnt = (int) (0.803-(8.683)-(tcb->m_ssThresh));

}
if (tcb->m_segmentSize < cnt) {
	tcb->m_cWnd = (int) (37.561-(tcb->m_ssThresh)-(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (59.092/0.1);

} else {
	tcb->m_cWnd = (int) (8.515*(17.209));
	segmentsAcked = (int) (45.326-(33.99)-(40.084));

}
ReduceCwnd (tcb);
if (cnt >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (14.439*(86.336)*(4.697)*(30.794)*(88.587)*(8.956)*(83.867)*(73.632)*(cnt));

} else {
	tcb->m_cWnd = (int) (1.08/0.1);
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
