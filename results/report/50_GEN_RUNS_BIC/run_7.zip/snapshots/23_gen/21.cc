int ZxoxxibpHRtTAXnJ = (int) (55.854+(26.928)+(7.255)+(32.471)+(18.361)+(tcb->m_cWnd));
if (cnt == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (59.242-(42.351)-(40.471)-(tcb->m_segmentSize)-(40.732)-(52.71)-(93.148)-(41.734));

} else {
	tcb->m_ssThresh = (int) (37.49/0.1);

}
tcb->m_cWnd = (int) (tcb->m_cWnd*(89.151)*(cnt));
tcb->m_cWnd = (int) (cnt+(14.566)+(30.912)+(9.613)+(89.862)+(segmentsAcked)+(41.548)+(49.695));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
float iATcBFnEGWBXQswD = (float) (98.859*(7.052)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(segmentsAcked));
if (tcb->m_ssThresh != iATcBFnEGWBXQswD) {
	tcb->m_ssThresh = (int) (67.127*(85.619)*(84.992)*(23.692)*(43.087)*(46.296)*(13.271)*(66.295)*(ZxoxxibpHRtTAXnJ));
	ZxoxxibpHRtTAXnJ = (int) ((87.454*(62.611)*(17.825)*(28.965)*(86.299))/89.552);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(7.003)*(tcb->m_ssThresh)*(7.898));

}
