ReduceCwnd (tcb);
float aQadagiBvPTUlQPz = (float) (segmentsAcked+(41.229)+(80.852)+(22.521)+(24.009)+(99.76));
cnt = (int) (75.604-(tcb->m_cWnd)-(12.436)-(30.518)-(69.327));
ReduceCwnd (tcb);
if (cnt >= cnt) {
	tcb->m_segmentSize = (int) ((((cnt*(segmentsAcked)*(tcb->m_segmentSize)))+((cnt+(29.476)+(segmentsAcked)))+(0.1)+(0.1)+(0.1))/((7.074)+(43.143)));

} else {
	tcb->m_segmentSize = (int) (43.452*(tcb->m_segmentSize)*(69.105));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(56.76)+(25.861)+(63.623)+(21.924)+(36.562)+(55.319));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (35.746+(97.336)+(61.856)+(30.638));
int HZCPyFJLkhgmiugb = (int) (89.599-(aQadagiBvPTUlQPz)-(66.871)-(segmentsAcked)-(86.915)-(62.998)-(96.174)-(55.384));
ReduceCwnd (tcb);
