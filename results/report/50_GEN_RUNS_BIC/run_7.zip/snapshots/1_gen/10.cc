cnt = (int) (98.076+(23.645)+(98.122)+(2.554)+(87.037));
segmentsAcked = (int) (((51.28)+(41.951)+(0.1)+(0.1))/((0.1)));
tcb->m_cWnd = (int) (58.496*(tcb->m_cWnd)*(37.546));
int xivmrmUZerpyhgPc = (int) (((70.019)+(0.1)+(96.205)+((54.943+(15.769)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(13.141)+(72.557)+(52.028)))+(64.916)+(0.1)+((tcb->m_segmentSize+(segmentsAcked)+(tcb->m_cWnd)+(57.901)))+(0.1))/((51.245)));
if (cnt < tcb->m_cWnd) {
	cnt = (int) (((12.418)+((92.882+(69.762)+(45.222)+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(44.773)+(17.482)+(41.384)+(64.409)))+(0.1)+(0.1)+(97.516)+(0.1)+((93.986-(57.885)-(42.917)-(74.158)-(34.375)-(74.741)-(xivmrmUZerpyhgPc)-(cnt)))+(0.1))/((0.1)));

} else {
	cnt = (int) (xivmrmUZerpyhgPc-(segmentsAcked)-(96.217)-(77.082)-(5.298)-(76.456)-(tcb->m_ssThresh));

}
int hLmsRzabmouoaUzp = (int) (tcb->m_segmentSize-(22.982)-(1.86)-(tcb->m_ssThresh)-(43.365)-(8.976)-(33.953)-(15.027)-(segmentsAcked));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
