ReduceCwnd (tcb);
if (cnt != segmentsAcked) {
	tcb->m_cWnd = (int) (27.429+(tcb->m_segmentSize)+(80.615)+(tcb->m_segmentSize)+(81.867)+(31.906)+(83.029));

} else {
	tcb->m_cWnd = (int) ((16.593-(87.638)-(48.585)-(95.812)-(50.559)-(26.39)-(86.073)-(30.895)-(50.576))/13.762);
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (25.417-(33.163)-(78.878)-(26.147)-(65.757)-(97.157)-(47.374));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
