tcb->m_cWnd = (int) (35.633+(87.836)+(cnt)+(70.336)+(40.178)+(38.092)+(95.087)+(99.138));
tcb->m_ssThresh = (int) (tcb->m_ssThresh*(30.757));
if (tcb->m_cWnd >= cnt) {
	cnt = (int) (32.618-(75.81)-(0.777)-(54.024));
	segmentsAcked = (int) ((((25.268-(96.918)-(68.287)-(3.663)-(20.238)-(43.436)-(21.635)-(42.72)-(62.517)))+(0.1)+(15.03)+(0.1)+(0.1))/((80.093)));

} else {
	cnt = (int) ((tcb->m_cWnd*(tcb->m_ssThresh))/0.1);

}
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (90.065-(46.033)-(86.421)-(segmentsAcked)-(56.761)-(37.37)-(40.152)-(73.126)-(33.418));
	cnt = (int) (31.148-(tcb->m_segmentSize)-(81.026)-(49.405));

} else {
	tcb->m_cWnd = (int) (65.076+(5.126)+(78.301)+(26.111)+(tcb->m_ssThresh)+(58.096)+(2.302));

}
tcb->m_ssThresh = (int) (30.288-(47.921)-(segmentsAcked));
ReduceCwnd (tcb);
