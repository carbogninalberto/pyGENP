int UyJTVXvrNkrsiKBU = (int) (68.551/31.829);
ReduceCwnd (tcb);
segmentsAcked = (int) (98.068+(94.52)+(69.305));
int QPjSFNteYAmZtOfG = (int) (((0.1)+(92.437)+((88.695*(94.467)*(4.504)*(UyJTVXvrNkrsiKBU)*(62.149)*(5.722)*(tcb->m_cWnd)))+(20.032)+(84.104)+(0.1)+(0.1))/((97.636)));
cnt = (int) (24.901*(57.481)*(80.013)*(84.205)*(96.794)*(tcb->m_segmentSize)*(48.283)*(34.524));
tcb->m_segmentSize = (int) (82.336+(57.089)+(49.114)+(26.311));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (9.108+(20.069)+(57.338)+(tcb->m_cWnd)+(QPjSFNteYAmZtOfG)+(QPjSFNteYAmZtOfG)+(65.373)+(20.031)+(27.25));
	segmentsAcked = (int) (0.873-(33.99)-(21.945)-(79.54)-(76.907)-(73.012));

} else {
	tcb->m_cWnd = (int) (14.515+(82.42)+(36.274)+(10.012)+(tcb->m_cWnd)+(64.923)+(51.475));
	tcb->m_segmentSize = (int) (68.609-(tcb->m_ssThresh)-(26.054)-(cnt)-(40.79)-(4.978)-(tcb->m_cWnd)-(39.267)-(9.764));

}
ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (97.838-(50.493)-(62.241)-(71.923)-(45.779));

} else {
	tcb->m_cWnd = (int) (83.202-(tcb->m_cWnd)-(74.464));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (72.492*(42.965));

}
