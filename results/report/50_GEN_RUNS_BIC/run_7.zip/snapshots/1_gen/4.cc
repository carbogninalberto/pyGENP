tcb->m_segmentSize = (int) (0.1/69.147);
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_ssThresh = (int) (0.1/52.677);

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (48.788+(4.24)+(3.032)+(63.432));
	tcb->m_cWnd = (int) (segmentsAcked-(68.723)-(segmentsAcked)-(75.405)-(segmentsAcked)-(43.243)-(15.381));

} else {
	tcb->m_segmentSize = (int) (3.913-(segmentsAcked)-(segmentsAcked)-(65.862)-(56.091)-(80.802));
	tcb->m_segmentSize = (int) (28.681-(79.303)-(tcb->m_ssThresh)-(85.541)-(81.731)-(64.829)-(17.873));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
float WORGxqFHNuIKNUFV = (float) (0.1/66.143);
ReduceCwnd (tcb);
