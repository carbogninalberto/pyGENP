if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (65.074-(1.525)-(30.103)-(84.999));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (0.1/49.421);
int AKnruuGPdAGFpNoF = (int) (33.654+(48.995)+(27.926)+(86.689));
tcb->m_cWnd = (int) (segmentsAcked-(36.651)-(50.364));
