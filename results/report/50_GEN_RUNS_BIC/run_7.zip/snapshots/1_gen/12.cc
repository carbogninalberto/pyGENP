tcb->m_cWnd = (int) (tcb->m_segmentSize*(87.593)*(tcb->m_ssThresh)*(30.293)*(segmentsAcked)*(46.258)*(3.721));
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	cnt = (int) (96.286*(96.481)*(55.282));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (59.694-(40.652)-(tcb->m_ssThresh)-(1.349)-(57.88)-(38.751));
	tcb->m_cWnd = (int) (84.696+(87.424)+(8.895)+(11.125)+(13.866)+(tcb->m_segmentSize)+(10.133));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (50.049*(2.43)*(35.414)*(81.839)*(76.05)*(93.495));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_segmentSize = (int) (cnt+(99.526)+(tcb->m_ssThresh)+(cnt)+(97.238)+(51.379));
	segmentsAcked = (int) (64.761/(19.521+(42.907)+(84.569)));
	tcb->m_ssThresh = (int) (10.575*(76.206)*(tcb->m_cWnd)*(18.503)*(35.574)*(tcb->m_ssThresh)*(segmentsAcked)*(0.881));

} else {
	tcb->m_segmentSize = (int) (7.356+(64.397)+(81.887)+(88.84)+(63.724));

}
