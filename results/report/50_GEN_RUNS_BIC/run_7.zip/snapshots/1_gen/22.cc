int LmRQqnqzzLohAeqg = (int) (25.21-(tcb->m_segmentSize)-(24.374)-(28.108)-(68.827)-(64.924)-(82.553));
if (tcb->m_segmentSize == cnt) {
	tcb->m_cWnd = (int) (86.557-(7.185)-(98.669));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (42.301*(50.626)*(LmRQqnqzzLohAeqg)*(tcb->m_segmentSize)*(78.529));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
cnt = (int) (29.909-(23.508)-(93.146)-(94.831)-(tcb->m_segmentSize)-(65.72));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_ssThresh) {
	cnt = (int) (36.155+(77.886)+(81.287)+(23.574)+(tcb->m_ssThresh)+(82.304)+(16.734)+(80.13));

} else {
	cnt = (int) (segmentsAcked-(LmRQqnqzzLohAeqg)-(74.633)-(13.574)-(56.899)-(9.585));

}
tcb->m_segmentSize = (int) (cnt*(89.326)*(99.227)*(10.66));
if (segmentsAcked >= LmRQqnqzzLohAeqg) {
	tcb->m_segmentSize = (int) (85.359+(64.771)+(26.193)+(85.987)+(segmentsAcked)+(72.014)+(1.126));
	tcb->m_ssThresh = (int) (69.107*(35.121)*(77.313)*(10.11)*(22.478)*(-0.033)*(80.269)*(52.019));
	LmRQqnqzzLohAeqg = (int) (54.006+(51.924));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(44.524)-(86.187)-(80.89));

}
