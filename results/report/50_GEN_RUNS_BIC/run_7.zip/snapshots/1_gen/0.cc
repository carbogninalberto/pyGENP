tcb->m_segmentSize = (int) (42.624-(88.365)-(segmentsAcked)-(9.94)-(46.187));
ReduceCwnd (tcb);
int MuMUetBHZxUoskUR = (int) (97.562*(43.896)*(segmentsAcked)*(32.994)*(tcb->m_cWnd)*(69.523)*(tcb->m_cWnd)*(30.4)*(29.896));
int BjrIyVDoQxdJYRAU = (int) (0.1/0.1);
BjrIyVDoQxdJYRAU = (int) (17.743-(18.409)-(83.227)-(31.468));
