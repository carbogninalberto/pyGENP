int DoDtJfmUTEOXzROx = (int) (40.844-(19.089));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (((84.462)+(0.1)+((cnt-(cnt)-(77.081)-(32.044)-(54.131)-(99.454)-(99.292)))+(7.028)+((tcb->m_ssThresh-(38.831)-(75.24)))+(0.1)+(73.102)+(0.1))/((0.1)));
tcb->m_ssThresh = (int) (33.045/0.1);
float VQatnEVNZwzStADn = (float) (60.631-(22.736)-(tcb->m_cWnd)-(cnt)-(16.735));
cnt = (int) (81.232-(85.49)-(26.375)-(84.611)-(32.854));
if (tcb->m_ssThresh > DoDtJfmUTEOXzROx) {
	VQatnEVNZwzStADn = (float) (0.1/44.505);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(56.073));

} else {
	VQatnEVNZwzStADn = (float) (tcb->m_segmentSize+(90.337));
	DoDtJfmUTEOXzROx = (int) (0.1/0.1);
	VQatnEVNZwzStADn = (float) ((77.713-(6.405)-(DoDtJfmUTEOXzROx)-(tcb->m_segmentSize)-(18.431)-(35.944)-(cnt)-(tcb->m_segmentSize))/0.1);

}
