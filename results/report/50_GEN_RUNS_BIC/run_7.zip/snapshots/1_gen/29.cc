cnt = (int) (((81.385)+((cnt*(99.346)*(99.72)*(27.272)*(64.523)))+(76.821)+((73.864-(16.198)-(59.127)-(75.777)-(29.032)))+(0.1)+(0.1))/((48.702)));
tcb->m_cWnd = (int) (45.284+(28.74)+(22.983)+(54.749)+(cnt)+(tcb->m_cWnd)+(6.767)+(50.122)+(30.148));
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (25.218+(49.578)+(13.854)+(segmentsAcked)+(segmentsAcked)+(14.057));
	tcb->m_cWnd = (int) (8.862-(93.583)-(28.419)-(25.046));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(tcb->m_cWnd)*(44.98));
	tcb->m_ssThresh = (int) (0.1/0.1);

}
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_segmentSize = (int) (7.271+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(98.38)+(8.891)+(tcb->m_segmentSize)+(22.259)+(70.616)+(22.498));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(97.251)*(54.396)*(cnt)*(tcb->m_cWnd)*(tcb->m_ssThresh));

}
tcb->m_ssThresh = (int) (99.913+(94.467)+(47.913)+(31.841));
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (68.717+(81.217)+(54.947)+(segmentsAcked)+(40.976));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(85.283)-(77.17)-(tcb->m_segmentSize)-(17.044)-(cnt)-(55.602)-(94.078)-(46.959));

}
segmentsAcked = (int) (tcb->m_segmentSize-(cnt)-(13.044)-(42.741));
