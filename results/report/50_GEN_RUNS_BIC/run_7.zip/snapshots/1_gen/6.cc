int VBmgFTmZfhsytFSt = (int) (67.888*(76.979)*(47.333)*(2.471)*(61.047)*(65.391)*(19.752)*(43.452));
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (97.726*(33.773)*(83.647)*(tcb->m_ssThresh)*(37.47)*(30.209));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (63.553*(19.837)*(72.996)*(76.622)*(61.845)*(72.101)*(10.86));
cnt = (int) (21.696*(VBmgFTmZfhsytFSt)*(88.605)*(75.984)*(91.966)*(83.793));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (6.037-(50.884));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
