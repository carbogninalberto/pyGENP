ReduceCwnd (tcb);
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((87.646)+((segmentsAcked*(tcb->m_cWnd)*(78.519)*(36.979)*(32.687)*(6.499)*(25.119)*(tcb->m_cWnd)))+(37.684)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(15.413)));
	tcb->m_ssThresh = (int) (0.1/26.978);
	cnt = (int) (74.008+(tcb->m_ssThresh)+(20.789)+(11.38)+(43.713));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(72.694)*(50.035)*(59.446)*(22.18)*(60.485)*(58.57)*(tcb->m_cWnd)*(4.741));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) ((59.25*(88.451)*(63.932)*(26.676)*(39.872)*(72.993)*(80.58)*(17.723)*(cnt))/4.858);
if (tcb->m_segmentSize <= cnt) {
	cnt = (int) (cnt+(33.4)+(59.635)+(85.411)+(96.881)+(tcb->m_ssThresh)+(3.345));
	tcb->m_segmentSize = (int) (91.012-(73.712)-(35.882)-(69.549)-(10.978)-(57.729)-(54.977)-(26.163));
	tcb->m_cWnd = (int) ((tcb->m_segmentSize+(cnt)+(37.023)+(50.476)+(92.202)+(7.486))/0.1);

} else {
	cnt = (int) (75.348-(89.732));

}
