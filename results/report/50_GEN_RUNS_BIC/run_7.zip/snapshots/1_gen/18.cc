if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (segmentsAcked*(43.757)*(32.018));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(25.697)+(8.793)+(96.844)+(25.213)+(segmentsAcked));
	ReduceCwnd (tcb);
	cnt = (int) (50.468+(97.546)+(85.583)+(cnt)+(segmentsAcked)+(82.623)+(8.405)+(28.688));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(17.818)+(43.775))/((28.935)+(0.1)+(0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (47.529+(57.445)+(45.714)+(76.769));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt <= segmentsAcked) {
	tcb->m_cWnd = (int) (95.937-(54.093)-(23.238)-(25.172)-(44.111)-(66.335)-(4.737)-(89.681));

} else {
	tcb->m_cWnd = (int) ((16.255*(25.154)*(1.395)*(74.333)*(44.569)*(1.701)*(86.348)*(37.976))/0.1);

}
