ReduceCwnd (tcb);
cnt = (int) (0.1/0.1);
cnt = (int) (0.1/0.1);
tcb->m_ssThresh = (int) (cnt-(68.283));
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (43.068-(17.927)-(cnt));

} else {
	tcb->m_ssThresh = (int) (0.1/31.751);

}
tcb->m_ssThresh = (int) (4.824*(36.583)*(40.011)*(80.624)*(14.513)*(34.472));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (89.613*(8.734)*(tcb->m_ssThresh)*(0.472)*(51.157)*(41.434)*(5.309)*(36.876));
	segmentsAcked = (int) (cnt+(70.182)+(86.855));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (75.948+(tcb->m_segmentSize)+(47.598));
	ReduceCwnd (tcb);

}
