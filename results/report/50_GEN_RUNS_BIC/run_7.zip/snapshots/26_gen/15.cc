if (tcb->m_segmentSize < segmentsAcked) {
	segmentsAcked = (int) (81.573*(tcb->m_segmentSize)*(48.573)*(21.863)*(99.39)*(27.888)*(46.707)*(segmentsAcked)*(79.724));
	tcb->m_ssThresh = (int) (((0.1)+(59.831)+(70.689)+(0.1))/((0.1)+(39.872)));
	cnt = (int) (73.55+(74.419)+(83.731)+(cnt)+(tcb->m_segmentSize)+(27.997));

} else {
	segmentsAcked = (int) (77.295*(55.074)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(90.704)*(13.76));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (24.833-(60.725)-(92.699));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	cnt = (int) (tcb->m_ssThresh+(tcb->m_ssThresh)+(9.736)+(21.962)+(63.968)+(cnt)+(65.914)+(59.703)+(95.161));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (16.21/(76.458-(78.626)-(30.874)-(87.988)-(6.078)));

} else {
	cnt = (int) (segmentsAcked-(segmentsAcked)-(2.259));
	tcb->m_segmentSize = (int) (15.122-(74.798)-(26.891)-(82.789));

}
if (tcb->m_segmentSize > cnt) {
	tcb->m_cWnd = (int) (59.232*(28.62));
	segmentsAcked = (int) (8.26+(cnt)+(48.258)+(80.545)+(75.065)+(tcb->m_ssThresh)+(36.439)+(87.992));

} else {
	tcb->m_cWnd = (int) (((0.1)+(44.511)+(0.1)+(66.673))/((0.1)+(0.1)+(79.401)));
	tcb->m_cWnd = (int) (segmentsAcked*(15.445)*(tcb->m_ssThresh)*(53.937)*(72.082)*(84.514)*(tcb->m_segmentSize)*(46.981));
	segmentsAcked = (int) (68.46+(96.548)+(2.748)+(tcb->m_cWnd)+(24.574)+(43.837)+(5.831)+(tcb->m_cWnd));

}
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (44.557*(77.284)*(91.641)*(48.24));

} else {
	tcb->m_ssThresh = (int) (((94.637)+(0.1)+(0.1)+(71.482))/((0.1)+(54.778)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (39.785-(32.53)-(52.955)-(34.224)-(cnt)-(34.923)-(61.561));
