if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (64.971*(16.847)*(76.588)*(12.184)*(78.017)*(91.123)*(0.229)*(7.426));

} else {
	tcb->m_segmentSize = (int) (85.768*(34.294));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (88.091-(tcb->m_segmentSize)-(56.013)-(tcb->m_segmentSize)-(19.613)-(57.215)-(93.169));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
