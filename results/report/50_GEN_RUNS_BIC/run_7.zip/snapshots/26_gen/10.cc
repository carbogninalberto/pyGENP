int xivmrmUZerpyhgPc = (int) (((-23.688)+(-73.261)+(-21.614)+((81.957+(-36.958)+(-47.52)+(-43.642)+(-15.45)+(5.943)+(23.958)))+(-44.789)+(-27.737)+((97.705+(39.987)+(4.3)+(-22.267)))+(-55.501))/((74.479)));
int hLmsRzabmouoaUzp = (int) (15.587-(38.247)-(53.074)-(0.934)-(-39.45)-(37.795)-(-93.734)-(-22.038)-(-90.103));
segmentsAcked = (int) (((-25.122)+(36.666)+(-38.091)+(-25.88))/((11.213)));
tcb->m_cWnd = (int) (-26.252*(-65.413)*(-54.3));
segmentsAcked = (int) (((-19.817)+(-7.273)+(-99.211)+(-83.719))/((85.898)));
tcb->m_cWnd = (int) (14.4*(-39.741)*(-80.822));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (14.386*(-11.321)*(-7.795));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((93.22)+(-79.561)+(6.624)+(-14.505))/((7.853)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-93.793*(94.168)*(85.543));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((-68.314)+(68.395)+(-87.854)+(75.822))/((-94.22)));
tcb->m_cWnd = (int) (-45.387*(-8.962)*(-49.596));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-36.612*(36.256)*(49.848));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
