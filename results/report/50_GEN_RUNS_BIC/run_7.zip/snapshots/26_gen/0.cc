int xivmrmUZerpyhgPc = (int) (((-31.611)+(-77.691)+(62.418)+((65.333+(99.218)+(-8.743)+(48.538)+(-22.445)+(-92.233)+(11.034)))+(70.699)+(99.533)+((-22.142+(-29.251)+(76.787)+(-45.598)))+(48.661))/((-68.721)));
segmentsAcked = (int) (((57.825)+(11.697)+(-81.186)+(37.82))/((41.367)));
int hLmsRzabmouoaUzp = (int) (82.779-(-28.311)-(86.49)-(27.037)-(10.058)-(-60.705)-(29.519)-(-98.727)-(-91.394));
tcb->m_cWnd = (int) (-48.192*(-20.077)*(61.905));
segmentsAcked = (int) (((50.172)+(41.276)+(96.778)+(62.741))/((23.75)));
tcb->m_cWnd = (int) (47.753*(75.222)*(-75.231));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-41.689*(-84.028)*(-10.451));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
