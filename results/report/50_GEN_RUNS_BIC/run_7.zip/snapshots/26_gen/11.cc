if (tcb->m_cWnd <= segmentsAcked) {
	cnt = (int) (9.117*(80.25)*(0.513)*(36.809)*(76.212)*(55.465)*(40.555)*(77.777));

} else {
	cnt = (int) (59.494/0.1);

}
ReduceCwnd (tcb);
if (cnt >= tcb->m_cWnd) {
	cnt = (int) (59.187*(84.936)*(tcb->m_cWnd)*(75.933)*(90.51)*(61.295)*(93.167));
	tcb->m_ssThresh = (int) (91.371*(62.697)*(tcb->m_ssThresh));

} else {
	cnt = (int) (25.446-(cnt)-(77.239)-(37.665));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float LyMNXkeeukdiEQrP = (float) (39.988*(52.501)*(tcb->m_ssThresh)*(67.239)*(30.553));
if (segmentsAcked >= tcb->m_cWnd) {
	cnt = (int) (40.268-(3.772)-(7.034)-(21.521)-(3.577)-(21.169)-(89.048)-(LyMNXkeeukdiEQrP));

} else {
	cnt = (int) (97.252/93.357);
	ReduceCwnd (tcb);
	segmentsAcked = (int) (22.567*(24.652)*(8.391)*(86.049)*(45.817)*(18.727)*(tcb->m_ssThresh)*(tcb->m_cWnd));

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (35.007*(55.156)*(3.969)*(52.196));
