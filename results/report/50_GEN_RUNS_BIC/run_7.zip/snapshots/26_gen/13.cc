if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) ((54.139-(79.247)-(86.783))/0.1);
if (cnt <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/26.839);
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) ((96.735*(58.717)*(cnt)*(65.082)*(35.109))/89.92);
	tcb->m_cWnd = (int) (26.328-(29.579)-(4.61)-(89.956)-(46.764));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (61.5+(69.213)+(73.849)+(40.219)+(31.62)+(cnt)+(tcb->m_ssThresh));
tcb->m_segmentSize = (int) (66.224-(81.186)-(tcb->m_cWnd)-(8.577)-(15.286)-(35.709));
