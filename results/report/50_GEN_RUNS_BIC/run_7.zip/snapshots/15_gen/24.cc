if (cnt <= segmentsAcked) {
	segmentsAcked = (int) (0.1/0.1);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (tcb->m_cWnd-(91.703)-(78.007)-(68.027)-(32.293)-(87.603)-(93.818)-(segmentsAcked));

}
if (tcb->m_segmentSize < cnt) {
	segmentsAcked = (int) (tcb->m_ssThresh*(10.826)*(10.366)*(46.972)*(14.113)*(44.505)*(94.4));
	tcb->m_cWnd = (int) (7.713*(79.485)*(98.313)*(64.118)*(97.009)*(98.331));

} else {
	segmentsAcked = (int) (33.319*(28.737)*(tcb->m_cWnd)*(55.06));
	tcb->m_segmentSize = (int) (12.338*(60.563)*(94.514)*(45.023)*(74.368)*(18.848)*(54.08)*(tcb->m_cWnd)*(59.413));
	segmentsAcked = (int) (48.682*(36.451)*(29.117));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (16.743*(36.268)*(84.671)*(18.248)*(tcb->m_segmentSize)*(60.469)*(11.339)*(59.286)*(segmentsAcked));
tcb->m_segmentSize = (int) (3.008*(94.368));
if (tcb->m_segmentSize == cnt) {
	tcb->m_ssThresh = (int) (55.69+(8.638)+(cnt)+(3.746)+(20.306)+(12.492));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) ((72.941*(11.669)*(95.962)*(tcb->m_segmentSize))/0.1);
	tcb->m_ssThresh = (int) (99.896/0.1);

}
ReduceCwnd (tcb);
