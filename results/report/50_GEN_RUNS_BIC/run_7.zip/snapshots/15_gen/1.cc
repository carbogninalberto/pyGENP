int xivmrmUZerpyhgPc = (int) (((-41.465)+(26.958)+(-60.904)+((-71.534+(-45.473)+(16.089)+(35.691)+(61.508)+(69.681)+(53.827)))+(-88.099)+(3.797)+((-47.114+(26.024)+(-76.293)+(-74.053)))+(-74.271))/((-67.026)));
segmentsAcked = (int) (((-78.153)+(-79.775)+(-70.278)+(16.285))/((-40.284)));
int hLmsRzabmouoaUzp = (int) (-50.535-(70.523)-(-36.952)-(-37.934)-(72.786)-(-62.491)-(17.618)-(-19.58)-(13.355));
tcb->m_cWnd = (int) (22.494*(62.814)*(-54.743));
segmentsAcked = (int) (((61.155)+(-68.741)+(35.872)+(-2.084))/((-0.006)));
tcb->m_cWnd = (int) (25.53*(66.235)*(-99.129));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((87.022)+(57.358)+(29.495)+(86.291))/((-92.865)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (30.643*(-87.382)*(-81.472));
tcb->m_cWnd = (int) (-0.077*(38.691)*(95.879));
segmentsAcked = (int) (((-71.73)+(-81.454)+(78.943)+(-10.038))/((85.343)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-69.79*(-74.623)*(46.283));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (66.166*(-65.792)*(98.487));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
