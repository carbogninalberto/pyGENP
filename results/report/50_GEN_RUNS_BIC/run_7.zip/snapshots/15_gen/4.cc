int xivmrmUZerpyhgPc = (int) (((-51.722)+(-76.394)+(-75.072)+((39.778+(-5.751)+(85.165)+(-89.016)+(-83.909)+(-93.517)+(-86.637)))+(6.041)+(-41.608)+((-88.707+(17.329)+(57.497)+(-26.471)))+(41.65))/((-69.361)));
int hLmsRzabmouoaUzp = (int) (-27.045-(-21.856)-(-60.64)-(-46.095)-(-53.426)-(92.077)-(18.196)-(-66.263)-(82.117));
segmentsAcked = (int) (((-73.767)+(86.262)+(65.142)+(-87.646))/((3.731)));
tcb->m_cWnd = (int) (27.976*(-25.404)*(46.596));
segmentsAcked = (int) (((-5.881)+(18.003)+(33.834)+(-3.024))/((3.793)));
segmentsAcked = (int) (((-33.8)+(21.442)+(-81.37)+(78.25))/((-78.343)));
tcb->m_cWnd = (int) (3.191*(45.45)*(-15.431));
tcb->m_cWnd = (int) (33.131*(-62.345)*(54.4));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((-4.76)+(6.527)+(28.067)+(-77.213))/((55.862)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-81.771*(-89.153)*(-83.19));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-66.538*(-92.153)*(-21.699));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (31.604*(-44.491)*(-0.045));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
