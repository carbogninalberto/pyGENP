float qfiEqtNEkdonQttM = (float) (tcb->m_ssThresh-(tcb->m_ssThresh)-(30.246)-(segmentsAcked)-(61.689)-(segmentsAcked)-(tcb->m_segmentSize));
ReduceCwnd (tcb);
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (45.382*(25.596)*(0.824)*(60.099));
	qfiEqtNEkdonQttM = (float) (47.177+(tcb->m_cWnd)+(2.162)+(39.787)+(15.329)+(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (22.071-(51.695)-(39.184)-(qfiEqtNEkdonQttM)-(95.402)-(33.594)-(88.437)-(43.389));
	segmentsAcked = (int) (4.583*(43.767)*(segmentsAcked)*(25.16)*(33.358)*(85.829));

}
if (cnt < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (51.788-(39.593)-(93.175));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (47.103+(30.452)+(1.374)+(qfiEqtNEkdonQttM)+(qfiEqtNEkdonQttM)+(24.694)+(8.378));

} else {
	tcb->m_segmentSize = (int) (88.581+(4.378)+(57.742));

}
tcb->m_segmentSize = (int) (3.507-(75.583)-(35.553)-(24.72)-(57.973));
int iUOpBbfjHZNYclWI = (int) (cnt-(89.25)-(68.544)-(tcb->m_segmentSize)-(39.149)-(62.175)-(83.706)-(22.465)-(12.606));
ReduceCwnd (tcb);
