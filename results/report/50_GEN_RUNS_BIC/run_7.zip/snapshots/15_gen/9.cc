int AkfbqdPuDggjKzQt = (int) 43.668;
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
AkfbqdPuDggjKzQt = (int) (((-18.506)+(-68.169)+(-2.297)+(-76.644))/((12.461)));
