ReduceCwnd (tcb);
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (89.308-(33.886)-(71.806)-(79.465)-(18.826)-(38.338));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (35.342/53.164);
	segmentsAcked = (int) (tcb->m_segmentSize+(49.463));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(88.291)-(tcb->m_segmentSize)-(66.055));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (97.275/0.1);

} else {
	tcb->m_segmentSize = (int) (47.181+(99.507)+(72.188)+(tcb->m_segmentSize)+(16.64)+(20.296)+(71.711));

}
