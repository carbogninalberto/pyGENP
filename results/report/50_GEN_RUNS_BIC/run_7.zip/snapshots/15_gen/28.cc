ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
segmentsAcked = (int) (20.43*(cnt)*(93.255)*(78.304)*(54.44)*(2.666)*(23.862));
tcb->m_segmentSize = (int) (23.946-(cnt)-(8.734)-(82.153)-(80.61)-(90.897));
tcb->m_cWnd = (int) (70.506/50.979);
if (segmentsAcked == tcb->m_ssThresh) {
	segmentsAcked = (int) (58.86*(86.824)*(70.674)*(89.521)*(33.784));
	segmentsAcked = (int) (0.1/0.1);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (45.865+(54.915)+(35.187));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
