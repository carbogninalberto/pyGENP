int xivmrmUZerpyhgPc = (int) (((74.906)+(16.743)+(-29.516)+((23.589+(-71.824)+(97.541)+(38.781)+(8.123)+(-46.583)+(-23.815)))+(-19.548)+(71.071)+((-35.843+(93.258)+(-80.108)+(5.672)))+(-23.552))/((67.245)));
segmentsAcked = (int) (((-84.169)+(-20.971)+(-45.421)+(24.652))/((1.831)));
int hLmsRzabmouoaUzp = (int) (-38.123-(-98.721)-(76.965)-(-1.65)-(-46.374)-(93.739)-(-74.194)-(-24.908)-(18.33));
tcb->m_cWnd = (int) (-69.104*(-55.505)*(66.022));
segmentsAcked = (int) (((-72.992)+(-78.505)+(-59.82)+(21.728))/((91.591)));
tcb->m_cWnd = (int) (90.302*(50.081)*(-54.676));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (27.092*(-33.285)*(13.793));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
