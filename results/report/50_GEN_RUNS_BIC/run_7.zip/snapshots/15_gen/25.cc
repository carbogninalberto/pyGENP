tcb->m_cWnd = (int) (65.834*(cnt)*(34.987)*(67.553)*(88.856));
float vnmrBxBHUDrIvXay = (float) ((36.656-(56.56)-(3.919)-(1.853))/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (79.457-(86.243)-(95.68)-(96.59));
cnt = (int) (11.929+(10.11));
if (tcb->m_ssThresh < vnmrBxBHUDrIvXay) {
	tcb->m_segmentSize = (int) (7.813*(85.87)*(39.489)*(74.362)*(51.305));
	tcb->m_ssThresh = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (18.405-(85.196)-(91.72)-(1.303)-(88.494)-(92.691)-(49.182)-(74.716));
	tcb->m_segmentSize = (int) (34.676-(70.29)-(94.551)-(90.763)-(24.224)-(32.297)-(51.147));

}
