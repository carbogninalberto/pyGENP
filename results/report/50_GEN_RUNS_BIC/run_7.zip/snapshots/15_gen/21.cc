cnt = (int) (98.775-(48.277)-(51.089)-(segmentsAcked)-(78.553));
tcb->m_cWnd = (int) (12.619+(16.372)+(tcb->m_cWnd)+(53.046)+(4.015)+(31.554)+(cnt)+(70.382)+(26.183));
tcb->m_ssThresh = (int) (40.394+(segmentsAcked)+(62.929)+(99.751)+(cnt)+(79.148)+(cnt)+(cnt));
if (cnt == segmentsAcked) {
	segmentsAcked = (int) (30.505-(9.791)-(8.752)-(8.945)-(23.263)-(23.47)-(59.635)-(11.242));

} else {
	segmentsAcked = (int) (1.037-(75.431)-(59.157)-(74.192)-(21.017)-(13.372));

}
segmentsAcked = (int) (tcb->m_ssThresh+(59.394)+(99.321)+(34.542));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
