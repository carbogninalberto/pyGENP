ReduceCwnd (tcb);
cnt = (int) (35.864-(75.064)-(40.8)-(tcb->m_segmentSize)-(tcb->m_segmentSize));
if (segmentsAcked == tcb->m_cWnd) {
	cnt = (int) (26.458*(tcb->m_ssThresh)*(49.145)*(41.691)*(10.468)*(30.43));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (tcb->m_cWnd*(58.622)*(74.895)*(segmentsAcked)*(43.702)*(51.671));

} else {
	cnt = (int) (85.35*(86.732)*(cnt)*(37.443)*(47.219)*(cnt));

}
if (cnt == cnt) {
	segmentsAcked = (int) ((5.497+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(20.533))/0.1);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (56.871*(98.801)*(0.351)*(46.368)*(30.244)*(94.579)*(cnt));
	ReduceCwnd (tcb);

}
if (cnt == tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_segmentSize-(19.948));
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (93.659+(22.522)+(94.525)+(60.302)+(tcb->m_cWnd)+(32.514));

} else {
	segmentsAcked = (int) (52.168-(21.666)-(32.195)-(88.222)-(19.001)-(8.076)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (22.652+(cnt)+(50.456)+(61.887)+(31.633)+(21.752)+(24.775)+(82.622));
	cnt = (int) (13.217-(93.844)-(84.013)-(51.429)-(tcb->m_cWnd)-(segmentsAcked)-(29.527)-(tcb->m_cWnd));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (15.376+(17.36)+(segmentsAcked)+(40.513)+(68.452)+(70.617)+(tcb->m_cWnd)+(19.916)+(37.133));
segmentsAcked = (int) ((tcb->m_cWnd-(95.737)-(tcb->m_segmentSize)-(segmentsAcked)-(8.453))/0.1);
if (tcb->m_ssThresh >= cnt) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(segmentsAcked)-(18.021)-(40.924)-(89.379));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) ((20.49-(69.691)-(25.986)-(tcb->m_cWnd)-(69.837)-(28.462)-(96.652)-(0.921))/35.003);
	cnt = (int) (25.372+(36.802)+(96.656)+(33.289)+(tcb->m_segmentSize)+(75.006)+(69.968)+(39.419)+(96.258));
	ReduceCwnd (tcb);

}
