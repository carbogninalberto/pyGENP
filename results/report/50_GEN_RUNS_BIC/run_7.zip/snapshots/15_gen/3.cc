int xivmrmUZerpyhgPc = (int) (((-0.148)+(-61.007)+(-30.261)+((-62.849+(2.737)+(96.41)+(-4.797)+(66.557)+(-6.386)+(61.214)))+(-96.849)+(-78.697)+((20.635+(-92.57)+(-56.405)+(-19.259)))+(-66.244))/((-16.173)));
segmentsAcked = (int) (((1.923)+(0.392)+(87.283)+(26.421))/((81.043)));
int hLmsRzabmouoaUzp = (int) (11.323-(-8.384)-(99.753)-(67.15)-(30.798)-(73.885)-(47.447)-(-6.628)-(3.731));
tcb->m_cWnd = (int) (-76.627*(67.102)*(-26.584));
segmentsAcked = (int) (((-59.233)+(63.123)+(-8.282)+(-92.515))/((-81.871)));
tcb->m_cWnd = (int) (21.558*(86.306)*(3.942));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
