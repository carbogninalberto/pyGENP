if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (41.102-(58.278)-(tcb->m_cWnd)-(29.999)-(89.034)-(cnt));
cnt = (int) (((0.1)+(83.297)+((92.982-(69.67)-(88.897)-(88.656)-(9.577)-(9.968)-(78.966)-(13.448)-(41.037)))+(82.935))/((0.1)+(47.239)+(18.339)+(0.1)));
int IKzmtnfJPrUGINOM = (int) (0.1/25.663);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (((0.1)+(0.1)+(34.68)+(0.1))/((77.118)+(0.1)));
