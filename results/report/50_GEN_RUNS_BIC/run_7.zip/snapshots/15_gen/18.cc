if (tcb->m_segmentSize > tcb->m_ssThresh) {
	cnt = (int) (44.513+(96.567)+(61.883));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (22.667-(50.003)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (29.052-(tcb->m_ssThresh)-(16.83)-(44.031)-(97.654)-(tcb->m_cWnd)-(cnt));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_cWnd = (int) (88.246-(36.841)-(28.787)-(segmentsAcked)-(43.144));

} else {
	tcb->m_cWnd = (int) (11.034-(8.099)-(69.63)-(cnt)-(67.916)-(11.581)-(20.888)-(92.485));
	cnt = (int) (10.875-(43.628)-(44.223)-(tcb->m_segmentSize)-(71.851)-(98.496));
	tcb->m_ssThresh = (int) (cnt+(cnt)+(36.718)+(64.955));

}
ReduceCwnd (tcb);
if (segmentsAcked > cnt) {
	tcb->m_ssThresh = (int) (59.595+(46.747)+(79.164)+(52.208)+(46.272)+(segmentsAcked));
	tcb->m_cWnd = (int) (1.168*(1.449)*(86.976)*(cnt)*(24.346)*(13.974));

} else {
	tcb->m_ssThresh = (int) (63.739*(90.076)*(98.412)*(56.827)*(cnt)*(9.111));
	cnt = (int) (80.15-(51.664)-(13.502)-(45.145)-(5.577));

}
tcb->m_segmentSize = (int) (19.508+(77.765));
