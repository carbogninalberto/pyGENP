tcb->m_cWnd = (int) (2.251*(-87.829)*(-40.632)*(28.963)*(46.079)*(16.013)*(-98.984)*(69.242)*(-79.873));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
