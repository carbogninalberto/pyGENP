cnt = (int) (30.657*(32.985)*(85.452));
tcb->m_segmentSize = (int) (84.045*(65.869)*(26.013)*(53.729)*(69.839)*(29.392));
tcb->m_segmentSize = (int) (tcb->m_cWnd-(32.72)-(31.351)-(20.916)-(27.908)-(tcb->m_cWnd)-(76.971)-(9.561)-(segmentsAcked));
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	segmentsAcked = (int) (0.1/33.961);

} else {
	segmentsAcked = (int) (0.1/67.867);

}
cnt = (int) (0.1/22.067);
if (tcb->m_cWnd > tcb->m_cWnd) {
	segmentsAcked = (int) (9.353*(92.99)*(tcb->m_ssThresh)*(88.92)*(58.987)*(44.892)*(12.126)*(74.465));

} else {
	segmentsAcked = (int) (30.868*(49.101)*(67.137)*(tcb->m_segmentSize));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
