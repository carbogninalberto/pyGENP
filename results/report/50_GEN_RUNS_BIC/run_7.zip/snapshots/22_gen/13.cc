ReduceCwnd (tcb);
ReduceCwnd (tcb);
int uwwakTimiEsBuvnp = (int) ((segmentsAcked+(4.611))/0.1);
if (cnt <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (78.385+(cnt)+(73.254));
	tcb->m_segmentSize = (int) (8.992+(3.567)+(87.697)+(tcb->m_ssThresh)+(98.256)+(3.771)+(29.916)+(segmentsAcked)+(uwwakTimiEsBuvnp));

} else {
	tcb->m_cWnd = (int) (18.204-(53.626)-(9.93)-(cnt)-(cnt)-(5.618)-(82.391)-(27.395));
	tcb->m_cWnd = (int) (64.75+(cnt)+(36.954)+(tcb->m_segmentSize));

}
tcb->m_cWnd = (int) (10.793+(93.549));
