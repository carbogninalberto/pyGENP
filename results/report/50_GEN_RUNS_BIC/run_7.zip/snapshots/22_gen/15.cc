ReduceCwnd (tcb);
int PEPodOyDFHbgoYSZ = (int) (17.161*(tcb->m_ssThresh)*(80.078));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float NTksOdGPCyVUjkSX = (float) (41.117*(59.251)*(56.022)*(56.589)*(29.669)*(37.835)*(71.792));
int gwhDqXfCJKRbMEhs = (int) (44.258-(55.882));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (30.552/69.297);
tcb->m_segmentSize = (int) (((0.1)+((tcb->m_cWnd-(16.997)-(54.788)-(63.732)))+(98.124)+((NTksOdGPCyVUjkSX-(38.09)-(9.902)-(90.876)-(89.687)-(21.63)-(PEPodOyDFHbgoYSZ)-(cnt)-(75.349)))+(25.477)+(0.1)+(66.284))/((0.1)+(0.1)));
