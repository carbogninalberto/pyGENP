int CTklpvFQORCfxvNn = (int) (-74.649+(-59.296)+(30.152)+(-70.06));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
