ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_cWnd-(tcb->m_ssThresh));
int MKfnvkyTdgqObuSp = (int) (43.991+(75.714)+(33.672)+(29.073));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
