float HlJVVrsahksiBKPF = (float) (52.507+(tcb->m_cWnd)+(cnt)+(98.755)+(11.753)+(68.698));
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (26.373*(66.48)*(segmentsAcked)*(91.963)*(36.562)*(80.998)*(22.149));

} else {
	tcb->m_ssThresh = (int) (58.064+(6.219)+(38.892)+(tcb->m_cWnd)+(75.388));
	cnt = (int) (31.793-(63.547)-(HlJVVrsahksiBKPF)-(12.322)-(20.522)-(95.744)-(99.391)-(83.238));

}
HlJVVrsahksiBKPF = (float) (30.543*(81.879)*(1.034)*(57.305)*(92.775)*(67.999)*(15.285)*(78.353));
if (segmentsAcked > HlJVVrsahksiBKPF) {
	HlJVVrsahksiBKPF = (float) (61.718-(21.432)-(97.469));

} else {
	HlJVVrsahksiBKPF = (float) (0.1/1.833);

}
segmentsAcked = (int) (2.629+(75.248)+(75.034)+(47.586)+(35.138));
if (segmentsAcked <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (64.473*(41.317)*(71.542)*(67.183));
	cnt = (int) (45.82-(55.964)-(43.677)-(tcb->m_ssThresh)-(3.817)-(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (HlJVVrsahksiBKPF+(19.951)+(60.3)+(89.362)+(34.957));
	tcb->m_cWnd = (int) (7.797*(81.774)*(79.292)*(87.184)*(98.333)*(tcb->m_segmentSize)*(53.488));
	tcb->m_ssThresh = (int) (35.064-(91.159)-(19.566)-(18.518)-(4.872));

}
