if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (29.421+(81.752)+(45.631)+(34.878)+(72.237)+(94.522)+(74.901)+(95.292));
	tcb->m_ssThresh = (int) ((74.349*(10.074)*(4.345)*(47.04)*(21.966)*(50.34))/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(22.032)-(91.677)-(41.828)-(91.257)-(23.644));

}
if (tcb->m_cWnd > cnt) {
	tcb->m_segmentSize = (int) (59.074+(68.151)+(92.555)+(91.773)+(58.736)+(53.276)+(80.379)+(tcb->m_ssThresh)+(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (27.36*(64.859)*(cnt)*(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (36.841*(96.795)*(61.063)*(tcb->m_segmentSize)*(20.038)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(87.149)*(79.775));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (47.375+(tcb->m_segmentSize)+(44.782)+(69.609)+(99.255)+(72.769));

}
if (cnt <= tcb->m_ssThresh) {
	cnt = (int) (33.258*(62.994)*(63.115)*(73.878)*(62.713));
	tcb->m_cWnd = (int) (40.229*(91.241)*(98.89)*(36.508)*(67.055)*(tcb->m_ssThresh)*(51.249)*(59.11)*(87.556));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (tcb->m_cWnd-(70.273)-(15.257)-(16.818)-(75.612));
	tcb->m_cWnd = (int) (56.199+(26.348)+(58.796));

}
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	segmentsAcked = (int) (34.885-(10.714)-(49.77)-(tcb->m_ssThresh)-(56.123)-(74.37)-(48.648)-(84.205)-(cnt));

} else {
	segmentsAcked = (int) (83.798+(segmentsAcked)+(73.144)+(97.519)+(tcb->m_segmentSize)+(95.582)+(66.132)+(tcb->m_ssThresh));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
