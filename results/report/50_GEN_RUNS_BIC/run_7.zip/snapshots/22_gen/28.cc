tcb->m_ssThresh = (int) (82.192*(52.788));
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	segmentsAcked = (int) ((((51.244-(47.086)-(tcb->m_segmentSize)-(65.627)-(66.44)-(18.599)-(42.143)-(24.149)-(tcb->m_ssThresh)))+(94.497)+((tcb->m_ssThresh*(60.067)))+(12.384))/((0.1)+(97.857)));
	segmentsAcked = (int) (50.368-(tcb->m_ssThresh)-(66.073)-(65.048)-(90.718)-(19.378));
	segmentsAcked = (int) (71.271-(96.965));

} else {
	segmentsAcked = (int) (55.425+(99.028)+(cnt)+(18.203)+(58.958)+(97.858)+(26.851));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (9.328+(41.813)+(92.686)+(27.795));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (((89.4)+(45.325)+(0.1)+(12.181)+(98.145))/((33.822)+(92.085)));
cnt = (int) (53.509*(92.339));
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (19.839*(60.647));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (97.995*(52.303)*(75.396)*(25.55));
	tcb->m_segmentSize = (int) (44.322-(4.597)-(47.374)-(11.112)-(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
