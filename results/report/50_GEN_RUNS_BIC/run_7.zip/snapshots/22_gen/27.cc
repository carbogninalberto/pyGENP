if (tcb->m_segmentSize == cnt) {
	tcb->m_ssThresh = (int) ((((4.011-(66.37)-(93.831)-(97.203)-(5.505)-(18.964)-(95.261)-(92.962)))+(0.1)+(0.1)+(0.1))/((0.1)));
	tcb->m_cWnd = (int) ((69.594*(42.791)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(74.318)*(67.653)*(97.378)*(51.917)*(51.499))/0.1);

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_cWnd) {
	cnt = (int) (cnt-(13.275)-(82.185)-(segmentsAcked)-(16.172)-(93.584)-(segmentsAcked)-(61.543)-(tcb->m_ssThresh));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (((39.094)+(53.679)+(42.997)+(0.1)+(0.1))/((0.1)+(89.205)+(19.681)+(0.1)));

}
tcb->m_ssThresh = (int) (56.305/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (cnt*(72.892)*(33.515)*(87.363)*(tcb->m_ssThresh)*(36.887));
