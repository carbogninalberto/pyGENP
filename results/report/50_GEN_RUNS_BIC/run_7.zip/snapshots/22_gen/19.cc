ReduceCwnd (tcb);
int xHGxVxMuluKPYVcc = (int) (cnt-(31.37));
cnt = (int) (79.652*(18.864)*(30.132)*(8.736)*(70.748)*(30.072));
if (segmentsAcked >= tcb->m_ssThresh) {
	cnt = (int) (58.012*(96.42)*(tcb->m_cWnd)*(72.228));

} else {
	cnt = (int) (95.922+(26.354)+(2.516)+(cnt)+(26.894)+(72.914));
	xHGxVxMuluKPYVcc = (int) (tcb->m_cWnd+(89.265)+(34.91)+(47.906)+(segmentsAcked)+(77.441)+(tcb->m_cWnd)+(87.722)+(xHGxVxMuluKPYVcc));

}
if (cnt > tcb->m_segmentSize) {
	xHGxVxMuluKPYVcc = (int) (tcb->m_ssThresh*(24.764));
	ReduceCwnd (tcb);

} else {
	xHGxVxMuluKPYVcc = (int) (49.668-(tcb->m_ssThresh)-(xHGxVxMuluKPYVcc)-(62.682));
	cnt = (int) (98.216-(73.424)-(52.278)-(xHGxVxMuluKPYVcc)-(tcb->m_segmentSize)-(segmentsAcked)-(13.666)-(18.989)-(96.972));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > segmentsAcked) {
	cnt = (int) (4.339+(1.607));

} else {
	cnt = (int) (53.361-(35.386)-(50.579)-(38.595));
	segmentsAcked = (int) (20.746+(tcb->m_cWnd)+(10.297)+(cnt)+(90.928)+(71.573)+(xHGxVxMuluKPYVcc));
	tcb->m_cWnd = (int) (segmentsAcked+(78.955)+(tcb->m_ssThresh)+(91.367)+(92.82)+(cnt)+(xHGxVxMuluKPYVcc));

}
if (tcb->m_ssThresh >= cnt) {
	tcb->m_cWnd = (int) (79.032/82.461);
	xHGxVxMuluKPYVcc = (int) (71.144*(64.97)*(46.528)*(26.767));

} else {
	tcb->m_cWnd = (int) (0.639*(cnt)*(18.241));
	xHGxVxMuluKPYVcc = (int) (22.777-(segmentsAcked)-(76.832)-(23.007)-(41.712)-(62.834)-(cnt)-(xHGxVxMuluKPYVcc)-(62.245));

}
ReduceCwnd (tcb);
