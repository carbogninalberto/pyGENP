int xivmrmUZerpyhgPc = (int) (((14.862)+(38.552)+(84.828)+((69.484+(8.585)+(-93.395)+(-15.609)+(-93.175)+(-37.533)+(33.451)))+(-16.776)+(-74.198)+((-7.461+(-53.184)+(-94.779)+(-5.281)))+(52.974))/((97.192)));
segmentsAcked = (int) (((82.277)+(-42.546)+(83.067)+(6.708))/((9.7)));
int hLmsRzabmouoaUzp = (int) (-65.113-(-98.157)-(-15.706)-(-55.377)-(-18.937)-(-80.688)-(-59.668)-(-78.935)-(-27.88));
tcb->m_cWnd = (int) (24.004*(-20.828)*(76.763));
segmentsAcked = (int) (((-57.409)+(-5.44)+(-80.753)+(75.002))/((25.597)));
tcb->m_cWnd = (int) (10.22*(91.409)*(8.024));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-30.451*(-93.706)*(94.53));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
