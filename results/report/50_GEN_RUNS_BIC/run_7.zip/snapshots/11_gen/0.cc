int xivmrmUZerpyhgPc = (int) (((47.44)+(33.519)+(65.749)+((29.939+(60.43)+(52.467)+(-92.06)+(2.731)+(-67.566)+(54.208)))+(-29.706)+(11.145)+((-75.085+(-52.838)+(55.027)+(-51.624)))+(-87.259))/((-23.227)));
segmentsAcked = (int) (((78.314)+(54.196)+(-91.391)+(30.863))/((-18.636)));
int hLmsRzabmouoaUzp = (int) (-19.105-(-97.596)-(-41.689)-(-77.631)-(80.179)-(-67.34)-(-20.491)-(92.333)-(32.944));
tcb->m_cWnd = (int) (25.643*(-71.804)*(68.631));
segmentsAcked = (int) (((95.635)+(61.115)+(-31.434)+(89.5))/((51.648)));
tcb->m_cWnd = (int) (38.566*(30.906)*(-66.596));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (66.074*(46.86)*(-53.338));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
