int xivmrmUZerpyhgPc = (int) (((-92.583)+(-91.759)+(0.652)+((85.887+(-68.917)+(-39.128)+(48.575)+(-73.268)+(18.855)+(-20.546)))+(-3.388)+(1.056)+((-77.298+(83.968)+(13.019)+(-60.632)))+(6.425))/((-24.112)));
segmentsAcked = (int) (((-28.608)+(-79.402)+(94.545)+(21.975))/((96.923)));
int hLmsRzabmouoaUzp = (int) (74.654-(-41.651)-(-57.237)-(-44.057)-(-16.795)-(-72.078)-(72.388)-(-38.565)-(-26.782));
tcb->m_cWnd = (int) (-89.923*(-85.75)*(-19.154));
segmentsAcked = (int) (((-28.601)+(9.742)+(-41.222)+(96.972))/((-94.852)));
tcb->m_cWnd = (int) (-17.218*(-97.266)*(-31.872));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((-50.914)+(-27.309)+(-78.487)+(-71.48))/((-65.776)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (46.672*(54.443)*(76.272));
tcb->m_cWnd = (int) (-91.383*(-64.026)*(-98.542));
segmentsAcked = (int) (((37.797)+(91.601)+(76.411)+(-57.69))/((69.857)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (48.115*(-92.385)*(-44.835));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-47.926*(-84.702)*(74.228));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
