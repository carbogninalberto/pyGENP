int xivmrmUZerpyhgPc = (int) (((71.503)+(-74.963)+(-8.2)+((34.601+(90.757)+(20.291)+(-61.85)+(-91.273)+(-77.343)+(-27.597)))+(-78.509)+(-6.198)+((-90.751+(-52.464)+(-65.98)+(89.055)))+(63.266))/((93.639)));
segmentsAcked = (int) (((64.63)+(31.747)+(94.38)+(-38.178))/((-79.531)));
int hLmsRzabmouoaUzp = (int) (-93.444-(97.743)-(91.468)-(37.819)-(-54.156)-(24.365)-(63.529)-(26.478)-(43.894));
tcb->m_cWnd = (int) (72.266*(8.733)*(-87.883));
segmentsAcked = (int) (((-91.235)+(-22.522)+(45.069)+(-90.605))/((-16.348)));
tcb->m_cWnd = (int) (-70.187*(94.335)*(4.572));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
