int xivmrmUZerpyhgPc = (int) (((92.086)+(72.689)+(31.194)+((52.18+(-60.893)+(65.081)+(-77.175)+(-24.981)+(-20.752)+(51.636)))+(-8.95)+(1.59)+((56.785+(9.327)+(94.506)+(15.105)))+(-92.95))/((91.446)));
int hLmsRzabmouoaUzp = (int) (43.282-(20.408)-(-0.633)-(-98.893)-(-13.939)-(-83.359)-(90.864)-(80.691)-(-17.653));
segmentsAcked = (int) (((-65.07)+(-4.546)+(63.225)+(-35.141))/((-60.826)));
tcb->m_cWnd = (int) (-47.573*(-27.349)*(-68.434));
segmentsAcked = (int) (((-50.423)+(26.389)+(51.977)+(-52.601))/((-15.703)));
segmentsAcked = (int) (((-40.742)+(39.099)+(98.004)+(-33.374))/((5.756)));
tcb->m_cWnd = (int) (70.212*(-88.605)*(88.744));
tcb->m_cWnd = (int) (-39.21*(19.215)*(-97.925));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((-69.001)+(-59.31)+(97.7)+(-30.407))/((-31.512)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-88.428*(49.848)*(-39.404));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (47.18*(-61.887)*(50.402));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (78.821*(-60.38)*(86.295));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
