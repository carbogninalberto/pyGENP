ReduceCwnd (tcb);
int YBVtwHRlQgkcSOdU = (int) (85.383/-46.848);
tcb->m_segmentSize = (int) (10.102-(-42.98)-(40.776)-(-94.361)-(-16.643)-(-46.269)-(53.868));
tcb->m_segmentSize = (int) (66.664-(5.631)-(20.804)-(-46.938)-(63.8)-(-78.319)-(83.628));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
