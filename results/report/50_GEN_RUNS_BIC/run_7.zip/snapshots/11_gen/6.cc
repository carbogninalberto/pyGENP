int xivmrmUZerpyhgPc = (int) (((-84.434)+(71.597)+(-98.955)+((1.803+(81.782)+(-44.674)+(-92.451)+(-6.584)+(80.594)+(-88.842)))+(61.003)+(-33.113)+((81.152+(27.708)+(-20.087)+(-93.829)))+(8.355))/((75.718)));
segmentsAcked = (int) (((36.879)+(96.711)+(-90.425)+(-31.332))/((-99.292)));
int hLmsRzabmouoaUzp = (int) (-74.766-(15.158)-(-31.52)-(-62.378)-(-77.873)-(-76.396)-(85.253)-(-29.94)-(-2.738));
tcb->m_cWnd = (int) (30.979*(44.749)*(25.15));
segmentsAcked = (int) (((6.253)+(80.848)+(95.858)+(-85.103))/((-83.132)));
tcb->m_cWnd = (int) (-10.295*(52.978)*(-81.008));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (60.725*(-95.554)*(-20.568));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-30.101*(-19.766)*(18.374));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
