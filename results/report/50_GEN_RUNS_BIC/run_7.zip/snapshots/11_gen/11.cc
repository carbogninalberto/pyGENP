int hLmsRzabmouoaUzp = (int) (-89.258-(-45.823)-(-9.922)-(22.276)-(99.517)-(-31.468)-(95.496)-(35.428)-(81.129));
segmentsAcked = (int) (((-34.983)+(-66.882)+(61.519)+(62.191))/((-29.478)));
int xivmrmUZerpyhgPc = (int) (((-87.07)+(-12.961)+(24.119)+((7.826+(-68.139)+(87.034)+(-82.818)+(26.214)+(28.072)+(-19.69)))+(-87.489)+(-50.496)+((2.694+(-66.323)+(3.12)+(19.489)))+(-35.087))/((73.518)));
tcb->m_cWnd = (int) (-3.691*(78.714)*(-69.352));
segmentsAcked = (int) (((10.8)+(-36.935)+(-15.723)+(-31.139))/((50.555)));
tcb->m_cWnd = (int) (-7.724*(-46.734)*(32.363));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-62.625*(-70.261)*(67.038));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((52.239)+(59.84)+(43.044)+(90.308))/((-28.86)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-64.05*(20.843)*(10.688));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((35.603)+(-71.404)+(84.711)+(47.858))/((-65.064)));
tcb->m_cWnd = (int) (-64.181*(21.331)*(82.766));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (58.722*(-13.27)*(-29.291));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
