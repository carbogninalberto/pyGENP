int xivmrmUZerpyhgPc = (int) (((32.318)+(7.978)+(16.752)+((-82.969+(-8.763)+(16.152)+(57.928)+(-2.589)+(-4.474)+(-36.459)))+(85.051)+(57.071)+((85.189+(-90.384)+(10.888)+(-52.227)))+(53.829))/((-41.857)));
int hLmsRzabmouoaUzp = (int) (82.417-(-97.586)-(-33.223)-(-72.034)-(93.828)-(-54.47)-(13.66)-(-60.661)-(-96.966));
segmentsAcked = (int) (((12.393)+(0.807)+(51.482)+(-30.363))/((-5.661)));
tcb->m_cWnd = (int) (-12.707*(58.738)*(-56.975));
segmentsAcked = (int) (((56.577)+(74.158)+(-24.987)+(86.454))/((-66.085)));
segmentsAcked = (int) (((-64.897)+(-66.646)+(68.739)+(56.009))/((82.896)));
tcb->m_cWnd = (int) (-33.5*(-49.446)*(-57.703));
tcb->m_cWnd = (int) (97.182*(67.807)*(-5.982));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((-15.729)+(53.676)+(-34.475)+(-16.626))/((-38.45)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (24.097*(97.76)*(-99.918));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-61.151*(36.971)*(0.401));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-59.404*(86.028)*(37.593));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
