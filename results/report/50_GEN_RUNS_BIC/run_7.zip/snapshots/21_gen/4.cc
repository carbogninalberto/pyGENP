tcb->m_segmentSize = (int) (-67.191/91.744);
