float WYnYeVEwOPtoBfCh = (float) (49.539-(95.47)-(-47.722)-(-17.964)-(34.161)-(-1.886)-(87.972)-(-79.786));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
