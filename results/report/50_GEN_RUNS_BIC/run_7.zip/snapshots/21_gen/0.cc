int xivmrmUZerpyhgPc = (int) (((-60.3)+(-6.894)+(-82.607)+((96.997+(51.217)+(47.137)+(27.253)+(-77.615)+(52.824)+(1.837)))+(88.703)+(-51.066)+((36.902+(-45.505)+(-45.143)+(-12.713)))+(-62.464))/((-33.779)));
segmentsAcked = (int) (((40.901)+(-76.405)+(-89.442)+(29.81))/((85.805)));
int hLmsRzabmouoaUzp = (int) (53.672-(-67.895)-(5.186)-(48.299)-(-57.247)-(61.581)-(79.873)-(-25.654)-(-26.19));
tcb->m_cWnd = (int) (-4.843*(25.474)*(29.681));
segmentsAcked = (int) (((-40.283)+(8.439)+(76.924)+(-32.537))/((13.022)));
tcb->m_cWnd = (int) (-55.36*(-40.827)*(82.026));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-82.829*(54.461)*(-41.388));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
