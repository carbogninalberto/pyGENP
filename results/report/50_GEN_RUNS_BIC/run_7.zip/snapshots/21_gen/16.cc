tcb->m_ssThresh = (int) (12.006*(23.186)*(15.306));
tcb->m_cWnd = (int) (tcb->m_cWnd*(42.905)*(tcb->m_cWnd)*(73.263)*(89.4)*(20.108)*(25.604)*(tcb->m_segmentSize)*(49.728));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_ssThresh = (int) (6.251*(70.023)*(17.046)*(52.526)*(80.781)*(33.262)*(99.346)*(36.836));

} else {
	tcb->m_ssThresh = (int) (94.973-(8.868)-(cnt)-(tcb->m_cWnd)-(34.176)-(tcb->m_segmentSize)-(43.098));

}
