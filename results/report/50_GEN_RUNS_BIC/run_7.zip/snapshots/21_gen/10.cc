tcb->m_segmentSize = (int) (-2.124/27.203);
segmentsAcked = (int) (89.362*(-2.634)*(-59.969)*(82.545));
tcb->m_segmentSize = (int) (57.181*(-72.466)*(-89.752));
tcb->m_segmentSize = (int) (58.604/31.827);
ReduceCwnd (tcb);
segmentsAcked = (int) (28.713*(-58.136)*(-62.968)*(-42.198));
tcb->m_segmentSize = (int) (-85.102*(-93.591)*(82.094));
ReduceCwnd (tcb);
