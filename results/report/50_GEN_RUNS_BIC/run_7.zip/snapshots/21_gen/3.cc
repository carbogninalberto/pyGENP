float eYCttdEQBnMtJYcm = (float) (-49.763+(-43.146)+(67.794)+(-19.822)+(95.769)+(-86.283));
float crpzzxeqbKIBvUdq = (float) (79.225-(45.282)-(76.535)-(44.393));
int pctlVvWmaeCDBNSj = (int) 40.747;
tcb->m_segmentSize = (int) (84.53+(45.801)+(61.386)+(84.508)+(85.311)+(71.539));
tcb->m_cWnd = (int) (-75.817*(76.285)*(-25.383)*(-28.832)*(-62.012)*(75.592)*(21.695)*(82.985)*(-72.289));
ReduceCwnd (tcb);
