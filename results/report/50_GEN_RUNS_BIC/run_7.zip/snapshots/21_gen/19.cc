ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (77.972-(13.184)-(15.333)-(83.958)-(52.018)-(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (18.37-(66.056)-(20.118)-(25.62)-(51.868));
	tcb->m_cWnd = (int) (55.14+(77.913)+(segmentsAcked)+(58.107)+(32.873)+(33.811)+(72.333)+(77.441)+(92.495));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(39.821)+(14.622)+(24.565)+(tcb->m_segmentSize)+(35.332)+(95.372));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (((0.1)+(98.198)+((tcb->m_segmentSize*(86.79)*(82.177)*(66.885)))+(38.948))/((60.09)));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (83.965*(62.317)*(66.045)*(segmentsAcked)*(17.269)*(20.817));

}
tcb->m_segmentSize = (int) (95.238/0.1);
cnt = (int) (23.818+(63.17)+(71.09)+(cnt));
tcb->m_ssThresh = (int) (63.755+(76.503)+(38.695));
ReduceCwnd (tcb);
