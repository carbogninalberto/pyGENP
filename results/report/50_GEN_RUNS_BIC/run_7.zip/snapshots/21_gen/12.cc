int xivmrmUZerpyhgPc = (int) (((-63.889)+(-50.237)+(27.044)+((-74.93+(3.785)+(-32.209)+(39.884)+(-54.783)+(-26.537)+(28.458)))+(65.145)+(-64.213)+((-81.461+(72.564)+(10.804)+(-79.383)))+(-19.167))/((16.561)));
segmentsAcked = (int) (((20.953)+(9.137)+(-93.269)+(54.053))/((32.597)));
int hLmsRzabmouoaUzp = (int) (-99.586-(96.413)-(-5.836)-(67.411)-(-10.302)-(-14.151)-(78.682)-(39.638)-(-0.519));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (25.795*(87.328)*(-81.734));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((77.74)+(51.274)+(18.504)+(15.416))/((36.907)));
tcb->m_cWnd = (int) (50.224*(-23.101)*(41.142));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (49.172*(-44.913)*(47.317));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
