tcb->m_ssThresh = (int) (40.864-(11.736));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (6.753*(tcb->m_segmentSize)*(89.124)*(57.168));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (48.742*(66.659)*(77.381));
	tcb->m_segmentSize = (int) (82.576+(segmentsAcked)+(77.335)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(56.539)+(60.993));

}
ReduceCwnd (tcb);
if (cnt != tcb->m_cWnd) {
	cnt = (int) (tcb->m_segmentSize-(86.301));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) ((27.187+(39.444)+(6.813)+(36.08)+(tcb->m_ssThresh)+(87.226)+(50.745)+(tcb->m_cWnd))/0.1);

} else {
	cnt = (int) ((60.382+(57.44)+(23.162)+(30.678)+(99.731)+(51.66)+(57.59)+(20.848))/44.776);
	ReduceCwnd (tcb);

}
float kQQIcdxqFAbnbIhm = (float) (80.778-(47.285));
if (kQQIcdxqFAbnbIhm <= tcb->m_cWnd) {
	kQQIcdxqFAbnbIhm = (float) (72.477+(29.044)+(27.787)+(54.069));
	ReduceCwnd (tcb);

} else {
	kQQIcdxqFAbnbIhm = (float) (81.893*(kQQIcdxqFAbnbIhm)*(tcb->m_cWnd)*(3.058)*(tcb->m_segmentSize)*(2.931)*(1.37));
	tcb->m_cWnd = (int) (kQQIcdxqFAbnbIhm-(segmentsAcked)-(89.671)-(19.666)-(48.157));
	ReduceCwnd (tcb);

}
if (cnt >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.1/53.798);
	tcb->m_segmentSize = (int) (0.1/(65.705*(50.582)*(56.857)*(10.814)*(94.884)*(54.205)*(53.023)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (0.1/(1.592+(tcb->m_ssThresh)+(45.144)+(segmentsAcked)+(60.617)+(20.358)+(66.248)+(68.784)+(14.795)));

}
tcb->m_ssThresh = (int) (segmentsAcked*(segmentsAcked)*(60.892)*(48.929)*(tcb->m_cWnd));
if (tcb->m_cWnd > cnt) {
	kQQIcdxqFAbnbIhm = (float) (21.696+(63.636)+(73.934)+(cnt)+(44.443)+(29.695)+(tcb->m_ssThresh)+(34.432)+(45.954));
	segmentsAcked = (int) (12.295-(69.07)-(20.586)-(13.279));
	tcb->m_ssThresh = (int) ((tcb->m_cWnd-(79.972)-(29.506)-(7.529)-(73.514))/0.1);

} else {
	kQQIcdxqFAbnbIhm = (float) (96.415/0.1);
	tcb->m_segmentSize = (int) (kQQIcdxqFAbnbIhm+(tcb->m_segmentSize)+(kQQIcdxqFAbnbIhm)+(tcb->m_segmentSize)+(34.946)+(51.342)+(63.093)+(tcb->m_ssThresh)+(39.702));

}
