float FgzXCLEkXdCpUaEB = (float) (-57.806+(37.636));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
