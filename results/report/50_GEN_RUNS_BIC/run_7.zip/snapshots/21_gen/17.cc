tcb->m_cWnd = (int) (88.64+(53.621)+(tcb->m_ssThresh)+(79.686));
ReduceCwnd (tcb);
int CzQNYfiKFzRxqYzI = (int) (14.405-(96.073));
if (cnt >= cnt) {
	CzQNYfiKFzRxqYzI = (int) (90.699+(35.397)+(98.139));

} else {
	CzQNYfiKFzRxqYzI = (int) (4.8-(tcb->m_segmentSize)-(60.165));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) ((tcb->m_ssThresh-(16.036)-(60.295)-(59.254)-(cnt)-(4.541))/0.1);
