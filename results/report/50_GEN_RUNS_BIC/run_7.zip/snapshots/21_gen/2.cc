int xivmrmUZerpyhgPc = (int) (((-7.804)+(97.818)+(96.458)+((95.382+(29.193)+(2.22)+(-9.413)+(-45.298)+(-63.457)+(93.551)))+(-97.493)+(33.155)+((-87.654+(-21.269)+(-8.476)+(-50.991)))+(58.057))/((-96.191)));
segmentsAcked = (int) (((20.908)+(50.393)+(-72.282)+(65.266))/((7.908)));
int hLmsRzabmouoaUzp = (int) (-15.292-(-19.69)-(-75.689)-(53.57)-(-25.911)-(-1.769)-(92.384)-(11.323)-(-39.175));
tcb->m_cWnd = (int) (58.869*(76.219)*(63.21));
segmentsAcked = (int) (((-60.677)+(-62.646)+(-81.462)+(81.975))/((-61.206)));
tcb->m_cWnd = (int) (-55.775*(-35.495)*(33.986));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-63.039*(97.118)*(-3.591));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
