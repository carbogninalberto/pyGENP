ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) ((((24.577-(93.114)))+(27.841)+(0.1)+(91.89))/((0.1)+(0.1)+(25.14)+(0.1)));
float DYtcvMzCUbCuYTGM = (float) (0.1/34.334);
