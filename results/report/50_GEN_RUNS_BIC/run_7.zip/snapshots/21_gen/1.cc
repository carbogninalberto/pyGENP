int xivmrmUZerpyhgPc = (int) (((54.439)+(17.358)+(8.288)+((-28.916+(80.827)+(31.861)+(96.891)+(-24.267)+(-62.715)+(-78.715)))+(70.887)+(-50.041)+((14.544+(-99.518)+(-71.811)+(-18.264)))+(-93.134))/((93.154)));
segmentsAcked = (int) (((-12.164)+(78.795)+(73.488)+(-22.838))/((-88.071)));
int hLmsRzabmouoaUzp = (int) (92.836-(-12.949)-(-86.575)-(-8.816)-(88.124)-(2.667)-(4.317)-(-36.926)-(-24.693));
tcb->m_cWnd = (int) (91.631*(47.001)*(-38.551));
segmentsAcked = (int) (((57.371)+(-16.188)+(-30.955)+(-9.106))/((-44.129)));
tcb->m_cWnd = (int) (19.974*(14.397)*(48.321));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (33.188*(9.521)*(-66.768));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-75.912*(-80.681)*(32.854));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
