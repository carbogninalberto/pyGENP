if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (15.006-(tcb->m_segmentSize));
int CTklpvFQORCfxvNn = (int) (73.798+(16.212)+(74.719)+(56.816));
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(38.852)*(58.391)*(61.326));

} else {
	tcb->m_cWnd = (int) (0.1/99.346);
	segmentsAcked = (int) (71.794-(97.734)-(4.479));

}
