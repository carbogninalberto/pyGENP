int xivmrmUZerpyhgPc = (int) (((-24.63)+(-41.675)+(-23.957)+((-43.523+(74.443)+(88.945)+(17.723)+(75.361)+(7.383)+(-46.634)))+(76.347)+(-69.442)+((20.737+(-41.857)+(-48.109)+(40.453)))+(-83.06))/((-99.776)));
segmentsAcked = (int) (((-0.304)+(-10.496)+(-76.64)+(-43.793))/((-68.723)));
int hLmsRzabmouoaUzp = (int) (21.392-(-35.682)-(84.228)-(-12.486)-(-32.355)-(-74.57)-(-54.888)-(-14.87)-(-51.623));
tcb->m_cWnd = (int) (13.651*(69.128)*(-55.724));
segmentsAcked = (int) (((-48.827)+(73.388)+(77.535)+(-71.068))/((-61.791)));
tcb->m_cWnd = (int) (-73.186*(76.552)*(-27.816));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-69.462*(98.493)*(6.535));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((-97.07)+(58.663)+(-70.669)+(-48.926))/((83.199)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-4.001*(-85.585)*(81.996));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((20.487)+(-4.041)+(-45.345)+(-62.171))/((40.912)));
tcb->m_cWnd = (int) (58.813*(-0.396)*(-49.774));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-20.03*(9.613)*(94.449));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
