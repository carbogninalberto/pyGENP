int wnBCsGnFYtajmHET = (int) (90.826*(7.56)*(-7.236)*(50.129)*(0.26)*(55.399)*(-63.147)*(89.179));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-87.65-(-2.875)-(-32.769)-(86.799)-(44.4)-(85.524)-(42.865));
tcb->m_segmentSize = (int) (-62.683-(0.434)-(52.971)-(96.978)-(91.74)-(98.507)-(40.681));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
