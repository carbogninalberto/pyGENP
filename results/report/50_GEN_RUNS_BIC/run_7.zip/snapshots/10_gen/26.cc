int xivmrmUZerpyhgPc = (int) (((30.364)+(-54.987)+(-64.484)+((-16.563+(89.703)+(74.373)+(82.762)+(45.976)+(-95.445)+(-30.174)))+(93.056)+(-27.737)+((83.65+(-54.625)+(-23.637)+(75.019)))+(-47.532))/((20.902)));
segmentsAcked = (int) (((11.424)+(13.071)+(-72.984)+(-91.491))/((-65.25)));
int hLmsRzabmouoaUzp = (int) (-0.671-(-88.35)-(-18.791)-(-23.235)-(57.287)-(84.748)-(-36.427)-(-7.979)-(19.006));
tcb->m_cWnd = (int) (69.268*(-56.252)*(47.812));
tcb->m_cWnd = (int) (-77.194*(22.436)*(-15.791));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((79.643)+(27.86)+(36.316)+(66.836))/((-83.458)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (84.207*(34.278)*(52.113));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
