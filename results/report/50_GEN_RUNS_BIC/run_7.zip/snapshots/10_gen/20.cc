if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (13.185/61.307);
tcb->m_segmentSize = (int) (-16.739+(-39.549)+(-34.99)+(-12.205)+(-51.219)+(-26.556)+(-28.793)+(-12.882)+(-18.419));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-2.031+(10.005)+(-25.116)+(-6.797)+(-27.982)+(42.162)+(-8.06)+(7.126)+(6.121));
