int xivmrmUZerpyhgPc = (int) (((-49.094)+(26.204)+(33.314)+((21.74+(90.977)+(-16.744)+(57.276)+(44.426)+(61.463)+(18.081)))+(-40.759)+(-42.766)+((55.663+(24.231)+(-45.739)+(-17.348)))+(-49.669))/((-50.235)));
segmentsAcked = (int) (((40.452)+(-21.511)+(-84.321)+(59.168))/((-49.737)));
int hLmsRzabmouoaUzp = (int) (41.428-(81.159)-(-95.843)-(55.437)-(88.112)-(-21.687)-(-29.797)-(71.491)-(87.635));
tcb->m_cWnd = (int) (6.16*(-56.404)*(85.107));
segmentsAcked = (int) (((-67.37)+(-65.869)+(30.669)+(-8.193))/((12.959)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (52.875*(10.173)*(41.672));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
