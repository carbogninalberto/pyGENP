if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int wnBCsGnFYtajmHET = (int) (41.279*(-37.775)*(-0.87)*(-8.503)*(19.483)*(66.231)*(-23.98)*(83.02));
float FlFEwwMcktruaxSw = (float) (6.877*(30.553)*(39.182)*(13.505)*(21.954)*(96.039)*(-86.782)*(-87.991));
