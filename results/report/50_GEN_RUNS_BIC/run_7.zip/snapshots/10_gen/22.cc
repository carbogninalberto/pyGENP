float CVwJoesneNJtOEwg = (float) (55.084/-40.124);
