int xivmrmUZerpyhgPc = (int) (((-93.178)+(20.189)+(-37.435)+((3.415+(1.968)+(29.971)+(11.621)+(41.278)+(-11.206)+(-73.984)))+(-50.761)+(-59.074)+((86.971+(5.008)+(63.681)+(37.824)))+(41.819))/((31.27)));
segmentsAcked = (int) (((-49.906)+(9.486)+(-59.719)+(-37.719))/((-58.305)));
int hLmsRzabmouoaUzp = (int) (26.101-(12.044)-(17.461)-(42.629)-(-84.362)-(-10.155)-(-16.981)-(17.991)-(28.868));
tcb->m_cWnd = (int) (-93.558*(66.885)*(-99.837));
segmentsAcked = (int) (((-12.352)+(-84.479)+(89.837)+(50.651))/((29.859)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (98.282*(-74.917)*(-63.108));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
