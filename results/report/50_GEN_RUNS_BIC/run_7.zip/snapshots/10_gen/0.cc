int xivmrmUZerpyhgPc = (int) (((8.811)+(-30.001)+(90.403)+((-30.322+(-20.38)+(40.708)+(92.509)+(9.726)+(-44.705)+(-38.871)))+(-19.321)+(51.985)+((-20.086+(8.307)+(25.632)+(21.931)))+(-51.317))/((-97.09)));
segmentsAcked = (int) (((46.961)+(66.315)+(45.317)+(-54.863))/((-78.546)));
int hLmsRzabmouoaUzp = (int) (-51.264-(-23.958)-(25.634)-(-62.38)-(97.005)-(70.411)-(14.494)-(-87.458)-(93.803));
tcb->m_cWnd = (int) (-37.735*(80.827)*(46.297));
segmentsAcked = (int) (((13.079)+(-68.202)+(-60.152)+(7.233))/((88.741)));
tcb->m_cWnd = (int) (-8.251*(-47.926)*(-25.806));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-68.195*(-11.611)*(1.888));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
