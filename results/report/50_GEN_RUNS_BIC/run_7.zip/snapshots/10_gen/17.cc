if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-81.373+(15.533)+(85.665)+(-85.628)+(-10.195)+(87.154)+(-49.764)+(68.172)+(-46.134));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-41.201+(78.072)+(-72.739)+(45.443)+(65.76)+(-6.254)+(-42.854)+(25.651)+(2.125));
