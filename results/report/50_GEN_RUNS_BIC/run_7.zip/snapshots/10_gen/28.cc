ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (34.48-(63.64)-(99.227)-(16.415)-(67.393));
segmentsAcked = (int) (-25.385*(87.86)*(67.049)*(90.292)*(26.591)*(71.089)*(-13.417)*(-77.487));
