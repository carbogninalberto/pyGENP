int JsDlTXFHlHJHsPzo = (int) (9.902*(-76.159)*(-43.284)*(55.306)*(55.646)*(71.878));
int iTEruEtVsgnINehg = (int) (-12.892-(-30.144)-(32.313));
segmentsAcked = (int) (1.535-(-93.43)-(24.524)-(-76.695));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
