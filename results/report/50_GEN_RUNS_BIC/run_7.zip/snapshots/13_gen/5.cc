int xivmrmUZerpyhgPc = (int) (((-18.238)+(38.5)+(-45.722)+((-39.158+(-29.783)+(99.094)+(-17.571)+(45.416)+(-74.699)+(-45.768)))+(92.668)+(13.559)+((77.545+(-89.982)+(-84.703)+(-76.855)))+(-66.477))/((39.005)));
segmentsAcked = (int) (((-58.069)+(-93.079)+(34.416)+(-83.245))/((-46.899)));
int hLmsRzabmouoaUzp = (int) (96.065-(-73.129)-(32.894)-(41.281)-(36.693)-(79.217)-(41.172)-(37.41)-(18.182));
tcb->m_cWnd = (int) (81.022*(67.56)*(39.735));
segmentsAcked = (int) (((-66.575)+(57.194)+(39.832)+(-40.462))/((-26.496)));
tcb->m_cWnd = (int) (-78.773*(30.116)*(-96.514));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((-70.699)+(-19.203)+(-8.547)+(30.083))/((-11.335)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (96.73*(90.828)*(-92.936));
tcb->m_cWnd = (int) (30.7*(52.704)*(98.475));
segmentsAcked = (int) (((15.467)+(60.529)+(86.71)+(89.907))/((41.81)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (88.229*(-11.175)*(-6.535));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (24.871*(-39.937)*(92.846));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
