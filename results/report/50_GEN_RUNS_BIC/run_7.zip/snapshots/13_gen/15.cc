tcb->m_cWnd = (int) (-27.164/44.04);
