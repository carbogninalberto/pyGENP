int iasDTazptaVOUdnS = (int) (((-83.806)+(74.394)+(-53.446)+(-61.887))/((-71.418)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (99.516+(75.213)+(95.141)+(-16.242)+(-19.979));
