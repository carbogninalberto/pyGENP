int xivmrmUZerpyhgPc = (int) (((7.298)+(-23.514)+(-6.944)+((-76.609+(-30.398)+(69.504)+(-41.745)+(-5.346)+(21.109)+(-55.461)))+(-10.828)+(-8.995)+((71.934+(80.464)+(67.732)+(-16.714)))+(-12.715))/((78.149)));
int hLmsRzabmouoaUzp = (int) (-49.019-(-57.161)-(65.602)-(-28.61)-(-14.568)-(-9.784)-(-11.44)-(-16.341)-(-15.115));
segmentsAcked = (int) (((-75.273)+(96.825)+(-89.935)+(-90.648))/((-92.212)));
tcb->m_cWnd = (int) (47.512*(-6.661)*(-61.723));
segmentsAcked = (int) (((-89.774)+(-87.836)+(71.334)+(-94.863))/((-95.916)));
segmentsAcked = (int) (((-20.088)+(86.046)+(-60.101)+(23.752))/((-27.182)));
tcb->m_cWnd = (int) (61.185*(-47.076)*(-78.983));
tcb->m_cWnd = (int) (-80.735*(10.185)*(-51.388));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((-70.931)+(33.666)+(-37.196)+(49.175))/((59.598)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (50.165*(19.413)*(-77.909));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-54.405*(-77.267)*(-77.388));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (28.526*(-58.525)*(8.654));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
