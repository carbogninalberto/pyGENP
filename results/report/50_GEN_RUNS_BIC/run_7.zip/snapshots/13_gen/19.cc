ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (69.932+(cnt)+(tcb->m_segmentSize));
segmentsAcked = (int) (75.056-(75.437)-(40.479)-(86.457)-(tcb->m_ssThresh)-(40.279)-(47.82)-(91.511)-(32.473));
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (22.821-(78.968));

} else {
	tcb->m_segmentSize = (int) (cnt-(cnt)-(cnt));
	tcb->m_ssThresh = (int) (66.117*(tcb->m_ssThresh)*(66.702)*(8.756)*(1.479)*(77.972));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
