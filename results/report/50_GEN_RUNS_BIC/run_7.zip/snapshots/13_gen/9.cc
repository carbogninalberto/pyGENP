int hLmsRzabmouoaUzp = (int) (-99.236-(-97.397)-(-35.834)-(-50.884)-(-56.053)-(-57.543)-(78.682)-(-89.957)-(-84.743));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int xivmrmUZerpyhgPc = (int) (((9.148)+(-63.557)+(43.673)+((-5.482+(83.418)+(-64.196)+(-1.766)+(73.564)+(-1.335)+(-86.029)))+(57.56)+(-77.209)+((11.06+(63.887)+(-35.084)+(-39.436)))+(86.981))/((-30.723)));
segmentsAcked = (int) (((-76.996)+(16.824)+(-70.216)+(-55.787))/((-93.6)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-12.008*(30.614)*(-47.407));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((58.967)+(-57.845)+(97.177)+(99.517))/((-53.02)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (31.782*(84.085)*(29.506));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
