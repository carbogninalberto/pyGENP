tcb->m_ssThresh = (int) ((1.397-(87.118)-(83.075)-(30.421)-(25.842))/38.724);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (88.532*(66.276));
if (cnt == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (39.371*(77.193)*(70.624)*(61.48)*(48.037)*(46.908)*(3.501)*(50.317));
	tcb->m_cWnd = (int) (segmentsAcked*(11.452));
	segmentsAcked = (int) (25.079-(58.287)-(91.693)-(62.908)-(segmentsAcked)-(16.313)-(45.305));

} else {
	tcb->m_ssThresh = (int) (24.73+(tcb->m_segmentSize)+(34.938)+(92.8)+(26.646)+(45.825));
	cnt = (int) ((((97.187-(92.988)-(47.475)-(80.476)))+((99.142-(6.209)))+(0.1)+(0.1)+(40.949)+(40.421))/((0.1)+(0.1)));

}
if (tcb->m_cWnd == cnt) {
	segmentsAcked = (int) (12.884+(13.795)+(38.035)+(63.898)+(24.706)+(54.541));

} else {
	segmentsAcked = (int) (38.875-(12.526)-(59.218)-(67.809)-(84.446)-(61.833)-(19.546));
	segmentsAcked = (int) (58.135*(cnt)*(10.952)*(33.579)*(60.386)*(33.297));

}
