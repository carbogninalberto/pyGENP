ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (55.958+(49.413)+(78.439)+(tcb->m_segmentSize)+(14.242));
if (segmentsAcked <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (74.49+(48.767)+(92.388));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (41.009+(78.807)+(38.761)+(16.966)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(63.531)+(83.914));

} else {
	tcb->m_ssThresh = (int) (88.858*(73.731)*(30.752)*(31.071)*(70.237)*(70.539)*(segmentsAcked)*(64.035)*(42.177));
	tcb->m_ssThresh = (int) (segmentsAcked*(52.131));
	cnt = (int) (14.975*(38.217)*(62.568)*(tcb->m_cWnd)*(67.848)*(93.193)*(23.846));

}
ReduceCwnd (tcb);
