if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_segmentSize = (int) (76.221*(7.795));

} else {
	tcb->m_segmentSize = (int) (24.616/73.2);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked <= tcb->m_cWnd) {
	segmentsAcked = (int) (92.181*(53.185)*(68.859)*(74.742)*(91.595)*(11.231));

} else {
	segmentsAcked = (int) (54.889*(75.546)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(48.569)*(66.645)*(76.146));

}
ReduceCwnd (tcb);
