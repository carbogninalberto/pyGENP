if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (((22.055)+((63.718*(6.978)*(11.341)*(segmentsAcked)*(44.774)))+(15.495)+(75.828)+(0.1)+(0.1)+(0.1))/((45.745)));
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (54.951-(tcb->m_ssThresh)-(81.499)-(24.303)-(57.87));
	tcb->m_cWnd = (int) (((0.1)+(65.468)+(0.1)+(0.1)+(0.1))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (((88.101)+(47.101)+(56.233)+(81.04)+(0.1))/((0.1)));
	tcb->m_segmentSize = (int) (87.326/0.1);
	tcb->m_cWnd = (int) (8.645*(93.735));

}
ReduceCwnd (tcb);
cnt = (int) (59.933/0.1);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	segmentsAcked = (int) (85.289-(89.607)-(11.984)-(93.176)-(8.726));

} else {
	segmentsAcked = (int) (24.19*(57.697)*(58.427)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(41.948)*(7.864)*(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
