ReduceCwnd (tcb);
cnt = (int) (cnt*(segmentsAcked)*(45.291)*(37.155)*(14.099)*(48.22));
tcb->m_cWnd = (int) (11.58/9.623);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (78.011-(32.592)-(66.781)-(60.062)-(58.104)-(15.003)-(62.108)-(tcb->m_cWnd));
cnt = (int) (25.818+(79.987)+(25.103)+(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (0.1/0.1);
