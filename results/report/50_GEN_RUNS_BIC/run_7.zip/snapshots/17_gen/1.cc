if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-67.232+(95.411)+(-10.974)+(-78.646)+(15.404)+(-32.852)+(33.745)+(-37.988)+(-90.958));
segmentsAcked = (int) (-41.639+(-44.955)+(5.636)+(-1.247));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
