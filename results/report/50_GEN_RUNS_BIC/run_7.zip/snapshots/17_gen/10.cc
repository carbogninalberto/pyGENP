int xivmrmUZerpyhgPc = (int) (((22.351)+(-17.864)+(29.993)+((19.295+(51.152)+(-46.941)+(-66.85)+(98.992)+(-71.986)+(-2.235)))+(43.207)+(94.568)+((-7.548+(-13.192)+(63.587)+(3.586)))+(-68.737))/((-38.504)));
segmentsAcked = (int) (((89.812)+(51.774)+(80.689)+(-69.897))/((-66.528)));
int hLmsRzabmouoaUzp = (int) (61.926-(-28.23)-(-44.249)-(-54.074)-(3.258)-(76.78)-(9.197)-(41.979)-(-22.255));
tcb->m_cWnd = (int) (-97.496*(7.736)*(-9.353));
segmentsAcked = (int) (((53.637)+(-90.088)+(-30.481)+(-82.341))/((-18.089)));
tcb->m_cWnd = (int) (52.237*(-26.664)*(45.22));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (28.042*(-69.191)*(31.054));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
