int xivmrmUZerpyhgPc = (int) (((-55.23)+(-53.912)+(26.644)+((48.692+(67.961)+(96.413)+(-26.575)+(-94.026)+(6.536)+(-62.112)))+(-40.49)+(-45.603)+((60.602+(-71.449)+(80.695)+(12.964)))+(46.586))/((-12.453)));
segmentsAcked = (int) (((-85.836)+(94.925)+(-86.61)+(-81.006))/((-64.604)));
int hLmsRzabmouoaUzp = (int) (-92.99-(-7.499)-(-73.98)-(-12.06)-(50.47)-(-38.013)-(91.13)-(-64.539)-(-78.744));
tcb->m_cWnd = (int) (-61.005*(27.921)*(-7.497));
segmentsAcked = (int) (((74.104)+(-32.768)+(30.266)+(29.06))/((-3.525)));
tcb->m_cWnd = (int) (28.333*(31.177)*(87.844));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (26.986*(80.665)*(87.411));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (19.157*(-51.282)*(4.122));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
