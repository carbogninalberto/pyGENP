int xivmrmUZerpyhgPc = (int) (((50.838)+(-36.433)+(48.052)+((32.908+(33.782)+(-79.825)+(95.476)+(-72.723)+(32.242)+(-43.84)))+(77.059)+(-54.917)+((-68.994+(72.01)+(-24.83)+(63.654)))+(11.672))/((-40.509)));
segmentsAcked = (int) (((12.194)+(-50.175)+(-90.108)+(24.958))/((-4.103)));
int hLmsRzabmouoaUzp = (int) (-24.944-(-95.836)-(-64.512)-(7.123)-(97.171)-(59.359)-(-56.644)-(-92.399)-(-78.802));
tcb->m_cWnd = (int) (-32.611*(-40.546)*(15.49));
segmentsAcked = (int) (((57.824)+(89.239)+(64.161)+(-17.477))/((26.353)));
tcb->m_cWnd = (int) (-75.322*(-73.352)*(-75.991));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-47.918*(-95.802)*(-81.636));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
