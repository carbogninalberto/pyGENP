int xivmrmUZerpyhgPc = (int) (((-52.921)+(-41.93)+(-38.665)+((-36.562+(-40.077)+(63.336)+(-27.443)+(-55.729)+(34.255)+(-14.858)))+(-21.118)+(49.861)+((99.635+(-22.582)+(46.103)+(-48.325)))+(84.459))/((-46.442)));
segmentsAcked = (int) (((-82.359)+(-50.572)+(27.887)+(-67.871))/((69.905)));
int hLmsRzabmouoaUzp = (int) (-57.776-(70.312)-(-62.543)-(-78.549)-(-77.062)-(-80.85)-(-2.283)-(-31.796)-(26.853));
tcb->m_cWnd = (int) (51.206*(-90.35)*(96.761));
segmentsAcked = (int) (((94.766)+(33.377)+(82.841)+(-67.267))/((82.059)));
tcb->m_cWnd = (int) (-15.384*(-75.07)*(68.015));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-1.099*(11.594)*(86.127));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
