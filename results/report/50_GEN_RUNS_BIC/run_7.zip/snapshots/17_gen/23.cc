tcb->m_segmentSize = (int) (11.975+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(47.254)+(6.292)+(tcb->m_ssThresh)+(17.721)+(74.238));
tcb->m_segmentSize = (int) (((3.052)+(0.1)+(0.1)+(0.1)+((4.011+(60.012)+(68.166)+(78.517)))+(0.1)+(0.1))/((0.1)+(10.53)));
int ceiiAPDdydiUnGUD = (int) (tcb->m_cWnd+(87.76)+(17.151)+(94.555)+(42.906)+(70.239));
tcb->m_cWnd = (int) (7.604-(14.049)-(28.396)-(47.786)-(63.321)-(ceiiAPDdydiUnGUD)-(78.545)-(67.894));
ceiiAPDdydiUnGUD = (int) (65.207*(10.214)*(4.024)*(tcb->m_segmentSize)*(63.035));
