cnt = (int) (78.455+(cnt)+(26.477)+(tcb->m_cWnd)+(71.964)+(76.308)+(62.286));
tcb->m_ssThresh = (int) (83.945*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(52.576)*(0.51)*(83.449)*(13.306)*(84.137)*(32.128));
ReduceCwnd (tcb);
segmentsAcked = (int) (66.687-(29.2)-(74.638)-(60.923)-(14.141));
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (segmentsAcked-(segmentsAcked)-(99.027)-(98.498)-(tcb->m_cWnd)-(31.716)-(25.766));

} else {
	tcb->m_ssThresh = (int) (77.267*(tcb->m_segmentSize)*(96.171)*(40.521)*(52.796));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt <= tcb->m_segmentSize) {
	cnt = (int) (97.205-(29.516)-(tcb->m_cWnd)-(51.833)-(44.736)-(51.888)-(2.674)-(95.097));
	tcb->m_ssThresh = (int) (12.639*(31.786)*(19.457)*(62.026)*(36.27)*(81.736)*(19.228)*(53.234));

} else {
	cnt = (int) (85.757+(98.299)+(79.261)+(39.485)+(segmentsAcked)+(54.172));
	cnt = (int) (29.178+(66.042)+(66.027)+(segmentsAcked)+(82.717)+(segmentsAcked));

}
if (tcb->m_ssThresh < cnt) {
	cnt = (int) (92.136/86.876);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (13.123-(5.11)-(77.018));
	tcb->m_cWnd = (int) (21.146-(96.435));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
