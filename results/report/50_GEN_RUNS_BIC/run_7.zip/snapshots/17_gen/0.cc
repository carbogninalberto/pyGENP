int xivmrmUZerpyhgPc = (int) (((-70.012)+(-25.174)+(-74.141)+((46.682+(57.109)+(49.264)+(43.994)+(-32.339)+(-83.791)+(67.091)))+(21.644)+(74.122)+((-7.485+(25.644)+(27.187)+(-30.057)))+(8.219))/((-95.037)));
segmentsAcked = (int) (((91.876)+(98.505)+(-6.946)+(89.252))/((39.013)));
int hLmsRzabmouoaUzp = (int) (-5.134-(96.961)-(-0.078)-(-55.098)-(88.583)-(-73.187)-(-70.149)-(-30.338)-(-6.218));
tcb->m_cWnd = (int) (75.811*(65.446)*(49.157));
segmentsAcked = (int) (((-53.585)+(65.34)+(-26.612)+(72.345))/((35.544)));
tcb->m_cWnd = (int) (41.878*(31.356)*(10.593));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-63.02*(44.954)*(47.29));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
