ReduceCwnd (tcb);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (cnt*(tcb->m_ssThresh)*(0.44)*(73.887)*(37.044));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (52.847*(76.572)*(47.914));

} else {
	tcb->m_ssThresh = (int) (75.792+(18.443)+(81.974)+(43.056)+(76.949)+(16.72)+(69.348)+(56.427));

}
if (cnt == segmentsAcked) {
	segmentsAcked = (int) (92.714+(tcb->m_segmentSize)+(tcb->m_cWnd)+(88.938)+(tcb->m_ssThresh)+(28.644)+(tcb->m_cWnd)+(59.754));
	cnt = (int) (((65.383)+(70.255)+(20.689)+(0.1))/((44.424)));

} else {
	segmentsAcked = (int) (((0.1)+((48.187+(59.744)))+(19.358)+((25.31-(93.531)-(16.624)-(48.797)-(51.856)-(90.332)-(18.369)-(69.429)-(44.195)))+(13.174))/((55.394)+(0.1)));

}
if (segmentsAcked >= cnt) {
	tcb->m_cWnd = (int) (29.232/(59.977*(19.817)*(88.893)*(72.184)*(segmentsAcked)*(3.261)*(96.833)*(tcb->m_cWnd)));

} else {
	tcb->m_cWnd = (int) (83.968*(58.856)*(9.851));

}
if (tcb->m_ssThresh < cnt) {
	cnt = (int) (11.154-(54.527)-(cnt));
	tcb->m_ssThresh = (int) (((76.5)+(72.635)+((tcb->m_cWnd-(28.843)-(91.809)-(31.508)-(tcb->m_cWnd)-(95.908)))+(40.71))/((76.897)+(6.025)+(0.1)));

} else {
	cnt = (int) (0.1/40.846);
	tcb->m_segmentSize = (int) (6.728*(73.385)*(tcb->m_ssThresh)*(16.969)*(62.16)*(32.714)*(11.174));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(37.675)*(35.366)*(22.156)*(92.602)*(15.663)*(tcb->m_ssThresh));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
