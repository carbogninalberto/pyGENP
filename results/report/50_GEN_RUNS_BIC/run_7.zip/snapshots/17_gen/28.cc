ReduceCwnd (tcb);
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (65.681/38.265);
	segmentsAcked = (int) (4.803+(tcb->m_segmentSize)+(60.817)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (49.968+(segmentsAcked)+(89.178));
	tcb->m_cWnd = (int) (7.351*(tcb->m_cWnd)*(72.145)*(54.679));
	tcb->m_ssThresh = (int) (78.889+(cnt)+(5.332)+(33.872)+(43.365)+(20.971));

}
tcb->m_cWnd = (int) (0.1/50.263);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (96.812/0.1);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (45.934+(57.513));
