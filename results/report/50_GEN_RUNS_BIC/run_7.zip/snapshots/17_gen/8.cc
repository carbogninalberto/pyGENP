int DBIDrcAkFenkPiNq = (int) (43.71*(-81.265)*(37.543)*(21.716));
float llSaNhozHVpDIKAW = (float) 97.726;
