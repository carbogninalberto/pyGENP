cnt = (int) (((47.309)+((89.014-(19.977)))+(0.1)+(0.1)+(0.1))/((0.1)+(38.245)+(83.281)));
tcb->m_ssThresh = (int) (42.788+(56.545)+(88.843)+(segmentsAcked)+(segmentsAcked)+(31.995)+(70.957));
if (cnt < tcb->m_segmentSize) {
	cnt = (int) (27.249*(tcb->m_segmentSize)*(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (80.911+(34.041));
	ReduceCwnd (tcb);

} else {
	cnt = (int) ((((42.369-(tcb->m_cWnd)-(segmentsAcked)))+(77.931)+(59.345)+(7.561))/((7.288)+(75.938)+(10.371)+(0.1)));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
