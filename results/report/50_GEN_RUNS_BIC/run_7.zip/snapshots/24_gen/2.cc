int EhFpcWJWZQsqTDdP = (int) (58.053/-37.838);
int FjggPeSMLGKkCNSh = (int) 92.943;
tcb->m_cWnd = (int) (-48.749-(65.716)-(67.905)-(-47.441));
ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (78.247/56.307);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (24.176-(29.611)-(85.947)-(segmentsAcked)-(82.516)-(13.91)-(8.398)-(15.466)-(39.02));
	tcb->m_segmentSize = (int) (45.202*(47.088));

}
