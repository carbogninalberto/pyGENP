ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (25.64*(tcb->m_cWnd)*(99.494)*(tcb->m_ssThresh)*(19.572)*(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (22.625-(0.206));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (52.534*(81.178)*(10.526)*(segmentsAcked)*(cnt));

} else {
	tcb->m_ssThresh = (int) (98.279+(77.071)+(81.214)+(88.106)+(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (((0.1)+(16.556)+(46.472)+(0.1)+(17.558))/((55.492)+(5.561)+(57.173)));

}
if (tcb->m_cWnd <= tcb->m_cWnd) {
	segmentsAcked = (int) (((96.801)+(0.1)+(0.1)+(0.1)+((92.816-(26.956)))+(62.188)+(56.301))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (47.663*(34.306)*(cnt));

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(18.258))/((0.1)+(27.55)+(0.1)));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= tcb->m_cWnd) {
	cnt = (int) (segmentsAcked-(11.816)-(67.529)-(95.292)-(63.067)-(7.932)-(tcb->m_cWnd));
	cnt = (int) ((((segmentsAcked*(80.525)*(13.324)*(82.594)*(40.541)))+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(97.007)+(63.928)));

} else {
	cnt = (int) (84.902*(51.647)*(66.538));
	tcb->m_cWnd = (int) ((((83.876*(segmentsAcked)*(39.842)*(tcb->m_ssThresh)*(cnt)*(44.895)*(29.845)*(15.227)))+(95.372)+(0.1)+(33.426))/((0.1)+(67.943)));

}
int FhLQXKFsllCvGygx = (int) (0.1/14.343);
