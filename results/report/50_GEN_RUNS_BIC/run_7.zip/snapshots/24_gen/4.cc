if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((52.195)+(48.526)+(0.1)+(96.371)+(0.1))/((19.992)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (0.1/70.937);
	ReduceCwnd (tcb);

}
if (segmentsAcked <= tcb->m_cWnd) {
	segmentsAcked = (int) (22.747*(segmentsAcked)*(0.54)*(22.595)*(62.291)*(57.191));

} else {
	segmentsAcked = (int) (0.1/0.1);
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
