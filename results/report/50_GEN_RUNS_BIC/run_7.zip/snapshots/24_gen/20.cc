float aNNpRqebshbjxMEj = (float) (75.428+(58.289)+(tcb->m_cWnd)+(32.044)+(41.083)+(38.004)+(31.8)+(82.788)+(tcb->m_segmentSize));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(20.251)-(50.16));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (15.865*(14.933)*(56.864)*(82.74));

} else {
	tcb->m_segmentSize = (int) (99.048+(12.711)+(5.477)+(98.87)+(65.515)+(65.695));

}
aNNpRqebshbjxMEj = (float) (99.928+(74.167)+(84.547)+(91.265)+(29.935)+(61.734)+(cnt)+(45.347));
cnt = (int) (31.017-(23.356)-(tcb->m_ssThresh)-(cnt)-(51.06)-(60.921)-(25.288)-(84.727)-(90.273));
