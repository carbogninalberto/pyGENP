if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (58.171+(7.708)+(59.174)+(30.199)+(18.701)+(17.906)+(36.722)+(60.588));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(72.254)-(96.103)-(2.974)-(63.653)-(25.292)-(80.028)-(63.578));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked*(70.425)*(tcb->m_cWnd)*(80.082)*(67.544)*(50.706));

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (cnt*(10.953)*(46.832)*(12.285)*(40.088)*(8.46));
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(15.339))/((0.1)+(0.1)+(48.392)+(0.1)));
	tcb->m_segmentSize = (int) (11.326/0.1);

} else {
	tcb->m_segmentSize = (int) (32.607+(segmentsAcked)+(99.838)+(cnt)+(82.834)+(91.594)+(17.244)+(43.257)+(53.112));

}
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (76.487*(24.816)*(75.918)*(segmentsAcked)*(61.921));

} else {
	tcb->m_segmentSize = (int) (1.511-(tcb->m_cWnd)-(98.774)-(16.222)-(39.502));
	cnt = (int) (segmentsAcked-(28.642));
	tcb->m_cWnd = (int) (72.037*(31.34)*(24.492)*(tcb->m_cWnd)*(89.841));

}
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_cWnd = (int) (((0.1)+(57.393)+(60.394)+(36.02)+(0.1)+(51.64))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (62.644+(71.69)+(64.955)+(22.223)+(63.86)+(6.94));

} else {
	tcb->m_cWnd = (int) (52.036+(20.731)+(36.415)+(31.123)+(95.903));

}
tcb->m_ssThresh = (int) (tcb->m_cWnd-(tcb->m_segmentSize)-(10.727)-(29.287)-(segmentsAcked)-(29.375)-(4.496));
cnt = (int) (0.1/99.102);
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (7.508*(49.961));
	tcb->m_ssThresh = (int) (91.056*(71.267)*(10.998));

} else {
	tcb->m_segmentSize = (int) (5.756+(tcb->m_cWnd)+(75.814));
	ReduceCwnd (tcb);

}
