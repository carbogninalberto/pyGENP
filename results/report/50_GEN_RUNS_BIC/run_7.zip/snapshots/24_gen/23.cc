segmentsAcked = (int) (10.906+(tcb->m_cWnd)+(37.976));
tcb->m_cWnd = (int) (((38.952)+(77.993)+(96.865)+(0.1))/((0.1)+(0.1)+(0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (33.066*(61.077)*(31.519)*(cnt)*(tcb->m_ssThresh)*(36.144));
	segmentsAcked = (int) ((((19.579+(74.424)+(13.399)+(32.368)))+(0.1)+(22.293)+(20.02))/((0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (26.768+(1.549)+(89.697));
	segmentsAcked = (int) (0.1/0.1);
	ReduceCwnd (tcb);

}
