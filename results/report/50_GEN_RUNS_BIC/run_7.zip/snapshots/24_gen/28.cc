ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(16.766)*(24.52)*(83.203));
tcb->m_ssThresh = (int) (63.627-(cnt));
ReduceCwnd (tcb);
