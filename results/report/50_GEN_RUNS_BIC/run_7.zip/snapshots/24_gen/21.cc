float KTAsShghMskXTxAb = (float) (63.065-(tcb->m_segmentSize)-(76.371)-(95.013)-(cnt)-(73.108)-(29.225)-(60.406)-(69.778));
KTAsShghMskXTxAb = (float) (68.334+(25.217)+(42.477)+(KTAsShghMskXTxAb)+(51.401)+(33.908)+(72.016));
int FSatCizovmFrgEvq = (int) (65.239*(tcb->m_segmentSize));
float FYjyaMZyJCqYOkYl = (float) (9.944+(14.077)+(KTAsShghMskXTxAb)+(29.195)+(7.094));
KTAsShghMskXTxAb = (float) (FSatCizovmFrgEvq-(FSatCizovmFrgEvq)-(FSatCizovmFrgEvq)-(tcb->m_ssThresh)-(2.35)-(13.711));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (KTAsShghMskXTxAb+(tcb->m_segmentSize)+(56.459)+(59.815)+(29.115));
float OsdjuGhLkqZShkDh = (float) (94.954+(39.418));
if (OsdjuGhLkqZShkDh >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (83.753-(OsdjuGhLkqZShkDh)-(FYjyaMZyJCqYOkYl));
	cnt = (int) (47.551/11.815);
	tcb->m_segmentSize = (int) (20.858-(46.27)-(FSatCizovmFrgEvq)-(tcb->m_cWnd)-(23.074)-(29.886)-(60.589)-(74.189)-(30.542));

} else {
	tcb->m_ssThresh = (int) (28.951/57.815);
	FYjyaMZyJCqYOkYl = (float) (77.87-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (11.306-(22.482)-(40.401));

}
