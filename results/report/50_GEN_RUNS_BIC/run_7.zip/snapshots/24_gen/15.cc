int gGhaPbPAVHdRYxAI = (int) (0.1/5.875);
tcb->m_ssThresh = (int) (73.816-(94.641)-(24.223)-(45.284)-(21.522)-(74.746)-(13.029)-(68.538)-(70.316));
segmentsAcked = (int) (segmentsAcked+(68.716)+(96.104)+(36.329)+(33.503)+(tcb->m_ssThresh)+(65.246)+(18.683));
if (segmentsAcked >= tcb->m_ssThresh) {
	segmentsAcked = (int) (76.167+(51.854));
	tcb->m_cWnd = (int) (19.232-(31.603)-(33.486)-(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) (95.879*(62.359)*(14.865));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (5.959+(88.748)+(tcb->m_ssThresh));

}
if (gGhaPbPAVHdRYxAI < tcb->m_cWnd) {
	gGhaPbPAVHdRYxAI = (int) (80.224/0.1);
	tcb->m_ssThresh = (int) (((81.397)+(0.1)+(72.503)+(0.1)+(80.751)+(2.545)+(0.1))/((0.1)));

} else {
	gGhaPbPAVHdRYxAI = (int) (68.303/40.088);
	tcb->m_ssThresh = (int) (59.456+(35.382)+(47.688)+(18.262)+(3.932)+(tcb->m_cWnd)+(32.456)+(tcb->m_cWnd)+(64.802));
	ReduceCwnd (tcb);

}
