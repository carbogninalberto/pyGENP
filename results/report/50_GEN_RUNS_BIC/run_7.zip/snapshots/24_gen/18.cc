if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (cnt <= tcb->m_cWnd) {
	segmentsAcked = (int) (1.478-(59.516)-(34.03)-(28.513)-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (51.886+(66.914)+(40.245)+(tcb->m_cWnd)+(74.557)+(tcb->m_cWnd)+(8.223));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
