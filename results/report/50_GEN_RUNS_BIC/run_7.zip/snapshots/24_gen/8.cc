int xivmrmUZerpyhgPc = (int) (((31.235)+(-43.636)+(-40.29)+((77.602+(-95.275)+(-79.566)+(14.832)+(-47.657)+(-28.845)+(-16.887)))+(5.273)+(22.527)+((-37.579+(-61.629)+(-48.134)+(29.952)))+(62.539))/((-27.635)));
segmentsAcked = (int) (((45.109)+(85.828)+(69.411)+(13.322))/((7.177)));
int hLmsRzabmouoaUzp = (int) (-73.858-(7.63)-(-10.453)-(-67.901)-(62.325)-(-12.619)-(49.815)-(-99.959)-(30.056));
tcb->m_cWnd = (int) (-98.302*(-38.791)*(49.554));
segmentsAcked = (int) (((49.826)+(-86.953)+(85.764)+(19.334))/((-80.58)));
tcb->m_cWnd = (int) (-45.813*(-80.043)*(33.952));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (43.188*(-48.878)*(94.988));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
