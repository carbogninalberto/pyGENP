cnt = (int) (tcb->m_ssThresh+(5.043)+(82.951)+(40.334)+(59.392)+(32.826)+(8.385)+(25.566)+(6.687));
tcb->m_segmentSize = (int) (15.513+(77.87)+(48.06));
tcb->m_segmentSize = (int) (tcb->m_cWnd*(86.873)*(tcb->m_ssThresh)*(60.825)*(67.854));
cnt = (int) (((7.399)+(10.516)+(0.1)+(0.1))/((2.052)+(0.1)));
ReduceCwnd (tcb);
cnt = (int) (33.041+(4.571)+(46.835)+(47.983)+(74.525)+(tcb->m_segmentSize));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
