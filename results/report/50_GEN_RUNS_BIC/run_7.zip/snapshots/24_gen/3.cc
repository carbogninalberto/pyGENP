float oFyRJdFKmewQTsTp = (float) (-76.722-(17.686)-(-81.785)-(-30.653));
int NMAfmSbhZAWIQmNo = (int) (34.789+(-10.954)+(-63.472)+(11.905));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
int wlzkIWtQYcByPvGd = (int) 64.408;
if (NMAfmSbhZAWIQmNo != wlzkIWtQYcByPvGd) {
	segmentsAcked = (int) (-0.936-(42.631)-(45.645)-(79.912));

} else {
	segmentsAcked = (int) (((37.004)+(18.578)+(15.254)+(61.639))/((74.961)+(16.965)));
	wlzkIWtQYcByPvGd = (int) (52.028-(41.746)-(-57.043)-(55.424));

}
tcb->m_cWnd = (int) (((96.874)+((wlzkIWtQYcByPvGd+(segmentsAcked)))+(-25.33)+(-25.787))/((43.881)+(-94.701)));
