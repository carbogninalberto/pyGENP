if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_segmentSize = (int) (12.308+(11.665)+(40.106)+(46.18)+(44.578));
	segmentsAcked = (int) (60.871*(41.629)*(53.809)*(20.67));

} else {
	tcb->m_segmentSize = (int) ((((tcb->m_ssThresh*(56.526)))+((segmentsAcked-(13.791)-(73.799)-(55.706)-(60.111)-(63.394)-(99.82)))+((67.989*(47.106)))+(6.992))/((80.71)+(59.595)+(0.1)+(0.1)+(0.1)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt <= cnt) {
	tcb->m_cWnd = (int) (cnt*(46.344)*(13.67)*(tcb->m_ssThresh)*(90.527)*(92.627)*(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (25.102*(14.807)*(47.381)*(32.539)*(tcb->m_ssThresh)*(44.105)*(80.454)*(58.554)*(segmentsAcked));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= cnt) {
	tcb->m_cWnd = (int) (66.906+(66.829)+(89.823));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (6.506*(tcb->m_segmentSize)*(40.334)*(46.435));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (94.285+(tcb->m_segmentSize)+(40.615)+(64.973));

}
