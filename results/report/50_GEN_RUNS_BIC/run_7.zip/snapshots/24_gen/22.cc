if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) ((75.621-(50.439)-(tcb->m_cWnd)-(22.4)-(segmentsAcked)-(0.818)-(88.833)-(36.309))/0.1);

} else {
	tcb->m_segmentSize = (int) (92.622/26.095);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(7.307)*(tcb->m_segmentSize)*(cnt)*(38.647));
	segmentsAcked = (int) (42.262+(tcb->m_ssThresh)+(83.662)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(32.097)+(90.415)+(tcb->m_ssThresh));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (85.768*(34.294));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (88.091-(tcb->m_segmentSize)-(56.013)-(tcb->m_segmentSize)-(19.613)-(57.215)-(93.169));

} else {
	tcb->m_segmentSize = (int) (64.971*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(12.184)*(78.017)*(91.123)*(0.229)*(7.426));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (31.155+(26.212)+(65.848)+(27.051));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= tcb->m_cWnd) {
	cnt = (int) (95.945*(81.275)*(41.074)*(59.055));
	cnt = (int) (23.135*(25.105)*(28.131)*(91.586)*(92.599)*(9.277)*(82.513)*(96.05)*(98.249));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (9.88*(62.731)*(14.772));

}
