int xivmrmUZerpyhgPc = (int) (((-94.249)+(-99.154)+(-63.841)+((-58.179+(23.105)+(90.699)+(-39.592)+(1.62)+(9.445)+(75.278)))+(85.286)+(24.297)+((-9.336+(-6.991)+(-4.541)+(-82.941)))+(12.522))/((88.485)));
segmentsAcked = (int) (((69.712)+(-84.512)+(58.546)+(-76.495))/((16.631)));
int hLmsRzabmouoaUzp = (int) (-3.954-(-88.44)-(54.041)-(40.575)-(-52.271)-(29.414)-(-14.65)-(-3.164)-(81.176));
tcb->m_cWnd = (int) (-31.04*(98.286)*(-85.766));
segmentsAcked = (int) (((29.311)+(-35.539)+(23.543)+(-41.765))/((-67.216)));
tcb->m_cWnd = (int) (-80.802*(-93.973)*(52.966));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (35.695*(71.571)*(-54.559));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
