int tHpSVdbuppGbNTpk = (int) (15.566*(74.516));
int iasDTazptaVOUdnS = (int) (((-85.247)+(-66.829)+(25.904)+(34.75))/((-3.351)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (68.859+(6.157)+(-87.22)+(-31.706)+(-48.385));
