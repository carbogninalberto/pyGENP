if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked <= tcb->m_cWnd) {
	segmentsAcked = (int) (54.889*(75.546)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(48.569)*(66.645)*(76.146));

} else {
	segmentsAcked = (int) (92.181*(53.185)*(68.859)*(74.742)*(91.595)*(11.231));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	cnt = (int) (61.788*(tcb->m_segmentSize)*(57.116));
	tcb->m_cWnd = (int) (40.054-(75.831)-(93.61)-(80.942)-(88.015)-(38.573)-(33.616)-(39.347)-(50.732));
	tcb->m_cWnd = (int) (92.829*(54.81)*(32.192)*(61.365)*(tcb->m_ssThresh)*(78.896));

} else {
	cnt = (int) (14.092-(86.996)-(4.761)-(2.045)-(36.527)-(65.838)-(98.788)-(tcb->m_ssThresh)-(44.733));
	tcb->m_cWnd = (int) (49.589*(tcb->m_ssThresh)*(78.677)*(43.536)*(39.807)*(3.742)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (87.297-(74.671));

}
tcb->m_cWnd = (int) (83.965+(57.487)+(50.126)+(tcb->m_ssThresh)+(10.988)+(8.285));
if (cnt == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((30.303)+(0.1)+(41.715)+(49.644)+(29.5))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (27.337*(cnt)*(tcb->m_segmentSize)*(43.576)*(29.844));
	tcb->m_segmentSize = (int) (cnt*(50.193)*(segmentsAcked)*(37.561)*(42.893)*(tcb->m_cWnd));

}
