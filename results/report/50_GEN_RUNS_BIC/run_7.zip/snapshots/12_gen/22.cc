tcb->m_cWnd = (int) (4.104/84.919);
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(33.198)-(cnt)-(15.291)-(tcb->m_ssThresh)-(45.528)-(44.98)-(segmentsAcked)-(78.86));
tcb->m_segmentSize = (int) (97.847-(cnt)-(42.512)-(81.953));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (9.371-(75.486));
tcb->m_segmentSize = (int) (9.327-(58.409)-(50.731)-(99.533)-(79.735)-(cnt)-(11.638)-(cnt));
