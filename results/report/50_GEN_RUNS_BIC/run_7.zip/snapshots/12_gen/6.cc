int xivmrmUZerpyhgPc = (int) (((-31.64)+(-9.03)+(-64.872)+((59.427+(-3.563)+(1.153)+(8.195)+(69.48)+(-43.095)+(-84.597)))+(58.945)+(30.906)+((-47.858+(-1.065)+(-12.256)+(-3.429)))+(99.313))/((3.574)));
segmentsAcked = (int) (((-56.737)+(87.533)+(-71.563)+(-81.918))/((90.401)));
int hLmsRzabmouoaUzp = (int) (-73.312-(34.745)-(-98.494)-(-100.0)-(-42.674)-(12.47)-(74.715)-(-38.913)-(-96.787));
tcb->m_cWnd = (int) (33.974*(-53.306)*(-89.826));
segmentsAcked = (int) (((57.153)+(76.549)+(74.317)+(-83.798))/((58.847)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (64.797*(-45.592)*(-48.908));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
