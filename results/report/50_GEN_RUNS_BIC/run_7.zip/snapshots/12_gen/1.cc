int xivmrmUZerpyhgPc = (int) (((-66.251)+(-3.814)+(-83.225)+((81.259+(-23.926)+(1.635)+(-46.567)+(-72.732)+(-13.623)+(-51.13)))+(-22.198)+(83.11)+((-36.551+(61.166)+(23.905)+(-53.703)))+(-34.457))/((57.191)));
segmentsAcked = (int) (((-48.241)+(29.852)+(64.176)+(74.001))/((-63.753)));
int hLmsRzabmouoaUzp = (int) (-56.062-(72.335)-(36.546)-(-24.835)-(26.794)-(75.96)-(58.681)-(1.586)-(6.507));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (49.108*(74.133)*(44.675));
segmentsAcked = (int) (((30.224)+(83.223)+(46.312)+(-69.458))/((-40.413)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (65.529*(-40.774)*(-21.896));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
