segmentsAcked = (int) ((84.692-(54.947)-(33.008)-(58.396)-(48.476))/76.455);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (cnt*(47.846)*(cnt)*(cnt));
if (segmentsAcked >= segmentsAcked) {
	cnt = (int) (62.067/54.913);
	ReduceCwnd (tcb);

} else {
	cnt = (int) (7.455*(tcb->m_segmentSize)*(79.402)*(tcb->m_segmentSize)*(4.155)*(49.547)*(92.518)*(67.896)*(5.676));
	tcb->m_cWnd = (int) (15.796*(7.972));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (18.455*(tcb->m_ssThresh)*(43.566));
