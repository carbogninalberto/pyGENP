int hLmsRzabmouoaUzp = (int) (-43.833-(-54.388)-(20.864)-(-1.795)-(59.049)-(94.094)-(-1.625)-(73.051)-(-80.741));
segmentsAcked = (int) (((82.489)+(70.651)+(-12.856)+(55.537))/((-26.455)));
int xivmrmUZerpyhgPc = (int) (((75.113)+(63.772)+(-7.313)+((-77.719+(-52.615)+(33.821)+(-35.774)+(15.91)+(-15.249)+(8.596)))+(37.975)+(-37.388)+((-13.797+(78.003)+(-54.931)+(97.268)))+(-56.978))/((-11.417)));
tcb->m_cWnd = (int) (-70.264*(33.922)*(75.943));
segmentsAcked = (int) (((-12.224)+(-30.165)+(-56.499)+(-17.415))/((-20.422)));
tcb->m_cWnd = (int) (24.437*(-79.657)*(-74.117));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
