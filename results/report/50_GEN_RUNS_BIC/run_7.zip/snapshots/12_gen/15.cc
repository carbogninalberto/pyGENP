int xivmrmUZerpyhgPc = (int) (((-22.406)+(64.76)+(-9.35)+((27.657+(99.432)+(-9.621)+(-22.348)+(37.574)+(31.511)+(-32.347)))+(-20.086)+(40.581)+((-23.925+(-14.326)+(-48.69)+(64.718)))+(-83.493))/((47.729)));
segmentsAcked = (int) (((88.586)+(26.932)+(-65.572)+(40.085))/((-19.299)));
int hLmsRzabmouoaUzp = (int) (-80.046-(-48.451)-(-10.986)-(14.457)-(-27.548)-(-8.971)-(15.698)-(33.269)-(89.748));
tcb->m_cWnd = (int) (-9.112*(95.445)*(43.444));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((-31.903)+(-23.475)+(-35.553)+(44.697))/((-14.463)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-13.643*(-16.472)*(-27.333));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (52.274*(31.294)*(37.682));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
