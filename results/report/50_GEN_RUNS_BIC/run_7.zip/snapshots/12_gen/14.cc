int xivmrmUZerpyhgPc = (int) (((-10.863)+(70.918)+(44.701)+((37.463+(20.551)+(-45.14)+(-15.197)+(-90.635)+(50.012)+(4.275)))+(-83.167)+(-10.21)+((86.216+(5.32)+(-85.134)+(34.701)))+(19.786))/((-49.128)));
int hLmsRzabmouoaUzp = (int) (-95.592-(92.467)-(22.984)-(55.989)-(94.213)-(41.628)-(24.638)-(93.059)-(16.87));
segmentsAcked = (int) (((12.796)+(48.281)+(-35.611)+(48.487))/((8.643)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-41.208*(42.122)*(83.425));
segmentsAcked = (int) (((27.619)+(59.481)+(-42.563)+(-57.493))/((13.369)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (14.817*(20.742)*(59.388));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((-13.871)+(68.928)+(-48.495)+(10.697))/((63.945)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (19.456*(18.717)*(-98.665));
segmentsAcked = (int) (((33.873)+(-70.305)+(9.675)+(88.961))/((49.379)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (26.422*(6.99)*(-60.925));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
