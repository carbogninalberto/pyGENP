float CUvXSkZcKUgzXeaX = (float) 54.397;
