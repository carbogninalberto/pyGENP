ReduceCwnd (tcb);
if (tcb->m_ssThresh == segmentsAcked) {
	segmentsAcked = (int) (8.994+(cnt)+(5.478)+(86.05)+(tcb->m_cWnd)+(51.9)+(37.609)+(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (52.145-(cnt)-(31.721)-(tcb->m_cWnd)-(9.523)-(4.939)-(tcb->m_cWnd));
	segmentsAcked = (int) (segmentsAcked*(45.042)*(49.478)*(14.644)*(tcb->m_ssThresh)*(52.116)*(segmentsAcked));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (cnt-(14.659)-(45.129)-(42.41)-(26.657)-(63.671)-(39.579));
int LPzaPoIFntkNZcUY = (int) (12.85-(cnt));
