int thNrBNWTgCaYVRmv = (int) ((60.652+(6.225)+(segmentsAcked)+(44.498)+(99.517))/64.435);
cnt = (int) (7.758/94.919);
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (22.638-(tcb->m_segmentSize)-(93.653)-(25.251)-(72.451)-(36.243)-(90.396)-(tcb->m_cWnd)-(45.437));
	cnt = (int) (45.862/48.592);

} else {
	tcb->m_segmentSize = (int) (63.96*(9.551)*(83.872)*(tcb->m_cWnd)*(24.674)*(80.644)*(31.056)*(4.177)*(63.837));

}
cnt = (int) (tcb->m_ssThresh+(tcb->m_segmentSize)+(80.777));
tcb->m_ssThresh = (int) (46.359+(81.885));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
