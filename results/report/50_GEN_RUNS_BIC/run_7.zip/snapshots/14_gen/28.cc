tcb->m_segmentSize = (int) (98.29*(43.963));
tcb->m_segmentSize = (int) (12.381+(99.236)+(93.682));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(77.035)-(8.748));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (62.556-(9.319)-(tcb->m_segmentSize)-(80.407)-(37.606));
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (cnt-(80.873)-(cnt)-(74.597)-(88.242)-(78.323)-(66.829)-(28.801));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (28.101+(38.297)+(65.692));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
cnt = (int) (91.792-(tcb->m_segmentSize)-(95.704)-(50.537)-(77.054)-(54.245)-(84.781)-(segmentsAcked));
