tcb->m_ssThresh = (int) (1.521+(segmentsAcked)+(32.615)+(segmentsAcked)+(12.486)+(cnt));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh == cnt) {
	segmentsAcked = (int) (47.58-(22.9)-(tcb->m_ssThresh)-(90.596)-(10.674)-(70.797)-(76.982));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (tcb->m_cWnd*(tcb->m_ssThresh)*(14.799)*(69.643)*(22.63)*(12.88));
	cnt = (int) (44.326+(cnt)+(70.064)+(21.655)+(segmentsAcked));

}
if (tcb->m_ssThresh == cnt) {
	segmentsAcked = (int) (15.132*(tcb->m_cWnd)*(tcb->m_ssThresh)*(segmentsAcked));
	cnt = (int) (26.467-(9.75)-(69.024)-(segmentsAcked)-(13.952));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (0.1/0.1);

}
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	segmentsAcked = (int) (34.694/40.925);

} else {
	segmentsAcked = (int) (13.294*(79.239));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	cnt = (int) (tcb->m_ssThresh-(43.256)-(17.08)-(segmentsAcked)-(29.014)-(cnt));
	cnt = (int) (73.686+(11.37)+(11.527)+(22.785)+(93.397)+(82.733)+(65.227)+(98.874)+(tcb->m_ssThresh));

} else {
	cnt = (int) (22.49+(24.693));

}
