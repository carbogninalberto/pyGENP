if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (0.105-(tcb->m_ssThresh)-(56.604)-(13.669)-(10.917)-(31.036)-(12.085)-(tcb->m_cWnd)-(segmentsAcked));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (73.377+(63.695)+(cnt)+(19.795)+(tcb->m_cWnd)+(4.784)+(77.404));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(73.154));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (tcb->m_cWnd*(38.962)*(7.732)*(32.552));
cnt = (int) (tcb->m_segmentSize+(21.241)+(64.806)+(0.601)+(23.643));
if (segmentsAcked <= cnt) {
	tcb->m_segmentSize = (int) (75.326*(39.757)*(46.545)*(99.451)*(53.205)*(34.544)*(tcb->m_ssThresh)*(7.448)*(88.02));
	tcb->m_segmentSize = (int) ((((76.459+(47.331)+(38.695)+(72.949)+(57.663)+(76.74)+(34.366)+(83.869)+(94.362)))+(59.335)+(0.1)+(30.106))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+((50.867-(68.124)-(72.92)-(56.552)-(46.16)-(83.651)-(17.952)))+(67.957)+(2.149)+(86.863))/((69.715)+(58.167)+(0.1)));
	segmentsAcked = (int) (46.354-(72.452)-(cnt)-(73.753)-(28.187)-(63.93)-(3.128));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked > tcb->m_cWnd) {
	cnt = (int) (28.836-(22.454)-(72.34));
	tcb->m_cWnd = (int) (86.973+(16.752)+(81.754)+(tcb->m_cWnd)+(27.467));
	tcb->m_cWnd = (int) (((74.543)+(47.23)+(2.493)+(77.65)+(0.1)+(67.147))/((0.1)+(99.725)));

} else {
	cnt = (int) (72.138-(60.551)-(48.932)-(69.956)-(45.226)-(79.925)-(tcb->m_ssThresh));

}
