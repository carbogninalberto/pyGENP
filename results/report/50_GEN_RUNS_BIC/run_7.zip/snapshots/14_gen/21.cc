if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	cnt = (int) (6.573*(9.676)*(25.134));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (61.887+(cnt));
	tcb->m_segmentSize = (int) (73.565*(73.344)*(95.14)*(87.756)*(59.854)*(47.594)*(42.195)*(28.246));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh > segmentsAcked) {
	cnt = (int) (16.299+(37.087)+(89.979)+(tcb->m_ssThresh)+(78.334)+(36.015)+(76.911)+(14.874)+(tcb->m_segmentSize));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (47.695-(8.277)-(38.423)-(cnt)-(64.77));
	tcb->m_cWnd = (int) (14.283*(6.204)*(56.396)*(60.606));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
