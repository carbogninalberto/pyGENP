int xivmrmUZerpyhgPc = (int) (((-38.266)+(43.569)+(-47.655)+((39.814+(54.9)+(92.006)+(-24.097)+(-35.561)+(-50.779)+(1.48)))+(7.77)+(29.893)+((-29.814+(-79.403)+(1.046)+(13.951)))+(-60.639))/((90.127)));
segmentsAcked = (int) (((-6.041)+(79.905)+(-99.862)+(-70.213))/((4.056)));
int hLmsRzabmouoaUzp = (int) (-86.567-(12.313)-(78.396)-(45.243)-(-15.816)-(-9.554)-(69.401)-(26.572)-(-46.225));
tcb->m_cWnd = (int) (3.622*(-64.035)*(13.125));
segmentsAcked = (int) (((72.342)+(72.22)+(-19.066)+(85.379))/((57.724)));
tcb->m_cWnd = (int) (72.977*(4.361)*(-51.547));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (39.112*(-56.442)*(21.478));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
