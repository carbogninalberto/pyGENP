if (tcb->m_cWnd <= cnt) {
	segmentsAcked = (int) (12.077/0.1);
	cnt = (int) (tcb->m_segmentSize*(56.344)*(61.435)*(4.754)*(46.427)*(70.678)*(62.582)*(98.4)*(21.455));

} else {
	segmentsAcked = (int) (((78.04)+(0.1)+(71.899)+(70.485)+(0.1))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (cnt*(92.279)*(29.25)*(36.12)*(0.376));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (74.261-(tcb->m_segmentSize)-(20.96)-(89.832)-(38.099)-(segmentsAcked));
tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(18.7))/((1.418)+(48.597)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (58.525-(58.686));
ReduceCwnd (tcb);
segmentsAcked = (int) (1.69*(57.026));
