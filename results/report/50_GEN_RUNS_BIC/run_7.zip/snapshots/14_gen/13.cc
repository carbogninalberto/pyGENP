int iuZJuAcOzVctrwev = (int) (((11.091)+(0.1)+(0.1)+(0.1)+(38.697)+(0.1))/((0.1)));
iuZJuAcOzVctrwev = (int) (95.586*(9.641)*(91.076)*(86.527));
ReduceCwnd (tcb);
float ivGnmlnfurLcIZtM = (float) (tcb->m_segmentSize+(92.523)+(cnt)+(69.294)+(46.169)+(iuZJuAcOzVctrwev)+(4.582)+(tcb->m_ssThresh)+(22.124));
if (iuZJuAcOzVctrwev == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(85.522)+(73.549)+(78.46)+(53.492)+(41.98)+(17.417)+(cnt));

} else {
	tcb->m_segmentSize = (int) (ivGnmlnfurLcIZtM+(66.543)+(36.542)+(87.437)+(39.812)+(40.564));
	cnt = (int) (0.1/55.185);
	tcb->m_segmentSize = (int) (((0.1)+((ivGnmlnfurLcIZtM+(96.83)+(87.379)+(66.934)+(58.479)+(15.212)+(3.003)+(72.857)))+((90.897+(cnt)+(69.307)+(16.575)+(39.076)+(tcb->m_ssThresh)))+(92.289))/((50.433)+(77.793)+(61.204)));

}
if (tcb->m_ssThresh != ivGnmlnfurLcIZtM) {
	tcb->m_ssThresh = (int) (iuZJuAcOzVctrwev+(93.587)+(49.628)+(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (segmentsAcked+(19.571)+(22.505)+(iuZJuAcOzVctrwev)+(44.545));

} else {
	tcb->m_ssThresh = (int) (54.181-(24.82)-(cnt)-(75.205)-(36.171));

}
