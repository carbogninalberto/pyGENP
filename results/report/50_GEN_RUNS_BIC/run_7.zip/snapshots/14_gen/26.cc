ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (63.295-(62.737)-(64.198)-(segmentsAcked)-(12.087)-(74.321)-(75.459));
tcb->m_segmentSize = (int) (52.241+(9.499)+(segmentsAcked)+(30.396));
if (cnt > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (34.136*(11.56)*(56.792)*(38.213));
	tcb->m_segmentSize = (int) (86.114+(99.319)+(tcb->m_ssThresh)+(34.701));
	cnt = (int) (((0.1)+(0.1)+(83.589)+(0.1)+(0.1)+(66.963))/((22.0)+(0.1)+(26.282)));

} else {
	tcb->m_cWnd = (int) (10.784+(89.077)+(66.078)+(tcb->m_cWnd)+(2.71)+(83.072));

}
if (tcb->m_ssThresh >= cnt) {
	tcb->m_cWnd = (int) (48.365*(35.685)*(74.851)*(0.607)*(40.567)*(96.532));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (7.234-(5.608)-(76.36)-(59.596)-(tcb->m_cWnd)-(88.129)-(49.631)-(64.775));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	cnt = (int) (98.758*(79.111)*(49.634)*(96.233)*(66.932)*(segmentsAcked)*(60.71)*(23.123));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (51.155+(tcb->m_cWnd)+(65.561)+(79.745)+(1.569)+(28.906)+(tcb->m_segmentSize)+(12.844)+(50.564));

} else {
	cnt = (int) ((tcb->m_cWnd-(segmentsAcked)-(55.908)-(82.946)-(tcb->m_ssThresh)-(23.241)-(17.22)-(4.695)-(73.24))/62.331);
	ReduceCwnd (tcb);
	cnt = (int) (97.701+(tcb->m_cWnd)+(tcb->m_segmentSize)+(89.333)+(tcb->m_cWnd)+(31.969)+(31.692)+(68.774)+(tcb->m_ssThresh));

}
tcb->m_ssThresh = (int) (0.1/67.945);
