int hLmsRzabmouoaUzp = (int) (-52.094-(-16.898)-(-68.809)-(-22.041)-(95.012)-(44.118)-(58.675)-(90.955)-(-26.656));
segmentsAcked = (int) (((33.692)+(-94.536)+(-11.483)+(-68.403))/((-37.292)));
int xivmrmUZerpyhgPc = (int) (((42.05)+(-96.895)+(86.501)+((85.734+(-13.018)+(-15.879)+(44.76)+(-88.759)+(58.651)+(79.633)))+(60.806)+(-51.596)+((1.623+(-52.127)+(10.334)+(-2.811)))+(-28.919))/((4.785)));
tcb->m_cWnd = (int) (-5.416*(14.069)*(51.382));
segmentsAcked = (int) (((-63.891)+(-28.795)+(-79.964)+(4.308))/((97.751)));
tcb->m_cWnd = (int) (60.278*(19.594)*(28.376));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((32.976)+(32.143)+(-3.783)+(-16.363))/((60.507)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-84.112*(31.346)*(46.4));
tcb->m_cWnd = (int) (-29.588*(19.661)*(36.294));
segmentsAcked = (int) (((29.113)+(-21.332)+(8.667)+(52.637))/((14.833)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (1.171*(66.263)*(0.934));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-83.911*(30.952)*(-18.397));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
