ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (52.257*(tcb->m_cWnd)*(11.805)*(4.451)*(83.298)*(68.701)*(4.001)*(1.407)*(segmentsAcked));
tcb->m_ssThresh = (int) ((((80.478-(93.668)-(6.829)-(99.191)))+(0.1)+(8.023)+(3.907)+(93.664))/((0.1)+(92.261)));
if (tcb->m_cWnd < cnt) {
	tcb->m_segmentSize = (int) (37.152-(42.574)-(20.017)-(cnt)-(90.217));
	segmentsAcked = (int) (43.538*(32.874)*(7.134)*(tcb->m_ssThresh)*(46.805));

} else {
	tcb->m_segmentSize = (int) (86.403/0.1);

}
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	cnt = (int) (tcb->m_ssThresh-(segmentsAcked)-(tcb->m_ssThresh)-(25.313)-(10.61)-(48.519)-(tcb->m_ssThresh));

} else {
	cnt = (int) (68.374+(23.281)+(11.115)+(60.874)+(43.041));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
