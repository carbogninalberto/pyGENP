cnt = (int) (49.942*(1.688)*(43.82)*(26.544)*(84.942));
int ZivOnaJKQvztEuBG = (int) (21.53+(2.598)+(51.504)+(35.756)+(40.99)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(35.668));
if (cnt == ZivOnaJKQvztEuBG) {
	tcb->m_segmentSize = (int) (39.445*(37.271));
	ZivOnaJKQvztEuBG = (int) (tcb->m_segmentSize+(ZivOnaJKQvztEuBG)+(39.829)+(ZivOnaJKQvztEuBG));
	tcb->m_cWnd = (int) (98.351+(37.893)+(tcb->m_cWnd)+(7.419)+(22.516)+(52.862)+(31.341));

} else {
	tcb->m_segmentSize = (int) (0.1/4.562);
	tcb->m_cWnd = (int) (39.06*(2.803));

}
if (tcb->m_cWnd <= segmentsAcked) {
	ZivOnaJKQvztEuBG = (int) (17.833-(19.931)-(ZivOnaJKQvztEuBG)-(78.291)-(37.539)-(15.483)-(ZivOnaJKQvztEuBG));
	ReduceCwnd (tcb);

} else {
	ZivOnaJKQvztEuBG = (int) (4.492-(30.697)-(76.811)-(tcb->m_segmentSize)-(43.2)-(21.409)-(21.906)-(54.51)-(77.295));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (11.762-(89.335));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (ZivOnaJKQvztEuBG == cnt) {
	cnt = (int) (11.59*(95.317)*(ZivOnaJKQvztEuBG)*(tcb->m_cWnd)*(12.48));

} else {
	cnt = (int) (36.97+(65.179)+(74.179)+(18.891)+(15.22)+(75.414)+(37.251)+(38.779)+(42.972));

}
if (tcb->m_ssThresh >= ZivOnaJKQvztEuBG) {
	tcb->m_segmentSize = (int) (80.776-(7.255)-(88.664)-(52.41));
	tcb->m_segmentSize = (int) (69.704*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) ((54.244+(46.274))/0.1);

}
