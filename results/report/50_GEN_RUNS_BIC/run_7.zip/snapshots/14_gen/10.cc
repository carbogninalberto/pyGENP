int xivmrmUZerpyhgPc = (int) (((-62.026)+(56.748)+(7.543)+((69.883+(36.189)+(-89.365)+(33.285)+(-53.69)+(49.087)+(-9.731)))+(59.545)+(4.067)+((-41.366+(-54.831)+(-44.884)+(-91.425)))+(-96.552))/((47.021)));
segmentsAcked = (int) (((-97.544)+(45.468)+(-35.171)+(44.889))/((-42.431)));
int hLmsRzabmouoaUzp = (int) (38.035-(34.553)-(72.467)-(44.186)-(52.09)-(-96.097)-(43.457)-(-55.06)-(94.898));
tcb->m_cWnd = (int) (-54.03*(-97.912)*(59.128));
segmentsAcked = (int) (((49.525)+(-39.605)+(87.337)+(94.873))/((23.394)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-9.879*(39.798)*(22.209));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-35.457*(-71.727)*(-59.358));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
