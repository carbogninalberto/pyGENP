tcb->m_segmentSize = (int) (tcb->m_cWnd-(7.262));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (71.098+(37.568)+(28.402));
segmentsAcked = (int) (5.107*(tcb->m_cWnd)*(26.588)*(tcb->m_segmentSize)*(45.454)*(96.304)*(39.882)*(68.019)*(41.852));
segmentsAcked = (int) (16.823*(tcb->m_ssThresh)*(93.574)*(45.178));
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(segmentsAcked)*(4.477));
	tcb->m_cWnd = (int) (((0.1)+(70.931)+(0.1)+(99.113)+(57.097)+(60.361))/((0.1)));
	cnt = (int) (segmentsAcked*(30.614)*(94.963)*(tcb->m_ssThresh)*(1.961)*(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(76.866)+(0.1))/((0.1)+(38.122)+(98.235)));
	tcb->m_cWnd = (int) (98.608-(3.158)-(1.291)-(77.282)-(tcb->m_ssThresh)-(21.675));
	tcb->m_segmentSize = (int) (14.829-(1.636)-(84.063)-(78.468)-(81.717)-(9.346)-(5.803)-(82.427));

}
