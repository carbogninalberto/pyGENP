tcb->m_cWnd = (int) (89.0+(55.746)+(50.68)+(cnt)+(51.783)+(98.001));
tcb->m_segmentSize = (int) (65.835+(80.108)+(9.762)+(48.187)+(97.942)+(26.741)+(4.128)+(28.647));
if (tcb->m_cWnd != cnt) {
	tcb->m_ssThresh = (int) (64.27*(49.74));
	segmentsAcked = (int) (73.807+(83.471)+(72.0)+(73.604)+(24.172)+(5.078)+(86.491));

} else {
	tcb->m_ssThresh = (int) (71.264*(62.459));

}
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (40.437*(61.633)*(87.774)*(38.177)*(15.695)*(95.299)*(67.364)*(25.839));
	tcb->m_segmentSize = (int) (68.352*(87.154)*(87.005));

} else {
	tcb->m_segmentSize = (int) (3.554/0.1);

}
cnt = (int) (0.1/0.1);
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	cnt = (int) (cnt*(71.884)*(49.145)*(41.063)*(28.434));

} else {
	cnt = (int) (tcb->m_cWnd+(32.771)+(tcb->m_segmentSize)+(42.61)+(segmentsAcked)+(68.992)+(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (96.153+(9.998)+(47.643)+(99.41)+(95.29));

}
cnt = (int) (52.52*(75.164)*(47.046)*(39.618)*(90.304)*(30.371)*(79.689)*(segmentsAcked));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_segmentSize*(10.258)*(8.836)*(34.956)*(cnt));
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (50.853*(92.756)*(69.578)*(tcb->m_ssThresh)*(32.03)*(tcb->m_cWnd));
	cnt = (int) (segmentsAcked-(91.674)-(69.505)-(94.019)-(tcb->m_cWnd)-(69.442)-(84.783)-(19.867)-(60.672));
	tcb->m_cWnd = (int) (43.611-(80.127)-(33.094)-(10.808)-(36.029));

}
