ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > tcb->m_cWnd) {
	cnt = (int) (16.881*(segmentsAcked)*(segmentsAcked)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(54.519)*(63.149));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(18.772)+(0.1)+(33.002)+(6.431))/((35.252)+(41.46)));

} else {
	cnt = (int) (48.442-(45.982)-(tcb->m_ssThresh)-(9.444)-(38.357)-(72.326)-(26.648));

}
tcb->m_ssThresh = (int) ((((60.274*(62.627)))+(20.946)+(32.564)+(0.1)+(0.1)+(0.1))/((21.11)+(0.1)));
ReduceCwnd (tcb);
