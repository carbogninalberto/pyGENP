if (cnt < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (71.805/0.1);
	tcb->m_ssThresh = (int) (31.094-(28.753)-(69.949)-(tcb->m_ssThresh)-(74.167)-(39.983)-(93.399)-(91.664)-(31.746));
	tcb->m_ssThresh = (int) (35.927-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(96.569)-(cnt)-(53.471)-(21.349)-(2.537));

} else {
	tcb->m_segmentSize = (int) (19.539-(17.008)-(43.993)-(32.612)-(1.874)-(61.145)-(36.083)-(84.362)-(76.568));
	tcb->m_cWnd = (int) (((0.1)+((58.742-(52.717)-(17.866)-(29.37)-(40.692)-(35.864)))+(0.1)+(0.1))/((93.891)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize >= cnt) {
	tcb->m_segmentSize = (int) (0.1/57.828);

} else {
	tcb->m_segmentSize = (int) (56.036*(32.977));

}
if (tcb->m_segmentSize <= cnt) {
	tcb->m_cWnd = (int) (((6.539)+(0.1)+(16.391)+(31.972)+((13.908-(tcb->m_ssThresh)-(38.116)))+(0.1)+(56.234)+(0.1))/((66.582)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (((0.1)+((77.112*(24.498)))+((16.547*(28.277)))+(83.43))/((0.1)+(87.589)));
	tcb->m_ssThresh = (int) (((50.587)+((83.811-(94.187)-(3.261)-(51.568)-(4.644)))+(1.584)+(0.1)+(0.1)+(49.042))/((35.962)+(0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_ssThresh = (int) (65.781-(cnt)-(65.53)-(93.908)-(tcb->m_segmentSize)-(43.419));
tcb->m_segmentSize = (int) (tcb->m_ssThresh+(91.428)+(segmentsAcked)+(31.799)+(41.947)+(69.091)+(cnt)+(99.809)+(93.424));
if (cnt <= segmentsAcked) {
	tcb->m_ssThresh = (int) (55.569-(41.797)-(64.202)-(27.457)-(29.366)-(61.483)-(76.878)-(34.841));
	tcb->m_cWnd = (int) (19.264-(39.917)-(70.247)-(83.55)-(27.185)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (96.538-(83.464)-(74.558)-(88.248)-(95.061)-(37.164));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(24.622)*(20.993)*(7.436)*(42.43)*(39.7)*(39.946)*(63.882)*(92.675));
	cnt = (int) (cnt-(49.278));

}
