float aKMTLUXiNvAbZSqD = (float) (tcb->m_segmentSize+(84.172)+(42.673)+(78.753)+(tcb->m_segmentSize)+(97.712)+(94.834)+(81.469)+(23.024));
tcb->m_cWnd = (int) (84.426-(tcb->m_cWnd)-(22.668)-(4.538)-(62.003)-(42.202)-(72.83));
tcb->m_segmentSize = (int) ((((tcb->m_segmentSize*(65.979)*(tcb->m_ssThresh)*(segmentsAcked)*(91.197)*(73.815)*(46.049)*(49.621)*(segmentsAcked)))+(0.1)+(0.1)+(0.1))/((73.525)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
