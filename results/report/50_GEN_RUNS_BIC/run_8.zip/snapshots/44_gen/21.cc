if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_segmentSize > segmentsAcked) {
	cnt = (int) (46.185/(0.777*(33.804)*(53.448)*(10.644)*(15.761)*(65.458)));
	segmentsAcked = (int) (35.231-(15.168)-(87.239)-(39.189));

} else {
	cnt = (int) (49.425*(28.627)*(3.306)*(81.194));

}
if (segmentsAcked != cnt) {
	tcb->m_cWnd = (int) (38.75/61.273);

} else {
	tcb->m_cWnd = (int) (((0.1)+(2.461)+(45.104)+(0.1)+(6.5))/((20.455)+(0.1)+(9.983)));

}
tcb->m_cWnd = (int) (0.1/(94.908-(tcb->m_cWnd)-(40.295)-(2.72)-(85.586)-(tcb->m_ssThresh)-(87.42)-(62.358)));
