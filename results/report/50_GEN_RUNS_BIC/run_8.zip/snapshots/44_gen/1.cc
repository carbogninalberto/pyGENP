int RPResGTUltAZDGLo = (int) (-92.245/31.873);
int khKTMNFNZAGBGZIO = (int) (-76.767-(-54.767)-(37.514)-(-51.021));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
