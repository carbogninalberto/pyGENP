if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh <= segmentsAcked) {
	cnt = (int) (segmentsAcked-(segmentsAcked)-(tcb->m_segmentSize)-(4.704)-(segmentsAcked)-(segmentsAcked)-(2.177));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (cnt-(12.117)-(42.98));

} else {
	cnt = (int) (tcb->m_segmentSize-(22.702)-(29.392)-(24.443)-(91.751));

}
if (cnt < tcb->m_cWnd) {
	cnt = (int) (36.796+(92.933));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (35.683-(tcb->m_cWnd)-(tcb->m_segmentSize)-(34.086)-(segmentsAcked)-(tcb->m_segmentSize)-(2.495));
	tcb->m_ssThresh = (int) (cnt-(40.531)-(33.572)-(34.66)-(27.96)-(tcb->m_segmentSize)-(39.847));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
cnt = (int) (1.128-(44.573)-(94.659)-(18.221));
