tcb->m_cWnd = (int) (15.437/0.1);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(76.874)+(24.176)+(53.517)+(70.666)+(37.348)+(18.185));

} else {
	tcb->m_ssThresh = (int) (((0.1)+((59.875+(16.088)+(tcb->m_segmentSize)+(71.506)+(tcb->m_segmentSize)))+(0.1)+(43.301))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (63.735-(54.922)-(6.668)-(8.242)-(63.29));
	tcb->m_ssThresh = (int) (84.678-(14.131)-(tcb->m_ssThresh)-(18.978)-(41.057)-(19.745)-(44.704)-(20.405)-(85.332));
	tcb->m_cWnd = (int) (9.358/79.644);

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(3.892)*(79.505)*(42.2));
	tcb->m_cWnd = (int) (13.395-(93.025)-(32.228)-(64.573)-(60.749)-(90.267));
	cnt = (int) (56.503-(13.767)-(81.61)-(23.768)-(21.063)-(tcb->m_cWnd)-(30.547)-(52.755)-(segmentsAcked));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
