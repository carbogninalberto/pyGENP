if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (82.465-(43.609)-(98.904)-(71.429)-(segmentsAcked)-(41.149)-(30.505));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (0.1/0.1);

}
cnt = (int) (85.04-(tcb->m_segmentSize)-(23.665)-(54.903)-(24.032));
tcb->m_cWnd = (int) (23.61*(96.799)*(79.943)*(12.209));
cnt = (int) (91.251+(42.588)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(93.667)+(63.928)+(37.251));
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/23.846);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (55.759*(6.598)*(2.541)*(79.848)*(11.62)*(62.906)*(92.879)*(78.869));

}
cnt = (int) (19.621+(tcb->m_cWnd)+(10.53)+(10.908)+(72.361)+(97.097));
ReduceCwnd (tcb);
