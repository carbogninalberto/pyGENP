tcb->m_cWnd = (int) (98.133/95.423);
cnt = (int) (23.998-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(segmentsAcked)-(72.708)-(73.937)-(59.474)-(72.294)-(96.462));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (28.603-(46.511)-(19.971)-(60.237)-(70.806)-(84.967)-(tcb->m_ssThresh)-(16.873));
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (44.28+(22.657)+(87.58)+(68.45)+(93.087)+(42.922)+(44.185));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (40.517+(43.741)+(9.88)+(55.628)+(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
