tcb->m_cWnd = (int) (16.224*(74.478)*(45.979)*(48.596)*(segmentsAcked)*(12.925)*(75.7)*(79.128)*(40.359));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (71.779/(5.605+(58.378)+(20.543)+(88.842)+(44.912)+(cnt)));
float HrvOhOXqTrjrAXOE = (float) (84.741+(7.983)+(9.011)+(segmentsAcked)+(28.605)+(segmentsAcked)+(46.424));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
