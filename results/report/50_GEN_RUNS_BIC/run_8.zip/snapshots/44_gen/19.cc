if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (28.494-(99.401)-(62.379)-(76.202)-(91.179));
	segmentsAcked = (int) (96.821+(43.673)+(11.409));

} else {
	tcb->m_ssThresh = (int) (cnt*(50.888)*(cnt)*(28.247));
	tcb->m_ssThresh = (int) (32.924-(33.241)-(64.978)-(tcb->m_segmentSize)-(72.628)-(26.731)-(16.949)-(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (((13.338)+(34.503)+(46.613)+(35.318))/((5.628)));
tcb->m_cWnd = (int) (39.006*(88.334)*(13.854));
ReduceCwnd (tcb);
