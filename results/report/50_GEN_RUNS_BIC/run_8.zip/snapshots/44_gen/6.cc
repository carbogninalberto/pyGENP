if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (85.16+(76.961));
ReduceCwnd (tcb);
if (cnt >= segmentsAcked) {
	cnt = (int) (0.1/35.681);

} else {
	cnt = (int) (tcb->m_segmentSize+(42.115)+(98.858)+(54.903)+(15.284)+(55.998));
	segmentsAcked = (int) (0.1/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
