cnt = (int) (77.781-(tcb->m_segmentSize)-(67.026)-(22.279)-(94.757)-(68.361)-(cnt));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
cnt = (int) (0.1/0.1);
cnt = (int) (27.772+(tcb->m_ssThresh)+(88.212)+(31.074)+(63.853));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (98.706+(96.454)+(59.65)+(tcb->m_cWnd)+(30.274)+(97.424)+(9.825));
int nFkFJoywibpfTgUx = (int) (0.1/0.1);
tcb->m_ssThresh = (int) (tcb->m_cWnd+(7.14));
