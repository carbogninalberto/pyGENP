ReduceCwnd (tcb);
int NxxfwSwGiOjAYSMj = (int) (58.727*(80.784));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
NxxfwSwGiOjAYSMj = (int) (50.335+(76.819)+(33.682)+(11.446)+(35.995)+(64.382));
if (cnt < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (51.233*(tcb->m_cWnd)*(14.985)*(44.336)*(61.027)*(28.552));

} else {
	tcb->m_ssThresh = (int) ((((82.189+(34.747)+(28.198)+(62.653)+(segmentsAcked)))+(0.1)+(0.1)+(62.997))/((26.065)+(92.685)+(26.573)));

}
