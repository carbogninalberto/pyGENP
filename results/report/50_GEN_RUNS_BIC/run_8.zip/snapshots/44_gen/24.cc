tcb->m_ssThresh = (int) (83.766+(7.559)+(51.681)+(73.431)+(13.794)+(21.328));
ReduceCwnd (tcb);
if (tcb->m_cWnd >= cnt) {
	tcb->m_ssThresh = (int) (34.876*(tcb->m_ssThresh));
	cnt = (int) (33.494/0.1);

} else {
	tcb->m_ssThresh = (int) ((((17.856+(14.352)+(54.752)+(60.916)+(52.438)+(cnt)))+(74.791)+(0.1)+(0.1)+(91.55))/((0.1)+(0.1)));

}
tcb->m_cWnd = (int) (2.355*(20.695)*(22.191)*(92.662)*(43.869));
tcb->m_cWnd = (int) (tcb->m_segmentSize+(1.205)+(segmentsAcked)+(12.701)+(83.991)+(63.899));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked == segmentsAcked) {
	segmentsAcked = (int) (19.881/36.06);
	tcb->m_cWnd = (int) (71.654-(85.694)-(tcb->m_cWnd)-(71.605)-(4.617));

} else {
	segmentsAcked = (int) (15.283+(37.343)+(73.018)+(32.578)+(55.603)+(67.47)+(69.634)+(76.2));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
