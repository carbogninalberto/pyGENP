int glXnxRRgpikQilQM = (int) (cnt-(46.815)-(cnt)-(50.922)-(tcb->m_cWnd));
ReduceCwnd (tcb);
if (glXnxRRgpikQilQM != cnt) {
	cnt = (int) (91.392+(tcb->m_ssThresh)+(4.377));
	cnt = (int) (28.621*(21.24)*(15.656)*(85.164)*(95.498));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (78.558/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (40.503+(90.132));

}
int GllQRmLkOzOpacjo = (int) (67.415/16.828);
cnt = (int) (30.8+(tcb->m_segmentSize)+(66.747)+(50.705)+(glXnxRRgpikQilQM)+(tcb->m_cWnd));
