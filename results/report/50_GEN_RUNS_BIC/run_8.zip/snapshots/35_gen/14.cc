float PkAUDzpSnLHVpwcy = (float) (62.383*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(0.714)*(88.302)*(79.606)*(97.324));
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (87.582/73.37);
	PkAUDzpSnLHVpwcy = (float) (55.732*(24.397)*(56.412)*(31.341)*(6.604)*(98.573)*(56.112)*(PkAUDzpSnLHVpwcy)*(66.124));
	tcb->m_ssThresh = (int) (51.803+(tcb->m_cWnd)+(89.132)+(14.29)+(tcb->m_ssThresh)+(82.671)+(94.313)+(76.242));

} else {
	tcb->m_ssThresh = (int) (84.413+(81.768)+(3.02)+(71.034)+(56.6)+(93.606));
	tcb->m_cWnd = (int) (0.1/74.389);
	ReduceCwnd (tcb);

}
PkAUDzpSnLHVpwcy = (float) (27.121/0.1);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (cnt-(tcb->m_ssThresh)-(cnt));
