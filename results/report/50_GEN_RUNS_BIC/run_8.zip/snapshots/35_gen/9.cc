if (segmentsAcked < cnt) {
	cnt = (int) (89.604*(25.834)*(14.512));
	tcb->m_segmentSize = (int) (23.191*(63.049)*(2.182)*(69.483)*(68.664)*(67.447)*(12.599)*(21.584));

} else {
	cnt = (int) (0.1/15.985);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (77.25/35.54);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_ssThresh = (int) (74.34+(84.947)+(32.869)+(tcb->m_cWnd)+(13.39));

} else {
	tcb->m_ssThresh = (int) (8.665*(tcb->m_segmentSize)*(53.831)*(77.991)*(tcb->m_cWnd)*(66.584)*(cnt)*(tcb->m_cWnd)*(segmentsAcked));
	tcb->m_cWnd = (int) (0.1/23.337);

}
tcb->m_cWnd = (int) (87.595+(21.119)+(69.236)+(81.668)+(36.402)+(tcb->m_ssThresh)+(51.293)+(81.119));
if (cnt >= tcb->m_ssThresh) {
	segmentsAcked = (int) (38.87*(26.156)*(46.949)*(47.247)*(24.864)*(48.969)*(35.384)*(segmentsAcked));
	tcb->m_ssThresh = (int) (90.793*(57.487)*(77.315)*(47.039)*(40.633));

} else {
	segmentsAcked = (int) (tcb->m_cWnd+(69.529)+(cnt)+(83.31)+(58.775)+(63.39)+(50.868)+(58.812)+(17.809));
	segmentsAcked = (int) (63.85-(86.609)-(tcb->m_segmentSize)-(65.012)-(31.983)-(36.594));
	segmentsAcked = (int) (0.1/70.224);

}
