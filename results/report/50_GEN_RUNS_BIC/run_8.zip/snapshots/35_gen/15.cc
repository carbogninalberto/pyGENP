if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float ZSpryhzDNyXHEcBI = (float) (57.647*(82.285));
float PEoUYfkBssgqOmaM = (float) (39.859-(19.519)-(56.185)-(75.286)-(ZSpryhzDNyXHEcBI)-(cnt)-(tcb->m_cWnd)-(67.693)-(36.258));
ZSpryhzDNyXHEcBI = (float) (95.417-(76.106)-(15.98));
float hIKJgfwXeFkFLqeJ = (float) (tcb->m_segmentSize+(96.364)+(cnt)+(48.711)+(14.361));
