if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (34.746+(51.193)+(segmentsAcked)+(20.062)+(96.732)+(28.636)+(19.636)+(12.887)+(87.821));
	tcb->m_cWnd = (int) (7.957*(94.044)*(95.405));

} else {
	tcb->m_segmentSize = (int) (11.272+(87.903)+(24.885)+(42.127)+(cnt)+(39.272)+(88.282)+(32.666)+(95.052));

}
cnt = (int) (82.536*(59.873)*(47.989)*(tcb->m_ssThresh)*(87.534)*(99.534)*(18.057)*(43.92)*(6.443));
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(81.569));

} else {
	tcb->m_ssThresh = (int) (cnt*(11.406)*(46.623)*(segmentsAcked)*(99.913)*(27.768)*(tcb->m_ssThresh)*(segmentsAcked)*(46.871));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (cnt*(22.753));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (98.317/0.1);

}
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(tcb->m_cWnd)*(73.824)*(1.829)*(75.495)*(43.06)*(23.003)*(69.193));
	segmentsAcked = (int) (cnt+(cnt)+(26.03)+(cnt)+(76.978));
	tcb->m_segmentSize = (int) (43.932-(51.866)-(46.206)-(63.859)-(39.433)-(96.373)-(segmentsAcked)-(47.491)-(cnt));

} else {
	tcb->m_segmentSize = (int) (38.254*(57.232)*(98.407)*(30.559));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (29.558/0.1);

}
