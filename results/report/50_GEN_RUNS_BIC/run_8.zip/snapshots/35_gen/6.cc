int WiIvtFypEHITflwD = (int) (-13.512-(-5.673)-(-70.724));
int keDXXLyBNXPTNCRX = (int) (60.633-(44.277));
if (segmentsAcked != segmentsAcked) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(55.44)+((69.584+(26.846)+(49.481)+(37.806)+(10.97)+(14.434)+(34.265)+(tcb->m_cWnd)))+(0.1))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (90.208-(tcb->m_cWnd)-(97.426)-(6.361)-(44.271)-(53.661)-(81.026)-(64.039)-(37.817));

}
