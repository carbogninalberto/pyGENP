int qoYBHfjyMYfPFbPp = (int) (((57.274)+(57.031)+(0.1)+((79.515-(61.19)-(5.416)-(10.434)-(65.563)))+((28.71+(37.763)+(77.617)))+(0.1)+(31.055))/((74.152)+(87.175)));
int OvQKmhOzfxAxvFcZ = (int) (79.111-(35.487)-(segmentsAcked)-(cnt)-(46.619)-(15.533));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (19.342+(98.558)+(35.052)+(tcb->m_ssThresh)+(29.999)+(tcb->m_ssThresh)+(73.966)+(segmentsAcked));
OvQKmhOzfxAxvFcZ = (int) ((46.311-(cnt)-(59.649)-(8.507)-(6.996)-(tcb->m_ssThresh))/0.1);
