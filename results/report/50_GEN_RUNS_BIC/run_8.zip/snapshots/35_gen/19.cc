cnt = (int) ((67.989*(71.939)*(segmentsAcked)*(37.028)*(1.9)*(23.692)*(12.09)*(cnt))/45.193);
tcb->m_ssThresh = (int) (4.038+(segmentsAcked)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(39.321)+(cnt)+(segmentsAcked));
tcb->m_cWnd = (int) (93.48-(45.225)-(62.095)-(30.201)-(40.289)-(28.434)-(76.402)-(57.171));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (67.175+(91.374)+(72.969));
if (cnt == segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(37.496)*(88.489)*(86.037));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (86.555*(cnt)*(55.519)*(77.991)*(41.05)*(27.259)*(tcb->m_cWnd)*(19.028)*(92.116));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
