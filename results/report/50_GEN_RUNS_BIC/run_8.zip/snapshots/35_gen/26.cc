cnt = (int) (61.721-(70.1)-(78.704)-(1.155)-(54.795)-(26.962));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (97.851+(36.397)+(79.752)+(55.044)+(78.683)+(94.002)+(53.645));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (23.724+(49.197)+(32.873)+(tcb->m_cWnd)+(3.443)+(7.42)+(cnt)+(55.098));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (86.67-(94.136)-(22.44)-(66.803)-(55.864)-(6.611)-(34.988)-(40.45));

}
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_cWnd = (int) (2.547*(70.179));
	cnt = (int) (14.247+(49.438)+(segmentsAcked));
	segmentsAcked = (int) (40.404+(74.567)+(56.102)+(tcb->m_cWnd)+(11.714)+(48.31));

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(53.094)-(57.689)-(20.098)-(17.453)-(39.864)-(segmentsAcked)-(tcb->m_segmentSize)-(57.082));
	segmentsAcked = (int) (tcb->m_segmentSize-(42.034)-(77.758)-(tcb->m_cWnd)-(27.015));
	tcb->m_cWnd = (int) (78.982+(74.622)+(segmentsAcked));

}
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(62.227)*(52.448)*(77.927));
	tcb->m_ssThresh = (int) (50.792-(92.035)-(95.13)-(80.89)-(30.339));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked+(19.835)+(22.496)+(33.379)+(cnt));

}
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (60.326+(70.202));

}
if (cnt >= tcb->m_cWnd) {
	segmentsAcked = (int) ((((40.353-(0.867)-(20.654)-(95.376)-(45.698)-(segmentsAcked)-(22.799)-(96.004)-(33.084)))+(0.1)+(0.1)+(0.1)+(0.1)+((48.645+(cnt)+(segmentsAcked)))+(0.1))/((0.1)+(66.866)));
	tcb->m_ssThresh = (int) (58.216-(segmentsAcked)-(74.616));

} else {
	segmentsAcked = (int) (13.056+(32.696)+(30.4));

}
tcb->m_cWnd = (int) (cnt-(tcb->m_ssThresh)-(cnt)-(9.132)-(93.538)-(43.102)-(7.755)-(32.328));
