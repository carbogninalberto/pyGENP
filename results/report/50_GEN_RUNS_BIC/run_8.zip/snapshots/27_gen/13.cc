float DbAjyzYiEHnNrgOb = (float) 54.103;
ReduceCwnd (tcb);
float bwEEjDEJAcQzBaVo = (float) 94.543;
if (bwEEjDEJAcQzBaVo <= segmentsAcked) {
	segmentsAcked = (int) (1.412-(75.645));

} else {
	segmentsAcked = (int) (tcb->m_cWnd-(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
DbAjyzYiEHnNrgOb = (float) (1.331-(-74.49)-(66.453)-(-21.869));
segmentsAcked = (int) (-89.759-(-35.853)-(-20.593)-(54.489)-(-52.683)-(-47.285)-(57.825)-(78.268));
