tcb->m_segmentSize = (int) (((-20.45)+((-45.224*(62.787)*(-64.55)*(tcb->m_ssThresh)*(-18.745)*(15.4)*(11.758)*(-55.168)))+(-44.191)+(45.282)+(99.143))/((-29.203)+(-29.78)+(-59.075)+(51.839)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
