if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (15.351*(75.719)*(25.025)*(tcb->m_cWnd)*(2.421)*(78.041)*(32.366));
	segmentsAcked = (int) (31.462+(47.373));
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (20.151/38.781);

}
