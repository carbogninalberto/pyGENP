int HblrwjcplqMjQEgd = (int) (63.219*(5.863)*(-51.481)*(-53.023)*(-51.116)*(51.403)*(-72.887)*(87.432)*(33.518));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
