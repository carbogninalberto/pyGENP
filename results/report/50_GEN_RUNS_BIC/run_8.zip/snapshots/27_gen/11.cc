tcb->m_segmentSize = (int) (68.816+(-20.966)+(95.579)+(-1.006)+(-76.575));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-24.636-(23.603)-(95.086));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (43.418-(-88.917)-(-47.871));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (14.571-(-22.07)-(77.282));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
