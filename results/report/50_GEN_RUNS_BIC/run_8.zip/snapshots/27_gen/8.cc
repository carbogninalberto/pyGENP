ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(75.167)-(57.294)-(tcb->m_cWnd)-(94.41)-(57.689)-(11.36)-(2.164)-(53.519));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(-15.399)*(-75.958)*(9.946));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(82.109)*(-15.901)*(9.946));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(75.167)-(57.294)-(tcb->m_cWnd)-(94.41)-(57.689)-(11.36)-(2.164)-(53.519));

}
tcb->m_segmentSize = (int) (-11.102-(-17.849)-(11.458)-(-22.408)-(35.035)-(-32.604)-(71.167)-(-38.666)-(-89.025));
if (segmentsAcked == tcb->m_segmentSize) {
	segmentsAcked = (int) (((0.1)+(42.021)+(83.715)+(35.107))/((29.636)+(0.1)+(0.1)+(49.452)+(11.964)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(27.401)+(84.226));

} else {
	segmentsAcked = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
