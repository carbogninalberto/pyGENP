if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (8.677*(85.138)*(segmentsAcked)*(82.68)*(66.581)*(91.633)*(73.827)*(37.6)*(29.781));

} else {
	tcb->m_cWnd = (int) (15.145+(90.593)+(65.93)+(86.314)+(tcb->m_cWnd)+(17.592));

}
int tSiQQLgrJDLFwCBE = (int) (62.038+(36.866)+(35.126)+(49.019)+(50.51)+(85.858));
tcb->m_segmentSize = (int) (16.498-(3.027)-(tcb->m_segmentSize)-(49.091)-(87.02)-(tSiQQLgrJDLFwCBE)-(56.68)-(7.675));
ReduceCwnd (tcb);
tSiQQLgrJDLFwCBE = (int) (segmentsAcked+(98.575)+(48.911)+(43.579)+(84.391)+(65.258)+(19.35));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
