ReduceCwnd (tcb);
if (cnt < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (29.879+(87.518)+(79.488)+(5.597));

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(81.218)+(75.924)+(0.1)+(0.1)+(61.356))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize != tcb->m_cWnd) {
	segmentsAcked = (int) (48.896+(59.851)+(21.721)+(76.508)+(tcb->m_cWnd)+(36.35)+(42.908)+(20.596));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(73.636)-(29.221)-(48.444)-(23.087));

} else {
	segmentsAcked = (int) (64.549*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(36.777)*(99.45)*(18.245));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (12.458/61.727);
tcb->m_cWnd = (int) (31.919-(52.764)-(31.127));
if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (20.639+(80.676)+(tcb->m_cWnd)+(65.264)+(8.087)+(32.907));
	segmentsAcked = (int) (cnt-(58.236)-(66.687)-(68.074)-(26.434)-(36.327)-(52.475)-(42.879)-(23.651));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (74.802*(64.347)*(6.129)*(39.822)*(tcb->m_cWnd));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
int gSmPdTALqbxhHZhQ = (int) (((0.1)+(0.1)+(52.881)+(25.719)+(30.291))/((31.569)+(0.1)));
if (tcb->m_cWnd > tcb->m_cWnd) {
	cnt = (int) (2.249-(70.172)-(cnt)-(86.176)-(16.179)-(35.285));
	cnt = (int) (tcb->m_ssThresh+(9.232)+(23.392)+(77.596)+(18.509)+(48.767)+(4.61));

} else {
	cnt = (int) (gSmPdTALqbxhHZhQ-(69.451)-(29.816)-(17.252));
	cnt = (int) (0.1/36.329);
	tcb->m_ssThresh = (int) (95.238+(54.068)+(91.298)+(gSmPdTALqbxhHZhQ)+(63.723)+(95.706));

}
