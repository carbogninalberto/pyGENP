tcb->m_ssThresh = (int) ((33.49+(98.775)+(54.969)+(21.434)+(79.968)+(25.412)+(tcb->m_cWnd)+(39.507))/63.0);
float vbRSqfXsbWRpOygW = (float) (92.874/0.1);
ReduceCwnd (tcb);
segmentsAcked = (int) (88.585-(90.138)-(tcb->m_cWnd)-(1.511));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
