ReduceCwnd (tcb);
segmentsAcked = (int) (16.854/0.1);
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (47.807-(94.619)-(84.128));
	tcb->m_ssThresh = (int) (94.72*(50.249)*(21.455)*(45.042));
	cnt = (int) (0.1/69.762);

} else {
	tcb->m_ssThresh = (int) (0.1/62.305);
	cnt = (int) (80.773*(27.873)*(cnt)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(31.744)*(53.856)*(tcb->m_cWnd));

}
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_segmentSize = (int) (55.112/(tcb->m_cWnd+(64.051)+(8.15)+(6.513)+(tcb->m_cWnd)+(91.0)+(tcb->m_cWnd)+(31.032)+(53.634)));
	tcb->m_segmentSize = (int) (67.338/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (75.678-(tcb->m_cWnd)-(77.067)-(89.261)-(tcb->m_cWnd));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (72.098-(29.91)-(75.404)-(36.238));
