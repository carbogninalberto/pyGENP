ReduceCwnd (tcb);
int IfsVDbCezrUyqStS = (int) (27.021+(55.299)+(37.754)+(64.779)+(84.778)+(63.369)+(69.419));
if (IfsVDbCezrUyqStS < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (57.593+(tcb->m_ssThresh)+(11.863)+(96.669)+(49.179)+(28.425)+(73.347));
	tcb->m_segmentSize = (int) (76.43-(78.337)-(57.753)-(79.331));
	IfsVDbCezrUyqStS = (int) (31.851-(IfsVDbCezrUyqStS)-(19.862)-(67.59)-(9.872));

} else {
	tcb->m_segmentSize = (int) (95.107-(52.676)-(52.884)-(90.85)-(80.632)-(51.716)-(72.293)-(19.995)-(segmentsAcked));
	IfsVDbCezrUyqStS = (int) (41.989/23.967);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt <= cnt) {
	tcb->m_segmentSize = (int) (47.732-(4.299)-(41.933)-(cnt)-(51.96)-(93.138)-(46.71));
	tcb->m_cWnd = (int) (20.969*(38.514)*(72.424)*(40.336)*(42.426)*(cnt));

} else {
	tcb->m_segmentSize = (int) (68.238*(0.454)*(69.724)*(segmentsAcked)*(90.846)*(82.313)*(91.647)*(37.491)*(67.982));
	tcb->m_ssThresh = (int) (38.858-(tcb->m_cWnd)-(13.505)-(79.704)-(93.259)-(97.819));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (0.1/18.302);
ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (58.244*(cnt)*(46.125)*(53.843)*(segmentsAcked)*(83.957)*(19.048));

} else {
	tcb->m_cWnd = (int) (55.729-(64.078)-(IfsVDbCezrUyqStS)-(95.727)-(cnt)-(97.205));

}
tcb->m_segmentSize = (int) (87.253+(27.473)+(8.669)+(tcb->m_segmentSize));
