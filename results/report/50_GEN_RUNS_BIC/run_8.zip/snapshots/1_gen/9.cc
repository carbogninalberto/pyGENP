if (tcb->m_ssThresh != tcb->m_segmentSize) {
	cnt = (int) (tcb->m_cWnd-(86.821)-(46.895)-(13.495)-(cnt)-(6.622)-(19.577)-(25.483)-(74.655));
	tcb->m_cWnd = (int) (35.133*(cnt)*(91.955));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (1.581*(50.59)*(50.426)*(38.67)*(tcb->m_cWnd)*(40.742));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(36.256)-(92.06)-(tcb->m_segmentSize));
	segmentsAcked = (int) (tcb->m_ssThresh+(68.912)+(68.656)+(39.966)+(60.406)+(27.263)+(19.092)+(30.919));

}
cnt = (int) (54.738-(11.541)-(52.386)-(12.936)-(52.145));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
