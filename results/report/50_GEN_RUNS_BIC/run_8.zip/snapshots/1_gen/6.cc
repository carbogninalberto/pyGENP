if (cnt != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (97.042/(14.178*(52.343)*(66.414)*(83.22)));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(9.542))/((11.802)));

}
if (cnt > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((17.132)+(70.654)+(73.621)+((38.738+(63.609)+(52.576)+(71.416)+(tcb->m_ssThresh)))+(0.1)+(0.1))/((0.1)+(58.917)+(16.501)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (cnt-(99.083));
	cnt = (int) (66.82*(8.285));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
cnt = (int) (67.297+(1.143)+(tcb->m_ssThresh)+(23.549)+(53.338)+(15.865));
if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (33.925+(1.101));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (77.85+(11.737)+(87.341)+(46.902)+(30.461)+(61.095)+(cnt)+(60.82));
	segmentsAcked = (int) (11.796+(51.909)+(68.158));

}
cnt = (int) (58.079/13.727);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (8.014+(9.015));
	tcb->m_segmentSize = (int) (11.851+(40.491)+(50.142));
	tcb->m_ssThresh = (int) (54.871+(86.055)+(cnt)+(46.577)+(26.947)+(88.748)+(29.034));

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+((88.102+(80.435)+(94.978)+(94.467)))+(0.1)+(0.1))/((0.1)+(0.1)+(40.882)+(60.836)));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(45.845)*(35.795)*(61.575)*(20.645)*(40.123)*(92.673)*(36.424));

}
