if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (49.089-(45.243)-(cnt)-(11.008)-(12.171)-(38.192));
cnt = (int) (((0.1)+(0.1)+(0.1)+((52.049*(62.919)*(55.694)*(15.832)*(42.273)*(tcb->m_segmentSize)*(72.002)*(39.396)))+(52.257)+(57.351)+(49.333)+(74.013))/((45.88)));
if (tcb->m_cWnd == tcb->m_ssThresh) {
	cnt = (int) (55.908+(1.915)+(50.008)+(59.938)+(95.419)+(36.801)+(50.334)+(2.886));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) ((8.865*(41.222)*(tcb->m_ssThresh)*(66.657)*(21.313)*(24.117)*(98.902)*(segmentsAcked)*(25.165))/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (85.689-(74.384)-(52.084)-(84.509));

}
tcb->m_segmentSize = (int) (tcb->m_cWnd+(17.991)+(12.352)+(90.94)+(48.179)+(59.725));
float yXSXeRsPGioPZMLD = (float) (80.843-(51.771)-(80.868)-(cnt)-(33.905)-(47.85)-(64.782)-(34.817)-(segmentsAcked));
float hDJHEyukmaDctTJE = (float) (0.1/62.281);
if (yXSXeRsPGioPZMLD <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) ((61.426*(1.307)*(89.279)*(88.589)*(51.157)*(85.429)*(12.999)*(79.965)*(65.331))/99.316);
	yXSXeRsPGioPZMLD = (float) (cnt+(93.573)+(17.433)+(yXSXeRsPGioPZMLD)+(66.912));

}
if (hDJHEyukmaDctTJE == cnt) {
	tcb->m_segmentSize = (int) (4.829+(86.336)+(74.93)+(87.801)+(72.594)+(94.21)+(84.098)+(hDJHEyukmaDctTJE));
	yXSXeRsPGioPZMLD = (float) (21.716+(89.38)+(94.521)+(94.561)+(76.88));

} else {
	tcb->m_segmentSize = (int) (73.962-(tcb->m_cWnd)-(15.949)-(tcb->m_cWnd)-(hDJHEyukmaDctTJE)-(58.991));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
