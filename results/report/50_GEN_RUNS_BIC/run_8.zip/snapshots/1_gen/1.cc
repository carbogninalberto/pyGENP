if (tcb->m_segmentSize >= cnt) {
	tcb->m_segmentSize = (int) (segmentsAcked-(22.312)-(66.871)-(segmentsAcked)-(tcb->m_cWnd)-(0.541)-(51.359)-(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (86.076-(tcb->m_ssThresh)-(46.655)-(69.869)-(9.779)-(tcb->m_cWnd)-(83.381)-(43.924)-(88.484));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(7.774)*(25.144)*(99.041)*(62.203)*(44.714)*(cnt)*(segmentsAcked));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (57.238*(23.906)*(92.378)*(3.443)*(23.659)*(tcb->m_segmentSize)*(25.813)*(85.967));
tcb->m_cWnd = (int) (tcb->m_cWnd-(tcb->m_cWnd)-(55.401));
