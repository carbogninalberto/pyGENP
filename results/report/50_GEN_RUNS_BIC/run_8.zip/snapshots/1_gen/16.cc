if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (94.821+(3.662)+(12.126));

} else {
	tcb->m_ssThresh = (int) (36.03*(65.611));
	segmentsAcked = (int) (51.682-(87.29)-(17.995)-(57.915)-(22.932)-(53.536));
	tcb->m_ssThresh = (int) (0.731+(18.834));

}
cnt = (int) (1.876*(cnt)*(cnt)*(29.676));
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_cWnd = (int) (54.975+(86.266)+(35.997)+(39.581)+(23.364)+(96.043)+(41.852)+(70.733));

} else {
	tcb->m_cWnd = (int) (((0.1)+(1.841)+(0.1)+(0.1)+(0.1)+(7.845))/((62.673)+(44.884)+(38.835)));
	tcb->m_cWnd = (int) (55.987+(tcb->m_ssThresh)+(43.098)+(45.542)+(85.985)+(39.185)+(7.742));

}
tcb->m_ssThresh = (int) (0.1/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
