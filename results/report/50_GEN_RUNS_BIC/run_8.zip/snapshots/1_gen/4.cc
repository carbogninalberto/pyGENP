if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (((0.1)+((68.216-(19.104)-(24.723)))+(11.685)+(0.1))/((0.1)));
if (tcb->m_cWnd != cnt) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+((49.844+(81.035)+(62.223)+(52.608)+(65.201)+(14.53)))+(0.1)+(43.592)+(0.1))/((32.507)));

} else {
	tcb->m_segmentSize = (int) (87.365+(72.122)+(39.463));
	segmentsAcked = (int) (41.222+(18.009)+(cnt)+(67.105)+(77.998));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(90.052)*(91.575)*(6.82)*(63.163)*(tcb->m_ssThresh)*(36.256)*(97.401)*(19.261));

}
tcb->m_ssThresh = (int) (28.748-(tcb->m_cWnd));
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	cnt = (int) (tcb->m_segmentSize*(97.832)*(16.209));
	tcb->m_cWnd = (int) ((((10.504+(68.615)+(35.041)+(14.889)+(48.666)+(39.331)+(6.011)+(65.868)+(37.102)))+(39.071)+(51.999)+(0.1))/((0.1)+(0.1)+(3.09)+(0.1)));

} else {
	cnt = (int) (tcb->m_cWnd-(95.684));
	ReduceCwnd (tcb);

}
