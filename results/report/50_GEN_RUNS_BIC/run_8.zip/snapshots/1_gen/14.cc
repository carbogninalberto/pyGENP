if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= tcb->m_cWnd) {
	cnt = (int) (60.341*(52.489)*(87.797));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (13.137*(segmentsAcked)*(30.362)*(cnt));

} else {
	cnt = (int) (((73.607)+((29.648*(3.222)*(32.122)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(4.392)*(segmentsAcked)*(tcb->m_ssThresh)))+(0.1)+(1.93))/((73.927)+(0.1)+(0.1)+(42.033)));

}
if (segmentsAcked > tcb->m_segmentSize) {
	segmentsAcked = (int) ((43.96+(19.298)+(90.953)+(93.957))/49.293);

} else {
	segmentsAcked = (int) (68.757+(73.447)+(97.292)+(segmentsAcked)+(99.898)+(61.349)+(90.83)+(73.587)+(segmentsAcked));

}
if (cnt < segmentsAcked) {
	tcb->m_ssThresh = (int) (((0.1)+(46.433)+(43.423)+((16.992*(34.982)*(88.05)*(66.672)*(61.683)))+((76.129+(67.131)+(11.822)+(78.395)+(37.231)+(75.919)))+(74.034)+(81.094))/((6.124)));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(11.678)-(71.596)-(segmentsAcked)-(14.97)-(30.765));

}
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(44.651)+(60.105)+(29.156));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(tcb->m_ssThresh));

}
if (cnt >= cnt) {
	tcb->m_cWnd = (int) (85.02+(94.877)+(72.641));

} else {
	tcb->m_cWnd = (int) (65.154-(98.121)-(73.407)-(30.069)-(26.764)-(tcb->m_cWnd)-(tcb->m_cWnd)-(74.964));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (55.716*(49.484)*(72.054)*(12.344));

}
