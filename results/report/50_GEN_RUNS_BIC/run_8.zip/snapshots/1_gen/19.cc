if (segmentsAcked >= tcb->m_ssThresh) {
	cnt = (int) (9.633*(25.145)*(26.624)*(51.168)*(40.927));

} else {
	cnt = (int) (42.378+(94.145)+(tcb->m_segmentSize)+(85.44));
	segmentsAcked = (int) (49.724+(14.109)+(5.334)+(93.442)+(55.012)+(29.706));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_cWnd = (int) (99.257+(52.306)+(36.845)+(cnt)+(62.659)+(27.156)+(15.496));
	cnt = (int) (13.112*(tcb->m_cWnd)*(90.5)*(46.067)*(27.615)*(21.543)*(28.737)*(12.699)*(48.754));
	tcb->m_cWnd = (int) (52.255*(tcb->m_ssThresh)*(23.18)*(67.932)*(75.921)*(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (64.46+(tcb->m_segmentSize)+(segmentsAcked)+(tcb->m_cWnd)+(65.549)+(tcb->m_cWnd)+(50.412)+(63.231)+(8.101));
	tcb->m_cWnd = (int) (20.29*(84.939)*(87.731));

}
ReduceCwnd (tcb);
