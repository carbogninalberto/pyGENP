int nJCXrfyMeipeCgtP = (int) (18.799*(3.218)*(21.545)*(40.901)*(79.455)*(25.071));
if (tcb->m_cWnd != tcb->m_segmentSize) {
	cnt = (int) (nJCXrfyMeipeCgtP+(26.796)+(51.807)+(0.239)+(89.554));
	tcb->m_ssThresh = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (nJCXrfyMeipeCgtP+(98.78)+(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_ssThresh >= nJCXrfyMeipeCgtP) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (74.92+(67.265)+(9.472)+(97.726)+(81.695)+(62.995));
	tcb->m_segmentSize = (int) (98.204+(4.804)+(tcb->m_ssThresh)+(30.222)+(63.572));

}
int vkevBXYaWqrTeDoH = (int) (75.994+(91.708)+(44.045)+(97.277)+(37.121));
float MopLNQkDJncMwMHm = (float) (22.788-(80.621)-(16.025)-(36.28)-(79.659)-(36.171)-(tcb->m_segmentSize)-(75.659));
int IdfQalztljviNXaD = (int) (90.344+(66.174)+(tcb->m_segmentSize)+(23.203)+(vkevBXYaWqrTeDoH));
vkevBXYaWqrTeDoH = (int) (25.547+(70.167)+(7.322)+(96.874));
ReduceCwnd (tcb);
