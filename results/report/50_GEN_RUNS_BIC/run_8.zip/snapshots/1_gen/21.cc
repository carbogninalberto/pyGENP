if (segmentsAcked <= segmentsAcked) {
	tcb->m_segmentSize = (int) (16.465/38.076);

} else {
	tcb->m_segmentSize = (int) (80.277*(30.519)*(65.899)*(30.646)*(cnt)*(77.652)*(75.277));

}
if (tcb->m_ssThresh == cnt) {
	segmentsAcked = (int) ((23.712+(cnt)+(segmentsAcked)+(79.481)+(cnt))/80.596);
	ReduceCwnd (tcb);
	cnt = (int) ((tcb->m_cWnd+(32.999)+(96.277)+(42.2)+(53.246)+(56.012)+(44.266)+(54.669))/0.1);

} else {
	segmentsAcked = (int) (tcb->m_cWnd*(27.329)*(tcb->m_ssThresh)*(58.09)*(50.406));
	tcb->m_segmentSize = (int) (59.982*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(95.74)*(cnt));
	tcb->m_ssThresh = (int) (23.669/0.1);

}
tcb->m_segmentSize = (int) (22.873/0.1);
if (cnt > cnt) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(94.927)+(42.003)+(15.18)+(94.006)+(52.266));

} else {
	tcb->m_ssThresh = (int) (41.623+(80.641)+(tcb->m_cWnd)+(10.09)+(segmentsAcked)+(cnt)+(63.255)+(88.587));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (segmentsAcked*(50.049));
