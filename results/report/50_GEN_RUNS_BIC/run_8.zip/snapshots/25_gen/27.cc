ReduceCwnd (tcb);
cnt = (int) (69.563+(92.731));
if (tcb->m_cWnd <= cnt) {
	tcb->m_cWnd = (int) (2.824+(tcb->m_segmentSize)+(7.121)+(7.018));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) ((cnt+(25.692))/0.1);

} else {
	tcb->m_cWnd = (int) (64.028+(94.914)+(86.247)+(17.301)+(41.16)+(10.162));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt <= tcb->m_segmentSize) {
	cnt = (int) (segmentsAcked+(16.855));
	tcb->m_ssThresh = (int) (((29.644)+(57.194)+(75.297)+(0.1)+((16.427*(cnt)*(tcb->m_ssThresh)*(6.522)))+((39.375+(25.228)+(tcb->m_ssThresh)+(5.58)+(70.524)+(89.405)+(96.967)))+(10.162))/((0.1)));

} else {
	cnt = (int) (tcb->m_cWnd*(2.086)*(52.381)*(29.216)*(84.629)*(58.945));
	tcb->m_segmentSize = (int) (93.066/0.1);

}
if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (54.465-(86.877));
	segmentsAcked = (int) (66.669-(33.251)-(37.459)-(12.319)-(69.907)-(10.308));
	tcb->m_cWnd = (int) (cnt*(15.984)*(45.112)*(tcb->m_segmentSize)*(6.04)*(91.999)*(80.229)*(10.916)*(73.643));

} else {
	tcb->m_cWnd = (int) (12.8-(tcb->m_cWnd)-(5.117)-(60.819)-(tcb->m_ssThresh)-(cnt)-(tcb->m_ssThresh)-(29.757)-(22.016));

}
segmentsAcked = (int) (45.263+(segmentsAcked)+(26.051)+(39.523)+(82.768)+(88.017));
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (11.238*(4.71)*(segmentsAcked)*(segmentsAcked)*(86.327)*(98.634)*(97.751));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (0.1/61.511);
	tcb->m_cWnd = (int) (81.915*(cnt));

}
if (tcb->m_cWnd == segmentsAcked) {
	segmentsAcked = (int) (tcb->m_cWnd*(15.626)*(7.788)*(24.964));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (tcb->m_cWnd+(42.313)+(80.649)+(22.18)+(82.153)+(7.358)+(73.224));
	ReduceCwnd (tcb);

}
