float DbAjyzYiEHnNrgOb = (float) (-94.19*(-89.537)*(-97.295)*(-96.74)*(19.839)*(95.065)*(-58.221)*(-36.916)*(83.78));
float bwEEjDEJAcQzBaVo = (float) (-19.26*(-47.141)*(-22.524));
if (bwEEjDEJAcQzBaVo <= segmentsAcked) {
	segmentsAcked = (int) (tcb->m_cWnd-(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (1.412-(75.645));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
