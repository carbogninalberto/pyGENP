if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (85.817-(2.382)-(97.562)-(49.477));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (12.189+(80.658)+(5.463)+(12.703)+(9.533)+(64.13)+(tcb->m_segmentSize)+(74.237)+(37.847));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(cnt)*(43.517)*(16.22));

}
cnt = (int) (((0.1)+(2.242)+(90.972)+(68.943))/((10.679)+(22.099)+(0.1)+(62.362)));
ReduceCwnd (tcb);
if (tcb->m_segmentSize != cnt) {
	segmentsAcked = (int) (99.21-(90.203));
	tcb->m_ssThresh = (int) (9.153*(5.174)*(tcb->m_ssThresh)*(47.455)*(26.949)*(16.067)*(42.238));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (71.562+(41.744));
	ReduceCwnd (tcb);

}
