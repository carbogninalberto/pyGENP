if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) ((((tcb->m_cWnd+(25.753)+(60.46)+(90.047)+(tcb->m_ssThresh)+(27.831)+(tcb->m_segmentSize)+(5.658)+(tcb->m_cWnd)))+((74.59+(cnt)+(89.307)+(48.146)))+(0.1)+(5.469))/((20.966)+(0.1)+(19.943)+(0.1)));
tcb->m_segmentSize = (int) (cnt-(27.153)-(24.571)-(69.313)-(25.54)-(tcb->m_cWnd)-(95.431)-(63.419)-(84.328));
if (tcb->m_segmentSize == cnt) {
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(tcb->m_segmentSize)-(1.952)-(62.918)-(59.613)-(12.16));
	tcb->m_segmentSize = (int) (28.753*(44.004)*(15.696)*(92.196)*(24.299)*(9.957));
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (87.137*(58.576));
	tcb->m_cWnd = (int) (80.968+(1.821)+(54.194)+(23.531)+(tcb->m_cWnd)+(66.214));

}
ReduceCwnd (tcb);
