tcb->m_ssThresh = (int) (tcb->m_cWnd-(26.061));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (25.298+(16.282)+(37.725));
segmentsAcked = (int) (((0.1)+((cnt*(33.391)))+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));
if (cnt > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (79.026-(99.163)-(44.235)-(45.549)-(88.175)-(tcb->m_cWnd)-(80.878));
	segmentsAcked = (int) ((97.667-(52.852)-(29.98)-(39.117)-(12.751)-(tcb->m_cWnd))/27.197);

} else {
	tcb->m_ssThresh = (int) (99.055*(tcb->m_cWnd)*(7.811)*(31.314)*(10.826)*(17.451)*(12.284)*(83.726));
	tcb->m_cWnd = (int) (20.914+(81.497)+(87.937)+(91.233)+(1.362)+(92.257)+(75.54)+(63.392));

}
