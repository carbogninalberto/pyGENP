if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (95.611*(79.746));

} else {
	tcb->m_cWnd = (int) (((89.826)+(0.1)+(0.1)+(97.799)+((tcb->m_segmentSize-(cnt)))+(1.083)+(0.1))/((0.1)));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(tcb->m_segmentSize)-(3.576));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (70.544*(-97.008)*(25.407)*(-46.215)*(-75.155));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (13.769*(-66.985)*(12.686)*(-78.215)*(87.482));
