if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int nFTYwNhgPYbSPLVF = (int) (-96.882-(30.35)-(-0.588)-(-88.788)-(99.521)-(-91.7)-(-11.127));
tcb->m_cWnd = (int) (-67.727*(-53.428)*(-16.125)*(81.403)*(-87.221));
