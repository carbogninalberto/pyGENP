ReduceCwnd (tcb);
int XPmYhOvtWcymDxdY = (int) (42.561-(33.674)-(tcb->m_segmentSize)-(37.537)-(70.036)-(6.078));
cnt = (int) ((((66.869*(15.064)*(53.987)*(XPmYhOvtWcymDxdY)*(92.497)*(6.75)*(35.255)))+(57.082)+((57.926-(segmentsAcked)-(20.68)-(60.133)-(44.282)-(68.681)-(1.025)-(67.32)))+(0.1))/((0.1)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
