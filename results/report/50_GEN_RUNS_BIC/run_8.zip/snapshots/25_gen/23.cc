if (segmentsAcked <= segmentsAcked) {
	tcb->m_ssThresh = (int) (51.533*(-0.042));

} else {
	tcb->m_ssThresh = (int) (9.486+(29.334)+(43.471)+(94.267)+(tcb->m_ssThresh)+(51.463)+(53.324)+(cnt)+(cnt));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int HblrwjcplqMjQEgd = (int) (96.111*(91.184)*(72.653)*(12.925)*(65.732)*(tcb->m_ssThresh)*(76.588)*(8.002)*(47.418));
ReduceCwnd (tcb);
if (segmentsAcked != tcb->m_segmentSize) {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(28.607))/((0.1)));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(27.816)*(44.334)*(tcb->m_cWnd)*(50.051)*(97.374)*(47.853)*(41.674)*(84.84));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize-(cnt)-(tcb->m_segmentSize)-(13.814)-(2.827)-(HblrwjcplqMjQEgd)-(30.571)-(42.198)-(46.405));
	tcb->m_cWnd = (int) (39.136*(HblrwjcplqMjQEgd)*(97.742)*(21.208));

}
HblrwjcplqMjQEgd = (int) (29.043-(91.17)-(tcb->m_segmentSize)-(cnt)-(25.166)-(90.07)-(29.916));
float HtSRiJycNPOnMlkH = (float) (52.351+(46.814));
if (cnt > tcb->m_ssThresh) {
	cnt = (int) (20.985+(7.083)+(97.47)+(54.709)+(41.969)+(5.167)+(23.034)+(47.896)+(47.295));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (85.191-(36.548)-(HblrwjcplqMjQEgd)-(36.314)-(14.889)-(63.298)-(96.25));

}
HtSRiJycNPOnMlkH = (float) (0.1/0.1);
