if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(4.995)-(54.312)-(4.917)-(32.632)-(66.68)-(24.851)-(95.568)-(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (79.283*(72.749)*(56.356)*(61.841)*(cnt)*(11.267)*(27.6));

}
tcb->m_cWnd = (int) (96.478-(80.268));
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (42.319+(90.369)+(segmentsAcked)+(tcb->m_segmentSize)+(15.108)+(86.95)+(tcb->m_segmentSize)+(31.771));
	segmentsAcked = (int) (82.656+(36.193));
	tcb->m_cWnd = (int) (79.168*(35.566)*(34.664)*(35.292)*(tcb->m_segmentSize)*(10.622)*(35.906)*(89.912)*(10.375));

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (4.687-(43.102));
	tcb->m_segmentSize = (int) (0.1/49.429);

}
ReduceCwnd (tcb);
if (segmentsAcked <= segmentsAcked) {
	tcb->m_cWnd = (int) (89.706-(5.069)-(0.763)-(2.765)-(62.073));
	tcb->m_segmentSize = (int) (1.363*(63.816)*(80.528));

} else {
	tcb->m_cWnd = (int) (80.13+(17.73)+(68.05));

}
