if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (23.975*(19.963));
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_cWnd = (int) (segmentsAcked+(tcb->m_segmentSize)+(40.01)+(53.531)+(95.833));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (61.541-(6.33)-(tcb->m_ssThresh)-(99.546)-(18.674));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(70.803)-(segmentsAcked)-(tcb->m_segmentSize)-(35.019)-(tcb->m_segmentSize)-(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (80.784*(88.512));
tcb->m_segmentSize = (int) (3.08*(cnt)*(37.166));
segmentsAcked = (int) (68.055/0.1);
