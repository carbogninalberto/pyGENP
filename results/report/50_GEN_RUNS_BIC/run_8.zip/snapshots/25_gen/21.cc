if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((28.909*(cnt)*(25.894)*(14.604)*(85.296)*(47.083)*(66.599)*(16.182)*(tcb->m_segmentSize))/49.488);

} else {
	tcb->m_segmentSize = (int) (2.128*(tcb->m_ssThresh)*(1.123)*(8.714)*(34.705));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (93.142*(54.164)*(62.248)*(29.314)*(8.742)*(3.51)*(1.374)*(64.625)*(40.989));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (35.913+(35.879)+(64.917)+(81.005));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
int egcMmgQOpvhfRIsS = (int) (tcb->m_segmentSize+(12.529)+(49.645)+(33.387));
tcb->m_ssThresh = (int) (65.073*(33.269)*(segmentsAcked)*(24.866)*(1.154)*(17.479)*(56.34)*(tcb->m_cWnd)*(36.668));
if (cnt <= egcMmgQOpvhfRIsS) {
	tcb->m_cWnd = (int) (2.391+(42.636)+(cnt)+(81.201)+(18.473));

} else {
	tcb->m_cWnd = (int) (97.007-(13.43)-(13.943)-(42.815)-(6.927));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (87.914*(egcMmgQOpvhfRIsS)*(tcb->m_cWnd)*(58.758)*(68.161)*(tcb->m_ssThresh)*(30.966));

}
ReduceCwnd (tcb);
cnt = (int) ((33.858-(97.993)-(4.647)-(34.612)-(93.424)-(86.808)-(62.606))/96.769);
