if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (22.395/0.1);

} else {
	tcb->m_cWnd = (int) (segmentsAcked+(66.086)+(86.333)+(14.562)+(41.408));

}
float GuhBQJWcqdexOxIi = (float) (13.879+(tcb->m_ssThresh)+(cnt)+(81.253));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (((90.07)+(0.1)+(0.1)+(93.217))/((46.248)+(0.1)));
ReduceCwnd (tcb);
