float YJTZDYpENxpkINAk = (float) (tcb->m_ssThresh+(59.11)+(25.765)+(31.392)+(24.222));
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (segmentsAcked-(82.982)-(22.783)-(tcb->m_segmentSize)-(42.003)-(12.101)-(50.046)-(62.477)-(15.917));
	YJTZDYpENxpkINAk = (float) (70.584+(98.158));

} else {
	tcb->m_segmentSize = (int) (17.813+(tcb->m_segmentSize));

}
if (cnt <= segmentsAcked) {
	YJTZDYpENxpkINAk = (float) (((0.1)+(0.1)+(0.1)+(79.256))/((80.834)+(0.1)+(0.1)));
	tcb->m_ssThresh = (int) (91.999*(54.582)*(YJTZDYpENxpkINAk));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	YJTZDYpENxpkINAk = (float) (73.27+(59.969)+(60.415)+(62.43)+(66.924)+(85.435)+(11.123)+(0.171));

}
float lWWuiqLfFxBPStZD = (float) (20.506*(45.537)*(45.193)*(15.808)*(84.199)*(47.46)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(83.824));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd <= segmentsAcked) {
	lWWuiqLfFxBPStZD = (float) (57.356*(43.789)*(91.197)*(YJTZDYpENxpkINAk)*(5.364));
	segmentsAcked = (int) (13.617-(segmentsAcked)-(segmentsAcked)-(37.283)-(1.512)-(69.09)-(99.816)-(59.817));
	ReduceCwnd (tcb);

} else {
	lWWuiqLfFxBPStZD = (float) (18.321+(tcb->m_segmentSize)+(88.032));
	tcb->m_cWnd = (int) (13.04*(62.779)*(4.497)*(70.648)*(12.326)*(4.15)*(41.11)*(21.893));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
