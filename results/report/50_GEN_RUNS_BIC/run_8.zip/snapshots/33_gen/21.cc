if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(58.347)+(cnt)+(30.1)+(78.973)+(segmentsAcked)+(12.407)+(92.293));
	segmentsAcked = (int) (41.613-(3.717)-(tcb->m_ssThresh)-(29.026)-(66.772));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (40.407*(segmentsAcked)*(0.369)*(81.097)*(77.439));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((48.163+(29.982))/0.1);
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (90.047*(36.199)*(57.443)*(37.699));
	tcb->m_cWnd = (int) (59.755+(86.817)+(13.236)+(segmentsAcked)+(79.721)+(60.116)+(14.9)+(65.761));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_cWnd = (int) (63.426-(47.775)-(78.732)-(90.577)-(62.767));
ReduceCwnd (tcb);
int MIxTOCQetgFKXPuA = (int) (41.638+(tcb->m_ssThresh)+(cnt)+(75.143)+(tcb->m_ssThresh)+(cnt)+(30.553));
tcb->m_ssThresh = (int) (74.066*(49.725)*(53.091)*(97.075)*(90.965)*(3.228)*(1.112)*(72.006)*(69.025));
cnt = (int) ((((30.837*(37.036)*(5.839)*(tcb->m_cWnd)*(7.746)*(24.804)*(69.549)*(cnt)*(tcb->m_segmentSize)))+(0.1)+(13.782)+(45.133)+(55.234))/((61.573)+(22.258)));
ReduceCwnd (tcb);
