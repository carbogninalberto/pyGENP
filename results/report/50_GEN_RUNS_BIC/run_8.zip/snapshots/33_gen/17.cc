if (tcb->m_cWnd > tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/(cnt*(17.223)*(52.341)));
	cnt = (int) (60.902+(51.929)+(16.902)+(64.873)+(51.394)+(46.091));

} else {
	segmentsAcked = (int) (0.1/10.637);
	ReduceCwnd (tcb);

}
cnt = (int) ((81.624*(tcb->m_ssThresh)*(51.909)*(29.911)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(70.958)*(tcb->m_cWnd)*(81.675))/0.1);
ReduceCwnd (tcb);
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (30.854-(82.381)-(46.775)-(18.519)-(tcb->m_segmentSize)-(12.653)-(98.148));

} else {
	tcb->m_ssThresh = (int) (67.653*(88.2)*(31.37)*(95.182)*(80.692)*(cnt));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (80.907/50.302);

}
segmentsAcked = (int) (44.598+(99.217)+(12.192)+(73.631)+(cnt));
