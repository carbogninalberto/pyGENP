if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (20.862*(-65.155)*(13.138)*(4.47));
tcb->m_segmentSize = (int) (-60.745-(-97.105)-(-44.625)-(-49.93));
segmentsAcked = (int) (3.952-(3.382)-(-13.162)-(31.334)-(14.289)-(4.188)-(-37.435));
segmentsAcked = (int) (-73.87-(-63.031)-(75.997)-(52.049)-(-17.646)-(3.336)-(-40.659));
