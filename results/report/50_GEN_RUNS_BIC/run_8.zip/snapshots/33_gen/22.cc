if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (75.434/0.1);

} else {
	tcb->m_ssThresh = (int) (24.061*(89.245)*(segmentsAcked));
	tcb->m_ssThresh = (int) (49.549+(cnt)+(segmentsAcked)+(50.104)+(32.299));
	tcb->m_segmentSize = (int) (82.856+(69.006)+(cnt)+(98.431)+(95.228)+(49.744)+(tcb->m_cWnd)+(88.099)+(81.102));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize > cnt) {
	tcb->m_ssThresh = (int) (20.551+(16.487)+(63.757)+(23.636)+(86.121)+(0.495)+(29.053)+(54.264)+(91.455));
	segmentsAcked = (int) (17.689-(0.65)-(86.582)-(38.546)-(50.408)-(93.102));

} else {
	tcb->m_ssThresh = (int) (16.745+(50.715)+(tcb->m_ssThresh)+(41.376));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (76.529-(39.431)-(cnt));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (86.919-(91.221)-(tcb->m_cWnd)-(60.751));

} else {
	tcb->m_segmentSize = (int) (93.726/0.1);
	tcb->m_cWnd = (int) (cnt*(34.789)*(45.179)*(11.774)*(31.388)*(84.603)*(43.027)*(85.746));
	tcb->m_ssThresh = (int) (35.009-(53.568)-(segmentsAcked));

}
cnt = (int) (14.053*(15.499)*(segmentsAcked));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
