cnt = (int) (((0.1)+(85.485)+(10.355)+((8.199*(cnt)))+(88.36)+((60.824*(68.203)*(61.652)*(33.356)*(70.123)*(60.21)*(26.099)*(95.005)))+(0.1)+(0.1))/((75.339)));
cnt = (int) ((((segmentsAcked+(62.535)+(50.306)+(91.715)+(30.961)+(25.035)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(24.373)))+(80.498)+(90.575)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)));
if (cnt > segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(98.683)*(16.202)*(63.399));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(35.914)+(6.76)+(11.512)+(43.704)+(66.41)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (96.726*(7.014)*(27.856)*(82.055)*(88.741)*(49.46));
	cnt = (int) (tcb->m_ssThresh+(20.829)+(31.369)+(66.423)+(37.962)+(cnt)+(94.636)+(79.849));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) (53.73/0.1);
	segmentsAcked = (int) (tcb->m_segmentSize-(42.464));
	tcb->m_ssThresh = (int) (40.978-(0.445)-(83.343)-(5.225)-(55.989)-(81.303)-(51.296)-(51.036));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(45.873)*(7.121)*(tcb->m_ssThresh)*(segmentsAcked)*(86.841));
	tcb->m_cWnd = (int) (7.794+(90.368)+(23.297));
	segmentsAcked = (int) (cnt*(61.129)*(19.836)*(92.409)*(59.846)*(33.017)*(cnt));

}
if (tcb->m_segmentSize <= cnt) {
	cnt = (int) (segmentsAcked-(17.276)-(segmentsAcked)-(48.755)-(92.552)-(44.845)-(tcb->m_segmentSize)-(71.111));
	segmentsAcked = (int) (96.86-(34.936)-(tcb->m_cWnd)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(97.432)-(73.292));

} else {
	cnt = (int) ((((tcb->m_segmentSize+(tcb->m_cWnd)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(61.413)+(tcb->m_segmentSize)+(65.222)+(11.6)+(segmentsAcked)))+(56.835)+(30.294)+(86.669)+(0.1))/((0.1)+(0.1)+(0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (3.42+(50.267)+(16.5)+(67.712)+(26.554));
