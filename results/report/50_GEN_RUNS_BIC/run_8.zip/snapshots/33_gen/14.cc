if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (((71.203)+(40.704)+(70.624)+(74.252))/((0.1)+(16.889)));

} else {
	tcb->m_cWnd = (int) (23.776+(tcb->m_cWnd)+(80.534)+(92.029)+(segmentsAcked)+(55.483));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (((64.403)+((93.745*(3.441)*(13.602)*(6.833)*(tcb->m_ssThresh)*(74.703)*(tcb->m_cWnd)))+(0.1)+(0.1)+(0.1)+(0.1)+(68.018))/((0.1)+(37.665)));

}
tcb->m_cWnd = (int) (36.08+(tcb->m_cWnd)+(4.809));
cnt = (int) (tcb->m_segmentSize*(94.556)*(86.646)*(70.536)*(1.168)*(97.145));
tcb->m_segmentSize = (int) (tcb->m_cWnd*(4.553)*(60.916)*(7.928)*(69.416)*(cnt)*(tcb->m_cWnd)*(tcb->m_cWnd));
ReduceCwnd (tcb);
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (39.2-(tcb->m_ssThresh)-(37.535)-(80.694)-(53.226)-(12.921)-(56.481)-(56.362)-(93.442));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (83.007-(84.332)-(62.701)-(cnt)-(32.289)-(49.094));
	tcb->m_ssThresh = (int) ((91.566+(41.817)+(11.615)+(tcb->m_cWnd)+(77.571)+(tcb->m_cWnd))/75.019);
	tcb->m_ssThresh = (int) (97.962-(90.467)-(53.58)-(20.506)-(94.102)-(tcb->m_segmentSize)-(1.501)-(53.216)-(33.222));

}
if (tcb->m_segmentSize <= cnt) {
	tcb->m_cWnd = (int) (26.423+(tcb->m_segmentSize)+(88.796)+(80.465)+(44.829)+(13.292)+(14.64)+(92.726));

} else {
	tcb->m_cWnd = (int) (29.005*(79.793)*(82.519)*(cnt));
	tcb->m_cWnd = (int) (3.038*(69.794)*(68.234)*(cnt)*(73.251)*(44.921)*(29.624)*(61.91));
	tcb->m_cWnd = (int) (17.406-(97.64)-(91.461)-(cnt));

}
segmentsAcked = (int) (29.82+(97.845)+(segmentsAcked));
ReduceCwnd (tcb);
