if (tcb->m_cWnd < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (91.428-(32.655)-(56.45)-(60.748)-(78.044)-(34.392)-(27.73)-(87.4)-(96.634));

} else {
	tcb->m_segmentSize = (int) (46.68+(25.857)+(63.611)+(9.671)+(61.088)+(69.695)+(17.14)+(61.331)+(9.97));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (59.125*(91.9));
tcb->m_segmentSize = (int) (58.497*(59.301)*(segmentsAcked)*(54.563)*(98.678)*(31.8)*(tcb->m_ssThresh));
if (cnt <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (69.151*(89.685)*(34.633)*(95.732)*(cnt)*(16.877)*(75.991)*(segmentsAcked));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (47.07+(37.188)+(75.89)+(31.112)+(39.326)+(94.75)+(segmentsAcked)+(90.075));

} else {
	tcb->m_cWnd = (int) (98.199+(41.211)+(89.889)+(24.319)+(71.017)+(36.934)+(17.416)+(33.879));

}
if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (96.334*(19.644)*(tcb->m_ssThresh));
	cnt = (int) (64.818*(97.382)*(93.421)*(35.854)*(45.739)*(73.275)*(segmentsAcked)*(cnt)*(27.326));
	segmentsAcked = (int) (52.379*(17.0)*(21.275));

} else {
	segmentsAcked = (int) (((0.1)+(94.655)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));

}
tcb->m_cWnd = (int) (16.786*(37.836)*(75.848)*(73.744));
