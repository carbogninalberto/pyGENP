segmentsAcked = (int) (13.152+(69.011)+(72.754)+(65.945)+(47.831)+(6.509));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-45.647+(39.588)+(-94.615)+(88.712)+(-92.531));
ReduceCwnd (tcb);
