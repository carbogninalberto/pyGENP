if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= tcb->m_segmentSize) {
	cnt = (int) (52.058-(77.118)-(12.815)-(33.96)-(72.418)-(32.611)-(23.854)-(30.64));
	tcb->m_ssThresh = (int) (99.582/62.467);
	ReduceCwnd (tcb);

} else {
	cnt = (int) (8.998+(52.823)+(segmentsAcked)+(59.116)+(cnt)+(69.775)+(0.671));
	segmentsAcked = (int) (78.654/0.1);
	ReduceCwnd (tcb);

}
cnt = (int) (29.798-(tcb->m_ssThresh)-(segmentsAcked)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(35.147)-(99.558)-(1.058)-(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
