ReduceCwnd (tcb);
float pmrKZveNkPRPIUYx = (float) ((tcb->m_ssThresh-(3.051)-(10.989)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(11.086))/89.11);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (pmrKZveNkPRPIUYx+(11.127));
	cnt = (int) (94.476+(46.454)+(52.125)+(57.469)+(26.898)+(75.541)+(96.74));
	tcb->m_ssThresh = (int) (75.88-(62.741)-(pmrKZveNkPRPIUYx)-(49.538)-(89.398)-(72.851)-(59.429)-(cnt));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(75.73)+((93.268*(7.708)))+(0.1))/((40.667)+(28.541)+(0.1)+(0.1)));

}
tcb->m_ssThresh = (int) (41.059*(84.753)*(78.886)*(99.19)*(43.234)*(75.583)*(14.272)*(22.697));
tcb->m_ssThresh = (int) (4.725+(98.214)+(26.333)+(81.707)+(9.058)+(74.352));
int uKvSGAmbLpVQDXGt = (int) (28.496+(52.709)+(12.4)+(63.734)+(65.897)+(50.17)+(91.767)+(5.67)+(2.792));
