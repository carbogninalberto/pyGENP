tcb->m_segmentSize = (int) (97.256*(96.307)*(90.772)*(-5.866)*(93.367));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
