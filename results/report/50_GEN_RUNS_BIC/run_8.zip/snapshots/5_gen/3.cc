tcb->m_segmentSize = (int) (63.838*(35.757)*(-9.223)*(-60.997)*(-85.473));
tcb->m_segmentSize = (int) (85.041*(-24.371)*(-94.725)*(30.956)*(-74.881));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
