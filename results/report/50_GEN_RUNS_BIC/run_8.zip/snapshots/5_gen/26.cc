ReduceCwnd (tcb);
cnt = (int) (tcb->m_cWnd*(9.715)*(14.556));
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	cnt = (int) (26.18-(tcb->m_segmentSize)-(78.645)-(23.756)-(26.136)-(99.119)-(segmentsAcked));

} else {
	cnt = (int) (88.996-(44.439)-(3.065)-(tcb->m_segmentSize)-(cnt)-(18.133));

}
int mofcNQTnTUpGGqfo = (int) (tcb->m_segmentSize+(80.806)+(17.2)+(segmentsAcked));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize >= mofcNQTnTUpGGqfo) {
	cnt = (int) (32.639*(35.546));

} else {
	cnt = (int) (79.353*(92.989)*(21.709)*(22.55));

}
