cnt = (int) (0.1/35.469);
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (18.574-(5.554)-(44.05)-(tcb->m_cWnd)-(52.326)-(61.574));
	tcb->m_segmentSize = (int) (61.114+(75.779)+(80.591)+(8.059)+(53.257)+(0.877)+(54.651)+(28.755));
	cnt = (int) (30.927*(39.406)*(4.814)*(38.377)*(25.084)*(78.134));

} else {
	tcb->m_segmentSize = (int) (55.455*(80.26)*(24.305)*(-0.094)*(cnt));
	cnt = (int) (84.02-(segmentsAcked)-(cnt)-(cnt));

}
tcb->m_cWnd = (int) (99.451-(44.116)-(92.413)-(tcb->m_ssThresh)-(14.622)-(94.763)-(49.213));
cnt = (int) (18.272-(38.717)-(38.113)-(40.536)-(segmentsAcked)-(43.606)-(57.53));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (44.464-(68.711)-(85.869));
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	cnt = (int) (36.144-(cnt));
	segmentsAcked = (int) (22.963+(segmentsAcked)+(68.359)+(29.257)+(18.275)+(34.902)+(56.158));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (86.041+(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (76.96-(34.302)-(segmentsAcked)-(67.257)-(tcb->m_ssThresh)-(37.57)-(37.879));

}
