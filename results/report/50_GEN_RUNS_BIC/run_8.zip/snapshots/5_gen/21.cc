if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
cnt = (int) (55.176*(87.122)*(segmentsAcked)*(tcb->m_ssThresh)*(68.539)*(34.243)*(6.503));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (79.097/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/15.44);
	tcb->m_segmentSize = (int) (((39.333)+((20.752+(tcb->m_cWnd)+(tcb->m_segmentSize)+(86.518)))+(0.1)+(96.32))/((17.068)));

} else {
	segmentsAcked = (int) (0.1/89.546);
	tcb->m_cWnd = (int) (9.016*(76.235)*(51.402)*(6.685));

}
