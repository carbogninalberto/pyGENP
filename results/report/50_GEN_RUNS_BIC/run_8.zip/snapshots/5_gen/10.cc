if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int IAVWHndrRAqKQoDX = (int) 88.495;
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((71.348)+(93.202)+(46.231)+(-70.825)+((-45.267-(segmentsAcked)-(31.102)-(-72.125)-(segmentsAcked)-(-78.524)-(-52.125)-(-70.701)-(86.862)))+(-96.866)+(36.652)+(32.116))/((17.164)));
tcb->m_segmentSize = (int) ((tcb->m_ssThresh-(-20.274)-(-96.158)-(49.366)-(-44.956)-(18.371)-(-6.942))/-49.22);
