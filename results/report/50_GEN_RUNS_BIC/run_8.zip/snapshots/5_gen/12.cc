tcb->m_segmentSize = (int) (-8.533*(11.15)*(-8.432)*(-12.701)*(83.947));
tcb->m_segmentSize = (int) (47.884*(-61.309)*(-24.788)*(71.31)*(98.995));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
