float nDuzXrhbLJkFdGcV = (float) (-72.077*(29.732)*(-6.785)*(-6.604)*(-8.829));
ReduceCwnd (tcb);
segmentsAcked = (int) (-96.653-(16.024)-(-58.08)-(-91.108)-(81.954)-(-62.909)-(78.144));
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (19.461+(64.834)+(9.103)+(55.882)+(99.575)+(2.905)+(50.633)+(79.703));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (47.704+(21.268)+(95.997)+(78.192)+(tcb->m_segmentSize)+(-71.8)+(tcb->m_segmentSize));

}
segmentsAcked = (int) (-45.389-(-52.699)-(33.343)-(-95.279)-(33.413)-(99.402)-(-20.809));
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (19.461+(64.834)+(9.103)+(55.882)+(99.575)+(2.905)+(50.633)+(79.703));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (47.704+(21.268)+(95.997)+(94.387)+(tcb->m_segmentSize)+(-19.157)+(tcb->m_segmentSize));

}
