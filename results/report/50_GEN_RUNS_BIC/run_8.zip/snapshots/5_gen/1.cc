tcb->m_segmentSize = (int) (1.222*(34.556)*(88.207)*(84.861)*(-20.554));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
