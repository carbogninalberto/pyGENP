tcb->m_segmentSize = (int) (-56.295*(47.27)*(-81.489)*(75.78)*(30.14));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
