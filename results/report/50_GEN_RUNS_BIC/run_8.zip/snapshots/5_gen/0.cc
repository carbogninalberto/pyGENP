tcb->m_segmentSize = (int) (13.336*(-73.789)*(23.448)*(21.412)*(-37.185));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
