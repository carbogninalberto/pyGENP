tcb->m_segmentSize = (int) (-31.913*(-91.109)*(-19.47)*(79.311)*(83.868));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
