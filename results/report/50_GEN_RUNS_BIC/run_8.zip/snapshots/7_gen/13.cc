int hYFCjPKruhHWKmoa = (int) (84.993-(4.822));
ReduceCwnd (tcb);
segmentsAcked = (int) (71.608-(1.878));
segmentsAcked = (int) (-8.198-(-69.024));
hYFCjPKruhHWKmoa = (int) ((-87.325-(-59.619)-(-67.686))/-35.159);
