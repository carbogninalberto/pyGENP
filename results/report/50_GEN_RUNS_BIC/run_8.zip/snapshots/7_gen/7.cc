float oYjTwTbPNiTPhwmN = (float) (-11.848-(-13.192)-(66.072)-(-67.357)-(22.102)-(-39.965)-(24.234)-(-48.375));
float WUMXKCZmPHiXUnFq = (float) (75.303/47.221);
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (93.877-(49.48));
	segmentsAcked = (int) (22.529*(-23.956)*(73.525)*(79.788)*(2.968)*(6.056));

} else {
	tcb->m_cWnd = (int) (39.295*(-63.542)*(97.618)*(tcb->m_cWnd));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
