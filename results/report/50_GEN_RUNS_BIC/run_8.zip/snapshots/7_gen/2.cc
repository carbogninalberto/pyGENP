tcb->m_segmentSize = (int) (36.223*(-54.769)*(-9.368)*(24.764)*(50.943));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
