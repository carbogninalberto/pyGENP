tcb->m_segmentSize = (int) (-13.084*(-67.244)*(-84.729)*(-22.93)*(-37.127));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
