tcb->m_segmentSize = (int) (68.45*(50.748)*(67.992)*(tcb->m_ssThresh)*(6.564)*(52.97)*(segmentsAcked));
if (cnt <= tcb->m_ssThresh) {
	segmentsAcked = (int) (56.47*(segmentsAcked)*(segmentsAcked)*(76.592)*(34.647)*(58.079));

} else {
	segmentsAcked = (int) (82.607+(tcb->m_segmentSize)+(94.302)+(30.616)+(33.966)+(segmentsAcked));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (22.6-(40.708));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(segmentsAcked)-(tcb->m_cWnd)-(84.97)-(25.26)-(83.355)-(37.108));
	tcb->m_cWnd = (int) (85.91+(67.517)+(4.086)+(34.24)+(90.884)+(50.438));
	cnt = (int) (segmentsAcked*(41.17)*(95.431));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
