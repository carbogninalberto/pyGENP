int RXQXSbesghTQHXAi = (int) (-33.164-(34.952)-(-14.937)-(-96.587)-(42.984)-(-2.012));
ReduceCwnd (tcb);
segmentsAcked = (int) (-22.457+(17.341)+(-83.793)+(36.332)+(-56.463)+(-22.676)+(-35.62)+(48.259));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (34.245+(-48.721));
RXQXSbesghTQHXAi = (int) (-5.383+(44.469)+(-87.153)+(98.765)+(57.634)+(-35.339)+(-35.314)+(50.924)+(6.957));
