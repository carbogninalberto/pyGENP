if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (cnt+(85.673)+(69.409)+(97.946)+(67.514)+(27.85)+(17.02));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (0.1/94.796);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (88.055-(18.298)-(tcb->m_ssThresh)-(95.728)-(tcb->m_cWnd));
ReduceCwnd (tcb);
