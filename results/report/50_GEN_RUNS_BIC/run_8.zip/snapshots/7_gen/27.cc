if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < cnt) {
	segmentsAcked = (int) (tcb->m_ssThresh+(85.087)+(40.939));
	cnt = (int) (73.139+(tcb->m_cWnd)+(3.619)+(54.667));
	segmentsAcked = (int) (95.44*(92.356)*(44.857)*(74.884)*(42.523)*(51.551)*(93.752)*(54.188)*(29.992));

} else {
	segmentsAcked = (int) (68.027-(68.622)-(tcb->m_ssThresh)-(34.639)-(60.2)-(19.969)-(54.582));
	tcb->m_segmentSize = (int) ((((69.474-(tcb->m_ssThresh)-(24.503)-(47.603)-(81.751)-(94.192)-(8.552)-(33.203)))+(0.1)+(0.1)+((68.855*(59.043)*(75.339)*(91.8)*(34.209)))+(47.419)+(82.413))/((0.1)));
	cnt = (int) (76.48*(83.259)*(91.814));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (58.392+(cnt)+(5.254)+(tcb->m_cWnd)+(34.166));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (cnt*(tcb->m_cWnd)*(82.861)*(32.032)*(9.313)*(73.99)*(segmentsAcked));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (34.143*(37.308)*(segmentsAcked)*(5.293));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	cnt = (int) (79.092*(41.763)*(15.261));
	tcb->m_ssThresh = (int) (94.726*(tcb->m_segmentSize)*(segmentsAcked));

} else {
	cnt = (int) (84.172-(63.548)-(63.849)-(66.964)-(36.854)-(25.464)-(43.549)-(50.035)-(35.97));

}
