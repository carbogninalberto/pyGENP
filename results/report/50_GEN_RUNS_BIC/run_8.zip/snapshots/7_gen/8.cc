int hYFCjPKruhHWKmoa = (int) (11.969-(3.365));
ReduceCwnd (tcb);
segmentsAcked = (int) (-77.509-(72.332));
