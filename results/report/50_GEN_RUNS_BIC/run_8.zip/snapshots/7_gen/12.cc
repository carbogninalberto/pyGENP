tcb->m_segmentSize = (int) (64.464*(-51.228)*(-68.275)*(-41.714)*(37.612));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (2.962*(82.416)*(-24.86)*(-6.859)*(23.287));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
