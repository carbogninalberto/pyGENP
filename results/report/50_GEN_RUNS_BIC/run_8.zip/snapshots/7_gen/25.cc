ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	cnt = (int) (33.486-(41.0));

} else {
	cnt = (int) (0.1/0.1);
	segmentsAcked = (int) (87.682+(87.535)+(99.714)+(16.212));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_cWnd = (int) (14.282*(20.543)*(55.811)*(88.449)*(44.072)*(tcb->m_cWnd)*(16.367)*(92.732)*(16.967));
int bLdlccOHNzhRaSHN = (int) (13.493/75.965);
ReduceCwnd (tcb);
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(44.726)+(32.807)+(tcb->m_ssThresh)+(90.118)+(38.928));
	tcb->m_cWnd = (int) (92.266*(bLdlccOHNzhRaSHN)*(0.785)*(95.829));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (82.331*(tcb->m_segmentSize)*(65.993)*(93.713)*(4.868));
	segmentsAcked = (int) (tcb->m_ssThresh+(20.803)+(2.41));
	tcb->m_ssThresh = (int) (bLdlccOHNzhRaSHN+(4.587)+(73.005)+(19.771)+(30.731)+(segmentsAcked)+(51.439)+(58.029)+(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
