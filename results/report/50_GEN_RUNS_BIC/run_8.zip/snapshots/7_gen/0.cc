tcb->m_segmentSize = (int) (92.519*(-22.235)*(81.59)*(88.226)*(-19.41));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
