tcb->m_segmentSize = (int) (-93.441*(34.442)*(74.701)*(61.082)*(-78.199));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
