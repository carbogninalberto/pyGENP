cnt = (int) (4.935*(tcb->m_cWnd)*(53.779));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	cnt = (int) (31.942*(40.386)*(6.803)*(59.403)*(segmentsAcked)*(14.433));
	tcb->m_ssThresh = (int) (61.598+(cnt)+(83.346)+(59.906)+(60.025)+(50.895)+(21.489));

} else {
	cnt = (int) (((50.668)+(0.1)+(66.769)+(98.492))/((91.492)));
	tcb->m_segmentSize = (int) (22.221-(87.862)-(16.227));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (34.786*(tcb->m_ssThresh)*(94.711)*(16.425)*(14.19)*(47.099)*(98.252));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
