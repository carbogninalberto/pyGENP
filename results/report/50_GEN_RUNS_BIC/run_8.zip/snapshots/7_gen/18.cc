if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (82.074*(tcb->m_ssThresh)*(9.228)*(66.811)*(31.642)*(75.745));
segmentsAcked = (int) (46.91-(86.68)-(78.313)-(37.448)-(79.309)-(27.019)-(65.708)-(77.707));
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) ((47.758-(97.811)-(8.265))/0.1);

} else {
	tcb->m_ssThresh = (int) (82.94*(cnt)*(35.857)*(9.919));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (10.051*(segmentsAcked)*(tcb->m_ssThresh)*(20.512)*(72.481)*(38.511));

}
tcb->m_segmentSize = (int) (0.1/0.1);
