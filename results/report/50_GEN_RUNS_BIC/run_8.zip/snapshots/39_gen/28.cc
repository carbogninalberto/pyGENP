ReduceCwnd (tcb);
int TnHYOgXkeOnOeSaP = (int) (26.569/0.1);
ReduceCwnd (tcb);
int rsIPCKoTnxqjFcaR = (int) (56.031*(91.208)*(51.641)*(76.173));
tcb->m_segmentSize = (int) (rsIPCKoTnxqjFcaR+(tcb->m_segmentSize)+(83.077)+(tcb->m_cWnd)+(36.064));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
