if (segmentsAcked > tcb->m_cWnd) {
	cnt = (int) (67.727+(96.426)+(33.995)+(84.64));
	tcb->m_segmentSize = (int) ((45.371*(segmentsAcked)*(17.357))/95.775);

} else {
	cnt = (int) (89.998-(28.158)-(49.103)-(tcb->m_ssThresh)-(74.957));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (47.905*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(53.543)*(3.809));
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (87.274+(33.132)+(16.461));

} else {
	tcb->m_segmentSize = (int) (29.754-(31.0)-(34.446)-(72.667));
	tcb->m_ssThresh = (int) (54.24+(83.107)+(39.337)+(81.162)+(26.218));

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	cnt = (int) (49.432+(17.648)+(21.965)+(27.553)+(tcb->m_cWnd)+(4.524));

} else {
	cnt = (int) (37.486-(60.349)-(72.03)-(79.419)-(segmentsAcked)-(32.643));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (16.945-(79.17)-(89.739)-(53.123)-(segmentsAcked)-(97.792)-(63.116)-(32.017));

}
tcb->m_cWnd = (int) (0.1/9.833);
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.976/77.83);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (85.741-(tcb->m_ssThresh)-(45.66)-(78.52));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
