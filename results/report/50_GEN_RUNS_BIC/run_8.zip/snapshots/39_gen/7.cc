if (segmentsAcked < tcb->m_segmentSize) {
	cnt = (int) (30.656*(39.106)*(15.284)*(85.932)*(87.314)*(98.855)*(13.16)*(93.346)*(41.134));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	cnt = (int) (68.248-(17.444)-(25.872)-(34.862)-(40.982));

}
tcb->m_ssThresh = (int) (((66.988)+(7.561)+((2.457*(12.963)*(18.038)*(36.238)*(45.821)*(23.728)))+(55.747))/((32.115)+(15.525)));
if (tcb->m_ssThresh >= segmentsAcked) {
	segmentsAcked = (int) ((82.262+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(cnt)+(tcb->m_segmentSize)+(32.818)+(90.641)+(66.919)+(84.752))/0.1);

} else {
	segmentsAcked = (int) (cnt-(32.385)-(cnt)-(98.082)-(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize > cnt) {
	tcb->m_segmentSize = (int) (71.534-(tcb->m_cWnd)-(83.467)-(29.063)-(30.639));

} else {
	tcb->m_segmentSize = (int) (59.673/92.935);
	ReduceCwnd (tcb);

}
