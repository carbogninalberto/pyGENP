int ggzpNQFExgNiIyjS = (int) (63.627-(-50.071)-(99.304)-(34.876)-(24.529)-(-69.278)-(26.219)-(75.508)-(65.236));
float IXqqqEzFyaMtGfZG = (float) 19.146;
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
