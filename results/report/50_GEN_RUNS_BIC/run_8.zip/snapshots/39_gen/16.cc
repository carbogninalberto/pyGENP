if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (64.272-(39.379)-(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (54.242*(87.269));

}
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	segmentsAcked = (int) (19.896*(75.899)*(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (37.467*(94.19)*(cnt));
	tcb->m_ssThresh = (int) (85.714*(17.716)*(tcb->m_cWnd)*(65.014));

} else {
	segmentsAcked = (int) ((segmentsAcked*(94.386)*(76.519)*(15.321)*(36.633)*(42.155)*(tcb->m_cWnd))/79.667);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (80.224-(29.554)-(53.668)-(20.732));

}
if (tcb->m_ssThresh == tcb->m_cWnd) {
	cnt = (int) (44.353*(19.697)*(cnt)*(28.518));
	segmentsAcked = (int) (41.203+(60.588)+(91.164)+(94.142)+(21.567)+(99.801)+(56.753)+(67.318)+(59.112));

} else {
	cnt = (int) (cnt+(34.168)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(5.249)+(85.138)+(60.031)+(cnt));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	segmentsAcked = (int) (53.853*(25.76)*(68.054)*(77.978));

} else {
	segmentsAcked = (int) (78.449+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (47.889-(56.424)-(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (64.36*(11.451));
cnt = (int) (0.1/11.076);
if (segmentsAcked <= segmentsAcked) {
	tcb->m_ssThresh = (int) (((79.616)+(99.398)+(0.1)+(0.1))/((35.354)));
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(75.459)+(40.522)+(0.1))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(96.161));
	cnt = (int) (19.856-(87.014));

}
