tcb->m_segmentSize = (int) (63.629*(cnt)*(20.035)*(81.612)*(53.525)*(41.497));
tcb->m_cWnd = (int) (((59.518)+(72.853)+(0.1)+((94.351*(66.645)*(45.74)*(28.257)*(86.891)*(8.216)))+(32.56))/((61.458)+(0.1)+(0.1)+(72.647)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int jDChGGitQvXSsKUl = (int) (0.1/(tcb->m_segmentSize*(91.603)*(1.633)*(tcb->m_segmentSize)*(27.875)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
