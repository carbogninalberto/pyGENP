float yaicWiDToEtGHHvG = (float) (54.859*(70.723)*(55.592)*(61.019)*(tcb->m_cWnd)*(33.775)*(25.258)*(16.019)*(52.996));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (19.09+(95.457)+(88.898)+(51.239)+(tcb->m_segmentSize)+(40.691));
	tcb->m_cWnd = (int) (43.515*(18.491)*(64.888)*(22.129)*(73.669)*(31.676)*(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(61.601)+(87.945)+(86.72)+(59.491)+(79.793)+(tcb->m_cWnd));
	cnt = (int) ((18.7*(69.142)*(34.771)*(78.433))/20.296);

}
float eCjZylBCgkgUzjRC = (float) (45.208+(0.682)+(35.109)+(89.577)+(93.159)+(5.127)+(87.248)+(7.817)+(7.602));
float mkIxujxZzvcwRYnk = (float) (68.848+(39.217)+(4.53)+(14.373)+(28.705)+(47.255)+(77.217));
float zzCihMWKLttHjbau = (float) (96.472+(cnt)+(cnt)+(96.694)+(58.235)+(tcb->m_segmentSize)+(33.512));
if (cnt >= zzCihMWKLttHjbau) {
	zzCihMWKLttHjbau = (float) (49.179-(4.792)-(tcb->m_ssThresh)-(69.494)-(tcb->m_cWnd));
	mkIxujxZzvcwRYnk = (float) (50.102+(zzCihMWKLttHjbau));

} else {
	zzCihMWKLttHjbau = (float) (29.636-(87.504)-(85.137)-(54.579)-(tcb->m_segmentSize)-(35.648)-(74.118));

}
eCjZylBCgkgUzjRC = (float) (((0.1)+(36.441)+((tcb->m_cWnd*(39.773)*(5.016)*(97.739)*(yaicWiDToEtGHHvG)*(58.754)*(49.659)*(9.25)*(79.468)))+(87.311)+(0.1)+(0.1))/((0.1)+(42.06)+(96.975)));
mkIxujxZzvcwRYnk = (float) (91.888+(49.581)+(36.741)+(37.116));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
