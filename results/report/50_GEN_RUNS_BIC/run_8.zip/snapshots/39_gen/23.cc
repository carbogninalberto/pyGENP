if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((0.1)+(51.525)+(1.79)+(0.1))/((0.1)+(58.684)+(0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (((33.386)+(0.1)+(33.903)+(85.537)+(0.1)+(0.1))/((7.843)+(0.1)+(99.516)));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
float mJZLRuIAAngqDNWG = (float) (11.89+(16.573)+(53.642)+(83.961)+(21.448)+(50.691)+(cnt)+(29.868)+(63.425));
