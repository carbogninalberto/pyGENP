ReduceCwnd (tcb);
segmentsAcked = (int) (1.533+(83.064));
tcb->m_segmentSize = (int) (39.654+(segmentsAcked)+(22.394)+(12.911)+(47.01)+(46.414)+(67.036));
tcb->m_ssThresh = (int) (((53.779)+(4.96)+(80.637)+(0.1)+(9.71)+(0.1)+(0.1)+(0.1))/((0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
