tcb->m_ssThresh = (int) ((((30.089-(52.735)-(26.147)))+(68.108)+(56.735)+(0.1))/((0.1)));
tcb->m_segmentSize = (int) (1.245*(34.96)*(21.752)*(cnt)*(13.921));
tcb->m_ssThresh = (int) (97.647+(66.427));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (cnt*(tcb->m_ssThresh)*(81.684)*(11.37)*(tcb->m_segmentSize)*(81.262)*(87.173)*(tcb->m_cWnd)*(25.291));
tcb->m_cWnd = (int) (79.959-(41.246));
