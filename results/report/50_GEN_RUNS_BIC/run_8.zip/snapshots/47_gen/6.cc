if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float mjCGxcxvggFWFERr = (float) (((20.718)+(0.1)+((54.093-(67.333)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(7.116)))+(64.774)+(52.881)+((tcb->m_cWnd*(tcb->m_cWnd)*(87.182)))+(0.1))/((0.1)+(0.1)));
cnt = (int) (89.311+(cnt)+(18.035)+(65.0));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (cnt <= tcb->m_segmentSize) {
	mjCGxcxvggFWFERr = (float) (82.122-(85.01)-(89.778)-(tcb->m_segmentSize)-(15.496)-(tcb->m_cWnd)-(cnt));
	ReduceCwnd (tcb);

} else {
	mjCGxcxvggFWFERr = (float) (tcb->m_segmentSize+(46.4)+(81.507)+(85.748)+(24.0)+(9.361));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
