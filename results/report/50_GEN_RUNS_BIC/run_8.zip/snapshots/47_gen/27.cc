if (tcb->m_ssThresh <= cnt) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (99.362-(60.024)-(57.393));
	tcb->m_segmentSize = (int) (34.746+(44.588)+(64.906)+(60.951)+(90.035)+(92.149)+(32.656));
	tcb->m_segmentSize = (int) (0.1/71.402);

}
tcb->m_ssThresh = (int) (77.887*(cnt)*(59.68));
tcb->m_cWnd = (int) (((72.815)+(0.1)+(0.1)+(0.1))/((0.1)+(9.912)+(0.1)));
tcb->m_ssThresh = (int) (24.3+(20.342));
segmentsAcked = (int) (0.71-(49.086));
tcb->m_cWnd = (int) (63.922-(tcb->m_ssThresh)-(segmentsAcked)-(50.104)-(56.883)-(92.001));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (segmentsAcked*(7.776)*(35.791)*(2.971));
