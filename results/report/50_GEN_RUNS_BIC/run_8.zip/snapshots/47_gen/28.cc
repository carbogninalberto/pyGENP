if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_cWnd) {
	cnt = (int) (75.9/7.182);
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(tcb->m_cWnd)-(71.776)-(14.303)-(0.914));

} else {
	cnt = (int) (76.467+(tcb->m_cWnd)+(segmentsAcked)+(0.223)+(cnt)+(48.351)+(tcb->m_cWnd));

}
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(94.53)*(segmentsAcked)*(49.279)*(23.601)*(64.78));

} else {
	tcb->m_ssThresh = (int) (25.291-(tcb->m_cWnd)-(27.555)-(89.364)-(60.298));
	tcb->m_segmentSize = (int) (45.271/9.301);
	tcb->m_segmentSize = (int) ((39.886+(tcb->m_cWnd)+(68.121)+(50.954)+(81.17)+(31.323)+(60.082)+(12.486)+(segmentsAcked))/0.1);

}
tcb->m_ssThresh = (int) (72.401*(62.329)*(50.473)*(82.028));
int ySkuURfrcLWpMKTV = (int) (65.0*(segmentsAcked)*(segmentsAcked)*(26.278)*(38.814));
if (segmentsAcked >= segmentsAcked) {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (71.401*(15.826)*(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (33.386*(75.925)*(41.722)*(66.248));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh+(tcb->m_cWnd)+(88.134)+(51.663)+(50.454)+(47.1)+(ySkuURfrcLWpMKTV)+(1.88)+(67.259));
	tcb->m_ssThresh = (int) (((34.06)+(97.432)+((57.323*(61.956)*(tcb->m_segmentSize)*(0.605)*(0.191)*(22.013)*(98.316)*(tcb->m_ssThresh)*(86.288)))+(16.124))/((44.917)+(0.1)));
	cnt = (int) ((22.728-(ySkuURfrcLWpMKTV)-(75.929)-(53.259))/(82.208-(17.916)-(61.313)-(67.264)));

}
ReduceCwnd (tcb);
