if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (74.153/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(58.338)*(89.96)*(42.247));
	tcb->m_cWnd = (int) ((((tcb->m_segmentSize-(11.134)-(46.96)-(tcb->m_ssThresh)-(4.211)-(68.533)-(tcb->m_ssThresh)))+(0.1)+(50.149)+(0.1))/((0.1)+(0.1)+(22.471)));
	tcb->m_ssThresh = (int) (55.822*(16.172)*(92.227)*(75.672)*(tcb->m_cWnd));

}
segmentsAcked = (int) (95.95*(4.806)*(16.385));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (22.863*(23.582)*(31.07)*(2.62)*(81.883)*(17.906));
ReduceCwnd (tcb);
