tcb->m_segmentSize = (int) (49.285+(cnt)+(87.834));
if (cnt < tcb->m_cWnd) {
	segmentsAcked = (int) (68.407+(89.314)+(0.795)+(47.049)+(49.485)+(22.018)+(segmentsAcked));
	tcb->m_segmentSize = (int) (87.524/39.83);
	tcb->m_ssThresh = (int) (55.448*(40.205));

} else {
	segmentsAcked = (int) (12.2/20.458);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (27.334*(46.466)*(tcb->m_cWnd)*(11.79)*(43.274)*(35.963));
	tcb->m_cWnd = (int) (33.131-(99.099));

} else {
	tcb->m_cWnd = (int) (45.22*(86.189)*(17.621)*(cnt)*(52.78));
	tcb->m_ssThresh = (int) (75.873+(67.563)+(61.764)+(54.049)+(56.046));
	segmentsAcked = (int) (93.005*(segmentsAcked)*(69.334)*(cnt)*(6.671)*(segmentsAcked)*(83.06)*(89.424)*(35.17));

}
if (cnt == tcb->m_ssThresh) {
	cnt = (int) (25.47-(23.829)-(90.829)-(segmentsAcked)-(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (86.872+(29.925)+(segmentsAcked)+(cnt)+(66.301)+(16.908)+(60.011)+(61.26)+(72.303));
	segmentsAcked = (int) (91.925/74.812);

} else {
	cnt = (int) (84.35*(17.656)*(73.908)*(12.352));
	cnt = (int) (81.192+(85.72)+(75.014)+(67.366)+(83.428)+(tcb->m_cWnd)+(44.857));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
