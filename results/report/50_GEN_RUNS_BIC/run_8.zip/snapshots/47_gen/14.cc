cnt = (int) (((0.1)+(79.008)+(4.18)+(92.983)+(0.1))/((22.412)+(0.1)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (cnt+(6.688));
segmentsAcked = (int) (97.536/0.1);
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.1/(71.666+(91.904)+(45.822)+(31.283)+(cnt)+(27.663)+(60.478)));

} else {
	tcb->m_ssThresh = (int) (0.1/51.569);

}
segmentsAcked = (int) (98.805-(41.442)-(51.995)-(14.506)-(57.03)-(segmentsAcked)-(38.609)-(cnt));
