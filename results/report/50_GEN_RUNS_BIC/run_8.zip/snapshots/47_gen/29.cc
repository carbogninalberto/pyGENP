float menhlHmFByFOJnBZ = (float) (74.02/40.113);
cnt = (int) (cnt*(menhlHmFByFOJnBZ)*(16.57)*(48.354)*(19.348)*(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(5.839)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(12.496)*(tcb->m_ssThresh));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (51.641-(99.968)-(cnt)-(37.699)-(93.364)-(22.997)-(84.921)-(58.074));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (97.757-(90.051));

}
if (tcb->m_segmentSize < tcb->m_cWnd) {
	menhlHmFByFOJnBZ = (float) (43.015*(3.97)*(19.116)*(82.324)*(49.13)*(2.256)*(88.674)*(82.935));

} else {
	menhlHmFByFOJnBZ = (float) (54.551-(21.098)-(8.681)-(42.864)-(72.209)-(59.058));
	tcb->m_ssThresh = (int) (86.265+(56.712)+(27.216)+(46.201)+(61.183)+(93.116)+(23.285)+(22.152));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(76.25)-(42.691));

}
