ReduceCwnd (tcb);
if (tcb->m_segmentSize <= cnt) {
	tcb->m_ssThresh = (int) (34.847*(tcb->m_segmentSize)*(cnt)*(98.912)*(segmentsAcked)*(segmentsAcked)*(15.79)*(64.54));

} else {
	tcb->m_ssThresh = (int) (74.647*(88.134)*(62.015)*(11.547)*(54.035)*(26.614)*(19.789));

}
cnt = (int) (32.615*(3.999)*(14.677)*(80.604)*(97.979)*(76.661)*(1.589)*(62.186)*(20.449));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (1.813+(18.96)+(73.195)+(tcb->m_segmentSize));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (62.369*(84.051)*(12.318)*(37.629)*(22.111));
