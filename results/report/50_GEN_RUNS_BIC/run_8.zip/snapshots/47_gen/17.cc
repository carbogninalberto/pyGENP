cnt = (int) (45.576-(77.633)-(88.249)-(tcb->m_segmentSize)-(90.917)-(tcb->m_cWnd)-(0.449)-(53.993));
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (43.092+(41.236)+(32.382)+(15.226)+(tcb->m_ssThresh)+(44.38));

} else {
	tcb->m_cWnd = (int) (66.251/0.1);

}
int IPEgjLzkkMrTMJfb = (int) (tcb->m_cWnd-(47.069)-(64.228)-(44.121)-(58.581)-(93.716)-(27.078));
ReduceCwnd (tcb);
if (cnt > segmentsAcked) {
	tcb->m_ssThresh = (int) (60.383+(72.099)+(0.422)+(61.02)+(5.196)+(88.101)+(69.557)+(98.479)+(75.885));
	IPEgjLzkkMrTMJfb = (int) (91.555-(IPEgjLzkkMrTMJfb)-(91.721)-(14.357)-(84.863)-(72.206)-(46.203));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (39.704*(23.984)*(tcb->m_segmentSize)*(51.169)*(72.518)*(85.63));
	tcb->m_segmentSize = (int) (92.735-(82.736)-(17.633)-(37.742)-(47.374)-(74.541)-(tcb->m_segmentSize)-(32.289)-(77.903));

}
tcb->m_ssThresh = (int) (45.307/63.525);
tcb->m_segmentSize = (int) (63.942+(60.874)+(87.044));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize != tcb->m_cWnd) {
	cnt = (int) (((97.302)+(0.1)+((IPEgjLzkkMrTMJfb+(26.242)+(5.486)+(30.622)+(32.097)+(68.529)))+(25.121)+(0.1)+((IPEgjLzkkMrTMJfb*(58.766)*(48.86)*(78.35)*(71.236)))+(0.1))/((0.1)));
	segmentsAcked = (int) (IPEgjLzkkMrTMJfb*(3.378)*(segmentsAcked)*(62.294)*(tcb->m_segmentSize)*(55.142)*(18.895)*(segmentsAcked));

} else {
	cnt = (int) (35.411/(7.414+(23.067)+(86.371)));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (79.495+(82.645)+(58.718)+(tcb->m_segmentSize)+(64.912)+(83.262)+(segmentsAcked)+(tcb->m_ssThresh));

}
