ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (segmentsAcked >= cnt) {
	tcb->m_cWnd = (int) (1.757+(74.84)+(33.942)+(61.426)+(79.848)+(cnt));
	cnt = (int) (35.618*(39.013));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(58.424)-(93.047)-(38.344));
	segmentsAcked = (int) (20.077*(18.637)*(segmentsAcked)*(76.965)*(63.531)*(86.151)*(tcb->m_segmentSize)*(10.68));
	segmentsAcked = (int) (8.065*(25.635)*(73.486));

}
if (tcb->m_ssThresh != cnt) {
	tcb->m_segmentSize = (int) (2.998-(20.985)-(87.738)-(36.042)-(cnt));
	tcb->m_segmentSize = (int) (segmentsAcked*(22.251)*(9.405));
	tcb->m_ssThresh = (int) (0.1/10.375);

} else {
	tcb->m_segmentSize = (int) (56.714*(tcb->m_cWnd)*(13.94)*(13.927)*(15.303)*(24.681)*(7.306)*(43.998)*(10.921));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
