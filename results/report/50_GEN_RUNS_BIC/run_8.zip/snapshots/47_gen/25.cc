if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (50.132*(41.791)*(64.268)*(87.117)*(22.319));
	tcb->m_cWnd = (int) (27.284-(tcb->m_segmentSize)-(64.999)-(95.684)-(20.102)-(98.424));

} else {
	tcb->m_ssThresh = (int) (18.21+(49.436)+(28.946)+(35.628)+(tcb->m_cWnd));
	cnt = (int) (75.128*(9.459)*(18.12)*(84.397));
	tcb->m_ssThresh = (int) (28.417-(71.767));

}
tcb->m_segmentSize = (int) (9.231-(92.193));
segmentsAcked = (int) (34.629-(50.448)-(15.083)-(42.663)-(67.024)-(56.913));
tcb->m_cWnd = (int) (64.132+(61.141)+(23.509)+(82.758));
tcb->m_segmentSize = (int) (90.243+(67.828)+(46.526)+(46.144)+(segmentsAcked)+(15.858)+(8.713)+(3.036));
ReduceCwnd (tcb);
int GXfvfuPJafxOIika = (int) (57.675-(84.615)-(cnt)-(12.795)-(31.186));
float NudIdOxlIvVwTmNJ = (float) (segmentsAcked+(8.883));
