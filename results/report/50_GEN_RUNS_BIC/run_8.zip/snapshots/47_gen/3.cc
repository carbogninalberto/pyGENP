if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) (72.797+(69.618)+(80.782));
	segmentsAcked = (int) (97.031-(29.181)-(59.663)-(39.945)-(tcb->m_ssThresh)-(32.773)-(5.608));

} else {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (11.964+(segmentsAcked)+(77.379)+(77.197)+(tcb->m_cWnd)+(tcb->m_cWnd));

}
ReduceCwnd (tcb);
float lkRDDqWomaIuizKg = (float) ((((39.827*(80.021)))+(66.499)+(0.1)+(0.1)+((86.669+(15.962)))+(0.1))/((16.42)+(75.159)));
cnt = (int) (72.485/50.933);
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (16.575-(cnt)-(23.098)-(73.779)-(18.301)-(0.65)-(57.371));

} else {
	tcb->m_ssThresh = (int) (24.636+(99.282)+(segmentsAcked)+(21.343));
	tcb->m_segmentSize = (int) (88.076+(cnt)+(53.476)+(66.654)+(82.936)+(cnt)+(31.695)+(28.193));
	lkRDDqWomaIuizKg = (float) ((2.837-(84.174)-(44.981)-(66.597))/0.1);

}
