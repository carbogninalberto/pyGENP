float FsqnHnwYieSTXVJr = (float) (34.035/90.781);
if (cnt >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (82.553-(33.257)-(97.543)-(tcb->m_ssThresh)-(43.246)-(21.327)-(57.462)-(31.308)-(63.261));
	tcb->m_segmentSize = (int) (86.327-(35.579)-(59.596)-(29.641)-(93.154)-(tcb->m_segmentSize));
	segmentsAcked = (int) (61.436+(30.27)+(36.245)+(95.407)+(74.91)+(cnt)+(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (45.133-(24.663)-(10.834));
	segmentsAcked = (int) (75.306-(33.799));

}
int GcKclvIyVZBxywRD = (int) (36.733*(0.605)*(60.971)*(82.685)*(96.211)*(60.725)*(15.548)*(5.642)*(segmentsAcked));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
