int eEtxYatwNxZZyXja = (int) (((13.05)+(0.1)+(0.1)+(0.1)+(0.1))/((85.125)));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (eEtxYatwNxZZyXja*(0.628)*(tcb->m_segmentSize)*(22.367));
	tcb->m_ssThresh = (int) (eEtxYatwNxZZyXja+(2.113));

} else {
	tcb->m_cWnd = (int) (22.746*(50.715)*(79.393));
	cnt = (int) (48.236*(54.276)*(39.324));
	eEtxYatwNxZZyXja = (int) (52.491-(26.058)-(82.327)-(60.953)-(19.022));

}
if (segmentsAcked == tcb->m_ssThresh) {
	segmentsAcked = (int) (26.81-(89.051)-(57.761)-(tcb->m_cWnd)-(73.689)-(44.567)-(22.294)-(13.356));

} else {
	segmentsAcked = (int) (cnt*(54.274)*(44.175)*(segmentsAcked)*(cnt)*(57.106)*(22.164)*(1.818));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (47.955*(72.005)*(70.967)*(22.417)*(23.595)*(38.589)*(37.537)*(eEtxYatwNxZZyXja)*(22.709));
