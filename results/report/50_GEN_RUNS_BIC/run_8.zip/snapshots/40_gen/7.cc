if (cnt > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.38-(60.216)-(56.28)-(82.456)-(segmentsAcked)-(23.606)-(13.993));
	tcb->m_cWnd = (int) (((0.1)+(53.501)+(0.1)+(22.449)+(64.915))/((0.1)));
	cnt = (int) (98.458+(4.201)+(cnt)+(44.814)+(91.666));

} else {
	tcb->m_cWnd = (int) (((49.84)+((39.502*(76.403)*(segmentsAcked)*(segmentsAcked)*(48.947)))+(0.1)+(0.1))/((0.1)+(17.22)+(0.1)+(21.493)+(5.842)));
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(41.628));

}
tcb->m_ssThresh = (int) (89.497+(52.995)+(60.307)+(92.405)+(63.183)+(38.092)+(42.162)+(88.701)+(83.402));
tcb->m_ssThresh = (int) (0.1/0.1);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_cWnd) {
	cnt = (int) (26.653*(58.598)*(segmentsAcked)*(70.405));

} else {
	cnt = (int) (tcb->m_ssThresh*(segmentsAcked)*(16.664));
	ReduceCwnd (tcb);

}
