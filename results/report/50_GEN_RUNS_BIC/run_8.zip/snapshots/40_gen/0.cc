ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (26.044*(-79.137)*(76.241));
tcb->m_cWnd = (int) (8.199-(-17.094)-(-58.498)-(10.884)-(75.887)-(-9.733)-(-99.194)-(75.95)-(-16.573));
