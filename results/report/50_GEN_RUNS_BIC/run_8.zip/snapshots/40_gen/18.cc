if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (87.806-(96.355));
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(41.93)+(76.444))/((67.513)+(79.856)+(0.1)+(0.1)+(98.052)));

} else {
	tcb->m_segmentSize = (int) (cnt*(27.373)*(28.89)*(69.385)*(cnt)*(3.324));

}
ReduceCwnd (tcb);
if (segmentsAcked >= segmentsAcked) {
	tcb->m_cWnd = (int) (((0.1)+(47.56)+(0.1)+(0.1)+(0.1)+(0.1))/((43.879)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_cWnd)*(59.625)*(10.367)*(96.033)*(cnt)*(87.02)*(54.085));

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(77.85)-(86.987)-(16.634)-(57.236));
	cnt = (int) ((75.76*(24.284)*(25.525)*(6.926)*(tcb->m_segmentSize)*(tcb->m_ssThresh))/0.1);
	tcb->m_segmentSize = (int) (78.327*(25.698)*(55.391)*(87.159)*(87.199)*(73.615)*(87.354)*(80.843)*(27.61));

}
