if (segmentsAcked > segmentsAcked) {
	tcb->m_ssThresh = (int) (55.452-(99.101)-(92.088)-(segmentsAcked)-(87.987)-(45.998));

} else {
	tcb->m_ssThresh = (int) (97.246+(16.038)+(50.569)+(16.501)+(39.57)+(79.765));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_ssThresh*(tcb->m_ssThresh)*(36.073));
tcb->m_ssThresh = (int) (94.219+(11.589)+(6.126)+(27.238)+(tcb->m_cWnd)+(37.145)+(tcb->m_segmentSize));
int cKernumMDoweAvqH = (int) (((69.718)+(0.1)+(0.1)+(41.315))/((76.807)));
