segmentsAcked = (int) (tcb->m_segmentSize+(30.519));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh > cnt) {
	tcb->m_segmentSize = (int) (36.269+(cnt)+(43.941)+(36.663));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (41.591+(90.951));

} else {
	tcb->m_segmentSize = (int) (96.407-(94.122));
	tcb->m_cWnd = (int) (77.214+(96.453));
	cnt = (int) (34.911*(0.458)*(52.788)*(61.054)*(68.181)*(90.039)*(34.207));

}
segmentsAcked = (int) (23.593*(53.516)*(segmentsAcked)*(58.269)*(cnt)*(73.697)*(40.692)*(6.822)*(81.625));
segmentsAcked = (int) (73.209*(91.245));
