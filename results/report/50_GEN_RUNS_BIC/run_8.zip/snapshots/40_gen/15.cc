if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (8.271*(29.885)*(tcb->m_cWnd)*(43.218));
	cnt = (int) (15.393*(68.967)*(5.711));
	tcb->m_ssThresh = (int) (((6.677)+(78.089)+(64.293)+(0.1)+(15.82)+(0.1))/((31.24)+(26.503)));

} else {
	tcb->m_cWnd = (int) (33.316/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
