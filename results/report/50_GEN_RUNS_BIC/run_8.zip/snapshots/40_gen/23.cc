if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize == tcb->m_cWnd) {
	segmentsAcked = (int) (99.72*(73.037)*(2.034)*(segmentsAcked)*(7.496)*(81.808)*(14.092)*(58.098));
	tcb->m_ssThresh = (int) (73.034+(95.079)+(58.62)+(19.71));

} else {
	segmentsAcked = (int) (cnt*(84.095)*(29.326)*(tcb->m_segmentSize)*(42.13)*(10.715)*(19.671)*(22.895));
	tcb->m_cWnd = (int) (27.173+(48.081)+(87.38)+(22.081)+(58.493)+(73.837)+(0.89));
	ReduceCwnd (tcb);

}
int cnIOIecOaaKiRHMO = (int) (68.466-(tcb->m_segmentSize)-(62.954)-(1.657)-(52.004));
ReduceCwnd (tcb);
int NRLynLMuJnuyOKqD = (int) (30.118-(23.48)-(51.043)-(79.906));
