if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (41.873-(45.348)-(29.661)-(84.417)-(0.157)-(31.347)-(77.041)-(31.396)-(25.241));
tcb->m_segmentSize = (int) (49.237/84.918);
tcb->m_cWnd = (int) (cnt+(89.166)+(85.442)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(92.235)+(tcb->m_ssThresh)+(95.486)+(14.863));
tcb->m_cWnd = (int) (39.169+(97.446)+(8.864));
tcb->m_ssThresh = (int) ((((98.73-(11.004)-(13.169)))+(0.1)+(77.163)+(83.162))/((0.1)));
tcb->m_segmentSize = (int) (35.082*(46.385)*(3.027)*(33.976)*(13.835)*(cnt)*(59.98)*(51.863)*(segmentsAcked));
segmentsAcked = (int) (14.985/52.434);
ReduceCwnd (tcb);
