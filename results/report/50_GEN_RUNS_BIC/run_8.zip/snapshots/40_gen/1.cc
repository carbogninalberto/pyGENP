tcb->m_segmentSize = (int) (-68.218*(-70.002)*(4.755)*(-27.356)*(-34.844));
float ErrttzJzfZlqCOKT = (float) (-28.077-(84.491)-(35.382)-(15.431)-(-99.255)-(36.914)-(77.799));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-24.871/35.467);
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.976/77.83);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (85.741-(-48.21)-(45.66)-(78.52));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
