tcb->m_cWnd = (int) (8.832-(93.07)-(tcb->m_segmentSize)-(68.447)-(72.811)-(76.512)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(segmentsAcked));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_ssThresh = (int) (32.236-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(40.778));
	tcb->m_segmentSize = (int) (28.315-(10.991)-(54.093));

} else {
	tcb->m_ssThresh = (int) (87.04-(tcb->m_segmentSize)-(37.077)-(41.798)-(30.935)-(4.69));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_cWnd = (int) (72.129/0.1);
tcb->m_segmentSize = (int) (9.32-(80.062)-(68.027)-(29.1)-(46.689)-(60.913));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > cnt) {
	segmentsAcked = (int) (tcb->m_cWnd-(tcb->m_segmentSize)-(72.846)-(21.278)-(51.069)-(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (8.448-(tcb->m_ssThresh)-(97.053)-(34.908)-(tcb->m_segmentSize)-(tcb->m_segmentSize));
	segmentsAcked = (int) (52.845-(77.136)-(15.34));

} else {
	segmentsAcked = (int) ((61.241*(63.809)*(82.704)*(3.956)*(50.234)*(59.098)*(55.424))/32.915);
	tcb->m_segmentSize = (int) (38.296+(cnt)+(45.695)+(71.998)+(10.847)+(52.656)+(40.613));
	tcb->m_ssThresh = (int) (0.1/30.612);

}
if (cnt < tcb->m_segmentSize) {
	cnt = (int) (94.234-(61.35)-(tcb->m_segmentSize)-(29.783)-(94.657)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(14.916)-(91.64));
	tcb->m_ssThresh = (int) (71.703*(74.334)*(6.128)*(36.1)*(9.12)*(segmentsAcked)*(61.348));

} else {
	cnt = (int) (34.83*(18.26)*(tcb->m_ssThresh)*(25.169)*(tcb->m_cWnd)*(40.999)*(42.839)*(cnt));
	cnt = (int) (4.588+(tcb->m_ssThresh)+(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (66.21-(27.989)-(48.941)-(21.013));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
