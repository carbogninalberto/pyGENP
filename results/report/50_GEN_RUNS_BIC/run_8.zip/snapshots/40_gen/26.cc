ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize > cnt) {
	cnt = (int) (21.55+(60.832)+(43.984)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(57.481)+(54.436)+(49.914)+(tcb->m_cWnd));
	cnt = (int) (27.091-(91.182)-(33.914)-(74.105)-(68.61)-(52.152)-(40.323)-(9.719)-(60.242));
	tcb->m_ssThresh = (int) (81.987-(82.029)-(98.434));

} else {
	cnt = (int) (((47.747)+(0.1)+(0.1)+(90.95)+(21.957))/((39.767)));
	tcb->m_segmentSize = (int) (0.1/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
