if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (21.015/(21.971*(13.506)*(47.436)*(58.703)*(tcb->m_ssThresh)*(62.342)*(9.59)*(22.472)));
segmentsAcked = (int) (tcb->m_segmentSize-(4.892)-(80.544)-(2.372)-(32.507));
cnt = (int) (76.427/24.758);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (95.237+(4.516)+(28.028)+(2.342));
tcb->m_cWnd = (int) (0.1/7.808);
