segmentsAcked = (int) (45.115*(87.676)*(tcb->m_ssThresh)*(50.488)*(26.589)*(54.629)*(47.62)*(cnt)*(81.342));
int gOKRUnuAPYhEsvCN = (int) ((93.508*(30.86)*(segmentsAcked)*(81.086)*(80.308))/0.1);
ReduceCwnd (tcb);
cnt = (int) (((0.1)+((77.427-(82.142)-(13.873)-(tcb->m_segmentSize)-(cnt)-(tcb->m_segmentSize)-(51.851)-(34.368)-(13.135)))+((10.224*(11.501)*(72.247)*(9.247)*(55.844)*(95.001)*(37.327)*(60.519)*(42.767)))+(0.1)+(0.1))/((0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (53.506-(59.817)-(70.616)-(3.283)-(4.985));
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_cWnd = (int) (12.02-(78.394)-(32.181));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (31.919+(7.429)+(tcb->m_cWnd)+(gOKRUnuAPYhEsvCN)+(50.86));

}
cnt = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(0.1)+(0.1))/((33.754)+(0.1)+(0.1)));
tcb->m_segmentSize = (int) (81.123+(7.566)+(41.976)+(94.904)+(25.683)+(80.486)+(86.197));
