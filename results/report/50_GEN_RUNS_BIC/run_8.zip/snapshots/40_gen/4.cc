tcb->m_segmentSize = (int) (7.22*(26.586)*(68.353)*(-63.776)*(-47.389));
int GNvTlDwuaUjNRhom = (int) (87.669*(19.3)*(55.147)*(60.814)*(-36.787)*(-1.065)*(-81.13)*(-92.715)*(41.685));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-72.347*(85.947)*(30.643)*(-46.899)*(33.07));
tcb->m_cWnd = (int) (-2.529/-61.859);
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.976/77.83);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (85.741-(42.417)-(45.66)-(78.52));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-50.341/-82.025);
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.976/77.83);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (85.741-(-47.872)-(45.66)-(78.52));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
