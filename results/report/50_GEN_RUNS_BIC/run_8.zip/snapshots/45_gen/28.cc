tcb->m_segmentSize = (int) (53.642+(50.385)+(87.678)+(98.413)+(tcb->m_ssThresh));
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(48.313)+(63.38)+(38.258)+(92.092)+(29.655));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (tcb->m_ssThresh-(96.395)-(19.866));

} else {
	tcb->m_segmentSize = (int) (cnt+(24.759));
	segmentsAcked = (int) (46.415+(87.451));
	tcb->m_segmentSize = (int) (42.309*(cnt)*(94.962)*(segmentsAcked)*(51.079)*(38.457)*(64.928)*(cnt));

}
tcb->m_ssThresh = (int) (76.941/0.1);
if (cnt != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((0.1)+(26.001)+(55.873)+(0.1)+(0.1)+(0.1))/((0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (42.736-(segmentsAcked)-(16.924)-(tcb->m_ssThresh)-(segmentsAcked)-(70.274)-(90.93));
	ReduceCwnd (tcb);

}
