ReduceCwnd (tcb);
if (cnt != cnt) {
	tcb->m_ssThresh = (int) (83.412-(45.691)-(39.691)-(tcb->m_cWnd)-(tcb->m_segmentSize)-(60.434));
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(tcb->m_segmentSize)+(segmentsAcked)+(6.171)+(38.56)+(89.956)+(92.736)+(93.472)+(41.911));

}
segmentsAcked = (int) (42.747-(28.009)-(tcb->m_ssThresh)-(75.891)-(63.161));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt <= tcb->m_ssThresh) {
	cnt = (int) (17.294*(34.83)*(segmentsAcked)*(38.811)*(17.75)*(tcb->m_cWnd)*(16.102)*(30.988));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (60.756+(tcb->m_ssThresh)+(87.145)+(segmentsAcked)+(cnt));

} else {
	cnt = (int) (48.56*(27.687)*(94.602)*(74.982)*(61.71)*(tcb->m_segmentSize)*(53.451)*(91.039)*(6.711));
	tcb->m_cWnd = (int) (53.617*(tcb->m_cWnd)*(20.11)*(57.084));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
