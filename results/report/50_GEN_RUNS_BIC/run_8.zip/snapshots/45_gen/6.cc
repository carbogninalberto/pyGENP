tcb->m_cWnd = (int) (tcb->m_cWnd+(87.639));
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (25.807+(tcb->m_segmentSize)+(49.281));
	cnt = (int) (97.452/32.255);
	cnt = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (3.648-(33.573)-(94.257)-(79.703)-(36.631));
	tcb->m_ssThresh = (int) (72.327+(40.464)+(30.432));
	tcb->m_cWnd = (int) (15.148+(78.462)+(19.569)+(66.841));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (86.266*(84.038)*(cnt));
tcb->m_segmentSize = (int) (82.363*(50.743)*(81.921));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (22.68-(57.542)-(89.32)-(segmentsAcked)-(7.643)-(90.312)-(tcb->m_segmentSize)-(19.46)-(49.656));
