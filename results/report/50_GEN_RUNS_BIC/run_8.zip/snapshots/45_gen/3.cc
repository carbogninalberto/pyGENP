if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/(95.985-(77.799)));

} else {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(45.263));
	segmentsAcked = (int) (tcb->m_segmentSize*(41.936)*(tcb->m_segmentSize)*(23.37)*(tcb->m_cWnd)*(9.292)*(3.708)*(82.049));

}
segmentsAcked = (int) (20.57*(85.368)*(29.02));
if (cnt >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (94.68+(0.451)+(67.409)+(14.041)+(50.248)+(tcb->m_segmentSize));
	cnt = (int) (61.809*(segmentsAcked)*(44.966)*(segmentsAcked)*(tcb->m_cWnd)*(92.563)*(17.855)*(93.304));

} else {
	tcb->m_segmentSize = (int) (62.228-(86.022)-(54.327)-(87.994)-(25.73)-(40.818)-(62.211));

}
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (18.141+(80.391)+(61.838)+(29.124));

} else {
	tcb->m_segmentSize = (int) (99.718+(31.778));

}
tcb->m_cWnd = (int) (tcb->m_cWnd+(18.44)+(38.999)+(tcb->m_segmentSize)+(80.383)+(24.62)+(tcb->m_cWnd));
tcb->m_segmentSize = (int) (tcb->m_ssThresh*(25.037)*(62.128)*(85.075)*(tcb->m_segmentSize)*(30.197)*(15.754)*(segmentsAcked));
