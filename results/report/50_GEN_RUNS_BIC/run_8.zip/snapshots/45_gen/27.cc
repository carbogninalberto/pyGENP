tcb->m_cWnd = (int) (segmentsAcked-(61.005)-(19.904));
tcb->m_cWnd = (int) (16.83+(tcb->m_ssThresh)+(78.861)+(10.539)+(98.951)+(63.372)+(tcb->m_ssThresh)+(36.27)+(83.417));
tcb->m_ssThresh = (int) (((0.1)+(17.048)+(26.799)+(0.1))/((0.1)+(0.1)));
cnt = (int) (tcb->m_cWnd*(21.634)*(tcb->m_segmentSize)*(45.787)*(5.368)*(8.101)*(cnt)*(tcb->m_cWnd));
cnt = (int) (66.439+(53.788));
if (cnt <= segmentsAcked) {
	tcb->m_segmentSize = (int) (97.613-(91.056)-(12.143)-(72.756)-(36.366)-(82.764)-(11.547)-(tcb->m_segmentSize));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (96.868-(58.258)-(58.636));

}
ReduceCwnd (tcb);
