tcb->m_segmentSize = (int) (66.679*(4.812));
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (68.198/35.591);
	tcb->m_segmentSize = (int) (60.28*(13.982)*(99.805));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(78.705)+(16.009)+(50.074)+(97.167));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (segmentsAcked == cnt) {
	tcb->m_cWnd = (int) (29.617-(47.313)-(36.687)-(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (68.385-(31.369)-(65.156));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(40.148));

}
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.752*(5.241)*(63.241)*(84.959));

} else {
	tcb->m_cWnd = (int) (((0.1)+(21.55)+(75.171)+(0.1)+(0.1)+(0.1))/((0.1)+(59.946)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (39.704+(96.562)+(tcb->m_cWnd)+(72.758)+(10.547)+(48.674)+(43.705)+(74.29));
	segmentsAcked = (int) ((47.808+(65.419))/94.974);

} else {
	tcb->m_ssThresh = (int) (93.565*(92.426)*(13.504)*(55.633)*(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
