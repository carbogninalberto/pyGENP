tcb->m_ssThresh = (int) (0.1/93.391);
if (cnt > tcb->m_cWnd) {
	segmentsAcked = (int) (97.208+(0.217)+(66.111)+(77.223)+(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (93.904-(36.741)-(cnt)-(segmentsAcked));
	segmentsAcked = (int) (25.116-(25.722));

}
tcb->m_cWnd = (int) (32.071-(97.855));
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (58.324+(tcb->m_ssThresh)+(83.489)+(tcb->m_cWnd)+(78.366)+(0.466));

} else {
	tcb->m_cWnd = (int) (((0.1)+((92.35*(22.102)))+(0.1)+(0.1)+(0.1)+((tcb->m_cWnd+(3.866)+(tcb->m_segmentSize)))+((29.527+(18.571)+(9.518)+(tcb->m_cWnd)+(44.164)+(82.31)))+(0.1))/((0.1)));
	tcb->m_cWnd = (int) (cnt*(41.59)*(87.739)*(tcb->m_ssThresh)*(39.574));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (88.688-(20.616)-(45.367)-(19.927)-(38.293)-(67.892)-(30.869)-(57.403));
int PCcrGYdRWfLUJlIL = (int) (tcb->m_segmentSize-(15.016)-(2.401));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (35.092-(58.362)-(cnt));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (56.742-(81.611)-(89.245)-(87.556)-(45.343)-(61.853)-(39.981)-(90.833)-(11.948));

} else {
	tcb->m_ssThresh = (int) (10.171+(91.64)+(64.615)+(tcb->m_segmentSize)+(75.28)+(78.63)+(tcb->m_cWnd));
	segmentsAcked = (int) (88.24-(6.932)-(tcb->m_segmentSize));

}
if (tcb->m_ssThresh != tcb->m_cWnd) {
	segmentsAcked = (int) (52.583*(93.698)*(PCcrGYdRWfLUJlIL)*(21.626));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (65.07+(cnt)+(43.384)+(97.791)+(55.755)+(91.571)+(92.658)+(75.123)+(93.974));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh*(cnt)*(58.408)*(45.701)*(segmentsAcked)*(48.8)*(19.591)*(54.761)*(42.253));
	PCcrGYdRWfLUJlIL = (int) (78.284-(PCcrGYdRWfLUJlIL)-(20.166)-(22.261)-(tcb->m_cWnd)-(84.368));
	tcb->m_segmentSize = (int) (PCcrGYdRWfLUJlIL*(88.279)*(segmentsAcked)*(82.117)*(PCcrGYdRWfLUJlIL)*(PCcrGYdRWfLUJlIL)*(46.446)*(76.791));

}
segmentsAcked = (int) ((((65.663*(70.561)*(53.732)*(6.606)*(12.973)*(67.853)*(79.135)))+(0.1)+(0.1)+(0.1))/((54.408)+(0.1)));
