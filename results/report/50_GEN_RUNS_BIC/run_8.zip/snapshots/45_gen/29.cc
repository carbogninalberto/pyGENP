if (tcb->m_ssThresh >= cnt) {
	tcb->m_cWnd = (int) (cnt+(20.222)+(25.394)+(cnt));

} else {
	tcb->m_cWnd = (int) (64.475*(tcb->m_cWnd)*(29.719)*(83.819)*(30.511)*(51.58));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (95.125*(82.544)*(83.951)*(3.28)*(13.813)*(73.134)*(57.687)*(59.112));

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(70.342)+(cnt));
if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (22.661*(16.609)*(43.744)*(61.129)*(52.944));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (44.318-(22.689)-(8.356)-(23.52)-(segmentsAcked)-(33.306)-(19.868)-(91.122));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (((0.1)+(17.704)+(85.05)+(79.583)+(0.1)+(0.1))/((51.245)+(96.579)));
