if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (17.176/0.1);
if (segmentsAcked <= cnt) {
	cnt = (int) (86.438-(1.657)-(93.348)-(68.839)-(7.653));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) ((55.737-(81.516)-(59.588)-(82.365)-(79.768)-(56.13))/39.964);

} else {
	cnt = (int) (((0.1)+(72.829)+(0.1)+(0.1)+(89.779)+(0.1))/((39.643)+(0.1)+(0.1)));

}
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (70.062+(16.3)+(1.816)+(tcb->m_ssThresh)+(90.817)+(88.443));
	tcb->m_segmentSize = (int) ((57.79+(51.065)+(78.677)+(23.474)+(28.086))/0.1);

} else {
	tcb->m_segmentSize = (int) (40.044+(79.768)+(22.215)+(54.715)+(84.734)+(16.566)+(57.014));
	tcb->m_cWnd = (int) (((60.567)+(71.175)+(74.72)+(48.453))/((61.127)+(67.711)+(58.066)));

}
if (tcb->m_cWnd < tcb->m_ssThresh) {
	cnt = (int) (1.801-(12.06)-(94.29)-(5.92)-(62.683)-(1.105)-(33.7));

} else {
	cnt = (int) (((0.1)+(73.335)+((53.126+(tcb->m_cWnd)+(18.782)+(tcb->m_segmentSize)+(3.654)))+(53.915))/((0.1)));

}
float srDNPSpXEXpEqrnu = (float) (10.799+(81.146)+(segmentsAcked)+(70.77));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (41.462/0.1);
tcb->m_ssThresh = (int) (37.267+(srDNPSpXEXpEqrnu));
