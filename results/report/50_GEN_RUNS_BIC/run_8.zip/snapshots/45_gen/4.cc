int gaDNKpfCPrUjeiGk = (int) (61.142*(97.834)*(27.65)*(94.152)*(segmentsAcked)*(34.482));
int YbgRvGyhoUhmFNEf = (int) (((0.1)+((16.532+(26.687)+(segmentsAcked)+(42.236)+(57.695)+(20.55)+(5.619)+(20.753)))+((54.674*(49.887)*(14.912)*(tcb->m_ssThresh)*(32.467)*(26.962)*(cnt)*(23.459)*(segmentsAcked)))+(0.1)+(0.1)+(74.243)+(34.676))/((0.1)));
if (segmentsAcked < YbgRvGyhoUhmFNEf) {
	tcb->m_segmentSize = (int) (6.944*(gaDNKpfCPrUjeiGk)*(38.489)*(57.656)*(tcb->m_ssThresh)*(98.737)*(35.626)*(41.826));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (30.395*(26.241)*(88.438));

}
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((36.761+(gaDNKpfCPrUjeiGk)+(cnt)+(29.512)+(25.677)+(87.803))/97.308);
	segmentsAcked = (int) (9.726*(cnt)*(48.821));
	tcb->m_ssThresh = (int) (36.616-(17.848)-(32.649)-(56.141)-(YbgRvGyhoUhmFNEf)-(77.094)-(83.383));

} else {
	tcb->m_segmentSize = (int) (88.528*(54.563)*(78.83)*(tcb->m_ssThresh)*(13.545)*(15.24)*(segmentsAcked)*(11.842)*(87.217));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked < YbgRvGyhoUhmFNEf) {
	cnt = (int) (83.355+(83.81)+(gaDNKpfCPrUjeiGk)+(45.356)+(46.96));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	cnt = (int) (33.904-(16.401)-(20.636)-(58.519)-(94.339)-(97.373));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked >= cnt) {
	YbgRvGyhoUhmFNEf = (int) (30.979*(5.412)*(gaDNKpfCPrUjeiGk)*(5.158)*(99.453)*(tcb->m_ssThresh)*(92.569));

} else {
	YbgRvGyhoUhmFNEf = (int) (((99.053)+(0.1)+(48.479)+(21.503)+(58.741))/((0.1)));
	segmentsAcked = (int) (0.1/76.881);
	segmentsAcked = (int) (15.477*(cnt)*(45.523)*(27.855)*(tcb->m_ssThresh)*(2.547)*(26.498)*(tcb->m_ssThresh)*(98.618));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
