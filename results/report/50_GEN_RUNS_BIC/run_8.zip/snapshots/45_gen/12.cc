cnt = (int) (0.1/0.1);
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (80.374-(24.687)-(tcb->m_segmentSize)-(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (76.345-(tcb->m_ssThresh)-(66.199)-(42.97)-(26.326)-(cnt)-(tcb->m_cWnd));
	segmentsAcked = (int) (21.339-(23.924)-(58.363));

}
if (tcb->m_cWnd != tcb->m_cWnd) {
	segmentsAcked = (int) (28.643*(tcb->m_segmentSize)*(10.376)*(94.656)*(97.466));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (7.32+(43.114)+(20.201)+(8.715)+(25.483)+(14.705)+(22.768)+(26.295));
	tcb->m_cWnd = (int) (cnt+(84.958)+(43.235));

}
if (cnt != tcb->m_segmentSize) {
	cnt = (int) (83.155-(64.633)-(84.083)-(5.679)-(9.464)-(60.706)-(48.211)-(40.368)-(28.579));
	tcb->m_segmentSize = (int) (38.53+(0.428)+(1.263)+(73.02)+(56.561)+(12.035)+(segmentsAcked)+(77.14));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (((0.1)+((cnt*(tcb->m_segmentSize)*(tcb->m_cWnd)*(10.329)))+((3.226*(tcb->m_segmentSize)*(28.326)*(56.535)*(cnt)*(71.202)*(47.952)*(6.683)))+(0.1)+((22.663*(tcb->m_ssThresh)*(42.514)*(78.653)*(47.27)*(12.917)*(64.522)))+(19.854))/((70.81)+(0.1)));

}
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (42.201*(98.928)*(tcb->m_cWnd)*(cnt)*(tcb->m_ssThresh)*(11.065)*(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (98.816+(80.546)+(89.126)+(76.087)+(28.21));
	tcb->m_cWnd = (int) (27.921+(tcb->m_cWnd)+(11.332)+(tcb->m_cWnd)+(30.184)+(98.397)+(tcb->m_cWnd)+(6.307));
	tcb->m_ssThresh = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh > segmentsAcked) {
	cnt = (int) (84.369+(65.245)+(cnt)+(cnt));
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(61.294)-(56.242)-(segmentsAcked)-(tcb->m_cWnd)-(87.653)-(21.074)-(tcb->m_segmentSize)-(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (cnt*(64.299)*(tcb->m_ssThresh)*(2.507));
	ReduceCwnd (tcb);

}
