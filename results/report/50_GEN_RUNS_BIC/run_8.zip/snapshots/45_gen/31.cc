if (cnt == segmentsAcked) {
	cnt = (int) (13.857+(43.988)+(10.855)+(86.855)+(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (tcb->m_segmentSize*(95.422)*(87.812)*(59.587)*(4.049));

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) ((((80.567+(53.586)+(22.053)+(tcb->m_segmentSize)+(92.47)+(tcb->m_cWnd)+(41.936)+(tcb->m_cWnd)+(1.782)))+(50.724)+(94.988)+(0.1))/((9.087)+(0.1)+(0.1)+(0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh > cnt) {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(97.381)+(15.805)+(32.872))/((0.1)));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (93.589*(86.339)*(84.097)*(0.08));

} else {
	segmentsAcked = (int) (81.186*(72.03));
	tcb->m_ssThresh = (int) (95.662+(50.608)+(26.814)+(46.693));
	tcb->m_ssThresh = (int) (33.274+(59.663));

}
