if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(11.669)+(14.657)+(48.975)+(57.335)+(65.699));
	tcb->m_ssThresh = (int) (82.77-(5.613)-(69.359)-(3.064)-(33.088)-(82.499));
	cnt = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (93.094-(tcb->m_ssThresh)-(segmentsAcked)-(41.455)-(2.951)-(54.833)-(96.17));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float wyRBIlXATBNGrxUL = (float) ((tcb->m_segmentSize-(71.238)-(cnt)-(50.306)-(tcb->m_segmentSize))/(tcb->m_ssThresh-(tcb->m_cWnd)-(61.016)-(51.925)-(29.664)-(82.932)-(segmentsAcked)-(25.378)-(78.845)));
ReduceCwnd (tcb);
if (wyRBIlXATBNGrxUL > wyRBIlXATBNGrxUL) {
	tcb->m_segmentSize = (int) (99.239+(segmentsAcked)+(40.611)+(80.032));
	segmentsAcked = (int) (87.692+(86.052)+(73.648)+(28.983)+(15.929)+(63.107));

} else {
	tcb->m_segmentSize = (int) (82.212+(11.375)+(28.809)+(96.205)+(50.158)+(22.114)+(26.4)+(62.16)+(88.721));

}
segmentsAcked = (int) (29.201+(79.949)+(42.764)+(tcb->m_cWnd)+(tcb->m_ssThresh));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	wyRBIlXATBNGrxUL = (float) (11.931*(1.193)*(58.5)*(7.808)*(13.859)*(6.03));
	wyRBIlXATBNGrxUL = (float) (81.342+(71.606)+(54.855)+(11.906)+(segmentsAcked)+(46.059)+(segmentsAcked)+(84.346));
	tcb->m_ssThresh = (int) (2.668*(98.092)*(82.389)*(90.047)*(tcb->m_cWnd)*(95.697)*(45.765));

} else {
	wyRBIlXATBNGrxUL = (float) (74.567*(34.107)*(92.94)*(24.365));
	wyRBIlXATBNGrxUL = (float) (cnt*(26.396)*(19.48)*(15.11)*(95.872));

}
