float dOCfyNLQYRgTMuwp = (float) (tcb->m_ssThresh*(15.426)*(26.193)*(65.716)*(60.57)*(54.651)*(72.566));
tcb->m_ssThresh = (int) (32.494-(72.386)-(83.826));
cnt = (int) (((0.1)+(0.1)+((72.836*(14.225)*(58.94)*(82.685)*(79.682)*(73.979)*(segmentsAcked)*(20.165)))+(94.51))/((69.564)));
float mFnmCtejGEGegcOn = (float) (75.392*(86.855)*(1.22)*(tcb->m_segmentSize));
if (dOCfyNLQYRgTMuwp <= mFnmCtejGEGegcOn) {
	segmentsAcked = (int) (99.713*(17.323)*(26.982));
	tcb->m_ssThresh = (int) (91.28*(tcb->m_cWnd)*(segmentsAcked)*(54.809)*(1.176)*(83.931)*(30.421)*(33.419));

} else {
	segmentsAcked = (int) (26.511+(3.848)+(segmentsAcked)+(23.298)+(9.704)+(93.569)+(43.025)+(53.638));
	tcb->m_cWnd = (int) (42.394-(73.766)-(12.181)-(67.391)-(97.991)-(20.491)-(64.334)-(tcb->m_segmentSize));
	cnt = (int) (56.923-(76.474)-(84.689));

}
tcb->m_cWnd = (int) (16.713/0.1);
