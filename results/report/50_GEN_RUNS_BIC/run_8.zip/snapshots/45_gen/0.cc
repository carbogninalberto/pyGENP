int qXUZyHBLUUEcMUGX = (int) (-7.685+(-62.581)+(96.721));
