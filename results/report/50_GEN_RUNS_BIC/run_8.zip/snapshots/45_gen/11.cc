if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (64.083*(tcb->m_segmentSize)*(70.936)*(9.635)*(72.205)*(99.659));
	cnt = (int) (tcb->m_cWnd+(23.894)+(10.877)+(4.805)+(48.991)+(30.008)+(46.075)+(62.315)+(33.222));

} else {
	tcb->m_ssThresh = (int) (9.179/(2.942-(73.641)-(tcb->m_cWnd)-(tcb->m_cWnd)-(97.831)-(70.948)-(tcb->m_ssThresh)-(32.26)-(30.537)));
	tcb->m_cWnd = (int) (tcb->m_cWnd-(42.93)-(0.795)-(tcb->m_ssThresh)-(78.381)-(3.308)-(tcb->m_segmentSize)-(49.874));

}
tcb->m_cWnd = (int) (16.774-(79.078)-(68.485)-(tcb->m_segmentSize)-(segmentsAcked));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (51.332-(tcb->m_cWnd)-(94.205)-(tcb->m_cWnd)-(72.082)-(8.924)-(55.607)-(78.978));
	tcb->m_ssThresh = (int) (66.848+(41.656)+(68.225)+(segmentsAcked)+(tcb->m_segmentSize)+(26.723)+(70.119));

} else {
	tcb->m_cWnd = (int) (72.901*(61.184)*(40.909)*(tcb->m_cWnd)*(77.486)*(tcb->m_ssThresh)*(73.366)*(21.576)*(segmentsAcked));

}
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_segmentSize = (int) (86.535+(45.352)+(61.989)+(51.616)+(40.98));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (49.218-(88.194)-(78.666)-(21.051)-(16.462)-(7.972));

} else {
	tcb->m_segmentSize = (int) (3.036-(7.014)-(91.756)-(15.099)-(29.034)-(20.077)-(61.631)-(cnt));
	segmentsAcked = (int) (8.169*(77.725)*(61.764)*(92.439)*(99.361)*(49.319)*(64.98)*(62.535));
	cnt = (int) (29.33+(36.476)+(92.091)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(28.691)+(67.828)+(98.854));

}
ReduceCwnd (tcb);
