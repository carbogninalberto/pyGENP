tcb->m_cWnd = (int) (28.249-(36.399)-(15.516)-(94.82)-(97.719)-(97.405)-(17.144));
if (segmentsAcked != cnt) {
	cnt = (int) (0.26*(34.945)*(22.843)*(48.585)*(10.537));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (27.777*(86.029)*(89.095)*(50.448)*(68.772)*(45.059));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float aYSrYEoZRIMwAMaY = (float) (cnt-(segmentsAcked)-(tcb->m_ssThresh)-(43.545)-(77.494)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(61.118)-(27.306));
cnt = (int) (52.453-(1.427)-(aYSrYEoZRIMwAMaY)-(2.139)-(84.533)-(90.76)-(23.117));
segmentsAcked = (int) (75.738*(87.309)*(73.971)*(57.503)*(15.262));
