float hyxTAnFaxlkAbAsE = (float) (44.282*(cnt)*(27.84)*(60.663)*(73.732)*(44.625)*(61.092)*(88.084));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (0.1/1.847);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (29.251-(tcb->m_cWnd)-(5.875)-(3.998)-(12.743)-(34.577)-(62.952)-(73.592)-(2.796));
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= hyxTAnFaxlkAbAsE) {
	tcb->m_segmentSize = (int) (91.392*(tcb->m_cWnd)*(24.639)*(27.181));

} else {
	tcb->m_segmentSize = (int) ((65.815*(35.104)*(tcb->m_ssThresh)*(48.047)*(48.472)*(16.592))/32.079);

}
ReduceCwnd (tcb);
