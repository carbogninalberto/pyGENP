tcb->m_segmentSize = (int) (0.1/79.089);
ReduceCwnd (tcb);
if (segmentsAcked >= tcb->m_ssThresh) {
	cnt = (int) (57.542*(7.797)*(78.019)*(44.21)*(75.678)*(cnt));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (2.278+(46.133)+(cnt)+(cnt)+(94.0));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (58.139/10.964);
	segmentsAcked = (int) (((55.633)+(0.1)+(0.1)+((37.448-(cnt)-(25.817)-(3.993)-(95.938)))+(0.1)+(0.1))/((73.487)));
	segmentsAcked = (int) (66.475*(tcb->m_segmentSize)*(50.975)*(11.676)*(33.944)*(80.686)*(18.687)*(40.798));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (71.776+(51.862)+(20.702)+(tcb->m_segmentSize)+(segmentsAcked));
