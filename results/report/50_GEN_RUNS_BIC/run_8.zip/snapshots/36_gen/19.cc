ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (50.999*(segmentsAcked)*(15.591)*(38.451)*(13.581)*(segmentsAcked)*(69.339)*(tcb->m_ssThresh));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (78.226*(21.695)*(26.695)*(71.187)*(34.692)*(57.105)*(6.594)*(15.25));

}
float uKjYyxykUBEdCxRl = (float) (68.905+(1.017)+(77.617)+(56.324)+(65.149)+(33.761));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
int VeMehRAJHtTANvZe = (int) (0.1/34.266);
if (segmentsAcked != tcb->m_segmentSize) {
	cnt = (int) (1.172+(18.452));

} else {
	cnt = (int) (69.184*(cnt));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (57.699*(uKjYyxykUBEdCxRl)*(37.86)*(15.694)*(VeMehRAJHtTANvZe));

}
