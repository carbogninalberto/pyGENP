if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (cnt*(30.246)*(31.648)*(8.457)*(45.666)*(9.375));
	tcb->m_ssThresh = (int) (18.541/65.263);
	tcb->m_ssThresh = (int) (((43.402)+((52.204-(7.947)-(15.009)-(64.91)-(57.146)-(68.413)-(55.801)-(69.614)-(tcb->m_ssThresh)))+(0.1)+(53.115))/((0.1)+(0.1)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (77.633-(1.775));
	tcb->m_ssThresh = (int) (29.33-(26.258)-(51.855)-(tcb->m_cWnd)-(40.78)-(5.516));
	ReduceCwnd (tcb);

}
if (segmentsAcked != segmentsAcked) {
	tcb->m_cWnd = (int) (((83.836)+(0.1)+(4.73)+(0.1)+(0.1))/((0.1)+(0.1)));
	segmentsAcked = (int) (89.537-(84.57)-(68.26));

} else {
	tcb->m_cWnd = (int) (37.005+(7.495)+(77.824)+(tcb->m_segmentSize)+(15.954)+(57.906)+(60.826)+(tcb->m_segmentSize)+(tcb->m_ssThresh));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (37.182*(8.816)*(41.685)*(69.675)*(tcb->m_cWnd)*(29.501)*(85.674)*(tcb->m_segmentSize)*(segmentsAcked));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
