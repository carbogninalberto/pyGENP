if (cnt >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((0.1)+(22.671)+(0.1)+(0.1)+(26.684)+(17.647))/((76.381)+(60.469)+(4.826)));
	segmentsAcked = (int) (81.365+(88.177));

} else {
	tcb->m_ssThresh = (int) (27.261+(97.802)+(2.852)+(79.714)+(75.82));
	cnt = (int) (segmentsAcked+(67.216)+(34.456)+(43.496)+(23.221));

}
tcb->m_segmentSize = (int) (61.299-(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
cnt = (int) (82.51-(63.166));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (72.638-(94.609)-(tcb->m_cWnd)-(75.332)-(segmentsAcked)-(53.056)-(14.895));
segmentsAcked = (int) (69.353+(88.345)+(43.068)+(34.945)+(27.143)+(62.793));
