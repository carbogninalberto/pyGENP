ReduceCwnd (tcb);
float GhLZUmdjbLSRctKZ = (float) (49.303+(48.385)+(28.221)+(74.56)+(34.241)+(tcb->m_cWnd)+(17.341)+(23.695));
GhLZUmdjbLSRctKZ = (float) (0.1/43.109);
segmentsAcked = (int) (75.423*(7.367));
ReduceCwnd (tcb);
