if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float PhLRklxJdtYSTREu = (float) (78.467+(tcb->m_cWnd)+(96.163)+(35.974)+(43.433));
ReduceCwnd (tcb);
if (tcb->m_segmentSize == cnt) {
	tcb->m_ssThresh = (int) (74.324-(4.106)-(26.502)-(29.496)-(50.011)-(56.39)-(87.651)-(4.507)-(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (43.12-(42.474)-(45.635)-(PhLRklxJdtYSTREu));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (25.608/0.1);
