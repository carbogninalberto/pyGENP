if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_cWnd = (int) (65.905-(27.422));

} else {
	tcb->m_cWnd = (int) (1.525-(80.845)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(52.095)-(53.28)-(11.815)-(99.739)-(65.476));

}
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (cnt-(7.646));

} else {
	tcb->m_cWnd = (int) (0.1/67.736);

}
if (tcb->m_segmentSize != segmentsAcked) {
	segmentsAcked = (int) (42.128*(33.609)*(32.643)*(61.953)*(57.996));
	tcb->m_cWnd = (int) (26.175*(20.286));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (76.07*(7.352)*(48.174)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(39.794)*(tcb->m_ssThresh)*(57.453));
	tcb->m_cWnd = (int) (0.1/16.182);

}
segmentsAcked = (int) (44.588-(32.326));
