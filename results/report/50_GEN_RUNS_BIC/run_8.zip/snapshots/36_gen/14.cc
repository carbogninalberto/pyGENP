if (tcb->m_cWnd > segmentsAcked) {
	cnt = (int) (7.805*(82.404)*(89.693)*(76.752)*(42.557));
	cnt = (int) (72.933-(46.909)-(59.742)-(55.106));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(tcb->m_cWnd)+(92.814)+(59.868)+(23.631)+(tcb->m_cWnd)+(93.24)+(6.12));

} else {
	cnt = (int) (86.116*(56.565)*(35.726)*(86.508)*(segmentsAcked)*(6.398)*(13.04)*(87.324));
	cnt = (int) (tcb->m_cWnd+(91.391)+(11.787));

}
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (48.404-(21.361));
	tcb->m_cWnd = (int) (68.964-(55.135)-(4.743)-(cnt)-(tcb->m_ssThresh)-(77.383));
	tcb->m_cWnd = (int) ((((16.487-(56.238)-(82.406)-(84.602)-(18.572)-(tcb->m_cWnd)-(16.991)-(98.886)-(98.591)))+((segmentsAcked+(28.428)+(76.005)+(tcb->m_segmentSize)+(segmentsAcked)+(94.42)+(4.509)+(80.183)))+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(20.165)));

} else {
	tcb->m_ssThresh = (int) (10.212*(54.801));
	cnt = (int) (1.53-(8.475)-(26.492)-(63.613)-(tcb->m_ssThresh)-(54.545)-(cnt)-(6.59));

}
cnt = (int) (34.312-(32.571)-(72.139)-(segmentsAcked)-(29.35)-(segmentsAcked)-(segmentsAcked)-(67.757));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
