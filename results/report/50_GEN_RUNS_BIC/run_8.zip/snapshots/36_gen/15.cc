if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (45.18+(cnt)+(segmentsAcked)+(33.524)+(tcb->m_cWnd)+(0.136));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (51.86*(tcb->m_segmentSize)*(21.034)*(18.299)*(57.884)*(28.526)*(49.889));
