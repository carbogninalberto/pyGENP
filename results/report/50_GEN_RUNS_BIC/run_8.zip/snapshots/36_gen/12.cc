if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_ssThresh = (int) (9.257+(43.024)+(72.985)+(tcb->m_segmentSize)+(59.699)+(tcb->m_ssThresh)+(35.028));
	tcb->m_segmentSize = (int) (14.71+(78.375)+(1.492)+(75.866)+(28.222));

} else {
	tcb->m_ssThresh = (int) (32.685-(1.669)-(30.571)-(67.206)-(63.189)-(segmentsAcked)-(23.628)-(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (39.204-(94.377)-(42.996)-(66.725)-(87.326)-(82.892)-(51.149)-(tcb->m_cWnd));
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_segmentSize = (int) (0.1/82.358);
	tcb->m_ssThresh = (int) (cnt*(tcb->m_segmentSize)*(18.9)*(43.669));

} else {
	tcb->m_segmentSize = (int) (38.405*(20.694)*(91.79)*(8.351)*(37.843)*(43.027)*(35.94));
	tcb->m_cWnd = (int) (61.617+(76.316)+(4.86)+(tcb->m_ssThresh)+(segmentsAcked)+(44.76)+(2.937)+(32.045));
	tcb->m_cWnd = (int) (80.885+(16.45)+(51.648)+(36.351)+(segmentsAcked)+(60.163));

}
ReduceCwnd (tcb);
