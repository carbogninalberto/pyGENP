if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (25.336/54.435);
	segmentsAcked = (int) (52.899*(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (cnt-(82.443)-(tcb->m_ssThresh)-(cnt)-(25.699)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (13.55+(44.994));

}
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_ssThresh+(tcb->m_segmentSize)+(42.838));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (57.026-(73.151));

} else {
	segmentsAcked = (int) (segmentsAcked-(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((0.1)+((10.518*(tcb->m_segmentSize)))+(31.415)+(0.1))/((98.595)+(24.715)));
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(43.777)+((50.612*(60.846)*(73.374)))+(84.069)+((36.769-(68.004)-(85.523)-(43.527)-(77.704)))+(24.07))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (31.421-(61.872)-(60.954)-(75.646)-(79.666)-(tcb->m_cWnd)-(34.856));
	segmentsAcked = (int) (14.668*(32.06)*(77.197));

}
