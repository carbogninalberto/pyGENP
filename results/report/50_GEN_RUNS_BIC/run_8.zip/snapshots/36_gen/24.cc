if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (70.518+(77.508)+(77.221)+(60.806)+(25.249));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
float NQUxAEWqFctSyJll = (float) (66.937/0.1);
NQUxAEWqFctSyJll = (float) (53.23*(95.869)*(92.826)*(99.117)*(81.309)*(62.816)*(17.847));
ReduceCwnd (tcb);
