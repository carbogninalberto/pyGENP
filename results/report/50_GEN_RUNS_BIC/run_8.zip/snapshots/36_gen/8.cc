if (segmentsAcked >= segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked-(89.773)-(19.982)-(58.678)-(28.407)-(6.333)-(segmentsAcked)-(cnt)-(41.921));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (39.51+(59.098)+(15.555));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (27.259*(54.577)*(12.7)*(86.902));
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (19.277*(77.978)*(96.44)*(62.822)*(86.595)*(70.892)*(58.347)*(77.016)*(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (68.031+(91.863)+(64.394)+(3.607)+(69.854)+(64.046)+(tcb->m_cWnd)+(2.484));
	tcb->m_cWnd = (int) (98.079-(37.947)-(45.537)-(17.876)-(73.37)-(46.079)-(82.374)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (4.354+(61.824)+(75.402)+(8.076)+(5.396)+(43.647)+(6.157)+(33.704));
	tcb->m_ssThresh = (int) (61.499+(59.689)+(25.494)+(52.731));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize == cnt) {
	tcb->m_ssThresh = (int) (84.348*(tcb->m_segmentSize)*(cnt));
	tcb->m_ssThresh = (int) (89.639*(99.689)*(tcb->m_ssThresh)*(14.588)*(cnt)*(cnt)*(63.84));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (35.393-(84.978)-(41.31)-(51.509));
	cnt = (int) (95.189*(tcb->m_cWnd)*(42.916)*(52.502));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (99.371-(12.565)-(83.389)-(tcb->m_cWnd)-(15.377)-(45.349)-(86.058)-(47.347)-(94.604));
tcb->m_segmentSize = (int) (tcb->m_ssThresh*(segmentsAcked)*(segmentsAcked)*(80.503)*(87.785));
segmentsAcked = (int) (cnt+(24.314)+(69.625)+(85.255)+(69.245)+(54.805)+(81.105)+(segmentsAcked));
