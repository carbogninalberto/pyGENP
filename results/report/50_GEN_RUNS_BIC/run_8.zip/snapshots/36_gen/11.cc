float EiGyEPFZPYWPxUIn = (float) (73.188*(61.857)*(65.77)*(segmentsAcked));
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(88.385)-(35.413)-(13.883)-(70.077)-(79.451));
	tcb->m_ssThresh = (int) (25.134-(20.735));

} else {
	tcb->m_segmentSize = (int) (3.68*(92.205)*(75.89)*(87.598)*(34.842)*(55.823));
	EiGyEPFZPYWPxUIn = (float) (41.509*(96.906)*(99.822)*(EiGyEPFZPYWPxUIn)*(85.966)*(96.764)*(60.0));
	EiGyEPFZPYWPxUIn = (float) (1.683+(34.983)+(18.035)+(EiGyEPFZPYWPxUIn));

}
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	segmentsAcked = (int) (31.252+(2.19)+(43.347));
	cnt = (int) (0.695+(cnt)+(49.364)+(52.551)+(36.821)+(1.451));

} else {
	segmentsAcked = (int) ((23.678-(tcb->m_cWnd)-(9.828)-(tcb->m_segmentSize)-(77.245)-(43.337)-(80.037)-(25.301)-(10.747))/0.1);
	cnt = (int) (EiGyEPFZPYWPxUIn-(43.287)-(29.084)-(tcb->m_cWnd));

}
if (segmentsAcked != tcb->m_ssThresh) {
	segmentsAcked = (int) (16.818*(33.744)*(37.01)*(77.678)*(63.598)*(44.077));

} else {
	segmentsAcked = (int) (55.879/0.1);
	cnt = (int) (50.212-(43.659)-(30.165)-(2.521));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
