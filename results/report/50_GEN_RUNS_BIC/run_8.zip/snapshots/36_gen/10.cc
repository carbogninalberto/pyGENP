if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (46.377-(segmentsAcked)-(64.976)-(31.169)-(18.162)-(29.347)-(81.364));
tcb->m_segmentSize = (int) (75.143*(cnt)*(95.02)*(40.973));
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(99.262)-(6.36)-(segmentsAcked)-(71.163)-(26.614)-(14.579)-(48.078));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
