tcb->m_cWnd = (int) (73.813+(36.575)+(73.117)+(1.795)+(cnt)+(47.532)+(tcb->m_ssThresh));
segmentsAcked = (int) (63.697+(62.032)+(75.828)+(14.517)+(20.775)+(tcb->m_segmentSize));
int mzLfODQuUrVZKRMK = (int) (31.034*(54.408)*(3.569));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	cnt = (int) (66.243/37.873);
	tcb->m_cWnd = (int) (23.938+(10.984)+(49.811));

} else {
	cnt = (int) (24.976+(73.214)+(18.993));

}
