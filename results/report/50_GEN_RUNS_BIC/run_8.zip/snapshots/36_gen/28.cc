ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (90.351/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (80.035+(40.112)+(64.58)+(98.101)+(segmentsAcked)+(39.009)+(34.694)+(71.561));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
