if (cnt <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (-0.014*(86.824)*(70.266)*(30.744)*(segmentsAcked)*(11.098));
	tcb->m_cWnd = (int) (97.355+(42.215)+(64.863)+(53.381)+(81.739));

} else {
	tcb->m_cWnd = (int) ((8.469-(76.497)-(22.429)-(69.844)-(80.107)-(35.743)-(56.545))/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (7.713+(41.317)+(8.649)+(82.752)+(45.375)+(cnt)+(30.877)+(cnt));

} else {
	tcb->m_cWnd = (int) (1.078+(4.1)+(97.611)+(segmentsAcked)+(76.855)+(4.428));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (6.709+(82.378)+(4.248));
	cnt = (int) (56.753*(48.13)*(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (43.547+(59.139)+(7.294)+(94.28)+(82.652)+(65.064)+(68.146)+(90.658));

}
tcb->m_cWnd = (int) (tcb->m_cWnd+(21.52)+(tcb->m_segmentSize)+(1.146)+(62.821)+(1.74)+(27.676));
tcb->m_cWnd = (int) (98.97*(92.061)*(81.578));
