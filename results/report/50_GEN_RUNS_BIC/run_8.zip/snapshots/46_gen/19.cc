ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (61.117-(25.087)-(10.947)-(40.153));
tcb->m_ssThresh = (int) (tcb->m_ssThresh-(segmentsAcked)-(53.198)-(80.808)-(52.569));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh >= cnt) {
	segmentsAcked = (int) (tcb->m_cWnd-(36.673)-(tcb->m_cWnd)-(41.2)-(68.307)-(4.609)-(4.784)-(61.607)-(81.947));
	tcb->m_segmentSize = (int) (89.154-(cnt)-(47.604)-(segmentsAcked));

} else {
	segmentsAcked = (int) (17.027/78.351);
	tcb->m_segmentSize = (int) (13.917*(73.532)*(5.404)*(29.657));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (tcb->m_cWnd*(cnt)*(60.399)*(79.196)*(15.181)*(88.617));
tcb->m_segmentSize = (int) ((((4.974*(41.904)*(31.233)))+(0.1)+(0.1)+(24.248))/((8.15)+(60.328)+(23.012)+(0.1)+(0.1)));
