tcb->m_cWnd = (int) (98.521+(74.084)+(27.431)+(72.081)+(89.464));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (83.798*(7.431)*(61.601));
tcb->m_segmentSize = (int) (54.472+(cnt)+(segmentsAcked)+(68.444)+(46.523)+(19.266));
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (86.84+(71.866)+(30.084)+(tcb->m_segmentSize)+(50.823)+(22.657)+(25.864)+(86.457));

} else {
	tcb->m_segmentSize = (int) (97.416*(tcb->m_segmentSize));
	segmentsAcked = (int) (19.218*(75.611)*(63.469));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
cnt = (int) (tcb->m_cWnd*(cnt)*(15.581)*(59.046)*(4.931)*(51.557)*(cnt));
cnt = (int) (97.212-(tcb->m_cWnd)-(tcb->m_ssThresh));
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_segmentSize+(segmentsAcked)+(66.294)+(cnt));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) ((tcb->m_ssThresh-(68.146)-(tcb->m_ssThresh)-(17.79)-(11.412)-(tcb->m_cWnd))/0.1);

} else {
	segmentsAcked = (int) (35.167*(96.136)*(6.234)*(44.121));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(34.541)-(18.927)-(73.391)-(15.189)-(57.448)-(12.402));
	ReduceCwnd (tcb);

}
