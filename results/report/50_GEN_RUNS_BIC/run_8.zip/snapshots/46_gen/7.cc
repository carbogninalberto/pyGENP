tcb->m_ssThresh = (int) ((61.478+(58.876)+(85.217))/0.1);
ReduceCwnd (tcb);
segmentsAcked = (int) (((0.1)+(0.1)+((36.762+(40.592)+(10.806)))+(97.984)+(5.194)+(0.1)+(0.1))/((0.1)));
if (cnt == cnt) {
	tcb->m_ssThresh = (int) (85.541-(67.112)-(segmentsAcked)-(70.678)-(47.583)-(64.6)-(70.292)-(93.186));
	tcb->m_cWnd = (int) (61.836*(segmentsAcked)*(85.988)*(63.904)*(30.395)*(23.922)*(41.794));
	tcb->m_cWnd = (int) ((49.067*(11.053)*(14.949)*(99.757)*(segmentsAcked)*(51.788))/54.472);

} else {
	tcb->m_ssThresh = (int) (97.501+(segmentsAcked)+(32.601)+(70.172)+(67.825)+(56.33)+(cnt)+(6.82)+(22.486));
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(70.423)+(98.552)+(55.484)+(3.684)+(37.675)+(64.963)+(cnt)+(27.041));
	tcb->m_ssThresh = (int) (((51.831)+(20.638)+(0.1)+(0.1)+(0.1))/((96.568)));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(18.497)-(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
