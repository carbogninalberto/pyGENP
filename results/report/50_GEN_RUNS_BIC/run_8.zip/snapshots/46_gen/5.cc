ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (95.189-(24.254)-(cnt)-(34.237)-(95.118)-(43.399)-(85.724)-(30.909)-(95.152));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (4.054-(40.096)-(17.641));
