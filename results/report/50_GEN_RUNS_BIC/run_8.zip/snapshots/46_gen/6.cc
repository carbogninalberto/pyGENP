if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
int tNHJVYKCSXudPeyJ = (int) (54.772-(94.92)-(52.962)-(cnt)-(2.164)-(17.792));
if (segmentsAcked > cnt) {
	tNHJVYKCSXudPeyJ = (int) (32.267*(12.338)*(77.255)*(1.828)*(18.823)*(80.313)*(tcb->m_cWnd));

} else {
	tNHJVYKCSXudPeyJ = (int) (0.1/1.149);
	cnt = (int) (tcb->m_segmentSize*(66.818));
	cnt = (int) ((88.827*(6.868)*(49.258)*(tcb->m_cWnd))/0.1);

}
ReduceCwnd (tcb);
