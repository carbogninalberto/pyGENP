if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (74.104+(4.289)+(34.959)+(99.985)+(69.283)+(16.004)+(94.899));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(33.423)*(98.064)*(24.942));
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(18.498)+(0.1)+(0.1))/((0.1)+(94.795)+(0.1)));

} else {
	tcb->m_cWnd = (int) (83.209+(54.475)+(15.886)+(cnt)+(18.622)+(tcb->m_ssThresh)+(56.303));
	tcb->m_ssThresh = (int) (44.537*(46.082));

}
if (segmentsAcked < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (19.017+(94.251));
	cnt = (int) (92.234*(4.897));

} else {
	tcb->m_ssThresh = (int) (27.385*(2.425)*(segmentsAcked)*(64.407)*(tcb->m_cWnd));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (44.546*(62.624)*(26.627));
cnt = (int) (segmentsAcked-(30.012)-(tcb->m_ssThresh)-(96.107)-(92.309)-(99.728));
tcb->m_ssThresh = (int) (14.216*(20.42)*(tcb->m_cWnd)*(33.566));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
