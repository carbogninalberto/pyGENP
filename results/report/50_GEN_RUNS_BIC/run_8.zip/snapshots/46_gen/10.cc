if (segmentsAcked == segmentsAcked) {
	segmentsAcked = (int) (tcb->m_segmentSize*(14.782)*(81.313));

} else {
	segmentsAcked = (int) (4.374*(tcb->m_ssThresh)*(52.891)*(42.472));

}
int lrNWJhFtskCBjpic = (int) (30.173*(86.402)*(88.6));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (81.9*(89.558)*(tcb->m_cWnd)*(43.535));
