segmentsAcked = (int) (75.576+(3.251));
if (segmentsAcked <= cnt) {
	tcb->m_ssThresh = (int) (0.1/61.122);
	cnt = (int) (53.17+(tcb->m_segmentSize)+(48.08)+(95.717)+(2.551)+(57.948));
	tcb->m_segmentSize = (int) (10.451+(8.453)+(14.732)+(segmentsAcked)+(43.894)+(41.741));

} else {
	tcb->m_ssThresh = (int) (10.807-(37.018)-(tcb->m_cWnd)-(tcb->m_ssThresh));
	segmentsAcked = (int) (2.38*(23.81)*(14.798)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(82.91));
	tcb->m_ssThresh = (int) (90.223+(7.677)+(28.139)+(67.891));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (cnt == tcb->m_segmentSize) {
	cnt = (int) (6.44*(tcb->m_ssThresh)*(43.83)*(55.094)*(tcb->m_segmentSize)*(40.835)*(50.218)*(46.044)*(25.064));

} else {
	cnt = (int) (96.832+(72.523)+(58.528)+(tcb->m_segmentSize)+(77.654)+(30.431)+(86.216)+(87.162));
	tcb->m_segmentSize = (int) (42.454*(38.541)*(14.967)*(52.849));
	segmentsAcked = (int) (segmentsAcked*(73.265)*(75.705));

}
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (47.191+(tcb->m_segmentSize)+(58.649)+(26.623)+(63.819)+(87.741)+(54.393)+(68.874));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (0.1/49.49);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
