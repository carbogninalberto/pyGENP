if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_segmentSize = (int) (93.884-(99.387)-(91.208));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (((74.675)+(16.485)+(0.1)+(0.1)+(0.1))/((0.1)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((38.034)+(59.575)+(64.977)+(0.1)+(0.1))/((35.246)+(0.1)));

} else {
	tcb->m_cWnd = (int) (segmentsAcked+(63.62)+(tcb->m_segmentSize)+(48.629)+(27.45)+(5.299));

}
