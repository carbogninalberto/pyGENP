ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (31.438*(84.865)*(57.499)*(20.59)*(segmentsAcked)*(segmentsAcked)*(54.259)*(cnt)*(88.269));
int YpgzOeNDLITiUCNk = (int) (48.295-(39.162)-(60.509));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
YpgzOeNDLITiUCNk = (int) (53.252*(56.27)*(29.877)*(19.5));
