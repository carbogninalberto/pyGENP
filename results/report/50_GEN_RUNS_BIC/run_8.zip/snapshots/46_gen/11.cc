if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
float VYgWnmvtYsCuwrOS = (float) ((((6.863*(cnt)*(85.859)*(tcb->m_cWnd)*(76.235)*(16.395)))+((tcb->m_segmentSize-(1.558)-(63.546)-(62.7)-(cnt)-(segmentsAcked)-(53.747)-(tcb->m_segmentSize)))+(66.901)+(4.975))/((31.57)+(39.276)));
if (VYgWnmvtYsCuwrOS < VYgWnmvtYsCuwrOS) {
	tcb->m_cWnd = (int) (67.112/39.817);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(6.654)-(59.266)-(20.55));

}
if (tcb->m_cWnd < VYgWnmvtYsCuwrOS) {
	cnt = (int) (segmentsAcked+(51.806)+(1.601));

} else {
	cnt = (int) (60.944+(60.875)+(86.925)+(VYgWnmvtYsCuwrOS)+(45.757)+(tcb->m_ssThresh)+(87.274));

}
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (82.251+(96.716)+(tcb->m_cWnd)+(50.272)+(6.909)+(26.306)+(tcb->m_segmentSize)+(40.965));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (19.49*(14.897)*(49.898));
	tcb->m_ssThresh = (int) (61.108+(segmentsAcked)+(85.322)+(35.632)+(24.631)+(84.879)+(20.225));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (77.166-(85.333)-(7.091)-(59.631)-(VYgWnmvtYsCuwrOS)-(1.649));

} else {
	tcb->m_cWnd = (int) (cnt-(85.524)-(50.721)-(41.539)-(24.784)-(41.705)-(88.286));

}
