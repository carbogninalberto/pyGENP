tcb->m_segmentSize = (int) (21.455/0.1);
if (tcb->m_ssThresh == segmentsAcked) {
	cnt = (int) (49.147-(segmentsAcked)-(tcb->m_ssThresh));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (3.853*(57.108)*(31.576)*(55.968));

} else {
	cnt = (int) (35.085*(53.713));

}
if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (3.451+(48.234)+(32.695)+(3.795)+(43.664)+(68.123)+(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (16.144+(10.766)+(44.556)+(tcb->m_cWnd)+(37.386)+(30.223)+(21.309)+(28.524)+(96.826));
	tcb->m_segmentSize = (int) (92.261+(44.191)+(4.407)+(68.461)+(70.73));
	tcb->m_segmentSize = (int) (92.751*(39.976));

}
if (cnt == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (cnt+(tcb->m_segmentSize)+(69.916));
	tcb->m_segmentSize = (int) (56.203*(64.839)*(tcb->m_cWnd)*(16.337)*(80.461)*(16.237)*(43.321)*(86.9));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(8.28)+(66.226));

} else {
	tcb->m_segmentSize = (int) (37.657-(tcb->m_segmentSize)-(16.44)-(76.772)-(74.02)-(27.683)-(55.823)-(94.077));
	tcb->m_segmentSize = (int) (55.179+(4.904)+(5.535)+(51.21));

}
if (cnt <= segmentsAcked) {
	tcb->m_cWnd = (int) (cnt+(25.847)+(35.843)+(56.621)+(40.271)+(77.416)+(tcb->m_cWnd)+(69.891));

} else {
	tcb->m_cWnd = (int) (51.822*(78.559)*(25.607)*(tcb->m_cWnd)*(77.806));
	tcb->m_ssThresh = (int) (((0.1)+(90.773)+(0.1)+((39.472*(2.481)*(13.152)*(81.885)*(8.59)*(tcb->m_segmentSize)*(segmentsAcked)*(19.708)))+(0.1))/((0.1)+(1.734)));

}
