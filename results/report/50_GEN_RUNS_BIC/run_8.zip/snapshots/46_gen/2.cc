float wyRBIlXATBNGrxUL = (float) ((-7.712-(18.77)-(-27.559)-(38.806)-(-27.423))/(-50.658-(-94.998)-(-7.174)-(-67.925)-(-16.998)-(74.017)-(-58.742)-(8.953)-(3.796)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (wyRBIlXATBNGrxUL > wyRBIlXATBNGrxUL) {
	tcb->m_segmentSize = (int) (99.239+(segmentsAcked)+(40.611)+(80.032));
	segmentsAcked = (int) (87.692+(86.052)+(73.648)+(28.983)+(15.929)+(63.107));

} else {
	tcb->m_segmentSize = (int) (82.212+(11.375)+(28.809)+(96.205)+(50.158)+(22.114)+(26.4)+(62.16)+(88.721));

}
segmentsAcked = (int) (-3.809+(95.802)+(-66.661)+(54.231)+(21.886));
