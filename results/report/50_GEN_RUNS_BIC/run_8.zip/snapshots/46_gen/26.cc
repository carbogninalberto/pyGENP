ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float ASuldJjbcYkQbGhY = (float) (95.977*(49.235)*(42.43)*(12.063)*(85.378)*(55.853)*(70.056)*(95.638));
ReduceCwnd (tcb);
float RkxjpCrRgJXggpbQ = (float) (14.023-(tcb->m_cWnd)-(65.62)-(67.692)-(tcb->m_ssThresh)-(17.371)-(57.441)-(5.378)-(53.829));
if (cnt >= tcb->m_cWnd) {
	segmentsAcked = (int) (49.394+(ASuldJjbcYkQbGhY)+(65.38)+(36.506)+(91.828)+(14.692)+(98.184));
	tcb->m_ssThresh = (int) (4.267/29.526);

} else {
	segmentsAcked = (int) (RkxjpCrRgJXggpbQ-(16.392)-(segmentsAcked)-(ASuldJjbcYkQbGhY)-(49.448)-(84.188)-(15.906)-(89.392));
	tcb->m_ssThresh = (int) (0.1/0.1);

}
float QUuiEwVOzopLXWpJ = (float) (69.471+(10.629)+(tcb->m_ssThresh));
ReduceCwnd (tcb);
