if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (52.163-(87.347)-(segmentsAcked)-(8.222)-(71.487)-(43.255)-(86.968));
	cnt = (int) (86.286*(tcb->m_segmentSize)*(86.164)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (76.162+(8.827)+(67.665)+(46.229)+(28.624)+(11.594)+(1.746)+(5.581)+(87.394));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) ((32.751*(tcb->m_cWnd)*(47.921)*(segmentsAcked)*(80.77)*(93.652)*(50.455)*(97.664)*(77.576))/48.475);
ReduceCwnd (tcb);
if (cnt > segmentsAcked) {
	tcb->m_segmentSize = (int) (3.037*(94.857)*(tcb->m_cWnd)*(70.555)*(90.764)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(95.133));

} else {
	tcb->m_segmentSize = (int) (31.333+(segmentsAcked)+(67.475));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (96.225-(28.03)-(69.338)-(6.12)-(56.278)-(50.614)-(81.049)-(23.757)-(63.142));

}
segmentsAcked = (int) (52.424/0.1);
