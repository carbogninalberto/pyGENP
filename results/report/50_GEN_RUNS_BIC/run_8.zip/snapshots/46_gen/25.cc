tcb->m_segmentSize = (int) (14.575*(91.68));
tcb->m_cWnd = (int) (58.627-(78.485)-(37.737)-(85.326)-(42.438)-(85.804)-(41.281)-(cnt));
tcb->m_ssThresh = (int) (75.258+(tcb->m_ssThresh)+(54.297)+(40.432)+(39.519)+(64.428)+(cnt));
if (cnt == cnt) {
	tcb->m_ssThresh = (int) (((28.798)+(15.197)+((39.589*(cnt)*(11.615)*(37.597)))+(19.129))/((47.484)+(0.1)+(0.1)+(22.393)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize-(19.527)-(69.672)-(segmentsAcked));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (42.73*(tcb->m_cWnd)*(85.387)*(segmentsAcked)*(71.533));

} else {
	tcb->m_segmentSize = (int) ((62.597+(2.582)+(21.799)+(38.242)+(94.421)+(2.837))/0.1);
	tcb->m_segmentSize = (int) (5.91+(5.835));

}
tcb->m_cWnd = (int) (segmentsAcked+(85.91)+(41.118)+(86.557)+(19.43)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(cnt));
