if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(35.183)+(20.767)+(0.1))/((80.448)+(6.412)));
	tcb->m_ssThresh = (int) (23.806*(55.901)*(cnt)*(23.639)*(59.259)*(tcb->m_ssThresh)*(40.552)*(37.639)*(5.037));
	tcb->m_cWnd = (int) (62.024*(8.502)*(cnt)*(33.361)*(73.951)*(66.707));

} else {
	tcb->m_cWnd = (int) (98.623*(tcb->m_ssThresh)*(37.375)*(11.195)*(24.441)*(19.193)*(82.658)*(tcb->m_cWnd));
	cnt = (int) (35.458+(segmentsAcked)+(74.185)+(36.744)+(tcb->m_ssThresh)+(91.417));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) ((tcb->m_ssThresh+(21.466)+(99.902)+(72.539)+(73.524))/0.1);

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(cnt)-(74.109));
	tcb->m_segmentSize = (int) ((tcb->m_segmentSize-(54.715)-(75.404)-(41.9))/0.1);

}
ReduceCwnd (tcb);
cnt = (int) (cnt-(76.613)-(segmentsAcked)-(33.793)-(65.802));
tcb->m_cWnd = (int) (27.489/0.1);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (68.032*(32.153)*(1.126)*(92.823)*(7.188)*(16.197));
tcb->m_segmentSize = (int) (66.616+(91.227)+(tcb->m_segmentSize)+(60.214)+(32.757)+(39.705)+(96.953)+(71.671));
