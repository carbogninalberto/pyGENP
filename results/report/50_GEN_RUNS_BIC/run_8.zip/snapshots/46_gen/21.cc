ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (tcb->m_cWnd+(46.622)+(63.379));
int BbWMvXUcLGNIagrp = (int) (1.731*(36.712)*(30.75)*(41.599));
ReduceCwnd (tcb);
