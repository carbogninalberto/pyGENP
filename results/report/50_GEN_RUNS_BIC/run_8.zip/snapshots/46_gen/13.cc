cnt = (int) (14.5+(segmentsAcked));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) (35.329+(20.894));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (28.753+(8.45));
	cnt = (int) ((26.652*(61.729))/30.187);
	cnt = (int) (71.391*(15.434)*(48.191));

}
segmentsAcked = (int) (55.19-(77.509)-(6.685)-(tcb->m_segmentSize)-(20.288)-(25.242));
tcb->m_cWnd = (int) ((((19.817+(60.302)))+(35.87)+(0.1)+(0.1)+(0.1))/((0.1)));
segmentsAcked = (int) (74.529/0.1);
float EsjrRABzKSnkviha = (float) (58.302/0.1);
