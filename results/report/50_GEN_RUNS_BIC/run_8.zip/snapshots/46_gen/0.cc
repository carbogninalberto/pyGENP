int ZfUrflETVgCNutgr = (int) (-14.404*(-9.872)*(8.892)*(38.968)*(-92.687)*(92.539));
int dwkmKCAtEEnLyAAH = (int) (-89.206+(-95.683)+(18.624));
ReduceCwnd (tcb);
segmentsAcked = (int) (28.834*(24.656)*(10.869)*(-11.198)*(-64.999)*(-75.041)*(36.882));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
