float dCSZsNKfmpjFkJub = (float) (-61.124-(-82.202)-(-17.258)-(-53.178));
