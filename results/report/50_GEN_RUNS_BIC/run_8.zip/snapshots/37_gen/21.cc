ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) ((((8.809+(8.735)+(39.545)+(36.955)+(99.505)+(9.585)+(54.982)))+(37.986)+(88.134)+(0.1)+((cnt+(tcb->m_cWnd)+(57.255)))+(57.152))/((0.1)+(3.746)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (((13.364)+(46.558)+((14.448*(36.331)*(50.799)*(35.102)*(48.127)*(63.17)*(segmentsAcked)))+(0.1)+(0.1)+(0.1))/((0.1)));
	cnt = (int) (tcb->m_cWnd-(78.815)-(1.498)-(42.618)-(26.883)-(89.077)-(25.051)-(50.027)-(7.164));
	tcb->m_ssThresh = (int) (20.26/0.1);

}
if (tcb->m_ssThresh >= cnt) {
	tcb->m_ssThresh = (int) (47.239+(49.446)+(86.132)+(cnt)+(34.027)+(47.076));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (75.516*(tcb->m_cWnd)*(50.943));
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(70.952))/((80.197)+(0.1)));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (((0.1)+((44.483*(83.569)*(32.884)*(58.774)))+(0.1)+(0.1)+((64.944-(65.26)-(89.869)-(99.328)-(65.556)))+(0.1))/((0.1)+(0.1)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
