ReduceCwnd (tcb);
int EHLRqTsxhXzPZrie = (int) (18.747+(95.408)+(tcb->m_segmentSize)+(24.728)+(92.657)+(54.909)+(47.767)+(69.702));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (19.155*(27.81)*(27.95)*(88.897));
cnt = (int) (((0.1)+((37.665+(65.33)+(tcb->m_cWnd)+(68.12)+(13.332)+(70.647)+(30.218)+(6.069)))+((14.356-(11.987)-(tcb->m_cWnd)-(EHLRqTsxhXzPZrie)))+(0.1))/((0.1)+(0.1)));
