if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (77.304*(tcb->m_cWnd)*(cnt)*(72.53)*(63.572)*(8.345)*(52.919));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(63.297)-(9.321)-(tcb->m_segmentSize)-(65.149)-(92.716)-(92.406)-(61.551));
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(86.931));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
if (cnt <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(96.563));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (71.258*(73.762)*(42.753)*(39.296)*(23.486)*(97.552));

} else {
	tcb->m_ssThresh = (int) ((13.571-(9.015)-(37.793)-(80.871))/31.89);

}
segmentsAcked = (int) (segmentsAcked-(55.142)-(cnt));
segmentsAcked = (int) (cnt*(7.691)*(98.2)*(74.418)*(tcb->m_cWnd)*(9.868)*(segmentsAcked));
float KwLfCFEdEHfNfIMt = (float) (0.1/19.882);
segmentsAcked = (int) (24.595/48.931);
cnt = (int) (0.1/62.145);
int MCrgMXKcGcVroxEb = (int) (((0.1)+(0.1)+(12.668)+(68.697)+(29.058))/((0.1)+(0.1)+(3.327)));
