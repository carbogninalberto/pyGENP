ReduceCwnd (tcb);
segmentsAcked = (int) (48.175+(11.518)+(32.927)+(55.143)+(67.805)+(11.301)+(19.72)+(73.787)+(segmentsAcked));
tcb->m_cWnd = (int) (((0.1)+((70.25-(85.468)))+(26.153)+(1.495)+(22.605)+(0.1)+(7.0))/((0.1)+(35.519)));
tcb->m_segmentSize = (int) (tcb->m_cWnd+(8.258)+(12.873)+(21.121));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
