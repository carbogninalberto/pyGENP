tcb->m_segmentSize = (int) (-67.711-(-93.407)-(99.64)-(-21.631));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
