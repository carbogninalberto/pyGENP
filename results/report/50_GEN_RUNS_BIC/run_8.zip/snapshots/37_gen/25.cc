if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize > segmentsAcked) {
	segmentsAcked = (int) (26.149+(37.274));
	tcb->m_segmentSize = (int) (80.34-(18.553)-(23.151)-(56.974));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (7.036*(5.273)*(49.547));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(48.29)-(52.104)-(59.982)-(9.623)-(43.635)-(81.778));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked*(50.554)*(18.571)*(43.674));
	tcb->m_ssThresh = (int) (63.939*(tcb->m_ssThresh)*(4.276)*(11.774)*(56.873)*(99.95)*(13.012)*(8.005)*(64.278));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(70.187)*(cnt));

} else {
	tcb->m_cWnd = (int) (88.202-(tcb->m_ssThresh)-(29.626)-(tcb->m_segmentSize)-(4.455)-(21.038)-(88.742)-(69.112));
	tcb->m_segmentSize = (int) (cnt-(32.82)-(97.622));

}
ReduceCwnd (tcb);
