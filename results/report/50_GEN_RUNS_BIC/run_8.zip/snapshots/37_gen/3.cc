float EiGyEPFZPYWPxUIn = (float) (42.959*(-5.44)*(-76.926)*(49.581));
