ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (40.005*(82.86)*(4.489));
ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_cWnd) {
	segmentsAcked = (int) ((((tcb->m_cWnd+(44.397)))+((20.626-(69.872)-(94.442)-(94.002)-(tcb->m_cWnd)-(60.089)-(16.346)-(segmentsAcked)))+((23.22-(52.081)-(24.583)-(38.236)-(43.506)-(66.438)-(54.439)))+(0.1))/((91.607)+(0.1)+(0.1)+(0.1)+(48.784)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (8.748+(78.846)+(tcb->m_cWnd)+(14.591)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(31.913));
	tcb->m_cWnd = (int) (18.849-(tcb->m_ssThresh)-(64.3)-(30.795)-(23.36)-(26.959)-(40.239)-(62.722));
	tcb->m_cWnd = (int) (13.153-(segmentsAcked)-(segmentsAcked)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(58.631)-(12.154)-(39.543));

}
float PcubCIoRtfTIVRPb = (float) (27.772-(89.657)-(21.829)-(44.501)-(31.642)-(5.91));
