if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (32.018+(tcb->m_segmentSize)+(49.701)+(tcb->m_segmentSize)+(segmentsAcked)+(41.922)+(36.94)+(79.646)+(13.429));
	ReduceCwnd (tcb);
	cnt = (int) (tcb->m_segmentSize+(84.387)+(cnt)+(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (15.471*(93.106)*(3.64)*(8.539)*(39.453)*(74.259)*(70.452)*(16.992)*(36.817));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
cnt = (int) (22.011*(83.57)*(51.348));
tcb->m_segmentSize = (int) (70.033*(90.66)*(tcb->m_cWnd)*(17.086));
if (segmentsAcked == segmentsAcked) {
	segmentsAcked = (int) (cnt-(27.996));
	tcb->m_cWnd = (int) (tcb->m_cWnd*(86.69)*(20.425)*(tcb->m_ssThresh)*(19.763)*(tcb->m_ssThresh));
	segmentsAcked = (int) ((tcb->m_ssThresh-(73.967)-(19.312)-(45.145)-(3.214)-(segmentsAcked))/63.402);

} else {
	segmentsAcked = (int) (90.183+(58.34)+(cnt)+(32.163)+(14.25));

}
tcb->m_cWnd = (int) (72.116*(90.235)*(15.302)*(18.679)*(segmentsAcked)*(67.487)*(97.202)*(19.497));
ReduceCwnd (tcb);
