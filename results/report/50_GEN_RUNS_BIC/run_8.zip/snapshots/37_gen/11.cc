ReduceCwnd (tcb);
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (9.167+(95.464));

} else {
	tcb->m_cWnd = (int) (97.584+(tcb->m_ssThresh)+(18.785));

}
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(95.643))/((0.1)+(0.1)+(0.1)+(35.133)+(84.835)));

} else {
	segmentsAcked = (int) (72.692+(51.403)+(92.871)+(14.116)+(cnt)+(18.249)+(12.386)+(96.188));
	cnt = (int) (16.757+(38.102)+(73.55)+(52.605)+(68.113)+(69.985)+(96.425)+(76.316)+(25.024));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (70.914+(tcb->m_segmentSize)+(tcb->m_cWnd)+(64.512)+(83.816)+(14.406)+(segmentsAcked));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
segmentsAcked = (int) (86.331+(55.539)+(74.092)+(53.244)+(55.67)+(96.493)+(75.327));
