cnt = (int) (tcb->m_cWnd*(tcb->m_cWnd)*(29.964)*(77.774)*(tcb->m_ssThresh)*(cnt)*(97.19)*(11.954));
ReduceCwnd (tcb);
segmentsAcked = (int) (36.746+(83.25));
if (cnt < cnt) {
	cnt = (int) (segmentsAcked-(72.541)-(27.38)-(83.254)-(89.315)-(81.847)-(tcb->m_segmentSize)-(63.662)-(54.806));

} else {
	cnt = (int) (80.128-(30.297)-(71.638)-(35.962));
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (((48.477)+(5.648)+(53.403)+(1.87))/((0.1)));
int tPEyKIHQAscIcAuY = (int) (38.472-(2.456)-(1.602)-(tcb->m_cWnd)-(tcb->m_cWnd)-(51.773));
ReduceCwnd (tcb);
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tPEyKIHQAscIcAuY = (int) (85.86-(56.657)-(74.406));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(57.656)-(23.746)-(tPEyKIHQAscIcAuY)-(16.121)-(82.617)-(8.38));

} else {
	tPEyKIHQAscIcAuY = (int) (segmentsAcked+(84.919)+(23.712));
	cnt = (int) (36.907+(85.515)+(9.85)+(cnt)+(44.111)+(22.529)+(32.272)+(tcb->m_ssThresh)+(tcb->m_cWnd));

}
