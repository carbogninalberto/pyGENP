int DvGVAPDkMCeWlgxi = (int) (6.083+(-5.155));
int zfuwKDYzTVasMzTD = (int) (-43.328-(74.843));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-96.794+(-68.378)+(-57.735)+(-76.95)+(-74.07)+(-7.708)+(-45.568)+(20.551));
segmentsAcked = (int) (-0.39/-55.027);
tcb->m_segmentSize = (int) (-31.933+(86.498)+(44.528)+(3.516)+(7.654)+(18.093));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (34.01-(59.262)-(-75.594)-(97.971)-(-0.81)-(-82.509)-(-3.73)-(-74.093));
