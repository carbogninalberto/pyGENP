tcb->m_segmentSize = (int) (77.487*(67.908)*(-59.324)*(-51.907)*(37.148));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
