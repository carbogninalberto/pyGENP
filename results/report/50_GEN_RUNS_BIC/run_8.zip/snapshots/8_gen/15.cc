int qSCvWkXyCYImTzYu = (int) ((-28.698+(-25.652)+(-59.33)+(59.11)+(-19.31)+(74.456))/-60.811);
int QMGRddeVbMpQNFqk = (int) (((-36.219)+(77.063)+(3.917)+(46.555)+(32.146))/((-44.235)+(-13.072)+(54.4)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
