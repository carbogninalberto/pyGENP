tcb->m_ssThresh = (int) (4.296*(96.582)*(7.1)*(16.492)*(27.639)*(4.646)*(82.734)*(36.326));
tcb->m_ssThresh = (int) (90.38*(72.283)*(67.039)*(34.707)*(44.622));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (22.003-(segmentsAcked)-(33.429)-(22.736)-(82.503)-(18.478)-(59.987));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (0.1/0.1);
