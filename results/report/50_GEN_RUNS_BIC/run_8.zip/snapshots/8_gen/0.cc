tcb->m_segmentSize = (int) (80.227*(-93.566)*(39.913)*(93.697)*(-60.46));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
