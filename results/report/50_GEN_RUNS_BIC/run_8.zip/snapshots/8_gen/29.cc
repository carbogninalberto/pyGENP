tcb->m_segmentSize = (int) (26.699*(tcb->m_cWnd)*(tcb->m_cWnd)*(8.749)*(54.601));
ReduceCwnd (tcb);
cnt = (int) (93.829*(16.873)*(89.142)*(77.049)*(88.246)*(0.13));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (10.167+(44.27)+(8.605)+(1.698)+(17.856));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (23.533+(2.171)+(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (31.117*(90.257)*(67.207)*(19.548)*(tcb->m_cWnd)*(25.261));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (56.343-(87.132)-(58.186)-(segmentsAcked)-(tcb->m_ssThresh)-(cnt)-(segmentsAcked)-(7.054)-(cnt));
