float WUMXKCZmPHiXUnFq = (float) (39.829/-9.407);
tcb->m_segmentSize = (int) (40.377+(11.129)+(19.53)+(13.184)+(-14.221));
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (93.877-(49.48));
	segmentsAcked = (int) (22.529*(-23.956)*(73.525)*(79.788)*(2.968)*(6.056));

} else {
	tcb->m_cWnd = (int) (39.295*(-63.542)*(97.618)*(tcb->m_cWnd));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
