tcb->m_ssThresh = (int) (24.337+(75.277)+(19.448)+(26.425)+(92.975)+(43.339)+(tcb->m_cWnd));
if (cnt <= cnt) {
	tcb->m_cWnd = (int) (50.991+(7.415)+(tcb->m_ssThresh)+(86.341)+(10.179)+(32.097)+(30.165));
	tcb->m_segmentSize = (int) (83.12*(84.937)*(22.649)*(95.608)*(44.496)*(52.211)*(59.132)*(68.42));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (88.879+(49.093)+(63.736));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(25.573)*(97.087)*(tcb->m_segmentSize)*(26.51)*(93.574)*(86.939));
	tcb->m_cWnd = (int) (92.685*(segmentsAcked)*(78.665)*(22.499)*(83.842)*(44.938)*(tcb->m_cWnd)*(78.615));
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(61.247)+(0.1))/((37.32)+(4.655)));

} else {
	tcb->m_segmentSize = (int) (79.374*(46.559));

}
float PFayOZgzoskhYmli = (float) (segmentsAcked*(66.89)*(tcb->m_segmentSize)*(2.382)*(35.682)*(62.848)*(32.131));
tcb->m_ssThresh = (int) (4.898-(tcb->m_segmentSize)-(82.016)-(53.219)-(segmentsAcked)-(82.383)-(16.185)-(segmentsAcked)-(54.99));
if (segmentsAcked > PFayOZgzoskhYmli) {
	tcb->m_ssThresh = (int) (22.763/0.1);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (79.828+(5.552)+(21.226)+(70.086)+(50.636)+(49.777)+(segmentsAcked)+(93.961)+(98.44));

} else {
	tcb->m_ssThresh = (int) (70.893+(90.463));
	cnt = (int) (42.161*(86.457)*(97.371)*(PFayOZgzoskhYmli)*(22.088)*(PFayOZgzoskhYmli)*(78.603));

}
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_ssThresh = (int) (42.638*(69.434)*(40.299)*(21.29)*(80.786)*(30.903)*(11.424)*(36.771)*(89.096));
	segmentsAcked = (int) (33.103-(63.287)-(cnt)-(53.614)-(93.398)-(cnt)-(tcb->m_ssThresh)-(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (((43.592)+(43.871)+(14.466)+(0.1)+(0.1)+(90.109))/((0.1)));

}
