if (tcb->m_segmentSize == cnt) {
	segmentsAcked = (int) (32.02-(10.841)-(29.959)-(58.615)-(64.858)-(1.527)-(67.163));
	cnt = (int) (((47.826)+(0.1)+((3.341*(72.435)*(58.033)*(7.597)*(97.683)*(tcb->m_cWnd)*(49.649)*(31.476)*(93.112)))+((54.819+(55.127)+(cnt)+(85.844)+(69.289)+(segmentsAcked)+(tcb->m_ssThresh)+(88.09)+(62.215)))+(0.1))/((5.126)+(34.891)+(0.1)+(2.774)));

} else {
	segmentsAcked = (int) (80.182*(tcb->m_ssThresh)*(23.458)*(99.859)*(30.626)*(90.919)*(segmentsAcked)*(60.478)*(40.566));
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_segmentSize = (int) (59.97*(83.399)*(55.711)*(52.713)*(37.211)*(68.96)*(9.709));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
if (cnt > cnt) {
	tcb->m_cWnd = (int) (61.722*(17.349)*(cnt)*(52.816));
	cnt = (int) (1.323+(segmentsAcked)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (65.625*(17.949)*(69.911)*(17.601)*(8.675)*(29.418)*(cnt)*(6.446)*(49.9));
	tcb->m_ssThresh = (int) (0.307*(35.967)*(27.439)*(96.331)*(20.074));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked == segmentsAcked) {
	tcb->m_ssThresh = (int) (69.799-(90.326)-(13.414)-(cnt)-(85.12)-(55.605));
	cnt = (int) (43.041+(36.41)+(25.253)+(cnt)+(85.668)+(91.305)+(segmentsAcked)+(73.943)+(36.617));
	cnt = (int) (tcb->m_segmentSize-(tcb->m_cWnd)-(26.576)-(28.652)-(11.066)-(52.307));

} else {
	tcb->m_ssThresh = (int) (((3.969)+(0.1)+((78.636*(85.947)*(99.822)*(32.174)*(40.844)*(tcb->m_cWnd)*(34.605)))+(0.1)+(50.741)+(83.961))/((32.778)+(85.441)));

}
if (tcb->m_ssThresh != cnt) {
	tcb->m_ssThresh = (int) (cnt+(97.043)+(1.185)+(28.208)+(tcb->m_segmentSize)+(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (62.285-(49.291)-(34.011)-(tcb->m_ssThresh)-(42.149)-(25.524)-(16.295)-(29.482)-(34.171));

}
