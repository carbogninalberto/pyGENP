if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (25.767+(48.832)+(64.875)+(67.428)+(54.055)+(segmentsAcked)+(69.548));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (83.228+(94.417)+(84.302)+(79.154));

} else {
	tcb->m_segmentSize = (int) (56.707*(19.62)*(49.948));
	tcb->m_segmentSize = (int) (47.707*(cnt)*(75.091));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	cnt = (int) (83.611-(13.954)-(63.162)-(cnt));

} else {
	cnt = (int) (97.47+(68.683)+(58.466)+(0.448));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
