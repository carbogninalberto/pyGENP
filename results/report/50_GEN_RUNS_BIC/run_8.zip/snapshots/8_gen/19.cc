if (tcb->m_ssThresh == cnt) {
	segmentsAcked = (int) (((85.076)+(0.1)+((46.447-(3.152)-(74.728)-(tcb->m_ssThresh)-(23.561)-(79.106)-(16.902)-(48.987)))+(0.1))/((0.1)+(0.1)));

} else {
	segmentsAcked = (int) (45.291-(79.821)-(tcb->m_cWnd)-(tcb->m_cWnd)-(40.233));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (4.136+(45.889)+(cnt)+(86.036)+(tcb->m_cWnd)+(71.614)+(58.168)+(42.699));
	tcb->m_segmentSize = (int) (63.365/0.1);

} else {
	tcb->m_cWnd = (int) (34.466-(65.807)-(20.813)-(4.595)-(74.48));

}
segmentsAcked = (int) (91.432-(44.378));
cnt = (int) (tcb->m_cWnd+(tcb->m_cWnd)+(59.28)+(19.609)+(63.079));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (94.334*(97.104)*(38.475)*(20.997)*(53.763));
ReduceCwnd (tcb);
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_ssThresh = (int) (77.037*(46.574)*(58.225)*(90.935)*(57.575)*(68.468)*(48.669)*(73.262));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (39.687+(cnt)+(segmentsAcked)+(segmentsAcked));
	tcb->m_segmentSize = (int) (77.108+(56.601)+(7.832)+(37.881));

}
