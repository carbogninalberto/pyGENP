int dTQatOJLdJxNMsLd = (int) (59.545+(39.656)+(0.126)+(16.292)+(32.614));
tcb->m_ssThresh = (int) (cnt+(62.152)+(15.668));
if (tcb->m_cWnd <= cnt) {
	tcb->m_segmentSize = (int) (48.414-(tcb->m_ssThresh)-(45.233)-(95.502)-(56.152)-(99.159)-(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (28.188*(65.393)*(tcb->m_segmentSize)*(73.503)*(16.246)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(74.81));
	tcb->m_cWnd = (int) (79.529/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.1/21.569);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) ((((50.47*(tcb->m_cWnd)*(35.108)*(12.192)*(86.26)*(0.325)*(41.784)))+((21.86+(61.368)+(8.22)+(50.53)))+(71.591)+(67.845)+(59.962)+(0.1))/((41.265)));

} else {
	tcb->m_ssThresh = (int) (76.582*(63.356)*(62.572)*(1.824)*(38.63)*(83.259)*(88.259)*(15.871));
	tcb->m_ssThresh = (int) (dTQatOJLdJxNMsLd-(97.215)-(60.972)-(tcb->m_cWnd)-(37.272));

}
ReduceCwnd (tcb);
if (cnt != tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(41.125)-(91.01));
	tcb->m_cWnd = (int) (21.684*(tcb->m_ssThresh)*(dTQatOJLdJxNMsLd)*(51.84)*(tcb->m_cWnd)*(73.783)*(cnt)*(44.068));

} else {
	tcb->m_ssThresh = (int) (18.189-(93.084));
	segmentsAcked = (int) (59.397*(tcb->m_cWnd)*(58.503)*(88.155));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
