ReduceCwnd (tcb);
segmentsAcked = (int) (-17.151*(58.497)*(-12.838)*(44.063)*(-68.604)*(-8.273)*(65.614)*(-66.289));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
