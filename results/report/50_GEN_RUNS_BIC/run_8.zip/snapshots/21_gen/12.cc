if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (39.912+(88.831)+(94.099)+(54.741)+(6.828)+(51.959)+(60.664));
	tcb->m_ssThresh = (int) (22.267-(80.454)-(tcb->m_ssThresh)-(5.813)-(4.299)-(26.107)-(18.621));
	tcb->m_segmentSize = (int) (66.426-(16.847)-(66.864)-(52.695)-(10.563)-(tcb->m_segmentSize)-(8.844)-(32.3)-(98.698));

} else {
	tcb->m_segmentSize = (int) (71.553*(tcb->m_cWnd)*(tcb->m_cWnd)*(39.344)*(1.153)*(cnt)*(76.995));
	segmentsAcked = (int) (segmentsAcked+(9.711)+(73.83)+(59.506)+(17.541)+(segmentsAcked)+(94.605)+(segmentsAcked)+(23.909));
	cnt = (int) (87.423/84.341);

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((0.1)+((36.288-(6.754)))+(49.929)+(0.1)+(98.305))/((0.1)));
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (6.949/0.1);

} else {
	tcb->m_segmentSize = (int) (98.687-(54.808)-(79.437)-(55.408)-(6.706)-(9.415)-(99.073));
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(50.019)+(23.718)+(42.811)+((4.38+(86.809)+(84.429)))+(47.423)+(22.652))/((0.1)));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (0.1/0.1);
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) (97.548*(segmentsAcked)*(98.582));
	segmentsAcked = (int) (2.193-(76.02));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(63.76)-(63.35)-(90.35)-(63.337)-(81.693)-(3.582));
	tcb->m_segmentSize = (int) (16.524+(65.915));
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(26.862)+(64.927)+((tcb->m_cWnd*(22.743)*(2.495)*(tcb->m_ssThresh)*(80.394)*(segmentsAcked)*(cnt)*(74.782)))+(0.1))/((28.993)+(0.1)));

}
float eTJHQuxKtjxIMtDg = (float) (0.1/0.1);
