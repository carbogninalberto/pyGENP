if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (segmentsAcked != tcb->m_cWnd) {
	segmentsAcked = (int) (70.887+(46.967)+(segmentsAcked)+(55.617)+(63.495)+(53.589)+(71.116)+(84.541));
	segmentsAcked = (int) (46.846-(6.438));
	segmentsAcked = (int) (cnt-(82.168)-(tcb->m_ssThresh)-(29.204));

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(2.79)+(0.1))/((95.626)+(36.45)));
	tcb->m_ssThresh = (int) (0.1/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (17.747/21.805);
if (segmentsAcked == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (68.493-(84.358)-(1.165)-(50.83)-(98.608)-(39.405)-(12.997)-(50.116));

} else {
	tcb->m_segmentSize = (int) (26.926-(45.065)-(87.721)-(60.61)-(9.458)-(8.825));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) ((3.343*(tcb->m_ssThresh)*(59.55)*(tcb->m_segmentSize)*(39.0)*(36.749)*(5.522))/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
