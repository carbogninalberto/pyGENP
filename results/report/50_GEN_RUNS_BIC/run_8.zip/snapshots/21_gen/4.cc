float OslizSIoLwVFjuTe = (float) (-66.377-(-99.009)-(-21.934)-(-37.272)-(-76.391)-(-40.506)-(-81.779)-(-19.047)-(66.268));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-13.07-(-39.896)-(-75.595)-(56.672)-(-10.145)-(40.583));
segmentsAcked = (int) (27.379/14.663);
OslizSIoLwVFjuTe = (float) (-53.191/24.161);
tcb->m_segmentSize = (int) (32.684+(77.963)+(-94.609)+(-46.529)+(-69.507)+(-65.591)+(28.376));
