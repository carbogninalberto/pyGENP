tcb->m_segmentSize = (int) (91.493+(tcb->m_cWnd)+(34.555)+(2.483));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (45.908+(66.438));
if (cnt == cnt) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(59.662)*(tcb->m_ssThresh)*(48.811)*(95.332));
	ReduceCwnd (tcb);
	cnt = (int) (78.155*(97.553)*(50.343)*(14.801)*(70.629)*(49.364));

} else {
	tcb->m_segmentSize = (int) (3.487+(54.392)+(segmentsAcked)+(87.278)+(62.082)+(37.204));

}
ReduceCwnd (tcb);
