if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (28.951-(61.965)-(58.082)-(27.957)-(43.368)-(98.817)-(tcb->m_segmentSize)-(97.102));
	cnt = (int) (83.337*(44.497)*(46.572)*(tcb->m_ssThresh)*(65.824)*(25.059)*(76.905)*(17.729)*(29.897));

} else {
	tcb->m_segmentSize = (int) (45.933*(segmentsAcked));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (tcb->m_cWnd*(tcb->m_cWnd)*(37.319)*(35.159)*(58.626));

}
tcb->m_segmentSize = (int) (11.632+(cnt)+(91.98)+(2.209)+(84.813)+(18.823)+(segmentsAcked)+(10.193));
if (tcb->m_segmentSize <= cnt) {
	segmentsAcked = (int) (((44.652)+(11.498)+((tcb->m_ssThresh-(56.295)-(96.339)-(64.753)-(92.982)))+(11.335))/((0.1)+(0.1)));

} else {
	segmentsAcked = (int) (25.431+(51.53));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (69.51*(58.206)*(66.852));
tcb->m_ssThresh = (int) (40.885*(2.445)*(segmentsAcked)*(9.609));
