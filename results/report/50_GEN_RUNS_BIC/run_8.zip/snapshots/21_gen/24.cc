int IMnrcOBzQiRMLlqM = (int) (38.797*(39.196)*(93.341)*(tcb->m_ssThresh)*(85.215)*(66.606)*(54.99)*(tcb->m_ssThresh));
segmentsAcked = (int) (33.994+(99.791)+(30.394)+(48.109)+(51.062)+(2.475)+(IMnrcOBzQiRMLlqM)+(70.521));
cnt = (int) (3.306-(segmentsAcked)-(14.847)-(93.986)-(55.494)-(2.496));
ReduceCwnd (tcb);
if (IMnrcOBzQiRMLlqM <= tcb->m_cWnd) {
	cnt = (int) (52.619/45.691);

} else {
	cnt = (int) (93.628+(95.492)+(27.088)+(22.37)+(51.084)+(56.083)+(7.584));
	segmentsAcked = (int) (((44.557)+(0.1)+((cnt-(79.71)-(66.908)-(67.546)-(16.354)-(7.364)-(55.19)))+((tcb->m_cWnd*(cnt)*(3.41)*(34.492)*(tcb->m_cWnd)))+(92.218))/((0.1)));
	tcb->m_cWnd = (int) (74.792*(40.862)*(24.837)*(segmentsAcked)*(55.831));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (55.313-(tcb->m_ssThresh)-(66.444)-(IMnrcOBzQiRMLlqM)-(10.554));
	tcb->m_ssThresh = (int) (IMnrcOBzQiRMLlqM*(23.811));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(92.755)-(74.916));
	tcb->m_ssThresh = (int) (57.363*(25.885));

}
if (segmentsAcked <= segmentsAcked) {
	tcb->m_cWnd = (int) (97.26*(99.466)*(90.052)*(segmentsAcked)*(12.689)*(tcb->m_ssThresh)*(94.132));
	tcb->m_cWnd = (int) (18.337-(-0.05)-(89.538)-(29.952)-(97.63)-(15.839)-(tcb->m_ssThresh)-(65.198));

} else {
	tcb->m_cWnd = (int) (2.717*(85.037)*(46.345));
	segmentsAcked = (int) (0.1/0.1);
	segmentsAcked = (int) (64.209-(62.297)-(1.134)-(73.038));

}
IMnrcOBzQiRMLlqM = (int) (35.216-(tcb->m_ssThresh)-(95.795)-(27.483));
cnt = (int) (53.411-(37.722)-(IMnrcOBzQiRMLlqM)-(82.469));
