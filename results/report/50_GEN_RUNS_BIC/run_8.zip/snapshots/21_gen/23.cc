int vCEVQsbhJspAcDuE = (int) ((((49.569*(53.844)*(tcb->m_cWnd)*(2.521)*(cnt)*(11.545)*(68.438)))+(0.1)+(82.55)+((tcb->m_ssThresh-(92.706)-(78.781)-(82.667)-(90.106)))+(0.1)+(15.185))/((0.1)+(34.416)));
tcb->m_ssThresh = (int) (segmentsAcked-(4.735)-(0.972)-(97.204)-(55.183)-(segmentsAcked)-(15.873)-(21.712));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (((0.1)+((14.031*(tcb->m_segmentSize)*(16.752)*(30.323)*(36.009)*(segmentsAcked)))+(86.673)+(0.1))/((77.701)+(81.396)+(0.1)));
tcb->m_ssThresh = (int) (0.1/9.185);
