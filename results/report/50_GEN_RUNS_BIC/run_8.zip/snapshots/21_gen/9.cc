ReduceCwnd (tcb);
if (tcb->m_segmentSize >= segmentsAcked) {
	segmentsAcked = (int) (0.1/24.317);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((11.316)+((94.288*(64.954)*(77.324)*(37.634)*(cnt)*(4.326)*(81.175)*(34.527)))+(70.079)+(19.601))/((78.411)+(0.1)+(0.1)+(47.606)+(0.1)));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
