tcb->m_segmentSize = (int) (64.462-(93.561)-(cnt)-(70.753));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (cnt == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (60.271*(56.549)*(96.252)*(segmentsAcked)*(0.729)*(cnt));

} else {
	tcb->m_segmentSize = (int) (42.777-(68.966)-(42.62));

}
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	cnt = (int) (89.096+(20.087)+(22.224)+(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (24.866-(92.519)-(segmentsAcked)-(21.368)-(89.659)-(28.556)-(29.78)-(9.726));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (0.1/0.1);

}
