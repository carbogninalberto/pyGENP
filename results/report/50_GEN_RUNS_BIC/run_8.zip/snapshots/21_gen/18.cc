if (tcb->m_cWnd >= cnt) {
	segmentsAcked = (int) (51.552*(17.694)*(20.938)*(41.536)*(30.961)*(55.471)*(19.498)*(85.543));
	tcb->m_ssThresh = (int) (77.605*(tcb->m_ssThresh)*(7.206)*(tcb->m_ssThresh)*(20.101)*(36.661)*(85.906)*(41.722));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (84.547+(98.447)+(7.831)+(78.898));
	cnt = (int) (42.736-(33.081)-(tcb->m_cWnd)-(90.753)-(11.168)-(42.759)-(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (50.628/0.1);
float NkwRTcVxIhxtkfJj = (float) ((segmentsAcked*(28.363)*(59.827)*(9.01)*(63.814)*(58.062))/0.1);
