segmentsAcked = (int) (-99.76*(-16.625)*(21.275)*(-37.119)*(41.132)*(63.992)*(16.363)*(25.881));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
