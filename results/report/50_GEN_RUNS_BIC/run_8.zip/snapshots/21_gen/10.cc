ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (28.437-(segmentsAcked));
if (tcb->m_ssThresh != tcb->m_ssThresh) {
	cnt = (int) (73.055*(tcb->m_segmentSize)*(67.864));
	tcb->m_segmentSize = (int) (cnt+(3.312)+(52.726)+(60.312)+(29.97)+(90.528)+(tcb->m_ssThresh)+(37.652));

} else {
	cnt = (int) (25.605*(28.301)*(4.068));

}
tcb->m_ssThresh = (int) (cnt+(54.898)+(52.213));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) ((0.829-(73.316)-(tcb->m_segmentSize)-(89.226)-(43.009)-(16.149)-(tcb->m_cWnd)-(18.64))/0.1);
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (60.108+(86.997)+(cnt)+(99.954)+(25.024));

} else {
	segmentsAcked = (int) (90.755+(91.435)+(88.229)+(24.222)+(95.497));
	cnt = (int) ((((33.555-(tcb->m_cWnd)-(segmentsAcked)-(tcb->m_segmentSize)))+((34.524*(73.699)*(97.068)*(13.401)*(22.103)))+(0.1)+(0.1))/((0.1)+(0.1)));

}
