float OslizSIoLwVFjuTe = (float) (-41.907-(-1.09)-(-5.158)-(-87.73)-(-20.275)-(60.662)-(72.063)-(-41.451)-(-60.965));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (17.837-(19.296)-(-74.381)-(0.125)-(-27.57)-(43.298));
segmentsAcked = (int) (-12.343/-88.396);
OslizSIoLwVFjuTe = (float) (-83.258/69.074);
tcb->m_segmentSize = (int) (72.112+(-84.368)+(-10.078)+(51.749)+(-3.912)+(-24.426)+(25.073));
