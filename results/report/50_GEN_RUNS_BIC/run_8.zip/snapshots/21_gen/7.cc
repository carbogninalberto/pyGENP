segmentsAcked = (int) (37.649*(83.956)*(-79.432)*(-44.431)*(-95.158)*(-16.884)*(-79.71)*(50.244));
int HudNJyGSxcwKvlGN = (int) (91.576-(71.004));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (19.931*(-26.977)*(85.172)*(-65.391)*(2.312)*(-23.567)*(96.115));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (32.934*(64.74)*(28.814)*(-45.146)*(-67.24)*(-78.988)*(38.62));
