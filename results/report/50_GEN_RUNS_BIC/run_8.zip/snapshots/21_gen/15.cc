cnt = (int) (((30.445)+((1.577-(4.598)-(tcb->m_segmentSize)-(30.647)))+(0.1)+(51.466))/((20.354)+(73.937)+(77.953)+(0.1)+(0.1)));
cnt = (int) (98.162-(13.284)-(11.445)-(6.519)-(66.161)-(2.643)-(12.735)-(tcb->m_cWnd));
segmentsAcked = (int) (65.566/0.1);
tcb->m_segmentSize = (int) (0.963-(81.731)-(cnt)-(36.675)-(54.402)-(31.466)-(28.516)-(75.068)-(38.339));
int JLAousOhPdcjiMNq = (int) (segmentsAcked*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(96.28));
