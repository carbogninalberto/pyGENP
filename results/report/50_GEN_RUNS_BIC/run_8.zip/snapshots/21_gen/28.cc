if (segmentsAcked == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+(10.438)+((29.236-(18.204)))+((69.52*(segmentsAcked)*(48.66)*(97.539)*(49.307)*(32.38)))+(2.33)+(0.1))/((0.1)+(22.229)+(41.375)));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (47.44+(12.695)+(cnt)+(47.832)+(47.845)+(22.248)+(11.78)+(17.899)+(52.438));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (6.657+(2.298)+(87.675)+(85.379));

}
float YXTsQNQknwnpopHA = (float) (84.745+(81.089)+(70.86));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (60.045/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (85.691/0.1);
segmentsAcked = (int) (tcb->m_segmentSize-(cnt)-(74.168)-(21.674)-(53.354));
YXTsQNQknwnpopHA = (float) (((92.122)+(97.124)+(0.1)+(0.1))/((78.237)));
segmentsAcked = (int) (((0.1)+(0.1)+(10.081)+(47.473)+(14.071))/((0.1)+(15.412)));
