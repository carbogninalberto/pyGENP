tcb->m_cWnd = (int) (33.705-(39.542)-(96.314));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked <= cnt) {
	tcb->m_segmentSize = (int) (18.583-(17.376)-(60.633)-(41.377)-(46.091));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) ((65.357+(23.614)+(92.05)+(75.307)+(15.228))/65.473);

}
if (cnt > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(38.875)+(12.938)+(70.096)+(segmentsAcked)+(tcb->m_ssThresh)+(55.849));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) ((((93.513+(68.168)+(29.899)+(69.193)+(61.213)+(cnt)))+((74.293-(30.788)))+(7.592)+(0.1)+(75.086)+(60.652))/((0.1)));

}
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (91.481/0.1);
	tcb->m_ssThresh = (int) (0.1/31.2);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (86.21+(34.384)+(cnt)+(95.21)+(36.998));
	segmentsAcked = (int) (((18.146)+(0.1)+(0.1)+(84.486))/((84.701)+(7.378)+(0.1)+(0.1)));

}
