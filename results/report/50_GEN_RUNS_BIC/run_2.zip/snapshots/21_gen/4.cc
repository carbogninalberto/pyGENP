int gvdSydQeRMdQwnUn = (int) 83.29;
