tcb->m_ssThresh = (int) (61.999+(tcb->m_cWnd));
segmentsAcked = (int) (0.1/0.1);
if (cnt <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (87.704*(87.538)*(7.53)*(66.603));
	segmentsAcked = (int) (54.288+(2.301)+(78.166)+(38.585)+(94.47)+(14.256)+(54.378)+(61.288));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (26.699-(8.334)-(54.396)-(segmentsAcked));

}
if (cnt == tcb->m_segmentSize) {
	segmentsAcked = (int) (95.476-(60.505)-(62.385));
	tcb->m_ssThresh = (int) (0.1/0.1);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (27.083*(73.261));
	segmentsAcked = (int) (segmentsAcked*(61.833)*(57.253)*(segmentsAcked)*(35.813)*(6.15)*(69.095)*(47.373));

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (67.357*(47.004)*(15.357)*(80.935));
	cnt = (int) (tcb->m_segmentSize+(90.161)+(47.674)+(42.697)+(0.993)+(tcb->m_cWnd)+(27.321));

} else {
	tcb->m_segmentSize = (int) (cnt*(29.336)*(93.539)*(58.226)*(0.971));
	ReduceCwnd (tcb);

}
