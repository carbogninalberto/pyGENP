tcb->m_ssThresh = (int) (1.716*(segmentsAcked)*(cnt)*(83.654));
if (segmentsAcked <= tcb->m_ssThresh) {
	segmentsAcked = (int) (((87.819)+((segmentsAcked*(segmentsAcked)*(7.226)*(17.728)*(18.702)*(33.778)))+(0.1)+(0.1)+(75.363)+(24.884))/((0.1)));
	segmentsAcked = (int) (2.358*(28.184)*(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(81.322))/((25.055)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (46.444-(56.963)-(tcb->m_cWnd));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(41.797)-(52.812)-(14.967)-(9.431)-(cnt)-(4.871)-(70.886));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
