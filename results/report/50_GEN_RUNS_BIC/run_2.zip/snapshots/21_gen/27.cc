ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	cnt = (int) (0.1/50.59);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (61.743+(77.897)+(60.667)+(31.895));

}
ReduceCwnd (tcb);
