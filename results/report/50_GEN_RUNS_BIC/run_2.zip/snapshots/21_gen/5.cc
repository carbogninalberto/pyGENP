tcb->m_segmentSize = (int) (81.292*(82.338)*(-28.568));
