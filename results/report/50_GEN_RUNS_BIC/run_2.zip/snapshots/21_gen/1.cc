tcb->m_cWnd = (int) (23.798-(78.405)-(-28.502)-(23.598)-(65.723)-(-51.977)-(14.682)-(58.155));
int zoAhEbvPbFkYvSou = (int) (93.211-(-81.232)-(35.848)-(26.902)-(-32.792)-(-98.108)-(-59.04)-(-61.769));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-94.786-(-72.757));
