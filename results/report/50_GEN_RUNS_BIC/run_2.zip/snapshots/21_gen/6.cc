int zoAhEbvPbFkYvSou = (int) 94.919;
tcb->m_cWnd = (int) (16.494-(76.401)-(-48.915)-(13.555)-(92.277)-(92.965)-(80.658)-(-48.934));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-6.337-(69.9));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
