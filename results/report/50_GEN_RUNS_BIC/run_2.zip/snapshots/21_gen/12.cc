segmentsAcked = (int) (71.036/0.1);
cnt = (int) (82.323+(cnt)+(27.02)+(90.606)+(17.503)+(26.208)+(15.154)+(1.105));
tcb->m_cWnd = (int) (13.392/60.201);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (tcb->m_ssThresh+(43.756)+(98.473)+(91.536)+(21.923)+(24.959)+(70.789)+(43.843)+(segmentsAcked));
