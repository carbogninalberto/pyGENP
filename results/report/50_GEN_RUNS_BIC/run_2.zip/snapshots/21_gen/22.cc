int WcOMLDMcOCVCFYrs = (int) (82.007+(34.81)+(33.789)+(12.993)+(segmentsAcked)+(33.648)+(41.436)+(95.448));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (WcOMLDMcOCVCFYrs < WcOMLDMcOCVCFYrs) {
	cnt = (int) (10.423*(59.769)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(7.312)*(38.492)*(62.479)*(tcb->m_segmentSize)*(35.626));

} else {
	cnt = (int) ((13.285-(segmentsAcked)-(43.517)-(13.569)-(16.868))/32.081);
	tcb->m_ssThresh = (int) (64.726-(78.115)-(WcOMLDMcOCVCFYrs)-(29.471));

}
if (WcOMLDMcOCVCFYrs < cnt) {
	tcb->m_ssThresh = (int) ((96.968+(20.026)+(63.899)+(30.007)+(78.363)+(90.346)+(tcb->m_cWnd)+(cnt))/0.1);

} else {
	tcb->m_ssThresh = (int) (((60.019)+(31.61)+(0.1)+(51.511)+(17.462))/((98.479)));

}
tcb->m_segmentSize = (int) (22.9+(33.98)+(25.742)+(WcOMLDMcOCVCFYrs)+(72.147)+(34.176)+(9.997)+(cnt)+(70.564));
cnt = (int) (24.952-(7.915)-(20.425)-(94.163)-(48.327)-(62.675)-(31.919)-(32.04)-(91.24));
int jRuvMjkCpXVVozOr = (int) (60.073-(33.652)-(14.477)-(tcb->m_ssThresh));
tcb->m_cWnd = (int) (((68.92)+(0.1)+(0.1)+(40.271)+(71.445))/((0.1)));
