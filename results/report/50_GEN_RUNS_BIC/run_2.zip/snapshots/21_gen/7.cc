int KSHjXfiYtTCgnSgK = (int) (75.307+(18.204)+(48.958)+(-67.233)+(70.897)+(39.544)+(12.403)+(83.928)+(51.709));
tcb->m_segmentSize = (int) (-89.452+(86.481)+(-26.926)+(22.919)+(71.916));
tcb->m_segmentSize = (int) (69.731+(-64.982)+(0.941)+(-54.469)+(-62.449));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
