if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked == cnt) {
	segmentsAcked = (int) (37.541/73.649);
	tcb->m_ssThresh = (int) (19.646*(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (77.962-(32.824)-(tcb->m_segmentSize)-(segmentsAcked)-(cnt)-(48.73));

}
cnt = (int) (58.88+(tcb->m_segmentSize)+(37.255)+(26.606)+(35.313)+(5.408));
cnt = (int) (58.798-(tcb->m_ssThresh)-(16.15)-(tcb->m_segmentSize)-(38.078)-(21.974)-(10.355)-(78.917));
if (tcb->m_cWnd < tcb->m_cWnd) {
	segmentsAcked = (int) (45.989-(2.174)-(97.305)-(5.535)-(95.744)-(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (0.1/49.002);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (99.949-(61.687)-(9.573)-(tcb->m_cWnd)-(57.597)-(segmentsAcked)-(segmentsAcked)-(81.212)-(cnt));

}
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (15.782+(58.778)+(47.306)+(96.268)+(30.013));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (1.785*(segmentsAcked)*(tcb->m_segmentSize)*(48.416)*(tcb->m_ssThresh));

}
