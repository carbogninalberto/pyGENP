tcb->m_ssThresh = (int) (25.311/0.1);
segmentsAcked = (int) (42.451+(29.34));
tcb->m_segmentSize = (int) (62.762-(81.546)-(tcb->m_cWnd)-(54.041)-(33.919)-(40.696)-(6.502));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked != cnt) {
	segmentsAcked = (int) (81.905+(94.438)+(segmentsAcked)+(41.266)+(77.196)+(tcb->m_ssThresh)+(60.039));
	tcb->m_cWnd = (int) (24.508+(37.172)+(22.812)+(50.61)+(49.353)+(14.648));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (37.687+(42.276)+(37.585)+(32.378)+(51.48));
	tcb->m_segmentSize = (int) (7.449-(19.088)-(42.904));

}
