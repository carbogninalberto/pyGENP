if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (70.681+(-76.951)+(58.74));
tcb->m_cWnd = (int) (45.278+(-45.901)+(17.521));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(5.947)*(39.944)*(9.886)*(29.857)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-43.558)*(64.457))/41.175);
tcb->m_cWnd = (int) ((segmentsAcked*(39.031)*(-62.969)*(-55.621)*(-16.503)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(25.852)*(-86.663))/-58.027);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
