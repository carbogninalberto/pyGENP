if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (14.713-(44.636)-(10.84)-(0.808));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(24.17)*(tcb->m_segmentSize)*(36.07)*(1.48)*(76.928)*(tcb->m_segmentSize)*(6.557)*(53.22));
	segmentsAcked = (int) (4.407*(37.677)*(cnt)*(59.643)*(3.399)*(49.394)*(23.801));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	cnt = (int) (((0.1)+(2.471)+((26.158*(tcb->m_segmentSize)*(19.165)*(31.984)*(tcb->m_cWnd)*(9.524)*(9.646)*(71.937)*(tcb->m_cWnd)))+((11.574+(4.39)+(38.321)+(tcb->m_segmentSize)+(20.466)))+(15.447))/((0.1)));
	segmentsAcked = (int) ((2.95*(17.101)*(83.112)*(77.326))/33.639);

} else {
	cnt = (int) (0.1/0.1);

}
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (61.532-(32.504)-(15.549)-(18.83)-(tcb->m_ssThresh)-(63.947)-(65.06)-(21.346));

} else {
	tcb->m_ssThresh = (int) (0.1/21.385);
	segmentsAcked = (int) ((19.073*(cnt)*(89.02)*(cnt)*(93.791)*(61.125))/57.002);
	segmentsAcked = (int) (((85.598)+(0.1)+(0.1)+(0.1)+(77.33)+(0.1)+(0.1))/((0.1)+(65.715)));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (90.6-(69.845)-(40.686)-(segmentsAcked)-(36.141)-(56.771));
tcb->m_segmentSize = (int) (12.19*(0.769)*(56.344)*(36.868)*(segmentsAcked)*(80.145)*(96.708)*(segmentsAcked)*(70.361));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
