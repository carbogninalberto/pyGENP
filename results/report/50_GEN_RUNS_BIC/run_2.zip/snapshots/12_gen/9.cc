ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (86.214+(-57.3)+(1.436)+(-31.156)+(-37.764)+(89.914));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
