tcb->m_cWnd = (int) (87.871-(80.523)-(87.528)-(54.721)-(69.658));
float fWwxXbYVRGAcxkml = (float) (90.396*(4.403)*(78.602)*(36.229)*(81.846));
if (fWwxXbYVRGAcxkml < tcb->m_ssThresh) {
	segmentsAcked = (int) (56.547/11.654);
	segmentsAcked = (int) (73.408-(81.005)-(11.53)-(76.899)-(59.126));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (15.134+(96.725)+(40.479)+(50.917)+(26.459)+(2.313)+(70.047)+(segmentsAcked)+(64.802));

} else {
	tcb->m_cWnd = (int) (((0.1)+(67.171)+(62.148)+(84.471))/((44.96)+(81.997)+(0.1)));

}
segmentsAcked = (int) (((0.1)+(54.883)+(50.759)+(21.99)+(16.927)+(89.756))/((71.29)));
tcb->m_segmentSize = (int) (24.561+(tcb->m_cWnd)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(71.207)+(cnt)+(89.391)+(tcb->m_ssThresh));
