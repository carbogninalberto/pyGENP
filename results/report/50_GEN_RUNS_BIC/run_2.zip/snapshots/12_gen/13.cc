int WqjkmZYpxMoZOQcm = (int) (-83.393/30.165);
float vSVYNLGluEluivEi = (float) (-35.85*(25.312)*(85.434)*(-11.574)*(60.479)*(-47.206)*(58.1));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
