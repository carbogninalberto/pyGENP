if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-94.709+(24.002)+(79.529));
tcb->m_cWnd = (int) ((segmentsAcked*(-13.374)*(27.325)*(-12.934)*(61.883)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-93.39)*(-51.975))/21.952);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-73.307)*(83.651)*(-90.364)*(-88.253)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(10.304)*(-81.968))/-90.137);
tcb->m_cWnd = (int) ((segmentsAcked*(83.955)*(84.253)*(-54.202)*(65.008)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-14.593)*(34.741))/-71.566);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-2.418)*(-81.026)*(-11.143)*(61.055)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-65.678)*(-50.906))/-34.839);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-41.901)*(-33.336)*(-12.319)*(-76.008)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-54.12)*(-24.359))/-20.046);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
