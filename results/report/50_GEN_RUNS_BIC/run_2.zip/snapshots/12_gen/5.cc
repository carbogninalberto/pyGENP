float qZfiLaLybZdQDwRK = (float) (27.601/-90.977);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) ((((53.439+(-97.94)+(tcb->m_ssThresh)+(96.73)+(-65.77)+(19.676)+(-77.547)+(47.285)))+((tcb->m_cWnd-(-97.01)-(31.755)-(-86.736)-(-31.33)-(36.436)-(-9.337)-(-96.815)-(95.786)))+(26.279)+(78.623))/((-86.698)));
ReduceCwnd (tcb);
