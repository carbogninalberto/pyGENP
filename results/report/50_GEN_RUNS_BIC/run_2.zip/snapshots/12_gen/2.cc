if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (38.086+(-66.659)+(-8.896));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(55.27)*(-35.017)*(-32.184)*(91.488)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(43.39)*(-77.432))/-99.306);
tcb->m_cWnd = (int) ((segmentsAcked*(-67.158)*(56.019)*(-53.951)*(74.83)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(59.08)*(18.842))/-40.62);
tcb->m_cWnd = (int) ((segmentsAcked*(-82.27)*(75.895)*(-15.298)*(-99.316)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-0.618)*(-92.29))/75.873);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (58.777+(-16.256)+(-31.148));
tcb->m_cWnd = (int) ((segmentsAcked*(53.724)*(47.458)*(-48.422)*(70.399)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-24.788)*(-13.959))/-67.089);
tcb->m_cWnd = (int) ((segmentsAcked*(-95.987)*(67.366)*(76.154)*(-84.899)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(56.092)*(2.074))/-39.345);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(16.475)*(-82.925)*(65.742)*(-43.163)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-21.673)*(-29.003))/-68.205);
tcb->m_cWnd = (int) ((segmentsAcked*(-55.291)*(60.954)*(-73.606)*(-7.107)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(14.584)*(-12.26))/-26.365);
tcb->m_cWnd = (int) ((segmentsAcked*(82.199)*(-35.117)*(29.625)*(-23.55)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-35.042)*(-83.304))/39.505);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (98.163+(84.16)+(-3.617));
tcb->m_cWnd = (int) ((segmentsAcked*(-52.217)*(-64.745)*(31.725)*(96.37)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(71.571)*(9.275))/-33.56);
tcb->m_cWnd = (int) ((segmentsAcked*(18.214)*(-11.607)*(-69.556)*(17.755)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-31.835)*(17.765))/-81.458);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-14.004)*(-66.082)*(85.896)*(79.594)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(55.465)*(63.438))/-8.719);
tcb->m_cWnd = (int) ((segmentsAcked*(-9.99)*(-37.776)*(-30.261)*(-66.493)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-31.412)*(-39.233))/17.679);
tcb->m_cWnd = (int) ((segmentsAcked*(-42.71)*(-17.915)*(-89.871)*(-76.481)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(19.485)*(65.624))/66.954);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-82.037)*(-65.689)*(84.336)*(82.715)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-51.758)*(-71.826))/86.436);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-74.598+(-6.094)+(-58.43));
tcb->m_cWnd = (int) ((segmentsAcked*(44.592)*(19.294)*(40.873)*(-37.372)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(39.265)*(-21.11))/18.765);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(76.114)*(91.749)*(-61.456)*(44.844)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(15.265)*(87.106))/-34.534);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-71.133)*(-88.73)*(44.318)*(39.904)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(12.523)*(40.01))/-29.696);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
