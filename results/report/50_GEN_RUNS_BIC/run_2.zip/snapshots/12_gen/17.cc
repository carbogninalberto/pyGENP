float cIYUpDTQXiySPHIv = (float) (segmentsAcked-(67.358)-(94.614));
tcb->m_cWnd = (int) (33.628/0.1);
if (cIYUpDTQXiySPHIv == tcb->m_cWnd) {
	cIYUpDTQXiySPHIv = (float) ((84.164-(44.408))/(12.698-(46.728)-(25.202)-(55.747)-(cIYUpDTQXiySPHIv)));
	cIYUpDTQXiySPHIv = (float) (((3.566)+((51.74*(89.501)*(cIYUpDTQXiySPHIv)*(99.925)*(48.683)*(tcb->m_ssThresh)*(69.06)*(3.22)*(77.914)))+(90.565)+(8.619))/((0.1)+(31.385)+(3.461)+(31.805)));

} else {
	cIYUpDTQXiySPHIv = (float) (81.014+(segmentsAcked)+(80.845)+(cnt)+(18.861));
	segmentsAcked = (int) (14.653-(14.862)-(segmentsAcked)-(69.503));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize > cnt) {
	tcb->m_cWnd = (int) (1.406*(0.26)*(53.154)*(42.46)*(85.505)*(cIYUpDTQXiySPHIv)*(89.159)*(65.106));

} else {
	tcb->m_cWnd = (int) (45.002-(40.469)-(80.805)-(24.556)-(74.306));

}
ReduceCwnd (tcb);
