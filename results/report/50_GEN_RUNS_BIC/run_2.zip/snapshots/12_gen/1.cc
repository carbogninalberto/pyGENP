if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (76.016+(-53.041)+(0.551));
tcb->m_cWnd = (int) ((segmentsAcked*(-1.371)*(21.995)*(57.402)*(-78.748)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-54.656)*(68.033))/75.178);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-4.13)*(-2.483)*(79.471)*(-9.45)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(30.119)*(67.334))/40.458);
tcb->m_cWnd = (int) ((segmentsAcked*(22.796)*(90.309)*(-31.162)*(49.341)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(22.938)*(-42.341))/-9.864);
tcb->m_cWnd = (int) ((segmentsAcked*(-88.072)*(-63.004)*(-68.617)*(-4.48)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(7.306)*(25.932))/-37.34);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(48.937)*(28.286)*(-7.141)*(-91.012)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-89.48)*(-18.52))/26.217);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(91.528)*(-81.347)*(1.572)*(-12.386)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-9.675)*(76.885))/26.633);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-80.001)*(50.5)*(86.871)*(-52.141)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(70.452)*(-32.722))/44.527);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
