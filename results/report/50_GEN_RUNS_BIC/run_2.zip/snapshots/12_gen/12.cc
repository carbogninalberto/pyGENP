if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (61.736+(-69.474)+(6.514));
tcb->m_cWnd = (int) ((segmentsAcked*(-35.721)*(50.467)*(11.077)*(68.139)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-8.672)*(83.248))/12.468);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-41.958)*(41.619)*(-98.035)*(-69.038)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-60.652)*(10.397))/-20.7);
tcb->m_cWnd = (int) ((segmentsAcked*(93.851)*(4.951)*(40.361)*(-23.791)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-44.518)*(-85.379))/21.301);
tcb->m_cWnd = (int) ((segmentsAcked*(73.78)*(52.23)*(-25.009)*(29.468)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-26.466)*(-86.032))/-42.495);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-61.734)*(-24.636)*(-12.236)*(30.318)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-99.603)*(26.23))/-71.922);
tcb->m_cWnd = (int) ((segmentsAcked*(30.072)*(-29.228)*(64.368)*(45.222)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-65.999)*(98.355))/-23.239);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-25.708)*(13.997)*(-86.91)*(89.159)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-1.543)*(-47.353))/-47.541);
tcb->m_cWnd = (int) ((segmentsAcked*(75.309)*(-58.834)*(47.854)*(-86.255)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-62.815)*(23.646))/34.239);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-71.251)*(-20.838)*(62.085)*(52.023)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(99.57)*(-47.742))/-51.707);
tcb->m_cWnd = (int) ((segmentsAcked*(-83.611)*(-88.38)*(8.064)*(-59.997)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(62.584)*(-28.161))/-98.453);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
