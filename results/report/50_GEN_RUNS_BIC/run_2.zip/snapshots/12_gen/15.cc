cnt = (int) (35.865-(12.241)-(63.44)-(93.327)-(11.266)-(2.458)-(51.693));
tcb->m_ssThresh = (int) (5.683-(20.856)-(18.714)-(58.896)-(23.157)-(43.172));
if (segmentsAcked <= segmentsAcked) {
	cnt = (int) (65.332-(37.225)-(14.618)-(tcb->m_cWnd)-(77.676)-(16.485)-(79.916)-(tcb->m_segmentSize));

} else {
	cnt = (int) (20.806+(tcb->m_cWnd)+(14.982));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (89.25-(81.757)-(82.208)-(7.15)-(75.28)-(69.887)-(91.838)-(59.055)-(33.12));

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	segmentsAcked = (int) ((((55.677*(15.413)*(6.141)*(98.362)))+(0.1)+(0.1)+(36.015))/((27.197)+(0.1)+(0.1)+(46.32)+(0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (98.07*(72.988)*(tcb->m_segmentSize)*(81.203)*(92.3)*(28.75)*(73.346)*(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (41.005+(tcb->m_ssThresh)+(12.635)+(3.98)+(60.041));
