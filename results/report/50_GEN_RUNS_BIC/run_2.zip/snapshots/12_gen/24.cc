ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (tcb->m_cWnd+(44.655)+(47.649)+(50.61)+(54.686)+(92.395)+(segmentsAcked));
tcb->m_segmentSize = (int) ((((cnt-(13.73)-(47.862)-(22.87)-(71.159)-(98.813)-(71.939)-(73.579)-(39.626)))+(35.315)+(0.1)+(76.967)+(40.473)+(20.326))/((0.1)));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (37.764*(48.178)*(3.3)*(tcb->m_segmentSize)*(56.237)*(78.284));

} else {
	tcb->m_segmentSize = (int) (21.519-(cnt)-(85.676)-(92.526)-(54.123)-(85.536)-(tcb->m_cWnd));
	segmentsAcked = (int) (18.688-(50.909)-(1.886)-(28.943)-(segmentsAcked)-(40.601)-(56.261));
	tcb->m_cWnd = (int) (4.099-(32.777)-(tcb->m_cWnd)-(70.204)-(97.466)-(89.304)-(3.354)-(tcb->m_cWnd));

}
if (segmentsAcked > cnt) {
	tcb->m_ssThresh = (int) (40.628+(13.878)+(5.088)+(tcb->m_cWnd)+(cnt));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (75.089-(cnt)-(85.544)-(85.374)-(4.974)-(tcb->m_ssThresh)-(16.394)-(segmentsAcked));
	tcb->m_ssThresh = (int) (0.995*(29.893));

}
