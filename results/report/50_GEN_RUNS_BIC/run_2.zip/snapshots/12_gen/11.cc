float gJhhdQnZYlyQjdCp = (float) 40.838;
ReduceCwnd (tcb);
gJhhdQnZYlyQjdCp = (float) (17.238+(97.041));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-84.117+(55.118)+(30.608)+(48.395)+(78.996)+(-81.057));
