if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-92.777-(30.659)-(-55.765)-(-18.909));
segmentsAcked = (int) (-2.789/-72.758);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (11.522-(-1.248)-(-63.722)-(30.17));
segmentsAcked = (int) (26.749/7.758);
