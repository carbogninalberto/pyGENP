int cyVHCWCVhRLbtxFx = (int) (99.349*(74.834)*(9.246)*(26.647)*(cnt));
tcb->m_cWnd = (int) (10.192-(33.934)-(62.085)-(83.748)-(40.387)-(79.195)-(49.362)-(cyVHCWCVhRLbtxFx)-(80.037));
float yssuzLBAvXSWFsuQ = (float) (82.318-(64.8)-(38.924)-(76.328)-(7.979));
ReduceCwnd (tcb);
float OwVQXfXHOnyhnMsE = (float) (59.719*(tcb->m_segmentSize)*(56.733));
if (tcb->m_segmentSize < cnt) {
	cnt = (int) (90.552-(89.552)-(65.111)-(7.057)-(38.629));
	cnt = (int) (((94.477)+(49.593)+(55.143)+(6.023)+(0.1))/((99.577)));

} else {
	cnt = (int) (3.113*(65.733)*(71.844)*(tcb->m_cWnd)*(OwVQXfXHOnyhnMsE)*(99.248)*(cnt)*(segmentsAcked));
	tcb->m_cWnd = (int) (88.58-(26.762)-(cyVHCWCVhRLbtxFx)-(segmentsAcked)-(61.95)-(42.528)-(40.512)-(67.724)-(61.253));
	ReduceCwnd (tcb);

}
