if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (67.194+(tcb->m_segmentSize)+(22.984)+(45.706));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (29.746+(63.209)+(74.242)+(46.984)+(85.622)+(14.091)+(tcb->m_ssThresh)+(67.772)+(63.621));
cnt = (int) (tcb->m_cWnd-(99.253));
