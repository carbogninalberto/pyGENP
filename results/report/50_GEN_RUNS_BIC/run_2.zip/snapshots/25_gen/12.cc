cnt = (int) ((tcb->m_ssThresh+(27.778)+(93.853)+(52.796)+(99.937)+(24.366)+(61.345)+(45.571))/0.1);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (9.915+(54.055)+(tcb->m_ssThresh)+(54.154)+(2.962)+(57.459));
tcb->m_cWnd = (int) (37.058-(85.639)-(39.56)-(82.241)-(9.288)-(cnt)-(56.503));
tcb->m_ssThresh = (int) (75.625+(89.974)+(84.406)+(76.993)+(tcb->m_ssThresh)+(98.383)+(30.145)+(90.965));
tcb->m_segmentSize = (int) (2.572/0.1);
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_ssThresh = (int) (68.076*(tcb->m_cWnd)*(cnt)*(69.58)*(34.737));

} else {
	tcb->m_ssThresh = (int) (25.633*(77.62)*(73.929)*(7.041)*(22.117)*(50.174)*(segmentsAcked));
	tcb->m_segmentSize = (int) (14.814-(81.016)-(21.305)-(14.83)-(2.182)-(66.96)-(92.395)-(0.317));

}
int BVrDGmbuuXBtDuhr = (int) (49.172/(73.053+(94.05)+(99.411)));
