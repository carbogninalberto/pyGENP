if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (79.713+(82.164)+(20.399)+(26.235)+(57.782)+(6.022)+(tcb->m_ssThresh)+(tcb->m_cWnd));
if (cnt >= tcb->m_cWnd) {
	segmentsAcked = (int) (89.5+(10.991)+(56.294)+(10.573)+(54.441)+(39.577)+(68.77));
	tcb->m_segmentSize = (int) (cnt*(44.569));

} else {
	segmentsAcked = (int) (19.304+(95.108)+(tcb->m_ssThresh)+(78.926)+(29.381)+(tcb->m_segmentSize)+(67.777)+(31.624));
	segmentsAcked = (int) (83.469+(97.353)+(32.316)+(46.621)+(2.225)+(48.898)+(98.058)+(81.596));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (57.691+(81.617)+(79.369));
tcb->m_segmentSize = (int) (segmentsAcked*(16.97));
float BtVXevCrvKGgiacQ = (float) (0.1/49.009);
