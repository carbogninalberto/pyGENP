int KAUPcoEusYGDhmgq = (int) (0.1/0.1);
ReduceCwnd (tcb);
if (tcb->m_cWnd <= KAUPcoEusYGDhmgq) {
	tcb->m_segmentSize = (int) (30.495/69.572);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (31.685+(70.898)+(38.66)+(17.257)+(29.504)+(56.804)+(74.721)+(48.96));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) ((7.428+(65.351)+(16.986)+(38.691)+(90.101)+(68.16)+(68.295)+(17.149))/21.327);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
