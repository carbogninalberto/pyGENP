if (tcb->m_segmentSize < tcb->m_cWnd) {
	cnt = (int) (91.259*(53.182)*(tcb->m_segmentSize)*(20.532)*(46.469)*(32.369)*(43.68)*(96.206));
	cnt = (int) (25.542*(17.596));

} else {
	cnt = (int) (tcb->m_segmentSize-(36.174)-(15.983)-(77.458));

}
if (cnt != segmentsAcked) {
	tcb->m_segmentSize = (int) (31.811*(73.903)*(23.991)*(93.791)*(15.862)*(34.591));
	tcb->m_ssThresh = (int) (61.421+(44.228)+(51.828)+(54.735));

} else {
	tcb->m_segmentSize = (int) (85.33*(77.038)*(tcb->m_ssThresh));
	cnt = (int) (31.007-(tcb->m_ssThresh)-(33.965));

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.295*(40.447)*(80.251)*(37.974)*(87.264)*(45.111));

} else {
	tcb->m_ssThresh = (int) (69.881-(87.326)-(73.704)-(9.768)-(5.778)-(90.567)-(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (20.847+(cnt)+(26.1)+(56.031)+(tcb->m_cWnd)+(36.583)+(53.633)+(38.002)+(91.361));

}
int nLQlTPePPTalYvTJ = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(0.1)+((26.443+(86.552)+(tcb->m_segmentSize)+(68.432)+(20.727)+(44.367)))+(97.268))/((0.1)));
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (77.475+(nLQlTPePPTalYvTJ)+(23.651)+(73.574)+(75.559));

} else {
	tcb->m_segmentSize = (int) (48.453-(94.514)-(80.133)-(tcb->m_ssThresh)-(72.121)-(tcb->m_segmentSize));
	ReduceCwnd (tcb);

}
