int ONOJKeiSBTthUBPt = (int) (-12.76/-90.264);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
