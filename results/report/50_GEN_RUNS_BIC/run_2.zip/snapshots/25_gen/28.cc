float ZWsRpfJGKNzPrQQU = (float) (49.675*(77.773)*(42.145)*(20.675)*(9.242)*(2.879)*(tcb->m_segmentSize)*(64.347)*(63.899));
segmentsAcked = (int) (72.302-(63.178));
ReduceCwnd (tcb);
if (ZWsRpfJGKNzPrQQU < segmentsAcked) {
	tcb->m_cWnd = (int) (segmentsAcked+(segmentsAcked)+(94.831)+(8.944)+(29.672)+(1.931)+(30.937)+(35.734));
	tcb->m_cWnd = (int) (56.911+(ZWsRpfJGKNzPrQQU));
	segmentsAcked = (int) (((55.382)+(56.826)+((25.883+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(tcb->m_cWnd)))+(0.1)+(0.1))/((74.848)));

} else {
	tcb->m_cWnd = (int) (42.071*(59.455)*(47.952)*(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (24.504-(88.504)-(59.72)-(34.167)-(7.517)-(12.343)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(tcb->m_ssThresh));

}
int dOASOAsISnpLnLfW = (int) (11.579+(85.355)+(62.308));
cnt = (int) (92.811+(tcb->m_cWnd)+(86.787));
if (dOASOAsISnpLnLfW != segmentsAcked) {
	tcb->m_cWnd = (int) (ZWsRpfJGKNzPrQQU-(31.124)-(9.317)-(76.761)-(99.574)-(8.0)-(63.146));

} else {
	tcb->m_cWnd = (int) (27.952*(53.276)*(69.295));
	ReduceCwnd (tcb);

}
