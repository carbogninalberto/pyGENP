ReduceCwnd (tcb);
segmentsAcked = (int) (15.325*(tcb->m_cWnd));
if (tcb->m_cWnd < segmentsAcked) {
	cnt = (int) (63.086+(94.169)+(51.218)+(55.297)+(tcb->m_segmentSize)+(98.056));
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	cnt = (int) (64.79-(segmentsAcked));

}
float ATQzxVCpXjRsNcqF = (float) (tcb->m_cWnd+(42.114)+(87.274)+(38.064)+(62.557));
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (97.796-(44.756)-(64.26)-(75.879)-(23.729));

} else {
	tcb->m_segmentSize = (int) (((21.336)+(0.1)+((cnt*(88.86)*(83.284)*(ATQzxVCpXjRsNcqF)*(1.133)*(95.229)*(5.753)*(68.92)))+(2.279))/((26.045)));
	tcb->m_ssThresh = (int) (37.996/3.572);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	segmentsAcked = (int) (95.471+(49.597)+(68.277)+(34.656)+(80.767)+(44.0)+(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) ((84.618+(51.385)+(88.76)+(21.98)+(tcb->m_segmentSize)+(56.008)+(17.487)+(17.247)+(45.305))/61.998);

}
float RZUEsZWnfVGhYtjB = (float) (64.842+(tcb->m_cWnd)+(23.429));
segmentsAcked = (int) (62.128/10.538);
