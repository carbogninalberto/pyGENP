int EloXQrrbqsaJtevx = (int) (98.698+(-35.868)+(52.619));
int XLjTHmHWiBVFXpZT = (int) (-71.608-(5.393)-(-90.079)-(79.013)-(2.278)-(72.634)-(87.072));
int ONOJKeiSBTthUBPt = (int) (-95.291/67.83);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ONOJKeiSBTthUBPt = (int) (82.181*(-12.674)*(-80.444)*(-65.679)*(65.793)*(-7.595)*(46.138)*(-80.687)*(60.314));
ONOJKeiSBTthUBPt = (int) (-94.711*(-14.791)*(-58.177)*(79.517)*(51.283)*(-99.092)*(-98.337)*(-68.903)*(-79.038));
