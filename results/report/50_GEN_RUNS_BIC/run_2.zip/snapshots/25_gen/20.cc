if (segmentsAcked < tcb->m_cWnd) {
	segmentsAcked = (int) (4.983*(53.988)*(98.945));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (64.599/0.1);

} else {
	segmentsAcked = (int) (95.262*(74.207)*(56.009)*(85.015)*(67.568)*(90.269)*(31.87));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(5.053)-(68.112)-(59.379)-(73.983)-(73.157)-(3.206)-(1.358));
	segmentsAcked = (int) (segmentsAcked+(11.035)+(97.311)+(tcb->m_cWnd)+(66.05)+(44.489)+(21.914));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int LLUBtrvAZgjsccWs = (int) (68.987/0.1);
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_cWnd*(59.506)*(56.107)*(84.515)*(tcb->m_segmentSize)*(22.548)*(40.389));
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (62.9-(62.822)-(36.522));
	tcb->m_segmentSize = (int) ((33.983*(47.692)*(4.824)*(69.705)*(LLUBtrvAZgjsccWs)*(cnt))/80.88);

} else {
	tcb->m_cWnd = (int) (61.513-(71.839));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (segmentsAcked-(39.258)-(2.346)-(21.325));
