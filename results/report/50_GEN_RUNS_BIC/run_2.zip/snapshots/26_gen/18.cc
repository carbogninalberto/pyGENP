segmentsAcked = (int) (segmentsAcked-(37.962));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) ((((tcb->m_segmentSize+(98.869)+(98.26)+(97.521)+(69.828)+(16.333)+(75.547)+(42.4)+(57.176)))+((17.343*(tcb->m_segmentSize)*(38.02)))+((cnt*(tcb->m_cWnd)*(76.575)*(8.157)*(74.304)*(81.815)*(20.577)))+(92.7)+(0.1))/((10.277)));
	tcb->m_ssThresh = (int) (76.857/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (19.992*(25.964)*(4.695)*(tcb->m_segmentSize)*(0.31)*(67.633));

}
cnt = (int) (69.739+(53.312));
