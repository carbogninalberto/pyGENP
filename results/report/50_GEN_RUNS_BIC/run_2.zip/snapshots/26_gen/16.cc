if (tcb->m_ssThresh < cnt) {
	tcb->m_ssThresh = (int) (36.458-(5.501)-(55.447)-(2.619));
	tcb->m_segmentSize = (int) (81.418+(40.228)+(4.915)+(28.301)+(20.204)+(tcb->m_segmentSize)+(19.118));
	tcb->m_segmentSize = (int) (61.13/96.143);

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
tcb->m_cWnd = (int) (4.369-(tcb->m_cWnd)-(15.961)-(38.588)-(81.916)-(30.561)-(8.905)-(53.978));
tcb->m_cWnd = (int) (0.1/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (63.336*(16.999)*(36.808));
