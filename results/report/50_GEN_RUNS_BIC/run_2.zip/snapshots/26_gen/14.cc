float gBOHLuYQAcQguOQb = (float) (tcb->m_ssThresh-(67.771)-(44.972)-(66.819)-(96.889));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
int tvNPkyyXeoqdQGtQ = (int) (92.105*(64.332)*(48.032)*(68.488)*(41.441)*(57.565)*(gBOHLuYQAcQguOQb)*(13.542)*(96.006));
if (tvNPkyyXeoqdQGtQ >= tvNPkyyXeoqdQGtQ) {
	cnt = (int) ((tcb->m_cWnd+(58.14)+(tcb->m_ssThresh)+(13.764)+(tcb->m_segmentSize)+(cnt)+(gBOHLuYQAcQguOQb)+(53.131))/33.786);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (52.907+(89.451)+(15.802)+(tvNPkyyXeoqdQGtQ)+(91.316)+(66.174));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= segmentsAcked) {
	gBOHLuYQAcQguOQb = (float) (1.633+(23.082)+(40.519));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (32.361+(47.91)+(90.52)+(67.313)+(50.098)+(tcb->m_segmentSize)+(75.913));

} else {
	gBOHLuYQAcQguOQb = (float) (46.625-(tcb->m_segmentSize));
	ReduceCwnd (tcb);

}
