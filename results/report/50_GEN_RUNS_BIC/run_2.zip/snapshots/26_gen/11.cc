if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (12.403-(39.233)-(10.255)-(11.408)-(66.235)-(90.206));

} else {
	tcb->m_ssThresh = (int) (6.992/9.964);

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (28.284*(65.296)*(63.196));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (41.632*(tcb->m_segmentSize)*(54.344)*(25.65));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (93.314*(22.902)*(38.508));

}
ReduceCwnd (tcb);
