ReduceCwnd (tcb);
int ToagYVKIjVQpLRHz = (int) (71.643*(52.758)*(79.631)*(tcb->m_cWnd)*(59.225)*(25.228)*(83.076)*(90.619));
float bWSVIIFeLSWROMqm = (float) (((90.008)+(1.83)+(0.1)+(0.1)+(53.428)+((60.872*(90.299)*(96.701)*(cnt)*(49.657)*(tcb->m_segmentSize)))+(0.1))/((0.1)+(0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (tcb->m_segmentSize+(91.557)+(67.832)+(82.076)+(11.696)+(tcb->m_segmentSize)+(68.613)+(88.657));
if (tcb->m_segmentSize != bWSVIIFeLSWROMqm) {
	segmentsAcked = (int) (30.904-(21.871)-(40.089));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (94.762*(tcb->m_segmentSize)*(1.083)*(39.744)*(tcb->m_ssThresh)*(6.682));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd < tcb->m_ssThresh) {
	cnt = (int) ((((59.516-(54.245)-(91.902)-(51.417)-(85.547)))+(21.077)+(0.1)+(0.1)+(0.1))/((0.1)+(43.654)+(25.792)+(0.1)));
	tcb->m_ssThresh = (int) (97.308*(5.049)*(37.033)*(24.277)*(77.816)*(6.843)*(ToagYVKIjVQpLRHz)*(35.45)*(81.435));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(2.964));

} else {
	cnt = (int) (54.555+(tcb->m_segmentSize)+(45.788)+(69.588)+(94.587));
	bWSVIIFeLSWROMqm = (float) (24.03-(tcb->m_ssThresh)-(51.629)-(35.86)-(82.019)-(69.439)-(40.0)-(57.886)-(52.988));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (bWSVIIFeLSWROMqm >= tcb->m_cWnd) {
	bWSVIIFeLSWROMqm = (float) (((0.1)+((93.364*(52.858)*(92.07)*(37.573)))+((28.653*(75.756)*(97.133)*(87.973)*(bWSVIIFeLSWROMqm)))+(47.184)+(0.1)+(0.1))/((48.0)));

} else {
	bWSVIIFeLSWROMqm = (float) (95.657+(29.9)+(tcb->m_ssThresh)+(99.906)+(9.796)+(23.046));
	segmentsAcked = (int) (51.948/46.261);

}
