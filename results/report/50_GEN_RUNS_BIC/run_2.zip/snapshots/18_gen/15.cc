tcb->m_cWnd = (int) (52.419/0.1);
tcb->m_segmentSize = (int) (41.762*(12.087)*(49.52)*(36.027)*(92.249));
int zKYHJURDfomNYmzf = (int) (26.131*(90.898)*(26.496)*(82.494)*(segmentsAcked)*(1.133)*(1.726)*(98.738));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (51.824*(69.722)*(tcb->m_cWnd)*(77.381)*(96.129)*(6.528));

} else {
	tcb->m_segmentSize = (int) (cnt*(zKYHJURDfomNYmzf)*(40.981));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
zKYHJURDfomNYmzf = (int) (segmentsAcked+(94.874)+(52.733)+(13.829)+(25.874));
