ReduceCwnd (tcb);
tcb->m_cWnd = (int) ((-5.239*(15.576)*(98.253))/5.786);
