float NdLKqPkguFlbPnEP = (float) ((90.32*(37.735)*(56.601)*(90.642)*(-78.954)*(-79.649)*(-59.117)*(-11.737))/-32.364);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-99.917+(78.181)+(40.753)+(78.408)+(94.285)+(-65.021)+(64.658)+(-98.199)+(-68.209));
