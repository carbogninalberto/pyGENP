int lbbLHrOcKKTVKcNJ = (int) (-43.08*(-91.682));
float uDkOfIoFTAIRZfYt = (float) (-64.08/60.826);
