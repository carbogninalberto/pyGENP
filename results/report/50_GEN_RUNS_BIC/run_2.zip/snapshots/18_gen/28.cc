tcb->m_segmentSize = (int) (((0.1)+(88.371)+(0.1)+(67.633))/((0.1)+(6.623)+(0.1)));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (52.006+(31.038)+(31.288));
tcb->m_ssThresh = (int) (12.708*(80.259));
tcb->m_segmentSize = (int) (58.302*(96.832)*(16.802)*(73.344)*(73.2));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int ezJcMElieAcdlUtb = (int) (69.699-(31.638)-(99.545)-(cnt)-(31.204)-(59.721)-(78.888)-(tcb->m_ssThresh));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
