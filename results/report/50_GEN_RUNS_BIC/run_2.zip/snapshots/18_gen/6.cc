if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float mVkcUfXByVZLZtxy = (float) (45.792+(43.436)+(45.129)+(63.214)+(48.2)+(50.565));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
