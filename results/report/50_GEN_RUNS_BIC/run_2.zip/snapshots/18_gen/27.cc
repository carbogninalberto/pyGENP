ReduceCwnd (tcb);
segmentsAcked = (int) (6.174-(80.428));
segmentsAcked = (int) (95.579-(72.312));
int WennwpPOOvrMTfzL = (int) (0.1/91.527);
if (cnt > tcb->m_segmentSize) {
	WennwpPOOvrMTfzL = (int) (18.676-(85.434)-(segmentsAcked)-(tcb->m_cWnd)-(cnt)-(80.064));
	cnt = (int) (75.949*(16.1));

} else {
	WennwpPOOvrMTfzL = (int) (71.943-(82.47));

}
int eRcAjSmVJpeRpkPi = (int) (WennwpPOOvrMTfzL*(WennwpPOOvrMTfzL)*(24.165)*(95.459));
