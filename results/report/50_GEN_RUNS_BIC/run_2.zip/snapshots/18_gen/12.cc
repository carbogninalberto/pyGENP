tcb->m_cWnd = (int) (2.707-(3.29)-(cnt)-(tcb->m_ssThresh));
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_ssThresh*(segmentsAcked)*(65.318)*(68.403)*(94.659)*(54.035)*(22.409)*(tcb->m_ssThresh));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (96.569+(2.166)+(75.828)+(92.685)+(76.605)+(tcb->m_cWnd));
int isNSBKLeWTQPIvgS = (int) (62.706*(55.45)*(46.407)*(53.63));
