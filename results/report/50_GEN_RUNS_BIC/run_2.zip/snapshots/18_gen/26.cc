float pqfOdzSZuzcQermN = (float) (tcb->m_segmentSize-(41.637)-(68.958)-(68.699)-(tcb->m_ssThresh));
tcb->m_cWnd = (int) (49.113*(85.869)*(64.425)*(67.716));
float OgYNJMSPFLBgWBZw = (float) (((21.786)+((71.463*(52.362)*(segmentsAcked)*(59.555)*(tcb->m_ssThresh)))+((90.442+(30.177)+(86.754)+(18.644)+(tcb->m_cWnd)+(39.644)+(99.743)+(89.886)))+(0.1))/((56.706)));
if (pqfOdzSZuzcQermN > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (79.881*(7.283));
	OgYNJMSPFLBgWBZw = (float) (51.033-(pqfOdzSZuzcQermN));

} else {
	tcb->m_cWnd = (int) (9.045/(1.902-(12.587)-(16.723)-(tcb->m_cWnd)-(81.724)-(78.575)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
OgYNJMSPFLBgWBZw = (float) (31.848*(50.052)*(segmentsAcked)*(53.237)*(6.186));
