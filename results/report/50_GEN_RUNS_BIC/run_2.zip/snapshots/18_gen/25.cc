if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (15.263*(41.704)*(tcb->m_ssThresh)*(88.635)*(segmentsAcked)*(cnt)*(tcb->m_ssThresh)*(8.67));
	tcb->m_ssThresh = (int) ((38.417+(72.413)+(0.49))/0.1);

} else {
	tcb->m_segmentSize = (int) (81.158*(86.137)*(15.138)*(0.393)*(segmentsAcked)*(segmentsAcked));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (60.908/58.172);

}
tcb->m_ssThresh = (int) (82.15*(tcb->m_ssThresh)*(99.338)*(39.742));
tcb->m_cWnd = (int) (55.997+(63.294)+(91.799)+(76.658));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (44.394+(54.682)+(43.321)+(7.985));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
