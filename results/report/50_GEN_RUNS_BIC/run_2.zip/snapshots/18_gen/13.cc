tcb->m_cWnd = (int) (26.773+(23.021)+(76.743)+(tcb->m_segmentSize)+(58.196)+(90.158)+(tcb->m_cWnd));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh-(16.41)-(75.835)-(60.421)-(19.176)-(76.161));

} else {
	tcb->m_ssThresh = (int) (77.857+(55.82)+(58.01)+(40.188)+(68.261)+(86.165));
	segmentsAcked = (int) (0.1/1.539);
	segmentsAcked = (int) ((42.312*(56.453)*(36.059)*(tcb->m_segmentSize)*(16.932)*(47.243)*(79.295)*(8.874))/0.1);

}
cnt = (int) (17.45+(45.879)+(tcb->m_cWnd)+(58.749)+(5.294)+(67.648)+(97.162)+(40.148));
if (segmentsAcked != cnt) {
	segmentsAcked = (int) ((72.805-(2.877)-(37.926)-(9.952)-(53.232)-(cnt)-(cnt)-(82.744)-(44.795))/83.209);

} else {
	segmentsAcked = (int) (86.131/31.274);

}
tcb->m_segmentSize = (int) (31.466+(segmentsAcked)+(38.471));
