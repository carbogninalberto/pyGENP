ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (28.794+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(42.911));
if (tcb->m_ssThresh <= cnt) {
	tcb->m_cWnd = (int) (86.435-(8.44)-(0.179)-(97.102)-(32.508));
	segmentsAcked = (int) (((64.047)+(3.6)+(39.468)+(93.633)+((64.783-(segmentsAcked)-(56.513)-(71.118)-(87.473)-(38.506)-(73.506)-(tcb->m_cWnd)-(43.19)))+(0.1))/((0.1)+(83.843)));

} else {
	tcb->m_cWnd = (int) (36.553/0.1);
	tcb->m_segmentSize = (int) (((16.718)+(62.601)+((99.453-(12.818)-(32.051)-(58.427)-(segmentsAcked)-(72.858)))+(0.1))/((0.1)));
	tcb->m_ssThresh = (int) (40.414+(cnt)+(tcb->m_segmentSize)+(11.413));

}
tcb->m_ssThresh = (int) (42.524-(36.152)-(segmentsAcked)-(81.053)-(62.005));
