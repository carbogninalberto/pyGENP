ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (2.84*(74.535));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (60.875/60.511);

} else {
	tcb->m_cWnd = (int) (32.436*(71.816)*(57.932)*(77.095)*(cnt)*(42.101));
	tcb->m_cWnd = (int) (((99.985)+(82.109)+((34.336+(47.718)+(32.844)+(47.779)+(67.534)+(1.056)))+(85.679)+(0.1)+(0.1))/((46.822)+(53.095)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (53.405/79.234);
