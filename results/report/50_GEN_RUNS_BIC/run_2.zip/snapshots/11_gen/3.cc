if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (39.325+(-96.044)+(-67.671));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(88.3)*(-14.08)*(-12.93)*(-91.338)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(77.49)*(-79.443))/30.735);
tcb->m_cWnd = (int) ((segmentsAcked*(-25.987)*(-22.527)*(-67.98)*(38.138)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(26.202)*(59.503))/-92.362);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (98.051+(75.549)+(-77.768));
tcb->m_cWnd = (int) ((segmentsAcked*(76.594)*(-58.031)*(-65.161)*(-50.004)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(25.923)*(-54.835))/-43.798);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-15.191)*(-98.061)*(-65.801)*(-25.889)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(68.275)*(-68.432))/-65.774);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-76.299)*(-78.997)*(-49.439)*(-98.989)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-18.416)*(-44.392))/81.472);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-27.898)*(-57.795)*(15.151)*(23.042)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-42.104)*(53.507))/59.817);
tcb->m_cWnd = (int) ((segmentsAcked*(72.238)*(52.364)*(6.282)*(26.641)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(88.271)*(97.544))/61.711);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (80.661+(-52.49)+(-93.338));
tcb->m_cWnd = (int) ((segmentsAcked*(-72.938)*(-61.576)*(45.566)*(54.375)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(44.275)*(42.37))/-21.39);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-56.912)*(40.399)*(30.606)*(90.676)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(65.062)*(-94.741))/31.781);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(5.765)*(59.217)*(73.587)*(-86.466)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(20.935)*(79.037))/82.384);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
