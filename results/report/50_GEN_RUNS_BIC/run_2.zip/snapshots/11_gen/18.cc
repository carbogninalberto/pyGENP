cnt = (int) (37.143+(tcb->m_cWnd)+(53.089)+(tcb->m_ssThresh)+(cnt)+(79.926));
tcb->m_segmentSize = (int) ((((51.177+(13.892)+(tcb->m_ssThresh)+(32.171)+(95.999)+(16.032)+(80.161)+(37.426)))+((tcb->m_cWnd-(98.31)-(74.181)-(83.806)-(8.351)-(92.921)-(65.946)-(28.109)-(87.263)))+(0.1)+(64.239))/((85.905)));
float qZfiLaLybZdQDwRK = (float) (0.1/29.093);
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	segmentsAcked = (int) ((((cnt+(cnt)+(45.891)+(tcb->m_ssThresh)))+(54.125)+(35.041)+(97.078)+(11.931))/((2.771)+(72.547)+(0.1)));

} else {
	segmentsAcked = (int) (27.386+(tcb->m_cWnd)+(60.62)+(80.822)+(78.737)+(79.985)+(27.022)+(81.686)+(40.23));
	tcb->m_ssThresh = (int) (42.675-(tcb->m_segmentSize)-(38.547)-(51.401)-(2.629)-(18.379)-(73.886));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (cnt*(23.052)*(34.332)*(qZfiLaLybZdQDwRK)*(61.085)*(62.62)*(tcb->m_segmentSize)*(61.302)*(74.763));
	segmentsAcked = (int) (5.145-(42.516)-(25.035)-(cnt)-(4.866)-(14.722)-(67.669));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (64.491*(51.605)*(91.649)*(77.191));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
if (cnt == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (8.82/61.003);
	cnt = (int) (68.336+(38.755)+(89.2)+(40.536)+(12.858)+(qZfiLaLybZdQDwRK)+(cnt)+(23.541));
	cnt = (int) (26.326*(tcb->m_cWnd));

} else {
	tcb->m_ssThresh = (int) (15.707*(34.843)*(45.83)*(tcb->m_ssThresh));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
