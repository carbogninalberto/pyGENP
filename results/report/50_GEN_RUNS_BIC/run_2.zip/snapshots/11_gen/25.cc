if (tcb->m_ssThresh <= cnt) {
	segmentsAcked = (int) (97.726/0.1);
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(72.463)-(4.93)-(80.624)-(49.804)-(52.201)-(84.847));

} else {
	segmentsAcked = (int) (23.523*(89.413)*(93.093)*(11.465)*(24.297)*(74.698)*(80.696));

}
ReduceCwnd (tcb);
if (cnt >= tcb->m_segmentSize) {
	segmentsAcked = (int) (6.462-(3.458));
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(75.899)+(0.1))/((56.78)));

} else {
	segmentsAcked = (int) (6.313+(16.394)+(79.467)+(15.281)+(97.928)+(33.526));

}
ReduceCwnd (tcb);
cnt = (int) (segmentsAcked+(tcb->m_segmentSize)+(43.591)+(segmentsAcked));
