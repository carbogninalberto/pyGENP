if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-47.505+(12.331)+(55.171));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(91.701)*(-22.943)*(68.031)*(99.087)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-20.401)*(-34.734))/55.897);
tcb->m_cWnd = (int) ((segmentsAcked*(-77.983)*(-95.846)*(-64.184)*(-7.643)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-61.056)*(3.338))/-46.675);
tcb->m_cWnd = (int) ((segmentsAcked*(88.778)*(-31.073)*(-42.503)*(-53.988)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-76.42)*(-35.676))/-33.418);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (91.55+(57.562)+(-5.16));
tcb->m_cWnd = (int) ((segmentsAcked*(7.573)*(51.782)*(-3.718)*(-78.639)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(70.835)*(-45.496))/-0.928);
tcb->m_cWnd = (int) ((segmentsAcked*(65.015)*(-35.169)*(18.623)*(91.333)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(25.011)*(53.66))/27.985);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-91.955)*(74.94)*(-72.042)*(54.392)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(3.768)*(-53.565))/51.323);
tcb->m_cWnd = (int) ((segmentsAcked*(-95.378)*(-92.073)*(90.974)*(82.965)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-40.355)*(-31.638))/90.352);
tcb->m_cWnd = (int) ((segmentsAcked*(23.0)*(-30.958)*(65.713)*(-56.42)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-36.537)*(41.444))/59.652);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (72.174+(55.59)+(-65.143));
tcb->m_cWnd = (int) ((segmentsAcked*(75.52)*(-43.734)*(74.188)*(-26.722)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(36.231)*(17.54))/22.459);
tcb->m_cWnd = (int) ((segmentsAcked*(33.611)*(81.238)*(-42.718)*(25.774)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(50.415)*(84.227))/-61.353);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(56.5)*(-33.482)*(85.713)*(-1.961)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(51.409)*(12.379))/-49.058);
tcb->m_cWnd = (int) ((segmentsAcked*(-91.366)*(84.192)*(9.628)*(-60.181)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(84.778)*(37.488))/-48.188);
tcb->m_cWnd = (int) ((segmentsAcked*(8.883)*(-43.158)*(-19.363)*(72.167)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-96.865)*(93.592))/80.718);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(71.123)*(8.625)*(-80.234)*(-50.523)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(70.11)*(-60.679))/87.591);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (59.854+(13.997)+(-50.282));
tcb->m_cWnd = (int) ((segmentsAcked*(-43.13)*(-99.014)*(39.561)*(72.333)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-72.217)*(-1.311))/-81.012);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(58.69)*(30.947)*(-28.139)*(30.589)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-47.593)*(-74.869))/-17.228);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(92.51)*(-45.195)*(-5.38)*(-63.105)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(92.449)*(-45.192))/-60.69);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
