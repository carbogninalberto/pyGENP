if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (97.339+(70.442)+(15.186));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) ((segmentsAcked*(-62.119)*(85.134)*(58.928)*(-24.4)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-64.758)*(14.508))/41.606);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-8.414)*(-89.371)*(78.745)*(-28.642)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-87.247)*(-31.75))/18.919);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
