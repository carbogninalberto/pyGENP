if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	cnt = (int) (((90.938)+(25.474)+((1.05+(46.025)+(96.984)+(15.222)+(17.79)))+(85.194))/((50.375)+(79.893)));
	tcb->m_cWnd = (int) (77.92+(83.565)+(43.784)+(96.262)+(tcb->m_cWnd)+(23.995)+(19.617)+(39.867));
	cnt = (int) (75.019-(43.09)-(tcb->m_cWnd)-(82.911));

} else {
	cnt = (int) (52.227*(21.096)*(tcb->m_ssThresh)*(segmentsAcked)*(75.649));

}
cnt = (int) (93.49-(27.248)-(81.418));
tcb->m_ssThresh = (int) (51.796-(33.331)-(34.361)-(79.177)-(50.995)-(tcb->m_cWnd));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (tcb->m_ssThresh+(85.231)+(71.301));
