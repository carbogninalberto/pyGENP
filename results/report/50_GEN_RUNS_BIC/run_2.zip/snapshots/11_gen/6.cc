int LPcTrXowSsSrTEEH = (int) (76.091*(49.689)*(-22.875)*(-60.019)*(-60.364)*(-24.012));
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) (14.159+(9.098)+(tcb->m_segmentSize)+(5.529)+(51.559));

} else {
	tcb->m_cWnd = (int) (58.685-(71.229)-(50.047)-(19.29)-(96.742)-(40.629)-(segmentsAcked));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (24.643-(30.569)-(-81.418)-(-8.6)-(27.686)-(50.636));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (43.503-(68.431)-(-40.307)-(49.316));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-44.126-(-36.089)-(-4.002)-(68.037)-(46.495)-(-82.358));
tcb->m_segmentSize = (int) (39.976-(25.189)-(-71.152)-(13.612));
