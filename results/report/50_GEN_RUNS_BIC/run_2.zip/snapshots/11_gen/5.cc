if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (41.969+(-62.162)+(-20.175));
tcb->m_cWnd = (int) ((segmentsAcked*(-69.933)*(96.657)*(-67.144)*(57.915)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(39.811)*(82.555))/30.83);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-98.96)*(48.558)*(-8.623)*(-98.564)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(34.968)*(-76.291))/68.934);
tcb->m_cWnd = (int) ((segmentsAcked*(17.602)*(25.963)*(-40.931)*(75.033)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-20.961)*(50.975))/-32.152);
tcb->m_cWnd = (int) ((segmentsAcked*(-78.721)*(56.364)*(50.548)*(99.053)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-11.794)*(97.203))/-33.372);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(28.807)*(55.513)*(-54.807)*(-88.674)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(8.867)*(-67.991))/58.635);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-85.973)*(-48.185)*(52.715)*(-1.132)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(14.031)*(-36.199))/-38.067);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-63.621)*(15.715)*(-20.232)*(-37.221)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-51.516)*(40.463))/16.538);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
