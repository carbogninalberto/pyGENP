ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (73.463*(tcb->m_cWnd)*(88.735)*(31.167)*(tcb->m_segmentSize)*(41.117)*(cnt)*(12.462)*(93.72));
	tcb->m_ssThresh = (int) (((58.556)+(98.213)+(15.393)+(13.47))/((98.762)+(8.65)+(60.403)+(22.361)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (0.1/42.045);
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(88.01)*(14.384));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(93.56)-(30.083)-(71.767)-(48.479)-(7.302)-(10.538));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (56.034/0.1);
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (81.279+(cnt)+(35.633)+(tcb->m_ssThresh)+(91.304)+(41.969)+(33.623)+(92.879));
	tcb->m_cWnd = (int) (cnt-(74.9)-(26.965)-(64.952));

} else {
	tcb->m_segmentSize = (int) (83.602*(tcb->m_ssThresh)*(segmentsAcked)*(12.406)*(31.911)*(70.474));
	tcb->m_ssThresh = (int) (39.606*(27.598)*(49.262)*(35.276)*(tcb->m_ssThresh)*(46.111)*(71.628)*(32.009)*(99.125));
	tcb->m_segmentSize = (int) (52.94/93.348);

}
if (tcb->m_cWnd == cnt) {
	cnt = (int) (48.999+(tcb->m_ssThresh)+(91.425)+(39.304)+(2.654)+(cnt)+(94.493));

} else {
	cnt = (int) (80.371-(4.922)-(22.47)-(94.744)-(26.858)-(tcb->m_segmentSize)-(95.906));
	tcb->m_cWnd = (int) (74.31-(tcb->m_segmentSize)-(4.868)-(33.541));

}
