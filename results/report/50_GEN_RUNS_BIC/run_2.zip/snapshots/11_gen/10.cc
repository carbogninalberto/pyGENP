if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (40.271+(77.009)+(67.294));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(29.699)*(-17.428)*(-53.321)*(-84.236)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-92.301)*(-69.703))/69.527);
tcb->m_cWnd = (int) ((segmentsAcked*(62.11)*(88.847)*(-73.11)*(68.335)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-84.513)*(41.434))/-53.261);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-85.784)*(-44.535)*(-21.101)*(-77.618)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-96.689)*(10.856))/39.943);
tcb->m_cWnd = (int) (58.495+(-34.125)+(-80.021));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-79.527)*(-8.142)*(-11.629)*(-31.266)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(4.005)*(-84.347))/98.594);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(88.772)*(45.375)*(-66.106)*(-3.872)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-34.576)*(35.677))/-1.226);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-4.494)*(95.756)*(-71.383)*(-22.681)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(28.022)*(-27.973))/-94.354);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(36.628)*(16.874)*(-48.397)*(18.865)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(55.711)*(-99.518))/-40.855);
tcb->m_cWnd = (int) ((segmentsAcked*(-55.187)*(48.368)*(64.858)*(-50.889)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(95.367)*(15.576))/47.656);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (40.947+(-54.577)+(-71.494));
tcb->m_cWnd = (int) ((segmentsAcked*(-33.411)*(-20.647)*(-42.37)*(-13.66)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(84.994)*(-89.398))/-90.358);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(69.96)*(-54.061)*(-3.34)*(56.407)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-48.869)*(-29.612))/-35.504);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(11.268)*(71.093)*(1.544)*(-65.056)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-63.912)*(87.21))/-95.58);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
