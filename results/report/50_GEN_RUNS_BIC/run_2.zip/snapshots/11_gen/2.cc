if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (14.12+(-20.58)+(23.273));
tcb->m_cWnd = (int) ((segmentsAcked*(-60.29)*(-14.957)*(-37.811)*(84.919)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-4.129)*(68.179))/34.255);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-55.934)*(-53.589)*(60.456)*(8.55)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(89.605)*(35.487))/18.505);
tcb->m_cWnd = (int) ((segmentsAcked*(98.559)*(-55.399)*(-3.347)*(36.099)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-70.004)*(4.326))/-15.85);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-48.275)*(7.159)*(79.174)*(-96.778)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-12.109)*(-79.028))/-7.742);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-25.187)*(41.445)*(-30.283)*(46.828)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-51.566)*(-26.006))/-97.693);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
