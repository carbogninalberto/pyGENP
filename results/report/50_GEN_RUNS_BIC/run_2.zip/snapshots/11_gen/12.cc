if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-96.087+(55.161)+(79.527));
tcb->m_cWnd = (int) (8.893+(29.322)+(-42.775));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(63.219)*(5.83)*(-12.223)*(57.768)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(44.88)*(-68.4))/-48.624);
tcb->m_cWnd = (int) ((segmentsAcked*(-83.973)*(-51.969)*(94.039)*(90.469)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(98.037)*(82.767))/-48.074);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
