int LPcTrXowSsSrTEEH = (int) (9.482*(64.349)*(44.24)*(86.921)*(62.112)*(-33.87));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (54.022-(-22.071)-(-41.455)-(99.227)-(91.85)-(8.644));
tcb->m_segmentSize = (int) (53.588-(-30.33)-(60.746)-(-15.758));
