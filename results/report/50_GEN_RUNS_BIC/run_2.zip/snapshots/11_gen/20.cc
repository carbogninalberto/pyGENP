float gJhhdQnZYlyQjdCp = (float) (7.103+(64.036)+(44.273)+(27.591)+(8.866)+(63.583)+(36.384)+(tcb->m_cWnd));
ReduceCwnd (tcb);
gJhhdQnZYlyQjdCp = (float) (21.913+(63.597));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (tcb->m_cWnd+(segmentsAcked)+(25.584)+(tcb->m_cWnd)+(79.008)+(83.747));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
