tcb->m_ssThresh = (int) (61.886-(11.448)-(74.724)-(44.905)-(17.19)-(tcb->m_cWnd));
float vSVYNLGluEluivEi = (float) (56.276*(73.441)*(45.65)*(75.608)*(26.182)*(28.843)*(28.146));
int WqjkmZYpxMoZOQcm = (int) (0.1/48.026);
ReduceCwnd (tcb);
if (cnt <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (24.272*(36.322)*(21.887)*(40.225)*(tcb->m_segmentSize)*(23.676)*(82.826)*(54.716)*(98.555));

} else {
	tcb->m_segmentSize = (int) (54.158*(37.114));
	WqjkmZYpxMoZOQcm = (int) (87.486-(tcb->m_ssThresh)-(12.463)-(92.932)-(98.274)-(24.919));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_ssThresh = (int) (57.817-(tcb->m_segmentSize)-(45.073)-(35.508)-(59.252)-(39.155)-(63.665));
