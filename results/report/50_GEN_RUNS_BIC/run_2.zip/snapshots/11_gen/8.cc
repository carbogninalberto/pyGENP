if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (0.831+(-91.562)+(72.7));
tcb->m_cWnd = (int) ((segmentsAcked*(-92.133)*(-82.362)*(-26.272)*(13.774)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-55.364)*(-23.99))/-59.824);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(3.082)*(-94.561)*(55.671)*(-30.024)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-20.666)*(36.134))/-95.727);
tcb->m_cWnd = (int) ((segmentsAcked*(-19.963)*(-95.44)*(8.488)*(70.923)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(71.16)*(-1.238))/-93.634);
tcb->m_cWnd = (int) ((segmentsAcked*(-38.339)*(-72.695)*(79.276)*(8.433)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(66.239)*(21.52))/29.797);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-30.782)*(-62.634)*(69.844)*(20.497)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-93.436)*(-6.644))/-21.659);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(15.803)*(-26.581)*(-34.025)*(-80.571)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-5.304)*(-13.357))/41.779);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-80.982)*(-72.166)*(88.982)*(-1.006)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-98.726)*(78.594))/-21.355);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
