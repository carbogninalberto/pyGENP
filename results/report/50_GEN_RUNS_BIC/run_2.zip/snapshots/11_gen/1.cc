if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (90.703+(-40.35)+(-32.166));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-26.355)*(94.731)*(69.394)*(-43.733)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(36.491)*(-44.606))/59.328);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-62.875+(13.392)+(-72.599));
tcb->m_cWnd = (int) ((segmentsAcked*(63.228)*(-44.632)*(-65.448)*(-79.345)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-46.405)*(20.43))/-65.71);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(78.359)*(40.449)*(-95.408)*(27.256)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-82.063)*(29.017))/90.526);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-69.95)*(-0.852)*(22.281)*(41.601)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(75.34)*(63.422))/-35.889);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
