if (cnt > segmentsAcked) {
	tcb->m_ssThresh = (int) (29.2*(tcb->m_cWnd)*(76.568)*(tcb->m_segmentSize)*(9.504)*(46.888)*(cnt)*(78.007)*(39.677));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (87.523*(cnt));

} else {
	tcb->m_ssThresh = (int) (64.025-(66.393)-(segmentsAcked)-(12.465)-(29.128)-(82.928)-(2.657)-(6.693));

}
if (cnt <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (81.173*(34.313)*(73.151)*(82.778));
	segmentsAcked = (int) (52.064+(43.05)+(37.432)+(93.044)+(1.095)+(86.521)+(tcb->m_ssThresh)+(17.788));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (66.935-(63.859)-(86.298)-(37.353)-(89.967)-(20.428));
	tcb->m_ssThresh = (int) (59.278-(98.948)-(56.849)-(1.794)-(tcb->m_cWnd)-(24.904)-(58.663)-(50.794)-(0.246));
	tcb->m_segmentSize = (int) (72.247/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((73.294)+(19.401)+((98.778+(cnt)+(cnt)+(37.319)+(41.747)))+(34.46))/((0.1)+(22.228)));
ReduceCwnd (tcb);
