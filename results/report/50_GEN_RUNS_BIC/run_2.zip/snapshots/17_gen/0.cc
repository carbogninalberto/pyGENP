int XGNhipgRjhVlBCGT = (int) 82.242;
int lotKkKDWcUzvrapo = (int) (-31.409*(80.746)*(-92.743));
float grrHcFnHuZTJsKtN = (float) (-74.279/-58.214);
int zydREgaQSDwTxttZ = (int) 97.39;
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
