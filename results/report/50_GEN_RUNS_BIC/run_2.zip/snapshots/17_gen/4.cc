float mVkcUfXByVZLZtxy = (float) (66.241+(-88.415)+(20.418)+(-94.147)+(39.162)+(-30.503));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize <= segmentsAcked) {
	segmentsAcked = (int) (65.203*(segmentsAcked)*(84.167)*(74.878)*(94.605)*(64.885)*(12.228));
	mVkcUfXByVZLZtxy = (float) (62.078*(96.136)*(10.059)*(93.935)*(12.452)*(18.291)*(41.179)*(11.449));
	tcb->m_segmentSize = (int) (51.797*(0.425)*(42.981)*(81.036)*(tcb->m_cWnd)*(65.737));

} else {
	segmentsAcked = (int) (66.044+(9.876)+(78.507));
	segmentsAcked = (int) (tcb->m_cWnd+(71.698)+(9.863)+(77.457));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	segmentsAcked = (int) (65.203*(segmentsAcked)*(84.167)*(74.878)*(94.605)*(64.885)*(12.228));
	mVkcUfXByVZLZtxy = (float) (62.078*(96.136)*(10.059)*(93.935)*(12.452)*(18.291)*(41.179)*(11.449));
	tcb->m_segmentSize = (int) (51.797*(0.425)*(42.981)*(81.036)*(tcb->m_cWnd)*(65.737));

} else {
	segmentsAcked = (int) (66.044+(9.876)+(78.507));
	segmentsAcked = (int) (tcb->m_cWnd+(71.698)+(9.863)+(77.457));

}
