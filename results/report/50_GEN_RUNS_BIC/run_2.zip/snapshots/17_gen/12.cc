if (cnt > segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(segmentsAcked)+(21.845)+(29.848)+(79.475)+(49.534)+(32.746)+(66.282));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (75.323+(segmentsAcked)+(57.74)+(tcb->m_ssThresh)+(14.916)+(3.405));

} else {
	tcb->m_segmentSize = (int) ((60.293-(tcb->m_ssThresh)-(72.041)-(tcb->m_ssThresh)-(98.658)-(0.228)-(35.646)-(93.684)-(40.437))/10.576);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (98.19/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (segmentsAcked+(87.105)+(9.224)+(93.799)+(33.457)+(6.116)+(75.278)+(tcb->m_segmentSize)+(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (((0.1)+(2.393)+(0.1)+((tcb->m_cWnd+(34.157)+(16.818)+(cnt)+(97.245)+(46.586)+(22.918)+(0.38)))+(0.1))/((83.372)+(51.161)+(21.202)+(93.282)));

}
if (cnt <= tcb->m_segmentSize) {
	segmentsAcked = (int) (66.83-(30.02)-(66.78)-(34.366)-(9.933)-(15.944)-(92.111)-(tcb->m_ssThresh)-(84.569));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (12.181+(88.471)+(77.768)+(31.395)+(34.048)+(64.917)+(67.134)+(6.541)+(17.248));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt <= cnt) {
	segmentsAcked = (int) (((85.857)+((31.844-(73.974)))+(60.306)+(0.1))/((76.685)+(44.325)+(29.708)+(0.1)));
	tcb->m_ssThresh = (int) (0.1/92.223);
	tcb->m_cWnd = (int) (51.555*(95.368)*(96.143)*(47.961)*(67.976)*(68.974));

} else {
	segmentsAcked = (int) (12.054-(88.897)-(68.886)-(21.724)-(43.217)-(25.149)-(74.668));
	segmentsAcked = (int) (tcb->m_cWnd+(73.103)+(segmentsAcked)+(62.303)+(tcb->m_ssThresh));

}
tcb->m_segmentSize = (int) (20.485*(63.244));
