tcb->m_cWnd = (int) (tcb->m_ssThresh+(77.872)+(51.779)+(54.273)+(45.062));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_segmentSize = (int) ((43.074-(84.166)-(tcb->m_cWnd)-(35.454)-(36.102))/27.773);
	segmentsAcked = (int) (61.018*(91.848)*(86.018)*(43.47)*(77.882)*(10.968));

} else {
	tcb->m_segmentSize = (int) (74.878*(53.465)*(37.563)*(94.735)*(76.476)*(83.762));

}
float AioIsKZkoUNccPAH = (float) (20.42+(42.177)+(tcb->m_ssThresh)+(56.947)+(20.199)+(15.332)+(cnt)+(57.239)+(66.818));
