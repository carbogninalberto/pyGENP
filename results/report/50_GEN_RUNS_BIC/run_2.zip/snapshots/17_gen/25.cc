int LIHPRAdlwfwVxkuY = (int) (33.225+(tcb->m_cWnd)+(tcb->m_ssThresh));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (87.155*(87.14)*(69.767)*(93.97));
	tcb->m_cWnd = (int) (28.045+(32.623)+(75.065)+(94.919));

} else {
	tcb->m_cWnd = (int) (97.653+(44.735)+(19.363)+(77.511)+(48.904)+(6.84)+(52.365));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
cnt = (int) (0.1/0.1);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
