int iIKdhYrXTqMsfKjy = (int) (tcb->m_segmentSize+(48.991)+(tcb->m_cWnd)+(61.263)+(16.343)+(33.682));
tcb->m_cWnd = (int) (cnt+(88.96)+(65.044)+(segmentsAcked)+(76.194));
int LvNWcFMwVlyqVcCD = (int) (76.68/60.471);
if (tcb->m_segmentSize <= segmentsAcked) {
	segmentsAcked = (int) (8.305-(24.223)-(3.536)-(53.411)-(cnt)-(19.409)-(63.174)-(29.546)-(44.632));
	cnt = (int) (58.242-(LvNWcFMwVlyqVcCD)-(4.147)-(0.692)-(cnt)-(15.223)-(6.612)-(58.853)-(16.247));

} else {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (19.608-(14.222)-(46.694)-(10.488)-(82.688)-(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (LvNWcFMwVlyqVcCD != tcb->m_segmentSize) {
	LvNWcFMwVlyqVcCD = (int) (82.187*(56.164)*(69.511)*(28.598)*(99.381));
	tcb->m_cWnd = (int) (61.417*(77.474)*(49.703)*(6.357)*(45.167));

} else {
	LvNWcFMwVlyqVcCD = (int) (27.544*(69.684)*(cnt)*(38.833)*(73.554)*(tcb->m_cWnd)*(89.228)*(31.066));

}
segmentsAcked = (int) (38.504*(57.276)*(15.389)*(segmentsAcked)*(19.803)*(iIKdhYrXTqMsfKjy)*(cnt));
segmentsAcked = (int) (80.181+(14.481));
LvNWcFMwVlyqVcCD = (int) (10.087-(40.679)-(tcb->m_ssThresh)-(8.178)-(23.009)-(82.105));
