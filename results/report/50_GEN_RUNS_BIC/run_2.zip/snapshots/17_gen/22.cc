tcb->m_ssThresh = (int) (18.109-(62.192)-(59.633)-(47.399));
ReduceCwnd (tcb);
cnt = (int) (55.686/8.935);
segmentsAcked = (int) (((5.624)+(61.166)+((tcb->m_ssThresh-(90.842)-(6.546)-(79.248)-(33.887)-(70.127)-(97.484)-(92.751)-(47.66)))+(42.408))/((64.505)));
int tXUVPIOtjgUqgvCy = (int) (2.695+(79.279));
ReduceCwnd (tcb);
