int ZJbirQOaOZesCgXC = (int) (70.402-(69.927)-(16.814)-(97.406)-(4.212)-(25.638)-(65.485));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
int WTBAfmYWYvIJjKdR = (int) (0.1/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
