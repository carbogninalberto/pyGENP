ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (78.227*(67.379)*(tcb->m_segmentSize));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh > cnt) {
	tcb->m_ssThresh = (int) (29.082-(36.301)-(5.497)-(cnt)-(tcb->m_segmentSize)-(segmentsAcked));
	cnt = (int) (39.939+(segmentsAcked)+(tcb->m_cWnd)+(80.308)+(93.211)+(63.419)+(6.212));
	tcb->m_ssThresh = (int) (((0.1)+(92.955)+(0.1)+((42.855+(8.97)+(tcb->m_segmentSize)))+(27.692))/((0.1)+(96.312)));

} else {
	tcb->m_ssThresh = (int) (3.565*(60.956)*(23.668)*(49.73)*(tcb->m_cWnd)*(19.345)*(77.351)*(cnt)*(12.749));

}
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_segmentSize = (int) (56.616*(16.391)*(segmentsAcked)*(50.335)*(36.072)*(75.224)*(85.8));
	tcb->m_cWnd = (int) (39.962-(82.926)-(66.052));
	cnt = (int) (40.999-(92.479)-(segmentsAcked)-(53.733)-(55.512)-(segmentsAcked)-(62.75));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+((49.113*(38.728)*(98.728)*(23.732)))+(0.1)+(40.625))/((0.1)+(0.1)+(0.1)+(86.181)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (14.662*(segmentsAcked)*(7.001));

}
tcb->m_ssThresh = (int) (69.863-(55.19)-(58.716)-(74.707));
if (tcb->m_cWnd >= cnt) {
	tcb->m_segmentSize = (int) (81.325/31.376);
	tcb->m_ssThresh = (int) (39.05+(99.952)+(tcb->m_ssThresh)+(62.849)+(9.75)+(8.81)+(41.804));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (4.909*(15.634));
	cnt = (int) (73.206*(38.861)*(94.384)*(tcb->m_segmentSize)*(50.268));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
