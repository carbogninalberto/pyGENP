tcb->m_cWnd = (int) (73.771-(99.595)-(4.331)-(9.003)-(74.127)-(31.442)-(88.007));
if (segmentsAcked > cnt) {
	segmentsAcked = (int) (75.544+(20.551)+(77.376)+(62.273)+(75.349)+(25.367)+(14.011));

} else {
	segmentsAcked = (int) (90.947-(17.704)-(39.271)-(79.133)-(19.752)-(99.393));

}
cnt = (int) (tcb->m_cWnd-(85.157)-(82.643));
tcb->m_cWnd = (int) ((tcb->m_ssThresh+(35.127)+(cnt)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(segmentsAcked)+(segmentsAcked))/4.735);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
