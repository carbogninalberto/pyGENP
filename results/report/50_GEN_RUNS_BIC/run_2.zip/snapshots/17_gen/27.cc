ReduceCwnd (tcb);
int qTrhHORwEOUFunkR = (int) (((0.1)+(0.1)+(10.407)+((52.232*(44.651)))+(0.1))/((0.1)));
float fHbXZIMTykahWLOs = (float) (tcb->m_segmentSize*(qTrhHORwEOUFunkR)*(24.944)*(88.923)*(70.262)*(81.329)*(11.679)*(tcb->m_ssThresh));
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	cnt = (int) (((0.1)+(99.108)+(12.768)+(27.655))/((0.1)+(0.1)));

} else {
	cnt = (int) (qTrhHORwEOUFunkR*(51.808)*(68.074)*(38.186)*(67.163)*(61.465));
	tcb->m_ssThresh = (int) (0.1/86.305);
	fHbXZIMTykahWLOs = (float) (0.1/10.116);

}
tcb->m_cWnd = (int) (72.172+(86.285)+(segmentsAcked)+(20.97)+(cnt)+(qTrhHORwEOUFunkR));
