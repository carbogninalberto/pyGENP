ReduceCwnd (tcb);
if (cnt == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (64.609*(61.964)*(81.041)*(60.563)*(92.526)*(68.312));
	cnt = (int) ((tcb->m_segmentSize*(94.968)*(46.539)*(12.896)*(36.413)*(54.502)*(tcb->m_ssThresh))/60.453);
	segmentsAcked = (int) (cnt-(4.177)-(2.753)-(cnt)-(47.126)-(segmentsAcked)-(2.95));

} else {
	tcb->m_segmentSize = (int) ((((3.635+(73.338)+(95.879)+(95.754)+(93.36)))+(75.774)+(30.187)+(0.1))/((6.276)));

}
ReduceCwnd (tcb);
int mmJIZIpGekwzNTSZ = (int) (((17.043)+(0.1)+(0.1)+(94.651))/((82.452)));
if (cnt <= mmJIZIpGekwzNTSZ) {
	tcb->m_segmentSize = (int) (61.013-(70.319));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (22.259+(22.168)+(93.435)+(45.829)+(72.358));
	mmJIZIpGekwzNTSZ = (int) (96.7-(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (((9.411)+(0.1)+((38.121*(1.027)*(tcb->m_segmentSize)*(51.106)*(11.741)*(46.15)*(segmentsAcked)*(44.958)*(6.888)))+(25.945)+(95.482)+(26.331))/((28.25)+(0.1)));

}
tcb->m_ssThresh = (int) ((((26.966*(5.204)*(72.889)*(39.42)*(96.207)*(95.538)))+(42.898)+((24.497+(15.291)+(43.063)+(mmJIZIpGekwzNTSZ)+(37.922)))+(37.506)+(0.1)+(0.1))/((44.802)+(0.1)));
ReduceCwnd (tcb);
if (cnt > mmJIZIpGekwzNTSZ) {
	cnt = (int) (48.318/84.455);
	cnt = (int) (44.861+(52.816)+(6.485)+(99.764)+(40.059)+(segmentsAcked)+(29.31)+(tcb->m_ssThresh));

} else {
	cnt = (int) (95.845-(12.999));
	tcb->m_ssThresh = (int) (71.158+(28.832));
	tcb->m_segmentSize = (int) (87.455/0.1);

}
