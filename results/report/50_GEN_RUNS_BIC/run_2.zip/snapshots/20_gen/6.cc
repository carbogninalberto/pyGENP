tcb->m_segmentSize = (int) (-46.281+(29.391)+(-31.887)+(28.483)+(94.187));
tcb->m_segmentSize = (int) (-92.702+(77.723)+(-99.634)+(-42.464)+(30.909));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
