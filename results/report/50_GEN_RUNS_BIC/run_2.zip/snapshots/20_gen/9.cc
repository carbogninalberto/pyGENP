ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (0.1/(70.062+(54.4)+(58.048)+(97.595)+(88.934)+(13.961)));
int fiOrSPuyLmplvzMv = (int) ((tcb->m_cWnd-(69.034)-(23.926)-(cnt)-(tcb->m_cWnd)-(34.026)-(67.806)-(1.735)-(32.754))/38.759);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (((74.953)+(0.1)+(0.1)+(89.95)+(95.885))/((98.392)+(5.567)+(0.1)));
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (87.251+(segmentsAcked)+(17.202)+(2.862)+(fiOrSPuyLmplvzMv)+(44.648)+(39.531)+(74.765));

} else {
	tcb->m_ssThresh = (int) (75.327-(23.02)-(55.734)-(32.797));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
