float mVkcUfXByVZLZtxy = (float) (76.719+(-31.6)+(83.697)+(-31.106)+(99.047)+(35.832));
tcb->m_segmentSize = (int) (65.005+(38.992)+(48.551)+(15.488)+(-90.13));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-74.603+(-21.382)+(-23.438)+(55.644)+(-41.049));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
