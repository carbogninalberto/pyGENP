segmentsAcked = (int) (41.972+(tcb->m_segmentSize)+(21.008)+(segmentsAcked)+(54.919)+(51.234));
if (cnt < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (22.85*(tcb->m_ssThresh)*(34.021)*(75.727));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (0.1/(13.288+(tcb->m_segmentSize)+(36.791)+(segmentsAcked)+(53.599)+(tcb->m_ssThresh)));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
float TksXwbdZgOLAmbEL = (float) (((36.221)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)+(0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
TksXwbdZgOLAmbEL = (float) (98.937*(22.691)*(tcb->m_segmentSize)*(26.902)*(90.881)*(segmentsAcked)*(99.833)*(tcb->m_segmentSize)*(86.089));
if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (95.734+(cnt)+(33.103)+(96.874)+(segmentsAcked)+(66.927));

} else {
	segmentsAcked = (int) (57.697+(79.477)+(57.175)+(38.5)+(tcb->m_ssThresh)+(tcb->m_segmentSize)+(39.407));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (tcb->m_segmentSize*(54.603)*(55.66)*(57.559)*(43.234)*(31.144)*(28.552));
