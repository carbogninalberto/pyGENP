if (segmentsAcked == tcb->m_cWnd) {
	cnt = (int) (40.415/44.806);
	cnt = (int) (77.042-(43.893)-(73.529)-(19.466)-(13.211)-(67.676)-(46.822));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (95.113+(tcb->m_ssThresh)+(74.584));
	cnt = (int) (tcb->m_ssThresh-(54.44)-(25.301));
	ReduceCwnd (tcb);

}
if (cnt < cnt) {
	tcb->m_segmentSize = (int) ((((22.922-(17.96)-(68.65)-(23.202)-(36.55)-(36.054)-(14.867)-(71.701)-(68.31)))+(0.1)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(69.48)));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (97.885*(49.433)*(0.821)*(82.411));
	tcb->m_ssThresh = (int) (61.76/54.948);
	tcb->m_cWnd = (int) (segmentsAcked*(58.35)*(83.158)*(cnt)*(27.86));

}
tcb->m_ssThresh = (int) (48.077+(72.415)+(20.586));
cnt = (int) (tcb->m_ssThresh+(tcb->m_ssThresh));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (tcb->m_ssThresh-(tcb->m_ssThresh)-(segmentsAcked)-(55.843)-(91.283)-(91.108));
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/66.873);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (38.065-(77.871)-(86.88)-(84.69)-(27.568)-(tcb->m_ssThresh)-(segmentsAcked)-(1.342));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
int gvdSydQeRMdQwnUn = (int) (90.128*(76.766)*(19.503));
tcb->m_cWnd = (int) (54.353-(35.424)-(67.97));
