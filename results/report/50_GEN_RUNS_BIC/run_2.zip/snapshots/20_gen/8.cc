if (segmentsAcked > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (25.593*(39.646)*(55.471)*(24.635)*(segmentsAcked)*(97.355)*(76.509)*(cnt)*(22.841));
	cnt = (int) (72.958/0.1);

} else {
	tcb->m_cWnd = (int) (20.348/0.1);

}
segmentsAcked = (int) (85.048+(50.235)+(tcb->m_cWnd)+(26.157)+(98.94)+(tcb->m_segmentSize));
cnt = (int) ((37.161+(tcb->m_segmentSize)+(32.909)+(61.519)+(44.826)+(38.508)+(22.396))/0.1);
segmentsAcked = (int) (1.833+(15.727)+(57.68)+(44.158)+(tcb->m_ssThresh));
tcb->m_segmentSize = (int) (5.993*(34.9)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(30.47)*(70.112)*(16.871));
int JIPYXnalMGRLrxKe = (int) (0.1/95.789);
