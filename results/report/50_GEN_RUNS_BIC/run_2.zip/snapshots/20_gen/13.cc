if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	ReduceCwnd (tcb);
	segmentsAcked = (int) (16.946*(3.556)*(68.102)*(cnt)*(segmentsAcked)*(1.814)*(50.504));

} else {
	tcb->m_ssThresh = (int) (80.082/84.174);
	tcb->m_cWnd = (int) (65.603*(34.711)*(cnt)*(60.246));

}
segmentsAcked = (int) (69.713/80.986);
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/32.083);

} else {
	tcb->m_ssThresh = (int) (44.6*(18.81)*(cnt)*(32.05)*(42.125)*(53.065)*(19.584)*(cnt));
	tcb->m_cWnd = (int) (98.551-(33.892)-(tcb->m_ssThresh)-(20.912)-(54.17)-(51.933)-(11.564)-(37.894));

}
float FDJvCWzyPMOXIeoB = (float) (93.415*(16.943)*(75.01)*(15.754)*(19.144)*(segmentsAcked)*(96.263));
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (79.092-(76.797)-(37.502));

} else {
	tcb->m_segmentSize = (int) (23.034+(59.107)+(37.253)+(95.798));

}
FDJvCWzyPMOXIeoB = (float) (((0.1)+(0.1)+(84.135)+(0.1)+((71.409-(8.669)-(99.328)))+(78.774))/((0.1)+(58.352)));
