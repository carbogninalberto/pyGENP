int SzoYWeoEZVWbIHoX = (int) (-70.597*(82.045)*(31.232)*(-98.913));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-96.491+(-1.546)+(20.584)+(-43.05)+(-78.713)+(16.961)+(83.617)+(-39.0)+(86.914));
