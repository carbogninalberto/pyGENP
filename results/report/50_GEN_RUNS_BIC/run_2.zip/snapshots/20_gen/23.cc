cnt = (int) (segmentsAcked*(13.729)*(segmentsAcked));
tcb->m_ssThresh = (int) (36.735*(1.647)*(55.095)*(0.52)*(60.102));
tcb->m_segmentSize = (int) (48.586-(40.65)-(55.262)-(95.271)-(98.07)-(79.183));
if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_segmentSize = (int) ((26.154+(64.004)+(21.074)+(27.11))/68.885);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (18.964-(1.07)-(89.514)-(97.137)-(12.116)-(19.01)-(97.665)-(61.734));
	tcb->m_cWnd = (int) (22.883-(15.637)-(59.685)-(17.834)-(91.322)-(tcb->m_ssThresh));

}
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (cnt*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(83.394)*(26.252));

} else {
	tcb->m_segmentSize = (int) (87.248+(58.144)+(63.479));
	cnt = (int) (60.777*(68.665)*(89.659)*(13.153));
	segmentsAcked = (int) (51.404-(32.938)-(72.845)-(82.958)-(20.254)-(34.202)-(tcb->m_segmentSize)-(1.316)-(62.588));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (26.615+(90.461)+(tcb->m_segmentSize)+(13.904)+(47.297)+(tcb->m_cWnd)+(95.268)+(26.678)+(48.432));
