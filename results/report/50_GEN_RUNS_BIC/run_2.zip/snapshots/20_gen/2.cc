tcb->m_segmentSize = (int) ((10.136+(segmentsAcked)+(-3.436)+(tcb->m_cWnd)+(-42.384)+(5.194)+(-39.692))/-87.906);
ReduceCwnd (tcb);
