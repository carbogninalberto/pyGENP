tcb->m_segmentSize = (int) ((66.912*(tcb->m_segmentSize)*(14.979)*(97.298)*(25.812))/0.1);
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (59.643*(78.146)*(segmentsAcked)*(66.225));
	cnt = (int) (32.205*(tcb->m_ssThresh)*(98.829)*(8.894));
	tcb->m_cWnd = (int) (75.01-(62.078)-(77.332)-(71.457)-(cnt)-(63.79)-(0.885)-(10.892));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(tcb->m_cWnd)*(97.772)*(tcb->m_cWnd)*(52.713)*(26.595)*(20.161)*(72.182));
	cnt = (int) (tcb->m_ssThresh+(51.966)+(tcb->m_segmentSize)+(37.656)+(61.06)+(tcb->m_ssThresh)+(21.396)+(91.381));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((0.1)+((44.85-(56.174)-(98.783)-(1.188)-(35.802)-(73.812)-(70.568)))+(0.1)+(78.644)+(0.1))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(62.555)*(9.9)*(55.2)*(59.624)*(75.783)*(segmentsAcked));
	ReduceCwnd (tcb);

}
cnt = (int) (33.326*(75.026)*(tcb->m_ssThresh)*(47.529)*(84.985)*(65.009)*(43.803)*(11.08)*(6.611));
float kFYundtutNdhCIIg = (float) (11.451*(36.466)*(91.073)*(59.945)*(69.578)*(79.757)*(84.823));
ReduceCwnd (tcb);
