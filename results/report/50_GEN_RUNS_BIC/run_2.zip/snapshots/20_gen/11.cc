if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (75.195+(2.66)+(87.236)+(cnt)+(67.668)+(cnt)+(11.155)+(63.293)+(tcb->m_segmentSize));
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (48.341*(28.312)*(cnt)*(92.715));
	tcb->m_segmentSize = (int) (cnt*(32.013)*(63.767)*(28.006));

} else {
	tcb->m_segmentSize = (int) ((61.622*(35.419)*(10.284))/0.1);
	tcb->m_segmentSize = (int) (89.344*(20.034)*(10.46));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) ((((cnt-(61.492)-(83.899)-(71.859)-(81.36)))+(44.789)+(0.1)+(0.1))/((50.97)));
