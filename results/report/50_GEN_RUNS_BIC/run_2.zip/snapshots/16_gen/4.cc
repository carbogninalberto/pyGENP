if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (57.042*(41.965)*(99.853)*(49.279)*(-13.543)*(52.011)*(segmentsAcked)*(tcb->m_cWnd)*(21.525));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (70.361-(30.071)-(99.105)-(19.555));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (37.337-(23.521)-(13.562));
