if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (69.098+(3.207)+(-82.898));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(75.209)*(-10.106)*(15.53)*(91.236)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-43.816)*(51.588))/92.009);
tcb->m_cWnd = (int) (26.148+(13.914)+(25.694));
tcb->m_cWnd = (int) ((segmentsAcked*(-63.995)*(3.72)*(39.668)*(-6.84)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-80.031)*(-46.278))/26.413);
tcb->m_cWnd = (int) ((segmentsAcked*(27.675)*(-26.238)*(10.25)*(61.32)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-54.496)*(91.952))/66.691);
tcb->m_cWnd = (int) ((segmentsAcked*(94.721)*(-6.15)*(-18.656)*(5.619)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(89.653)*(33.602))/15.735);
tcb->m_cWnd = (int) ((segmentsAcked*(-24.854)*(13.888)*(39.884)*(44.872)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-86.922)*(15.692))/21.01);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(23.265)*(22.401)*(90.946)*(45.388)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-90.079)*(-81.574))/28.217);
tcb->m_cWnd = (int) (-83.027+(-55.072)+(58.639));
tcb->m_cWnd = (int) ((segmentsAcked*(60.899)*(-27.724)*(-46.194)*(82.442)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(79.625)*(78.149))/48.012);
tcb->m_cWnd = (int) ((segmentsAcked*(96.02)*(96.33)*(-63.667)*(43.105)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(93.404)*(25.279))/61.522);
tcb->m_cWnd = (int) ((segmentsAcked*(-78.295)*(79.205)*(-30.232)*(48.631)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-84.706)*(28.37))/-61.027);
tcb->m_cWnd = (int) ((segmentsAcked*(-18.011)*(65.269)*(-96.063)*(22.138)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-37.029)*(-35.342))/-99.806);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-83.228)*(18.199)*(27.331)*(4.656)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-63.358)*(32.588))/-75.503);
tcb->m_cWnd = (int) (62.388+(-52.124)+(-90.137));
tcb->m_cWnd = (int) ((segmentsAcked*(64.566)*(7.789)*(-87.782)*(-67.323)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-11.797)*(-11.149))/26.125);
tcb->m_cWnd = (int) ((segmentsAcked*(83.576)*(-61.984)*(48.697)*(21.192)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(14.487)*(-37.073))/92.781);
tcb->m_cWnd = (int) ((segmentsAcked*(51.537)*(-46.15)*(-3.452)*(13.937)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-72.374)*(18.245))/89.76);
tcb->m_cWnd = (int) ((segmentsAcked*(54.87)*(-3.02)*(20.133)*(0.778)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(78.975)*(-67.024))/12.728);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(7.141)*(-38.107)*(-65.089)*(32.832)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-30.272)*(45.132))/20.454);
tcb->m_cWnd = (int) (38.147+(1.058)+(92.66));
tcb->m_cWnd = (int) ((segmentsAcked*(87.85)*(27.726)*(-44.942)*(-20.213)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-20.11)*(-68.994))/89.635);
tcb->m_cWnd = (int) ((segmentsAcked*(-46.902)*(30.395)*(80.958)*(-60.332)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(14.354)*(17.448))/-4.374);
tcb->m_cWnd = (int) ((segmentsAcked*(35.388)*(32.059)*(-77.618)*(43.23)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(21.151)*(-81.0))/-51.548);
tcb->m_cWnd = (int) ((segmentsAcked*(-41.761)*(-12.71)*(-3.095)*(-4.886)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(45.248)*(-46.696))/4.348);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(17.013)*(-68.172)*(61.329)*(85.68)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(46.691)*(54.767))/31.192);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(53.789)*(-80.475)*(-85.216)*(-59.443)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-3.474)*(-14.233))/-22.815);
tcb->m_cWnd = (int) (-87.105+(-89.748)+(29.052));
tcb->m_cWnd = (int) ((segmentsAcked*(38.369)*(-28.053)*(37.403)*(-0.363)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(76.414)*(-23.96))/-68.479);
tcb->m_cWnd = (int) ((segmentsAcked*(38.158)*(48.057)*(91.523)*(88.365)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(85.277)*(-17.271))/-78.417);
tcb->m_cWnd = (int) ((segmentsAcked*(-6.248)*(-90.107)*(-52.956)*(88.049)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(97.635)*(-98.938))/-16.722);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(67.945)*(-59.482)*(-78.81)*(-8.43)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(15.06)*(-22.119))/-44.091);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(19.033)*(74.752)*(-87.68)*(37.084)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-63.531)*(38.554))/-80.673);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(24.939)*(59.55)*(-85.218)*(-43.06)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-22.155)*(59.818))/36.809);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (95.143+(-67.501)+(6.996));
tcb->m_cWnd = (int) ((segmentsAcked*(-45.895)*(52.521)*(73.303)*(-73.09)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(40.633)*(94.838))/-99.51);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(77.786)*(79.559)*(31.712)*(33.468)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-88.332)*(-88.25))/47.002);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(43.27)*(-22.054)*(97.686)*(-92.999)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-44.182)*(-14.071))/16.022);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
