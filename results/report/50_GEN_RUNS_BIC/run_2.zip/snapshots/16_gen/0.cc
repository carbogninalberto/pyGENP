if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (18.381+(-55.968)+(77.168));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(31.511)*(77.077)*(47.875)*(-25.543)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(86.853)*(-2.729))/-76.699);
tcb->m_cWnd = (int) ((segmentsAcked*(-31.841)*(-15.272)*(-71.263)*(-77.593)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-65.594)*(-44.126))/11.681);
tcb->m_cWnd = (int) ((segmentsAcked*(33.359)*(-64.898)*(96.939)*(46.679)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(6.284)*(69.471))/60.921);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (9.024+(-95.48)+(55.422));
tcb->m_cWnd = (int) ((segmentsAcked*(67.714)*(-52.776)*(35.062)*(-98.97)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-66.002)*(-43.123))/-55.969);
tcb->m_cWnd = (int) ((segmentsAcked*(-78.93)*(-12.188)*(74.059)*(-97.646)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-1.733)*(33.646))/-32.18);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-39.827)*(-11.56)*(-73.868)*(-57.934)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-71.992)*(-70.975))/-46.873);
tcb->m_cWnd = (int) ((segmentsAcked*(11.134)*(-77.819)*(-58.204)*(8.259)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-88.788)*(-81.893))/86.679);
tcb->m_cWnd = (int) ((segmentsAcked*(83.449)*(-31.527)*(-74.868)*(51.973)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(53.818)*(41.074))/-95.815);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (10.504+(-85.741)+(52.484));
tcb->m_cWnd = (int) ((segmentsAcked*(-65.916)*(62.984)*(-90.928)*(30.766)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-90.644)*(-9.227))/40.067);
tcb->m_cWnd = (int) ((segmentsAcked*(-76.571)*(-37.236)*(70.181)*(21.046)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-36.951)*(-91.142))/83.651);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(89.951)*(11.203)*(55.289)*(-82.687)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(18.164)*(74.471))/-63.247);
tcb->m_cWnd = (int) ((segmentsAcked*(68.979)*(-35.552)*(11.437)*(78.478)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(2.452)*(-43.841))/-96.969);
tcb->m_cWnd = (int) ((segmentsAcked*(-70.056)*(59.065)*(-99.395)*(79.863)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-38.416)*(-91.496))/47.414);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-42.88)*(34.657)*(-3.613)*(-75.986)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(36.465)*(-34.122))/-85.916);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (21.002+(84.574)+(90.916));
tcb->m_cWnd = (int) ((segmentsAcked*(-98.743)*(84.835)*(-19.082)*(21.822)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(63.049)*(-12.662))/27.174);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-76.914)*(84.354)*(56.601)*(19.124)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(18.169)*(-34.893))/-28.014);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-75.527)*(36.614)*(76.717)*(-83.97)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-90.393)*(-6.889))/-74.591);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
