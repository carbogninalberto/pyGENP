if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (27.185+(-2.671)+(-96.178));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-53.381)*(-98.365)*(-41.376)*(22.921)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-24.867)*(60.592))/-53.617);
tcb->m_cWnd = (int) ((segmentsAcked*(72.832)*(30.998)*(44.329)*(-51.913)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(43.386)*(2.165))/-83.724);
tcb->m_cWnd = (int) ((segmentsAcked*(-87.303)*(8.903)*(-96.49)*(-46.684)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-15.799)*(85.264))/-39.411);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-24.912+(56.487)+(-1.563));
tcb->m_cWnd = (int) ((segmentsAcked*(-68.79)*(-68.016)*(80.221)*(19.479)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-44.383)*(-93.438))/63.786);
tcb->m_cWnd = (int) ((segmentsAcked*(-97.661)*(-86.115)*(34.651)*(47.927)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-0.218)*(24.757))/63.722);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-77.705)*(-2.756)*(80.473)*(34.128)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(39.114)*(-39.254))/45.947);
tcb->m_cWnd = (int) ((segmentsAcked*(0.541)*(8.55)*(85.242)*(-98.662)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-32.886)*(-94.514))/57.459);
tcb->m_cWnd = (int) ((segmentsAcked*(28.925)*(94.932)*(-25.936)*(75.395)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-6.327)*(90.065))/28.767);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (50.582+(75.02)+(-56.567));
tcb->m_cWnd = (int) ((segmentsAcked*(13.336)*(13.166)*(-87.088)*(-67.601)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(65.102)*(46.405))/-18.055);
tcb->m_cWnd = (int) ((segmentsAcked*(5.973)*(84.475)*(-12.39)*(52.967)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(48.336)*(50.001))/-2.728);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(2.671)*(58.056)*(-48.699)*(-70.833)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(42.404)*(83.158))/62.031);
tcb->m_cWnd = (int) ((segmentsAcked*(-30.898)*(71.094)*(-93.033)*(92.617)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-88.971)*(32.292))/14.037);
tcb->m_cWnd = (int) ((segmentsAcked*(5.59)*(-68.557)*(89.591)*(21.036)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(17.722)*(-42.196))/25.066);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(79.86)*(76.675)*(-49.165)*(-78.283)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(54.06)*(-87.462))/20.758);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-70.321+(48.247)+(56.623));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(44.445)*(89.38)*(-77.838)*(-73.042)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(24.701)*(-19.643))/2.146);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) ((segmentsAcked*(16.945)*(-69.705)*(-19.83)*(73.274)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(28.752)*(41.544))/42.731);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(61.885)*(91.028)*(-18.2)*(99.167)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(63.206)*(88.335))/-59.709);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-67.983)*(64.142)*(-48.068)*(-40.782)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(64.865)*(-41.648))/-26.11);
tcb->m_cWnd = (int) ((segmentsAcked*(-82.08)*(-21.618)*(-28.23)*(-56.124)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-0.037)*(36.334))/-80.23);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-78.489)*(-84.847)*(71.779)*(-81.739)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-55.218)*(19.277))/42.454);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(13.966)*(78.363)*(2.77)*(-65.681)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-96.859)*(87.791))/-26.845);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-74.018+(-83.734)+(-97.954));
tcb->m_cWnd = (int) ((segmentsAcked*(52.946)*(66.141)*(34.918)*(17.651)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(28.317)*(-16.243))/62.676);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(47.025)*(13.007)*(-28.864)*(-28.054)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-82.397)*(-32.572))/15.786);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-54.874)*(86.26)*(45.74)*(84.413)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(90.48)*(-5.735))/95.872);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
