float grrHcFnHuZTJsKtN = (float) (-89.216/47.701);
