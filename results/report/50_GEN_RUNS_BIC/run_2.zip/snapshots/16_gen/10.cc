int zydREgaQSDwTxttZ = (int) (61.933-(28.932)-(24.065));
float grrHcFnHuZTJsKtN = (float) (-92.91/-54.646);
int XGNhipgRjhVlBCGT = (int) 82.759;
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (grrHcFnHuZTJsKtN <= segmentsAcked) {
	tcb->m_cWnd = (int) (-79.471-(98.654)-(50.812)-(56.35)-(57.734)-(9.457)-(2.778)-(59.28));

} else {
	tcb->m_cWnd = (int) (87.955+(zydREgaQSDwTxttZ)+(63.104)+(50.272));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
