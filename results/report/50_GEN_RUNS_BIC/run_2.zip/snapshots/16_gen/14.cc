tcb->m_ssThresh = (int) (90.937/60.768);
if (cnt < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (81.186-(tcb->m_segmentSize)-(segmentsAcked));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (27.46*(18.121)*(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
cnt = (int) (63.424/0.1);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (85.546-(92.958)-(64.499)-(68.477));
tcb->m_segmentSize = (int) (91.357+(16.84)+(segmentsAcked)+(6.095));
ReduceCwnd (tcb);
if (tcb->m_cWnd <= segmentsAcked) {
	segmentsAcked = (int) (43.114+(61.657)+(38.082)+(65.074)+(17.797)+(70.981)+(10.736));
	cnt = (int) (58.114*(tcb->m_ssThresh)*(cnt)*(73.652)*(29.487)*(16.27)*(tcb->m_cWnd)*(45.749)*(41.543));

} else {
	segmentsAcked = (int) (22.352*(cnt)*(97.166)*(53.37)*(95.176));
	tcb->m_ssThresh = (int) ((90.255-(cnt)-(segmentsAcked)-(36.402))/0.1);
	tcb->m_segmentSize = (int) (((18.668)+(0.1)+(86.564)+(0.1)+(47.441)+(0.1))/((0.1)+(89.067)));

}
tcb->m_cWnd = (int) (5.858-(70.227)-(2.505)-(28.598)-(45.787)-(5.639)-(cnt)-(61.642));
