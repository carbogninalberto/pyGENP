float HTqLlBreETFryUis = (float) (94.855-(95.292)-(74.211)-(-14.216)-(-43.265)-(-78.513)-(-66.694)-(-70.251));
HTqLlBreETFryUis = (float) (-29.287+(-41.479)+(53.017));
segmentsAcked = (int) (-11.438-(-73.833)-(53.584)-(-32.757)-(61.144)-(-65.18));
tcb->m_cWnd = (int) (-64.506-(20.532));
if (segmentsAcked != tcb->m_cWnd) {
	segmentsAcked = (int) (95.122+(8.445));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (-28.322-(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
