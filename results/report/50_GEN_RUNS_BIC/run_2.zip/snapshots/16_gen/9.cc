int zydREgaQSDwTxttZ = (int) (-66.561-(98.015)-(73.147));
float grrHcFnHuZTJsKtN = (float) (-49.413/-40.091);
int XGNhipgRjhVlBCGT = (int) (62.528-(31.348)-(50.393)-(-63.967)-(-20.853)-(5.287)-(-36.011)-(3.644));
