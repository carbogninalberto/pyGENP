if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= cnt) {
	tcb->m_cWnd = (int) (31.71+(40.16)+(64.337)+(49.959)+(21.41)+(42.094)+(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (42.3+(16.553)+(55.915)+(69.213)+(99.102)+(32.163));

} else {
	tcb->m_cWnd = (int) (11.611*(69.599)*(88.381)*(cnt));
	tcb->m_segmentSize = (int) (87.153+(19.822)+(98.085)+(tcb->m_ssThresh)+(73.523)+(97.004)+(19.145)+(76.513));
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (55.675-(tcb->m_segmentSize)-(tcb->m_ssThresh));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/54.331);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (32.79+(0.441)+(29.253)+(68.558)+(tcb->m_cWnd)+(40.322)+(5.616)+(90.507)+(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (65.856-(35.414)-(19.417)-(tcb->m_segmentSize)-(8.238));

}
cnt = (int) (56.803+(40.57)+(segmentsAcked)+(tcb->m_segmentSize)+(cnt));
if (segmentsAcked == segmentsAcked) {
	cnt = (int) (40.734*(0.469)*(48.573));

} else {
	cnt = (int) ((63.771*(17.892)*(51.137)*(tcb->m_ssThresh)*(79.399)*(69.072)*(tcb->m_ssThresh))/64.679);

}
tcb->m_ssThresh = (int) (tcb->m_segmentSize+(68.76)+(49.424)+(tcb->m_ssThresh)+(23.0));
