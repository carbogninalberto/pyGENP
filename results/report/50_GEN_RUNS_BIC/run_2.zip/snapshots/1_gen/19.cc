if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (0.418*(27.814)*(66.706)*(13.57)*(47.63)*(23.026)*(20.236)*(cnt)*(74.564));

} else {
	tcb->m_ssThresh = (int) (66.197*(1.687)*(80.759));
	tcb->m_segmentSize = (int) (26.846+(98.483)+(44.812)+(segmentsAcked)+(96.711)+(tcb->m_cWnd));

}
segmentsAcked = (int) (5.826*(cnt)*(17.456)*(38.127)*(23.567)*(54.444)*(94.052)*(66.474));
if (cnt <= tcb->m_ssThresh) {
	segmentsAcked = (int) (14.582*(94.263)*(12.898));

} else {
	segmentsAcked = (int) (97.353*(71.73)*(76.74)*(1.996));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (12.919+(segmentsAcked)+(64.377)+(65.017)+(99.255));

}
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (98.745*(33.408)*(59.73));

}
segmentsAcked = (int) (tcb->m_ssThresh+(segmentsAcked)+(5.326)+(tcb->m_segmentSize)+(31.279));
cnt = (int) (6.326*(tcb->m_ssThresh)*(cnt)*(10.13));
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	cnt = (int) (75.701+(57.879));
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(38.359)-(52.586)-(tcb->m_ssThresh)-(61.454)-(5.098)-(27.107));

} else {
	cnt = (int) (tcb->m_segmentSize+(42.941)+(70.234)+(66.815)+(28.468)+(46.075)+(10.719)+(96.001));

}
