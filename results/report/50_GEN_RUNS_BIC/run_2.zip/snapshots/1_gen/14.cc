tcb->m_cWnd = (int) (14.813+(97.585)+(68.032));
float cPEIBOquoBrzrSpT = (float) (87.078/85.317);
tcb->m_ssThresh = (int) (77.112+(89.75)+(77.139)+(15.663));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > tcb->m_cWnd) {
	cPEIBOquoBrzrSpT = (float) (87.37-(9.325)-(tcb->m_cWnd)-(65.969)-(20.276)-(77.785)-(21.783)-(66.184)-(73.083));

} else {
	cPEIBOquoBrzrSpT = (float) (92.118+(19.569)+(6.651));
	tcb->m_segmentSize = (int) (segmentsAcked-(75.285)-(cnt)-(54.493));
	tcb->m_ssThresh = (int) (77.636-(80.349)-(47.102)-(segmentsAcked));

}
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) ((((tcb->m_cWnd+(40.129)+(cPEIBOquoBrzrSpT)+(44.286)+(65.293)+(28.812)+(5.774)))+(0.1)+(0.1)+(0.1)+(5.426))/((0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (0.1/0.1);

}
