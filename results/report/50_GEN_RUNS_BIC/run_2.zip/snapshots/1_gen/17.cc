float PkZiKXiiXePbUNbr = (float) (71.775-(46.148));
float QSQjvCRxWrcHoeAC = (float) (tcb->m_segmentSize+(segmentsAcked)+(75.677)+(28.769)+(93.423));
ReduceCwnd (tcb);
if (QSQjvCRxWrcHoeAC <= QSQjvCRxWrcHoeAC) {
	cnt = (int) (0.1/72.53);
	tcb->m_segmentSize = (int) ((82.14+(7.667)+(tcb->m_segmentSize)+(27.618)+(13.798)+(53.378))/79.286);
	PkZiKXiiXePbUNbr = (float) (tcb->m_segmentSize+(85.79)+(77.678)+(PkZiKXiiXePbUNbr));

} else {
	cnt = (int) (51.3-(65.764)-(84.702)-(50.841)-(20.607)-(14.528));
	tcb->m_cWnd = (int) (segmentsAcked-(21.269)-(cnt));

}
if (tcb->m_segmentSize >= PkZiKXiiXePbUNbr) {
	tcb->m_cWnd = (int) (((67.442)+((61.527+(24.607)+(62.571)+(39.909)))+((7.175*(83.61)*(cnt)*(67.248)*(70.391)*(39.44)*(5.921)*(84.752)*(61.851)))+(0.1)+(70.282))/((0.1)+(0.1)));
	cnt = (int) (19.757-(QSQjvCRxWrcHoeAC)-(73.24)-(23.041)-(2.81)-(tcb->m_segmentSize)-(70.686)-(6.057));

} else {
	tcb->m_cWnd = (int) (16.033-(8.206)-(tcb->m_ssThresh)-(47.106)-(QSQjvCRxWrcHoeAC)-(98.161)-(72.781)-(segmentsAcked)-(12.677));

}
