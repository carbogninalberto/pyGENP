if (segmentsAcked == tcb->m_cWnd) {
	cnt = (int) (19.276+(26.049)+(31.534)+(tcb->m_ssThresh));

} else {
	cnt = (int) (((0.1)+(54.214)+((14.826-(57.216)-(50.168)-(16.44)-(cnt)-(56.325)-(tcb->m_segmentSize)-(11.852)))+(83.6)+(0.1))/((0.1)+(15.326)+(0.1)+(0.1)));
	tcb->m_ssThresh = (int) (cnt-(78.011)-(55.539)-(90.937)-(28.365)-(39.257));

}
if (cnt > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((22.128)+(98.499)+(15.315)+(0.1)+(0.1))/((0.1)+(88.39)+(0.1)));

} else {
	tcb->m_cWnd = (int) (0.1/30.182);

}
ReduceCwnd (tcb);
cnt = (int) (18.647*(24.279)*(8.727)*(76.245)*(99.881));
if (cnt < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (44.668-(81.93));
	cnt = (int) (14.935-(57.546)-(cnt)-(segmentsAcked)-(81.829)-(82.561)-(78.295));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(83.307)-(37.009)-(55.479)-(26.419)-(85.868)-(26.034)-(5.508));

}
ReduceCwnd (tcb);
