if (cnt > segmentsAcked) {
	tcb->m_cWnd = (int) (92.089+(1.305)+(75.826)+(98.347)+(20.265)+(15.6)+(85.953));

} else {
	tcb->m_cWnd = (int) (44.498*(36.715)*(53.482)*(81.533)*(44.85)*(cnt)*(22.542));
	tcb->m_cWnd = (int) (0.1/65.91);
	segmentsAcked = (int) (cnt-(cnt)-(17.098)-(69.365)-(71.056)-(96.695));

}
tcb->m_segmentSize = (int) (86.462*(92.934)*(2.119)*(89.568)*(64.301)*(segmentsAcked)*(63.84)*(segmentsAcked));
segmentsAcked = (int) (segmentsAcked*(4.305)*(74.971)*(70.025)*(85.118));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < cnt) {
	tcb->m_cWnd = (int) (97.456-(1.36)-(cnt)-(tcb->m_cWnd)-(16.406));
	tcb->m_cWnd = (int) (90.157+(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (0.975*(26.431)*(14.437)*(62.588)*(tcb->m_cWnd)*(23.413)*(-0.015)*(tcb->m_segmentSize));

}
tcb->m_ssThresh = (int) (96.007/0.1);
ReduceCwnd (tcb);
