cnt = (int) (6.051+(tcb->m_ssThresh)+(87.163)+(62.133)+(segmentsAcked)+(29.113));
cnt = (int) (((60.623)+(0.1)+(14.51)+(0.1)+(0.1))/((0.1)+(14.933)+(0.1)+(6.94)));
tcb->m_segmentSize = (int) (96.186/0.1);
tcb->m_cWnd = (int) (20.514+(58.813)+(81.74)+(tcb->m_ssThresh)+(56.117)+(78.125));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
