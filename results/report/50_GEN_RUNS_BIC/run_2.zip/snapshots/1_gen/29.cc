if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (26.523*(2.283)*(tcb->m_segmentSize)*(59.931)*(cnt)*(31.218)*(50.21));
	cnt = (int) (85.395-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(92.184)-(90.897));
	tcb->m_cWnd = (int) (71.746*(segmentsAcked)*(tcb->m_cWnd)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(segmentsAcked)*(41.017)*(cnt)*(16.614));

} else {
	tcb->m_cWnd = (int) (88.254-(tcb->m_ssThresh)-(44.13)-(88.728)-(59.449)-(31.254));
	cnt = (int) (64.301+(27.562)+(78.497)+(9.498)+(3.507)+(segmentsAcked));
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(78.52)+(39.669)+(2.471)+(96.885)+(33.247)+(40.56)+(84.194)+(segmentsAcked));

}
tcb->m_segmentSize = (int) (95.782*(tcb->m_cWnd)*(71.153)*(16.077));
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (((28.492)+(5.729)+(69.991)+(0.1))/((62.169)+(43.048)+(31.886)));
	tcb->m_ssThresh = (int) (((68.127)+((94.335-(88.788)-(5.603)-(77.081)-(7.531)-(64.148)-(34.223)-(tcb->m_cWnd)))+(45.438)+(0.1)+(54.396))/((86.186)));

} else {
	tcb->m_ssThresh = (int) (70.126+(13.171)+(cnt)+(82.107)+(segmentsAcked)+(73.565));
	tcb->m_cWnd = (int) (14.773-(11.96)-(18.123)-(39.109)-(tcb->m_segmentSize)-(54.02)-(segmentsAcked)-(74.189)-(cnt));

}
tcb->m_ssThresh = (int) (63.547/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
