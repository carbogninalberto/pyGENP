if (cnt != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+((94.076-(14.293)-(69.106)-(23.139)-(81.047)-(69.294)-(12.516)-(27.153)-(cnt)))+(93.587))/((68.973)+(88.556)+(0.1)+(52.236)));

} else {
	tcb->m_ssThresh = (int) (63.485*(tcb->m_cWnd)*(tcb->m_ssThresh));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < tcb->m_ssThresh) {
	cnt = (int) (segmentsAcked-(tcb->m_ssThresh)-(9.525)-(92.546)-(99.258)-(tcb->m_segmentSize)-(68.854));

} else {
	cnt = (int) (87.456-(38.851)-(35.939)-(26.825)-(tcb->m_ssThresh)-(11.291)-(20.918));
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (((0.1)+((30.502+(23.331)+(63.02)+(46.266)))+(0.1)+(70.635)+(37.094))/((0.1)+(66.748)+(2.355)+(8.0)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (0.1/(18.544*(tcb->m_segmentSize)*(22.893)*(75.748)));
