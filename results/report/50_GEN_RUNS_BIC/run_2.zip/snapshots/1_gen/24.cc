ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (7.96+(42.16)+(60.749));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_ssThresh = (int) (87.554*(segmentsAcked)*(tcb->m_cWnd)*(92.578)*(26.266));
	tcb->m_segmentSize = (int) (10.148+(7.556)+(8.244)+(segmentsAcked)+(15.073)+(tcb->m_segmentSize)+(63.064)+(13.342));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (79.098-(69.82)-(69.861)-(tcb->m_cWnd)-(23.879));

}
tcb->m_cWnd = (int) ((segmentsAcked*(77.926)*(29.067)*(79.3)*(57.8)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(33.29)*(30.704))/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
