cnt = (int) (60.646+(27.911)+(23.319)+(53.218)+(69.471)+(6.913)+(59.709)+(70.962)+(22.978));
if (cnt == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (88.896-(23.557)-(99.528)-(tcb->m_cWnd)-(73.929)-(11.429)-(33.931));
	segmentsAcked = (int) (6.73+(55.426)+(26.627)+(54.853)+(98.479)+(2.033)+(16.562)+(33.554)+(86.898));

} else {
	tcb->m_cWnd = (int) (45.652-(51.43)-(65.434));
	segmentsAcked = (int) (93.904*(45.549)*(82.798)*(tcb->m_segmentSize)*(46.079)*(31.768)*(77.418));
	cnt = (int) (67.679-(tcb->m_segmentSize)-(92.124)-(tcb->m_cWnd)-(34.523));

}
int gXncIWdqEtmFERpk = (int) (84.63+(5.555));
ReduceCwnd (tcb);
if (tcb->m_segmentSize != cnt) {
	cnt = (int) (34.325*(95.288)*(31.364)*(57.031)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(6.555));

} else {
	cnt = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(40.007)*(99.285));
	tcb->m_cWnd = (int) (93.778*(11.371));

}
