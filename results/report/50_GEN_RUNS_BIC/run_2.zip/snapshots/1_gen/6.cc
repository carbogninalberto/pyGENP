ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < cnt) {
	tcb->m_segmentSize = (int) (52.335+(tcb->m_segmentSize)+(35.877)+(87.246));
	tcb->m_ssThresh = (int) (37.076*(91.254)*(cnt)*(94.547));
	segmentsAcked = (int) (40.986*(3.396));

} else {
	tcb->m_segmentSize = (int) (cnt-(18.498)-(38.367)-(48.053)-(2.378)-(72.834)-(54.616));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float FAYqRYYZzPLrnBnv = (float) (3.173*(8.364)*(58.709)*(tcb->m_segmentSize)*(12.578)*(57.737)*(tcb->m_segmentSize)*(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
