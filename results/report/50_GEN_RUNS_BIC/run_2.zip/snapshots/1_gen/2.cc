if (segmentsAcked <= segmentsAcked) {
	cnt = (int) (52.105*(61.565)*(41.269)*(69.405)*(63.87));
	cnt = (int) (79.538*(48.854)*(62.106)*(77.297)*(28.454)*(23.563)*(53.112));

} else {
	cnt = (int) (20.705-(1.139));

}
cnt = (int) (39.252*(72.067)*(78.741));
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((89.642)+(0.1)+(22.863)+(89.225)+(82.704)));
	cnt = (int) (68.365*(21.439)*(tcb->m_segmentSize)*(3.139));
	cnt = (int) (18.458-(tcb->m_cWnd)-(tcb->m_cWnd)-(58.826)-(74.052));

} else {
	tcb->m_ssThresh = (int) (19.263-(24.899)-(99.849)-(44.551)-(24.512)-(tcb->m_cWnd)-(70.899)-(52.427));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(88.585)-(69.542)-(65.431)-(2.759)-(29.913)-(13.727)-(50.812)-(23.449));
