tcb->m_ssThresh = (int) (7.464-(12.157)-(83.026));
segmentsAcked = (int) (tcb->m_segmentSize+(segmentsAcked)+(86.817)+(90.652)+(5.16)+(72.716)+(90.868)+(68.363)+(segmentsAcked));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) ((((segmentsAcked*(69.119)*(34.528)*(98.376)*(70.546)*(96.829)*(tcb->m_ssThresh)*(14.425)*(40.347)))+(65.868)+((80.178*(35.201)*(27.828)*(55.895)*(65.658)*(tcb->m_segmentSize)*(64.312)))+(93.231)+(57.435))/((64.355)));
