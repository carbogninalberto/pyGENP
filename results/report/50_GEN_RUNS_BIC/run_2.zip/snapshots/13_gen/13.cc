ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (tcb->m_ssThresh*(53.411)*(cnt)*(85.037)*(tcb->m_ssThresh));
if (tcb->m_segmentSize >= cnt) {
	tcb->m_cWnd = (int) (63.969*(tcb->m_ssThresh)*(83.677)*(cnt));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (95.418*(19.704)*(29.274)*(75.929)*(65.765)*(10.588));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (97.084/22.984);

}
if (tcb->m_ssThresh != cnt) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(41.813)*(67.27)*(90.678)*(53.16)*(9.573)*(41.491)*(tcb->m_cWnd)*(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (79.204-(41.271)-(tcb->m_segmentSize)-(91.185)-(cnt)-(19.897));

}
