float uyPYrXmzUJPLFdxQ = (float) (-97.15/10.156);
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (29.484*(14.028)*(tcb->m_segmentSize));
	uyPYrXmzUJPLFdxQ = (float) (7.59-(tcb->m_segmentSize)-(19.214)-(20.361)-(9.489)-(uyPYrXmzUJPLFdxQ)-(99.76)-(2.757));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-79.667*(2.436)*(-6.703)*(-40.741)*(-56.318)*(-29.509)*(-25.671)*(-73.416));
