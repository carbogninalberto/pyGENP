if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-73.028+(-56.958)+(75.049));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-85.678)*(-31.896)*(0.002)*(-8.801)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(67.76)*(43.593))/0.728);
tcb->m_cWnd = (int) ((segmentsAcked*(90.618)*(30.544)*(44.123)*(-24.393)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(37.036)*(-57.055))/-21.678);
tcb->m_cWnd = (int) ((segmentsAcked*(42.75)*(-26.837)*(-90.099)*(-63.788)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(81.239)*(-3.507))/-81.717);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (53.24+(-0.561)+(98.892));
tcb->m_cWnd = (int) ((segmentsAcked*(72.337)*(80.474)*(60.705)*(-12.744)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(96.994)*(80.853))/27.82);
tcb->m_cWnd = (int) ((segmentsAcked*(-23.715)*(4.17)*(23.494)*(-95.825)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(45.017)*(-90.355))/80.473);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(93.806)*(69.552)*(96.195)*(-72.296)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-37.09)*(-1.407))/93.943);
tcb->m_cWnd = (int) ((segmentsAcked*(-96.181)*(33.23)*(28.753)*(87.749)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(16.101)*(-68.724))/-91.951);
tcb->m_cWnd = (int) ((segmentsAcked*(-23.847)*(34.39)*(44.964)*(-67.83)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(72.173)*(-21.497))/60.506);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (48.98+(-82.905)+(42.295));
tcb->m_cWnd = (int) ((segmentsAcked*(-20.642)*(94.493)*(55.348)*(64.876)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-54.706)*(98.621))/-75.117);
tcb->m_cWnd = (int) ((segmentsAcked*(45.302)*(78.366)*(94.513)*(-28.764)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(33.092)*(-86.999))/82.558);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-27.196)*(-21.215)*(56.034)*(10.166)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-73.395)*(-17.004))/-66.716);
tcb->m_cWnd = (int) ((segmentsAcked*(-96.537)*(7.198)*(76.219)*(-13.646)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(64.724)*(28.513))/-10.717);
tcb->m_cWnd = (int) ((segmentsAcked*(94.128)*(-75.318)*(-58.856)*(52.597)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-84.612)*(-32.715))/35.39);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-76.267)*(-9.867)*(-16.887)*(-48.264)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-10.176)*(-45.202))/-50.157);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (22.432+(41.371)+(-89.477));
tcb->m_cWnd = (int) ((segmentsAcked*(5.32)*(-50.777)*(-34.563)*(-14.081)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-46.704)*(-43.222))/68.166);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(99.512)*(41.406)*(40.428)*(-35.129)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(29.248)*(-16.388))/-26.297);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(10.959)*(15.009)*(-57.727)*(-57.057)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-8.156)*(-9.48))/71.597);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
