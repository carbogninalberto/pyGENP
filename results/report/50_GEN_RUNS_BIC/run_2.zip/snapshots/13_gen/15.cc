if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh == cnt) {
	tcb->m_ssThresh = (int) (42.54+(6.745)+(57.722)+(82.364)+(tcb->m_ssThresh)+(85.69));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (26.126*(82.615)*(95.898)*(65.742)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(32.982)*(8.122)*(14.068));

} else {
	tcb->m_ssThresh = (int) (63.688*(17.36)*(cnt)*(93.752)*(73.86)*(tcb->m_cWnd));

}
ReduceCwnd (tcb);
cnt = (int) (((0.1)+(51.019)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));
if (tcb->m_segmentSize < cnt) {
	tcb->m_ssThresh = (int) (14.338-(35.627)-(cnt)-(74.324)-(56.482)-(39.869)-(63.92)-(52.663)-(93.844));

} else {
	tcb->m_ssThresh = (int) (80.752+(43.746)+(7.847));
	tcb->m_ssThresh = (int) (56.314-(95.658)-(28.367)-(97.792)-(44.884));

}
if (tcb->m_ssThresh < segmentsAcked) {
	cnt = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(88.998));
	tcb->m_ssThresh = (int) (cnt-(59.249)-(69.224)-(87.496)-(tcb->m_segmentSize)-(0.75)-(15.921)-(8.635));

} else {
	cnt = (int) (segmentsAcked*(88.497)*(73.922)*(43.752)*(97.943)*(3.357)*(51.592));
	tcb->m_segmentSize = (int) (24.861-(18.156));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
