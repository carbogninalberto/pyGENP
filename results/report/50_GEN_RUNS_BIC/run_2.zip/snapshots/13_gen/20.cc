if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (18.736*(tcb->m_segmentSize)*(22.77)*(12.485)*(91.072)*(51.504)*(74.191)*(80.641)*(tcb->m_cWnd));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (96.539+(87.379)+(segmentsAcked)+(69.626)+(1.561)+(74.799));
tcb->m_cWnd = (int) (41.062-(65.963)-(36.644)-(51.86)-(56.695));
