int MTWwvWQFwErSBauC = (int) 71.218;
