if (segmentsAcked < tcb->m_segmentSize) {
	segmentsAcked = (int) (94.721*(24.441)*(42.065)*(tcb->m_ssThresh)*(cnt)*(62.455)*(5.653)*(49.146)*(79.155));

} else {
	segmentsAcked = (int) (11.636/0.1);
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (76.861*(cnt)*(94.559)*(95.118)*(71.606));
tcb->m_ssThresh = (int) (55.273-(60.427)-(segmentsAcked)-(32.469)-(94.432)-(84.294));
if (segmentsAcked < cnt) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(47.83)+(14.31)+(56.406)+(tcb->m_ssThresh)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (13.637-(tcb->m_segmentSize)-(54.383)-(90.779));
	segmentsAcked = (int) (48.829/0.1);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (91.54-(84.662)-(66.003)-(47.874)-(22.402)-(14.773));

}
if (tcb->m_cWnd < cnt) {
	tcb->m_segmentSize = (int) (99.937-(51.191)-(tcb->m_segmentSize)-(32.62)-(31.108)-(13.875)-(79.114));
	tcb->m_segmentSize = (int) (7.744*(8.337)*(97.604)*(72.885)*(65.826)*(cnt)*(59.984));
	tcb->m_segmentSize = (int) (11.816-(3.396)-(65.318)-(97.976)-(22.351));

} else {
	tcb->m_segmentSize = (int) ((99.871*(cnt)*(24.927)*(tcb->m_ssThresh)*(10.671)*(17.05)*(17.286)*(22.579))/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(75.639)*(29.232)*(1.66)*(22.168)*(9.695)*(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (23.485+(tcb->m_cWnd));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh >= segmentsAcked) {
	segmentsAcked = (int) (24.912*(tcb->m_ssThresh)*(0.208));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (53.347+(63.772)+(51.101)+(34.305)+(43.646));
	tcb->m_cWnd = (int) (27.747/40.688);

}
