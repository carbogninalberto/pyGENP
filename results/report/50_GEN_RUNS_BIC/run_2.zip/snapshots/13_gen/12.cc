float WceGdnmpRptSIyJv = (float) (77.135*(35.117));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (WceGdnmpRptSIyJv >= WceGdnmpRptSIyJv) {
	cnt = (int) (66.514+(16.07)+(tcb->m_ssThresh)+(WceGdnmpRptSIyJv)+(64.263)+(78.556)+(WceGdnmpRptSIyJv)+(95.554));
	segmentsAcked = (int) (((11.004)+(0.1)+(0.1)+(20.136)+(80.266))/((0.1)+(0.1)+(74.172)+(0.1)));
	cnt = (int) (47.815*(59.753)*(83.591)*(segmentsAcked)*(tcb->m_cWnd));

} else {
	cnt = (int) (50.319+(40.684)+(tcb->m_ssThresh)+(59.441)+(cnt)+(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (WceGdnmpRptSIyJv-(28.124)-(tcb->m_cWnd)-(63.793)-(tcb->m_cWnd)-(40.721));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (WceGdnmpRptSIyJv*(12.905)*(17.644)*(cnt)*(58.695)*(97.18));
WceGdnmpRptSIyJv = (float) (3.06-(4.35)-(WceGdnmpRptSIyJv)-(60.51));
