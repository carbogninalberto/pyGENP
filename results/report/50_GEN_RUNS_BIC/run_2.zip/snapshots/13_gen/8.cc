if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (76.501+(-9.236)+(-51.551));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-37.919)*(41.292)*(76.972)*(90.555)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-28.663)*(97.862))/-25.527);
tcb->m_cWnd = (int) ((segmentsAcked*(16.324)*(9.373)*(46.565)*(44.095)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(99.671)*(0.806))/-28.317);
tcb->m_cWnd = (int) ((segmentsAcked*(-75.327)*(-0.862)*(43.24)*(99.981)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-33.656)*(-58.9))/62.681);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (32.573+(-95.553)+(-33.053));
tcb->m_cWnd = (int) ((segmentsAcked*(17.094)*(-29.865)*(49.06)*(40.815)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-68.073)*(-38.369))/-46.724);
tcb->m_cWnd = (int) ((segmentsAcked*(-48.985)*(94.802)*(-99.241)*(-28.806)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-12.034)*(66.582))/-19.291);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(94.437)*(-12.927)*(12.207)*(63.601)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-72.337)*(1.788))/39.374);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-40.188+(16.966)+(26.98));
tcb->m_cWnd = (int) ((segmentsAcked*(4.778)*(-50.626)*(20.37)*(26.834)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-85.77)*(-1.909))/-97.535);
tcb->m_cWnd = (int) ((segmentsAcked*(-54.874)*(84.076)*(-77.714)*(93.22)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-6.877)*(59.684))/5.961);
tcb->m_cWnd = (int) ((segmentsAcked*(67.7)*(33.406)*(-2.587)*(-69.647)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-75.129)*(92.686))/-88.784);
tcb->m_cWnd = (int) ((segmentsAcked*(-51.439)*(-7.957)*(-60.824)*(6.975)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(73.092)*(76.333))/55.608);
tcb->m_cWnd = (int) ((segmentsAcked*(44.194)*(-65.157)*(-51.967)*(71.295)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-87.2)*(99.562))/92.38);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-47.401)*(-83.854)*(-99.659)*(-85.926)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-93.038)*(-94.098))/31.857);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-11.207)*(-95.724)*(-50.129)*(19.769)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(89.962)*(-97.535))/-21.104);
tcb->m_cWnd = (int) (75.947+(-39.6)+(72.106));
tcb->m_cWnd = (int) ((segmentsAcked*(-42.356)*(0.318)*(-18.751)*(-27.918)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-37.085)*(63.057))/-80.225);
tcb->m_cWnd = (int) ((segmentsAcked*(23.727)*(-23.848)*(-12.387)*(-59.51)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(7.324)*(-19.97))/-70.767);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-42.887)*(72.002)*(79.23)*(4.734)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-39.993)*(41.767))/24.029);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-23.214+(-5.089)+(-22.894));
tcb->m_cWnd = (int) ((segmentsAcked*(-82.119)*(-92.453)*(75.406)*(-94.421)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-12.323)*(21.598))/-60.785);
tcb->m_cWnd = (int) ((segmentsAcked*(36.296)*(-61.215)*(67.239)*(33.046)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(56.618)*(-46.152))/96.688);
tcb->m_cWnd = (int) ((segmentsAcked*(9.342)*(-74.643)*(-57.643)*(-33.729)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(46.696)*(-91.75))/-46.789);
tcb->m_cWnd = (int) ((segmentsAcked*(85.063)*(11.266)*(97.75)*(54.479)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(8.871)*(-26.805))/-34.304);
tcb->m_cWnd = (int) ((segmentsAcked*(41.253)*(-0.402)*(53.995)*(-76.279)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(73.342)*(6.104))/89.552);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-82.692)*(93.205)*(72.459)*(89.308)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(97.704)*(28.903))/18.443);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(36.132)*(27.058)*(-83.484)*(79.482)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(1.504)*(19.722))/-80.55);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-12.954)*(70.767)*(-22.78)*(13.076)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(5.942)*(94.108))/-29.439);
tcb->m_cWnd = (int) (-71.722+(3.568)+(80.77));
tcb->m_cWnd = (int) ((segmentsAcked*(-75.817)*(-36.104)*(-45.166)*(-53.517)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-16.46)*(-12.087))/-32.305);
tcb->m_cWnd = (int) ((segmentsAcked*(-22.487)*(-44.081)*(15.026)*(-34.311)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-26.298)*(60.031))/-69.538);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-62.488)*(27.862)*(34.75)*(-9.383)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-97.159)*(-47.034))/-43.633);
tcb->m_cWnd = (int) ((segmentsAcked*(69.301)*(78.288)*(-43.334)*(-59.989)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-96.726)*(56.58))/84.415);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-99.335)*(-42.612)*(24.957)*(60.276)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-33.478)*(52.244))/-86.16);
tcb->m_cWnd = (int) (-14.288+(97.355)+(80.442));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-74.258)*(-89.542)*(3.889)*(-99.006)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-23.048)*(88.891))/-58.529);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-98.474)*(77.334)*(-11.662)*(65.678)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-49.128)*(-93.101))/71.747);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-96.513)*(21.552)*(-94.534)*(-15.132)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(65.564)*(29.313))/55.774);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
