tcb->m_ssThresh = (int) (94.065*(46.109)*(36.463)*(17.855)*(87.626)*(41.871)*(78.196));
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(42.334)+(54.983)+(60.195)+(53.048));
if (tcb->m_segmentSize != cnt) {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(16.389)+(0.1)+(0.1)+(0.1)+(41.43))/((70.097)+(74.62)));
	tcb->m_cWnd = (int) (23.037*(tcb->m_segmentSize)*(58.802)*(44.863)*(segmentsAcked)*(48.351)*(tcb->m_cWnd)*(4.409));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (24.173+(74.331));
	cnt = (int) (97.035-(79.548));

}
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(82.528)*(31.384)*(34.111)*(29.036));

} else {
	tcb->m_cWnd = (int) (((0.1)+((25.017+(43.023)+(52.584)+(36.87)))+(81.591)+(0.1)+(15.493)+(0.1))/((0.1)+(0.1)));

}
tcb->m_cWnd = (int) (0.1/0.1);
ReduceCwnd (tcb);
