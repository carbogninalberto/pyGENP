if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int QGPMnXwgGmxpTNbd = (int) (44.939*(95.843)*(59.739)*(25.161));
tcb->m_ssThresh = (int) ((((55.6+(26.801)+(cnt)+(66.436)+(69.879)))+(25.881)+(0.1)+((96.41-(75.545)-(2.647)-(33.838)-(cnt)))+(36.383))/((0.1)));
int CNgXthoaqddOnHgR = (int) (2.827*(29.605)*(85.157)*(72.599)*(78.138)*(QGPMnXwgGmxpTNbd)*(75.9)*(73.961));
if (tcb->m_ssThresh != segmentsAcked) {
	QGPMnXwgGmxpTNbd = (int) (19.55*(48.766));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (19.764*(26.767)*(62.849));

} else {
	QGPMnXwgGmxpTNbd = (int) (segmentsAcked+(25.177)+(73.633)+(CNgXthoaqddOnHgR));

}
if (segmentsAcked == cnt) {
	tcb->m_ssThresh = (int) ((((45.711+(23.158)+(94.037)+(69.679)+(74.773)))+(0.1)+(58.295)+(71.255))/((0.1)));
	tcb->m_ssThresh = (int) (cnt-(69.492)-(82.616)-(63.054));
	tcb->m_segmentSize = (int) (cnt*(36.789));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(32.111)+(12.455)+(12.708)+(47.112)+(23.802)+(QGPMnXwgGmxpTNbd)+(tcb->m_cWnd));

}
ReduceCwnd (tcb);
