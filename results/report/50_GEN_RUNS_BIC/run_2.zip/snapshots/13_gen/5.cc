int MTWwvWQFwErSBauC = (int) (-50.202*(34.566)*(-15.631)*(-36.522)*(-75.04)*(5.772)*(-68.268));
MTWwvWQFwErSBauC = (int) (-2.787+(-1.429)+(-30.365)+(-68.261)+(83.028)+(-24.581));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
