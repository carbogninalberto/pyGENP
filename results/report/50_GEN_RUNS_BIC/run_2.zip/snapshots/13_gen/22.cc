if (tcb->m_ssThresh <= tcb->m_cWnd) {
	segmentsAcked = (int) (35.677+(42.149)+(67.132)+(61.106));
	tcb->m_cWnd = (int) (((0.1)+(61.893)+(0.1)+((5.842*(84.587)*(52.54)*(tcb->m_segmentSize)*(71.042)*(39.621)*(tcb->m_cWnd)*(82.251)*(27.859)))+(0.1))/((84.476)+(7.108)));

} else {
	segmentsAcked = (int) (0.1/57.211);
	cnt = (int) (2.38+(31.655)+(92.793)+(18.305)+(segmentsAcked)+(1.386)+(60.524));

}
ReduceCwnd (tcb);
if (segmentsAcked <= segmentsAcked) {
	segmentsAcked = (int) (28.289+(58.07));
	tcb->m_cWnd = (int) (segmentsAcked+(66.109)+(32.269)+(88.927)+(24.184));
	tcb->m_segmentSize = (int) ((67.481-(cnt)-(9.127)-(72.607)-(73.456)-(44.837)-(16.909)-(tcb->m_ssThresh))/0.1);

} else {
	segmentsAcked = (int) (34.698+(6.053)+(64.068)+(74.54)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(82.739)+(81.316)+(80.578));

}
tcb->m_cWnd = (int) ((segmentsAcked-(9.129)-(10.319)-(56.167)-(26.547)-(11.086)-(22.821)-(7.377))/0.1);
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	cnt = (int) (9.162+(tcb->m_cWnd)+(42.714)+(tcb->m_ssThresh));

} else {
	cnt = (int) (20.357*(93.408)*(segmentsAcked)*(41.664)*(50.025));
	tcb->m_ssThresh = (int) (22.47*(tcb->m_segmentSize)*(36.716)*(6.277)*(74.351)*(68.152));

}
tcb->m_cWnd = (int) (21.133*(57.567)*(tcb->m_segmentSize)*(80.83)*(96.439)*(17.046)*(49.53));
if (tcb->m_cWnd <= cnt) {
	tcb->m_ssThresh = (int) (52.986+(45.651));
	tcb->m_segmentSize = (int) ((((49.021*(44.768)*(11.581)*(31.253)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(cnt)))+(56.969)+(57.428)+(13.886)+(0.1))/((0.1)+(48.122)+(85.083)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (21.518*(43.436)*(14.607)*(tcb->m_ssThresh)*(92.338)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(98.02));
	segmentsAcked = (int) (0.1/0.1);

}
