int MTWwvWQFwErSBauC = (int) (-2.261*(43.035)*(-49.812)*(-7.953)*(-19.588)*(75.432)*(16.831));
MTWwvWQFwErSBauC = (int) (-74.59+(51.228)+(-95.003)+(96.238)+(85.469)+(-66.206));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
