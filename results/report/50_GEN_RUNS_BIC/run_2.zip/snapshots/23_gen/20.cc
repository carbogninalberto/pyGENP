if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_ssThresh = (int) (20.12*(tcb->m_cWnd)*(43.309)*(30.34)*(60.393));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (12.335-(segmentsAcked)-(1.126)-(52.388)-(80.84)-(10.52)-(97.611)-(89.479));

}
if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (68.154-(96.788)-(30.181)-(23.053)-(82.41)-(19.996)-(segmentsAcked));
	tcb->m_cWnd = (int) (97.357+(0.51)+(94.615)+(tcb->m_segmentSize)+(cnt)+(28.149)+(tcb->m_ssThresh)+(0.063)+(segmentsAcked));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (44.185/19.894);
	tcb->m_cWnd = (int) (68.756-(1.679)-(65.63)-(26.642)-(40.306)-(segmentsAcked)-(89.623)-(78.413)-(5.135));

}
cnt = (int) (1.766-(59.738)-(tcb->m_segmentSize));
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	cnt = (int) (((0.1)+((30.429-(tcb->m_ssThresh)-(60.664)-(77.159)-(16.96)-(29.784)-(45.265)-(63.011)-(70.897)))+(0.1)+(0.1)+(0.1))/((0.1)));
	segmentsAcked = (int) (tcb->m_cWnd-(90.555)-(36.895)-(56.994));

} else {
	cnt = (int) (35.475-(23.217)-(74.36));

}
ReduceCwnd (tcb);
