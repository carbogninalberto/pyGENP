if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (tcb->m_segmentSize*(99.856)*(32.792)*(95.23)*(41.992)*(88.41)*(30.981));
cnt = (int) (71.49*(87.862)*(tcb->m_cWnd)*(26.727)*(40.314)*(cnt)*(59.434)*(1.041)*(16.842));
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (70.874-(84.533)-(97.01)-(61.947)-(25.613)-(39.88)-(32.462));

} else {
	tcb->m_ssThresh = (int) (cnt*(25.931)*(7.512)*(58.033)*(20.067)*(2.027)*(89.851)*(56.337)*(17.914));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) ((((0.551-(5.225)-(33.199)-(40.74)))+(0.1)+((cnt*(segmentsAcked)*(34.287)*(83.651)*(97.663)*(0.347)))+((8.344*(62.768)*(cnt)*(6.204)*(80.023)*(54.451)*(41.092)*(13.224)))+(0.1)+(1.296))/((62.352)+(75.986)+(56.396)));
cnt = (int) (70.987+(49.543)+(31.216)+(tcb->m_ssThresh)+(62.652));
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_ssThresh = (int) (10.137+(99.545)+(96.394));
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(29.466)*(cnt)*(0.602)*(11.813)*(42.207)*(cnt)*(cnt));

} else {
	tcb->m_ssThresh = (int) (38.322+(34.796)+(37.314)+(48.672));
	tcb->m_ssThresh = (int) (tcb->m_cWnd-(tcb->m_ssThresh)-(73.651)-(54.724)-(81.693)-(41.888)-(26.456));
	ReduceCwnd (tcb);

}
