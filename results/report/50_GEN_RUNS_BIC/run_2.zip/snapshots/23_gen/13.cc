if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (((12.094)+(0.1)+(0.1)+(0.1))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (50.764-(78.884)-(27.05)-(72.915)-(75.635)-(segmentsAcked)-(69.475));
	cnt = (int) (16.173/53.318);
	ReduceCwnd (tcb);

}
if (tcb->m_ssThresh == cnt) {
	tcb->m_cWnd = (int) (94.948+(17.558)+(82.484)+(tcb->m_cWnd)+(75.157));

} else {
	tcb->m_cWnd = (int) (43.764*(43.044)*(9.352));

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (((0.1)+(15.73)+((tcb->m_segmentSize-(12.59)-(59.569)-(22.279)-(75.63)-(21.279)-(cnt)-(18.133)))+(0.1))/((55.708)));
tcb->m_cWnd = (int) (56.1+(99.322));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
