int hLTMahRAslvZcHll = (int) (tcb->m_segmentSize*(15.971)*(73.269));
ReduceCwnd (tcb);
int sUAYCxTyJUDiFbRq = (int) (95.07*(97.451)*(54.324)*(hLTMahRAslvZcHll)*(26.379)*(41.212));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int bjDLdRcvqEDprQzi = (int) (42.715-(49.548)-(59.739)-(89.862));
