ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(cnt)+(26.9)+(2.648)+(47.539)+(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (12.564-(77.679)-(24.226)-(96.641));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (segmentsAcked+(19.405)+(24.483)+(tcb->m_ssThresh)+(2.519)+(21.253));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
