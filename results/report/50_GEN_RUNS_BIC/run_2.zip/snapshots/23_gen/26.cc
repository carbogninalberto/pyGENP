if (segmentsAcked >= segmentsAcked) {
	tcb->m_ssThresh = (int) (79.375+(91.531)+(tcb->m_segmentSize)+(3.799)+(21.737)+(46.266)+(61.186));
	segmentsAcked = (int) (57.139-(94.917)-(16.27));
	cnt = (int) (99.404*(15.808)*(46.194)*(56.666));

} else {
	tcb->m_ssThresh = (int) (34.676-(9.198)-(28.711));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (73.043/51.503);
cnt = (int) (((0.1)+(0.1)+(99.806)+(0.1)+(2.827)+(0.1)+(71.251))/((10.15)));
cnt = (int) (42.986*(42.5)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(52.056));
ReduceCwnd (tcb);
if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (12.574*(83.479)*(59.533)*(89.857)*(38.523));
	segmentsAcked = (int) (93.519+(7.43)+(40.129)+(48.239)+(69.698)+(cnt)+(21.319));
	segmentsAcked = (int) (0.252-(97.891));

} else {
	tcb->m_ssThresh = (int) (80.802-(cnt)-(segmentsAcked)-(tcb->m_ssThresh));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
