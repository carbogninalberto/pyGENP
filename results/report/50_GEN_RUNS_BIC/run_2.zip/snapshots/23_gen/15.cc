if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (((40.625)+(0.1)+(0.1)+(0.1))/((89.18)+(2.699)));
	segmentsAcked = (int) (93.923/49.986);
	tcb->m_cWnd = (int) (62.861-(cnt)-(98.403)-(54.305)-(48.198)-(tcb->m_ssThresh)-(84.026)-(78.903));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(89.516)+(93.345)+(16.093)+(76.012));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (61.691-(31.636));

}
cnt = (int) (47.579-(29.848)-(61.433));
int BJrnkesCwVeBipWO = (int) (0.1/0.1);
