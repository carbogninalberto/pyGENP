int YhqOwOvUVjYezGhq = (int) ((50.658*(-72.532)*(79.602)*(-63.113)*(-14.554)*(-44.875))/-52.739);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (((96.162)+((91.341*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(34.342)*(-83.964)*(-66.791)))+(-13.881)+(-45.671)+(19.346)+(-49.338))/((-3.737)+(79.286)+(-51.058)));
YhqOwOvUVjYezGhq = (int) (-74.821-(-63.237)-(91.79));
if (YhqOwOvUVjYezGhq < segmentsAcked) {
	tcb->m_cWnd = (int) (47.646+(9.097)+(91.06)+(87.143)+(52.718)+(0.432)+(27.779)+(55.191));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(5.298)+(48.106)+(-11.506)+(44.292)+(80.284));

}
