tcb->m_cWnd = (int) (-47.717/15.57);
