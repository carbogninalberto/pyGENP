float mVkcUfXByVZLZtxy = (float) (-70.255+(-35.593)+(-54.305)+(90.314)+(80.118)+(-1.438));
tcb->m_segmentSize = (int) (57.741+(-9.024)+(72.842)+(-63.266)+(74.303));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
