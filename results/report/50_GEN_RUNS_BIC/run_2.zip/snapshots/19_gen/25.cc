tcb->m_segmentSize = (int) (93.591-(21.145)-(51.106)-(7.125)-(80.486)-(10.954)-(99.718)-(cnt));
ReduceCwnd (tcb);
segmentsAcked = (int) (79.052-(91.383));
ReduceCwnd (tcb);
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	segmentsAcked = (int) (87.696/(37.353+(0.141)));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (((17.124)+(34.602)+(3.91)+(13.949)+(43.585))/((0.1)+(25.308)+(23.682)+(99.823)));

}
