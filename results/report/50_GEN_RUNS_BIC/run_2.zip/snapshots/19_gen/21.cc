int VKZjcLntzrHPZCxQ = (int) (72.164*(59.858)*(81.511)*(35.26)*(72.048)*(0.517)*(67.144)*(8.425));
if (tcb->m_ssThresh == cnt) {
	segmentsAcked = (int) (70.083*(18.741)*(61.253)*(82.066)*(84.782));
	cnt = (int) (51.625-(70.288)-(62.778)-(59.181)-(26.986)-(16.556)-(54.462));
	segmentsAcked = (int) (93.07-(cnt)-(99.595)-(74.757)-(70.171)-(37.69)-(12.813)-(53.145));

} else {
	segmentsAcked = (int) (VKZjcLntzrHPZCxQ+(50.134)+(12.896)+(67.562)+(99.507)+(78.111)+(29.124)+(66.091));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_ssThresh = (int) (73.572+(73.69)+(63.92)+(tcb->m_segmentSize)+(80.694)+(45.795)+(20.024)+(40.504)+(15.557));

} else {
	tcb->m_ssThresh = (int) (95.407+(24.623));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
int tJcvTKJaGYCXBUHT = (int) (69.059-(59.152)-(cnt)-(cnt)-(75.746));
tcb->m_segmentSize = (int) (34.538*(43.412)*(41.838)*(0.607)*(25.601)*(1.693)*(15.295)*(33.174)*(cnt));
if (cnt <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((((15.352*(segmentsAcked)*(23.088)*(48.942)*(29.199)*(75.027)*(27.892)))+(0.1)+(0.1)+(48.135)+(0.1))/((0.1)+(0.1)+(0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (cnt*(35.456)*(67.797));
	tcb->m_segmentSize = (int) ((13.39*(39.905)*(80.937)*(tJcvTKJaGYCXBUHT))/40.817);

}
if (VKZjcLntzrHPZCxQ == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (81.32+(41.136)+(tcb->m_cWnd)+(41.762)+(VKZjcLntzrHPZCxQ));

} else {
	tcb->m_ssThresh = (int) (89.742*(54.137)*(94.571)*(tcb->m_cWnd)*(82.581)*(77.509)*(39.057)*(69.036)*(24.283));
	cnt = (int) (cnt-(cnt));

}
ReduceCwnd (tcb);
