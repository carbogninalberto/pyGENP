ReduceCwnd (tcb);
if (cnt <= tcb->m_cWnd) {
	segmentsAcked = (int) (((48.315)+((30.263+(20.911)))+((31.246-(14.822)-(81.616)-(tcb->m_segmentSize)-(36.563)))+(90.781)+(2.38)+(21.113)+(19.256))/((0.1)+(11.835)));

} else {
	segmentsAcked = (int) (tcb->m_cWnd+(tcb->m_segmentSize)+(segmentsAcked)+(66.083)+(14.919)+(-0.024)+(14.07)+(77.174));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (29.217+(52.184)+(22.571)+(tcb->m_segmentSize)+(36.787)+(81.83)+(56.745)+(13.191)+(14.189));

}
if (cnt != tcb->m_cWnd) {
	cnt = (int) (10.685/81.291);

} else {
	cnt = (int) (69.484/0.1);
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
float rmdNqHRlkafivjFd = (float) (0.1/34.918);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float dXAfYIZDVuKVATRS = (float) (55.573-(77.246)-(18.364));
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (99.91/0.1);
	dXAfYIZDVuKVATRS = (float) (dXAfYIZDVuKVATRS+(10.345)+(89.561)+(60.211)+(70.487)+(8.138)+(25.72)+(56.182));

} else {
	tcb->m_ssThresh = (int) (45.128-(segmentsAcked));
	ReduceCwnd (tcb);

}
