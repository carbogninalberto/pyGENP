tcb->m_ssThresh = (int) (36.493-(26.108)-(39.043));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt != segmentsAcked) {
	segmentsAcked = (int) (60.253+(segmentsAcked)+(11.61)+(tcb->m_segmentSize)+(87.313));
	tcb->m_ssThresh = (int) (60.591-(60.609));

} else {
	segmentsAcked = (int) (25.545*(45.987)*(80.473)*(41.295)*(3.494)*(10.834));
	tcb->m_ssThresh = (int) (17.431-(70.293)-(5.933)-(65.244)-(99.695)-(79.438));
	cnt = (int) (97.089/0.1);

}
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_segmentSize = (int) (57.191+(tcb->m_cWnd)+(79.956));
	cnt = (int) (80.704*(8.529)*(83.456)*(32.163)*(0.172)*(tcb->m_ssThresh)*(17.529)*(24.782));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	segmentsAcked = (int) (98.158-(53.621)-(52.058)-(3.42)-(50.029)-(81.675)-(93.44)-(44.383));

}
if (tcb->m_ssThresh == cnt) {
	segmentsAcked = (int) (tcb->m_cWnd-(24.348)-(38.755)-(5.3)-(segmentsAcked));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (69.823*(46.505)*(44.186)*(20.101)*(8.111)*(25.032)*(15.214)*(58.577)*(segmentsAcked));
	tcb->m_ssThresh = (int) (18.945*(47.536)*(2.713)*(22.314)*(segmentsAcked));

}
