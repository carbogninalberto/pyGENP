tcb->m_cWnd = (int) (84.193-(tcb->m_segmentSize)-(44.798));
int jWoiIKhndlmLWAAJ = (int) (44.766*(38.029)*(16.333)*(20.79)*(45.429)*(38.205));
tcb->m_segmentSize = (int) (cnt*(11.12)*(84.038)*(57.147)*(tcb->m_ssThresh)*(76.043)*(tcb->m_cWnd)*(27.915)*(52.958));
jWoiIKhndlmLWAAJ = (int) (89.798+(58.959)+(tcb->m_cWnd));
jWoiIKhndlmLWAAJ = (int) (37.92+(28.92)+(14.512)+(90.796)+(78.734)+(cnt));
