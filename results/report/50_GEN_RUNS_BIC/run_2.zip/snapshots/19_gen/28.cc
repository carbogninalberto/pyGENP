cnt = (int) (tcb->m_segmentSize*(cnt)*(63.171));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((22.614-(50.728)-(19.526))/22.905);
	ReduceCwnd (tcb);
	cnt = (int) (40.207-(46.652)-(tcb->m_segmentSize)-(41.898)-(58.174)-(62.504)-(segmentsAcked)-(79.61));

} else {
	tcb->m_segmentSize = (int) (29.727-(6.445)-(86.702));
	tcb->m_ssThresh = (int) (((39.811)+(0.1)+(0.1)+(79.453)+(13.405))/((40.706)+(50.08)+(44.475)));
	tcb->m_ssThresh = (int) (26.739+(17.551)+(1.435)+(tcb->m_cWnd));

}
cnt = (int) (70.171/31.76);
ReduceCwnd (tcb);
if (cnt <= tcb->m_segmentSize) {
	segmentsAcked = (int) (28.009-(60.366)-(37.584)-(tcb->m_cWnd)-(68.859));

} else {
	segmentsAcked = (int) (59.454*(69.705)*(segmentsAcked)*(95.186)*(86.967));

}
ReduceCwnd (tcb);
