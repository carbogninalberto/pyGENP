cnt = (int) (tcb->m_segmentSize-(47.245)-(93.165)-(13.753));
segmentsAcked = (int) (tcb->m_segmentSize+(tcb->m_cWnd));
if (cnt != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((70.484)+(0.1)+(0.1)+(0.1)+(43.599))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (cnt*(24.428)*(76.744)*(60.794)*(tcb->m_segmentSize)*(cnt)*(segmentsAcked)*(45.017)*(0.293));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) ((((41.332*(81.229)*(84.317)*(29.609)*(43.142)*(5.957)*(24.017)*(87.037)*(21.978)))+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)+(91.886)));

}
ReduceCwnd (tcb);
cnt = (int) (cnt+(49.958)+(tcb->m_segmentSize)+(9.276)+(4.495)+(20.944)+(12.208)+(49.43));
tcb->m_cWnd = (int) (16.011+(cnt)+(97.673)+(55.743));
if (tcb->m_ssThresh < cnt) {
	tcb->m_ssThresh = (int) (82.153+(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (4.842-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(73.521)-(10.784)-(tcb->m_segmentSize));

}
cnt = (int) (48.585-(36.336)-(26.571)-(72.24)-(38.865)-(67.22)-(99.269)-(83.545));
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(49.76)*(79.678)*(67.863)*(38.457)*(tcb->m_ssThresh)*(54.239)*(8.936)*(41.72));
	segmentsAcked = (int) (((32.037)+(85.719)+(63.625)+(11.124))/((0.1)+(77.61)+(0.1)+(0.1)+(43.246)));

} else {
	tcb->m_cWnd = (int) (72.743-(tcb->m_segmentSize)-(60.574));

}
