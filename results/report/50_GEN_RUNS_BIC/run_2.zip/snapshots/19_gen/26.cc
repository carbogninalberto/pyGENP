ReduceCwnd (tcb);
tcb->m_segmentSize = (int) ((23.008+(segmentsAcked)+(25.667)+(tcb->m_cWnd)+(48.765)+(92.997)+(8.714))/0.1);
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_cWnd) {
	cnt = (int) (77.973-(36.808));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (48.076+(57.318));
	cnt = (int) (64.491*(4.705)*(tcb->m_cWnd));

}
if (cnt > tcb->m_ssThresh) {
	cnt = (int) (63.269-(68.86)-(6.205));
	tcb->m_cWnd = (int) (48.718-(61.693)-(13.752)-(92.622)-(20.585));

} else {
	cnt = (int) (58.086+(42.954)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(2.625)+(73.774)+(5.07)+(16.288)+(tcb->m_segmentSize));
	cnt = (int) (tcb->m_segmentSize+(99.792));
	tcb->m_ssThresh = (int) (70.57-(12.315)-(1.716)-(segmentsAcked)-(60.948)-(91.968)-(7.551)-(80.887)-(72.577));

}
cnt = (int) (11.179*(tcb->m_cWnd)*(40.671)*(45.305)*(52.607)*(8.484)*(segmentsAcked));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
