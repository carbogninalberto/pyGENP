if (tcb->m_ssThresh < tcb->m_ssThresh) {
	cnt = (int) (0.1/78.877);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (((43.428)+((71.08-(55.802)-(cnt)-(85.638)-(67.736)-(61.183)-(88.303)-(39.887)-(69.216)))+(0.1)+(45.185)+(0.1))/((0.1)+(0.1)+(92.83)));

} else {
	cnt = (int) ((18.385+(12.033)+(9.436)+(64.808)+(67.403)+(5.078)+(68.775)+(64.279))/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (0.1/16.915);

}
if (cnt < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (8.566+(75.572)+(65.301)+(91.394)+(57.326)+(0.177));

} else {
	tcb->m_cWnd = (int) (4.631+(17.546)+(73.017)+(6.843)+(32.051)+(segmentsAcked));
	segmentsAcked = (int) (86.386*(70.439)*(55.189)*(80.107));

}
if (tcb->m_segmentSize < cnt) {
	tcb->m_ssThresh = (int) (0.1/80.236);

} else {
	tcb->m_ssThresh = (int) (1.776+(50.501)+(28.49)+(71.124)+(61.176));
	tcb->m_cWnd = (int) (28.055*(15.66)*(60.046)*(52.868)*(36.789)*(70.662));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	cnt = (int) (segmentsAcked*(88.871)*(39.224)*(29.385)*(17.951));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (92.836-(67.613)-(33.318)-(27.58)-(82.017)-(48.145)-(tcb->m_segmentSize)-(10.747));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (0.1/29.831);

}
tcb->m_segmentSize = (int) (27.058*(cnt)*(54.695)*(63.016)*(23.212)*(20.109));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
