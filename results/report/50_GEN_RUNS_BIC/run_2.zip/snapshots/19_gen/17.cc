int CSjJPiXueNQXbBIO = (int) (tcb->m_cWnd-(31.731)-(81.719)-(11.094));
if (cnt < cnt) {
	tcb->m_cWnd = (int) (segmentsAcked*(20.593)*(16.593)*(60.472)*(25.622));

} else {
	tcb->m_cWnd = (int) (9.615-(34.586)-(64.398)-(96.66)-(89.591)-(30.133)-(59.696));

}
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((0.1)+(15.95)+((36.297+(58.777)+(94.992)+(65.603)+(83.754)+(11.441)+(13.783)+(84.648)))+(15.005)+(88.761))/((45.992)+(0.1)+(82.594)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (0.1/17.507);
	tcb->m_segmentSize = (int) (CSjJPiXueNQXbBIO-(segmentsAcked)-(24.757)-(25.626)-(94.58)-(6.02)-(4.067));
	CSjJPiXueNQXbBIO = (int) (((0.1)+(0.1)+((2.327*(17.265)*(33.445)*(30.631)))+((83.984*(78.518)*(0.277)*(97.751)*(59.252)*(37.401)*(87.252)*(13.218)))+(0.1)+(38.443)+(36.485))/((0.1)+(0.1)));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	CSjJPiXueNQXbBIO = (int) (11.3-(57.288)-(cnt)-(tcb->m_segmentSize)-(97.678)-(84.48));
	tcb->m_ssThresh = (int) (71.703*(43.104)*(65.07)*(7.19));

} else {
	CSjJPiXueNQXbBIO = (int) (58.705*(66.197));

}
CSjJPiXueNQXbBIO = (int) (6.808-(80.506)-(tcb->m_ssThresh)-(21.204)-(20.347));
