segmentsAcked = (int) (21.451+(5.094)+(8.496));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (cnt < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (81.9-(81.933)-(85.639)-(segmentsAcked)-(68.31)-(93.632));
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (21.361-(8.529)-(73.781)-(30.941)-(85.058)-(18.863)-(tcb->m_segmentSize)-(99.179));

}
if (cnt < segmentsAcked) {
	tcb->m_segmentSize = (int) (79.434/40.678);

} else {
	tcb->m_segmentSize = (int) (69.11*(44.455));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (74.597+(69.673)+(63.745)+(54.728)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(33.314)+(42.435)+(6.788));
