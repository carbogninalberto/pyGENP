if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int SzoYWeoEZVWbIHoX = (int) (46.592*(43.894)*(99.392)*(75.79));
tcb->m_segmentSize = (int) (-78.359+(80.325)+(-24.389)+(-43.475)+(97.624)+(75.912)+(11.616)+(-71.436)+(-99.757));
