float sZqgbUynBaDbDZTW = (float) (4.818+(37.982));
if (cnt <= sZqgbUynBaDbDZTW) {
	tcb->m_cWnd = (int) ((20.559*(34.516)*(39.179)*(cnt)*(86.303))/94.98);

} else {
	tcb->m_cWnd = (int) (93.739+(tcb->m_ssThresh)+(tcb->m_cWnd)+(52.277)+(45.342)+(65.731));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= segmentsAcked) {
	sZqgbUynBaDbDZTW = (float) (77.943*(tcb->m_ssThresh)*(74.09));
	ReduceCwnd (tcb);

} else {
	sZqgbUynBaDbDZTW = (float) (31.961+(segmentsAcked)+(tcb->m_ssThresh)+(47.626)+(47.787));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (sZqgbUynBaDbDZTW >= sZqgbUynBaDbDZTW) {
	tcb->m_segmentSize = (int) (44.805+(47.425)+(cnt)+(76.534)+(94.81)+(5.694));

} else {
	tcb->m_segmentSize = (int) (14.859-(tcb->m_ssThresh)-(18.46)-(6.725)-(cnt)-(83.814)-(26.526)-(40.668));

}
tcb->m_ssThresh = (int) (92.244+(26.029)+(95.33)+(23.207)+(33.892)+(77.519)+(6.029));
