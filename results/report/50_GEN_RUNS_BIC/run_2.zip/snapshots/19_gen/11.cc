ReduceCwnd (tcb);
ReduceCwnd (tcb);
float iKDkoRpdnlUzBLVT = (float) (25.046-(75.474)-(94.06)-(31.81));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (3.452-(15.837)-(39.633)-(37.196)-(tcb->m_ssThresh));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (34.655+(43.945));
