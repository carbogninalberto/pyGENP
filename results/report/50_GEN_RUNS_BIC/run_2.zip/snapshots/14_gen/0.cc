if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-57.503+(19.775)+(8.702));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(45.25)*(-97.361)*(-9.404)*(-3.67)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-63.006)*(26.523))/51.397);
tcb->m_cWnd = (int) ((segmentsAcked*(73.642)*(23.068)*(46.49)*(-1.892)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(49.865)*(-56.923))/-7.927);
tcb->m_cWnd = (int) ((segmentsAcked*(-16.547)*(-34.726)*(32.213)*(-95.457)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(5.036)*(48.965))/-87.53);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (65.765+(-14.868)+(-80.635));
tcb->m_cWnd = (int) ((segmentsAcked*(17.022)*(-50.762)*(-47.031)*(89.401)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-28.121)*(28.118))/-36.84);
tcb->m_cWnd = (int) ((segmentsAcked*(-40.246)*(-71.056)*(-55.8)*(45.723)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(88.62)*(-4.034))/-26.185);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(57.783)*(-13.283)*(51.373)*(49.712)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(97.23)*(69.016))/-69.623);
tcb->m_cWnd = (int) ((segmentsAcked*(34.199)*(-13.53)*(26.442)*(-38.251)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(31.877)*(-64.196))/-15.654);
tcb->m_cWnd = (int) ((segmentsAcked*(71.533)*(-89.531)*(23.908)*(-91.385)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-40.002)*(-8.548))/-85.569);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (73.938+(-68.409)+(15.852));
tcb->m_cWnd = (int) ((segmentsAcked*(-51.681)*(39.056)*(83.372)*(76.552)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-81.489)*(37.36))/-76.309);
tcb->m_cWnd = (int) ((segmentsAcked*(-66.476)*(-40.224)*(-13.453)*(67.12)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(15.907)*(-22.495))/-26.974);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(60.307)*(64.997)*(-69.541)*(11.959)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-34.459)*(71.797))/-37.838);
tcb->m_cWnd = (int) ((segmentsAcked*(-86.679)*(-92.48)*(67.925)*(-33.468)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-61.021)*(-90.399))/-46.972);
tcb->m_cWnd = (int) ((segmentsAcked*(-58.321)*(59.587)*(48.041)*(67.593)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-22.356)*(-26.272))/-17.905);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(6.365)*(1.256)*(-27.273)*(-95.592)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(50.719)*(-86.958))/96.243);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-69.141+(66.997)+(-74.797));
tcb->m_cWnd = (int) ((segmentsAcked*(-13.685)*(-7.046)*(81.706)*(12.076)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(84.819)*(-88.912))/82.075);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-43.157)*(-38.133)*(1.883)*(31.179)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(37.138)*(49.879))/54.016);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(77.244)*(-63.047)*(44.314)*(40.393)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(60.486)*(72.978))/95.642);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
