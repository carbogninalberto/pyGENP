cnt = (int) (48.277+(2.242)+(40.627)+(9.505)+(28.74)+(40.021)+(64.572)+(93.186)+(82.259));
tcb->m_cWnd = (int) (40.078*(37.799)*(72.124)*(27.292)*(79.473)*(89.401)*(66.352)*(98.081)*(69.15));
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (50.986*(27.487)*(cnt)*(37.426)*(segmentsAcked)*(72.501)*(22.439)*(35.328));
	segmentsAcked = (int) (65.491*(34.811)*(tcb->m_segmentSize)*(66.329)*(35.478)*(segmentsAcked)*(86.324)*(8.738)*(58.883));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (84.944-(94.401)-(81.925)-(35.586)-(56.265)-(55.644));

}
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_cWnd = (int) (90.571-(3.37)-(tcb->m_ssThresh)-(21.842)-(tcb->m_cWnd)-(95.339)-(57.873)-(96.457));

} else {
	tcb->m_cWnd = (int) (60.553+(36.554)+(segmentsAcked)+(77.381)+(30.892));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
cnt = (int) (96.578-(8.46)-(4.814)-(61.378)-(11.866)-(51.259));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
float tmqlCSLlymxwUjsN = (float) (62.482-(3.932)-(cnt)-(45.682)-(0.151)-(8.947)-(2.628));
