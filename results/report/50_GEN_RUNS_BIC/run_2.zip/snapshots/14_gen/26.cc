if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh == cnt) {
	segmentsAcked = (int) (segmentsAcked*(81.508)*(segmentsAcked)*(80.724)*(78.946));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (25.175/12.28);
	tcb->m_segmentSize = (int) (9.383+(94.934));

}
float lMqPiZvtKCPudgyk = (float) (((8.3)+((58.712-(94.682)))+(0.1)+(98.552)+(0.1))/((0.1)));
ReduceCwnd (tcb);
if (lMqPiZvtKCPudgyk >= segmentsAcked) {
	cnt = (int) (43.436*(48.849)*(66.706));

} else {
	cnt = (int) (33.567+(62.459)+(26.786)+(15.707)+(3.047));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (lMqPiZvtKCPudgyk <= tcb->m_cWnd) {
	cnt = (int) (39.967-(62.756)-(31.802)-(69.815)-(64.035)-(62.523)-(cnt)-(53.331));

} else {
	cnt = (int) (14.168*(39.685));
	tcb->m_segmentSize = (int) (41.613*(lMqPiZvtKCPudgyk));

}
tcb->m_ssThresh = (int) (98.485*(44.174)*(83.425)*(12.827)*(73.321)*(segmentsAcked)*(27.139));
ReduceCwnd (tcb);
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	cnt = (int) (24.728-(50.71)-(89.217)-(18.902)-(tcb->m_segmentSize)-(67.761)-(49.342));
	tcb->m_ssThresh = (int) (11.417+(69.303)+(46.119)+(1.738)+(tcb->m_cWnd)+(4.169));
	lMqPiZvtKCPudgyk = (float) (42.05+(93.462));

} else {
	cnt = (int) (91.389+(59.061)+(74.638)+(25.767));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
