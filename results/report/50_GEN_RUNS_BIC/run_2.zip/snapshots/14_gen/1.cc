float uyPYrXmzUJPLFdxQ = (float) (-58.777/-14.713);
