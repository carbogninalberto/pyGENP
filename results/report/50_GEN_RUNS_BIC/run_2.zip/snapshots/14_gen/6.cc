if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int MTWwvWQFwErSBauC = (int) 74.369;
MTWwvWQFwErSBauC = (int) (44.905+(18.251)+(13.463)+(81.581)+(-64.425)+(-53.841));
