ReduceCwnd (tcb);
tcb->m_segmentSize = (int) ((((cnt-(31.623)-(15.074)-(-5.556)-(78.263)-(47.653)-(14.142)-(-41.563)-(-63.458)))+(-34.989)+(95.626)+(93.928)+(-51.572)+(-10.21))/((89.147)));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (21.519-(9.508)-(85.676)-(92.526)-(54.123)-(85.536)-(tcb->m_cWnd));
	segmentsAcked = (int) (18.688-(50.909)-(1.886)-(28.943)-(segmentsAcked)-(40.601)-(56.261));
	tcb->m_cWnd = (int) (4.099-(32.777)-(tcb->m_cWnd)-(70.204)-(97.466)-(89.304)-(3.354)-(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (37.764*(48.178)*(3.3)*(tcb->m_segmentSize)*(56.237)*(78.284));

}
