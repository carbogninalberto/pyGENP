if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (46.124-(50.837)-(59.446)-(93.412)-(41.396)-(89.553)-(63.198)-(32.045)-(56.205));

} else {
	tcb->m_segmentSize = (int) (24.207-(63.531)-(98.355)-(cnt)-(segmentsAcked)-(7.165)-(86.977));

}
if (cnt >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (44.195+(segmentsAcked)+(15.544)+(58.072));
	tcb->m_segmentSize = (int) (segmentsAcked+(86.657)+(72.937)+(tcb->m_ssThresh)+(64.967)+(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (17.389-(86.242)-(97.279)-(2.698));
	tcb->m_segmentSize = (int) (80.555*(51.994)*(67.89)*(9.677)*(69.086)*(cnt)*(66.792));

}
tcb->m_cWnd = (int) (0.1/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int PJsfRpOJuVqKhVXA = (int) (65.424-(0.404)-(cnt)-(66.679)-(36.705));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize > PJsfRpOJuVqKhVXA) {
	segmentsAcked = (int) (90.669+(62.016));
	tcb->m_ssThresh = (int) (96.794-(73.308)-(21.675)-(33.823)-(tcb->m_ssThresh)-(70.202));

} else {
	segmentsAcked = (int) (10.411+(93.697)+(55.807)+(14.697)+(37.351));
	tcb->m_ssThresh = (int) (56.89+(87.698)+(66.403)+(PJsfRpOJuVqKhVXA));
	tcb->m_cWnd = (int) (27.447*(44.64)*(96.834)*(35.48)*(1.623)*(25.782)*(cnt)*(35.064));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
