ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((21.657)+(79.121)+((22.848*(98.658)*(52.115)*(segmentsAcked)*(11.943)*(37.909)*(38.848)))+(0.1)+(0.1)+(0.1)+(71.623))/((0.1)+(19.925)));
	segmentsAcked = (int) (91.132*(43.538)*(22.366));

} else {
	tcb->m_segmentSize = (int) (28.223-(10.646));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt <= segmentsAcked) {
	tcb->m_cWnd = (int) (cnt+(45.781));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) ((60.38+(cnt)+(99.669))/95.647);
	segmentsAcked = (int) ((((87.66*(95.63)*(62.422)*(42.983)*(segmentsAcked)))+((54.499*(cnt)*(cnt)*(70.801)*(4.031)))+(0.1)+(0.1))/((0.1)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
