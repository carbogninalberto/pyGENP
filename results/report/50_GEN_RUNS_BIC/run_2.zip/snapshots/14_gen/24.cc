tcb->m_cWnd = (int) (79.317+(81.471)+(6.82));
if (tcb->m_cWnd > tcb->m_cWnd) {
	cnt = (int) (88.565*(43.771)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(13.779));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (56.939*(65.794));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (92.983-(45.596)-(54.622)-(3.443)-(22.262)-(93.825)-(segmentsAcked));

}
tcb->m_ssThresh = (int) (0.1/0.1);
if (cnt < tcb->m_cWnd) {
	cnt = (int) (63.337/0.1);
	tcb->m_segmentSize = (int) (((31.271)+((11.087-(78.506)-(78.674)-(65.994)-(cnt)-(42.62)-(70.475)))+(80.189)+(81.916))/((0.1)+(24.164)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (55.736*(30.238)*(tcb->m_cWnd)*(27.129));

}
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (14.185-(80.817)-(12.898));
	tcb->m_ssThresh = (int) ((((22.302+(22.332)+(29.522)+(55.888)+(48.875)+(42.13)+(tcb->m_ssThresh)+(40.431)))+(47.558)+(55.836)+(0.1)+(0.1)+(0.1))/((98.832)+(0.1)+(1.171)));
	tcb->m_ssThresh = (int) (33.708/0.1);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
