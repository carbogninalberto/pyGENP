if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int MTWwvWQFwErSBauC = (int) 45.308;
MTWwvWQFwErSBauC = (int) (58.62+(41.695)+(-93.07)+(60.72)+(-56.095)+(-35.091));
MTWwvWQFwErSBauC = (int) (46.987+(81.341)+(-40.071)+(-13.781)+(16.879)+(-94.017));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
