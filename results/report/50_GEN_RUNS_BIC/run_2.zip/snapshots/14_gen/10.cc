float uyPYrXmzUJPLFdxQ = (float) 66.118;
