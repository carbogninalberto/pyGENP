ReduceCwnd (tcb);
if (segmentsAcked <= segmentsAcked) {
	segmentsAcked = (int) (28.289+(58.07));
	tcb->m_cWnd = (int) (segmentsAcked+(66.109)+(32.269)+(88.927)+(24.184));
	tcb->m_segmentSize = (int) ((67.481-(cnt)-(9.127)-(72.607)-(73.456)-(44.837)-(16.909)-(tcb->m_ssThresh))/0.1);

} else {
	segmentsAcked = (int) (34.698+(6.053)+(64.068)+(74.54)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(82.739)+(81.316)+(80.578));

}
tcb->m_cWnd = (int) ((segmentsAcked-(31.294)-(-82.135)-(33.529)-(10.738)-(98.732)-(36.773)-(21.998))/4.528);
tcb->m_cWnd = (int) (59.791*(-45.846)*(92.908)*(17.894)*(47.098)*(44.266)*(-12.905));
