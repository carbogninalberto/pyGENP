tcb->m_cWnd = (int) (5.279/76.902);
cnt = (int) (30.817+(86.739)+(95.09)+(cnt)+(22.688)+(40.61));
tcb->m_ssThresh = (int) (tcb->m_cWnd+(77.504));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (19.431*(1.752)*(35.517));
float HNcqaHWxUhhyAGcP = (float) (81.175-(42.102)-(79.307)-(tcb->m_ssThresh)-(40.562));
float ABFnUleAbvHQjCSa = (float) ((8.602-(73.407)-(86.912)-(96.11)-(26.68)-(33.507)-(HNcqaHWxUhhyAGcP)-(84.308))/24.77);
