int JuhLwtqMznSkjCQy = (int) (30.397/9.996);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int MTWwvWQFwErSBauC = (int) 74.781;
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
