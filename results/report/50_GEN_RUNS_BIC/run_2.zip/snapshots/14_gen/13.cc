if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (0.1/95.46);
cnt = (int) (79.294+(39.596)+(93.865)+(39.663)+(12.585)+(69.25)+(28.296)+(21.486));
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_segmentSize = (int) (32.02+(80.238)+(cnt)+(48.749));

} else {
	tcb->m_segmentSize = (int) (93.481-(segmentsAcked)-(29.759)-(76.213)-(18.431)-(61.149)-(74.717)-(24.796));

}
