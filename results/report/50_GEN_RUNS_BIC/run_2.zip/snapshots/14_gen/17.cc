segmentsAcked = (int) (cnt*(39.092)*(87.744)*(60.934)*(51.737)*(96.339)*(28.997)*(11.033));
segmentsAcked = (int) (46.326-(46.31)-(24.217));
tcb->m_segmentSize = (int) (70.731-(95.982)-(60.334)-(9.769)-(tcb->m_ssThresh)-(27.834)-(54.042));
tcb->m_cWnd = (int) (4.978+(72.444)+(1.872)+(57.085));
if (tcb->m_segmentSize == cnt) {
	cnt = (int) (40.53-(92.738)-(24.146)-(3.039)-(90.704)-(39.396)-(49.524)-(tcb->m_segmentSize)-(tcb->m_segmentSize));
	segmentsAcked = (int) (56.472-(9.955)-(82.923));

} else {
	cnt = (int) (segmentsAcked+(65.471)+(40.903)+(13.235)+(87.729)+(37.742)+(7.236));

}
