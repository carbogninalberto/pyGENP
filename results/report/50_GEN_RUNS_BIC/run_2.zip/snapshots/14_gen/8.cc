float zIZJNkxaPPqNVJwi = (float) (71.205*(-59.587));
float gIKXMeStMztDUfWl = (float) (19.39+(57.512)+(-78.76)+(14.021));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (gIKXMeStMztDUfWl > zIZJNkxaPPqNVJwi) {
	segmentsAcked = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (65.944/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (tcb->m_cWnd-(46.664)-(-65.886)-(30.018));

}
tcb->m_segmentSize = (int) (-70.811*(-93.381)*(-53.324)*(91.723)*(63.651)*(22.67)*(10.682)*(-33.585));
