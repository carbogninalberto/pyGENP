ReduceCwnd (tcb);
float XJsPiLPIMAXCVWvB = (float) (((79.254)+(97.366)+(50.148)+(0.1)+(27.523)+(0.1)+(51.918)+(0.1))/((71.954)));
float CKyHDZFtPBdYbtCf = (float) (26.345/(76.39+(cnt)+(75.494)+(84.546)+(tcb->m_ssThresh)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
