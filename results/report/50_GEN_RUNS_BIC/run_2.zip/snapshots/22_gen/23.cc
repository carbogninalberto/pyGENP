if (tcb->m_cWnd == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (39.274-(90.677)-(81.619)-(36.914)-(cnt)-(66.827)-(92.858));
	tcb->m_ssThresh = (int) (31.462*(cnt)*(49.678)*(cnt));

} else {
	tcb->m_ssThresh = (int) (28.959-(tcb->m_ssThresh)-(61.14)-(22.447)-(tcb->m_segmentSize));

}
cnt = (int) (tcb->m_cWnd-(segmentsAcked)-(17.356)-(97.783)-(37.305)-(67.751));
if (cnt == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(96.965)*(cnt)*(tcb->m_segmentSize)*(91.697));
	tcb->m_cWnd = (int) (64.202+(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (67.537-(87.731)-(47.208));
	segmentsAcked = (int) (0.1/0.1);
	segmentsAcked = (int) (segmentsAcked-(tcb->m_segmentSize)-(48.809)-(84.776)-(97.023)-(53.235));

}
if (tcb->m_segmentSize == segmentsAcked) {
	tcb->m_cWnd = (int) (96.614-(46.581));

} else {
	tcb->m_cWnd = (int) (24.457/11.75);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
