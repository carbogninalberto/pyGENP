if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (59.576*(61.775)*(92.468)*(18.133));
	tcb->m_cWnd = (int) (75.669-(2.312)-(4.305)-(tcb->m_segmentSize)-(68.382)-(17.109)-(51.1)-(46.097));

} else {
	tcb->m_cWnd = (int) (72.596+(11.775)+(60.568));

}
segmentsAcked = (int) (19.981-(5.948)-(91.032)-(71.254)-(74.45)-(71.255)-(30.18)-(91.32)-(71.429));
ReduceCwnd (tcb);
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	cnt = (int) ((((10.937+(tcb->m_segmentSize)))+(0.1)+(5.201)+(99.015)+(0.1)+(0.1))/((0.1)));
	tcb->m_cWnd = (int) (tcb->m_cWnd*(0.492)*(88.681)*(7.909)*(38.122));

} else {
	cnt = (int) (tcb->m_cWnd+(32.139)+(25.399)+(tcb->m_cWnd)+(8.082)+(42.848));

}
if (tcb->m_cWnd != segmentsAcked) {
	cnt = (int) ((86.706*(15.384)*(44.105)*(99.699)*(cnt)*(10.282))/0.1);
	ReduceCwnd (tcb);

} else {
	cnt = (int) (77.787-(25.693)-(tcb->m_cWnd)-(47.949)-(58.356)-(30.574)-(tcb->m_ssThresh)-(94.297));
	cnt = (int) (56.613-(-0.075)-(segmentsAcked)-(80.987)-(54.52)-(59.303)-(19.272)-(22.806));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
