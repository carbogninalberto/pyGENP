if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (segmentsAcked+(91.564)+(92.978)+(80.917));

} else {
	tcb->m_ssThresh = (int) (47.418-(55.416)-(segmentsAcked)-(67.405)-(6.072)-(56.855)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (49.265-(44.398)-(tcb->m_ssThresh)-(27.391)-(12.854)-(segmentsAcked)-(tcb->m_ssThresh));

}
cnt = (int) (68.796-(38.455)-(24.207)-(15.832)-(57.936)-(23.133)-(97.452)-(66.565)-(70.145));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (cnt != segmentsAcked) {
	segmentsAcked = (int) (0.1/0.1);
	segmentsAcked = (int) ((62.189*(75.754)*(77.861)*(69.925)*(tcb->m_cWnd)*(segmentsAcked)*(65.443)*(5.255)*(18.232))/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (((0.1)+(76.788)+(0.1)+(80.496)+((segmentsAcked-(33.863)-(98.966)-(61.349)))+(60.927)+(0.1))/((0.1)));
	cnt = (int) (81.276-(84.397)-(70.83)-(segmentsAcked)-(tcb->m_cWnd)-(68.667)-(63.403)-(96.365)-(20.463));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
