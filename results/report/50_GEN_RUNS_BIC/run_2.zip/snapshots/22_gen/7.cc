tcb->m_segmentSize = (int) (55.289+(0.259)+(11.127)+(1.91));
float lvoNefMgrLCfprzT = (float) (20.245*(83.265)*(82.681)*(40.731));
lvoNefMgrLCfprzT = (float) (13.498*(31.132)*(tcb->m_segmentSize)*(54.439)*(70.479)*(71.867));
tcb->m_segmentSize = (int) (70.623*(73.779)*(61.737)*(tcb->m_ssThresh)*(90.817));
tcb->m_segmentSize = (int) (82.523-(64.429)-(lvoNefMgrLCfprzT)-(33.821)-(21.005));
tcb->m_cWnd = (int) (((61.325)+((tcb->m_segmentSize*(tcb->m_cWnd)*(12.092)*(85.703)*(12.641)*(tcb->m_ssThresh)))+((20.291+(45.463)+(tcb->m_cWnd)+(43.929)+(lvoNefMgrLCfprzT)+(72.159)))+((57.711*(0.589)*(43.439)*(79.037)*(39.471)*(tcb->m_segmentSize)*(83.798)))+(0.1))/((0.1)+(41.659)));
