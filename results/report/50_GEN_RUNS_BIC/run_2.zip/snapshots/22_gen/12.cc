float HXvdOvkMGsTgZPPh = (float) (tcb->m_segmentSize-(45.615)-(0.971)-(89.234)-(29.179));
segmentsAcked = (int) (((11.594)+(0.1)+(61.725)+((72.992*(19.673)*(79.101)*(56.35)*(28.002)*(26.946)*(32.237)*(tcb->m_ssThresh)*(71.612)))+(0.1)+(0.1))/((0.1)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt == cnt) {
	HXvdOvkMGsTgZPPh = (float) (55.033-(90.988)-(88.408)-(80.616)-(70.681)-(21.12)-(39.669));

} else {
	HXvdOvkMGsTgZPPh = (float) (64.68-(81.306)-(cnt)-(72.719)-(8.453)-(34.006)-(41.437));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd == HXvdOvkMGsTgZPPh) {
	tcb->m_ssThresh = (int) (76.918+(91.1)+(tcb->m_segmentSize)+(1.774)+(tcb->m_cWnd)+(59.11)+(25.121)+(32.009)+(43.815));
	HXvdOvkMGsTgZPPh = (float) (96.275/25.387);
	segmentsAcked = (int) (22.331+(cnt)+(26.413)+(79.588)+(48.216));

} else {
	tcb->m_ssThresh = (int) (HXvdOvkMGsTgZPPh+(1.895));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
