ReduceCwnd (tcb);
int MvALuaHNDhDyQlaz = (int) (80.26-(37.086)-(54.977)-(75.518)-(66.772)-(52.684));
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (32.992*(76.868)*(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (((0.1)+(1.843)+(20.298)+(0.1))/((0.1)));

}
int tFQfQdJdXhxqsmUs = (int) (68.441*(55.375)*(17.824)*(36.834)*(tcb->m_segmentSize)*(segmentsAcked)*(1.442));
tFQfQdJdXhxqsmUs = (int) (28.704-(69.124));
ReduceCwnd (tcb);
if (tcb->m_ssThresh < tFQfQdJdXhxqsmUs) {
	tcb->m_cWnd = (int) (0.1/91.362);
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (69.061-(35.55)-(62.806)-(MvALuaHNDhDyQlaz)-(53.419)-(84.421)-(22.386));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tFQfQdJdXhxqsmUs < cnt) {
	tcb->m_segmentSize = (int) (14.348+(3.613)+(89.157)+(94.685)+(46.517)+(93.73)+(22.079)+(85.134)+(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (MvALuaHNDhDyQlaz*(22.436)*(tcb->m_segmentSize)*(84.992)*(67.069)*(66.398)*(33.771)*(64.826));
	MvALuaHNDhDyQlaz = (int) (MvALuaHNDhDyQlaz-(57.984)-(segmentsAcked)-(25.124));

}
