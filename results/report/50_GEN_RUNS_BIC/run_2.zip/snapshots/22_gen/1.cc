int zoAhEbvPbFkYvSou = (int) (58.491-(-38.691)-(-87.197)-(-72.479)-(-36.114)-(9.029)-(70.238)-(48.996));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
