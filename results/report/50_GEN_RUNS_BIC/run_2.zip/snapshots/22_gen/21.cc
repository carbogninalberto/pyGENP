tcb->m_ssThresh = (int) (((50.595)+(7.559)+((75.684+(74.002)+(2.023)+(31.262)+(38.049)+(cnt)+(segmentsAcked)+(segmentsAcked)+(27.19)))+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)+(70.926)));
if (cnt <= tcb->m_ssThresh) {
	cnt = (int) (39.0/(64.568-(80.383)-(87.373)));
	cnt = (int) (94.808-(8.427)-(82.809)-(89.452));

} else {
	cnt = (int) (59.674+(72.664)+(86.848)+(50.294));
	cnt = (int) (3.112+(tcb->m_ssThresh)+(19.898)+(70.564)+(66.687)+(42.962)+(3.277));

}
tcb->m_segmentSize = (int) (61.998-(19.494)-(25.782)-(49.247)-(99.382)-(91.648)-(tcb->m_cWnd));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked == segmentsAcked) {
	tcb->m_ssThresh = (int) (34.779*(41.873)*(50.74)*(19.841)*(25.131)*(55.026)*(78.188)*(15.694)*(73.537));
	tcb->m_ssThresh = (int) (22.814*(78.136)*(95.172)*(1.895)*(tcb->m_ssThresh)*(96.619)*(85.274)*(46.723));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (60.44/0.1);

}
