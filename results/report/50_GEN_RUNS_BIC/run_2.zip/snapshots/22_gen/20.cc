float SXFfvONhsxlypseE = (float) (((5.247)+(0.1)+(16.684)+(0.1))/((0.1)));
tcb->m_ssThresh = (int) (60.632*(16.75)*(61.226));
ReduceCwnd (tcb);
if (SXFfvONhsxlypseE >= cnt) {
	tcb->m_segmentSize = (int) (78.551-(80.057)-(71.713)-(89.65)-(0.855)-(3.653)-(35.307)-(segmentsAcked)-(27.811));
	segmentsAcked = (int) (79.003+(33.736)+(SXFfvONhsxlypseE)+(74.61)+(41.119)+(30.151)+(27.853));

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(10.995)*(64.871)*(cnt)*(89.674)*(19.699)*(56.929));
	cnt = (int) (0.763-(98.483)-(tcb->m_ssThresh)-(93.718)-(77.111)-(81.574)-(97.41)-(27.339)-(5.112));

}
segmentsAcked = (int) (20.813+(74.843)+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(16.596)+(93.104)+(SXFfvONhsxlypseE));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (64.636+(24.992));
tcb->m_segmentSize = (int) ((((2.616*(76.161)*(48.353)*(9.259)*(22.689)))+(93.507)+(15.061)+(0.1)+(0.1)+(60.483))/((0.1)));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (93.291-(tcb->m_segmentSize)-(segmentsAcked)-(70.397)-(29.426));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(SXFfvONhsxlypseE)+(24.713));
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(91.187)+(79.558));

}
