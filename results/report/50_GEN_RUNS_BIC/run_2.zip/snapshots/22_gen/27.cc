if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (57.377+(22.149)+(tcb->m_segmentSize)+(82.262)+(38.838)+(39.241)+(7.064)+(tcb->m_segmentSize)+(19.249));
	tcb->m_ssThresh = (int) ((((94.3*(segmentsAcked)*(77.453)*(89.197)*(32.0)*(58.616)*(tcb->m_cWnd)*(8.218)*(tcb->m_ssThresh)))+(43.653)+(0.1)+(61.119))/((0.1)+(44.268)+(90.931)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) ((((1.833*(16.075)*(17.05)*(tcb->m_segmentSize)*(cnt)*(61.028)*(20.504)*(81.365)))+(0.1)+(0.1)+(6.206)+(46.269))/((56.938)+(0.1)+(0.1)+(93.51)));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (82.214*(68.52)*(segmentsAcked)*(68.009));

} else {
	tcb->m_cWnd = (int) (64.18-(33.048)-(57.045)-(0.017));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float smJOGymjzIKzRhsB = (float) (((80.306)+(0.1)+(44.456)+(0.1))/((20.423)+(66.126)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	smJOGymjzIKzRhsB = (float) (3.98*(46.861)*(54.841));
	tcb->m_ssThresh = (int) (33.707/17.812);

} else {
	smJOGymjzIKzRhsB = (float) (0.1/8.103);
	tcb->m_segmentSize = (int) (((0.1)+((23.812+(segmentsAcked)+(28.31)))+(41.891)+(55.815)+(0.1))/((100.0)+(71.597)+(56.469)+(37.104)));

}
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (20.191*(tcb->m_cWnd)*(93.493)*(26.239)*(89.018)*(70.746)*(7.986)*(75.608)*(cnt));
	segmentsAcked = (int) (16.337-(71.564)-(tcb->m_ssThresh)-(15.223)-(38.025)-(12.268)-(2.847)-(9.905));

} else {
	tcb->m_segmentSize = (int) (2.919-(32.441));
	ReduceCwnd (tcb);
	smJOGymjzIKzRhsB = (float) (((0.1)+((45.329*(27.025)*(segmentsAcked)*(39.855)*(smJOGymjzIKzRhsB)*(48.535)*(cnt)))+(31.815)+(0.1))/((0.1)+(60.487)));

}
tcb->m_cWnd = (int) (tcb->m_ssThresh*(tcb->m_cWnd)*(96.867)*(86.653)*(33.287));
