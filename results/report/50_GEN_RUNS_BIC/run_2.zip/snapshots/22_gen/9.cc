if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (tcb->m_segmentSize+(78.529)+(42.179)+(82.917)+(40.715)+(4.377));
if (tcb->m_cWnd < cnt) {
	tcb->m_segmentSize = (int) (45.164+(33.328)+(50.225)+(32.431)+(43.633)+(0.887)+(61.434));

} else {
	tcb->m_segmentSize = (int) (41.519*(87.048)*(10.754));
	tcb->m_cWnd = (int) (90.165-(tcb->m_cWnd)-(65.299)-(82.966)-(93.773));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
