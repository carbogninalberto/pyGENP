segmentsAcked = (int) (64.278+(-76.011));
tcb->m_segmentSize = (int) (73.628-(6.393)-(62.154)-(73.202)-(83.056)-(-24.697)-(22.587));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
