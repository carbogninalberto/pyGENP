float GRihSHfLAHIXVMoX = (float) (69.93+(13.723)+(12.999)+(98.605));
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (83.259*(89.403)*(22.061));

} else {
	segmentsAcked = (int) (28.907-(50.833)-(46.703)-(34.897)-(29.861)-(66.019)-(91.027));
	GRihSHfLAHIXVMoX = (float) (((46.693)+(0.1)+(61.386)+(21.067)+(21.612)+((36.771-(10.747)))+(0.1))/((17.767)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd >= cnt) {
	tcb->m_ssThresh = (int) (2.522-(12.805)-(19.826)-(3.291)-(26.377));
	tcb->m_segmentSize = (int) (55.074*(segmentsAcked)*(77.072)*(78.529)*(30.564)*(11.381)*(tcb->m_ssThresh)*(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) ((((75.151-(79.941)-(23.609)-(cnt)-(GRihSHfLAHIXVMoX)))+(64.855)+((0.393*(29.131)*(70.808)*(12.322)*(35.303)*(28.384)*(67.148)))+(92.81)+(0.1)+(66.061))/((44.971)));
	segmentsAcked = (int) (25.686-(30.504)-(tcb->m_cWnd)-(5.28)-(84.302)-(12.113)-(segmentsAcked)-(72.478)-(7.338));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (74.091*(56.761)*(66.114)*(87.644)*(96.95));
if (GRihSHfLAHIXVMoX <= tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/35.347);
	tcb->m_ssThresh = (int) (21.562+(35.07)+(28.921)+(tcb->m_ssThresh)+(12.351)+(cnt));

} else {
	segmentsAcked = (int) (44.841-(75.415)-(5.964)-(segmentsAcked)-(tcb->m_ssThresh)-(segmentsAcked)-(15.477)-(tcb->m_ssThresh)-(57.786));

}
tcb->m_ssThresh = (int) (57.146/0.1);
float fxqxtgHZYbeyfHJr = (float) (89.644-(84.398)-(51.068));
if (tcb->m_ssThresh == fxqxtgHZYbeyfHJr) {
	segmentsAcked = (int) (((49.482)+(92.776)+(0.1)+(11.1))/((0.1)+(58.798)+(62.944)+(0.1)));

} else {
	segmentsAcked = (int) (71.12/0.1);

}
