ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (cnt+(91.586)+(76.33)+(74.473)+(segmentsAcked)+(21.53));
if (cnt == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (13.99-(74.564)-(79.694)-(79.805)-(17.548)-(23.169)-(15.727));

} else {
	tcb->m_cWnd = (int) (83.876-(34.4)-(28.403)-(50.432)-(54.53)-(tcb->m_ssThresh)-(87.98)-(cnt)-(75.123));

}
tcb->m_cWnd = (int) (((0.1)+((93.984*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(14.868)*(58.701)*(7.759)))+(0.1)+(0.1)+(0.1)+(0.1))/((53.092)+(87.987)+(21.219)));
int YhqOwOvUVjYezGhq = (int) ((96.922*(tcb->m_segmentSize)*(12.212)*(97.133)*(6.329)*(tcb->m_cWnd))/14.242);
if (YhqOwOvUVjYezGhq != cnt) {
	segmentsAcked = (int) (15.797*(39.189)*(42.333)*(13.57));
	tcb->m_ssThresh = (int) (14.015+(45.125)+(21.831)+(92.397)+(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (91.913*(3.762));

} else {
	segmentsAcked = (int) (33.538+(37.813)+(56.522)+(45.394));

}
YhqOwOvUVjYezGhq = (int) (43.671-(21.55)-(38.396));
if (YhqOwOvUVjYezGhq < segmentsAcked) {
	tcb->m_cWnd = (int) (47.646+(9.097)+(91.06)+(87.143)+(52.718)+(0.432)+(27.779)+(55.191));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd+(5.298)+(48.106)+(tcb->m_ssThresh)+(44.292)+(80.284));

}
