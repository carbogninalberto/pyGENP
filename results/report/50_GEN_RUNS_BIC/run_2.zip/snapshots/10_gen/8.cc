if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (15.096+(24.065)+(12.54));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(68.843)*(65.469)*(27.31)*(2.029)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-35.882)*(-94.909))/-35.949);
tcb->m_cWnd = (int) ((segmentsAcked*(9.854)*(69.537)*(-60.658)*(31.396)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-9.109)*(88.534))/8.151);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
