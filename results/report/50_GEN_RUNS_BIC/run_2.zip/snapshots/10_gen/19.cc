if (tcb->m_segmentSize == cnt) {
	cnt = (int) (tcb->m_segmentSize+(cnt)+(34.585)+(3.983));
	tcb->m_ssThresh = (int) (86.015*(segmentsAcked)*(93.201));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (19.988-(24.823)-(84.303)-(segmentsAcked)-(50.235)-(70.372)-(61.828)-(tcb->m_ssThresh));
	segmentsAcked = (int) (95.705+(41.476));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(43.057)+(59.935)+(1.166)+(tcb->m_ssThresh));

}
tcb->m_ssThresh = (int) (segmentsAcked*(10.955)*(98.957)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(56.808)*(0.318)*(55.825)*(32.943));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (87.162-(6.428));
	ReduceCwnd (tcb);
	cnt = (int) (65.349*(45.087)*(38.682)*(14.045)*(7.154)*(54.342)*(87.464)*(85.07)*(tcb->m_cWnd));

} else {
	tcb->m_segmentSize = (int) (14.932+(12.427)+(17.731)+(cnt)+(cnt)+(42.251));
	tcb->m_cWnd = (int) (9.405+(14.108)+(81.518)+(58.112)+(4.738)+(86.12)+(46.94));
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(20.311));

}
ReduceCwnd (tcb);
