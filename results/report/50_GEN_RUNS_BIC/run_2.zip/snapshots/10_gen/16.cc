ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) ((tcb->m_ssThresh-(18.664)-(66.397)-(tcb->m_cWnd)-(87.457)-(cnt)-(78.849)-(tcb->m_cWnd))/0.1);
	tcb->m_segmentSize = (int) (35.494+(67.088)+(3.103)+(97.693));
	cnt = (int) (64.142/0.1);

} else {
	tcb->m_cWnd = (int) (19.02*(3.222)*(25.776));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int LPcTrXowSsSrTEEH = (int) (50.044*(7.824)*(85.035)*(55.793)*(tcb->m_segmentSize)*(tcb->m_ssThresh));
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(27.147)-(33.576)-(segmentsAcked)-(2.755)-(2.009));
tcb->m_segmentSize = (int) (12.594-(46.382)-(LPcTrXowSsSrTEEH)-(75.697));
if (LPcTrXowSsSrTEEH != tcb->m_cWnd) {
	cnt = (int) (0.1/89.744);

} else {
	cnt = (int) (segmentsAcked*(34.001)*(26.49)*(95.981)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(tcb->m_cWnd)*(85.131));
	tcb->m_segmentSize = (int) (((0.1)+(29.891)+(84.283)+(0.1)+(0.1)+(0.1))/((98.208)));

}
