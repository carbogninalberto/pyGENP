if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (61.051+(71.241)+(-52.005));
tcb->m_cWnd = (int) ((segmentsAcked*(0.668)*(2.102)*(51.266)*(-40.424)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(54.494)*(-22.322))/29.325);
tcb->m_cWnd = (int) ((segmentsAcked*(-31.617)*(58.334)*(-28.288)*(77.779)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(33.418)*(59.008))/-96.54);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) ((segmentsAcked*(85.615)*(-12.686)*(-95.798)*(-65.479)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-28.037)*(55.686))/-31.455);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(27.756)*(-62.88)*(39.906)*(-84.339)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(46.447)*(-99.26))/79.685);
tcb->m_cWnd = (int) ((segmentsAcked*(39.449)*(94.083)*(-9.43)*(-58.969)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-23.867)*(26.89))/-1.129);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-27.441)*(14.665)*(-4.079)*(-35.052)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-78.467)*(-24.87))/72.474);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(9.823)*(-46.032)*(-54.496)*(84.532)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-67.647)*(-33.816))/-81.539);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
