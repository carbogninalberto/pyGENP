int czfhfRqDXnuvQRvy = (int) (79.996*(85.13)*(63.163)*(12.062)*(33.762)*(91.582)*(37.422)*(47.581));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (54.949*(36.031));
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (70.328+(95.169));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (56.661-(28.508)-(66.861)-(4.609));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt <= cnt) {
	tcb->m_ssThresh = (int) (4.039-(37.844));
	cnt = (int) (22.128+(27.13));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(58.987)*(89.313)*(50.052)*(79.13)*(tcb->m_cWnd)*(56.798)*(2.988)*(56.883));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (67.91*(48.365)*(26.008));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (37.365-(86.85)-(cnt)-(91.497)-(37.173)-(47.775)-(tcb->m_cWnd));
	ReduceCwnd (tcb);
	czfhfRqDXnuvQRvy = (int) (7.134*(27.166)*(79.53)*(tcb->m_segmentSize)*(4.901)*(86.756)*(czfhfRqDXnuvQRvy)*(czfhfRqDXnuvQRvy));

}
