if (tcb->m_segmentSize > tcb->m_ssThresh) {
	segmentsAcked = (int) (95.83*(5.02));

} else {
	segmentsAcked = (int) (62.315-(tcb->m_cWnd)-(cnt)-(4.456)-(65.127));

}
int IMNGgtdtQHXmKzPx = (int) (17.965*(62.198)*(98.808)*(64.626)*(tcb->m_ssThresh));
if (IMNGgtdtQHXmKzPx != tcb->m_ssThresh) {
	cnt = (int) (0.1/0.1);

} else {
	cnt = (int) (cnt*(11.982)*(42.748)*(27.829)*(34.004)*(tcb->m_cWnd)*(40.42));
	tcb->m_cWnd = (int) (44.159+(59.943)+(23.94)+(37.427)+(67.543)+(90.57)+(7.3));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt != tcb->m_ssThresh) {
	cnt = (int) (((0.1)+(71.393)+(0.1)+(29.677)+(7.579))/((6.817)));
	cnt = (int) (segmentsAcked*(89.027)*(83.18)*(tcb->m_ssThresh)*(54.937)*(22.433));

} else {
	cnt = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (segmentsAcked*(24.671)*(86.146)*(76.016)*(78.826)*(60.298)*(87.03)*(tcb->m_ssThresh)*(71.734));

}
tcb->m_segmentSize = (int) (26.184+(34.361)+(44.517)+(17.871)+(91.164)+(tcb->m_segmentSize)+(41.686)+(24.112));
if (IMNGgtdtQHXmKzPx < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (33.584/0.1);

} else {
	tcb->m_ssThresh = (int) (22.691+(13.425)+(50.947)+(66.977));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (((25.487)+((66.928-(41.927)-(47.34)-(tcb->m_ssThresh)-(cnt)-(68.698)))+(35.573)+(0.1)+((cnt+(58.588)+(90.916)+(24.784)+(81.408)+(96.691)+(tcb->m_segmentSize)+(73.406)))+(43.014))/((76.878)));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (92.296*(65.492)*(40.468)*(84.94)*(tcb->m_segmentSize)*(IMNGgtdtQHXmKzPx)*(62.895)*(53.433));

} else {
	tcb->m_ssThresh = (int) (50.011*(49.495)*(17.073)*(segmentsAcked)*(cnt)*(57.715)*(26.277)*(67.873));

}
