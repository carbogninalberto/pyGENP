if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (73.292+(-77.858)+(-21.443));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(41.295)*(69.219)*(5.304)*(63.882)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(60.608)*(-34.949))/-82.451);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-50.45+(68.23)+(-22.403));
tcb->m_cWnd = (int) ((segmentsAcked*(-91.579)*(-90.062)*(95.006)*(87.849)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-49.788)*(-96.093))/-42.38);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-3.844)*(26.755)*(8.81)*(-68.073)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-65.309)*(7.308))/-76.883);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(89.028)*(-44.341)*(-14.179)*(31.644)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-53.981)*(6.322))/-57.47);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
