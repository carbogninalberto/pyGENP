if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-97.831+(-89.928)+(34.669));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-90.329+(-87.928)+(-5.862));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) ((segmentsAcked*(-52.258)*(73.262)*(-1.428)*(-78.904)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(89.815)*(-59.385))/66.345);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-61.789)*(78.943)*(55.822)*(7.206)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-95.288)*(96.392))/24.104);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-33.509+(-15.094)+(22.1));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-18.353)*(72.435)*(55.635)*(-10.251)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-22.785)*(-10.562))/2.22);
tcb->m_cWnd = (int) (39.14+(34.355)+(4.599));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) ((segmentsAcked*(-88.37)*(67.243)*(33.914)*(-4.389)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(51.497)*(11.7))/-91.65);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-55.994)*(-78.105)*(-46.928)*(-87.203)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(27.296)*(5.951))/45.963);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(55.813)*(-61.702)*(6.617)*(35.355)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(99.115)*(44.511))/-49.877);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(13.134)*(19.128)*(25.019)*(22.251)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(39.448)*(35.342))/-25.032);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(25.329)*(-75.82)*(63.37)*(-33.028)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-34.519)*(86.607))/-50.54);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
