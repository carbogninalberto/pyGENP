if (cnt < tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/0.1);
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (15.22+(91.628)+(42.206)+(34.767));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (38.974*(48.263)*(37.635)*(57.27)*(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (cnt*(85.047));

}
tcb->m_ssThresh = (int) (0.1/0.1);
tcb->m_cWnd = (int) (80.575*(segmentsAcked)*(51.352)*(tcb->m_cWnd)*(52.775)*(83.767)*(56.607));
if (tcb->m_segmentSize >= cnt) {
	tcb->m_cWnd = (int) (52.881/0.1);
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(61.087)+(43.243));
	tcb->m_ssThresh = (int) (45.593-(66.841));

} else {
	tcb->m_cWnd = (int) (45.365-(51.335)-(36.887));
	segmentsAcked = (int) (6.819*(52.863)*(34.318)*(80.541)*(60.321)*(35.562)*(84.133));
	cnt = (int) (35.368*(21.125)*(28.023)*(tcb->m_cWnd));

}
tcb->m_ssThresh = (int) (0.1/0.1);
