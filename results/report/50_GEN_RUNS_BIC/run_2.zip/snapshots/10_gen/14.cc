float qkqnRSIvxiNQMZnW = (float) (96.218/(13.046-(tcb->m_ssThresh)-(6.586)-(96.469)-(23.683)-(27.204)-(23.643)-(5.228)));
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (0.1/5.892);
	tcb->m_cWnd = (int) (80.072-(tcb->m_ssThresh)-(59.711)-(88.139)-(36.935)-(57.195)-(34.679));

} else {
	tcb->m_cWnd = (int) (23.713+(84.921)+(11.909));

}
cnt = (int) (69.311-(34.295)-(58.188)-(5.118)-(40.166)-(31.938)-(17.258)-(47.185));
if (cnt > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((20.137)+(0.1)+(0.1)+(0.1))/((44.454)+(0.1)+(78.936)+(65.544)+(0.1)));
	tcb->m_cWnd = (int) (93.864+(21.294)+(13.828)+(qkqnRSIvxiNQMZnW)+(qkqnRSIvxiNQMZnW)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (50.097+(17.899)+(95.506)+(19.752)+(37.188)+(62.966)+(58.116)+(49.385));

} else {
	tcb->m_segmentSize = (int) (59.874*(57.166)*(66.859)*(33.242));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_ssThresh = (int) (27.592*(tcb->m_ssThresh)*(43.981)*(89.522)*(31.889)*(94.457)*(45.592)*(84.952)*(91.136));
float rVDMdsGZkGLTONlE = (float) (44.386-(75.591)-(segmentsAcked)-(17.399)-(56.165)-(qkqnRSIvxiNQMZnW));
if (cnt != rVDMdsGZkGLTONlE) {
	tcb->m_segmentSize = (int) (34.386-(98.569));
	tcb->m_segmentSize = (int) (((70.729)+(22.404)+(37.108)+((15.835*(61.75)*(tcb->m_segmentSize)*(60.382)*(16.224)*(segmentsAcked)*(24.263)*(70.092)))+(15.614))/((70.114)+(0.1)+(39.934)));
	rVDMdsGZkGLTONlE = (float) (0.1/5.487);

} else {
	tcb->m_segmentSize = (int) (20.455*(45.166)*(41.592)*(12.764)*(5.765));

}
if (tcb->m_ssThresh > rVDMdsGZkGLTONlE) {
	cnt = (int) ((rVDMdsGZkGLTONlE-(tcb->m_segmentSize)-(0.378)-(rVDMdsGZkGLTONlE))/63.195);

} else {
	cnt = (int) (33.851/0.1);

}
