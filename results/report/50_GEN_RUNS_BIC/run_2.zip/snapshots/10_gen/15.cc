if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (tcb->m_cWnd-(12.431)-(16.711)-(16.624)-(segmentsAcked)-(95.415)-(4.257));
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	segmentsAcked = (int) (((96.963)+((80.364*(8.422)*(64.478)*(30.109)))+(69.512)+(33.457))/((60.169)));
	tcb->m_cWnd = (int) (59.622+(6.889)+(tcb->m_cWnd)+(35.122)+(cnt)+(57.277)+(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(cnt)*(60.346)*(17.019)*(13.174)*(13.309));

} else {
	segmentsAcked = (int) ((((91.148*(42.85)*(8.598)*(tcb->m_segmentSize)*(96.544)))+(0.1)+(0.1)+((segmentsAcked*(84.723)*(58.547)*(tcb->m_segmentSize)*(13.661)))+(0.1))/((25.621)+(64.909)+(0.1)));
	tcb->m_ssThresh = (int) (3.662/0.1);
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (69.54+(22.257)+(75.243)+(37.391)+(58.304)+(tcb->m_ssThresh)+(99.115)+(64.693));
tcb->m_cWnd = (int) (tcb->m_ssThresh+(41.814)+(tcb->m_segmentSize)+(29.622)+(52.124)+(5.122)+(27.749)+(19.578));
