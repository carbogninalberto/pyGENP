if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-20.386+(19.867)+(-26.339));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-17.481)*(91.06)*(94.889)*(35.635)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(22.094)*(-53.272))/-77.75);
tcb->m_cWnd = (int) ((segmentsAcked*(-2.038)*(94.799)*(-76.416)*(82.739)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(34.917)*(-66.406))/-38.495);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-86.174+(27.764)+(70.508));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(55.881)*(59.934)*(78.526)*(51.34)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-73.592)*(-45.221))/-33.104);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_cWnd = (int) ((segmentsAcked*(-57.723)*(-92.01)*(-97.219)*(-98.988)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(92.434)*(-55.857))/17.39);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-31.871)*(10.767)*(1.71)*(-75.251)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(39.456)*(-6.008))/-72.219);
tcb->m_cWnd = (int) ((segmentsAcked*(62.047)*(-27.708)*(-83.045)*(23.689)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-97.897)*(-1.047))/-73.352);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(91.391)*(-41.628)*(-43.583)*(28.834)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-59.447)*(30.307))/-26.291);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
