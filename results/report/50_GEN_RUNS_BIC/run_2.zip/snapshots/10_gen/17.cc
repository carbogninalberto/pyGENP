float QwicjPeHvKUgeUNQ = (float) (99.751-(segmentsAcked)-(18.68)-(9.943)-(tcb->m_cWnd));
if (QwicjPeHvKUgeUNQ != tcb->m_ssThresh) {
	cnt = (int) (46.725*(4.438)*(83.107)*(52.062)*(5.464));

} else {
	cnt = (int) (cnt-(74.532));

}
if (tcb->m_ssThresh >= QwicjPeHvKUgeUNQ) {
	tcb->m_cWnd = (int) (94.229*(40.678)*(66.688)*(9.111)*(33.451)*(46.315));
	cnt = (int) (40.609+(tcb->m_ssThresh)+(63.491)+(85.187)+(46.932));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (74.214-(24.764)-(0.328)-(68.716)-(cnt)-(tcb->m_segmentSize)-(30.324)-(9.909)-(66.33));

}
float hmglxPJYqugFZRGH = (float) ((tcb->m_segmentSize*(56.328)*(10.578))/0.1);
if (hmglxPJYqugFZRGH <= hmglxPJYqugFZRGH) {
	QwicjPeHvKUgeUNQ = (float) (34.395-(56.499)-(27.423)-(6.534)-(28.812));
	tcb->m_cWnd = (int) (50.367+(tcb->m_ssThresh));

} else {
	QwicjPeHvKUgeUNQ = (float) (82.999+(25.321)+(tcb->m_segmentSize)+(hmglxPJYqugFZRGH)+(31.92)+(cnt));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > hmglxPJYqugFZRGH) {
	segmentsAcked = (int) (0.1/(55.027+(95.75)+(12.46)+(34.117)));

} else {
	segmentsAcked = (int) (63.59+(29.636)+(11.666)+(63.88)+(segmentsAcked)+(75.973));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (QwicjPeHvKUgeUNQ < hmglxPJYqugFZRGH) {
	tcb->m_segmentSize = (int) (0.1/65.806);
	segmentsAcked = (int) (15.26-(35.022)-(23.005)-(82.435)-(27.445)-(98.472)-(tcb->m_cWnd)-(99.613)-(72.661));

} else {
	tcb->m_segmentSize = (int) (50.031/77.778);
	cnt = (int) (tcb->m_ssThresh*(65.474)*(12.956)*(58.146)*(28.212)*(14.403));

}
