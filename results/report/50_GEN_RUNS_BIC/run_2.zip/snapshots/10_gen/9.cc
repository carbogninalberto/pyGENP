if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (53.371+(-54.52)+(-36.454));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-47.7)*(-99.26)*(-43.544)*(-54.106)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(61.785)*(18.276))/93.732);
tcb->m_cWnd = (int) ((segmentsAcked*(73.542)*(48.643)*(12.962)*(-52.057)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-6.457)*(-91.798))/55.803);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-61.855+(7.793)+(99.652));
tcb->m_cWnd = (int) ((segmentsAcked*(25.268)*(-44.286)*(-56.233)*(-71.679)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(10.034)*(11.697))/59.838);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(87.123)*(-65.631)*(-53.777)*(-61.472)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-54.141)*(-36.931))/41.813);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-27.053)*(11.541)*(-80.747)*(-43.369)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-26.496)*(-34.51))/96.679);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(63.355)*(45.459)*(-11.904)*(72.395)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(73.869)*(85.978))/-40.082);
tcb->m_cWnd = (int) ((segmentsAcked*(0.083)*(61.876)*(-81.799)*(45.145)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-24.057)*(-96.858))/-36.579);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (74.036+(37.217)+(7.145));
tcb->m_cWnd = (int) ((segmentsAcked*(22.436)*(-46.59)*(-30.171)*(-10.698)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-74.933)*(-37.134))/-44.961);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(89.628)*(-9.136)*(71.141)*(-76.484)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-86.729)*(-65.549))/46.592);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(7.2)*(-79.929)*(-28.605)*(-96.624)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(41.542)*(-70.405))/-1.587);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
