if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-17.079+(-87.992)+(6.282));
tcb->m_cWnd = (int) ((segmentsAcked*(-41.166)*(46.036)*(5.777)*(-49.464)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(44.96)*(-48.072))/-32.313);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-25.968)*(25.223)*(-5.824)*(67.852)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-64.99)*(30.202))/-79.065);
tcb->m_cWnd = (int) ((segmentsAcked*(72.094)*(-51.719)*(23.646)*(48.648)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(36.147)*(-39.511))/-61.293);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(17.631)*(-22.71)*(79.561)*(28.733)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-6.364)*(79.582))/-65.977);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(69.908)*(-82.566)*(-44.304)*(86.58)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-42.217)*(-2.698))/69.176);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
