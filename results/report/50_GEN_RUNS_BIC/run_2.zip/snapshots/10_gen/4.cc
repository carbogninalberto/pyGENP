if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (59.739+(-23.207)+(79.003));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(0.358)*(-48.045)*(-5.698)*(-79.046)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-4.626)*(-72.915))/56.946);
tcb->m_cWnd = (int) ((segmentsAcked*(35.387)*(-92.781)*(-4.703)*(4.509)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-30.367)*(94.937))/78.975);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-57.139+(-64.528)+(73.171));
tcb->m_cWnd = (int) ((segmentsAcked*(-44.716)*(3.098)*(-92.647)*(72.47)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(20.117)*(-80.05))/-50.752);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-56.234)*(-26.528)*(63.667)*(46.576)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(13.47)*(30.826))/90.146);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(42.762)*(-27.913)*(27.554)*(-77.48)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-72.624)*(18.496))/-52.489);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
