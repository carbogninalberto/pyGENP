ReduceCwnd (tcb);
if (cnt <= tcb->m_segmentSize) {
	segmentsAcked = (int) (((0.1)+(0.1)+((39.42*(tcb->m_cWnd)*(48.584)*(41.32)*(22.393)))+(2.581)+(0.1))/((0.1)+(80.572)+(0.1)+(1.731)));

} else {
	segmentsAcked = (int) (19.505/0.1);
	tcb->m_cWnd = (int) ((17.216-(79.906)-(11.101))/0.1);
	tcb->m_ssThresh = (int) (5.25*(tcb->m_ssThresh)*(45.514)*(5.398));

}
cnt = (int) ((47.558+(55.422)+(72.215)+(7.558)+(70.778)+(61.805)+(98.572)+(92.745)+(32.071))/0.1);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(47.858)+(36.016)+(44.197))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (98.562/60.979);

}
tcb->m_cWnd = (int) ((47.05*(55.479)*(2.837))/0.1);
