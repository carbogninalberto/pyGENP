cnt = (int) (77.838*(tcb->m_cWnd)*(tcb->m_segmentSize)*(14.121));
ReduceCwnd (tcb);
cnt = (int) (49.01+(1.451)+(66.039)+(20.576)+(22.178)+(75.824)+(24.047)+(60.648)+(tcb->m_cWnd));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) ((48.863+(1.881)+(tcb->m_ssThresh)+(91.377))/0.1);
int nyUeBqBzhdQawqJl = (int) (tcb->m_cWnd-(segmentsAcked));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (nyUeBqBzhdQawqJl >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (58.632/0.1);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(6.85)-(71.142)-(86.73)-(tcb->m_ssThresh)-(94.734)-(30.906)-(82.624)-(tcb->m_ssThresh));

}
