if (tcb->m_ssThresh <= cnt) {
	segmentsAcked = (int) (68.048+(24.32)+(46.685)+(64.767)+(35.916));

} else {
	segmentsAcked = (int) (27.553/4.547);

}
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(3.25)+(cnt)+(78.107)+(78.376)+(cnt)+(40.06)+(cnt));
tcb->m_cWnd = (int) (63.774*(97.687));
int PADGWwUncwilhxcG = (int) (38.135-(52.07)-(87.23)-(62.057));
ReduceCwnd (tcb);
if (tcb->m_cWnd > cnt) {
	tcb->m_segmentSize = (int) (81.761+(19.573)+(91.34)+(44.52)+(98.07)+(78.113));
	segmentsAcked = (int) (18.32+(3.841)+(57.603)+(30.509)+(67.377)+(8.589)+(36.326)+(83.48));

} else {
	tcb->m_segmentSize = (int) (78.188-(36.612)-(92.68));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) ((58.863*(19.787)*(44.558)*(75.458))/0.1);

}
ReduceCwnd (tcb);
