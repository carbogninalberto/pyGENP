tcb->m_segmentSize = (int) (73.209*(50.954)*(tcb->m_ssThresh)*(95.09)*(63.868)*(35.36));
if (segmentsAcked <= cnt) {
	cnt = (int) (30.427-(62.121));
	tcb->m_segmentSize = (int) (24.247-(22.728));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (84.644*(77.429)*(59.311)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(12.859));
	tcb->m_cWnd = (int) (26.863/(51.642-(11.504)-(74.106)-(71.384)));
	cnt = (int) (tcb->m_segmentSize*(49.3));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(49.242)*(13.968)*(tcb->m_segmentSize)*(58.655)*(cnt));

} else {
	tcb->m_cWnd = (int) (73.468/0.1);

}
ReduceCwnd (tcb);
