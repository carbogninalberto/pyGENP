if (segmentsAcked != tcb->m_segmentSize) {
	cnt = (int) (18.444+(75.035));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (0.1/0.1);

}
tcb->m_ssThresh = (int) (4.769*(81.363)*(tcb->m_cWnd)*(7.474)*(tcb->m_segmentSize)*(tcb->m_ssThresh));
ReduceCwnd (tcb);
cnt = (int) (cnt+(14.217)+(90.6)+(27.629)+(0.706));
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	segmentsAcked = (int) (67.669/0.1);

} else {
	segmentsAcked = (int) (((0.1)+(51.794)+(0.1)+(0.1)+((82.247+(54.393)))+(0.1))/((90.893)+(0.1)));

}
