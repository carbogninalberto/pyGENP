tcb->m_cWnd = (int) (7.987+(29.291)+(-79.713)+(77.285)+(40.763)+(69.004)+(-72.296)+(-79.222)+(-11.851));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (3.209+(-88.131));
