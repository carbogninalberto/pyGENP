if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) ((tcb->m_ssThresh*(41.047)*(13.444)*(50.39))/0.1);
tcb->m_ssThresh = (int) (69.823+(34.3));
ReduceCwnd (tcb);
if (cnt >= tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_ssThresh*(56.194)*(83.882)*(cnt)*(0.914)*(22.324)*(88.735));
	tcb->m_ssThresh = (int) (99.662+(67.875)+(30.828)+(1.725)+(63.612)+(65.836));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (22.599-(28.148));
	tcb->m_ssThresh = (int) ((67.151-(58.586)-(26.788)-(26.614)-(75.447)-(98.363))/99.826);

}
