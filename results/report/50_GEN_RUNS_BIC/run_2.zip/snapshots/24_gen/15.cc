cnt = (int) (83.298-(33.375)-(26.821)-(20.052)-(0.272)-(72.902)-(17.347)-(54.052));
if (cnt >= cnt) {
	tcb->m_segmentSize = (int) (96.057*(15.496)*(segmentsAcked)*(25.596));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(17.402)-(50.664)-(39.078)-(cnt)-(23.39)-(68.842));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (cnt+(35.823)+(6.454)+(37.838)+(1.792)+(tcb->m_cWnd));
tcb->m_ssThresh = (int) (46.478/0.1);
tcb->m_segmentSize = (int) (92.152*(85.528)*(52.234)*(11.461)*(segmentsAcked)*(tcb->m_ssThresh));
