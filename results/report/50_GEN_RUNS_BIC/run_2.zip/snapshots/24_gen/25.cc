if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (14.013*(84.228)*(cnt)*(tcb->m_ssThresh)*(segmentsAcked)*(4.612)*(16.997));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (89.365-(0.926)-(59.215)-(30.844)-(tcb->m_ssThresh)-(28.275)-(tcb->m_segmentSize)-(98.528)-(76.947));
	segmentsAcked = (int) (tcb->m_ssThresh+(34.718)+(19.048)+(14.415));

}
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	segmentsAcked = (int) (44.959-(tcb->m_ssThresh)-(61.128)-(69.412)-(80.954)-(98.461)-(99.145)-(74.799)-(1.275));
	segmentsAcked = (int) (76.652+(86.322)+(42.982)+(60.311)+(segmentsAcked)+(36.942));
	tcb->m_segmentSize = (int) (24.143-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(62.658));

} else {
	segmentsAcked = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
if (segmentsAcked > tcb->m_cWnd) {
	cnt = (int) (0.1/78.817);
	tcb->m_segmentSize = (int) (35.38*(70.63)*(81.171));
	tcb->m_ssThresh = (int) (74.506-(58.904)-(tcb->m_ssThresh));

} else {
	cnt = (int) (21.385*(32.691)*(89.746)*(1.381)*(22.633));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (73.282*(9.605)*(19.358)*(99.697)*(tcb->m_segmentSize)*(21.378));

}
tcb->m_ssThresh = (int) (33.523-(segmentsAcked)-(20.661)-(71.031)-(15.058)-(66.067)-(22.893));
