float vcvSjhAGipwjyRYd = (float) (64.318*(77.887));
if (vcvSjhAGipwjyRYd > tcb->m_cWnd) {
	cnt = (int) (0.1/55.188);
	cnt = (int) ((20.309*(cnt)*(75.069))/0.1);

} else {
	cnt = (int) (68.663*(segmentsAcked)*(73.566)*(9.873)*(93.766)*(7.841)*(91.172)*(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (88.912*(10.642)*(81.603));
	cnt = (int) (26.301-(44.415)-(99.798)-(tcb->m_cWnd)-(67.615)-(36.538)-(34.764)-(49.875)-(71.953));

}
ReduceCwnd (tcb);
int rwQGdLjlnNyDTbJm = (int) (26.149*(tcb->m_segmentSize)*(77.345)*(73.04)*(tcb->m_ssThresh)*(19.263));
float TFnuuqptCxmgcUfy = (float) (13.937*(97.013)*(60.346));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
