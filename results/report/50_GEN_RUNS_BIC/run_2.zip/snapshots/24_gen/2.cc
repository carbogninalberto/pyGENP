if (segmentsAcked >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (68.154-(96.788)-(30.181)-(23.053)-(82.41)-(19.996)-(segmentsAcked));
	tcb->m_cWnd = (int) (97.357+(0.51)+(94.615)+(tcb->m_segmentSize)+(14.508)+(28.149)+(82.992)+(0.063)+(segmentsAcked));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (44.185/19.894);
	tcb->m_cWnd = (int) (68.756-(1.679)-(65.63)-(26.642)-(40.306)-(segmentsAcked)-(89.623)-(78.413)-(5.135));

}
int FIsnqNGrsQXAMoxw = (int) (0.383*(-70.197)*(74.315)*(-75.276)*(-34.518));
ReduceCwnd (tcb);
