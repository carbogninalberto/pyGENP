ReduceCwnd (tcb);
segmentsAcked = (int) (cnt+(26.647)+(88.465)+(37.308)+(91.296)+(38.907)+(78.686)+(14.537));
tcb->m_ssThresh = (int) (((0.1)+(47.651)+(80.63)+(0.1))/((13.721)));
if (tcb->m_ssThresh < cnt) {
	tcb->m_segmentSize = (int) (44.203+(79.268)+(48.634)+(0.535)+(tcb->m_cWnd)+(cnt)+(tcb->m_segmentSize)+(4.832));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (40.51*(segmentsAcked)*(58.677)*(16.718)*(15.446)*(tcb->m_ssThresh)*(segmentsAcked)*(33.984)*(58.686));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(14.006)+(0.1)+(0.1))/((0.1)+(47.245)));
	segmentsAcked = (int) (cnt*(43.976)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(82.654)*(7.058)*(tcb->m_ssThresh)*(14.287)*(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (35.416-(tcb->m_cWnd)-(90.209)-(86.776)-(37.362)-(7.389)-(13.897));
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.1/0.1);
	cnt = (int) (tcb->m_ssThresh*(84.063)*(94.036)*(76.259)*(39.691)*(32.116)*(69.593)*(21.503)*(7.146));

} else {
	tcb->m_cWnd = (int) (46.622/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(96.246)-(99.371));

}
