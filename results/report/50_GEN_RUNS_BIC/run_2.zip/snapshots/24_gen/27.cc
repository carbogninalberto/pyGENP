if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	cnt = (int) (54.312+(66.34)+(50.018)+(16.663)+(11.513));
	tcb->m_ssThresh = (int) (((18.34)+(80.515)+((40.098-(segmentsAcked)-(25.203)-(99.125)-(56.14)-(tcb->m_cWnd)-(cnt)-(39.11)))+(33.349))/((0.1)+(0.1)+(0.1)));

} else {
	cnt = (int) (55.149+(88.37));
	tcb->m_segmentSize = (int) ((39.664-(cnt)-(53.756)-(37.169)-(52.806)-(39.341)-(36.012)-(tcb->m_ssThresh))/21.048);

}
cnt = (int) (cnt+(61.182)+(90.186)+(19.519)+(89.888));
if (segmentsAcked > segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd+(65.766)+(44.247)+(tcb->m_cWnd)+(17.173));
	cnt = (int) (((12.882)+(68.047)+(0.1)+(0.1))/((0.1)+(13.392)+(78.419)));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)));
	tcb->m_cWnd = (int) (64.509/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt > segmentsAcked) {
	tcb->m_ssThresh = (int) (((83.865)+((51.928+(8.371)+(tcb->m_cWnd)))+(0.1)+(0.1)+(0.1))/((67.212)));

} else {
	tcb->m_ssThresh = (int) (7.121-(20.453)-(43.283)-(24.458)-(76.992)-(tcb->m_ssThresh)-(11.229));

}
cnt = (int) (11.115+(segmentsAcked)+(18.397)+(49.469)+(51.617));
tcb->m_ssThresh = (int) (49.434+(cnt));
