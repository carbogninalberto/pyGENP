cnt = (int) (52.335-(87.743)-(68.559)-(71.036)-(27.327)-(segmentsAcked)-(48.198)-(95.779)-(47.337));
tcb->m_cWnd = (int) (0.1/0.1);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
float VFnVPkLedgpTxvGi = (float) (69.676-(47.502)-(44.088));
