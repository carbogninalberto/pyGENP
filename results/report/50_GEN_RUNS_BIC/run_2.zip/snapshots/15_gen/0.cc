ReduceCwnd (tcb);
tcb->m_cWnd = (int) ((28.405*(-98.143)*(13.706))/-16.706);
