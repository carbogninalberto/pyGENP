if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-45.182+(77.774)+(68.355));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-45.053)*(52.516)*(-32.591)*(-58.658)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(38.039)*(22.514))/78.048);
tcb->m_cWnd = (int) ((segmentsAcked*(57.095)*(24.786)*(-6.568)*(68.945)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(59.757)*(-79.105))/76.619);
tcb->m_cWnd = (int) ((segmentsAcked*(-83.825)*(-33.045)*(15.91)*(68.06)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-71.304)*(-56.655))/-32.121);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (96.608+(16.453)+(-13.586));
tcb->m_cWnd = (int) ((segmentsAcked*(-50.503)*(84.854)*(-99.892)*(50.484)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(32.68)*(0.924))/-18.664);
tcb->m_cWnd = (int) ((segmentsAcked*(67.461)*(-7.087)*(-44.518)*(-35.919)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(45.572)*(74.918))/84.036);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-61.531)*(62.16)*(54.281)*(-33.954)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-21.331)*(-40.758))/51.181);
tcb->m_cWnd = (int) ((segmentsAcked*(8.853)*(88.783)*(49.038)*(31.182)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(95.996)*(-50.303))/-49.348);
tcb->m_cWnd = (int) ((segmentsAcked*(-88.953)*(-92.38)*(-41.522)*(-48.455)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(16.427)*(-22.145))/71.289);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (46.766+(3.456)+(-49.988));
tcb->m_cWnd = (int) ((segmentsAcked*(-38.139)*(-33.171)*(4.02)*(30.879)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-70.122)*(-4.077))/12.91);
tcb->m_cWnd = (int) ((segmentsAcked*(-80.186)*(93.177)*(-34.772)*(-47.91)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(4.413)*(80.033))/-57.901);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-27.708)*(17.679)*(-8.246)*(-40.314)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-92.95)*(-73.043))/68.223);
tcb->m_cWnd = (int) ((segmentsAcked*(61.384)*(-88.174)*(84.632)*(-94.31)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(41.97)*(-18.471))/18.289);
tcb->m_cWnd = (int) ((segmentsAcked*(56.009)*(20.129)*(27.627)*(85.567)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-80.33)*(73.968))/-53.755);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(-2.411)*(-18.034)*(45.996)*(34.189)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-71.751)*(-77.314))/1.624);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (56.517+(-72.011)+(-95.888));
tcb->m_cWnd = (int) ((segmentsAcked*(92.469)*(-90.1)*(-65.681)*(-15.854)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(-29.866)*(64.955))/40.842);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(31.082)*(-58.052)*(-76.177)*(-14.532)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(94.91)*(14.202))/-95.884);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) ((segmentsAcked*(29.312)*(64.073)*(-68.629)*(54.821)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(65.127)*(-13.923))/-86.671);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
