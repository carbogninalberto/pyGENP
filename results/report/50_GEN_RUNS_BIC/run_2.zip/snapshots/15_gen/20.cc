if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (60.973/98.637);
tcb->m_cWnd = (int) (18.587+(82.192)+(54.192)+(tcb->m_segmentSize)+(51.293)+(86.481)+(52.964)+(tcb->m_segmentSize));
if (cnt > segmentsAcked) {
	tcb->m_ssThresh = (int) (24.302/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (0.891+(72.538)+(19.36));

}
tcb->m_segmentSize = (int) (93.508+(15.831)+(52.974));
tcb->m_ssThresh = (int) (87.178-(62.219));
