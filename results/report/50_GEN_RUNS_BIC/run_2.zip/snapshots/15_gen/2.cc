float tTWzJMFNIEkZmXOu = (float) (-87.021*(-88.155)*(61.597)*(76.699)*(85.065)*(-13.959)*(-99.71)*(-88.49));
tcb->m_cWnd = (int) (-42.09-(-2.753)-(-35.748)-(46.498));
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (62.316*(4.733)*(22.173)*(87.845)*(77.421)*(50.907)*(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (73.806-(81.102)-(31.311)-(43.053)-(6.871)-(43.025));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (65.383*(-48.396)*(79.74)*(16.563)*(56.193)*(27.51)*(42.164)*(32.227)*(-50.124));
