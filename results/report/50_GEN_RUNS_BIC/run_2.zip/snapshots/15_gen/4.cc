if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_cWnd+(74.767)+(93.132)+(99.983)+(37.992)+(22.681));
	tcb->m_cWnd = (int) (19.318-(65.539)-(segmentsAcked));
	tcb->m_segmentSize = (int) (57.957-(3.402)-(30.355)-(25.481)-(63.883)-(33.797));

} else {
	segmentsAcked = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (0.1/0.1);
	segmentsAcked = (int) (3.38*(62.99)*(47.404)*(87.309)*(28.81));

}
segmentsAcked = (int) (18.782+(-66.286)+(-24.912)+(-26.85)+(66.945)+(37.997)+(26.98)+(44.778)+(63.039));
