float lMqPiZvtKCPudgyk = (float) (((-9.524)+((-31.995-(-85.469)))+(26.63)+(47.398)+(42.507))/((69.34)));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
