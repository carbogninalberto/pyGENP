if (segmentsAcked != cnt) {
	segmentsAcked = (int) (18.939*(83.236)*(72.66));
	tcb->m_ssThresh = (int) (72.812+(tcb->m_segmentSize)+(19.845)+(33.306)+(1.708)+(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (22.754-(61.195)-(33.284)-(segmentsAcked)-(63.403)-(34.45)-(55.515)-(tcb->m_cWnd)-(24.706));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_ssThresh = (int) (46.137+(11.958)+(16.537)+(tcb->m_segmentSize)+(91.144)+(58.447));
	tcb->m_cWnd = (int) (82.614/0.1);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (0.1/7.467);

}
tcb->m_segmentSize = (int) (57.519+(60.463)+(1.463)+(36.202)+(10.362)+(13.103)+(57.639)+(24.649));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	cnt = (int) (tcb->m_cWnd*(53.71)*(48.955));

} else {
	cnt = (int) (17.818-(38.418)-(56.092)-(24.265)-(49.334)-(95.236));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (40.617+(tcb->m_segmentSize)+(48.523)+(tcb->m_ssThresh));
