if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (88.705-(52.927));

} else {
	tcb->m_cWnd = (int) (49.407-(96.455)-(93.258)-(0.44)-(86.11)-(41.823)-(67.523)-(60.209));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (50.436+(39.009)+(35.105)+(58.475));

}
tcb->m_segmentSize = (int) (15.609-(cnt)-(3.071)-(58.674)-(73.923)-(cnt));
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= cnt) {
	tcb->m_segmentSize = (int) (0.1/0.1);

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+((25.664*(92.558)*(74.65)*(89.08)*(44.636)*(32.743)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(51.671)))+(0.1)+(0.1)+(0.1))/((0.1)));

}
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (28.559-(tcb->m_segmentSize)-(37.574)-(42.745)-(45.375)-(94.156)-(26.53)-(80.606)-(88.61));

} else {
	tcb->m_segmentSize = (int) (76.451/0.1);
	cnt = (int) (cnt+(60.082));

}
