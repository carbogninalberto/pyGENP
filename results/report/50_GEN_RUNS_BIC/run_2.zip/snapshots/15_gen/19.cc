if (tcb->m_cWnd == segmentsAcked) {
	cnt = (int) (25.084/89.477);

} else {
	cnt = (int) (cnt*(80.192)*(82.98));
	cnt = (int) (6.814-(58.26));

}
if (segmentsAcked > segmentsAcked) {
	segmentsAcked = (int) (68.725/22.937);

} else {
	segmentsAcked = (int) (14.997-(59.408)-(10.954)-(31.459)-(cnt)-(65.625)-(tcb->m_cWnd));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (19.643-(95.483)-(17.189)-(20.162)-(7.506)-(20.564)-(cnt)-(11.325));

}
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (57.042*(41.965)*(99.853)*(49.279)*(tcb->m_ssThresh)*(cnt)*(segmentsAcked)*(tcb->m_cWnd)*(21.525));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (70.361-(30.071)-(99.105)-(19.555));

}
if (tcb->m_segmentSize < segmentsAcked) {
	cnt = (int) (87.346+(9.214)+(tcb->m_segmentSize)+(59.166));

} else {
	cnt = (int) (41.562/0.1);

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (tcb->m_ssThresh-(cnt)-(36.479));
