segmentsAcked = (int) (-60.041+(74.252)+(24.836)+(-82.481)+(73.315)+(34.441)+(61.007)+(-18.728));
int MTWwvWQFwErSBauC = (int) 95.82;
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (6.025-(49.143));
	tcb->m_cWnd = (int) (25.941-(66.035)-(48.197)-(segmentsAcked)-(18.221)-(52.974));

} else {
	segmentsAcked = (int) (71.161+(22.999)+(20.973));

}
MTWwvWQFwErSBauC = (int) (75.499+(71.366)+(50.892)+(65.238)+(50.909)+(52.779));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
