float xNrpnzSLIzXeFIFU = (float) (((0.1)+(0.1)+(71.502)+(25.565))/((0.1)+(0.1)+(0.1)));
if (cnt >= tcb->m_cWnd) {
	xNrpnzSLIzXeFIFU = (float) (79.098*(87.51)*(22.517)*(28.763)*(67.302)*(71.851)*(9.35)*(22.378));

} else {
	xNrpnzSLIzXeFIFU = (float) (cnt+(xNrpnzSLIzXeFIFU));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked >= xNrpnzSLIzXeFIFU) {
	segmentsAcked = (int) (20.502*(57.743)*(14.415)*(segmentsAcked)*(segmentsAcked)*(64.364)*(24.855)*(89.765)*(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (xNrpnzSLIzXeFIFU+(68.362)+(6.379)+(37.124));

} else {
	segmentsAcked = (int) (49.789+(9.633)+(56.502)+(22.047)+(segmentsAcked)+(33.715));
	ReduceCwnd (tcb);

}
cnt = (int) (segmentsAcked*(44.046));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((20.579)+((52.064+(75.978)+(38.982)+(74.172)))+(45.671)+((36.368*(48.12)*(91.202)))+(0.1))/((42.176)+(1.278)));
	tcb->m_ssThresh = (int) (26.747-(xNrpnzSLIzXeFIFU)-(27.65)-(87.04));
	xNrpnzSLIzXeFIFU = (float) (segmentsAcked-(79.279)-(tcb->m_ssThresh)-(57.371)-(23.914)-(65.056)-(8.125)-(10.794)-(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (xNrpnzSLIzXeFIFU*(88.336));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (xNrpnzSLIzXeFIFU > cnt) {
	segmentsAcked = (int) (14.091*(96.72)*(62.304)*(26.052)*(56.177)*(1.386)*(21.703)*(18.631)*(3.924));
	cnt = (int) (45.288*(5.085)*(74.94)*(12.735)*(98.401)*(28.992));

} else {
	segmentsAcked = (int) (((0.1)+(0.1)+(49.47)+(2.83))/((0.1)+(0.1)+(0.1)));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(14.559)+(0.1)+(0.1))/((38.317)));

}
if (segmentsAcked > xNrpnzSLIzXeFIFU) {
	cnt = (int) (34.017-(44.158));
	segmentsAcked = (int) (37.043*(50.041)*(57.344)*(40.566)*(29.635));
	tcb->m_cWnd = (int) ((4.999*(12.733)*(9.539)*(98.049)*(32.897))/93.009);

} else {
	cnt = (int) (4.797*(segmentsAcked));
	segmentsAcked = (int) (54.027-(40.844)-(47.679)-(50.748)-(89.97));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
