ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (21.899-(90.889)-(19.431)-(17.71)-(tcb->m_segmentSize)-(59.137));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (segmentsAcked-(36.599)-(tcb->m_segmentSize)-(segmentsAcked));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
