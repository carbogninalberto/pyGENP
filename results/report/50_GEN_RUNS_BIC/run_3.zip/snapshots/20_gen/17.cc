segmentsAcked = (int) (62.941*(tcb->m_ssThresh));
cnt = (int) (89.523+(tcb->m_ssThresh)+(55.13)+(64.699));
cnt = (int) (12.056+(98.284)+(cnt)+(66.516)+(48.552));
tcb->m_ssThresh = (int) ((62.326-(22.744)-(8.111)-(76.037)-(70.315)-(60.418)-(37.198)-(72.392)-(84.441))/10.996);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	cnt = (int) (42.275-(25.259)-(71.209)-(15.634)-(95.809)-(26.834));
	segmentsAcked = (int) (61.116+(tcb->m_cWnd)+(tcb->m_cWnd)+(70.599)+(69.141));
	tcb->m_segmentSize = (int) (54.72/80.96);

} else {
	cnt = (int) (90.577-(cnt)-(21.005)-(49.532));
	segmentsAcked = (int) (42.518+(18.479)+(tcb->m_ssThresh)+(50.459)+(45.908));
	tcb->m_segmentSize = (int) (19.778-(50.403)-(tcb->m_cWnd)-(3.265)-(15.015)-(12.924));

}
if (tcb->m_ssThresh < cnt) {
	cnt = (int) (11.302+(51.292));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (23.826*(32.476)*(35.683)*(92.003)*(67.364)*(segmentsAcked));

} else {
	cnt = (int) (49.61*(tcb->m_ssThresh)*(90.897)*(22.843)*(48.892));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (21.062*(45.821)*(50.226));

} else {
	tcb->m_segmentSize = (int) (93.332/8.51);
	tcb->m_cWnd = (int) (((69.103)+(0.1)+(0.1)+((cnt*(tcb->m_segmentSize)*(73.234)*(55.909)*(segmentsAcked)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(74.599)))+(0.1)+(5.537))/((38.245)+(84.778)));
	tcb->m_cWnd = (int) (2.523/31.453);

}
