float csXTBQbEYtFxaQHX = (float) (30.825+(71.191)+(segmentsAcked)+(3.046)+(76.566)+(70.262)+(32.918)+(tcb->m_ssThresh)+(73.346));
if (cnt < tcb->m_ssThresh) {
	csXTBQbEYtFxaQHX = (float) (cnt-(45.466)-(24.419)-(5.48)-(tcb->m_cWnd));

} else {
	csXTBQbEYtFxaQHX = (float) (82.975+(56.059)+(78.767)+(tcb->m_cWnd)+(76.205)+(88.342));
	tcb->m_segmentSize = (int) (0.1/54.91);
	tcb->m_cWnd = (int) (40.474-(64.621)-(cnt)-(25.676)-(20.358)-(60.857)-(12.773));

}
tcb->m_segmentSize = (int) (19.658/14.074);
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (88.34-(72.205)-(91.614)-(30.551)-(83.82));

} else {
	tcb->m_ssThresh = (int) (96.287-(87.046)-(cnt)-(43.974)-(41.15)-(tcb->m_ssThresh)-(9.464)-(23.875)-(88.741));
	tcb->m_ssThresh = (int) (93.906/95.961);
	csXTBQbEYtFxaQHX = (float) (99.67-(28.153)-(cnt)-(64.569)-(73.24)-(91.126)-(36.18)-(99.838));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (cnt*(tcb->m_ssThresh)*(83.673)*(87.386)*(24.91)*(85.661)*(88.933)*(95.059)*(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (12.46-(tcb->m_ssThresh)-(2.075)-(66.713)-(segmentsAcked)-(29.748)-(21.117));
	csXTBQbEYtFxaQHX = (float) (22.457+(tcb->m_cWnd)+(1.583)+(14.52)+(tcb->m_segmentSize)+(tcb->m_cWnd)+(36.844)+(88.403)+(1.684));
	tcb->m_ssThresh = (int) (92.558+(43.661)+(17.16)+(19.542)+(56.616)+(35.427)+(segmentsAcked)+(tcb->m_segmentSize));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd <= csXTBQbEYtFxaQHX) {
	csXTBQbEYtFxaQHX = (float) (46.583-(46.014)-(35.235)-(92.831)-(tcb->m_cWnd)-(45.271)-(68.775)-(segmentsAcked));
	tcb->m_segmentSize = (int) (67.104/0.1);
	ReduceCwnd (tcb);

} else {
	csXTBQbEYtFxaQHX = (float) (0.1/59.633);

}
tcb->m_cWnd = (int) (0.1/12.958);
