tcb->m_cWnd = (int) (49.64+(51.02)+(22.742)+(tcb->m_segmentSize)+(tcb->m_segmentSize));
tcb->m_ssThresh = (int) (37.665/21.005);
ReduceCwnd (tcb);
int cHMTMxvBWrUvzPEO = (int) (61.79*(5.908)*(segmentsAcked)*(85.298)*(22.217)*(tcb->m_segmentSize)*(32.011)*(57.599)*(8.271));
ReduceCwnd (tcb);
