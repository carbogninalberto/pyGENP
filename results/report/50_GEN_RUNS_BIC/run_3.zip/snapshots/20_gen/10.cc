int ukVCPlKAGyjPfxOw = (int) (85.727-(-62.216)-(76.239)-(71.472)-(81.007)-(25.124)-(81.079));
tcb->m_cWnd = (int) (28.877*(-58.958)*(-27.515));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (70.375*(85.564)*(10.583));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (74.073*(-1.122)*(50.136));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-1.071*(-8.454)*(-21.631));
