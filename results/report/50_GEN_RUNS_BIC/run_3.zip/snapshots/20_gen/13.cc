int rVQGwvORSEASLmAS = (int) (95.697*(13.185)*(18.699));
ReduceCwnd (tcb);
segmentsAcked = (int) ((87.059-(75.67)-(60.597))/43.781);
segmentsAcked = (int) ((-97.868-(-62.356)-(13.105))/99.255);
ReduceCwnd (tcb);
