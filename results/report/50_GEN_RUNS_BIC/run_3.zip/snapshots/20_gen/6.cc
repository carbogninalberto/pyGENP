int rVQGwvORSEASLmAS = (int) (-81.061*(-87.094)*(18.17));
float YLHbtPPxLDJvvStz = (float) (64.735/66.601);
