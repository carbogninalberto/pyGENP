int klWGcMgNaGdrEHjq = (int) (-36.562*(-90.538)*(67.165)*(-48.084)*(-85.603)*(23.348)*(-22.176)*(43.927));
float AzAPlqrYrOAgweof = (float) (11.914*(16.758)*(-91.01)*(-94.506)*(28.634)*(-91.542)*(11.72)*(-80.648));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-44.811+(-65.916)+(37.27)+(-3.447)+(-77.012)+(-76.568)+(-79.456)+(23.716)+(67.616));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (51.566+(-29.805)+(-24.163)+(69.737)+(-46.197)+(-29.253)+(21.198)+(-97.532)+(-68.862));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
