ReduceCwnd (tcb);
int ukVCPlKAGyjPfxOw = (int) (59.428-(96.571)-(-45.75)-(53.759)-(-48.788)-(-30.92)-(-68.087));
tcb->m_cWnd = (int) (-23.772*(56.382)*(-28.264));
