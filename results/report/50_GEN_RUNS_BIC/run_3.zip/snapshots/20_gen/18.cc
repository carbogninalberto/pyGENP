if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) ((tcb->m_segmentSize+(24.205)+(tcb->m_cWnd)+(74.843)+(83.551))/83.976);

} else {
	segmentsAcked = (int) (37.291*(19.073)*(30.193)*(cnt)*(63.043)*(tcb->m_cWnd)*(38.956)*(1.393)*(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (85.379*(25.595)*(29.601)*(86.581));

}
if (segmentsAcked != cnt) {
	cnt = (int) (57.701/81.947);
	segmentsAcked = (int) (11.119+(77.582)+(segmentsAcked));
	tcb->m_segmentSize = (int) (39.149+(25.326)+(16.859)+(73.408)+(58.634)+(75.421)+(tcb->m_cWnd));

} else {
	cnt = (int) (73.735-(86.697));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(57.295)+(53.118)+(5.824)+(77.673)+(cnt));
	segmentsAcked = (int) (43.836*(84.191)*(44.568)*(17.348)*(0.84)*(84.887)*(58.968));

}
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (76.309+(tcb->m_cWnd)+(86.799)+(64.901)+(18.946)+(tcb->m_cWnd));
	cnt = (int) (cnt+(tcb->m_segmentSize));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (59.129+(cnt)+(87.097)+(segmentsAcked)+(19.958)+(0.815)+(66.3));
	tcb->m_cWnd = (int) (17.456+(cnt)+(59.964)+(tcb->m_segmentSize)+(6.23)+(segmentsAcked)+(66.578)+(70.703));

}
int JiaoweigcbjRDIDa = (int) (24.637-(90.267));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
