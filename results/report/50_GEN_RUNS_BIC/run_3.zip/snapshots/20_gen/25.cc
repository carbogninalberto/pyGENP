segmentsAcked = (int) (87.213-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(55.618)-(11.809)-(12.697)-(cnt)-(tcb->m_cWnd)-(15.039));
segmentsAcked = (int) (19.555+(62.387)+(17.223)+(24.967)+(73.484));
ReduceCwnd (tcb);
int FylNgDSkkJslbdou = (int) (segmentsAcked-(68.102)-(57.856)-(2.348)-(53.709)-(17.955));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (38.066*(70.253)*(tcb->m_segmentSize)*(74.866)*(FylNgDSkkJslbdou));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (63.764+(90.059)+(tcb->m_segmentSize)+(48.967)+(tcb->m_cWnd)+(94.641));
	segmentsAcked = (int) (60.089-(79.383)-(tcb->m_ssThresh)-(33.527)-(30.431)-(FylNgDSkkJslbdou));
	segmentsAcked = (int) ((84.244*(47.221)*(51.164)*(65.209)*(tcb->m_segmentSize))/(14.605-(67.084)));

}
ReduceCwnd (tcb);
