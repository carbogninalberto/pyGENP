tcb->m_cWnd = (int) (35.452-(30.151)-(-21.233)-(48.426));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (59.907-(-97.834)-(-30.569)-(60.448));
ReduceCwnd (tcb);
