int rsMYxZzmbYEWUmHU = (int) (66.571*(-34.488)*(-55.104)*(54.562)*(27.898)*(-26.332)*(58.448)*(-90.646));
tcb->m_cWnd = (int) (-30.223+(-16.418)+(19.005)+(-79.604)+(14.692));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
rsMYxZzmbYEWUmHU = (int) (-74.934/97.408);
rsMYxZzmbYEWUmHU = (int) (-43.258/-49.437);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (1.741*(-39.246)*(-65.819));
tcb->m_cWnd = (int) (28.499*(-82.078)*(-67.469));
