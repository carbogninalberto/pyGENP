tcb->m_segmentSize = (int) (99.0-(47.28)-(tcb->m_ssThresh)-(4.205)-(42.198));
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	segmentsAcked = (int) (tcb->m_ssThresh-(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) ((segmentsAcked-(63.241)-(20.241))/0.1);

} else {
	segmentsAcked = (int) (tcb->m_ssThresh+(19.277)+(47.808)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(98.455)+(39.473));
	tcb->m_cWnd = (int) (segmentsAcked*(8.588));

}
tcb->m_ssThresh = (int) (12.408*(tcb->m_ssThresh)*(93.911)*(50.481)*(87.878)*(76.222));
ReduceCwnd (tcb);
if (tcb->m_cWnd > tcb->m_segmentSize) {
	cnt = (int) (segmentsAcked+(tcb->m_cWnd)+(66.92));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (cnt+(56.381)+(9.792)+(95.157));
	tcb->m_ssThresh = (int) (69.684-(49.893)-(94.672)-(segmentsAcked)-(tcb->m_segmentSize)-(73.318)-(86.157));

}
if (tcb->m_cWnd <= tcb->m_cWnd) {
	segmentsAcked = (int) (tcb->m_segmentSize-(cnt)-(87.235)-(30.195)-(segmentsAcked)-(19.948)-(3.089)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (11.555*(9.31)*(77.014)*(71.396)*(95.324)*(60.986));
	cnt = (int) (27.164+(35.909)+(96.622));

} else {
	segmentsAcked = (int) (84.207-(6.882)-(77.615)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(cnt)-(15.926)-(cnt));
	tcb->m_cWnd = (int) (29.131-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (46.036/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
