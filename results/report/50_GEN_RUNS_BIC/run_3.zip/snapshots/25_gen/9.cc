int ukVCPlKAGyjPfxOw = (int) (94.808-(63.384)-(-53.649)-(-94.526)-(-66.979)-(5.953)-(-53.427));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (30.504*(-31.595)*(-5.889));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-89.536*(57.818)*(49.58));
