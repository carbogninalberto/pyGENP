cnt = (int) (28.896+(28.472)+(74.04)+(tcb->m_ssThresh)+(38.897)+(72.388)+(32.661));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int rsMYxZzmbYEWUmHU = (int) (segmentsAcked*(tcb->m_cWnd)*(tcb->m_segmentSize)*(11.35)*(13.948)*(15.187)*(1.295)*(tcb->m_ssThresh));
rsMYxZzmbYEWUmHU = (int) (57.23/0.1);
ReduceCwnd (tcb);
if (cnt < rsMYxZzmbYEWUmHU) {
	tcb->m_ssThresh = (int) (43.433*(segmentsAcked)*(71.968)*(62.683)*(73.717)*(65.948));

} else {
	tcb->m_ssThresh = (int) ((3.056-(54.901)-(cnt)-(60.155)-(6.566)-(tcb->m_ssThresh)-(20.546)-(69.848))/0.1);
	tcb->m_ssThresh = (int) (46.103*(rsMYxZzmbYEWUmHU)*(63.819));

}
tcb->m_cWnd = (int) (94.2*(97.093)*(segmentsAcked));
