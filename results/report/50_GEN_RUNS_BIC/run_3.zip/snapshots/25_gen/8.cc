tcb->m_cWnd = (int) (-26.367-(-3.123)-(-82.532)-(-35.267)-(-65.694)-(-19.036)-(37.71)-(-41.003)-(72.92));
if (segmentsAcked != segmentsAcked) {
	segmentsAcked = (int) (50.749+(tcb->m_cWnd)+(95.411)+(71.509)+(segmentsAcked)+(63.666));

} else {
	segmentsAcked = (int) ((tcb->m_segmentSize*(cnt)*(tcb->m_cWnd)*(72.266)*(45.614)*(69.965)*(22.679)*(73.844))/38.788);
	segmentsAcked = (int) (((0.1)+(67.224)+(0.1)+(0.1)+(93.029)+(0.1))/((7.392)+(36.246)));
	tcb->m_cWnd = (int) (92.442*(tcb->m_cWnd)*(95.512)*(tcb->m_segmentSize)*(27.125));

}
if (segmentsAcked != segmentsAcked) {
	segmentsAcked = (int) (50.749+(tcb->m_cWnd)+(95.411)+(71.509)+(segmentsAcked)+(63.666));

} else {
	segmentsAcked = (int) ((tcb->m_segmentSize*(cnt)*(tcb->m_cWnd)*(72.266)*(45.614)*(69.965)*(22.679)*(73.844))/38.788);
	segmentsAcked = (int) (((0.1)+(67.224)+(0.1)+(0.1)+(93.029)+(0.1))/((7.392)+(36.246)));
	tcb->m_cWnd = (int) (92.442*(tcb->m_cWnd)*(95.512)*(tcb->m_segmentSize)*(27.125));

}
tcb->m_segmentSize = (int) (-75.693+(-50.891));
tcb->m_segmentSize = (int) (77.349+(88.163));
segmentsAcked = (int) (25.514-(90.171)-(-60.258)-(-66.501)-(-86.007)-(92.014)-(-35.608)-(8.405)-(62.276));
segmentsAcked = (int) (-37.99-(91.417)-(49.702)-(-93.423)-(26.289)-(-18.925)-(-7.621)-(-62.861)-(83.151));
tcb->m_segmentSize = (int) (-70.562/-74.148);
tcb->m_segmentSize = (int) (-36.161/96.317);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
