tcb->m_segmentSize = (int) (77.75-(50.991));
tcb->m_segmentSize = (int) (72.427-(49.44)-(46.328)-(39.74)-(5.918)-(31.578)-(tcb->m_segmentSize)-(19.344));
cnt = (int) (51.024+(98.435)+(tcb->m_ssThresh));
int lDsuycOcbBCusFAo = (int) (94.815*(40.323)*(tcb->m_ssThresh));
ReduceCwnd (tcb);
lDsuycOcbBCusFAo = (int) (2.992+(17.825)+(63.103)+(47.791)+(24.887));
