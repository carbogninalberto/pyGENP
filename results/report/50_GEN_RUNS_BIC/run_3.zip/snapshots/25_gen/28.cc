int bTuMiSMtUoXOELiF = (int) (47.071-(17.8)-(65.648)-(11.373)-(7.491)-(86.918)-(99.397)-(40.886)-(33.398));
if (tcb->m_segmentSize != bTuMiSMtUoXOELiF) {
	tcb->m_segmentSize = (int) (79.577+(9.157));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (77.424-(tcb->m_ssThresh)-(75.379)-(46.205)-(1.39)-(82.323)-(91.932)-(46.885));
	segmentsAcked = (int) (55.523/0.1);

}
tcb->m_ssThresh = (int) (0.1/(tcb->m_segmentSize+(68.642)+(67.655)+(tcb->m_segmentSize)+(bTuMiSMtUoXOELiF)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (bTuMiSMtUoXOELiF == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (((63.431)+((45.782-(66.871)-(6.957)-(cnt)-(92.782)-(92.482)-(47.664)-(54.48)-(66.733)))+((87.998*(93.016)*(bTuMiSMtUoXOELiF)*(76.51)*(17.944)*(70.196)*(40.403)*(tcb->m_ssThresh)*(1.655)))+(94.96))/((0.1)+(0.1)+(0.1)));
	tcb->m_ssThresh = (int) (94.538*(29.435)*(38.782)*(30.973)*(14.557)*(9.049)*(32.377)*(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (20.501+(40.617));

} else {
	tcb->m_ssThresh = (int) (cnt-(53.675)-(44.669)-(11.253)-(49.206)-(61.568));

}
cnt = (int) (64.996/46.219);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
