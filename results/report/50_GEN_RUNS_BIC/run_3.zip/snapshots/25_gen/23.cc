ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (2.034+(segmentsAcked)+(92.507)+(tcb->m_cWnd)+(58.856)+(83.769)+(11.96)+(1.672));
tcb->m_ssThresh = (int) (20.614+(47.3)+(9.391)+(48.049)+(85.855)+(15.071));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (48.794-(tcb->m_ssThresh)-(69.274)-(4.025)-(84.99)-(30.959));
if (segmentsAcked <= segmentsAcked) {
	cnt = (int) (0.1/65.918);

} else {
	cnt = (int) (99.468*(segmentsAcked)*(97.25));
	ReduceCwnd (tcb);
	cnt = (int) (55.629+(18.259)+(79.371));

}
