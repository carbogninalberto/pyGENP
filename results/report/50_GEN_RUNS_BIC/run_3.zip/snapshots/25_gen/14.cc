if (segmentsAcked != tcb->m_cWnd) {
	cnt = (int) (44.654*(55.14)*(9.594)*(11.792));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	cnt = (int) (7.619+(66.43)+(1.803)+(37.209)+(79.925)+(segmentsAcked)+(cnt));

}
if (tcb->m_segmentSize > tcb->m_cWnd) {
	segmentsAcked = (int) (66.414/0.1);

} else {
	segmentsAcked = (int) (48.047*(87.119)*(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (68.658+(25.553)+(11.104));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked <= tcb->m_segmentSize) {
	segmentsAcked = (int) (83.058-(64.076)-(99.642)-(91.906)-(tcb->m_cWnd)-(65.937)-(79.735)-(tcb->m_ssThresh)-(44.028));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (cnt+(24.277)+(57.201)+(40.013)+(23.527)+(14.25)+(cnt));

} else {
	segmentsAcked = (int) (85.137+(32.37)+(81.988)+(79.271)+(tcb->m_ssThresh)+(22.291));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (tcb->m_cWnd+(71.761)+(57.244)+(93.181)+(81.876));

}
if (segmentsAcked <= cnt) {
	tcb->m_cWnd = (int) (segmentsAcked*(77.24)*(tcb->m_segmentSize)*(41.191)*(53.916)*(segmentsAcked)*(4.232));
	segmentsAcked = (int) (segmentsAcked+(55.207));

} else {
	tcb->m_cWnd = (int) (13.206/36.505);
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
