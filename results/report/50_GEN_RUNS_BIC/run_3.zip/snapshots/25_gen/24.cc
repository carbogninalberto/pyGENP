cnt = (int) (7.503*(cnt)*(tcb->m_ssThresh)*(61.766)*(23.691)*(31.817)*(segmentsAcked)*(segmentsAcked));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (54.634-(85.014)-(22.192)-(tcb->m_segmentSize)-(52.38)-(tcb->m_cWnd)-(tcb->m_cWnd)-(69.549));
int dZRaJeTDfHRbQJnk = (int) (0.1/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (32.165+(16.691)+(49.48)+(35.827)+(43.601)+(34.586)+(88.175)+(30.115));
