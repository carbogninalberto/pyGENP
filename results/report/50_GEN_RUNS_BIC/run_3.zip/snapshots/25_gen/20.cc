if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (72.965*(1.056));

} else {
	tcb->m_cWnd = (int) (segmentsAcked+(38.68)+(85.019)+(93.497)+(29.339)+(62.201)+(23.661)+(tcb->m_cWnd)+(95.529));
	cnt = (int) (0.1/85.061);
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd >= cnt) {
	tcb->m_cWnd = (int) (14.391/47.646);

} else {
	tcb->m_cWnd = (int) ((segmentsAcked-(10.679)-(45.532))/0.1);
	tcb->m_cWnd = (int) (85.055+(66.635)+(53.113)+(27.955)+(8.807)+(38.486)+(37.128)+(24.643)+(0.631));

}
int inkmtiSVtGNaxmma = (int) ((cnt-(64.071))/0.1);
if (inkmtiSVtGNaxmma < inkmtiSVtGNaxmma) {
	tcb->m_cWnd = (int) (90.705+(21.291)+(17.352)+(35.259)+(cnt)+(74.579));

} else {
	tcb->m_cWnd = (int) (52.43-(tcb->m_cWnd)-(86.134)-(2.19)-(3.203)-(79.827)-(49.586)-(inkmtiSVtGNaxmma)-(59.264));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (0.1/0.1);

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (82.984-(8.291)-(97.568)-(4.101)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (42.24-(9.393)-(90.799)-(56.723)-(94.562)-(98.486));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
