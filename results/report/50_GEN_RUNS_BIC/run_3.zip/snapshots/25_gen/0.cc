float eiOVtWCIEHLvEXdj = (float) (42.56-(21.191)-(-31.185)-(87.208)-(92.424)-(-67.549));
eiOVtWCIEHLvEXdj = (float) ((-71.195+(tcb->m_cWnd)+(-17.54)+(93.108)+(-88.343)+(80.079)+(-18.098))/37.821);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
