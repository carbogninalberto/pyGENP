float eiOVtWCIEHLvEXdj = (float) (61.84-(16.728)-(-69.516)-(-76.268)-(-91.487)-(51.878));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
