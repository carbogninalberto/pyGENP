if (segmentsAcked != segmentsAcked) {
	segmentsAcked = (int) (50.749+(tcb->m_cWnd)+(95.411)+(71.509)+(segmentsAcked)+(63.666));

} else {
	segmentsAcked = (int) ((tcb->m_segmentSize*(cnt)*(tcb->m_cWnd)*(72.266)*(45.614)*(69.965)*(22.679)*(73.844))/38.788);
	segmentsAcked = (int) (((0.1)+(67.224)+(0.1)+(0.1)+(93.029)+(0.1))/((7.392)+(36.246)));
	tcb->m_cWnd = (int) (92.442*(tcb->m_cWnd)*(95.512)*(tcb->m_segmentSize)*(27.125));

}
tcb->m_segmentSize = (int) (0.833+(74.784));
segmentsAcked = (int) (12.625-(5.612)-(-14.353)-(86.745)-(88.931)-(-80.88)-(80.155)-(86.555)-(-56.543));
tcb->m_segmentSize = (int) (-90.36/-30.754);
ReduceCwnd (tcb);
