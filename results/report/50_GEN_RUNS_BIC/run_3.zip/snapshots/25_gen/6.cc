if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (39.88-(1.928)-(33.223)-(93.491));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-69.612-(18.99)-(-33.776)-(68.082));
ReduceCwnd (tcb);
