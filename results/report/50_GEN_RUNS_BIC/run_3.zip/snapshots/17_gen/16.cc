ReduceCwnd (tcb);
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (0.1/(81.855-(tcb->m_segmentSize)-(95.048)-(38.621)-(26.772)-(segmentsAcked)));
	tcb->m_segmentSize = (int) (0.382+(94.883)+(43.304)+(41.538)+(93.613));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (41.656/0.1);
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh <= segmentsAcked) {
	tcb->m_ssThresh = (int) (((15.661)+(92.161)+((42.469-(51.64)-(segmentsAcked)-(67.118)-(13.838)))+((86.71*(54.386)*(7.565)*(29.094)*(73.697)*(75.565)*(35.348)*(36.244)*(64.359)))+(0.1)+(50.146)+(60.926))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (43.521-(57.943)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(16.318)-(51.16));

}
segmentsAcked = (int) (98.381/22.341);
