float UnLqgPBJxexOIjRy = (float) (93.083-(54.792)-(-95.256)-(-13.325)-(-31.898)-(-61.113)-(-61.823));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (78.792-(22.364)-(64.52)-(66.043));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
