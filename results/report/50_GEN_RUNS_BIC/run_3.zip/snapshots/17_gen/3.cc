int ukVCPlKAGyjPfxOw = (int) (17.504-(-15.299)-(-47.634)-(-81.165)-(-79.56)-(-77.173)-(46.454));
tcb->m_cWnd = (int) (78.165*(22.598)*(-73.623));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-53.736*(55.047)*(17.997));
