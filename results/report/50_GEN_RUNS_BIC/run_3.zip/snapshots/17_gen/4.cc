int ukVCPlKAGyjPfxOw = (int) (70.428-(-97.217)-(-79.752)-(9.531)-(80.949)-(9.797)-(24.627));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (57.995*(-95.174)*(-24.221));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (63.457*(-99.01)*(-14.338));
tcb->m_cWnd = (int) (-13.589*(-12.859)*(-62.904));
