int ukVCPlKAGyjPfxOw = (int) (31.651-(-2.133)-(-71.098)-(-5.389)-(-1.723)-(81.313)-(25.874));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (21.61*(72.85)*(-14.453));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-87.593*(-78.817)*(-51.045));
