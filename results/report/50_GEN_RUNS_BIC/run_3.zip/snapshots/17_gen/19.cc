cnt = (int) (75.292*(74.184)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(segmentsAcked)*(35.197)*(15.23)*(66.507));
ReduceCwnd (tcb);
if (segmentsAcked < cnt) {
	tcb->m_segmentSize = (int) (96.211*(99.778)*(76.612)*(25.897)*(segmentsAcked)*(99.538)*(13.311)*(69.769)*(65.572));
	cnt = (int) (4.541*(94.509)*(50.406)*(87.015)*(76.674)*(78.767)*(30.313)*(67.434)*(25.421));

} else {
	tcb->m_segmentSize = (int) ((9.556*(35.568)*(97.437)*(55.151)*(84.769)*(84.594)*(57.158))/72.516);
	cnt = (int) (46.039-(segmentsAcked)-(11.074)-(59.1)-(9.595));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
