segmentsAcked = (int) (99.175-(91.942)-(6.643)-(53.978)-(4.294)-(19.197)-(53.287)-(57.237));
cnt = (int) (35.485-(tcb->m_segmentSize)-(54.793)-(34.555));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (73.535+(30.722)+(55.184)+(cnt));
if (tcb->m_ssThresh <= cnt) {
	tcb->m_cWnd = (int) (88.438*(25.927)*(tcb->m_ssThresh)*(33.483)*(47.128)*(72.969)*(38.332)*(57.446)*(35.693));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (0.1/49.51);
	cnt = (int) (97.901/0.1);

}
