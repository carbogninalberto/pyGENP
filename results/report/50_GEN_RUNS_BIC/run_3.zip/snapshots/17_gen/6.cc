int ukVCPlKAGyjPfxOw = (int) (-73.999-(-1.489)-(-89.43)-(5.827)-(88.948)-(-82.315)-(-20.898));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (70.792*(63.125)*(63.186));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-65.291*(58.742)*(73.034));
tcb->m_cWnd = (int) (-44.448*(46.69)*(-29.08));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-72.222*(10.684)*(64.146));
