float mdSosKaKppqgqvOI = (float) (57.876*(cnt)*(5.99)*(segmentsAcked)*(segmentsAcked)*(1.693)*(20.279));
if (tcb->m_ssThresh != mdSosKaKppqgqvOI) {
	cnt = (int) (15.657*(37.995)*(tcb->m_ssThresh)*(56.119)*(77.815)*(94.324)*(13.377)*(66.587)*(87.427));
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(23.82));
	mdSosKaKppqgqvOI = (float) (88.957-(segmentsAcked)-(37.101)-(58.041)-(56.4));

} else {
	cnt = (int) (48.514-(97.577)-(14.345)-(58.806)-(tcb->m_ssThresh)-(53.945));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (88.69-(71.969)-(91.839));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (60.426-(32.848)-(81.078)-(33.114)-(8.431)-(mdSosKaKppqgqvOI));
	mdSosKaKppqgqvOI = (float) (cnt-(11.698)-(42.213)-(tcb->m_ssThresh)-(56.673)-(34.994));

}
tcb->m_ssThresh = (int) (87.145+(27.921)+(51.281)+(97.591)+(tcb->m_ssThresh)+(76.831)+(96.118)+(88.641)+(47.14));
int YNygLoVKTuxipzsk = (int) (tcb->m_segmentSize+(11.414)+(93.509)+(71.26)+(81.417)+(34.16)+(84.525));
tcb->m_segmentSize = (int) (31.399*(86.351)*(92.631)*(70.341)*(48.136)*(86.911));
ReduceCwnd (tcb);
