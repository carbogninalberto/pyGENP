int ukVCPlKAGyjPfxOw = (int) (3.318-(29.995)-(-8.183)-(-19.418)-(-44.764)-(-75.529)-(75.79));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-85.955*(34.573)*(-61.746));
tcb->m_cWnd = (int) (99.559*(89.276)*(7.906));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-54.454*(60.613)*(-36.487));
