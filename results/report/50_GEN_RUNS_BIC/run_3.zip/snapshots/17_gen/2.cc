int ukVCPlKAGyjPfxOw = (int) (-7.395-(99.346)-(51.882)-(4.975)-(-47.672)-(70.929)-(70.503));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-87.727*(-65.675)*(71.453));
