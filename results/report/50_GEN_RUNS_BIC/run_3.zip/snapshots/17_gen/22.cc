if (tcb->m_ssThresh <= cnt) {
	tcb->m_segmentSize = (int) (41.416*(17.028)*(37.034)*(73.731)*(29.744)*(cnt));
	cnt = (int) (46.359+(37.019)+(70.79));

} else {
	tcb->m_segmentSize = (int) (65.421+(74.714)+(95.77)+(cnt)+(87.665)+(4.85)+(tcb->m_ssThresh)+(83.438));

}
float WqQzcMoZxwrJvjOl = (float) (60.702+(59.057)+(67.604)+(33.716)+(76.151)+(23.982)+(tcb->m_ssThresh)+(60.022));
if (segmentsAcked > segmentsAcked) {
	cnt = (int) (tcb->m_segmentSize+(86.672)+(40.308)+(79.631)+(93.388)+(78.433)+(WqQzcMoZxwrJvjOl));

} else {
	cnt = (int) (26.365+(WqQzcMoZxwrJvjOl)+(62.416)+(89.2)+(WqQzcMoZxwrJvjOl)+(46.772)+(tcb->m_segmentSize)+(95.902)+(56.216));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (14.684+(23.457)+(segmentsAcked)+(68.106)+(tcb->m_segmentSize)+(37.637)+(46.491)+(55.969)+(74.921));
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	segmentsAcked = (int) (6.647+(30.729)+(84.012));
	segmentsAcked = (int) (22.559*(90.164)*(32.866)*(29.677)*(90.352)*(22.115)*(66.448)*(29.898));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (87.214-(43.634));
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (tcb->m_ssThresh*(tcb->m_cWnd)*(tcb->m_ssThresh)*(82.936)*(tcb->m_ssThresh)*(58.178)*(89.656)*(20.895));
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (14.133*(22.91)*(tcb->m_cWnd)*(58.86)*(27.117));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (WqQzcMoZxwrJvjOl-(29.764)-(WqQzcMoZxwrJvjOl)-(29.478)-(6.338)-(segmentsAcked)-(61.917));

}
