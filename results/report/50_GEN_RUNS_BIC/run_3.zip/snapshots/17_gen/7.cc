if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
segmentsAcked = (int) (92.02-(18.841)-(46.556));
ReduceCwnd (tcb);
