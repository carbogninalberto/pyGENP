ReduceCwnd (tcb);
int ukVCPlKAGyjPfxOw = (int) (64.381-(-9.871)-(-10.046)-(-16.578)-(37.907)-(11.824)-(-92.575));
tcb->m_cWnd = (int) (-97.065*(69.052)*(68.982));
