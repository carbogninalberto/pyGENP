ReduceCwnd (tcb);
int kjWohnimIOkIVMsI = (int) (92.107/31.813);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float qErVlVSRVlpGdiAB = (float) (((0.1)+(0.1)+(0.1)+((55.809*(75.755)))+(0.1)+(92.304))/((7.097)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
