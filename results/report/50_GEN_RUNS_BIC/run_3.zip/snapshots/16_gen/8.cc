if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float rruKwnZUHBxXkgOy = (float) (92.132+(30.669)+(97.466)+(-73.387)+(20.648));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (19.219*(-38.258)*(23.157)*(34.594));
tcb->m_cWnd = (int) (7.277*(-74.433)*(98.187)*(11.029));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (39.533*(90.476)*(-84.31)*(92.945));
tcb->m_cWnd = (int) (-49.905*(59.982)*(-54.054)*(0.497));
