tcb->m_segmentSize = (int) (0.1/62.911);
tcb->m_segmentSize = (int) (44.566+(48.258)+(69.208)+(74.46)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(53.09)+(33.213)+(47.299));
tcb->m_ssThresh = (int) (58.413+(62.734)+(63.611)+(5.176)+(cnt));
tcb->m_cWnd = (int) (98.632+(34.126)+(38.944)+(45.952)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(84.544));
tcb->m_segmentSize = (int) ((74.655+(1.769))/74.12);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int zdajTRyHHnJXkcWK = (int) (74.982*(cnt)*(25.659)*(74.671)*(tcb->m_cWnd)*(38.801)*(27.302)*(17.362));
