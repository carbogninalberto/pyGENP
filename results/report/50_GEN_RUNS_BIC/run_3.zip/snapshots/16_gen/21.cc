tcb->m_cWnd = (int) (12.888+(63.519)+(33.011)+(tcb->m_ssThresh)+(50.2)+(22.63));
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (78.741*(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(30.733)*(91.892)*(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (48.939*(50.144)*(75.139)*(94.155)*(cnt)*(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(96.354)+(segmentsAcked)+(tcb->m_cWnd)+(51.187)+(segmentsAcked)+(tcb->m_segmentSize)+(28.708));
	tcb->m_cWnd = (int) (tcb->m_cWnd+(tcb->m_cWnd)+(93.654)+(10.581)+(9.074)+(cnt)+(61.704));
	tcb->m_ssThresh = (int) (0.1/0.1);

} else {
	tcb->m_ssThresh = (int) (segmentsAcked*(17.36)*(segmentsAcked)*(24.142)*(18.947)*(27.135)*(39.318)*(54.35));

}
segmentsAcked = (int) (47.144-(36.074)-(tcb->m_ssThresh));
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (57.326-(48.159)-(1.735));
	cnt = (int) (46.373+(74.748)+(tcb->m_segmentSize)+(60.56)+(36.841)+(tcb->m_cWnd)+(segmentsAcked));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (35.169+(4.895)+(86.411)+(59.493));
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(99.438));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (85.611*(35.912)*(segmentsAcked)*(28.888)*(42.044)*(6.598)*(98.735)*(69.225)*(19.5));
