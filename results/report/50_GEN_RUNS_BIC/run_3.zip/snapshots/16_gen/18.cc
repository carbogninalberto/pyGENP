tcb->m_cWnd = (int) (59.928*(18.882)*(15.685)*(1.653)*(92.934)*(53.129)*(15.099)*(62.888));
float GfQUlvXNxCunSywX = (float) (22.553*(77.487));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (34.122*(49.36)*(30.712)*(segmentsAcked)*(88.942)*(34.054));
GfQUlvXNxCunSywX = (float) (39.413*(82.98)*(26.016)*(77.479)*(97.396)*(39.332)*(tcb->m_segmentSize)*(41.356)*(10.101));
segmentsAcked = (int) (9.967*(3.56)*(17.104));
