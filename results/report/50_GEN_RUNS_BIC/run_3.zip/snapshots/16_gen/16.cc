if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (81.418*(27.112)*(48.212)*(70.884)*(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (82.492+(58.055)+(84.277)+(83.016)+(75.915)+(tcb->m_segmentSize)+(30.442)+(68.834));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt == segmentsAcked) {
	cnt = (int) (0.1/0.1);
	segmentsAcked = (int) (0.585-(0.709)-(92.723)-(5.232)-(2.137)-(tcb->m_cWnd)-(3.904));

} else {
	cnt = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (19.062*(45.098)*(cnt)*(58.844)*(37.249)*(tcb->m_ssThresh));

}
cnt = (int) (cnt+(66.118)+(86.439)+(5.39)+(tcb->m_ssThresh));
segmentsAcked = (int) (38.931-(tcb->m_segmentSize)-(segmentsAcked)-(73.37)-(46.861)-(98.14)-(83.688)-(tcb->m_ssThresh)-(13.743));
int WysoJqckQQyBWxPL = (int) (81.65*(segmentsAcked)*(78.852)*(42.248));
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (2.378*(77.689)*(tcb->m_ssThresh)*(31.597)*(8.06)*(6.318));
	segmentsAcked = (int) (83.788/0.1);
	tcb->m_cWnd = (int) (56.838*(40.071)*(36.973)*(4.166)*(69.956)*(22.527)*(94.931)*(79.267));

} else {
	tcb->m_segmentSize = (int) (WysoJqckQQyBWxPL-(12.318)-(61.573)-(74.119)-(cnt)-(46.174)-(16.737));

}
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	cnt = (int) (56.883+(42.85));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (cnt+(59.528)+(55.843));

} else {
	cnt = (int) (0.16*(59.055));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (28.308*(59.019)*(85.578)*(4.732));

}
