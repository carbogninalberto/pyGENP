int jEWqNfAOnSkkzNgR = (int) (35.601*(-60.361)*(-1.933)*(90.05)*(-44.214)*(-58.129)*(-32.757));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
