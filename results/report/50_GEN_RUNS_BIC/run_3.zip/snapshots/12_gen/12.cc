if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float rruKwnZUHBxXkgOy = (float) (8.836+(70.134)+(-7.06)+(-54.715)+(-7.023));
tcb->m_cWnd = (int) (-3.567*(1.242)*(12.287)*(79.651));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-35.32*(-73.697)*(-15.108)*(89.24));
