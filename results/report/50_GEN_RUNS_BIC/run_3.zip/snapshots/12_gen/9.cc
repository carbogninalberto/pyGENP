float HqSKmfDcRBBPpzsw = (float) (76.963/-35.059);
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_segmentSize = (int) (12.136*(-89.426)*(segmentsAcked));
	tcb->m_segmentSize = (int) (40.12+(38.75));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (-29.207+(85.017)+(25.89)+(13.219)+(62.498));

}
HqSKmfDcRBBPpzsw = (float) (-29.357-(-35.138)-(-48.214)-(71.662));
