float WxEhGFDAOzXArXwh = (float) (-42.716*(30.195));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (18.976-(-68.479)-(-51.782)-(-61.872)-(46.409)-(83.671));
