tcb->m_segmentSize = (int) (91.522+(42.35));
