ReduceCwnd (tcb);
int ukVCPlKAGyjPfxOw = (int) (-2.823-(35.204)-(34.874)-(-57.67)-(-74.441)-(93.665)-(-96.804));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-1.056*(-32.523)*(26.743));
tcb->m_cWnd = (int) (-50.951*(-10.536)*(-72.182));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
