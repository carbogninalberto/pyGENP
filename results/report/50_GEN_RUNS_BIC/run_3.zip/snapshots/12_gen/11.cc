float WxEhGFDAOzXArXwh = (float) (-0.794*(53.494));
ReduceCwnd (tcb);
