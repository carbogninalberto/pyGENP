int jEWqNfAOnSkkzNgR = (int) (-84.193*(-52.77)*(30.609)*(6.488)*(47.321)*(36.355)*(-72.225));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
