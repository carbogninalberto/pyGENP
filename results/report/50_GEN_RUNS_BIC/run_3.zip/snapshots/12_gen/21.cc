float HqSKmfDcRBBPpzsw = (float) (80.759/5.457);
ReduceCwnd (tcb);
if (tcb->m_cWnd == segmentsAcked) {
	tcb->m_segmentSize = (int) (12.136*(24.926)*(segmentsAcked));
	tcb->m_segmentSize = (int) (40.12+(38.75));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (-54.978+(85.017)+(25.89)+(13.219)+(62.498));

}
HqSKmfDcRBBPpzsw = (float) (-50.602-(-87.937)-(90.999)-(-25.787));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
