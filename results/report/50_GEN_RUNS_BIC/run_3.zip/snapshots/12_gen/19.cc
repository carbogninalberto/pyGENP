float WxEhGFDAOzXArXwh = (float) (47.142*(-73.814));
tcb->m_segmentSize = (int) (-63.247-(-21.035)-(-97.828)-(82.036)-(-6.127)-(-2.326));
