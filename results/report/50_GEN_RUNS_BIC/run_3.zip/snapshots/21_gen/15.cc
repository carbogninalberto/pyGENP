if (tcb->m_cWnd == tcb->m_segmentSize) {
	segmentsAcked = (int) (segmentsAcked+(tcb->m_cWnd)+(90.343)+(47.273)+(67.849));
	tcb->m_ssThresh = (int) (0.1/43.197);
	tcb->m_cWnd = (int) (((33.368)+(0.1)+(29.65)+(59.203)+(6.815))/((50.38)+(87.281)+(63.059)));

} else {
	segmentsAcked = (int) (((74.648)+(0.1)+(0.1)+(29.626))/((0.1)));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_cWnd = (int) (40.275/0.1);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (64.879+(36.935));
cnt = (int) (86.799/(5.772-(12.078)-(94.574)-(26.786)-(75.396)-(88.441)-(32.289)-(43.498)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
