if (cnt >= tcb->m_cWnd) {
	segmentsAcked = (int) (28.711+(cnt)+(segmentsAcked)+(96.463)+(30.731)+(31.757)+(91.362)+(60.874)+(68.289));
	cnt = (int) (43.406-(19.046));

} else {
	segmentsAcked = (int) (((71.11)+(62.032)+(0.1)+(78.51))/((0.1)+(79.666)));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (16.189-(40.122)-(77.219));
tcb->m_cWnd = (int) (6.414*(86.438)*(86.771)*(43.861)*(tcb->m_ssThresh));
