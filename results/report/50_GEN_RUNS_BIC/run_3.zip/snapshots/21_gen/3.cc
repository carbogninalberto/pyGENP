int rSWVTQpeDgPBZYDw = (int) (-91.792*(-47.985)*(79.664)*(-75.426)*(-43.206)*(-87.832)*(-60.362)*(7.145)*(-96.567));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
