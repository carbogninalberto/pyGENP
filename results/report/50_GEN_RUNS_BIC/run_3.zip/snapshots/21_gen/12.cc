segmentsAcked = (int) (9.482-(66.786)-(28.938));
float CkrHplBvDCaXmauj = (float) (27.18*(89.414));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (tcb->m_cWnd*(94.231));
segmentsAcked = (int) (0.1/(12.793*(3.325)*(8.103)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(40.067)*(tcb->m_segmentSize)*(7.765)));
