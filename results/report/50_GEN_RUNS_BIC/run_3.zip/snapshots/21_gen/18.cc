ReduceCwnd (tcb);
segmentsAcked = (int) (1.445*(16.225)*(75.347)*(63.58)*(73.9)*(71.205)*(tcb->m_cWnd)*(0.263));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (41.381/63.846);
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(46.561)+(27.812)+(94.96));
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (15.436+(39.122)+(73.432)+(27.479)+(61.341)+(tcb->m_ssThresh)+(54.061)+(41.672)+(14.238));

} else {
	tcb->m_ssThresh = (int) (74.405*(cnt)*(42.858)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(tcb->m_ssThresh)*(35.731)*(60.765));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (47.674*(33.583)*(82.271)*(52.991)*(76.87)*(9.244));

}
tcb->m_ssThresh = (int) (14.048-(tcb->m_ssThresh)-(38.243)-(segmentsAcked)-(61.355)-(45.471)-(82.528)-(72.399));
ReduceCwnd (tcb);
