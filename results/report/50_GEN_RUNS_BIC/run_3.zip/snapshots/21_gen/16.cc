ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (42.741*(30.943));
int VtgXzldofQrlmTUT = (int) (27.382-(63.816));
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= VtgXzldofQrlmTUT) {
	tcb->m_segmentSize = (int) (33.655+(80.21)+(segmentsAcked)+(63.396));
	segmentsAcked = (int) (-0.084*(24.632)*(58.06)*(VtgXzldofQrlmTUT)*(46.707)*(19.017)*(tcb->m_segmentSize)*(17.43));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (59.91-(70.225)-(tcb->m_segmentSize)-(5.606)-(cnt)-(26.989)-(segmentsAcked)-(65.705)-(53.61));

}
if (tcb->m_ssThresh >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (95.304-(62.943)-(67.351)-(30.128)-(6.004)-(95.96)-(3.839)-(tcb->m_segmentSize)-(19.846));

} else {
	tcb->m_ssThresh = (int) (81.921-(85.172)-(VtgXzldofQrlmTUT)-(34.363));

}
