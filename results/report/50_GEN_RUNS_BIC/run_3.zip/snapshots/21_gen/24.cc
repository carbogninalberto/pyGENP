if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (65.517*(23.766)*(24.452)*(66.38)*(63.203)*(tcb->m_segmentSize)*(35.593));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) ((24.571+(tcb->m_cWnd)+(85.227)+(86.63)+(94.754)+(32.043)+(5.515)+(75.678)+(78.369))/82.216);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_ssThresh) {
	cnt = (int) (50.119-(90.492)-(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (58.289-(tcb->m_ssThresh)-(tcb->m_cWnd)-(69.259)-(tcb->m_ssThresh));

} else {
	cnt = (int) (63.293*(22.528));
	cnt = (int) (((0.1)+(0.1)+(16.152)+(0.1))/((0.1)));

}
