int HZUHtrMdguDQxMXn = (int) (79.365*(29.272)*(-33.395)*(43.95)*(-2.87)*(17.376));
segmentsAcked = (int) (19.33*(-44.337)*(-45.961));
ReduceCwnd (tcb);
