int ukVCPlKAGyjPfxOw = (int) (-3.692-(-34.485)-(-73.691)-(-48.064)-(70.648)-(-93.055)-(32.937));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (7.328*(78.712)*(-31.559));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-14.971*(69.233)*(-63.934));
