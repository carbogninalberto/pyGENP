segmentsAcked = (int) (99.174+(25.996)+(46.557));
if (tcb->m_segmentSize > tcb->m_cWnd) {
	cnt = (int) (76.995-(segmentsAcked)-(72.113)-(tcb->m_cWnd)-(58.742)-(71.72)-(18.035));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (81.603-(78.481)-(87.235)-(tcb->m_ssThresh)-(29.063)-(segmentsAcked)-(61.688));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_ssThresh = (int) (22.448+(39.837)+(91.669)+(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (9.371+(42.321)+(50.625)+(69.426)+(83.897)+(82.026));

}
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(10.087)+(75.431)+(tcb->m_segmentSize)+(54.91));
	cnt = (int) (97.92*(41.686)*(tcb->m_segmentSize)*(cnt)*(75.053)*(47.204)*(8.135)*(tcb->m_cWnd)*(97.45));

} else {
	tcb->m_segmentSize = (int) (14.071-(62.486));
	tcb->m_ssThresh = (int) (75.433-(8.022));
	tcb->m_segmentSize = (int) (37.665+(39.136)+(65.281)+(tcb->m_cWnd));

}
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (79.226+(15.37)+(98.162)+(40.714)+(59.006));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (73.905/(9.146+(57.498)+(75.975)+(4.607)+(28.978)+(7.028)+(52.456)));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(55.124)*(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (segmentsAcked*(14.814)*(40.387)*(98.801));

}
