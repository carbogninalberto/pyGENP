tcb->m_ssThresh = (int) (0.1/44.273);
float lMZUgjRCqkIEXNzi = (float) (((0.1)+((74.175+(88.82)+(15.843)+(95.479)+(tcb->m_cWnd)+(97.109)+(cnt)+(28.111)))+((89.718+(29.354)+(71.044)))+(0.1)+(30.73))/((0.1)+(0.1)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt == tcb->m_segmentSize) {
	segmentsAcked = (int) (cnt-(tcb->m_segmentSize)-(30.4)-(42.738)-(46.24)-(16.286)-(14.309));
	tcb->m_cWnd = (int) (84.372*(75.676)*(5.447)*(tcb->m_ssThresh)*(3.602));

} else {
	segmentsAcked = (int) (27.324+(16.289)+(tcb->m_ssThresh)+(91.741)+(19.204)+(segmentsAcked)+(27.868)+(78.145));
	tcb->m_segmentSize = (int) (cnt+(42.189)+(82.986)+(47.831)+(2.049)+(72.454)+(67.547)+(tcb->m_ssThresh));

}
ReduceCwnd (tcb);
cnt = (int) (tcb->m_ssThresh-(tcb->m_cWnd)-(cnt)-(17.811)-(13.995)-(41.556));
if (tcb->m_ssThresh != cnt) {
	lMZUgjRCqkIEXNzi = (float) (((99.994)+(35.733)+(19.361)+(34.687))/((16.203)));
	tcb->m_ssThresh = (int) (16.583*(95.691)*(70.737));

} else {
	lMZUgjRCqkIEXNzi = (float) (67.912-(9.612)-(34.553)-(65.786));
	lMZUgjRCqkIEXNzi = (float) (tcb->m_cWnd*(51.864)*(45.438));
	tcb->m_cWnd = (int) (32.637-(85.717)-(36.775)-(lMZUgjRCqkIEXNzi)-(40.565)-(56.424)-(94.813)-(40.664)-(lMZUgjRCqkIEXNzi));

}
