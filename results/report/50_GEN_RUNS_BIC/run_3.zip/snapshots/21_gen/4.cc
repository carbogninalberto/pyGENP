float IlbjAYOpJXesSzJr = (float) (-83.503/84.516);
