float mjbdYvXDMwOMkAfv = (float) (85.041+(99.037)+(54.613)+(tcb->m_ssThresh)+(91.905));
segmentsAcked = (int) (0.1/0.1);
if (mjbdYvXDMwOMkAfv < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (5.459*(cnt)*(61.405)*(58.081)*(42.084)*(94.074));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (19.67+(mjbdYvXDMwOMkAfv));
	tcb->m_segmentSize = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_segmentSize = (int) (67.301/0.1);

} else {
	tcb->m_segmentSize = (int) (((68.842)+((51.638*(1.226)*(cnt)*(34.796)*(tcb->m_segmentSize)*(87.966)))+(0.1)+(13.121)+(0.1)+(93.681))/((76.118)+(0.1)+(82.885)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
