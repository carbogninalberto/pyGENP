tcb->m_cWnd = (int) ((58.946*(12.471)*(53.048)*(segmentsAcked)*(12.299)*(cnt))/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (cnt+(88.856)+(77.596)+(58.19)+(tcb->m_segmentSize)+(96.395)+(10.078));
tcb->m_segmentSize = (int) (tcb->m_cWnd-(81.676));
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_ssThresh = (int) (79.846*(tcb->m_cWnd)*(49.479)*(65.721)*(77.657));

} else {
	tcb->m_ssThresh = (int) (83.889*(47.127)*(1.687)*(67.743)*(12.249)*(tcb->m_cWnd)*(segmentsAcked)*(tcb->m_cWnd));
	segmentsAcked = (int) (tcb->m_segmentSize-(19.944)-(32.05)-(34.097)-(58.952)-(tcb->m_segmentSize)-(34.474)-(cnt)-(46.063));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (85.072-(84.231)-(85.674)-(89.556)-(17.615)-(89.582)-(tcb->m_cWnd)-(0.426)-(cnt));
