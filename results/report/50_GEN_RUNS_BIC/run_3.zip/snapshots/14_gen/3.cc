int ukVCPlKAGyjPfxOw = (int) (49.581-(-20.317)-(0.069)-(6.468)-(96.274)-(-74.866)-(-55.347));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-27.773*(4.196)*(-97.665));
