if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float rruKwnZUHBxXkgOy = (float) (17.513+(-76.484)+(-29.925)+(-31.394)+(-94.135));
tcb->m_cWnd = (int) (62.904*(-5.574)*(-62.993)*(81.059));
