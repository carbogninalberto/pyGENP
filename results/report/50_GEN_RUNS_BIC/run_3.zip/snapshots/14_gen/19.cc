tcb->m_cWnd = (int) (67.698*(4.829)*(57.485));
int ukVCPlKAGyjPfxOw = (int) (-0.475-(-0.687)-(75.054)-(38.804)-(99.246)-(97.27)-(9.793));
tcb->m_cWnd = (int) (40.241*(38.997)*(19.822));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (43.468*(-41.0)*(68.782));
tcb->m_cWnd = (int) (19.609*(-82.952)*(90.484));
