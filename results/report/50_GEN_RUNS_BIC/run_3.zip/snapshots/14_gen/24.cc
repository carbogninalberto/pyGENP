int ukVCPlKAGyjPfxOw = (int) (47.909-(-97.159)-(-30.159)-(-0.85)-(-3.097)-(-47.736)-(70.267));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (22.053*(-83.06)*(54.979));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (70.63*(49.944)*(67.045));
