if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float rruKwnZUHBxXkgOy = (float) (-56.111+(-97.473)+(-59.143)+(-63.046)+(-67.642));
tcb->m_cWnd = (int) (0.444*(88.125)*(-87.19)*(71.122));
tcb->m_cWnd = (int) (74.931*(36.399)*(73.498)*(62.145));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-26.865*(-58.328)*(21.744)*(51.501));
