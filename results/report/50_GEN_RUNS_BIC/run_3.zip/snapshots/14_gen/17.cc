if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float rruKwnZUHBxXkgOy = (float) (-27.051+(90.302)+(22.667)+(-87.186)+(34.514));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-23.703*(-20.744)*(-18.3)*(5.104));
tcb->m_cWnd = (int) (49.025*(-59.453)*(26.224)*(-83.16));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (42.519*(-61.964)*(80.632)*(-63.431));
tcb->m_cWnd = (int) (-27.348*(-90.971)*(-83.483)*(14.979));
