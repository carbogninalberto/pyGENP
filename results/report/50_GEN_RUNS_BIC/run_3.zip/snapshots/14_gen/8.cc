if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float rruKwnZUHBxXkgOy = (float) (-50.195+(-86.015)+(11.713)+(-50.75)+(78.852));
tcb->m_cWnd = (int) (-54.74*(81.862)*(-51.084)*(-22.064));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-56.113*(22.899)*(92.117)*(43.311));
