ReduceCwnd (tcb);
int ukVCPlKAGyjPfxOw = (int) (19.394-(96.08)-(91.0)-(61.216)-(82.612)-(49.681)-(-25.187));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (67.566*(55.617)*(-46.231));
