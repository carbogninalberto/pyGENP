float rruKwnZUHBxXkgOy = (float) (48.133+(-6.392)+(84.728)+(35.293)+(37.006));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (56.176*(-74.732)*(98.004)*(9.147));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (83.42*(33.043)*(-47.221)*(91.072));
tcb->m_cWnd = (int) (-57.2*(-34.936)*(93.85)*(-38.756));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-95.23*(-9.104)*(-50.782)*(-17.324));
