int ukVCPlKAGyjPfxOw = (int) (-16.945-(-17.446)-(-53.569)-(-1.466)-(-17.269)-(47.854)-(56.177));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (53.606*(95.09)*(-56.617));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (18.731*(-62.652)*(-74.619));
