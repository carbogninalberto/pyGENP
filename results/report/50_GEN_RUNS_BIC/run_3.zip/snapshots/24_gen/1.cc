if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (47.563-(-32.786));
tcb->m_cWnd = (int) (92.651*(44.664)*(-92.391)*(-63.052));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (75.164*(-64.591)*(53.82)*(13.907)*(87.732));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (39.676*(-66.358)*(94.063)*(-42.48));
tcb->m_cWnd = (int) (-45.201*(-60.082)*(-65.536)*(64.655)*(-29.332));
