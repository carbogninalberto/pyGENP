if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (70.968+(35.739));

} else {
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(91.821)+(60.173)+(62.364));

}
ReduceCwnd (tcb);
int VnFgnCsyrbowsSDz = (int) (85.47-(tcb->m_cWnd)-(97.898)-(32.473)-(84.028));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (tcb->m_cWnd-(24.958)-(67.228));
VnFgnCsyrbowsSDz = (int) (93.589-(77.939)-(cnt)-(83.001)-(tcb->m_cWnd)-(0.185)-(VnFgnCsyrbowsSDz)-(47.138));
