segmentsAcked = (int) (58.472*(tcb->m_segmentSize)*(16.168)*(96.752)*(45.269)*(66.334));
cnt = (int) (75.868-(38.137)-(93.351)-(67.489)-(tcb->m_ssThresh)-(segmentsAcked)-(33.089));
tcb->m_ssThresh = (int) (1.73-(segmentsAcked)-(63.309)-(17.034)-(85.815)-(14.304)-(94.556)-(cnt));
segmentsAcked = (int) (0.1/0.1);
ReduceCwnd (tcb);
