if (tcb->m_ssThresh <= tcb->m_cWnd) {
	cnt = (int) (72.477*(54.498)*(segmentsAcked)*(92.564)*(69.253)*(16.723));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	cnt = (int) (57.291*(49.225)*(69.088)*(54.577));

}
if (tcb->m_ssThresh >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (55.982*(segmentsAcked)*(68.598)*(49.092)*(80.532)*(cnt)*(tcb->m_segmentSize));
	tcb->m_ssThresh = (int) (6.136+(tcb->m_cWnd)+(segmentsAcked)+(14.129)+(69.841));

} else {
	tcb->m_cWnd = (int) (((0.1)+((tcb->m_cWnd*(tcb->m_cWnd)*(23.044)*(95.156)*(49.981)*(64.977)*(10.023)*(29.498)*(68.342)))+(51.584)+(16.009)+((99.178*(34.093)*(tcb->m_cWnd)*(33.041)*(cnt)))+(0.1))/((91.471)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(20.28)-(12.637)-(43.509)-(57.243));

} else {
	tcb->m_segmentSize = (int) (9.107*(24.075)*(40.154)*(56.051)*(17.377));
	cnt = (int) (99.351*(37.462)*(tcb->m_ssThresh)*(63.271)*(98.988)*(44.33)*(79.771)*(tcb->m_ssThresh));

}
