if (segmentsAcked <= segmentsAcked) {
	segmentsAcked = (int) (94.718+(93.889)+(tcb->m_ssThresh)+(9.41)+(tcb->m_segmentSize)+(77.741)+(tcb->m_ssThresh));

} else {
	segmentsAcked = (int) (48.341+(58.354)+(cnt)+(cnt)+(74.188));

}
int SKAqRzVLlFnVHVik = (int) (93.639*(72.801)*(10.348)*(49.089));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (98.597*(75.298));

} else {
	tcb->m_ssThresh = (int) (46.833+(29.518)+(96.92)+(39.066)+(8.886)+(9.367)+(50.546));
	SKAqRzVLlFnVHVik = (int) (85.002*(12.824)*(67.645)*(2.484)*(29.917)*(tcb->m_cWnd)*(9.568));
	segmentsAcked = (int) (tcb->m_ssThresh*(67.827)*(70.324)*(32.116)*(58.295)*(36.14));

}
if (SKAqRzVLlFnVHVik == cnt) {
	tcb->m_ssThresh = (int) (((61.746)+(26.709)+(0.1)+(0.1))/((58.601)+(0.1)));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) ((((8.208-(40.281)-(28.373)))+(96.295)+(78.085)+(82.684)+(0.1))/((30.459)+(32.928)+(93.217)+(19.229)));

} else {
	tcb->m_ssThresh = (int) (((73.388)+((47.445-(15.361)-(65.707)-(5.877)-(33.772)-(85.694)-(43.246)-(87.723)))+(0.1)+(22.977))/((0.1)+(92.018)+(0.1)+(0.1)+(0.1)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
SKAqRzVLlFnVHVik = (int) (76.048-(cnt)-(97.611)-(79.185)-(70.275));
if (SKAqRzVLlFnVHVik == SKAqRzVLlFnVHVik) {
	segmentsAcked = (int) ((((tcb->m_cWnd+(62.624)+(65.404)+(65.761)+(89.992)+(76.831)+(tcb->m_cWnd)+(57.815)))+(7.289)+(0.1)+(77.978))/((0.1)+(0.1)));

} else {
	segmentsAcked = (int) (tcb->m_cWnd-(52.762)-(tcb->m_ssThresh)-(66.187)-(78.587)-(81.435));
	tcb->m_ssThresh = (int) (0.265*(89.067)*(15.145)*(36.976));
	tcb->m_cWnd = (int) (SKAqRzVLlFnVHVik+(77.086)+(96.077)+(72.961)+(39.695)+(87.748)+(92.299)+(49.266));

}
if (segmentsAcked < SKAqRzVLlFnVHVik) {
	cnt = (int) (((81.958)+(17.639)+(36.503)+((14.089+(71.886)+(segmentsAcked)+(36.24)+(60.752)+(89.387)+(21.257)+(4.852)+(13.77)))+(0.1))/((34.028)+(0.1)+(79.315)+(0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	cnt = (int) (21.467/0.1);
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (27.05+(cnt)+(49.466)+(cnt)+(9.608)+(15.568)+(tcb->m_cWnd)+(SKAqRzVLlFnVHVik));

}
