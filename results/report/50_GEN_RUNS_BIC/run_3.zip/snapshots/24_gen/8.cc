tcb->m_cWnd = (int) (((96.483)+(-50.19)+(-55.406)+(41.773))/((-31.231)+(-9.626)+(-66.303)+(89.945)+(47.632)));
int plwLUDrEodcqTnaE = (int) (-74.829-(-96.615)-(-78.785)-(-38.442));
tcb->m_cWnd = (int) (-1.43*(-12.647));
tcb->m_segmentSize = (int) (-8.729*(60.959));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (30.818-(18.558)-(segmentsAcked)-(34.074)-(96.906)-(43.587));

} else {
	tcb->m_segmentSize = (int) (47.905+(7.425)+(53.609)+(33.195)+(26.608)+(32.706)+(7.045)+(46.069)+(83.421));

}
tcb->m_cWnd = (int) (4.48*(-4.035));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (46.381*(97.367));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (47.905+(7.425)+(-43.749)+(33.195)+(26.608)+(32.706)+(7.045)+(46.069)+(83.421));

} else {
	tcb->m_segmentSize = (int) (30.818-(18.558)-(segmentsAcked)-(34.074)-(96.906)-(43.587));

}
ReduceCwnd (tcb);
