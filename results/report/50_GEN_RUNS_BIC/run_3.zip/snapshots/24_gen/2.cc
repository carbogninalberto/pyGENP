float omhHQYwcUcPOTMql = (float) (-81.03-(28.585)-(56.332)-(10.332)-(24.531)-(-52.254)-(34.916));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
