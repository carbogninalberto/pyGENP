tcb->m_cWnd = (int) (-44.001-(63.115)-(-13.811)-(-95.261)-(-76.753)-(-68.953)-(36.065)-(-31.611)-(14.114));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
