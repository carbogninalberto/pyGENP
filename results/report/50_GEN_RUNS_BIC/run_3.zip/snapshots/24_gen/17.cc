ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= cnt) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(tcb->m_ssThresh)*(96.609)*(cnt));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);

}
if (tcb->m_ssThresh <= tcb->m_cWnd) {
	cnt = (int) (0.845-(segmentsAcked)-(95.915)-(23.776)-(53.47)-(77.576)-(61.069)-(73.106)-(37.306));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (5.443+(cnt)+(cnt)+(47.689)+(19.345)+(cnt)+(75.593)+(59.399));
	tcb->m_segmentSize = (int) (23.934+(93.617)+(tcb->m_cWnd)+(26.028)+(61.734)+(68.315)+(46.507));
	tcb->m_segmentSize = (int) (64.867-(35.974)-(cnt)-(segmentsAcked)-(7.426)-(cnt)-(55.439)-(22.871)-(38.774));

}
tcb->m_ssThresh = (int) (32.865+(11.113)+(segmentsAcked)+(22.354)+(99.286)+(13.345)+(cnt)+(56.036));
