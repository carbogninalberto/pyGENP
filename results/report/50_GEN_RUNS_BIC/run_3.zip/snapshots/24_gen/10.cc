float IxAWxVeYfTvYHQOk = (float) (20.875+(-48.294)+(-30.059)+(80.591)+(94.063));
int ZfXKqkXbzDvxJyIx = (int) 72.712;
int NFpnsyzUmEjaYMui = (int) 15.984;
