tcb->m_segmentSize = (int) (-76.861-(-3.943)-(24.685)-(-52.957));
int VCGhfQVTmYtClprx = (int) (71.755+(-39.073)+(-7.17)+(2.653)+(-56.904)+(42.872)+(36.618)+(-94.305)+(36.444));
tcb->m_cWnd = (int) (-83.235*(-58.842));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (51.284-(84.968)-(1.047)-(-24.453)-(32.196)-(-53.852));
