int pMRBowqjtCqlMgwM = (int) (((24.871)+(82.176)+(42.314)+(44.408)+(33.509)+(36.968)+((13.683*(95.847)*(66.516)*(9.472)*(84.967)*(49.13)*(32.655)*(60.503)))+(34.265))/((33.22)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked >= segmentsAcked) {
	cnt = (int) (4.305-(cnt)-(tcb->m_ssThresh)-(53.549));

} else {
	cnt = (int) (0.1/44.885);

}
pMRBowqjtCqlMgwM = (int) (35.569-(56.167)-(46.503));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (11.212*(5.822)*(56.402)*(tcb->m_ssThresh)*(42.404));
	tcb->m_cWnd = (int) (8.245+(tcb->m_ssThresh)+(59.625)+(99.266)+(44.137));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd*(58.885)*(21.738)*(tcb->m_segmentSize)*(98.133)*(21.903));
	tcb->m_ssThresh = (int) (0.1/95.883);
	cnt = (int) (35.854+(tcb->m_ssThresh));

}
