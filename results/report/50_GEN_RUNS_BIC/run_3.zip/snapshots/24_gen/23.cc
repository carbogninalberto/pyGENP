if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt <= cnt) {
	segmentsAcked = (int) (92.307-(28.176)-(84.789)-(73.168)-(18.23)-(50.832));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(24.905)*(49.142)*(segmentsAcked)*(96.329)*(9.39)*(88.169)*(33.519)*(61.189));

} else {
	segmentsAcked = (int) (93.379-(94.65)-(19.635));
	segmentsAcked = (int) (7.716*(86.53)*(96.5)*(segmentsAcked)*(52.158)*(segmentsAcked)*(cnt)*(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (87.174*(74.697)*(19.547)*(65.034)*(78.973)*(41.514)*(tcb->m_cWnd)*(39.174));

}
if (segmentsAcked != segmentsAcked) {
	segmentsAcked = (int) (50.749+(tcb->m_cWnd)+(95.411)+(71.509)+(segmentsAcked)+(63.666));

} else {
	segmentsAcked = (int) ((tcb->m_segmentSize*(cnt)*(tcb->m_cWnd)*(72.266)*(45.614)*(69.965)*(22.679)*(73.844))/38.788);
	segmentsAcked = (int) (((0.1)+(67.224)+(0.1)+(0.1)+(93.029)+(0.1))/((7.392)+(36.246)));
	tcb->m_cWnd = (int) (92.442*(tcb->m_cWnd)*(95.512)*(tcb->m_segmentSize)*(27.125));

}
tcb->m_segmentSize = (int) (10.173+(73.625));
segmentsAcked = (int) (tcb->m_segmentSize-(1.695)-(93.492)-(18.329)-(56.143)-(28.978)-(8.016)-(77.962)-(39.22));
tcb->m_segmentSize = (int) (45.245/0.1);
ReduceCwnd (tcb);
