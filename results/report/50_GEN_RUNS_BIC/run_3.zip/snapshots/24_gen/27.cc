if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_segmentSize = (int) (48.662+(tcb->m_segmentSize)+(4.017)+(92.753)+(71.39)+(17.621)+(7.849)+(99.815)+(56.251));

} else {
	tcb->m_segmentSize = (int) (33.474/0.1);

}
int kzLppnQuOrQmWilN = (int) (20.561-(44.933)-(79.573)-(7.162)-(52.781));
segmentsAcked = (int) (22.578*(49.902)*(55.332)*(tcb->m_cWnd)*(tcb->m_cWnd)*(kzLppnQuOrQmWilN));
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (kzLppnQuOrQmWilN-(segmentsAcked)-(64.999)-(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (41.469+(40.679)+(4.712)+(90.084)+(65.41)+(37.294));

} else {
	tcb->m_segmentSize = (int) (27.516+(81.876)+(74.93)+(segmentsAcked)+(57.901)+(16.523)+(tcb->m_cWnd));
	segmentsAcked = (int) (78.812*(42.748)*(53.565)*(51.174)*(segmentsAcked)*(16.09)*(segmentsAcked));
	cnt = (int) (61.613*(31.201));

}
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((77.434)+(18.384)+((83.939*(32.686)*(84.465)*(27.126)*(58.918)))+(0.1)+(0.1)+(67.385)+(96.637))/((84.009)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (90.517+(42.216)+(38.63)+(73.067)+(52.557)+(28.591)+(86.775)+(14.749));

}
tcb->m_ssThresh = (int) (8.852-(78.02)-(93.769)-(97.739)-(25.05)-(28.523)-(86.096)-(48.239));
ReduceCwnd (tcb);
