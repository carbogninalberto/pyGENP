if (tcb->m_segmentSize > cnt) {
	segmentsAcked = (int) (5.297*(tcb->m_segmentSize)*(88.941));
	tcb->m_segmentSize = (int) (60.106+(81.491)+(cnt)+(63.121)+(22.734)+(74.233)+(37.773)+(45.385)+(33.073));

} else {
	segmentsAcked = (int) (51.2+(60.256)+(39.844)+(98.736)+(13.093)+(segmentsAcked)+(97.978));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (0.1/0.1);
if (tcb->m_cWnd < cnt) {
	tcb->m_ssThresh = (int) (2.942/93.568);
	tcb->m_cWnd = (int) (96.497-(86.855)-(63.663)-(15.372));

} else {
	tcb->m_ssThresh = (int) (81.143*(21.424)*(6.394)*(72.566)*(95.387));

}
if (cnt <= segmentsAcked) {
	tcb->m_cWnd = (int) (25.647+(61.026));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (44.991*(segmentsAcked));
	tcb->m_cWnd = (int) (segmentsAcked+(10.161)+(45.672)+(49.179)+(32.253)+(65.211));

}
tcb->m_cWnd = (int) (36.638-(17.652)-(76.256)-(26.052));
ReduceCwnd (tcb);
