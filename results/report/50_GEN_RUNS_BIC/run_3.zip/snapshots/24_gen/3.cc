if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (94.279-(2.989)-(18.656)-(19.513)-(49.678));
	segmentsAcked = (int) (25.772*(33.879)*(85.328));

} else {
	tcb->m_segmentSize = (int) (53.203+(87.333)+(tcb->m_segmentSize)+(95.574)+(6.562)+(89.041)+(11.517)+(32.451));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_cWnd = (int) ((((-43.605-(98.445)-(48.693)-(-51.754)-(89.874)-(-2.926)-(24.144)-(10.578)))+(-42.768)+(8.805)+(32.335))/((6.574)));
