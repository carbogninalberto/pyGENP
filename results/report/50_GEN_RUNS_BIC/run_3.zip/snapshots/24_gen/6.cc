int ZfXKqkXbzDvxJyIx = (int) (((51.474)+(-75.482)+(77.749)+(-58.791))/((-6.305)));
float IxAWxVeYfTvYHQOk = (float) (-18.669+(32.751)+(10.153)+(39.35)+(-21.669));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
