int VFWxpgZNxFPQhLIc = (int) (72.154*(4.812)*(segmentsAcked)*(segmentsAcked));
ReduceCwnd (tcb);
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (63.141*(26.259)*(96.738)*(46.443)*(72.627)*(76.992));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (95.695*(31.398)*(6.269)*(53.618)*(VFWxpgZNxFPQhLIc));

}
if (tcb->m_cWnd <= segmentsAcked) {
	cnt = (int) (35.172*(10.298)*(26.914)*(78.179)*(60.572)*(83.87));
	tcb->m_segmentSize = (int) (63.753*(55.281)*(64.779));
	segmentsAcked = (int) (tcb->m_cWnd-(78.916)-(18.207)-(cnt)-(VFWxpgZNxFPQhLIc));

} else {
	cnt = (int) (0.61+(21.537)+(16.992)+(84.748));

}
VFWxpgZNxFPQhLIc = (int) (cnt*(12.99)*(4.908));
tcb->m_ssThresh = (int) (39.132-(59.426));
segmentsAcked = (int) (52.698/51.132);
