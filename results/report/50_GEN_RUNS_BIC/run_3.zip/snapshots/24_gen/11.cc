segmentsAcked = (int) (80.715+(-22.468)+(-14.786)+(-25.773));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
