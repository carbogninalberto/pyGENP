float rbFGnhTUTWhZJuHd = (float) (((30.869)+((85.803*(65.481)*(1.682)*(49.426)*(42.35)))+((72.673-(37.899)-(94.34)-(2.787)-(34.124)-(tcb->m_segmentSize)-(61.618)-(82.794)))+(0.1)+(52.659))/((72.423)));
tcb->m_ssThresh = (int) (78.112+(segmentsAcked)+(35.649)+(98.089));
ReduceCwnd (tcb);
rbFGnhTUTWhZJuHd = (float) (92.363+(tcb->m_cWnd)+(77.346)+(rbFGnhTUTWhZJuHd)+(tcb->m_segmentSize)+(73.807)+(57.02)+(85.78));
ReduceCwnd (tcb);
