ReduceCwnd (tcb);
segmentsAcked = (int) (10.618-(segmentsAcked)-(19.442)-(47.03)-(48.753));
int WMTTqBlLvAVOoUva = (int) (73.569*(25.73)*(78.028)*(15.563)*(63.513)*(65.46)*(94.109)*(tcb->m_ssThresh)*(48.242));
tcb->m_ssThresh = (int) (32.342*(WMTTqBlLvAVOoUva)*(7.19)*(73.105));
tcb->m_cWnd = (int) (((37.632)+(75.613)+(0.1)+(16.973)+(0.1)+(16.772)+(41.853))/((17.612)));
ReduceCwnd (tcb);
