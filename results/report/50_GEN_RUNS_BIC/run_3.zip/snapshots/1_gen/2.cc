ReduceCwnd (tcb);
if (tcb->m_ssThresh >= segmentsAcked) {
	tcb->m_segmentSize = (int) (48.098+(67.557)+(28.288)+(36.887)+(48.773)+(49.178));
	tcb->m_segmentSize = (int) (51.404*(54.374)*(7.141)*(segmentsAcked)*(11.603)*(65.851)*(tcb->m_ssThresh)*(91.86)*(87.225));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (98.23*(14.347)*(21.598));
	tcb->m_segmentSize = (int) (46.348+(42.977)+(65.586)+(53.956)+(26.068)+(25.385)+(73.252));

}
int dnKpNqDlCmMetHnr = (int) (87.726+(74.543));
segmentsAcked = (int) (35.597+(16.241)+(16.761)+(28.846)+(56.336)+(94.513)+(82.22));
segmentsAcked = (int) (5.664+(60.257)+(75.957)+(62.674));
