ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (68.529*(33.621)*(93.466)*(32.527)*(91.168)*(12.716)*(cnt)*(55.286));
if (tcb->m_cWnd == cnt) {
	tcb->m_segmentSize = (int) (4.795/2.039);
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(21.35)*(20.014)*(77.514)*(2.9)*(63.592)*(33.408)*(tcb->m_segmentSize));
	cnt = (int) (tcb->m_cWnd-(24.282)-(tcb->m_segmentSize)-(57.79)-(97.882)-(84.427)-(45.787)-(62.096));
	cnt = (int) (segmentsAcked*(65.899)*(11.595));

}
if (cnt >= segmentsAcked) {
	cnt = (int) (82.18*(37.203)*(-0.049)*(82.604));
	tcb->m_ssThresh = (int) (61.669*(47.945)*(34.137)*(37.233)*(46.402)*(15.757)*(52.868)*(74.192));

} else {
	cnt = (int) (80.595+(38.956)+(10.021)+(45.32)+(81.872)+(49.14)+(22.632)+(3.143)+(92.112));
	segmentsAcked = (int) (17.326-(7.252));
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (29.327-(tcb->m_cWnd)-(35.739)-(97.764)-(25.449)-(27.377)-(tcb->m_ssThresh));
if (segmentsAcked == cnt) {
	tcb->m_segmentSize = (int) (88.177*(cnt)*(78.722)*(93.19)*(44.112)*(53.963)*(31.323)*(75.619));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (43.843/45.518);

} else {
	tcb->m_segmentSize = (int) (41.943*(26.399)*(77.787)*(7.185)*(7.711));
	tcb->m_segmentSize = (int) (35.873*(54.626)*(98.047)*(48.524)*(61.32)*(6.749)*(38.8)*(tcb->m_cWnd)*(43.296));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
float xUBTUjGpwaUOSROs = (float) (53.816*(13.151)*(segmentsAcked)*(23.301)*(74.975)*(31.766)*(49.427)*(tcb->m_ssThresh));
if (xUBTUjGpwaUOSROs > cnt) {
	tcb->m_ssThresh = (int) (49.358*(76.934)*(xUBTUjGpwaUOSROs)*(18.676)*(segmentsAcked));
	tcb->m_cWnd = (int) (51.297+(xUBTUjGpwaUOSROs)+(53.951)+(6.147)+(10.127));
	segmentsAcked = (int) (53.382+(46.132)+(12.097)+(86.615));

} else {
	tcb->m_ssThresh = (int) (75.113+(86.848)+(95.282)+(90.791)+(tcb->m_segmentSize)+(67.077)+(33.025)+(cnt));
	tcb->m_ssThresh = (int) (49.194*(34.226)*(72.661)*(19.496)*(19.262)*(81.842)*(55.085)*(12.615)*(54.948));
	tcb->m_ssThresh = (int) ((30.719*(tcb->m_cWnd)*(8.017)*(81.563)*(tcb->m_segmentSize)*(10.413)*(15.809))/0.1);

}
ReduceCwnd (tcb);
