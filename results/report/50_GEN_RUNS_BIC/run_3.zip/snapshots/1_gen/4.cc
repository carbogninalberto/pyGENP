float agrpywZsexVrZkNf = (float) (92.055/67.718);
tcb->m_segmentSize = (int) (64.461/0.1);
tcb->m_ssThresh = (int) (cnt-(55.442));
if (tcb->m_ssThresh != agrpywZsexVrZkNf) {
	tcb->m_segmentSize = (int) (62.893+(8.666));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (91.585-(99.069)-(12.758)-(0.508)-(86.393));

}
int oAkFDJuZXICPRunz = (int) (2.306+(75.398)+(segmentsAcked)+(23.75)+(45.244)+(8.621)+(90.017));
tcb->m_segmentSize = (int) (30.353+(62.183)+(tcb->m_cWnd)+(87.401)+(19.958)+(34.79)+(agrpywZsexVrZkNf)+(80.579)+(54.671));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	segmentsAcked = (int) (36.317+(tcb->m_ssThresh)+(segmentsAcked)+(63.93)+(26.564)+(92.387));
	cnt = (int) (45.792*(0.962)*(80.009)*(45.742)*(34.665));

} else {
	segmentsAcked = (int) (0.1/0.1);

}
int RXPgNofwlntNYtjE = (int) (81.638-(tcb->m_segmentSize)-(3.839)-(40.422)-(66.046)-(17.962)-(88.603));
RXPgNofwlntNYtjE = (int) (52.308/84.012);
