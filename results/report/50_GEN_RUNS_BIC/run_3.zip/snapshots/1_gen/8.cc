tcb->m_segmentSize = (int) (78.85/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt != segmentsAcked) {
	segmentsAcked = (int) (23.196-(38.121)-(47.133));

} else {
	segmentsAcked = (int) (tcb->m_cWnd-(1.496)-(92.856)-(37.99)-(78.089)-(tcb->m_segmentSize)-(52.874));

}
tcb->m_segmentSize = (int) (0.1/44.403);
float hghjRLmPZydXCnqr = (float) (0.1/0.1);
