segmentsAcked = (int) (30.82*(80.562)*(tcb->m_segmentSize)*(cnt)*(tcb->m_ssThresh)*(53.934)*(40.724)*(23.382)*(24.796));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd != tcb->m_ssThresh) {
	cnt = (int) (57.154-(tcb->m_segmentSize)-(41.231));
	tcb->m_segmentSize = (int) (16.346-(15.075)-(71.207));

} else {
	cnt = (int) (65.387/0.1);

}
tcb->m_segmentSize = (int) (36.603/(73.64-(11.563)));
