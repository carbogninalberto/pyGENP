tcb->m_cWnd = (int) (68.949+(4.791)+(73.51)+(tcb->m_ssThresh)+(57.473)+(36.302));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (32.16*(cnt)*(tcb->m_ssThresh)*(96.297));
tcb->m_segmentSize = (int) ((((9.729*(30.173)*(61.903)*(segmentsAcked)*(segmentsAcked)*(56.019)*(31.833)*(5.37)*(83.064)))+(0.1)+(97.81)+(43.641)+(16.4)+(0.1))/((71.493)));
if (tcb->m_ssThresh > cnt) {
	cnt = (int) (62.824-(62.511)-(98.223)-(1.388)-(98.295)-(9.766));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (21.336+(79.279)+(tcb->m_segmentSize)+(53.611)+(31.901)+(55.493)+(tcb->m_cWnd));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd == segmentsAcked) {
	cnt = (int) (cnt*(tcb->m_cWnd)*(67.269)*(segmentsAcked)*(92.423)*(88.184)*(64.169)*(30.228)*(70.329));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (55.474*(tcb->m_ssThresh));

} else {
	cnt = (int) (10.049-(cnt)-(tcb->m_segmentSize));
	segmentsAcked = (int) (72.189+(61.54)+(89.128)+(14.313)+(44.972)+(89.903)+(69.195));

}
if (segmentsAcked != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh+(2.891)+(81.526));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (cnt-(tcb->m_cWnd)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(segmentsAcked)-(62.038)-(32.538));
	tcb->m_ssThresh = (int) ((((tcb->m_segmentSize*(8.962)*(39.663)*(42.609)*(84.639)*(77.413)))+((cnt+(segmentsAcked)))+(0.1)+(28.165))/((26.163)));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
