float smRgusGtrZdcebHK = (float) (((0.1)+(0.1)+((cnt*(tcb->m_ssThresh)))+(47.652)+(91.211))/((8.442)+(60.567)+(0.1)));
ReduceCwnd (tcb);
cnt = (int) ((84.242-(62.875))/91.67);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	cnt = (int) (76.962*(63.883)*(smRgusGtrZdcebHK));

} else {
	cnt = (int) (88.953+(tcb->m_ssThresh)+(37.998)+(74.943)+(segmentsAcked)+(98.495)+(2.525)+(tcb->m_ssThresh));

}
tcb->m_segmentSize = (int) (74.302-(11.559)-(94.478));
int lrAMKUKHYVRNyxWU = (int) (96.273-(41.614)-(20.992)-(31.598)-(tcb->m_cWnd));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
