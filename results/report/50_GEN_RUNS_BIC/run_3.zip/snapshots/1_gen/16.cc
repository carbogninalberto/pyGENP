cnt = (int) (90.076-(1.102)-(8.308)-(tcb->m_segmentSize)-(51.843)-(tcb->m_ssThresh)-(21.329)-(73.22)-(82.496));
segmentsAcked = (int) (5.98*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(34.423));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (51.924/30.287);

} else {
	tcb->m_segmentSize = (int) (71.745+(17.453)+(77.484)+(73.307)+(32.841)+(53.007)+(29.07)+(75.191)+(84.427));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (12.723*(80.299)*(75.133)*(tcb->m_ssThresh));
	tcb->m_segmentSize = (int) (11.617*(cnt)*(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (13.925*(2.161)*(51.785)*(41.596));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
