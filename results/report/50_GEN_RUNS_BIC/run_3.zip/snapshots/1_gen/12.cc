if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (83.967*(52.247)*(12.545)*(tcb->m_ssThresh));
	segmentsAcked = (int) (77.902-(96.231)-(12.345)-(91.849));
	tcb->m_cWnd = (int) (98.3*(12.082)*(segmentsAcked)*(58.836)*(16.654)*(60.475)*(72.409)*(38.56)*(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (((71.332)+(0.1)+((1.808-(9.161)-(23.932)-(tcb->m_ssThresh)-(88.824)))+(74.75)+(9.349))/((19.639)));
	segmentsAcked = (int) (82.191*(5.42)*(68.472)*(37.123)*(tcb->m_segmentSize)*(74.559)*(20.628)*(tcb->m_segmentSize)*(2.535));
	cnt = (int) (39.219-(40.385)-(49.903)-(33.031)-(63.845)-(89.765)-(tcb->m_ssThresh)-(cnt)-(36.267));

}
segmentsAcked = (int) (((39.757)+(0.1)+(0.1)+(0.1))/((0.1)));
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_segmentSize-(84.265));
if (segmentsAcked != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((55.505)+((88.173-(cnt)-(7.932)-(40.132)-(88.231)-(28.063)))+(0.1)+(92.753))/((25.862)+(66.141)+(0.1)+(0.1)+(1.896)));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(segmentsAcked)*(23.097)*(53.511)*(66.371)*(35.928)*(70.44)*(14.203));
	tcb->m_cWnd = (int) (segmentsAcked+(tcb->m_segmentSize)+(11.63));

} else {
	tcb->m_segmentSize = (int) (86.468*(90.374)*(segmentsAcked)*(79.782));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (45.761-(89.931)-(74.887));
	cnt = (int) (((51.794)+(43.351)+(0.1)+((41.035*(81.553)*(90.858)*(39.492)*(41.014)*(tcb->m_ssThresh)*(59.109)))+(65.299))/((34.333)+(81.297)+(2.44)+(13.146)));

} else {
	tcb->m_ssThresh = (int) (51.223+(69.147)+(68.096)+(2.671));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (82.25+(30.968)+(32.362));

}
if (tcb->m_cWnd == tcb->m_ssThresh) {
	cnt = (int) (52.536+(30.451)+(67.392));

} else {
	cnt = (int) (cnt+(86.917)+(92.733)+(17.617)+(76.98)+(49.93)+(44.961));

}
if (tcb->m_ssThresh >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (44.738+(67.701)+(35.869)+(0.972)+(23.86)+(8.93));
	segmentsAcked = (int) (12.99*(segmentsAcked)*(77.17)*(33.966)*(70.913)*(92.504)*(tcb->m_cWnd));
	cnt = (int) (((0.1)+((63.725+(79.993)+(77.455)+(tcb->m_cWnd)+(3.516)))+((79.681+(77.584)+(7.084)))+(0.1))/((0.1)));

} else {
	tcb->m_ssThresh = (int) (19.233+(73.38)+(1.679)+(63.534)+(68.056)+(80.622)+(segmentsAcked));
	tcb->m_ssThresh = (int) (47.499*(90.827)*(81.045)*(95.29)*(27.433)*(56.271)*(77.367)*(segmentsAcked)*(tcb->m_cWnd));
	tcb->m_cWnd = (int) (4.237+(77.892)+(99.574)+(29.862)+(27.678)+(92.942)+(tcb->m_cWnd)+(95.333)+(75.707));

}
