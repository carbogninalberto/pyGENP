if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh != cnt) {
	tcb->m_ssThresh = (int) (29.86-(55.34));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (16.63-(tcb->m_cWnd)-(tcb->m_cWnd)-(57.983)-(70.453)-(3.848)-(20.528));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (39.973*(38.394)*(13.525)*(tcb->m_segmentSize)*(23.073)*(9.401));

}
if (cnt == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (93.789+(29.297)+(83.607)+(62.057)+(4.471)+(tcb->m_ssThresh)+(42.421)+(69.025)+(0.688));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (27.798-(55.668)-(91.177)-(82.218)-(cnt)-(84.377)-(77.213)-(tcb->m_ssThresh)-(83.452));

} else {
	tcb->m_segmentSize = (int) (0.1/39.698);
	tcb->m_segmentSize = (int) (21.655-(35.841)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(99.417));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
