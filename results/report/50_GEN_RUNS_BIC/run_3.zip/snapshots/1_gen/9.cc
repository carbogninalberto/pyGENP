ReduceCwnd (tcb);
tcb->m_cWnd = (int) (28.766+(39.827)+(72.189)+(16.496)+(66.783)+(27.967)+(86.173)+(85.408));
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (5.32*(15.906)*(segmentsAcked)*(82.729)*(54.555));
	cnt = (int) (1.467*(49.933)*(tcb->m_ssThresh)*(62.893)*(39.544)*(97.714));

} else {
	tcb->m_segmentSize = (int) (19.357*(7.983));
	cnt = (int) (((0.1)+(62.153)+((13.692-(tcb->m_cWnd)))+((tcb->m_cWnd*(75.133)))+(0.1)+(76.906))/((7.763)+(0.1)));
	tcb->m_ssThresh = (int) (15.521+(48.422)+(98.779));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
