ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh == segmentsAcked) {
	tcb->m_segmentSize = (int) (segmentsAcked+(8.799)+(53.587)+(17.811)+(59.641));

} else {
	tcb->m_segmentSize = (int) (87.221/87.106);
	segmentsAcked = (int) (4.757-(28.762)-(74.28)-(14.654)-(80.399)-(36.582));

}
ReduceCwnd (tcb);
if (cnt > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (((0.1)+(99.052)+(80.93)+(0.1))/((0.1)+(0.1)+(0.1)));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (((0.1)+(30.711)+(26.703)+(87.86)+((tcb->m_cWnd-(tcb->m_cWnd)))+(68.582)+(0.1))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (24.338-(segmentsAcked));
	segmentsAcked = (int) (46.242+(69.3)+(53.606)+(tcb->m_ssThresh));
	ReduceCwnd (tcb);

}
if (segmentsAcked == tcb->m_cWnd) {
	cnt = (int) (9.685*(tcb->m_segmentSize)*(28.881)*(segmentsAcked)*(55.096)*(7.464));
	tcb->m_segmentSize = (int) (78.81*(57.174)*(57.488)*(tcb->m_ssThresh)*(0.114)*(39.673)*(82.737));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (58.067*(segmentsAcked)*(tcb->m_ssThresh)*(segmentsAcked)*(11.014)*(36.276)*(49.49));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
