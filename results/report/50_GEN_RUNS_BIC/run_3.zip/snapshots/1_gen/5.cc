tcb->m_segmentSize = (int) (((0.1)+(77.851)+(0.1)+(9.504)+(2.199))/((0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
segmentsAcked = (int) (95.269+(segmentsAcked)+(86.734)+(18.264)+(99.909)+(45.434)+(cnt)+(89.226));
