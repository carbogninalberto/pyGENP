ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (((56.146)+(37.918)+(0.1)+(6.199))/((6.6)+(53.441)+(0.1)));
tcb->m_ssThresh = (int) (30.908-(97.701)-(25.82));
tcb->m_ssThresh = (int) (segmentsAcked-(20.657)-(3.291)-(54.293)-(20.373));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
