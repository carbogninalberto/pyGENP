if (tcb->m_cWnd <= cnt) {
	tcb->m_segmentSize = (int) (24.945+(68.582)+(3.871)+(12.161)+(67.993));
	cnt = (int) (77.696/(tcb->m_cWnd+(46.473)+(cnt)+(76.0)+(93.085)+(35.608)+(66.355)+(36.848)+(segmentsAcked)));

} else {
	tcb->m_segmentSize = (int) (1.725-(31.609)-(52.142)-(13.682)-(51.03)-(2.905)-(22.903)-(54.777)-(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (43.242/78.516);
	tcb->m_segmentSize = (int) (((85.148)+(0.1)+(0.1)+(0.1)+(0.1)+(12.181))/((63.856)+(0.1)));

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (42.687*(62.412)*(62.678)*(13.748)*(tcb->m_ssThresh)*(55.622));
segmentsAcked = (int) (73.971-(32.737)-(34.378));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < cnt) {
	tcb->m_ssThresh = (int) (84.37+(35.72)+(27.398)+(segmentsAcked)+(60.306));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (99.447+(74.713)+(23.06)+(tcb->m_ssThresh)+(39.271)+(31.974)+(16.345));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
