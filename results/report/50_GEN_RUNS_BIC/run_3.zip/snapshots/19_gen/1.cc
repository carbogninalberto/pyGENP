int ukVCPlKAGyjPfxOw = (int) (18.374-(93.379)-(-5.966)-(62.211)-(-90.987)-(93.337)-(3.114));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-6.68*(-3.65)*(77.498));
tcb->m_cWnd = (int) (35.099*(20.052)*(11.83));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (78.482*(13.119)*(-84.722));
