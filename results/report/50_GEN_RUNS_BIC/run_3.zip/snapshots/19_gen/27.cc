ReduceCwnd (tcb);
ReduceCwnd (tcb);
float iVNlhLGtXcMFZtcd = (float) (50.427*(78.019));
ReduceCwnd (tcb);
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	iVNlhLGtXcMFZtcd = (float) (82.576+(tcb->m_segmentSize)+(50.03)+(segmentsAcked)+(segmentsAcked)+(74.199)+(78.044));
	cnt = (int) (tcb->m_ssThresh*(cnt)*(segmentsAcked)*(segmentsAcked)*(iVNlhLGtXcMFZtcd)*(67.981));
	tcb->m_ssThresh = (int) (27.409*(65.478)*(21.962)*(99.014)*(61.482));

} else {
	iVNlhLGtXcMFZtcd = (float) (87.803*(43.139)*(85.246)*(92.766)*(41.335)*(tcb->m_cWnd)*(56.643));

}
tcb->m_ssThresh = (int) (67.373-(95.029)-(iVNlhLGtXcMFZtcd)-(82.927)-(30.331)-(55.089)-(95.891)-(cnt)-(10.016));
tcb->m_ssThresh = (int) (22.756*(29.62));
