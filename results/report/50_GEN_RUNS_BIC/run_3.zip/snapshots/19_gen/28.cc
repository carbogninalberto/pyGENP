ReduceCwnd (tcb);
int rVQGwvORSEASLmAS = (int) (30.166*(89.094)*(79.676));
segmentsAcked = (int) ((50.972-(45.244)-(68.184))/58.439);
ReduceCwnd (tcb);
if (cnt == cnt) {
	segmentsAcked = (int) (64.441*(47.569)*(40.23)*(23.81)*(4.763));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(11.688)*(14.764)*(tcb->m_ssThresh)*(97.215)*(20.533)*(12.317));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (83.36+(tcb->m_segmentSize)+(tcb->m_ssThresh)+(segmentsAcked)+(tcb->m_segmentSize)+(9.659)+(rVQGwvORSEASLmAS)+(54.662));
	segmentsAcked = (int) (53.907+(38.505));

}
