float HQbMiULMqBTvCKzB = (float) (segmentsAcked+(48.421));
if (HQbMiULMqBTvCKzB >= segmentsAcked) {
	tcb->m_ssThresh = (int) (50.669-(20.494)-(65.178)-(42.859)-(92.497)-(7.715)-(cnt)-(13.351));
	segmentsAcked = (int) (tcb->m_cWnd*(24.953));
	tcb->m_ssThresh = (int) (95.93+(35.203)+(1.646)+(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (74.864-(12.395)-(64.104)-(32.462)-(25.614)-(85.961)-(91.69));
	tcb->m_segmentSize = (int) (35.135+(10.439));
	ReduceCwnd (tcb);

}
segmentsAcked = (int) (28.806-(5.59)-(2.486)-(segmentsAcked)-(96.346)-(57.917)-(cnt));
cnt = (int) (20.9-(0.934)-(63.617)-(82.799)-(70.559)-(48.51));
ReduceCwnd (tcb);
cnt = (int) (((48.492)+(0.1)+(2.58)+(38.556))/((22.134)+(69.824)));
tcb->m_ssThresh = (int) (95.009*(56.721)*(tcb->m_ssThresh)*(69.212)*(HQbMiULMqBTvCKzB)*(1.837)*(46.379)*(tcb->m_ssThresh));
if (HQbMiULMqBTvCKzB == cnt) {
	HQbMiULMqBTvCKzB = (float) (30.774*(61.123)*(63.509)*(61.245)*(37.403)*(43.802));

} else {
	HQbMiULMqBTvCKzB = (float) (38.454+(50.158)+(HQbMiULMqBTvCKzB)+(49.091));
	HQbMiULMqBTvCKzB = (float) (segmentsAcked+(51.265)+(segmentsAcked)+(54.254)+(50.85)+(73.492)+(HQbMiULMqBTvCKzB));

}
