if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float qcCvcjXTkqpDOEbf = (float) (57.214*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(41.115)*(11.22)*(81.703)*(22.879)*(93.517));
if (tcb->m_ssThresh == qcCvcjXTkqpDOEbf) {
	segmentsAcked = (int) (29.036*(60.599)*(45.545)*(1.847));

} else {
	segmentsAcked = (int) (32.744+(72.174)+(44.79)+(segmentsAcked)+(5.022));

}
if (tcb->m_segmentSize < cnt) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(23.488)-(68.784)-(9.657)-(83.836)-(73.229));
	qcCvcjXTkqpDOEbf = (float) (44.97/0.1);

} else {
	tcb->m_cWnd = (int) (85.732-(tcb->m_cWnd)-(tcb->m_cWnd)-(63.585)-(39.936));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
