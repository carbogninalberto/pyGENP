float aYPMQsPefcNuGnZu = (float) 76.572;
