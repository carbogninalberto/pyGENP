tcb->m_segmentSize = (int) (39.222*(-37.575)*(-60.036)*(89.521)*(77.997));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
