int ukVCPlKAGyjPfxOw = (int) (56.315-(-21.716)-(-5.989)-(80.967)-(-18.355)-(-64.881)-(-27.737));
tcb->m_cWnd = (int) (-31.114*(19.42)*(-1.846));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-90.545*(31.056)*(-20.949));
