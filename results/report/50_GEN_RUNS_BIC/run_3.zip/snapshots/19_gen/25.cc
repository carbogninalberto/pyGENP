ReduceCwnd (tcb);
int TUCTiOuZtikWWgLb = (int) (96.111/96.597);
ReduceCwnd (tcb);
float cXoNgGQVbYarJLZw = (float) (0.1/28.67);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
