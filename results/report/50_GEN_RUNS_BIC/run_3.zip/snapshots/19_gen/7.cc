int KDaNipAnjzCEPNMA = (int) (-0.927*(-19.585));
tcb->m_segmentSize = (int) (51.936*(29.579)*(82.945)*(-92.52)*(87.702));
segmentsAcked = (int) ((tcb->m_segmentSize-(-13.959)-(1.963)-(-67.683)-(-5.705)-(76.966))/78.472);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
