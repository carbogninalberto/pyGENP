float xNFGIBQTsfHGbwwk = (float) (-91.099-(-5.612)-(-91.268));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (48.959*(-98.666)*(50.624)*(33.912));
tcb->m_cWnd = (int) (-62.894*(47.801)*(-37.388)*(-64.78)*(56.972));
