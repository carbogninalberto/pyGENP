ReduceCwnd (tcb);
int ukVCPlKAGyjPfxOw = (int) (42.995-(75.395)-(-83.932)-(70.664)-(-85.587)-(19.82)-(-90.052));
tcb->m_cWnd = (int) (-91.797*(-71.457)*(24.948));
