tcb->m_segmentSize = (int) (8.714-(19.525)-(65.213)-(83.441)-(63.783));
if (tcb->m_cWnd < cnt) {
	cnt = (int) (91.225-(tcb->m_cWnd)-(89.441)-(20.355)-(84.994)-(segmentsAcked)-(22.92));
	tcb->m_ssThresh = (int) (58.217-(43.635)-(46.898)-(15.095)-(38.048));

} else {
	cnt = (int) (20.582-(96.801));
	tcb->m_cWnd = (int) (((22.286)+(66.523)+(58.606)+((39.296+(17.697)+(cnt)+(segmentsAcked)+(22.106)+(2.951)+(89.382)+(14.416)))+(4.882))/((14.859)));
	segmentsAcked = (int) (87.527/55.968);

}
cnt = (int) (70.345+(segmentsAcked)+(90.992)+(94.46)+(15.979)+(20.394)+(segmentsAcked)+(27.998)+(73.104));
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (85.924+(27.093)+(0.462)+(73.196)+(16.487)+(88.914)+(93.56)+(tcb->m_ssThresh)+(4.765));

} else {
	tcb->m_ssThresh = (int) (((9.722)+(0.1)+(17.21)+(0.1))/((0.1)+(0.1)+(33.804)+(0.1)+(0.1)));
	tcb->m_ssThresh = (int) (segmentsAcked+(segmentsAcked)+(50.582)+(tcb->m_cWnd)+(tcb->m_cWnd)+(14.857));
	ReduceCwnd (tcb);

}
cnt = (int) (0.1/0.1);
