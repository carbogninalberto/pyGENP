if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (33.675*(cnt)*(42.889));

} else {
	tcb->m_segmentSize = (int) (24.626*(71.34)*(53.618)*(48.523)*(tcb->m_ssThresh)*(72.45)*(10.726)*(90.153)*(61.313));

}
cnt = (int) (segmentsAcked*(52.665)*(20.15)*(4.249)*(65.413)*(segmentsAcked)*(75.173)*(77.396)*(tcb->m_segmentSize));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (88.358+(67.482)+(8.896)+(12.239)+(80.953)+(52.619)+(90.198));
