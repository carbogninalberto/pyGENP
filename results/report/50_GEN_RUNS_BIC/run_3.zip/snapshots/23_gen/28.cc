float CPvflnArLEXPMCtD = (float) (((0.1)+((tcb->m_ssThresh+(29.778)+(32.549)+(8.802)+(90.338)+(64.656)+(29.288)+(43.091)))+(0.1)+(0.1))/((80.658)+(0.1)));
if (tcb->m_ssThresh > tcb->m_cWnd) {
	segmentsAcked = (int) (9.271+(96.994)+(tcb->m_ssThresh)+(20.724)+(tcb->m_ssThresh)+(CPvflnArLEXPMCtD));
	CPvflnArLEXPMCtD = (float) (34.002+(20.0)+(17.557)+(84.286)+(49.647)+(72.028)+(CPvflnArLEXPMCtD)+(65.564)+(52.804));

} else {
	segmentsAcked = (int) (0.1/71.749);

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (cnt+(45.709));
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (65.386+(76.869)+(79.366)+(96.644)+(41.46)+(76.432)+(35.408));

} else {
	tcb->m_ssThresh = (int) (32.414*(39.778)*(25.673)*(CPvflnArLEXPMCtD)*(6.451)*(64.268));
	tcb->m_ssThresh = (int) (CPvflnArLEXPMCtD*(60.607)*(93.209)*(0.754)*(81.972)*(tcb->m_cWnd)*(4.663)*(1.046)*(92.691));

}
cnt = (int) (45.44+(53.906)+(CPvflnArLEXPMCtD)+(62.432)+(13.905)+(5.161)+(47.325));
segmentsAcked = (int) (3.607+(22.404)+(segmentsAcked)+(tcb->m_cWnd)+(77.817)+(cnt)+(cnt));
