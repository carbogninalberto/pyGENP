int NFpnsyzUmEjaYMui = (int) (-71.533-(-95.758)-(60.667)-(-33.905)-(37.07));
float IxAWxVeYfTvYHQOk = (float) (-51.001+(-17.963)+(-5.482)+(64.002)+(-29.086));
int ZfXKqkXbzDvxJyIx = (int) (((13.319)+(-55.355)+(7.007)+(-35.821))/((-97.858)));
