cnt = (int) (32.963*(17.691)*(6.107)*(76.313));
tcb->m_segmentSize = (int) (cnt-(5.132)-(33.212)-(9.246));
if (cnt >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(38.136)*(99.913)*(13.809)*(49.251)*(cnt)*(45.558));
	segmentsAcked = (int) (68.963*(37.042)*(31.116)*(83.231)*(62.614)*(tcb->m_cWnd)*(tcb->m_segmentSize)*(9.285)*(44.761));

} else {
	tcb->m_ssThresh = (int) ((20.351+(66.268)+(81.506)+(19.411)+(cnt)+(46.18)+(67.11)+(44.902)+(tcb->m_segmentSize))/0.1);
	tcb->m_ssThresh = (int) (32.863+(24.622)+(segmentsAcked));

}
tcb->m_cWnd = (int) (15.884*(cnt));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (97.967-(75.522)-(6.062)-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(tcb->m_segmentSize));
if (segmentsAcked <= cnt) {
	cnt = (int) (76.679-(31.019)-(34.295)-(71.955)-(33.608)-(66.055)-(tcb->m_segmentSize)-(91.243));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (26.401/0.1);

}
