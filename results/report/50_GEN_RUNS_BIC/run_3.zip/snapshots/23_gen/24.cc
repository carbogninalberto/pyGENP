if (cnt < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (81.576+(segmentsAcked)+(52.593)+(cnt)+(51.893)+(cnt)+(56.907)+(96.881));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (94.635-(45.234)-(27.245)-(81.619)-(75.902)-(cnt));

} else {
	tcb->m_ssThresh = (int) (cnt+(53.723)+(79.202)+(15.183)+(tcb->m_segmentSize)+(66.486)+(72.932));

}
if (tcb->m_cWnd == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (55.316*(3.87)*(51.504)*(87.368)*(64.491));
	segmentsAcked = (int) (cnt+(cnt)+(61.883)+(99.182)+(segmentsAcked)+(98.575)+(16.407)+(tcb->m_segmentSize)+(44.476));
	tcb->m_segmentSize = (int) (segmentsAcked-(87.779)-(58.729)-(39.953));

} else {
	tcb->m_segmentSize = (int) (64.985+(tcb->m_cWnd)+(tcb->m_cWnd)+(24.343)+(35.304)+(55.236)+(52.225)+(79.845)+(85.106));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (59.689/69.637);
cnt = (int) (cnt-(cnt)-(segmentsAcked)-(55.672));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
