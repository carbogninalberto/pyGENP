int knACnMhvuQYdsItd = (int) (65.441-(74.419)-(24.599));
float aFoBhOszxZgMDUZZ = (float) (24.836+(43.729));
if (tcb->m_segmentSize == cnt) {
	tcb->m_segmentSize = (int) (((0.1)+((tcb->m_ssThresh+(31.609)+(27.878)+(21.566)))+(0.1)+(0.1)+(0.1))/((14.803)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (40.714*(48.717)*(80.931)*(86.723)*(33.982)*(27.579)*(93.113));

}
aFoBhOszxZgMDUZZ = (float) (27.102-(74.686)-(90.719)-(26.395)-(9.117));
if (cnt > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (58.832*(84.619)*(62.086)*(cnt)*(77.758)*(0.432));
	tcb->m_ssThresh = (int) (((0.1)+(0.1)+(36.982)+(0.1))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (cnt+(85.401)+(45.135)+(aFoBhOszxZgMDUZZ)+(cnt)+(25.142));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	knACnMhvuQYdsItd = (int) (((26.083)+(20.451)+(0.1)+(0.1))/((0.1)+(0.1)+(6.041)+(0.1)+(22.287)));

}
segmentsAcked = (int) (13.48+(82.606)+(79.653)+(39.523)+(28.318)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(4.011)+(28.744));
if (aFoBhOszxZgMDUZZ < tcb->m_segmentSize) {
	knACnMhvuQYdsItd = (int) (knACnMhvuQYdsItd*(98.933)*(segmentsAcked)*(86.187)*(47.716)*(70.628)*(40.993));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	knACnMhvuQYdsItd = (int) (0.1/0.1);

}
tcb->m_ssThresh = (int) (37.105*(68.196)*(28.395)*(91.737)*(74.537)*(91.334)*(cnt)*(17.518)*(81.384));
if (aFoBhOszxZgMDUZZ < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (60.039-(47.038)-(42.383));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (68.201*(49.632)*(96.212)*(34.528)*(16.429)*(aFoBhOszxZgMDUZZ));
	knACnMhvuQYdsItd = (int) (99.468*(6.24)*(87.448)*(53.261)*(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
