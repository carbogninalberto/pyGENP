if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize == tcb->m_cWnd) {
	cnt = (int) (tcb->m_cWnd*(16.837)*(4.858)*(segmentsAcked)*(62.171)*(91.3));
	cnt = (int) (41.516+(86.837)+(4.236)+(9.07));

} else {
	cnt = (int) ((((55.226*(tcb->m_segmentSize)*(cnt)*(21.178)*(tcb->m_segmentSize)*(63.47)*(45.972)))+(59.811)+((72.21*(53.858)*(76.074)*(26.327)*(46.501)*(67.19)*(segmentsAcked)))+(86.617)+(24.728)+(49.735))/((0.1)+(3.456)+(10.705)));

}
if (cnt >= segmentsAcked) {
	segmentsAcked = (int) (28.983*(46.534)*(13.119)*(tcb->m_cWnd)*(9.388)*(42.479));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (0.1/65.127);
	tcb->m_segmentSize = (int) (28.822*(89.755)*(cnt)*(10.064)*(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (57.956+(tcb->m_ssThresh)+(59.446)+(51.426)+(91.144));

}
if (tcb->m_ssThresh <= cnt) {
	segmentsAcked = (int) (72.6/0.1);
	cnt = (int) (71.557/0.1);

} else {
	segmentsAcked = (int) (39.921*(60.014));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
