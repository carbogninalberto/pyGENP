int NFpnsyzUmEjaYMui = (int) (-46.039-(-43.388)-(-16.439)-(-92.373)-(-40.601));
float IxAWxVeYfTvYHQOk = (float) (33.68+(-64.486)+(-53.247)+(15.654)+(35.368));
int ZfXKqkXbzDvxJyIx = (int) (((91.356)+(72.648)+(98.391)+(4.704))/((7.47)));
tcb->m_segmentSize = (int) (-29.815+(-29.249));
