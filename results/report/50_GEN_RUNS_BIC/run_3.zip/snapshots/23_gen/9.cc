float dwAamSXkxfNBUZaa = (float) ((71.36-(58.873)-(29.818))/-72.091);
int RXBvpcbDMHcrFVoD = (int) (23.354*(7.917)*(-22.625)*(71.86)*(-46.672)*(37.164)*(-60.392));
ReduceCwnd (tcb);
segmentsAcked = (int) (40.525-(82.499)-(-82.075)-(31.803)-(38.184));
ReduceCwnd (tcb);
segmentsAcked = (int) ((97.866+(79.08)+(85.198)+(-58.256))/-49.707);
ReduceCwnd (tcb);
