tcb->m_segmentSize = (int) (((-59.383)+(-26.582)+(3.334)+(7.936)+(-50.948)+(55.486))/((38.904)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (62.832-(-64.188)-(-57.697));
