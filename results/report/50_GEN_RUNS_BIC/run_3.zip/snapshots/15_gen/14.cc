int ukVCPlKAGyjPfxOw = (int) (-13.206-(68.963)-(-30.648)-(93.02)-(-31.343)-(-4.905)-(23.608));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (29.749*(76.981)*(97.306));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-5.6*(57.549)*(24.335));
