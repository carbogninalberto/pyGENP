int ukVCPlKAGyjPfxOw = (int) (42.458-(54.979)-(-2.707)-(46.747)-(-7.65)-(98.919)-(-84.361));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (12.083*(67.962)*(-6.782));
