int ukVCPlKAGyjPfxOw = (int) (-27.025-(44.859)-(-70.004)-(-18.99)-(95.128)-(-58.396)-(48.851));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-55.691*(47.996)*(64.816));
