int ukVCPlKAGyjPfxOw = (int) (77.962-(-55.314)-(-61.05)-(25.499)-(26.813)-(66.594)-(61.653));
tcb->m_cWnd = (int) (43.827*(98.243)*(-36.747));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-76.631*(40.6)*(-94.821));
