int ukVCPlKAGyjPfxOw = (int) (-84.046-(-94.675)-(76.815)-(-8.936)-(-94.299)-(-40.52)-(20.168));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (64.137*(49.346)*(21.951));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-37.809*(-28.16)*(25.911));
tcb->m_cWnd = (int) (57.364*(-73.406)*(22.299));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (33.563*(12.244)*(23.992));
