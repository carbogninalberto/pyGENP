int ukVCPlKAGyjPfxOw = (int) (95.594-(80.728)-(-93.299)-(82.443)-(68.976)-(78.472)-(97.793));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (83.5*(91.114)*(-26.097));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-73.971*(44.648)*(-41.719));
