float rruKwnZUHBxXkgOy = (float) (-82.942+(-51.606)+(-33.834)+(1.35)+(25.947));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-77.172*(-65.137)*(59.805)*(-73.706));
tcb->m_cWnd = (int) (96.545*(-47.513)*(-89.249)*(-85.003));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (51.313*(31.623)*(62.077)*(61.677));
