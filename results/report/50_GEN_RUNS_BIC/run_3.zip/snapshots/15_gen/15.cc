int ukVCPlKAGyjPfxOw = (int) (81.206-(-52.706)-(28.702)-(-36.07)-(-58.498)-(16.232)-(45.22));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (34.872*(10.041)*(19.72));
tcb->m_cWnd = (int) (-9.526*(-70.986)*(76.493));
tcb->m_cWnd = (int) (94.823*(33.022)*(-15.738));
tcb->m_cWnd = (int) (-15.836*(48.451)*(-74.029));
