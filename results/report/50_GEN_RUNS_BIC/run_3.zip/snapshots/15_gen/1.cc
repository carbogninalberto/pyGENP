ReduceCwnd (tcb);
int ukVCPlKAGyjPfxOw = (int) (-87.476-(95.376)-(4.99)-(14.727)-(9.906)-(-38.443)-(60.909));
tcb->m_cWnd = (int) (-42.059*(-7.779)*(80.888));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (64.152*(-4.675)*(-19.247));
