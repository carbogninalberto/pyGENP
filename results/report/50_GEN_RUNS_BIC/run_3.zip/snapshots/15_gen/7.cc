float rruKwnZUHBxXkgOy = (float) (11.284+(-23.181)+(41.104)+(69.166)+(63.252));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-17.321*(-56.739)*(-60.536)*(63.528));
