float rruKwnZUHBxXkgOy = (float) (94.984+(-67.819)+(49.233)+(75.758)+(-9.08));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (83.998*(54.433)*(23.419)*(-45.214));
tcb->m_cWnd = (int) (-9.961*(-9.257)*(10.509)*(-28.446));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-81.998*(-17.265)*(92.452)*(-88.156));
tcb->m_cWnd = (int) (-9.659*(-28.377)*(39.884)*(75.986));
