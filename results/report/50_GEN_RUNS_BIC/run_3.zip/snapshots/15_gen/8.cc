float rruKwnZUHBxXkgOy = (float) (75.611+(-58.814)+(65.101)+(-76.561)+(-82.347));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-52.283*(-68.258)*(44.894)*(-47.939));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (30.126*(-38.132)*(69.558)*(-21.802));
