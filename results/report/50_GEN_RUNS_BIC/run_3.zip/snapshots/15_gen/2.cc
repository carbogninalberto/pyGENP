int ukVCPlKAGyjPfxOw = (int) (-77.821-(94.153)-(78.339)-(94.492)-(38.216)-(6.353)-(-87.947));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (86.524*(82.536)*(35.907));
