int ukVCPlKAGyjPfxOw = (int) (46.002-(2.448)-(95.958)-(-98.17)-(-1.161)-(94.683)-(-70.283));
tcb->m_cWnd = (int) (-16.531*(81.51)*(-75.582));
tcb->m_cWnd = (int) (97.009*(98.459)*(6.828));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (1.562*(-72.487)*(33.159));
tcb->m_cWnd = (int) (-36.941*(-29.733)*(-43.983));
