ReduceCwnd (tcb);
int uEyTLIsHiwjufHZA = (int) (24.074-(segmentsAcked)-(tcb->m_segmentSize)-(49.974)-(63.893)-(73.194));
segmentsAcked = (int) (17.447-(tcb->m_ssThresh)-(uEyTLIsHiwjufHZA)-(13.9)-(83.107));
cnt = (int) (90.07/7.944);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < uEyTLIsHiwjufHZA) {
	cnt = (int) (99.808-(30.589)-(segmentsAcked)-(65.797)-(33.956)-(93.389)-(2.603));

} else {
	cnt = (int) (cnt*(70.418)*(cnt)*(2.995)*(24.603)*(86.941)*(15.776)*(67.435)*(5.291));

}
uEyTLIsHiwjufHZA = (int) ((uEyTLIsHiwjufHZA+(76.022)+(93.526)+(26.704))/0.1);
