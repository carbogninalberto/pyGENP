ReduceCwnd (tcb);
if (segmentsAcked == segmentsAcked) {
	tcb->m_segmentSize = (int) (36.938+(83.619));
	tcb->m_cWnd = (int) (44.736*(tcb->m_ssThresh)*(cnt));
	tcb->m_ssThresh = (int) (53.179-(33.759)-(segmentsAcked)-(segmentsAcked)-(75.468));

} else {
	tcb->m_segmentSize = (int) (35.223-(45.493)-(99.596)-(tcb->m_ssThresh)-(89.078)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(65.197));
	segmentsAcked = (int) (tcb->m_ssThresh+(62.272));
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(27.728)*(24.038)*(96.64)*(44.994)*(30.522)*(tcb->m_cWnd)*(53.686)*(24.974));

}
if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (90.874*(53.104)*(92.005)*(99.437)*(25.395)*(3.797)*(55.017)*(58.183)*(86.944));
	tcb->m_cWnd = (int) (43.669-(38.595)-(tcb->m_cWnd)-(82.42)-(79.944)-(15.129));
	tcb->m_ssThresh = (int) (88.794-(36.296)-(39.638));

} else {
	segmentsAcked = (int) (91.115*(70.594)*(69.638)*(81.55)*(75.472)*(segmentsAcked));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_segmentSize = (int) (((35.802)+(28.195)+(0.1)+(0.1)+(0.1))/((0.1)+(0.1)));
	cnt = (int) (45.637-(segmentsAcked)-(88.668)-(81.165)-(tcb->m_segmentSize)-(57.564)-(82.328)-(16.356)-(0.442));

} else {
	tcb->m_segmentSize = (int) (95.659*(92.85));

}
tcb->m_cWnd = (int) (94.43-(51.895)-(4.826)-(93.422)-(58.384)-(71.73)-(cnt)-(34.841)-(17.95));
tcb->m_ssThresh = (int) (45.712+(92.372)+(1.18)+(segmentsAcked)+(23.427));
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	cnt = (int) (53.91+(91.717)+(segmentsAcked)+(15.421));

} else {
	cnt = (int) (99.514*(29.14)*(tcb->m_ssThresh)*(37.594)*(31.63));
	cnt = (int) (47.08+(4.922)+(40.814));

}
