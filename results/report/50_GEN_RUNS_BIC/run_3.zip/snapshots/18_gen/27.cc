if (cnt < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((0.1)+(49.49)+(4.647)+(62.89))/((0.1)));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (9.881/0.1);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (86.357*(68.951)*(19.246)*(55.999)*(78.581)*(tcb->m_cWnd));
float ovVNIvMHmmzRUSKM = (float) (75.373-(39.11)-(93.867)-(3.015)-(tcb->m_segmentSize));
if (ovVNIvMHmmzRUSKM != segmentsAcked) {
	tcb->m_ssThresh = (int) (83.843-(28.614)-(96.691)-(tcb->m_segmentSize)-(42.644)-(42.926)-(7.057)-(75.168)-(49.881));

} else {
	tcb->m_ssThresh = (int) (1.465*(27.996));

}
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (72.067+(segmentsAcked)+(54.618)+(88.427)+(22.983));
	segmentsAcked = (int) (73.685/0.1);

} else {
	tcb->m_ssThresh = (int) (cnt-(ovVNIvMHmmzRUSKM)-(31.331)-(96.925));
	tcb->m_ssThresh = (int) (cnt+(5.597)+(tcb->m_segmentSize)+(47.042)+(3.242)+(3.142)+(92.159)+(71.893)+(24.572));

}
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	ovVNIvMHmmzRUSKM = (float) (0.1/50.379);

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);

}
