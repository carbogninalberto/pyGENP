int tMEYgpETHISNdwQD = (int) (-32.228+(20.541)+(4.777)+(-77.381)+(-77.857)+(76.35)+(68.326));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (7.004+(48.461));
