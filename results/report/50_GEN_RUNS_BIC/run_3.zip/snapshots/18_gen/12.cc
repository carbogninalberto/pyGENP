float mdSosKaKppqgqvOI = (float) 91.345;
