int ukVCPlKAGyjPfxOw = (int) (-36.935-(61.299)-(-23.855)-(-35.478)-(27.74)-(12.397)-(-24.081));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (57.404*(86.501)*(94.805));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (40.414*(-75.965)*(-58.855));
