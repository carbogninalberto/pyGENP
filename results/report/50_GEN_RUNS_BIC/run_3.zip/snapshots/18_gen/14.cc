tcb->m_segmentSize = (int) (-11.877/-77.927);
if (segmentsAcked == segmentsAcked) {
	segmentsAcked = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((74.502)));
	segmentsAcked = (int) (3.239+(tcb->m_cWnd)+(73.581)+(70.133)+(15.285)+(59.447)+(70.05));

} else {
	segmentsAcked = (int) (88.975*(96.919)*(tcb->m_cWnd)*(4.897));

}
