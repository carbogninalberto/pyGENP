ReduceCwnd (tcb);
int ukVCPlKAGyjPfxOw = (int) (28.772-(49.857)-(12.306)-(-88.038)-(52.184)-(-48.497)-(34.175));
tcb->m_cWnd = (int) (-79.683*(-91.773)*(96.664));
