if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	segmentsAcked = (int) (30.302-(segmentsAcked)-(66.038)-(27.082)-(80.551));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (17.93-(52.233)-(23.897)-(51.308)-(24.816)-(18.142));

} else {
	segmentsAcked = (int) (63.762/0.1);

}
if (tcb->m_cWnd == segmentsAcked) {
	cnt = (int) (7.937*(9.251)*(33.807)*(85.556));

} else {
	cnt = (int) (((0.1)+(0.1)+(95.964)+((52.533-(12.04)-(56.902)-(59.913)))+(58.668))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (81.151*(56.559)*(segmentsAcked)*(56.651)*(64.597)*(tcb->m_segmentSize)*(24.017)*(tcb->m_segmentSize));
