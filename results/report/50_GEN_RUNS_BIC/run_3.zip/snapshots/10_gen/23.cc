if (tcb->m_segmentSize >= segmentsAcked) {
	cnt = (int) (10.375-(29.023)-(segmentsAcked)-(cnt)-(83.901));
	tcb->m_segmentSize = (int) (73.105-(78.292));

} else {
	cnt = (int) (0.1/3.188);
	cnt = (int) (0.1/0.1);

}
tcb->m_ssThresh = (int) (0.1/(21.063*(7.837)*(60.541)));
tcb->m_ssThresh = (int) (28.149*(58.44)*(69.187)*(5.332)*(44.395));
int OTOvYQImlTxINWKD = (int) (57.073/0.1);
cnt = (int) (1.553-(25.248)-(cnt)-(57.897)-(58.017));
