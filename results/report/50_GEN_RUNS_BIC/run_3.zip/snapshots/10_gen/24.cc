if (cnt == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((((64.94*(38.048)*(60.7)*(42.042)*(50.215)*(15.138)))+(0.1)+(50.303)+(10.443))/((0.1)+(99.234)));

} else {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh*(52.384)*(46.436)*(5.977)*(63.707)*(tcb->m_ssThresh));
	cnt = (int) (98.144-(94.572)-(6.024)-(50.718)-(tcb->m_cWnd)-(40.249)-(tcb->m_cWnd)-(0.858));
	cnt = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (((8.766)+((44.622-(69.521)-(5.995)-(11.249)-(21.285)))+(0.1)+(0.1)+(92.06)+(2.281)+(96.756))/((0.1)));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (tcb->m_cWnd-(10.242)-(tcb->m_cWnd)-(53.751)-(51.837)-(66.147)-(67.213));
tcb->m_segmentSize = (int) (97.67-(20.359));
cnt = (int) (((33.166)+((14.367*(56.103)*(tcb->m_cWnd)))+(0.1)+(10.045))/((49.476)+(0.1)));
segmentsAcked = (int) (16.339*(tcb->m_segmentSize)*(20.881));
