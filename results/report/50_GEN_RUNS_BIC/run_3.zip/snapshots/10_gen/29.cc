float rruKwnZUHBxXkgOy = (float) (50.987+(-24.504)+(14.549)+(67.095)+(60.207));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (5.89*(23.6)*(6.902)*(56.31));
