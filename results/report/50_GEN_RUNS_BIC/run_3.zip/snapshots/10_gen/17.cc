tcb->m_ssThresh = (int) (tcb->m_segmentSize*(cnt));
if (cnt > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (48.46*(28.227)*(64.462)*(3.738)*(68.823));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (49.811+(15.393)+(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (15.935-(73.286)-(69.929)-(80.729)-(8.647)-(cnt)-(tcb->m_cWnd)-(87.951)-(77.551));

}
tcb->m_cWnd = (int) (93.092*(70.836)*(30.965)*(3.553)*(38.641)*(6.444)*(7.513));
tcb->m_cWnd = (int) (segmentsAcked-(91.771)-(37.873)-(13.838)-(42.361));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (60.518+(52.001)+(tcb->m_cWnd)+(tcb->m_cWnd)+(6.805)+(17.511)+(70.538));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (11.841*(segmentsAcked)*(96.059)*(3.976));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
