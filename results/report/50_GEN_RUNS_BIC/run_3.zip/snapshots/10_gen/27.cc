if (cnt <= tcb->m_ssThresh) {
	segmentsAcked = (int) (98.088-(tcb->m_segmentSize)-(tcb->m_cWnd)-(88.984));
	cnt = (int) (tcb->m_segmentSize*(segmentsAcked)*(26.923)*(7.513)*(39.149)*(58.923));

} else {
	segmentsAcked = (int) (91.266*(segmentsAcked)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(27.668)*(84.229)*(segmentsAcked)*(98.718)*(7.147));
	tcb->m_segmentSize = (int) (59.232-(42.238)-(21.7));
	tcb->m_ssThresh = (int) (30.12+(59.43)+(28.899)+(20.079)+(cnt));

}
tcb->m_segmentSize = (int) (0.1/0.1);
segmentsAcked = (int) (55.423*(90.737)*(82.725)*(62.986));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (65.342+(90.944)+(tcb->m_cWnd));
