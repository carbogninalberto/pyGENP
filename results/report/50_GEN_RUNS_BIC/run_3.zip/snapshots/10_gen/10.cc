float rruKwnZUHBxXkgOy = (float) (89.945+(18.309)+(61.571)+(-11.918)+(-62.749));
tcb->m_cWnd = (int) (70.956*(-95.428)*(-60.351)*(95.411));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-4.504*(-4.775)*(55.791)*(-28.044));
tcb->m_cWnd = (int) (68.914*(-17.871)*(-43.725)*(48.03));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (6.987*(-57.576)*(66.418)*(80.709));
tcb->m_cWnd = (int) (24.9*(22.89)*(50.255)*(79.918));
tcb->m_cWnd = (int) (-94.856*(37.708)*(-29.42)*(81.184));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-53.784*(-0.515)*(15.44)*(-30.832));
