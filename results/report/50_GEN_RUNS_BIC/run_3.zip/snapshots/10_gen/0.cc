float rruKwnZUHBxXkgOy = (float) (-58.575+(-79.464)+(82.017)+(-5.905)+(-81.559));
tcb->m_cWnd = (int) (-28.118*(52.121)*(-72.135)*(54.764));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-37.662*(-10.302)*(58.734)*(-40.934));
tcb->m_cWnd = (int) (-19.798*(-72.995)*(-48.598)*(99.538));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (58.209*(40.754)*(-44.721)*(52.513));
