int xbxonlDYOhqRqTcv = (int) (12.639*(47.465)*(-28.798)*(50.205)*(-5.378));
segmentsAcked = (int) (37.965*(39.692)*(-57.695)*(-47.57)*(-71.26)*(-96.177)*(7.282)*(-30.598));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
