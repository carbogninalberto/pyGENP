if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-56.56+(30.265)+(-31.383)+(13.442)+(20.196)+(-1.816));
