tcb->m_cWnd = (int) (-3.506+(81.399)+(-45.787)+(-20.519)+(-67.058)+(9.375));
tcb->m_cWnd = (int) (-96.717+(44.239)+(7.677)+(35.35)+(23.465)+(-36.134));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (5.997*(segmentsAcked)*(51.875)*(45.749)*(28.537)*(2.68));

} else {
	tcb->m_segmentSize = (int) (29.905+(4.16)+(59.041)+(-64.196)+(tcb->m_cWnd)+(segmentsAcked)+(69.299));

}
