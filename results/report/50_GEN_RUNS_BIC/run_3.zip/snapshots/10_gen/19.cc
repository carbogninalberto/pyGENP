if (tcb->m_segmentSize >= cnt) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(47.465)*(80.163)*(71.588)*(31.861)*(9.877)*(tcb->m_cWnd));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (13.126-(40.271));

}
if (tcb->m_ssThresh != tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((84.131+(tcb->m_segmentSize))/0.1);
	cnt = (int) (59.906-(29.199)-(cnt)-(46.578)-(85.997)-(34.842)-(7.289)-(97.14));

} else {
	tcb->m_cWnd = (int) (16.874*(13.983)*(15.806)*(24.967)*(9.519)*(33.167)*(30.569));
	cnt = (int) (16.138-(97.266));
	segmentsAcked = (int) (55.433+(85.99)+(26.326)+(55.065)+(67.463)+(96.404)+(2.229)+(7.609)+(2.13));

}
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(23.79));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (70.446*(cnt)*(63.207)*(0.079)*(84.41)*(76.019)*(55.044)*(62.173)*(67.419));
	cnt = (int) (tcb->m_cWnd-(76.827)-(cnt)-(65.125)-(79.729)-(73.898));

}
tcb->m_ssThresh = (int) (45.279-(tcb->m_cWnd)-(segmentsAcked)-(90.369)-(10.096)-(81.071)-(tcb->m_segmentSize)-(19.565));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (tcb->m_cWnd-(cnt)-(47.03));
if (cnt >= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (13.314/0.1);
	tcb->m_segmentSize = (int) (63.516-(14.678));
	cnt = (int) (cnt+(tcb->m_ssThresh)+(55.304)+(55.846)+(83.214)+(34.229)+(52.391));

} else {
	tcb->m_cWnd = (int) (55.593+(tcb->m_cWnd));
	ReduceCwnd (tcb);

}
