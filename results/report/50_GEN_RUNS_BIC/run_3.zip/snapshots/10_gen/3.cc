float pJQTweHdyNKaxbrD = (float) (-58.337-(-48.592)-(-31.26)-(67.009)-(94.899)-(-79.723)-(-94.099));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
