if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= tcb->m_segmentSize) {
	cnt = (int) (93.823*(11.469)*(58.751)*(74.069)*(37.212)*(92.128)*(tcb->m_ssThresh)*(tcb->m_segmentSize));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (tcb->m_segmentSize-(56.283));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float CrbJhLAbdBIzIWmd = (float) (0.1/93.532);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (74.213-(14.093)-(42.08));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (33.339+(CrbJhLAbdBIzIWmd)+(CrbJhLAbdBIzIWmd)+(23.321)+(65.953)+(74.968));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
