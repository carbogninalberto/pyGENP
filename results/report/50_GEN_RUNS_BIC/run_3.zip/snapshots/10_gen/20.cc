ReduceCwnd (tcb);
if (cnt <= tcb->m_segmentSize) {
	cnt = (int) (0.1/0.1);
	segmentsAcked = (int) (80.272/43.171);
	ReduceCwnd (tcb);

} else {
	cnt = (int) (tcb->m_segmentSize+(32.637));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (89.171+(27.209)+(40.48)+(54.654)+(tcb->m_segmentSize)+(60.869)+(11.066));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (5.723*(46.511)*(34.857)*(tcb->m_ssThresh)*(5.162)*(91.61)*(cnt)*(94.354));
if (cnt <= tcb->m_cWnd) {
	cnt = (int) (((3.462)+(13.384)+(0.1)+(95.752))/((0.1)+(0.1)+(0.1)+(0.1)));

} else {
	cnt = (int) (82.007+(42.76)+(88.708)+(5.325)+(segmentsAcked)+(2.387)+(76.847)+(15.472));
	tcb->m_segmentSize = (int) (87.091+(segmentsAcked)+(55.402));

}
segmentsAcked = (int) (71.651+(33.028)+(tcb->m_cWnd));
