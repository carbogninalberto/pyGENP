ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	segmentsAcked = (int) (90.555*(76.748)*(23.775)*(45.508)*(87.658)*(tcb->m_ssThresh)*(22.861));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (46.123-(54.99)-(19.615)-(37.971));

} else {
	segmentsAcked = (int) (99.83*(87.208));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_cWnd = (int) (((49.722)+((22.534-(tcb->m_segmentSize)-(48.223)-(43.956)-(tcb->m_ssThresh)-(94.454)-(84.583)-(72.251)-(26.54)))+(0.1)+(51.157)+(86.156)+(55.847)+(0.1))/((0.1)+(0.1)));
	tcb->m_segmentSize = (int) (56.168-(82.585)-(65.173));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(43.247)*(12.249)*(30.325));
	tcb->m_segmentSize = (int) (78.292*(43.763));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (tcb->m_segmentSize-(65.882)-(21.403));
if (segmentsAcked != segmentsAcked) {
	cnt = (int) (18.749+(97.749)+(94.554)+(6.184)+(tcb->m_segmentSize)+(72.777));

} else {
	cnt = (int) (85.672*(3.411)*(5.467)*(33.357)*(41.272)*(51.431)*(16.77)*(45.448));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (65.701+(78.509));

}
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(19.48)+(47.332)+(96.058)+(cnt));
tcb->m_segmentSize = (int) (30.469*(segmentsAcked));
