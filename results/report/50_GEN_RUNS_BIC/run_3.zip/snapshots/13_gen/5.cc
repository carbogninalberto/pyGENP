int ukVCPlKAGyjPfxOw = (int) (28.929-(-33.34)-(57.029)-(-66.211)-(52.129)-(7.876)-(37.008));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-9.852*(-41.567)*(95.521));
