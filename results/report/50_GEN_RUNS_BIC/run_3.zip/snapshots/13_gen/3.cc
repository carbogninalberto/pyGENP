int ukVCPlKAGyjPfxOw = (int) (55.968-(-40.176)-(-26.134)-(27.083)-(92.766)-(-2.551)-(-61.299));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-27.346*(10.109)*(85.196));
