float rruKwnZUHBxXkgOy = (float) (-21.422+(62.137)+(65.995)+(-85.65)+(-31.653));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-50.917*(56.211)*(-2.482)*(-5.988));
tcb->m_cWnd = (int) (37.1*(-90.712)*(-90.83)*(96.86));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (25.583*(44.456)*(-56.049)*(-11.598));
