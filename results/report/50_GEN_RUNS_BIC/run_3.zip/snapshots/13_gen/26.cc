int ukVCPlKAGyjPfxOw = (int) (68.097-(87.086)-(40.972)-(23.668)-(-64.823)-(-50.573)-(31.915));
tcb->m_cWnd = (int) (24.529*(-31.336)*(-22.114));
tcb->m_cWnd = (int) (-74.479*(-62.224)*(83.735));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (51.474*(95.829)*(66.171));
tcb->m_cWnd = (int) (-84.94*(-12.908)*(21.093));
