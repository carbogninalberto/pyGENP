int ukVCPlKAGyjPfxOw = (int) (-49.613-(-39.242)-(54.472)-(-70.182)-(90.057)-(-61.771)-(-56.42));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (23.782*(-49.069)*(94.933));
tcb->m_cWnd = (int) (86.34*(-13.886)*(-44.872));
