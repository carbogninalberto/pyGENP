float rruKwnZUHBxXkgOy = (float) (-99.079+(-18.43)+(-84.151)+(60.493)+(-74.552));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (40.41*(19.911)*(73.036)*(-66.699));
