int MAJHtYGONGyCCffO = (int) (38.819+(26.9)+(8.194)+(-17.92)+(71.992)+(47.226)+(-81.415)+(28.113)+(-57.394));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
