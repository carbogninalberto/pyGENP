int ukVCPlKAGyjPfxOw = (int) (-60.293-(-39.716)-(15.973)-(97.825)-(85.883)-(-37.971)-(-7.681));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-12.955*(33.648)*(-63.92));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-51.269*(-49.056)*(74.951));
tcb->m_cWnd = (int) (-83.14*(-19.706)*(1.899));
