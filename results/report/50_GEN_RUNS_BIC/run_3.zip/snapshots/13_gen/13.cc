int ukVCPlKAGyjPfxOw = (int) (69.579-(-26.457)-(81.767)-(-9.36)-(-17.409)-(-54.381)-(73.365));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-74.989*(62.097)*(-8.578));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (74.285*(68.17)*(28.881));
