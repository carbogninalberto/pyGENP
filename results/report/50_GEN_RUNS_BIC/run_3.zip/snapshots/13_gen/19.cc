int ukVCPlKAGyjPfxOw = (int) (-79.07-(-12.849)-(-69.264)-(-59.819)-(30.007)-(46.656)-(-2.552));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (62.772*(19.193)*(-21.863));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (74.735*(55.373)*(62.355));
tcb->m_cWnd = (int) (-84.971*(-56.025)*(15.148));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-59.686*(-46.869)*(91.765));
