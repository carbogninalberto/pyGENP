float rruKwnZUHBxXkgOy = (float) (-27.97+(38.201)+(-77.213)+(-71.556)+(-48.725));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (35.039*(-47.26)*(31.051)*(86.107));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (7.95*(-0.11)*(22.389)*(32.977));
