int ukVCPlKAGyjPfxOw = (int) (69.28-(-29.759)-(28.802)-(34.604)-(73.499)-(77.174)-(8.501));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-42.421*(77.794)*(-1.771));
tcb->m_cWnd = (int) (28.614*(65.28)*(62.267));
tcb->m_cWnd = (int) (61.026*(-22.638)*(-78.3));
tcb->m_cWnd = (int) (-51.561*(-96.134)*(-55.401));
