if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_cWnd = (int) (((49.722)+((22.534-(tcb->m_segmentSize)-(48.223)-(43.956)-(tcb->m_ssThresh)-(94.454)-(84.583)-(72.251)-(26.54)))+(0.1)+(51.157)+(86.156)+(55.847)+(0.1))/((0.1)+(0.1)));
	tcb->m_segmentSize = (int) (56.168-(82.585)-(65.173));

} else {
	tcb->m_cWnd = (int) (75.59*(43.247)*(12.249)*(30.325));
	tcb->m_segmentSize = (int) (78.292*(43.763));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_cWnd = (int) (((49.722)+((22.534-(tcb->m_segmentSize)-(48.223)-(43.956)-(tcb->m_ssThresh)-(94.454)-(84.583)-(72.251)-(26.54)))+(0.1)+(51.157)+(86.156)+(55.847)+(0.1))/((0.1)+(0.1)));
	tcb->m_segmentSize = (int) (56.168-(82.585)-(65.173));

} else {
	tcb->m_cWnd = (int) (75.59*(43.247)*(12.249)*(30.325));
	tcb->m_segmentSize = (int) (78.292*(43.763));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (37.444-(-96.121)-(30.05));
segmentsAcked = (int) (49.55-(-57.451)-(61.101));
