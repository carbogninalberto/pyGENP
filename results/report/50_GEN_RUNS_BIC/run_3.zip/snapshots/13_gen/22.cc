segmentsAcked = (int) (51.85-(-28.159)-(-94.537));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
