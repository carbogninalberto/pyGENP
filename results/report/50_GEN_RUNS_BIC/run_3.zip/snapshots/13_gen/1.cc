int ukVCPlKAGyjPfxOw = (int) (-57.125-(23.872)-(-52.002)-(-7.109)-(-81.806)-(-18.159)-(-98.473));
tcb->m_cWnd = (int) (-32.802*(12.475)*(68.836));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-10.929*(-46.116)*(-10.693));
