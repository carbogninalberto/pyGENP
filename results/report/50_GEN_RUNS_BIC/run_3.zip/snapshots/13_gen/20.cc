segmentsAcked = (int) (-44.698+(48.768)+(71.978)+(56.153)+(-99.896));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (27.241-(-17.164)-(99.055)-(31.969)-(-60.996)-(-31.794));
tcb->m_segmentSize = (int) (-29.683-(-20.588)-(91.948)-(-67.53)-(24.245)-(-65.741));
