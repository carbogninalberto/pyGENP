float rruKwnZUHBxXkgOy = (float) (46.06+(21.661)+(69.032)+(96.819)+(74.693));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-43.704*(41.869)*(55.923)*(-10.134));
tcb->m_cWnd = (int) (-50.887*(55.0)*(-65.741)*(12.342));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (-48.677*(-93.896)*(-54.374)*(94.129));
tcb->m_cWnd = (int) (26.938*(-10.651)*(-61.408)*(-3.743));
