float FdvsSNNSgzgarwId = (float) (1.844*(-51.632)*(-99.691)*(20.478)*(-10.504));
int HHRQGKpHmpnktoPK = (int) (49.796/-35.844);
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(44.422)*(0.671)*(90.029)*(2.596));
	tcb->m_cWnd = (int) (61.442*(79.03));

} else {
	tcb->m_cWnd = (int) (77.375-(78.608)-(94.445)-(61.835)-(88.946));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (tcb->m_cWnd*(12.516)*(38.524)*(tcb->m_segmentSize)*(46.555)*(4.605));

}
if (tcb->m_cWnd == HHRQGKpHmpnktoPK) {
	tcb->m_cWnd = (int) (18.824/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (26.004*(46.084));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
