ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (cnt+(21.043)+(92.276)+(4.452)+(69.142)+(cnt));
int HnlOeRclvzMpmGPl = (int) (87.9+(64.846)+(51.926)+(23.806));
tcb->m_segmentSize = (int) (tcb->m_cWnd*(20.172));
if (segmentsAcked >= cnt) {
	segmentsAcked = (int) (tcb->m_segmentSize+(70.215)+(cnt)+(HnlOeRclvzMpmGPl)+(43.164)+(4.008)+(75.953)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (64.278+(17.837)+(cnt)+(27.017));
	tcb->m_ssThresh = (int) (((0.1)+(27.69)+((94.661*(20.724)*(18.108)*(tcb->m_cWnd)*(5.025)*(tcb->m_ssThresh)))+(78.315)+(46.909)+(33.549))/((69.022)+(96.646)+(0.1)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize-(15.258)-(85.681));
	cnt = (int) (cnt*(48.4)*(tcb->m_segmentSize)*(86.867)*(97.82)*(79.167)*(tcb->m_ssThresh)*(32.385)*(83.785));
	cnt = (int) (((0.1)+((tcb->m_ssThresh-(segmentsAcked)))+((52.692-(89.968)-(3.997)-(11.746)-(21.379)-(49.152)-(45.262)-(93.29)-(36.532)))+(0.1))/((89.987)+(36.907)+(15.834)));

}
tcb->m_cWnd = (int) (24.766-(tcb->m_ssThresh)-(38.796)-(68.794)-(96.723)-(64.964)-(25.61)-(tcb->m_ssThresh));
if (tcb->m_cWnd == HnlOeRclvzMpmGPl) {
	tcb->m_cWnd = (int) (29.156-(69.12)-(4.608)-(94.887)-(33.554));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (23.763+(83.283)+(57.345)+(77.742)+(tcb->m_cWnd));
	tcb->m_cWnd = (int) (50.557+(11.722)+(11.336)+(segmentsAcked)+(42.376));
	tcb->m_cWnd = (int) (33.375+(33.62)+(10.323)+(90.632)+(29.598)+(60.52)+(HnlOeRclvzMpmGPl));

}
