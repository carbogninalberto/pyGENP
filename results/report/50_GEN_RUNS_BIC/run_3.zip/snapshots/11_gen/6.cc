tcb->m_cWnd = (int) (0.713-(-63.495)-(-77.398)-(78.186)-(68.409)-(-82.686)-(70.791)-(26.173)-(-54.744));
segmentsAcked = (int) (-81.39+(-60.358)+(-44.216)+(86.293)+(-17.416)+(-59.776)+(80.108)+(28.662));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
