if (segmentsAcked < tcb->m_ssThresh) {
	cnt = (int) (19.177+(35.255)+(24.855)+(cnt)+(61.035));
	tcb->m_cWnd = (int) (43.072-(77.898)-(6.221)-(69.328)-(7.651));

} else {
	cnt = (int) (94.81/(3.837*(20.723)*(20.301)*(68.963)*(71.598)*(tcb->m_ssThresh)*(9.159)));
	tcb->m_segmentSize = (int) (4.773+(70.067)+(22.508)+(7.057)+(90.805)+(73.171));
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(4.398)-(tcb->m_cWnd)-(15.158)-(28.576)-(91.884)-(segmentsAcked)-(82.855)-(74.374));

}
tcb->m_cWnd = (int) (61.925-(34.114)-(87.794)-(47.602));
if (cnt >= cnt) {
	tcb->m_ssThresh = (int) (8.732-(5.477)-(62.324)-(7.805)-(12.306)-(5.409)-(cnt)-(cnt)-(59.603));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (30.385/0.1);

}
float xVmQmkTwyfsFwZeU = (float) (28.595*(10.308));
if (tcb->m_cWnd < segmentsAcked) {
	tcb->m_ssThresh = (int) (58.801+(70.181)+(38.177));
	tcb->m_segmentSize = (int) (46.44*(12.709)*(89.81)*(1.986)*(28.37)*(25.017)*(78.973));

} else {
	tcb->m_ssThresh = (int) (34.209*(9.842)*(56.918)*(24.421)*(48.452));
	xVmQmkTwyfsFwZeU = (float) (tcb->m_ssThresh+(4.618)+(4.302));
	cnt = (int) (8.557+(segmentsAcked)+(73.964)+(72.126)+(tcb->m_ssThresh)+(87.865));

}
ReduceCwnd (tcb);
if (xVmQmkTwyfsFwZeU == cnt) {
	tcb->m_segmentSize = (int) (56.911+(tcb->m_segmentSize)+(73.428)+(29.592)+(7.52)+(segmentsAcked)+(tcb->m_segmentSize));
	segmentsAcked = (int) (((0.1)+(0.1)+((10.37*(69.43)*(17.598)*(80.627)))+(98.69)+(97.317)+(71.21))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (74.485+(tcb->m_ssThresh)+(85.638)+(86.635)+(65.116)+(tcb->m_segmentSize)+(segmentsAcked));
	xVmQmkTwyfsFwZeU = (float) (0.1/(76.68-(xVmQmkTwyfsFwZeU)-(54.807)));

}
if (tcb->m_cWnd == xVmQmkTwyfsFwZeU) {
	tcb->m_cWnd = (int) (84.596*(98.899)*(0.983)*(33.694)*(63.326)*(3.099)*(13.453));
	ReduceCwnd (tcb);
	xVmQmkTwyfsFwZeU = (float) (0.1/0.1);

} else {
	tcb->m_cWnd = (int) (0.1/39.284);
	tcb->m_cWnd = (int) (17.374/0.1);

}
