ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (tcb->m_ssThresh*(87.019)*(94.276)*(66.088));
