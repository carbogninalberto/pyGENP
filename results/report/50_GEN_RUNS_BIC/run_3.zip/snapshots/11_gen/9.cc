float FdvsSNNSgzgarwId = (float) (-30.145*(-26.082)*(38.204)*(26.991)*(-49.923));
int HHRQGKpHmpnktoPK = (int) (0.005/45.439);
if (tcb->m_cWnd == HHRQGKpHmpnktoPK) {
	tcb->m_cWnd = (int) (18.824/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (26.004*(46.084));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (tcb->m_cWnd == HHRQGKpHmpnktoPK) {
	tcb->m_cWnd = (int) (18.824/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (26.004*(46.084));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
