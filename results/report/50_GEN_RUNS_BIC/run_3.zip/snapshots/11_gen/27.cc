ReduceCwnd (tcb);
if (tcb->m_ssThresh <= cnt) {
	tcb->m_cWnd = (int) (51.265-(tcb->m_cWnd)-(68.749)-(41.876));

} else {
	tcb->m_cWnd = (int) (((90.265)+(0.1)+(98.101)+(51.6))/((5.582)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (49.154-(54.194));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (10.507*(66.292)*(11.781)*(88.654)*(7.338)*(67.382)*(26.54));

} else {
	tcb->m_segmentSize = (int) (45.273-(38.531)-(59.057)-(92.318)-(88.278)-(96.338)-(28.712)-(tcb->m_segmentSize));

}
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (segmentsAcked-(98.961)-(75.706)-(75.572)-(22.352)-(9.517)-(8.657)-(8.477)-(16.569));
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (61.448*(22.253)*(0.448)*(73.504)*(54.184)*(10.057)*(16.91)*(34.913)*(18.949));
	tcb->m_segmentSize = (int) (7.651+(14.299)+(10.883)+(35.658));
	segmentsAcked = (int) (50.502+(tcb->m_ssThresh)+(87.336)+(48.872)+(43.822)+(cnt)+(16.833)+(86.373)+(76.823));

}
if (tcb->m_segmentSize == cnt) {
	tcb->m_cWnd = (int) (0.1/38.201);
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (90.907+(tcb->m_ssThresh)+(10.892)+(50.945)+(54.848)+(23.321));

} else {
	tcb->m_cWnd = (int) (78.387*(9.419)*(tcb->m_segmentSize));
	tcb->m_cWnd = (int) (49.775/0.1);

}
tcb->m_segmentSize = (int) (70.832-(69.292)-(44.38)-(cnt)-(10.211));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_ssThresh = (int) (segmentsAcked+(41.493)+(tcb->m_ssThresh)+(cnt)+(73.078)+(82.776)+(94.431)+(11.089));
	tcb->m_segmentSize = (int) (69.389-(tcb->m_segmentSize)-(80.541)-(71.8)-(tcb->m_segmentSize)-(48.16)-(tcb->m_ssThresh)-(6.953)-(44.712));

} else {
	tcb->m_ssThresh = (int) (75.536-(73.11)-(3.164)-(50.568));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(32.416)*(95.244)*(tcb->m_segmentSize)*(33.151)*(51.536)*(4.898));

}
