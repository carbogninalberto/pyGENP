int ukVCPlKAGyjPfxOw = (int) (57.411-(-11.12)-(-19.003)-(-16.565)-(-79.704)-(96.568)-(-12.583));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-59.599*(-35.944)*(-25.922));
tcb->m_cWnd = (int) (-71.753*(43.707)*(-9.869));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
