tcb->m_segmentSize = (int) (((99.777)+(0.1)+(73.756)+(66.755)+(46.907))/((0.1)+(0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize >= cnt) {
	cnt = (int) (0.1/53.902);
	segmentsAcked = (int) ((((29.236+(7.043)+(tcb->m_segmentSize)+(14.447)+(4.044)+(92.342)+(50.398)+(83.481)+(83.452)))+((98.525*(79.674)*(1.904)*(14.375)*(39.004)*(1.128)))+((88.303*(39.51)*(tcb->m_ssThresh)*(tcb->m_ssThresh)))+(0.1)+(72.442))/((35.877)+(0.1)));
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(19.948)-(3.218)-(77.665)-(15.082)-(tcb->m_ssThresh)-(50.115)-(72.257));

} else {
	cnt = (int) (2.367+(tcb->m_cWnd)+(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked <= cnt) {
	tcb->m_cWnd = (int) (segmentsAcked+(53.432));
	tcb->m_cWnd = (int) (72.13/73.86);
	tcb->m_segmentSize = (int) (78.19-(64.224)-(33.798)-(22.733)-(76.504)-(39.863)-(75.133)-(tcb->m_ssThresh)-(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (0.1/59.177);
	tcb->m_cWnd = (int) (85.347*(90.239)*(88.988)*(cnt));
	ReduceCwnd (tcb);

}
if (cnt == tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (20.494*(81.868)*(tcb->m_cWnd)*(39.282)*(cnt)*(tcb->m_cWnd)*(91.572)*(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (((0.1)+(44.345)+(0.1)+((76.362+(12.875)+(82.643)+(cnt)+(32.64)))+(0.1)+(0.1)+(99.64)+(0.1))/((94.874)));

}
int jEWqNfAOnSkkzNgR = (int) (46.844*(71.35)*(94.452)*(44.093)*(67.046)*(86.092)*(68.259));
ReduceCwnd (tcb);
