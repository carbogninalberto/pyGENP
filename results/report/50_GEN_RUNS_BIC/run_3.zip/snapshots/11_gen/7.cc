int OTOvYQImlTxINWKD = (int) (-36.513/-59.305);
ReduceCwnd (tcb);
