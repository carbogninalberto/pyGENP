if (cnt <= tcb->m_cWnd) {
	cnt = (int) (77.02*(45.821)*(segmentsAcked)*(21.277));
	tcb->m_ssThresh = (int) (14.132+(3.53)+(10.534)+(0.349)+(tcb->m_cWnd)+(cnt)+(tcb->m_cWnd));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (tcb->m_segmentSize-(19.228)-(63.036)-(83.311));
	tcb->m_cWnd = (int) (90.044*(30.239)*(79.544)*(56.201)*(92.12)*(7.079)*(81.798)*(55.849)*(37.296));
	tcb->m_segmentSize = (int) ((11.298*(69.707)*(78.426)*(54.701)*(44.664)*(tcb->m_ssThresh)*(88.882)*(31.759)*(84.942))/0.1);

}
if (cnt <= segmentsAcked) {
	segmentsAcked = (int) (90.866*(87.62)*(9.232)*(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (34.675-(18.887)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(45.091)-(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (0.1/0.1);
ReduceCwnd (tcb);
if (tcb->m_ssThresh > cnt) {
	tcb->m_segmentSize = (int) (93.398*(8.025));

} else {
	tcb->m_segmentSize = (int) (90.722/0.1);
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (64.965-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(42.704)-(27.916)-(65.085));

}
int ElTazWOWdLMWpdoT = (int) (21.681*(tcb->m_segmentSize)*(96.526)*(segmentsAcked)*(48.317)*(cnt)*(56.943));
