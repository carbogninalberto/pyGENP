if (segmentsAcked >= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (cnt-(22.446)-(14.658)-(56.664)-(45.649)-(58.182)-(72.477)-(0.127));
	cnt = (int) (69.05*(5.194)*(44.602));
	tcb->m_cWnd = (int) (0.1/5.997);

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(79.939)*(16.491)*(segmentsAcked)*(segmentsAcked)*(63.045)*(tcb->m_cWnd)*(17.047));

}
tcb->m_cWnd = (int) (22.66+(20.063)+(cnt));
if (cnt < segmentsAcked) {
	tcb->m_cWnd = (int) (0.296-(83.631)-(9.906)-(1.461)-(16.836)-(84.387)-(tcb->m_segmentSize)-(78.514)-(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (10.284-(47.66)-(tcb->m_cWnd));
	tcb->m_cWnd = (int) (0.1/0.1);

}
float kANktRZTGuGSZTqv = (float) ((tcb->m_ssThresh-(tcb->m_ssThresh)-(tcb->m_ssThresh)-(80.533)-(5.692)-(tcb->m_cWnd)-(5.104))/0.1);
cnt = (int) (25.83-(55.607)-(segmentsAcked)-(29.577)-(84.339)-(tcb->m_cWnd));
kANktRZTGuGSZTqv = (float) (((62.805)+(0.1)+(0.1)+(0.1))/((3.002)+(70.959)+(0.1)+(0.1)));
tcb->m_segmentSize = (int) (82.158+(70.912)+(77.32)+(tcb->m_cWnd)+(44.265)+(64.338)+(tcb->m_segmentSize));
if (tcb->m_segmentSize == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (kANktRZTGuGSZTqv-(segmentsAcked)-(52.319)-(tcb->m_segmentSize)-(66.535));

} else {
	tcb->m_segmentSize = (int) (59.823-(tcb->m_ssThresh)-(53.04));
	tcb->m_cWnd = (int) (68.595+(69.946)+(tcb->m_segmentSize)+(59.139));
	cnt = (int) (61.946-(kANktRZTGuGSZTqv)-(kANktRZTGuGSZTqv)-(26.788)-(92.258)-(segmentsAcked));

}
