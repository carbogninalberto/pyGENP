tcb->m_cWnd = (int) (56.718+(95.385)+(90.289)+(42.784)+(86.225)+(0.885)+(tcb->m_segmentSize)+(94.183));
if (tcb->m_cWnd != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(94.323)*(39.888));
	tcb->m_cWnd = (int) (73.804-(87.533)-(62.384)-(29.51)-(tcb->m_cWnd)-(63.996)-(99.266)-(31.678)-(98.186));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (94.823-(13.206)-(77.491));

}
tcb->m_ssThresh = (int) (segmentsAcked*(tcb->m_cWnd)*(11.146)*(3.934)*(13.741));
tcb->m_ssThresh = (int) (tcb->m_segmentSize-(9.32));
tcb->m_cWnd = (int) (tcb->m_segmentSize-(37.905)-(41.458)-(tcb->m_cWnd)-(3.828)-(82.65)-(segmentsAcked)-(9.823)-(4.77));
int IwuaIBCIyzfYtYWU = (int) (cnt+(cnt));
if (tcb->m_segmentSize >= cnt) {
	cnt = (int) (61.021-(tcb->m_ssThresh)-(35.73));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (28.618*(82.9)*(tcb->m_segmentSize)*(30.13)*(52.664)*(33.529));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(19.772)+(59.572));
	segmentsAcked = (int) (88.042*(51.671)*(cnt)*(74.958)*(92.062)*(60.103)*(61.52)*(1.906)*(28.848));

}
if (tcb->m_segmentSize != tcb->m_segmentSize) {
	segmentsAcked = (int) (segmentsAcked+(99.459)+(21.651)+(12.838));

} else {
	segmentsAcked = (int) (IwuaIBCIyzfYtYWU+(27.558)+(43.358));
	cnt = (int) (1.87+(18.064)+(tcb->m_ssThresh)+(25.325)+(tcb->m_ssThresh)+(72.457)+(72.924));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked > tcb->m_cWnd) {
	cnt = (int) (85.361*(74.807)*(99.055)*(49.584));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

} else {
	cnt = (int) (54.338-(2.265)-(47.699)-(48.603)-(tcb->m_segmentSize)-(11.642));

}
