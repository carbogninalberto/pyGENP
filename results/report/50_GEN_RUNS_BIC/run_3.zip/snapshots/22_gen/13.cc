tcb->m_segmentSize = (int) (77.198+(54.972));
int ZfXKqkXbzDvxJyIx = (int) (((0.1)+(0.1)+(0.1)+(0.1))/((0.1)));
float IxAWxVeYfTvYHQOk = (float) (85.438+(25.746)+(74.349)+(tcb->m_cWnd)+(67.948));
int NFpnsyzUmEjaYMui = (int) (75.737-(tcb->m_cWnd)-(61.239)-(78.512)-(46.588));
if (ZfXKqkXbzDvxJyIx != NFpnsyzUmEjaYMui) {
	cnt = (int) (0.1/61.317);

} else {
	cnt = (int) (26.504*(46.53));
	tcb->m_ssThresh = (int) ((((54.041-(cnt)-(74.782)-(60.756)-(IxAWxVeYfTvYHQOk)-(tcb->m_segmentSize)))+(47.261)+(0.1)+(72.177)+(30.608)+(0.1)+(0.1))/((28.829)+(69.83)));

}
