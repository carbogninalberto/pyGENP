if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (16.07/0.1);

} else {
	tcb->m_cWnd = (int) (0.463*(45.177)*(6.596));
	tcb->m_segmentSize = (int) (50.823*(51.957)*(46.647)*(84.319)*(46.111)*(29.964)*(29.855)*(tcb->m_segmentSize));

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh >= cnt) {
	tcb->m_ssThresh = (int) (98.785*(1.329)*(segmentsAcked)*(89.017));
	tcb->m_ssThresh = (int) ((25.835*(39.479))/0.1);

} else {
	tcb->m_ssThresh = (int) (0.1/24.171);
	cnt = (int) (0.1/68.533);

}
if (cnt < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (segmentsAcked*(segmentsAcked)*(35.303)*(37.431)*(0.647)*(cnt));

} else {
	tcb->m_ssThresh = (int) (18.397*(tcb->m_cWnd)*(7.912));
	segmentsAcked = (int) (79.931/49.075);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
