int VtgXzldofQrlmTUT = (int) (79.038-(-34.399));
if (VtgXzldofQrlmTUT == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) ((21.129-(50.065)-(7.629)-(89.225)-(73.642)-(90.77)-(47.615))/54.773);
	tcb->m_cWnd = (int) (48.617*(92.357)*(23.93)*(76.747)*(41.744));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (22.179*(77.646)*(72.712)*(8.677));
	VtgXzldofQrlmTUT = (int) (55.138/22.981);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-61.863*(-10.748));
ReduceCwnd (tcb);
