tcb->m_segmentSize = (int) (10.815+(29.092)+(77.039)+(16.244)+(33.662)+(56.773)+(65.97)+(86.727)+(71.297));
cnt = (int) (52.785-(15.097));
tcb->m_ssThresh = (int) (99.072-(57.36));
ReduceCwnd (tcb);
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (71.805-(65.402)-(62.22)-(11.519)-(54.626)-(56.83)-(30.882));
	tcb->m_cWnd = (int) (98.268+(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (22.119-(49.912));
	cnt = (int) (0.1/(78.934*(67.873)*(56.268)*(5.438)*(34.447)*(39.008)));

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) ((27.657-(20.867)-(8.466)-(tcb->m_ssThresh))/81.128);
if (tcb->m_ssThresh > tcb->m_cWnd) {
	cnt = (int) (97.228*(84.787)*(95.979));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	cnt = (int) (97.781+(55.028)+(4.534)+(63.692)+(49.149)+(55.195)+(tcb->m_ssThresh)+(82.903));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
