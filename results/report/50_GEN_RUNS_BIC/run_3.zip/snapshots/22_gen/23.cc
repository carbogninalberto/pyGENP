segmentsAcked = (int) (41.743-(1.778)-(7.697)-(24.696)-(8.251)-(88.547));
cnt = (int) (88.949-(49.023)-(tcb->m_segmentSize)-(21.631)-(tcb->m_cWnd)-(46.777)-(72.235));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (34.557-(cnt)-(2.384)-(segmentsAcked)-(20.225));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (89.494-(1.001)-(43.575));
tcb->m_segmentSize = (int) (((0.1)+(8.161)+(79.213)+(62.399))/((0.1)+(0.1)));
if (cnt >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (53.289*(30.176)*(tcb->m_cWnd)*(36.979));

} else {
	tcb->m_ssThresh = (int) (94.969+(79.08)+(43.892)+(76.396)+(14.013)+(cnt)+(tcb->m_segmentSize));

}
