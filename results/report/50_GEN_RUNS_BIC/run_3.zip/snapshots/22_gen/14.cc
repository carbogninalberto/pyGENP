tcb->m_segmentSize = (int) (53.486-(78.076)-(73.309));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (54.364+(29.483)+(14.197));
ReduceCwnd (tcb);
int CDLUwKeszbqROtNw = (int) (90.156+(80.64));
tcb->m_cWnd = (int) (9.474-(96.544)-(CDLUwKeszbqROtNw)-(49.221)-(18.363)-(87.71));
