if (segmentsAcked >= segmentsAcked) {
	segmentsAcked = (int) ((((tcb->m_ssThresh-(30.04)-(31.193)-(57.621)-(37.022)))+(25.236)+((50.051+(59.231)+(37.312)+(74.146)+(24.245)+(67.28)+(63.3)+(35.671)+(74.018)))+(41.239))/((44.96)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (8.995*(segmentsAcked)*(89.29)*(24.086)*(64.182)*(cnt)*(83.96));
	tcb->m_ssThresh = (int) (60.046*(59.696)*(71.187)*(tcb->m_ssThresh)*(30.619));
	cnt = (int) (24.197+(13.058)+(tcb->m_ssThresh)+(tcb->m_ssThresh));

}
float YMkTrZgxEVmdzWds = (float) (cnt-(59.199)-(40.814)-(72.216)-(tcb->m_cWnd)-(5.639)-(5.238)-(0.541));
float zCJUqxkcUbvmAVrY = (float) (92.15+(YMkTrZgxEVmdzWds)+(75.765)+(tcb->m_cWnd)+(44.429)+(30.716)+(tcb->m_segmentSize));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (87.959+(68.22));
tcb->m_cWnd = (int) (98.333-(35.337));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	cnt = (int) (segmentsAcked-(94.604)-(cnt)-(30.001)-(50.683)-(83.633)-(26.147)-(24.954));
	YMkTrZgxEVmdzWds = (float) (YMkTrZgxEVmdzWds+(cnt)+(54.023)+(tcb->m_segmentSize)+(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (85.728*(34.011)*(4.553)*(zCJUqxkcUbvmAVrY)*(tcb->m_ssThresh)*(91.672)*(38.527));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (81.418+(cnt));

} else {
	tcb->m_ssThresh = (int) (46.533*(66.628)*(1.87)*(27.482)*(55.373)*(56.704)*(27.763)*(63.091)*(52.953));

}
if (YMkTrZgxEVmdzWds <= YMkTrZgxEVmdzWds) {
	cnt = (int) (90.238-(segmentsAcked)-(cnt)-(26.653)-(tcb->m_segmentSize)-(cnt)-(14.111)-(49.889)-(49.685));
	tcb->m_segmentSize = (int) (36.549+(zCJUqxkcUbvmAVrY)+(5.223));

} else {
	cnt = (int) (tcb->m_cWnd-(15.487)-(17.44)-(22.554)-(66.546)-(97.986)-(YMkTrZgxEVmdzWds)-(29.47));

}
