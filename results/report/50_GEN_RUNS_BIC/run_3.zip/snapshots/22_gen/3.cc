tcb->m_cWnd = (int) (81.454/-39.745);
