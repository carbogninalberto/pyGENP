cnt = (int) (0.1/53.636);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (11.127+(1.407)+(tcb->m_ssThresh)+(94.07)+(34.289)+(0.843)+(60.928));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (63.345-(51.877)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(2.907));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (0.1/89.025);
	tcb->m_cWnd = (int) (75.727*(tcb->m_segmentSize)*(1.184)*(99.73));
	tcb->m_segmentSize = (int) (6.769-(70.117)-(70.631));

}
