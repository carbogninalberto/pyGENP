int auQOktHtewbOCgXp = (int) (37.246+(30.818)+(1.138));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
auQOktHtewbOCgXp = (int) (11.084-(tcb->m_cWnd)-(0.931)-(cnt)-(54.93)-(40.477)-(79.368)-(49.339)-(41.709));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (35.199+(48.775)+(83.418)+(71.991));
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (91.176-(23.697)-(tcb->m_cWnd)-(96.875));

} else {
	tcb->m_ssThresh = (int) (95.284*(84.533)*(35.492)*(90.673)*(50.959)*(28.589)*(77.626)*(tcb->m_cWnd)*(19.066));

}
ReduceCwnd (tcb);
