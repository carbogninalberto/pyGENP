tcb->m_cWnd = (int) (-97.655-(-92.467)-(45.186)-(31.397));
int iXipgwLzRfBmLGVC = (int) (22.451*(-99.927)*(-62.928)*(-9.599)*(57.228)*(84.226)*(58.363));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
