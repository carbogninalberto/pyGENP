int zBKDejwVlQTzNLnc = (int) (-69.078+(60.784)+(62.389)+(70.328)+(-22.578)+(-86.255)+(-44.915));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (54.696-(-81.564));
