tcb->m_segmentSize = (int) (-98.892+(-35.677)+(-24.345));
int nROjOiBFFuqOdUOw = (int) (-12.807-(83.138)-(46.672)-(-93.173));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-14.913)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (64.36-(-19.905)-(-15.995)-(-52.114)-(-75.712)-(65.165)-(97.526)-(16.976));
tcb->m_segmentSize = (int) (-5.401+(-57.167)+(-46.665)+(-64.564)+(-67.147)+(-18.866));
tcb->m_segmentSize = (int) (-30.794+(11.019)+(41.775));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(17.958)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (-17.478-(86.605)-(93.506)-(-53.852)-(-22.618)-(31.025)-(-25.288)-(99.457));
tcb->m_segmentSize = (int) (-45.497+(-60.399)+(-70.777)+(41.644)+(-99.091)+(56.952));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
