int RDOJmalYwwjeoetD = (int) (81.827*(-29.937)*(3.962));
