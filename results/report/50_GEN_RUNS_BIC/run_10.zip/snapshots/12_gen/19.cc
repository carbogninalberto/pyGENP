if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int TLRWaccFYJOFpSYi = (int) (65.065-(32.005)-(74.222)-(cnt)-(35.396)-(81.739));
segmentsAcked = (int) (tcb->m_segmentSize*(27.279)*(80.534)*(51.899));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (50.29*(63.86)*(55.322)*(62.791)*(37.558));
if (tcb->m_segmentSize < segmentsAcked) {
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(21.036));

} else {
	tcb->m_ssThresh = (int) (69.804-(6.086)-(6.541)-(7.194)-(10.965)-(32.347)-(TLRWaccFYJOFpSYi)-(segmentsAcked)-(51.639));
	TLRWaccFYJOFpSYi = (int) (6.741+(22.524)+(tcb->m_segmentSize)+(17.683)+(tcb->m_cWnd)+(91.165));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
