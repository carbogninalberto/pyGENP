cnt = (int) (69.153*(segmentsAcked)*(43.846));
ReduceCwnd (tcb);
float yuMQjvqWTlxtZyoS = (float) (65.353+(80.59)+(43.75)+(46.826));
ReduceCwnd (tcb);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	yuMQjvqWTlxtZyoS = (float) (cnt+(28.43)+(yuMQjvqWTlxtZyoS)+(57.583));
	cnt = (int) (cnt*(cnt)*(63.377)*(35.605)*(50.613)*(36.858)*(41.396)*(1.713)*(31.224));
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(91.644)+(47.38)+(16.572)+(19.526));

} else {
	yuMQjvqWTlxtZyoS = (float) (84.926*(92.953)*(83.445)*(16.493)*(33.94)*(80.055)*(83.635)*(17.611)*(yuMQjvqWTlxtZyoS));
	yuMQjvqWTlxtZyoS = (float) ((((tcb->m_cWnd*(tcb->m_cWnd)*(14.237)*(69.89)*(tcb->m_ssThresh)))+(67.773)+((4.323-(90.98)-(tcb->m_cWnd)-(34.946)-(yuMQjvqWTlxtZyoS)-(90.336)-(71.412)-(segmentsAcked)-(95.599)))+(0.1)+(29.429)+(38.61))/((0.1)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
