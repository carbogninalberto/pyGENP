tcb->m_ssThresh = (int) (41.394+(62.467)+(23.197));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (8.535*(87.872)*(18.255)*(94.304)*(86.547)*(19.896)*(74.958)*(55.357));
float wHmNxwxOcUEjDtTx = (float) (((99.649)+(81.169)+(0.1)+(84.536)+(64.812))/((0.1)+(81.713)));
if (segmentsAcked <= wHmNxwxOcUEjDtTx) {
	tcb->m_segmentSize = (int) (31.162*(20.912)*(72.696)*(73.235)*(84.895)*(70.18));
	segmentsAcked = (int) (tcb->m_cWnd+(17.108)+(2.756)+(16.671)+(tcb->m_cWnd)+(50.428));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	cnt = (int) (wHmNxwxOcUEjDtTx+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(3.662)+(65.692)+(tcb->m_ssThresh)+(92.714)+(65.45)+(89.308));
	ReduceCwnd (tcb);

}
