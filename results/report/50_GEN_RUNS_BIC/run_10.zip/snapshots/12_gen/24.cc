if (segmentsAcked >= segmentsAcked) {
	tcb->m_cWnd = (int) (cnt*(tcb->m_segmentSize)*(67.641)*(82.751)*(1.658)*(41.443)*(tcb->m_segmentSize));

} else {
	tcb->m_cWnd = (int) (41.541-(97.514)-(cnt)-(49.137)-(tcb->m_segmentSize)-(64.988)-(40.03)-(91.819)-(segmentsAcked));

}
ReduceCwnd (tcb);
if (segmentsAcked == segmentsAcked) {
	segmentsAcked = (int) (20.283-(tcb->m_ssThresh)-(49.328)-(85.62)-(50.418)-(11.118));
	tcb->m_ssThresh = (int) (15.053*(46.188)*(34.489));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (tcb->m_segmentSize-(85.555)-(67.994)-(6.74));
	tcb->m_cWnd = (int) (60.924*(38.349)*(tcb->m_ssThresh)*(40.267)*(91.212)*(55.166));

}
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (26.77/68.447);
if (tcb->m_segmentSize > tcb->m_cWnd) {
	segmentsAcked = (int) ((38.547-(12.906)-(2.56)-(36.733)-(64.191)-(89.458)-(segmentsAcked))/0.1);
	tcb->m_ssThresh = (int) (53.442+(5.908)+(tcb->m_segmentSize)+(58.779)+(cnt)+(54.635)+(56.09));
	cnt = (int) ((31.735-(segmentsAcked)-(8.419)-(70.775)-(cnt)-(14.832)-(64.772)-(29.419))/35.491);

} else {
	segmentsAcked = (int) (66.544+(77.81)+(84.664)+(28.391)+(89.379)+(82.595)+(37.264));
	tcb->m_cWnd = (int) (96.978*(86.671)*(36.033)*(84.873));
	ReduceCwnd (tcb);

}
