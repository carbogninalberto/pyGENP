if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_segmentSize = (int) (15.077*(73.012)*(50.473)*(36.997));
	cnt = (int) (59.422*(cnt)*(80.0)*(cnt));

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	tcb->m_cWnd = (int) (45.714*(tcb->m_ssThresh)*(30.844)*(0.363)*(98.898));

}
if (tcb->m_segmentSize == segmentsAcked) {
	segmentsAcked = (int) (96.126+(60.31)+(37.42)+(49.342)+(2.568)+(55.549)+(99.725));
	tcb->m_cWnd = (int) (37.293+(cnt)+(79.791)+(45.208)+(58.739)+(21.372)+(segmentsAcked)+(15.374)+(5.011));

} else {
	segmentsAcked = (int) (tcb->m_ssThresh-(10.969)-(segmentsAcked)-(85.64)-(96.504)-(45.453));

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_cWnd = (int) (27.128*(segmentsAcked)*(57.867)*(77.248)*(20.654)*(76.431)*(6.3));
	tcb->m_cWnd = (int) (5.869/(34.038+(17.115)+(cnt)+(37.729)+(41.65)+(20.325)));

} else {
	tcb->m_cWnd = (int) (23.69+(51.688)+(95.256)+(44.274)+(tcb->m_cWnd)+(98.488)+(76.871)+(81.363)+(82.726));
	tcb->m_cWnd = (int) (4.091*(76.662)*(59.148)*(57.742)*(26.401)*(75.629)*(61.766)*(31.478)*(segmentsAcked));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
