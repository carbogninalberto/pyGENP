cnt = (int) (60.707+(91.954)+(44.786)+(tcb->m_cWnd)+(84.128));
if (tcb->m_cWnd < tcb->m_ssThresh) {
	cnt = (int) (57.903*(51.941)*(2.709)*(tcb->m_cWnd)*(tcb->m_cWnd)*(96.025)*(20.811));
	segmentsAcked = (int) (cnt+(7.003)+(64.514)+(64.212)+(tcb->m_segmentSize)+(67.992)+(60.63));

} else {
	cnt = (int) (12.837*(83.315)*(7.39)*(tcb->m_cWnd)*(34.801)*(64.701)*(30.831)*(27.148));
	tcb->m_segmentSize = (int) (1.898*(61.524)*(26.555));
	tcb->m_ssThresh = (int) (67.787-(20.79)-(14.37)-(0.227)-(92.141)-(66.818)-(93.02)-(cnt)-(4.411));

}
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	segmentsAcked = (int) (10.942-(tcb->m_cWnd)-(77.837)-(42.745)-(23.783)-(90.72)-(tcb->m_segmentSize));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(53.002)*(51.377));
	tcb->m_segmentSize = (int) (7.294-(96.342)-(tcb->m_cWnd)-(segmentsAcked)-(12.855)-(49.96)-(84.79)-(60.015)-(37.754));
	tcb->m_cWnd = (int) (96.856+(33.902)+(41.925)+(0.371)+(segmentsAcked)+(0.651)+(tcb->m_ssThresh)+(tcb->m_ssThresh)+(81.819));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
