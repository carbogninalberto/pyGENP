tcb->m_cWnd = (int) (28.488*(84.521)*(41.255)*(99.93)*(48.596)*(tcb->m_segmentSize));
if (segmentsAcked < cnt) {
	segmentsAcked = (int) (61.03*(tcb->m_ssThresh)*(3.427)*(1.094)*(9.451)*(segmentsAcked));

} else {
	segmentsAcked = (int) (75.818-(16.854)-(75.668)-(49.451)-(65.055)-(tcb->m_segmentSize)-(40.13)-(54.866));
	tcb->m_segmentSize = (int) (35.43+(82.526)+(92.354)+(segmentsAcked)+(14.277)+(8.099));

}
int LIgoBtQadEjhpVPP = (int) (tcb->m_ssThresh-(80.202));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
segmentsAcked = (int) (tcb->m_ssThresh-(23.369)-(32.815)-(51.386));
ReduceCwnd (tcb);
