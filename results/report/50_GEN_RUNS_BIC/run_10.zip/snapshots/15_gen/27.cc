tcb->m_segmentSize = (int) (0.1/22.009);
if (tcb->m_ssThresh > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (29.166-(79.446)-(cnt)-(80.004)-(98.324)-(52.022)-(54.546)-(98.927));
	tcb->m_cWnd = (int) (96.038*(0.1)*(tcb->m_ssThresh)*(47.924)*(51.933));
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(59.917)-(68.28)-(44.326)-(11.573));

} else {
	tcb->m_cWnd = (int) (50.146*(21.966)*(75.51)*(56.077));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (26.937/0.1);

}
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (((31.082)+(39.179)+(0.1)+((15.509*(22.892)*(99.204)))+(34.58))/((30.82)));
if (tcb->m_segmentSize < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh+(85.94)+(65.449)+(tcb->m_segmentSize)+(91.843)+(tcb->m_segmentSize)+(75.38)+(32.816));
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(56.979));

} else {
	tcb->m_cWnd = (int) (9.759+(65.009)+(67.944));
	segmentsAcked = (int) (18.883+(93.881)+(15.284)+(44.852));

}
