ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(83.6)-(62.949));
segmentsAcked = (int) (35.657-(tcb->m_ssThresh)-(36.855)-(81.207)-(85.06)-(73.812)-(43.338)-(86.577));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (52.897-(36.08)-(63.787)-(86.207)-(59.813)-(45.107)-(12.188));
if (tcb->m_cWnd != segmentsAcked) {
	tcb->m_ssThresh = (int) (49.336+(26.047)+(25.255)+(2.85)+(16.775)+(99.407)+(segmentsAcked)+(39.592)+(51.873));

} else {
	tcb->m_ssThresh = (int) (55.587*(tcb->m_ssThresh)*(30.452)*(70.163)*(57.99)*(cnt)*(84.291)*(26.762));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt != tcb->m_cWnd) {
	segmentsAcked = (int) (78.106*(83.893)*(98.949)*(57.378)*(56.329));
	cnt = (int) (tcb->m_segmentSize-(74.235)-(42.266)-(tcb->m_ssThresh)-(52.172)-(98.974)-(88.786)-(36.063));

} else {
	segmentsAcked = (int) (13.301-(14.853)-(15.666)-(18.802));
	ReduceCwnd (tcb);

}
