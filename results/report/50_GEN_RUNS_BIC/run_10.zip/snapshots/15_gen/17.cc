tcb->m_segmentSize = (int) (((81.265)+(4.227)+(23.711)+(0.1)+(6.962))/((75.207)));
float KsVDGRrqZuECYsSq = (float) (44.062+(18.216)+(segmentsAcked)+(84.757)+(30.592)+(68.832)+(tcb->m_cWnd)+(segmentsAcked));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (10.815-(66.375)-(segmentsAcked)-(8.162)-(72.672));
float VGTyQEKHWCvTaHPU = (float) ((((11.973*(15.376)*(tcb->m_ssThresh)*(88.758)))+(63.465)+(0.1)+(57.306))/((93.701)+(0.1)+(8.944)));
if (VGTyQEKHWCvTaHPU >= tcb->m_segmentSize) {
	VGTyQEKHWCvTaHPU = (float) (0.1/0.1);
	tcb->m_segmentSize = (int) (77.79-(55.957));
	ReduceCwnd (tcb);

} else {
	VGTyQEKHWCvTaHPU = (float) (((0.1)+(35.054)+(29.684)+(0.1)+(7.206)+((99.886*(tcb->m_segmentSize)*(7.692)*(78.255)*(tcb->m_ssThresh)*(63.771)))+(0.1))/((0.1)+(39.696)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
