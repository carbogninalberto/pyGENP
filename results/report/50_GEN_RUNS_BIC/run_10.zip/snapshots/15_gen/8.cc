tcb->m_segmentSize = (int) (0.1/99.148);
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(66.16));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/0.1);
	segmentsAcked = (int) (11.392-(43.255));
	cnt = (int) (cnt+(46.34)+(cnt)+(2.849));

} else {
	tcb->m_cWnd = (int) (10.804*(36.161)*(9.559)*(4.693));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (70.927+(tcb->m_ssThresh)+(91.701)+(22.602)+(segmentsAcked)+(80.107)+(97.488)+(97.295));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (24.337+(93.823));

} else {
	tcb->m_cWnd = (int) (96.643-(63.273)-(18.674)-(27.817));
	segmentsAcked = (int) ((((10.011+(22.447)+(47.854)+(tcb->m_segmentSize)+(67.888)+(5.124)+(34.684)+(73.372)+(11.829)))+(61.613)+(23.395)+(0.1)+(29.407)+(61.028))/((1.679)));
	tcb->m_segmentSize = (int) (58.853/21.979);

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
