int MkYwHhLPxkfLmdYK = (int) (tcb->m_ssThresh*(95.785)*(16.752));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
MkYwHhLPxkfLmdYK = (int) (23.182-(tcb->m_cWnd)-(MkYwHhLPxkfLmdYK));
if (tcb->m_ssThresh == tcb->m_segmentSize) {
	cnt = (int) (75.244*(91.823)*(96.545)*(11.002)*(54.211));
	cnt = (int) (68.883+(16.65)+(tcb->m_ssThresh)+(56.664)+(8.296)+(segmentsAcked)+(2.624));

} else {
	cnt = (int) (((79.453)+(0.1)+(0.1)+(0.1)+(48.262))/((0.1)));
	segmentsAcked = (int) (12.727/0.1);
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize <= cnt) {
	MkYwHhLPxkfLmdYK = (int) (56.138+(71.889)+(10.597)+(34.885));
	ReduceCwnd (tcb);

} else {
	MkYwHhLPxkfLmdYK = (int) (22.182*(96.871)*(29.607)*(9.903)*(segmentsAcked)*(21.383)*(5.787)*(3.346)*(37.422));
	segmentsAcked = (int) (9.224+(52.179)+(43.553));
	tcb->m_ssThresh = (int) (74.483-(40.51)-(88.39));

}
