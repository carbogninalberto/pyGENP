cnt = (int) ((97.115*(50.245))/65.649);
ReduceCwnd (tcb);
if (cnt != cnt) {
	tcb->m_ssThresh = (int) (6.881-(cnt)-(48.62)-(35.368)-(2.524)-(26.697)-(tcb->m_segmentSize)-(61.398)-(30.241));
	segmentsAcked = (int) (75.579+(85.557)+(6.47)+(16.307)+(54.868)+(65.407));

} else {
	tcb->m_ssThresh = (int) (cnt-(34.617)-(48.475)-(segmentsAcked));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (tcb->m_ssThresh*(93.173)*(10.712)*(24.588)*(30.181)*(4.158)*(tcb->m_cWnd)*(47.671)*(15.043));
if (tcb->m_ssThresh <= cnt) {
	tcb->m_cWnd = (int) (26.918/63.468);
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (49.984+(12.146)+(83.613)+(79.376)+(67.564)+(60.702));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked < tcb->m_ssThresh) {
	segmentsAcked = (int) (49.032+(99.479));
	tcb->m_cWnd = (int) (1.807-(33.389)-(9.15)-(0.595)-(63.92)-(segmentsAcked));

} else {
	segmentsAcked = (int) (25.666+(15.946)+(34.199)+(37.189)+(70.949)+(24.015)+(12.198)+(88.702)+(44.854));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
