ReduceCwnd (tcb);
if (tcb->m_segmentSize == cnt) {
	tcb->m_segmentSize = (int) (33.345+(cnt));

} else {
	tcb->m_segmentSize = (int) (67.853-(70.824)-(52.436)-(77.166)-(94.531)-(77.5));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
float liGJgeLaEGVLDfby = (float) (50.867-(61.633)-(89.358)-(tcb->m_segmentSize));
ReduceCwnd (tcb);
liGJgeLaEGVLDfby = (float) (liGJgeLaEGVLDfby*(54.403)*(39.804)*(tcb->m_ssThresh)*(42.706)*(50.287));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (tcb->m_ssThresh+(66.05)+(64.349)+(15.917)+(tcb->m_segmentSize)+(70.092)+(27.576)+(tcb->m_ssThresh)+(67.228));
