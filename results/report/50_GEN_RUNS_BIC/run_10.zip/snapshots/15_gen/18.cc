tcb->m_segmentSize = (int) (46.265+(tcb->m_cWnd)+(tcb->m_ssThresh)+(59.718)+(30.142)+(22.425)+(78.007));
tcb->m_segmentSize = (int) (15.839-(38.173)-(11.88)-(32.514)-(74.878)-(12.109)-(4.88));
int HmiUDtBtohGRDPzE = (int) (segmentsAcked+(24.205)+(64.812)+(segmentsAcked)+(4.819)+(67.031)+(57.953)+(5.411));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (HmiUDtBtohGRDPzE != cnt) {
	tcb->m_cWnd = (int) (50.358*(8.681)*(48.879));
	cnt = (int) (tcb->m_cWnd-(29.768)-(92.148)-(44.531)-(36.391)-(88.293));

} else {
	tcb->m_cWnd = (int) (27.301-(81.782));

}
tcb->m_ssThresh = (int) (93.413-(64.45)-(84.375));
if (tcb->m_ssThresh <= HmiUDtBtohGRDPzE) {
	tcb->m_ssThresh = (int) (cnt+(40.327)+(tcb->m_ssThresh)+(cnt)+(55.144)+(23.901)+(38.837)+(29.423));
	tcb->m_ssThresh = (int) (88.956*(4.267)*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(9.55)*(53.021)*(2.552));

} else {
	tcb->m_ssThresh = (int) (89.927/96.976);

}
