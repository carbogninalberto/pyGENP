if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (56.841+(34.698)+(7.627)+(24.012)+(segmentsAcked)+(cnt)+(79.04)+(27.824));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (56.476+(94.345)+(73.647)+(60.899));
cnt = (int) (56.267+(0.699)+(5.707)+(76.794)+(98.092)+(-0.014));
if (cnt == tcb->m_segmentSize) {
	cnt = (int) (tcb->m_segmentSize*(91.61)*(96.273)*(tcb->m_cWnd)*(13.23)*(8.999)*(62.876));

} else {
	cnt = (int) (38.917-(29.398));

}
