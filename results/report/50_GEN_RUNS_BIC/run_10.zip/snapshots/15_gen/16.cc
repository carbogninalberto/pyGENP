ReduceCwnd (tcb);
ReduceCwnd (tcb);
cnt = (int) (tcb->m_cWnd*(41.759)*(34.7)*(53.575)*(tcb->m_ssThresh)*(segmentsAcked)*(18.089)*(40.622)*(94.879));
float DYiSionuVPqANvql = (float) (33.494-(81.721)-(24.683)-(segmentsAcked)-(70.497)-(segmentsAcked)-(5.774)-(82.024)-(75.499));
if (tcb->m_ssThresh < DYiSionuVPqANvql) {
	cnt = (int) ((28.493-(8.966)-(94.185)-(tcb->m_cWnd)-(tcb->m_ssThresh))/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (38.976+(73.888)+(tcb->m_cWnd)+(89.168)+(74.359));

} else {
	cnt = (int) (0.1/26.917);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (tcb->m_segmentSize-(DYiSionuVPqANvql)-(2.956)-(60.865)-(tcb->m_ssThresh));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (0.1/72.328);
