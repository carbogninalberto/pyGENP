if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (88.941+(69.78)+(85.026)+(15.061)+(88.989));
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (44.946-(94.058)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(segmentsAcked)-(43.774)-(77.941)-(93.238)-(tcb->m_ssThresh));
	tcb->m_ssThresh = (int) (59.912-(95.308)-(tcb->m_ssThresh)-(10.564)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(52.942));

} else {
	tcb->m_segmentSize = (int) (64.471+(66.493)+(25.831)+(24.923)+(42.464));

}
float ocgjLMkwwFGZtynX = (float) (61.79-(64.475)-(87.447)-(89.6)-(cnt));
tcb->m_cWnd = (int) (2.294*(ocgjLMkwwFGZtynX)*(61.826)*(35.206)*(39.848)*(54.64));
ReduceCwnd (tcb);
segmentsAcked = (int) (6.253*(79.291));
