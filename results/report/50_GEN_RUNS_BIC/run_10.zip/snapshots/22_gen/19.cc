cnt = (int) (74.214-(97.766));
tcb->m_segmentSize = (int) (23.633-(42.02)-(85.966)-(5.262)-(segmentsAcked)-(44.654)-(88.857)-(25.954));
if (tcb->m_cWnd == segmentsAcked) {
	cnt = (int) ((((14.183+(96.363)+(99.907)+(73.37)+(segmentsAcked)+(segmentsAcked)+(34.147)))+(16.16)+(64.551)+(2.318)+((92.571*(tcb->m_segmentSize)))+(80.195)+(64.59))/((0.1)+(0.1)));

} else {
	cnt = (int) (segmentsAcked-(tcb->m_segmentSize)-(segmentsAcked)-(62.205)-(97.499));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) ((((tcb->m_ssThresh-(92.508)-(tcb->m_ssThresh)))+((tcb->m_segmentSize-(12.798)-(56.075)-(4.675)-(76.024)-(34.443)))+((tcb->m_ssThresh*(95.438)))+(8.909)+(98.503)+(0.1))/((88.622)+(70.526)+(0.1)));
