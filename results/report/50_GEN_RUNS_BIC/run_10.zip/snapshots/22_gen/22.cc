if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (9.879*(2.377)*(93.717)*(tcb->m_cWnd)*(72.306));
tcb->m_ssThresh = (int) (64.458-(82.502)-(tcb->m_segmentSize));
segmentsAcked = (int) (42.446+(95.761)+(12.388)+(60.042)+(91.027)+(24.045));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
