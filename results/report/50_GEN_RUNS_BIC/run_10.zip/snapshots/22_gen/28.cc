int aEzhSvTypgwouTeV = (int) (36.966-(44.881)-(tcb->m_cWnd)-(81.765)-(15.346)-(30.037)-(98.808)-(cnt)-(18.266));
if (tcb->m_ssThresh > aEzhSvTypgwouTeV) {
	aEzhSvTypgwouTeV = (int) (cnt*(88.136)*(69.26)*(26.971)*(71.585)*(89.96)*(0.556)*(44.114));

} else {
	aEzhSvTypgwouTeV = (int) ((((65.234*(14.944)*(63.962)*(74.881)*(33.341)*(91.97)*(91.63)))+(0.1)+(0.1)+(65.394))/((0.1)+(44.823)+(0.1)+(0.1)));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (82.228/(51.492*(tcb->m_ssThresh)*(53.357)*(3.109)*(24.823)*(94.065)*(85.588)*(14.116)*(cnt)));

}
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	cnt = (int) (33.581*(41.19)*(25.199)*(52.56)*(cnt)*(34.546)*(76.731)*(19.556));
	segmentsAcked = (int) ((segmentsAcked+(41.808)+(segmentsAcked)+(24.793))/72.736);

} else {
	cnt = (int) (29.607*(aEzhSvTypgwouTeV)*(92.512)*(14.525));

}
if (aEzhSvTypgwouTeV <= cnt) {
	aEzhSvTypgwouTeV = (int) (5.67+(83.12)+(10.593)+(tcb->m_cWnd)+(84.42)+(0.567)+(62.485)+(80.286));
	tcb->m_cWnd = (int) (7.997-(41.566)-(segmentsAcked)-(21.56)-(segmentsAcked)-(85.733)-(35.974));
	ReduceCwnd (tcb);

} else {
	aEzhSvTypgwouTeV = (int) (60.664-(34.691)-(11.76));
	ReduceCwnd (tcb);
	ReduceCwnd (tcb);

}
if (segmentsAcked > tcb->m_cWnd) {
	cnt = (int) (segmentsAcked+(15.326));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (52.868*(8.244)*(18.307)*(2.206));

}
float UQlAhAIVkETUfuTi = (float) (cnt-(6.382)-(81.488)-(91.85));
aEzhSvTypgwouTeV = (int) (75.012+(UQlAhAIVkETUfuTi));
