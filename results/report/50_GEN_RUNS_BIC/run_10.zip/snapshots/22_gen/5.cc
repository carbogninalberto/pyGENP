tcb->m_cWnd = (int) (0.908-(-38.54)-(89.233)-(-18.069)-(-78.41)-(49.672)-(-25.566));
segmentsAcked = (int) (-71.005*(59.067)*(-23.284)*(28.555)*(-24.743)*(-0.311)*(-63.196));
segmentsAcked = (int) ((10.043-(tcb->m_segmentSize)-(-25.732)-(75.605)-(25.92)-(50.306)-(-5.242))/11.778);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
