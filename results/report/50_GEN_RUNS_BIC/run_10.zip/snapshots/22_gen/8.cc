int nROjOiBFFuqOdUOw = (int) (-84.838-(-80.386)-(44.409)-(3.429));
tcb->m_segmentSize = (int) (21.195+(98.428)+(-89.916));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(37.191)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (-88.581-(-90.182)-(-25.132)-(39.357)-(-0.203)-(-88.603)-(77.962)-(-95.178));
nROjOiBFFuqOdUOw = (int) (-1.722-(-37.202)-(22.488)-(-17.971)-(21.71)-(7.173)-(27.523)-(23.74));
tcb->m_segmentSize = (int) (73.659+(55.269)+(51.778)+(13.353)+(54.988)+(34.317));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (23.258+(93.48)+(-5.63)+(93.012)+(33.525)+(-27.463));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
