int nROjOiBFFuqOdUOw = (int) (-50.067-(65.744)-(-25.786)-(-33.148));
tcb->m_segmentSize = (int) (25.174+(13.109)+(-4.572));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (-62.917-(-32.56)-(-32.384)-(-25.035)-(38.113)-(-79.84)-(-79.653)-(46.8));
tcb->m_segmentSize = (int) (-49.749+(1.264)+(-54.176)+(10.087)+(-6.308)+(-45.777));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
