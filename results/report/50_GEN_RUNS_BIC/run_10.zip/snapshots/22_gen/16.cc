if (tcb->m_ssThresh > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (3.102+(tcb->m_ssThresh)+(42.41)+(27.632));
	tcb->m_segmentSize = (int) (27.082*(26.781)*(93.952)*(56.286));

} else {
	tcb->m_ssThresh = (int) (63.589*(43.199)*(65.108)*(cnt)*(85.783)*(cnt)*(tcb->m_ssThresh));

}
tcb->m_ssThresh = (int) (tcb->m_cWnd-(2.726)-(82.664)-(79.808)-(2.078)-(29.721)-(segmentsAcked));
tcb->m_segmentSize = (int) (88.007/74.626);
if (tcb->m_cWnd <= cnt) {
	tcb->m_segmentSize = (int) ((50.672+(46.892)+(69.918)+(96.452)+(19.219))/47.895);

} else {
	tcb->m_segmentSize = (int) (35.145+(29.387));

}
tcb->m_ssThresh = (int) (52.121*(43.994)*(53.73)*(36.637)*(tcb->m_segmentSize)*(21.612)*(49.399)*(76.936)*(77.885));
