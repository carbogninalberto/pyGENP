tcb->m_cWnd = (int) ((23.525-(59.406))/72.512);
if (segmentsAcked < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/(18.327*(0.096)*(98.151)));
	ReduceCwnd (tcb);
	cnt = (int) ((77.411*(6.998))/(39.141*(96.424)*(tcb->m_cWnd)*(51.61)*(60.826)*(97.707)*(17.314)));

} else {
	tcb->m_cWnd = (int) (26.961+(45.229)+(97.964)+(17.943)+(85.419)+(27.466));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_ssThresh = (int) (69.174*(tcb->m_segmentSize)*(84.338)*(98.218)*(93.043));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (0.1/66.437);
ReduceCwnd (tcb);
if (segmentsAcked <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (23.044+(4.597)+(28.708)+(51.137));
	tcb->m_ssThresh = (int) (23.921-(tcb->m_segmentSize)-(74.969)-(64.84)-(12.132)-(88.027));

} else {
	tcb->m_segmentSize = (int) (8.451+(40.345)+(28.509)+(94.494)+(79.994)+(20.86)+(10.283)+(68.594)+(15.817));
	tcb->m_segmentSize = (int) ((16.946+(98.694)+(82.429)+(4.569))/11.231);
	tcb->m_cWnd = (int) ((((tcb->m_segmentSize*(segmentsAcked)*(cnt)*(62.763)*(52.529)*(30.165)*(12.194)))+((69.066+(86.941)+(tcb->m_ssThresh)+(42.653)+(24.782)+(53.115)+(16.269)+(93.075)+(72.658)))+(0.1)+(0.1)+(59.377))/((0.1)));

}
segmentsAcked = (int) (63.033-(35.932)-(tcb->m_segmentSize)-(6.346)-(cnt)-(39.84)-(49.502)-(18.655));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
