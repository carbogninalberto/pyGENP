cnt = (int) (((0.1)+(0.1)+(20.209)+((58.916+(98.365)))+(0.1)+(0.1)+(0.1)+(0.1))/((26.379)));
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (47.891-(cnt)-(17.059)-(tcb->m_cWnd)-(39.5)-(56.231)-(99.469));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (cnt*(19.104)*(62.912)*(cnt)*(87.051)*(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (70.516+(63.9)+(26.496)+(95.396)+(8.007)+(33.57));
	tcb->m_cWnd = (int) (((0.1)+(90.643)+(73.594)+(0.1))/((0.1)+(0.1)+(43.599)+(64.427)));
	tcb->m_cWnd = (int) (tcb->m_segmentSize-(43.59)-(25.004)-(52.531)-(36.383)-(51.545)-(25.772)-(24.568)-(segmentsAcked));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (68.928*(14.952)*(tcb->m_ssThresh)*(9.056)*(tcb->m_ssThresh)*(38.56)*(25.827)*(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (51.792+(73.11)+(78.156)+(35.965)+(18.484));

} else {
	tcb->m_ssThresh = (int) (66.085*(70.921)*(25.384)*(3.917)*(98.777)*(33.361)*(32.42)*(cnt)*(88.386));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
