if (tcb->m_segmentSize < tcb->m_segmentSize) {
	cnt = (int) (26.631*(48.886)*(36.329)*(84.629)*(tcb->m_segmentSize)*(tcb->m_segmentSize));

} else {
	cnt = (int) (79.197*(73.195)*(19.769)*(tcb->m_cWnd));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (0.1/1.109);
if (tcb->m_segmentSize >= segmentsAcked) {
	tcb->m_cWnd = (int) (71.676+(65.175)+(12.382)+(98.844)+(52.406));

} else {
	tcb->m_cWnd = (int) (86.103*(tcb->m_cWnd)*(54.881)*(78.616)*(segmentsAcked)*(37.154)*(40.218)*(0.436)*(37.366));
	tcb->m_ssThresh = (int) (((0.1)+((tcb->m_cWnd*(3.961)*(31.703)*(40.054)*(15.272)*(44.568)*(cnt)))+((13.471+(79.68)+(segmentsAcked)+(segmentsAcked)))+(0.1)+(71.926))/((0.1)+(64.796)+(0.1)+(0.1)));

}
if (tcb->m_segmentSize > segmentsAcked) {
	tcb->m_segmentSize = (int) (76.705-(44.48)-(33.951)-(91.046)-(23.433)-(33.927)-(19.582));
	cnt = (int) (89.325+(38.331)+(46.342)+(tcb->m_segmentSize)+(4.841));

} else {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh*(76.893));
	cnt = (int) (11.299-(65.553)-(95.057));

}
