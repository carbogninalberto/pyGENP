tcb->m_segmentSize = (int) (2.259*(46.32)*(8.189)*(tcb->m_ssThresh)*(cnt)*(65.685)*(40.99));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt >= tcb->m_cWnd) {
	cnt = (int) (19.624-(63.541)-(69.741)-(cnt));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (0.1/34.797);

}
cnt = (int) (((84.326)+(31.661)+((tcb->m_cWnd*(54.688)*(segmentsAcked)*(61.22)*(54.641)*(87.829)*(11.724)*(45.89)))+(0.1)+((63.914+(42.018)+(tcb->m_ssThresh)))+(0.1))/((0.1)));
if (cnt == cnt) {
	tcb->m_cWnd = (int) (1.856/0.1);

} else {
	tcb->m_cWnd = (int) (62.668-(35.948)-(35.84));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt < cnt) {
	tcb->m_cWnd = (int) (43.555*(65.714)*(95.968)*(57.629)*(tcb->m_cWnd)*(18.268)*(33.211)*(47.685));
	tcb->m_ssThresh = (int) (cnt-(42.526));
	tcb->m_ssThresh = (int) ((tcb->m_cWnd+(tcb->m_segmentSize)+(87.452)+(8.807)+(70.749)+(90.549)+(86.717)+(31.453)+(37.67))/73.657);

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+((65.253*(tcb->m_ssThresh)*(9.176)*(78.276)))+(0.1)+(78.88)+(95.077)+(0.1))/((79.6)+(35.408)));
	tcb->m_cWnd = (int) (28.233*(22.417)*(76.977)*(71.645)*(96.88)*(55.145)*(17.141)*(40.682)*(1.686));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked <= cnt) {
	segmentsAcked = (int) (16.263+(51.447)+(39.093)+(46.622));
	tcb->m_segmentSize = (int) (0.1/0.1);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (10.186/72.749);
	tcb->m_ssThresh = (int) (83.58-(7.202)-(segmentsAcked)-(tcb->m_cWnd));
	cnt = (int) (67.484*(46.079)*(segmentsAcked)*(93.267)*(cnt)*(28.626));

}
if (tcb->m_ssThresh < tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (0.1/31.02);

} else {
	tcb->m_cWnd = (int) (61.01*(91.717)*(16.065)*(48.774)*(33.106)*(55.118)*(94.402));
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(63.746));

}
