float flAZxQssHUpoPnBl = (float) (70.655+(68.151));
if (cnt < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (98.498-(27.682)-(11.925)-(51.259));

} else {
	tcb->m_cWnd = (int) (56.778+(86.895)+(66.863));

}
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((52.543*(89.969)*(0.917)*(37.452)*(90.89))/16.73);
	tcb->m_ssThresh = (int) (29.859*(50.486));
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(tcb->m_ssThresh)-(6.16)-(39.89)-(7.589)-(71.482)-(69.775)-(98.491)-(flAZxQssHUpoPnBl));

} else {
	tcb->m_ssThresh = (int) (0.1/78.156);
	tcb->m_segmentSize = (int) (18.684+(cnt)+(flAZxQssHUpoPnBl));
	cnt = (int) (80.803-(35.761)-(32.633)-(cnt));

}
tcb->m_ssThresh = (int) (60.772-(99.469)-(21.053)-(34.786)-(53.724)-(88.154)-(43.871)-(45.987)-(21.304));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (56.449-(42.297)-(5.572)-(59.633)-(12.428)-(tcb->m_cWnd)-(82.741));
float FxXDEfpcVjMORoVi = (float) (tcb->m_segmentSize-(41.825)-(45.918)-(37.359)-(42.622)-(17.662)-(4.121));
int uQmyVmNupZmDMTyT = (int) (83.817*(83.194)*(36.114));
int KvygJrPJLXxZfMbO = (int) (32.762-(46.684)-(31.238)-(5.617)-(tcb->m_cWnd)-(56.544));
