if (tcb->m_segmentSize > segmentsAcked) {
	cnt = (int) (63.694+(87.854)+(0.561)+(40.086)+(38.909));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (0.1/88.599);

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (7.089+(tcb->m_segmentSize)+(91.112)+(80.226)+(29.318));

} else {
	tcb->m_ssThresh = (int) (22.042*(27.636)*(1.84)*(tcb->m_cWnd)*(72.363)*(90.814));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh >= cnt) {
	tcb->m_cWnd = (int) (segmentsAcked-(22.812)-(tcb->m_segmentSize)-(80.87)-(64.403)-(52.509));
	tcb->m_segmentSize = (int) (80.483-(46.683)-(84.822)-(9.879));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (segmentsAcked+(23.925)+(53.971)+(65.297)+(28.484));
	segmentsAcked = (int) (22.379-(52.794)-(10.223));

}
