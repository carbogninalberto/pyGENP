segmentsAcked = (int) (((0.1)+(79.605)+((68.613*(39.38)*(segmentsAcked)*(88.65)*(78.758)*(95.554)*(12.588)*(14.142)))+(0.1))/((54.398)+(2.522)+(0.1)));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
segmentsAcked = (int) (16.375*(93.765)*(47.971)*(cnt)*(6.002)*(25.482)*(45.622)*(32.484));
