if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked < cnt) {
	tcb->m_cWnd = (int) (56.378-(95.812)-(tcb->m_segmentSize)-(57.669)-(41.301)-(tcb->m_ssThresh)-(tcb->m_segmentSize)-(57.016)-(66.351));
	tcb->m_segmentSize = (int) (73.022-(21.088)-(41.273)-(69.275));
	tcb->m_segmentSize = (int) (37.979*(15.584)*(65.565)*(tcb->m_ssThresh)*(51.38)*(93.81));

} else {
	tcb->m_cWnd = (int) (56.887-(segmentsAcked));
	segmentsAcked = (int) (5.461*(76.508)*(51.513)*(31.953)*(33.829)*(tcb->m_ssThresh)*(55.402));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (segmentsAcked <= cnt) {
	cnt = (int) (28.568-(45.478)-(tcb->m_cWnd)-(46.725)-(segmentsAcked)-(80.992)-(segmentsAcked));
	cnt = (int) ((67.409+(33.171)+(81.334)+(43.992)+(83.361)+(93.745)+(0.758)+(tcb->m_segmentSize))/11.647);

} else {
	cnt = (int) (0.1/30.279);
	tcb->m_ssThresh = (int) (segmentsAcked*(45.798));

}
