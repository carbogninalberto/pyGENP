if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (0.1/30.952);
tcb->m_ssThresh = (int) (92.952*(44.131));
tcb->m_ssThresh = (int) (86.325*(2.598)*(tcb->m_ssThresh)*(59.585)*(65.182)*(tcb->m_segmentSize)*(32.933)*(51.116));
if (tcb->m_cWnd > tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(tcb->m_cWnd)-(13.317)-(41.751)-(9.25)-(72.786)-(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (35.203-(92.371));

} else {
	tcb->m_cWnd = (int) (72.707+(66.95)+(16.256)+(21.601));
	tcb->m_segmentSize = (int) (3.839-(62.281)-(20.905)-(59.14)-(52.148)-(24.451)-(73.755)-(16.367)-(34.011));
	tcb->m_segmentSize = (int) (46.12+(5.875)+(9.889)+(64.738)+(tcb->m_ssThresh)+(cnt)+(11.235)+(0.41));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
