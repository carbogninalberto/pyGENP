if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (82.752*(72.372)*(tcb->m_ssThresh)*(78.111)*(95.195)*(tcb->m_ssThresh)*(29.499)*(3.66)*(16.029));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(58.914)+(9.183))/((0.1)+(24.817)+(0.1)+(26.706)));
	tcb->m_cWnd = (int) (56.235+(tcb->m_ssThresh)+(tcb->m_cWnd)+(55.093)+(63.95)+(18.589)+(5.053)+(cnt));

}
tcb->m_ssThresh = (int) (36.779*(83.134)*(65.097)*(tcb->m_cWnd)*(66.491)*(21.569));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (62.796+(16.185)+(94.17)+(18.321)+(22.701)+(62.056));

} else {
	segmentsAcked = (int) (0.1/50.105);
	tcb->m_cWnd = (int) (34.205*(tcb->m_ssThresh)*(91.713));

}
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(74.627)+(73.696)+(19.955)+(0.764));

} else {
	segmentsAcked = (int) (cnt+(83.582)+(tcb->m_cWnd)+(66.791));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < cnt) {
	tcb->m_cWnd = (int) (19.893*(48.441)*(91.462)*(26.228)*(36.97)*(34.228)*(tcb->m_ssThresh)*(12.143)*(76.84));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (24.462+(91.577)+(10.725)+(68.146)+(87.924)+(82.844)+(38.539)+(57.632)+(39.057));

} else {
	tcb->m_cWnd = (int) (83.277-(74.534)-(18.703)-(98.089)-(3.506)-(25.213));

}
