tcb->m_cWnd = (int) (54.1/0.1);
float MfBgnvkMtzVkbEkd = (float) (40.686-(tcb->m_cWnd)-(61.981)-(62.323));
if (tcb->m_segmentSize != cnt) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(87.576)*(69.216)*(40.904)*(69.115));
	cnt = (int) (69.004/50.236);

} else {
	tcb->m_segmentSize = (int) (19.042+(58.76)+(tcb->m_ssThresh)+(26.909)+(30.599)+(79.179)+(tcb->m_cWnd));
	tcb->m_cWnd = (int) (68.351*(7.151)*(tcb->m_cWnd)*(9.119)*(28.999)*(62.248)*(45.305));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
