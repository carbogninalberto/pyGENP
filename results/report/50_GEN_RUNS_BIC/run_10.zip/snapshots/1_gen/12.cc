float LCxmWwAiOGLtZoPF = (float) (50.289*(segmentsAcked)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(4.021)*(16.22));
tcb->m_ssThresh = (int) (((90.348)+(0.1)+(21.965)+(0.1)+(0.1)+(8.559)+(0.1))/((0.1)+(97.542)));
tcb->m_cWnd = (int) (95.418+(59.481)+(5.615)+(50.111)+(tcb->m_segmentSize)+(41.161));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
