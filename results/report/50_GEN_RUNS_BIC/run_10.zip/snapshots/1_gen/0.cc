ReduceCwnd (tcb);
float mGOtklmGvOuLyLye = (float) (0.1/21.881);
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (mGOtklmGvOuLyLye-(85.225));
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(66.8)*(96.866)*(42.84)*(tcb->m_ssThresh)*(56.235));

} else {
	tcb->m_segmentSize = (int) (82.559-(91.546)-(31.774)-(27.245)-(8.535)-(tcb->m_segmentSize)-(28.301)-(50.809)-(35.615));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (3.213*(tcb->m_segmentSize)*(17.413));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
