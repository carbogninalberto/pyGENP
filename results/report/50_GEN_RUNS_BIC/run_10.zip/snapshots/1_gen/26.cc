float nSfLQDAwTAHECjes = (float) (38.359*(39.754));
ReduceCwnd (tcb);
float pepsmftoGtoxUFba = (float) (41.402*(78.695)*(20.676)*(tcb->m_cWnd)*(59.477));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize >= cnt) {
	segmentsAcked = (int) (59.004*(31.057)*(nSfLQDAwTAHECjes)*(nSfLQDAwTAHECjes)*(34.075));

} else {
	segmentsAcked = (int) (44.342+(23.871)+(35.608)+(36.013)+(cnt)+(77.786)+(segmentsAcked)+(28.832));

}
tcb->m_ssThresh = (int) (66.954/0.1);
