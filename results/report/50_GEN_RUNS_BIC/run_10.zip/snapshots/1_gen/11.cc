int vZeOmpcQdlolXaHl = (int) (4.172-(15.179)-(71.229));
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (((0.1)+(83.669)+(58.126)+((75.978-(16.949)-(25.414)-(cnt)))+(21.782))/((0.1)));

} else {
	tcb->m_segmentSize = (int) (17.019+(0.991)+(tcb->m_ssThresh)+(68.697));
	tcb->m_cWnd = (int) (((64.153)+((87.054-(tcb->m_ssThresh)-(55.098)-(tcb->m_cWnd)-(62.401)-(14.076)-(tcb->m_cWnd)))+(0.1)+(0.1)+(0.1)+(0.1))/((0.1)+(97.171)));
	tcb->m_segmentSize = (int) (3.822+(45.171)+(29.16));

}
float ZAOgcvvuJGfoQPDp = (float) ((27.37*(78.544)*(tcb->m_segmentSize)*(74.58)*(49.948)*(tcb->m_ssThresh)*(70.698))/18.581);
if (tcb->m_ssThresh <= vZeOmpcQdlolXaHl) {
	ZAOgcvvuJGfoQPDp = (float) ((45.556-(53.896)-(95.007))/13.97);

} else {
	ZAOgcvvuJGfoQPDp = (float) (42.54-(54.721)-(61.378));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (73.967+(3.964)+(8.525));
if (vZeOmpcQdlolXaHl <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (18.26+(87.857)+(13.842)+(45.678)+(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (31.775+(tcb->m_ssThresh)+(65.617)+(vZeOmpcQdlolXaHl)+(tcb->m_segmentSize)+(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (vZeOmpcQdlolXaHl+(63.351)+(21.581)+(44.473)+(60.863));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
