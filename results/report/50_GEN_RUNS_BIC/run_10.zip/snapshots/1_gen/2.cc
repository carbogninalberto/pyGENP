if (tcb->m_cWnd < tcb->m_ssThresh) {
	segmentsAcked = (int) (54.708/0.1);
	tcb->m_ssThresh = (int) (cnt*(3.463)*(17.371));

} else {
	segmentsAcked = (int) (29.479+(43.098)+(93.866)+(46.17)+(15.225)+(tcb->m_segmentSize)+(95.47)+(89.169));
	tcb->m_ssThresh = (int) (76.423+(5.772)+(99.765)+(13.916)+(59.951)+(7.542)+(66.121)+(70.188));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (49.884*(75.887)*(95.246));
tcb->m_ssThresh = (int) (90.194+(tcb->m_cWnd)+(cnt)+(12.744)+(59.017)+(63.885)+(tcb->m_ssThresh)+(49.646));
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(segmentsAcked)+(33.69)+(77.729)+(8.227)+(14.826));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (54.567+(73.404)+(20.636));
	tcb->m_cWnd = (int) (99.635-(10.759)-(45.384)-(segmentsAcked));

}
cnt = (int) (0.1/0.1);
tcb->m_ssThresh = (int) (89.461+(42.774)+(24.113)+(62.057)+(62.848)+(12.607)+(tcb->m_cWnd)+(29.043));
ReduceCwnd (tcb);
