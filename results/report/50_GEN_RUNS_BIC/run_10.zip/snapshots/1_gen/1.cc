if (tcb->m_cWnd <= cnt) {
	segmentsAcked = (int) (56.962-(84.121)-(41.202)-(29.344)-(48.313));

} else {
	segmentsAcked = (int) (59.287-(71.482)-(24.556)-(48.444)-(1.568)-(segmentsAcked));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	cnt = (int) (tcb->m_cWnd-(84.625)-(91.663)-(74.943));

}
tcb->m_ssThresh = (int) (34.953-(tcb->m_cWnd)-(87.185)-(68.6)-(84.286)-(86.321));
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_ssThresh = (int) (cnt-(65.568)-(24.753)-(64.714)-(64.082)-(tcb->m_ssThresh)-(44.48));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(73.033)-(61.745)-(38.642)-(43.119)-(48.447)-(20.471));

}
tcb->m_segmentSize = (int) (23.445+(63.95)+(64.252)+(89.9)+(27.326)+(66.788)+(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (41.163*(7.106)*(42.365)*(11.975)*(tcb->m_segmentSize)*(75.18)*(28.031));
tcb->m_ssThresh = (int) (17.366/93.679);
