if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (69.741+(4.458)+(cnt)+(11.472)+(tcb->m_segmentSize)+(tcb->m_cWnd));
tcb->m_ssThresh = (int) (94.773-(82.459)-(91.401));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (0.1/37.316);
