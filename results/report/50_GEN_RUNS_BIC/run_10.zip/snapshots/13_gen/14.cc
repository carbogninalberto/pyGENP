segmentsAcked = (int) (24.488/0.1);
tcb->m_ssThresh = (int) (13.79+(52.403)+(16.502)+(18.282)+(tcb->m_cWnd)+(77.632)+(75.444));
float nJedYFKaxStSAiox = (float) (0.1/(85.095+(10.443)+(31.96)+(38.708)+(77.678)+(66.338)+(4.236)+(segmentsAcked)));
if (nJedYFKaxStSAiox == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (segmentsAcked+(29.673));
	nJedYFKaxStSAiox = (float) (2.187+(31.476)+(0.545));

} else {
	tcb->m_cWnd = (int) (41.088*(57.082)*(nJedYFKaxStSAiox)*(94.305)*(1.82)*(3.6)*(4.716));
	tcb->m_cWnd = (int) (98.87+(segmentsAcked)+(77.12)+(35.918));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (segmentsAcked*(20.877)*(tcb->m_ssThresh)*(18.74)*(88.878)*(tcb->m_cWnd)*(46.353)*(tcb->m_ssThresh));
