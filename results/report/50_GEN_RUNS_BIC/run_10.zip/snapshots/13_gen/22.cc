ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (63.821-(67.166)-(66.809)-(40.237)-(47.653)-(cnt)-(tcb->m_cWnd));
tcb->m_segmentSize = (int) (90.945+(cnt));
if (cnt == cnt) {
	tcb->m_segmentSize = (int) (98.077-(tcb->m_segmentSize)-(75.349)-(45.017)-(29.682)-(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (cnt*(25.395)*(6.094));
	cnt = (int) (66.141-(92.183)-(18.971)-(99.556)-(tcb->m_segmentSize)-(84.924));
	cnt = (int) (73.162/66.751);

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh != segmentsAcked) {
	tcb->m_cWnd = (int) (20.026*(63.642));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (((78.796)+(30.183)+(17.577)+(0.1)+(0.1)+(0.1))/((0.1)));

} else {
	tcb->m_cWnd = (int) (73.372-(69.449)-(tcb->m_segmentSize)-(68.871)-(94.088));
	cnt = (int) (89.853+(63.254)+(7.32)+(16.586));

}
