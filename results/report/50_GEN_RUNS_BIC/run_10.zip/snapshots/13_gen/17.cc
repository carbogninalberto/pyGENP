if (tcb->m_ssThresh == cnt) {
	tcb->m_ssThresh = (int) (36.62+(82.128)+(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (75.33+(19.576)+(99.559)+(89.31)+(10.045));

}
tcb->m_segmentSize = (int) (25.462*(77.496)*(23.555)*(24.957)*(9.837));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (0.1/0.1);
