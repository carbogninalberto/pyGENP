float lougluFNhjHavNht = (float) (18.293*(-61.857)*(35.065)*(-64.887)*(-49.078)*(38.851));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (22.981*(72.588)*(53.16));
tcb->m_segmentSize = (int) (12.899*(59.338)*(78.659));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
