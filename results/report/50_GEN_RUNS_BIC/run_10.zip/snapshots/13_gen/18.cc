segmentsAcked = (int) (38.345*(26.169)*(70.717)*(64.498)*(77.913)*(82.654)*(30.722)*(tcb->m_segmentSize)*(53.592));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (72.571*(59.482)*(12.121)*(24.294)*(26.625)*(46.015)*(tcb->m_ssThresh)*(17.021));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
