float lougluFNhjHavNht = (float) (-24.102*(61.322)*(20.521)*(7.705)*(-47.318)*(-8.552));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
