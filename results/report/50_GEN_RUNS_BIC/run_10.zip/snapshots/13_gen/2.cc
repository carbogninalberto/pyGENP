float lougluFNhjHavNht = (float) (71.133*(-14.051)*(-48.712)*(84.221)*(-41.108)*(46.588));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (55.241*(-71.899)*(50.857));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
