int JUsYiGFxDIbQWjPE = (int) ((38.666-(31.89)-(23.884))/68.697);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) ((14.006-(95.224)-(57.789)-(32.454))/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (tcb->m_cWnd-(30.904)-(98.593));
tcb->m_cWnd = (int) (((50.78)+(0.1)+(0.1)+(57.612))/((0.1)+(0.1)+(57.728)));
tcb->m_segmentSize = (int) (14.095*(14.482)*(34.041)*(62.031)*(JUsYiGFxDIbQWjPE)*(42.459)*(segmentsAcked)*(45.088)*(32.803));
if (cnt <= segmentsAcked) {
	cnt = (int) (8.804+(tcb->m_cWnd)+(76.0)+(58.659));
	tcb->m_ssThresh = (int) (92.12-(14.074)-(88.266)-(cnt)-(tcb->m_segmentSize)-(JUsYiGFxDIbQWjPE));
	tcb->m_cWnd = (int) (95.866+(JUsYiGFxDIbQWjPE)+(84.564)+(tcb->m_cWnd)+(tcb->m_segmentSize)+(94.207)+(24.92)+(37.039)+(79.41));

} else {
	cnt = (int) (82.705/49.417);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
