float ctOAdBQDuAyUXEXA = (float) (48.999-(-10.334)-(-98.573));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-74.844+(-5.38)+(24.639)+(9.025)+(-44.394)+(4.249)+(-32.486)+(24.388));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
