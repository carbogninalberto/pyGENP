tcb->m_segmentSize = (int) (19.852*(33.508)*(-30.803)*(77.529)*(-5.078)*(-22.542)*(-63.713)*(-22.362));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
