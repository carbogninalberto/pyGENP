int nROjOiBFFuqOdUOw = (int) (82.015-(-52.779)-(46.392)-(22.106));
tcb->m_segmentSize = (int) (-83.609+(70.561)+(-52.23));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-19.028)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (-9.908-(-86.921)-(-94.951)-(43.192)-(-74.094)-(-82.125)-(40.42)-(7.496));
tcb->m_segmentSize = (int) (-63.524+(-17.787)+(84.316)+(-60.653)+(-53.698)+(90.123));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
