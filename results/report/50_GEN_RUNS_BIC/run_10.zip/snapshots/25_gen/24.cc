if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
segmentsAcked = (int) (23.389+(3.231)+(tcb->m_cWnd)+(5.718)+(43.327)+(tcb->m_segmentSize)+(98.133)+(segmentsAcked));
cnt = (int) (42.715*(tcb->m_ssThresh)*(81.325)*(tcb->m_ssThresh)*(26.885)*(38.985)*(49.244)*(tcb->m_ssThresh)*(43.217));
cnt = (int) (4.689*(86.146));
