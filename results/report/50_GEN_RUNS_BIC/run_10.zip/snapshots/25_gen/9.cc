tcb->m_segmentSize = (int) (81.706+(-47.167)+(29.522));
int nROjOiBFFuqOdUOw = (int) (-98.661-(71.855)-(-11.182)-(-52.606));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
nROjOiBFFuqOdUOw = (int) (0.091-(-27.112)-(96.086)-(98.116)-(-8.155)-(0.676)-(88.156)-(-85.544));
tcb->m_segmentSize = (int) (-31.5+(94.099)+(-50.895)+(6.196)+(27.356)+(-69.24));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
