if (tcb->m_cWnd != tcb->m_cWnd) {
	segmentsAcked = (int) (((99.103)+(38.033)+(2.808)+(85.686))/((0.1)));

} else {
	segmentsAcked = (int) (62.756+(10.799)+(7.608)+(-27.837)+(86.405)+(50.485));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-48.591+(77.489)+(-85.977)+(-51.739));
