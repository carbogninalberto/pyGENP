if (tcb->m_cWnd == cnt) {
	tcb->m_cWnd = (int) (75.842*(22.424)*(9.603)*(15.016)*(tcb->m_cWnd));

} else {
	tcb->m_cWnd = (int) (63.903*(11.323)*(23.426)*(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (30.215-(60.427)-(48.641)-(tcb->m_cWnd)-(cnt));
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(84.759)-(32.439)-(tcb->m_ssThresh)-(36.611)-(20.689)-(67.438));

}
segmentsAcked = (int) (77.012+(48.62));
if (segmentsAcked <= cnt) {
	cnt = (int) (tcb->m_ssThresh+(48.963)+(50.98)+(tcb->m_cWnd));
	cnt = (int) (segmentsAcked-(90.394)-(tcb->m_ssThresh)-(72.025)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(70.149)-(14.354));
	cnt = (int) (46.096*(29.314)*(24.109));

} else {
	cnt = (int) (tcb->m_segmentSize-(30.784)-(21.857));
	cnt = (int) (86.094+(84.004)+(67.433)+(48.904)+(64.88)+(52.495));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd == cnt) {
	tcb->m_segmentSize = (int) (38.297+(96.093)+(76.202)+(tcb->m_cWnd)+(0.932)+(47.317)+(91.436)+(segmentsAcked)+(20.355));
	tcb->m_cWnd = (int) (78.375-(tcb->m_cWnd)-(segmentsAcked)-(77.477)-(38.886)-(85.921)-(93.23)-(tcb->m_ssThresh));

} else {
	tcb->m_segmentSize = (int) (29.49*(65.184)*(61.105)*(segmentsAcked));

}
