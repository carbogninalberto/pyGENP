if (tcb->m_ssThresh < tcb->m_cWnd) {
	cnt = (int) (9.109/56.492);
	tcb->m_cWnd = (int) (79.731*(tcb->m_segmentSize)*(73.551)*(90.056)*(36.576)*(21.075)*(77.472)*(tcb->m_segmentSize));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (68.294*(30.211)*(segmentsAcked)*(58.146)*(49.412)*(tcb->m_segmentSize)*(97.853)*(81.919));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) (65.916*(40.287)*(85.2)*(25.347)*(cnt)*(1.82)*(tcb->m_segmentSize));
	segmentsAcked = (int) (16.357/0.1);
	tcb->m_cWnd = (int) (((94.684)+(28.642)+(0.1)+((tcb->m_segmentSize*(15.485)*(49.266)*(91.103)*(41.349)*(75.166)))+(0.1))/((0.1)));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(tcb->m_cWnd)*(16.825)*(cnt));
	tcb->m_segmentSize = (int) (0.1/53.188);
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(tcb->m_cWnd)+(64.642)+(42.377)+(75.8)+(2.589));

}
if (tcb->m_cWnd < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (91.417*(95.424)*(80.921)*(92.139)*(83.268)*(tcb->m_segmentSize)*(0.149)*(10.276)*(51.785));
	segmentsAcked = (int) (13.512+(22.661)+(14.487)+(53.185)+(22.542)+(66.553));
	segmentsAcked = (int) (62.449*(48.482)*(90.775)*(75.656)*(segmentsAcked)*(tcb->m_cWnd)*(11.739)*(21.22));

} else {
	tcb->m_cWnd = (int) (tcb->m_ssThresh-(39.898)-(88.528)-(51.616));
	ReduceCwnd (tcb);

}
if (cnt < tcb->m_segmentSize) {
	segmentsAcked = (int) (49.39+(segmentsAcked)+(81.693)+(2.956)+(tcb->m_segmentSize)+(53.598)+(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (((45.516)+((26.663-(tcb->m_segmentSize)-(35.284)-(7.285)-(92.669)))+(73.889)+(0.1))/((95.983)+(5.475)+(48.383)+(0.1)));

} else {
	segmentsAcked = (int) (23.403+(11.602));

}
ReduceCwnd (tcb);
