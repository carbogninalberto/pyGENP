ReduceCwnd (tcb);
if (cnt >= segmentsAcked) {
	tcb->m_segmentSize = (int) (0.839*(57.453)*(29.189)*(81.767)*(70.432)*(6.567)*(44.011));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (tcb->m_segmentSize*(25.671));

} else {
	tcb->m_segmentSize = (int) (42.766+(80.72)+(segmentsAcked)+(98.937)+(tcb->m_segmentSize)+(tcb->m_ssThresh));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	segmentsAcked = (int) (tcb->m_segmentSize+(80.626)+(66.278)+(34.741));
	tcb->m_cWnd = (int) (83.603*(22.14)*(tcb->m_ssThresh)*(91.534)*(79.996)*(92.653)*(96.919)*(46.665)*(78.188));

} else {
	segmentsAcked = (int) (66.08+(tcb->m_cWnd)+(94.478)+(72.184)+(46.389));
	tcb->m_ssThresh = (int) (((0.1)+(89.338)+(79.055)+(79.464))/((58.229)+(77.43)+(69.131)));
	tcb->m_ssThresh = (int) (42.263*(81.141)*(52.202)*(13.654)*(7.921)*(tcb->m_segmentSize)*(85.752)*(82.839)*(28.112));

}
tcb->m_ssThresh = (int) (42.271+(tcb->m_segmentSize)+(37.004));
