cnt = (int) (60.367+(52.462)+(47.707));
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(78.806)-(42.182)-(97.703));
	tcb->m_ssThresh = (int) (60.317-(tcb->m_segmentSize)-(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (33.646-(84.189)-(31.945));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (32.07*(14.773)*(88.88));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (48.125*(32.989));
	tcb->m_cWnd = (int) (11.096+(segmentsAcked)+(76.033)+(96.939));
	cnt = (int) (53.292*(segmentsAcked)*(62.326)*(96.234)*(31.033)*(15.988)*(30.143)*(34.811));

} else {
	tcb->m_segmentSize = (int) (33.875-(0.925)-(8.484)-(92.46)-(63.951));

}
tcb->m_cWnd = (int) (tcb->m_cWnd+(segmentsAcked)+(50.719)+(cnt));
