int nROjOiBFFuqOdUOw = (int) (-91.203-(-62.366)-(30.736)-(-20.724));
tcb->m_segmentSize = (int) (66.148+(13.502)+(8.435));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-58.442)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (40.967-(-56.223)-(23.862)-(51.121)-(89.426)-(21.447)-(39.154)-(19.727));
tcb->m_segmentSize = (int) (2.505+(45.267)+(84.561)+(-97.633)+(-68.939)+(-66.457));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
