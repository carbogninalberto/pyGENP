tcb->m_segmentSize = (int) (-58.595+(56.918)+(37.641));
int nROjOiBFFuqOdUOw = (int) (85.652-(-35.428)-(-37.79)-(-86.214));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-43.889)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (8.573-(59.743)-(4.072)-(53.159)-(-67.593)-(-65.948)-(43.093)-(9.095));
tcb->m_segmentSize = (int) (5.532+(-64.301)+(-64.354)+(-29.797)+(92.861)+(-37.63));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
