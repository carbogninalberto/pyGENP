if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int iXipgwLzRfBmLGVC = (int) (17.365*(-80.652)*(35.171)*(-20.753)*(85.065)*(-66.87)*(-48.665));
float HUGZKwGEyUEvAVSG = (float) (68.963-(38.526)-(75.036)-(18.76)-(-79.817));
