if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float xPYWMdBrvIUKezFK = (float) (44.625-(-36.468)-(-57.566)-(68.481)-(-93.633)-(10.236)-(-63.883)-(81.6)-(-11.593));
segmentsAcked = (int) (14.535-(55.011));
