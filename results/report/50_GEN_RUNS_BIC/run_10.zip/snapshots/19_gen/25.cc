cnt = (int) (84.583*(67.847)*(tcb->m_segmentSize)*(49.451)*(28.712)*(77.527)*(70.991)*(4.216)*(cnt));
ReduceCwnd (tcb);
int BPnyGOYhpCTCDnhq = (int) (18.033+(19.409)+(tcb->m_ssThresh));
BPnyGOYhpCTCDnhq = (int) (6.578-(25.353)-(79.455)-(66.136)-(segmentsAcked)-(tcb->m_segmentSize));
tcb->m_cWnd = (int) (53.227*(tcb->m_segmentSize)*(99.885)*(tcb->m_cWnd));
ReduceCwnd (tcb);
