if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float xUyrsavUffLgbztI = (float) (71.151-(tcb->m_ssThresh)-(tcb->m_cWnd)-(3.026)-(73.583));
if (cnt <= xUyrsavUffLgbztI) {
	tcb->m_cWnd = (int) (41.985-(segmentsAcked));
	xUyrsavUffLgbztI = (float) (87.864*(44.236)*(56.136)*(tcb->m_ssThresh)*(56.387)*(38.682)*(33.995)*(65.099)*(42.771));

} else {
	tcb->m_cWnd = (int) (xUyrsavUffLgbztI*(46.761)*(63.036));

}
tcb->m_ssThresh = (int) (tcb->m_segmentSize+(82.407)+(48.099)+(55.84)+(19.551)+(97.403));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
