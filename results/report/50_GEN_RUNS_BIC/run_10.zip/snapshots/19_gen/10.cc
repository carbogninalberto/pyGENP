int nROjOiBFFuqOdUOw = (int) (-99.781-(19.823)-(-57.029)-(-34.973));
tcb->m_segmentSize = (int) (-72.814+(-49.761)+(22.689));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-14.913)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
nROjOiBFFuqOdUOw = (int) (-98.072-(-46.195)-(-13.302)-(-76.91)-(5.808)-(-1.721)-(-48.572)-(27.972));
tcb->m_segmentSize = (int) (43.165+(50.393)+(-22.988)+(73.374)+(3.151)+(-90.263));
tcb->m_segmentSize = (int) (-5.81+(51.636)+(-60.676));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(17.958)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (38.512-(18.596)-(-82.992)-(74.735)-(63.837)-(-50.972)-(-32.715)-(40.192));
tcb->m_segmentSize = (int) (43.801+(17.709)+(45.222)+(85.304)+(-60.391)+(-54.017));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
