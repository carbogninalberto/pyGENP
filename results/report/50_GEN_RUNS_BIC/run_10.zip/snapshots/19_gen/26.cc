if (cnt <= tcb->m_segmentSize) {
	segmentsAcked = (int) (83.997*(segmentsAcked)*(cnt)*(81.085)*(40.275)*(71.507)*(81.469)*(17.587)*(63.101));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (tcb->m_ssThresh*(11.211)*(24.572)*(17.414));

} else {
	segmentsAcked = (int) (((67.625)+((30.766+(tcb->m_ssThresh)+(2.288)+(91.607)+(38.127)+(tcb->m_ssThresh)+(25.171)))+(47.611)+(57.552)+(78.001))/((0.1)+(36.123)+(45.324)));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (segmentsAcked == tcb->m_ssThresh) {
	segmentsAcked = (int) (((0.1)+(0.1)+(36.252)+(0.1)+(0.1)+(32.869))/((83.734)+(4.46)));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(85.693)*(77.138)*(96.038)*(55.471)*(14.175)*(7.124));
	segmentsAcked = (int) (91.895+(tcb->m_segmentSize)+(48.249)+(tcb->m_segmentSize)+(88.953));

}
if (segmentsAcked >= tcb->m_ssThresh) {
	cnt = (int) (76.746*(89.957)*(10.613)*(30.097)*(51.196)*(98.415)*(82.024));
	segmentsAcked = (int) (segmentsAcked-(segmentsAcked)-(94.23)-(28.604)-(74.332)-(35.995)-(98.089));
	tcb->m_ssThresh = (int) (58.949-(27.105));

} else {
	cnt = (int) ((((72.501+(94.558)+(25.876)+(5.384)+(45.712)))+(96.785)+(53.716)+(37.619))/((42.525)+(53.58)+(0.1)+(12.565)+(67.309)));

}
tcb->m_cWnd = (int) (0.1/2.412);
if (cnt <= cnt) {
	segmentsAcked = (int) (62.253*(tcb->m_ssThresh)*(20.381)*(48.517));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) ((67.214*(82.187)*(67.101)*(59.208)*(tcb->m_ssThresh)*(15.868)*(40.608)*(26.663))/71.794);

}
ReduceCwnd (tcb);
