ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (0.1/50.105);
	tcb->m_cWnd = (int) (34.205*(71.255)*(91.713));

} else {
	segmentsAcked = (int) (62.796+(16.185)+(94.17)+(18.321)+(22.701)+(62.056));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (62.796+(16.185)+(94.17)+(18.321)+(22.701)+(62.056));

} else {
	segmentsAcked = (int) (0.1/50.105);
	tcb->m_cWnd = (int) (34.205*(65.819)*(91.713));

}
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(74.627)+(73.696)+(19.955)+(0.764));

} else {
	segmentsAcked = (int) (-99.816+(83.582)+(tcb->m_cWnd)+(66.791));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (62.796+(16.185)+(94.17)+(18.321)+(22.701)+(62.056));

} else {
	segmentsAcked = (int) (0.1/50.105);
	tcb->m_cWnd = (int) (34.205*(65.819)*(91.713));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(74.627)+(73.696)+(19.955)+(0.764));

} else {
	segmentsAcked = (int) (-99.816+(83.582)+(tcb->m_cWnd)+(66.791));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(74.627)+(73.696)+(19.955)+(0.764));

} else {
	segmentsAcked = (int) (-50.285+(83.582)+(tcb->m_cWnd)+(66.791));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(74.627)+(73.696)+(19.955)+(0.764));

} else {
	segmentsAcked = (int) (-50.285+(83.582)+(tcb->m_cWnd)+(66.791));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (62.796+(16.185)+(94.17)+(18.321)+(22.701)+(62.056));

} else {
	segmentsAcked = (int) (0.1/50.105);
	tcb->m_cWnd = (int) (34.205*(71.255)*(91.713));

}
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(74.627)+(73.696)+(19.955)+(0.764));

} else {
	segmentsAcked = (int) (-50.285+(83.582)+(tcb->m_cWnd)+(66.791));

}
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (62.796+(16.185)+(94.17)+(18.321)+(22.701)+(62.056));

} else {
	segmentsAcked = (int) (0.1/50.105);
	tcb->m_cWnd = (int) (34.205*(71.255)*(91.713));

}
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(74.627)+(73.696)+(19.955)+(0.764));

} else {
	segmentsAcked = (int) (-50.285+(83.582)+(tcb->m_cWnd)+(66.791));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (62.796+(16.185)+(94.17)+(18.321)+(22.701)+(62.056));

} else {
	segmentsAcked = (int) (0.1/50.105);
	tcb->m_cWnd = (int) (34.205*(71.255)*(91.713));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < tcb->m_segmentSize) {
	segmentsAcked = (int) (62.796+(16.185)+(94.17)+(18.321)+(22.701)+(62.056));

} else {
	segmentsAcked = (int) (0.1/50.105);
	tcb->m_cWnd = (int) (34.205*(71.255)*(91.713));

}
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(74.627)+(73.696)+(19.955)+(0.764));

} else {
	segmentsAcked = (int) (-99.816+(83.582)+(tcb->m_cWnd)+(66.791));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(74.627)+(73.696)+(19.955)+(0.764));

} else {
	segmentsAcked = (int) (-99.816+(83.582)+(tcb->m_cWnd)+(66.791));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(74.627)+(73.696)+(19.955)+(0.764));

} else {
	segmentsAcked = (int) (-99.816+(83.582)+(tcb->m_cWnd)+(66.791));

}
ReduceCwnd (tcb);
if (tcb->m_cWnd < segmentsAcked) {
	segmentsAcked = (int) (segmentsAcked+(74.627)+(73.696)+(19.955)+(0.764));

} else {
	segmentsAcked = (int) (-99.816+(83.582)+(tcb->m_cWnd)+(66.791));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
