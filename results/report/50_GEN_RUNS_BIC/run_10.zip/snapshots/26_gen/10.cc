int nROjOiBFFuqOdUOw = (int) (-19.388-(-12.095)-(-97.246)-(-26.382));
tcb->m_segmentSize = (int) (-24.765+(6.97)+(-75.091));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(28.939)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (-30.678-(-72.733)-(-75.711)-(86.622)-(-85.695)-(-9.344)-(-63.344)-(-0.401));
tcb->m_segmentSize = (int) (57.884+(-7.745)+(-89.943));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(15.829)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
tcb->m_segmentSize = (int) (-51.009+(4.931)+(-12.099)+(49.473)+(-25.382)+(-94.788));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
nROjOiBFFuqOdUOw = (int) (36.406-(-98.091)-(53.59)-(-98.098)-(26.988)-(-98.982)-(-51.161)-(55.717));
tcb->m_segmentSize = (int) (84.831+(75.711)+(-48.117)+(92.678)+(81.304)+(-49.922));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
