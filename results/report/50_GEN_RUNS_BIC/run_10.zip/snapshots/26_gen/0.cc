int nROjOiBFFuqOdUOw = (int) (-78.784-(-71.268)-(59.061)-(-90.301));
tcb->m_segmentSize = (int) (-86.545+(97.355)+(51.152));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-52.738)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (49.395-(-62.708)-(56.818)-(-32.0)-(39.023)-(-67.644)-(-61.767)-(24.475));
tcb->m_segmentSize = (int) (-16.679+(-6.91)+(6.769)+(-6.739)+(-62.275)+(63.521));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
