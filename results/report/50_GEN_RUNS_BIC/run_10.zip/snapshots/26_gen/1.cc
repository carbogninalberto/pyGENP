tcb->m_segmentSize = (int) (-14.926+(33.929)+(-6.76));
int nROjOiBFFuqOdUOw = (int) (25.713-(-10.492)-(-75.661)-(86.008));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-19.028)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
nROjOiBFFuqOdUOw = (int) (12.68-(11.543)-(-17.497)-(-76.635)-(72.692)-(87.641)-(40.41)-(81.617));
tcb->m_segmentSize = (int) (-26.494+(22.671)+(36.429)+(30.996)+(-63.505)+(-92.112));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
