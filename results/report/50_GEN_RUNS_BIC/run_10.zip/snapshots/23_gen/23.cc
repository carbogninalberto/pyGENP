ReduceCwnd (tcb);
if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_cWnd = (int) ((((23.483-(cnt)-(13.9)-(2.065)-(cnt)-(71.096)-(19.561)))+(0.1)+(0.1)+(51.022))/((37.158)));

} else {
	tcb->m_cWnd = (int) (94.374+(95.628)+(tcb->m_cWnd)+(41.044)+(tcb->m_ssThresh)+(56.886)+(87.207)+(10.31));
	segmentsAcked = (int) (96.878-(cnt)-(tcb->m_cWnd));

}
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (76.641*(98.978)*(32.139));

} else {
	tcb->m_ssThresh = (int) (33.269-(17.966)-(tcb->m_segmentSize)-(tcb->m_cWnd)-(97.537)-(41.861)-(14.246));
	tcb->m_ssThresh = (int) (27.968-(segmentsAcked));
	segmentsAcked = (int) (((0.1)+(89.155)+(0.1)+((10.417-(48.036)-(2.803)-(tcb->m_segmentSize)))+(60.112)+(52.266)+(0.1))/((0.1)));

}
tcb->m_ssThresh = (int) (94.076*(13.049)*(segmentsAcked));
if (cnt < segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_ssThresh-(5.001)-(71.615)-(65.932)-(87.43));
	segmentsAcked = (int) (43.544*(54.74)*(59.009)*(17.13)*(tcb->m_segmentSize)*(tcb->m_ssThresh)*(segmentsAcked)*(tcb->m_cWnd)*(41.143));

} else {
	tcb->m_segmentSize = (int) ((20.065*(84.936)*(46.15)*(28.031)*(22.913))/36.321);
	cnt = (int) ((tcb->m_cWnd-(3.236)-(46.232)-(32.055)-(cnt))/76.128);

}
tcb->m_ssThresh = (int) (tcb->m_ssThresh-(23.447)-(63.506)-(73.214)-(cnt)-(tcb->m_ssThresh));
