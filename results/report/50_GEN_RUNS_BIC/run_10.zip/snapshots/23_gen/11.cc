float zKNPIZdfanTSlWyp = (float) (22.541+(-72.307)+(-56.951)+(-33.232)+(64.108)+(66.35)+(-68.669));
tcb->m_segmentSize = (int) (32.944/45.838);
