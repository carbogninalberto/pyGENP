if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int osCGyiiZqmbZCnTt = (int) (12.649*(90.234)*(98.854));
osCGyiiZqmbZCnTt = (int) (28.191-(81.003)-(tcb->m_cWnd)-(34.578)-(tcb->m_segmentSize)-(segmentsAcked)-(cnt)-(60.489));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (osCGyiiZqmbZCnTt < segmentsAcked) {
	tcb->m_cWnd = (int) (48.827*(osCGyiiZqmbZCnTt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	segmentsAcked = (int) (59.473+(65.032));

} else {
	tcb->m_cWnd = (int) (((15.651)+(0.1)+(5.702)+(0.1)+(69.102)+(50.531))/((34.864)+(78.298)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	osCGyiiZqmbZCnTt = (int) (((0.1)+(0.1)+(83.077)+(0.1))/((0.1)));

}
if (segmentsAcked > osCGyiiZqmbZCnTt) {
	osCGyiiZqmbZCnTt = (int) (segmentsAcked+(43.187)+(55.923)+(46.206));

} else {
	osCGyiiZqmbZCnTt = (int) ((((71.634-(cnt)))+(77.287)+(72.688)+((tcb->m_ssThresh*(26.044)*(26.163)*(74.748)*(19.702)*(92.307)*(95.786)*(52.682)*(osCGyiiZqmbZCnTt)))+(0.1)+(70.96)+(0.1))/((54.795)+(84.383)));
	ReduceCwnd (tcb);
	segmentsAcked = (int) (((0.1)+(85.797)+((25.092+(0.095)+(2.552)+(87.967)+(45.345)+(30.757)+(42.702)+(93.813)))+(34.852)+(0.1)+(0.1))/((0.1)+(13.829)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
