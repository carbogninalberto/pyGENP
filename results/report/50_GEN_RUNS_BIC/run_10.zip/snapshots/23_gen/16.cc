if (segmentsAcked == segmentsAcked) {
	tcb->m_segmentSize = (int) ((((1.415*(88.14)*(81.658)*(15.452)*(50.891)*(44.937)*(63.589)))+(0.1)+(0.1)+(70.263)+(16.214)+(0.1)+(46.204))/((0.1)));
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (79.657*(13.263)*(97.22)*(76.344)*(50.433)*(30.345)*(60.434));
	tcb->m_cWnd = (int) (61.005/0.1);

}
cnt = (int) (46.217+(71.163)+(74.417)+(62.5)+(82.523)+(cnt)+(43.722));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (43.649*(83.068)*(84.87)*(90.802)*(61.688)*(78.741)*(16.576)*(segmentsAcked)*(95.6));
