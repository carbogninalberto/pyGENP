int vLOirIypnLtwmrnO = (int) ((-31.534-(45.31)-(38.393))/13.374);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
vLOirIypnLtwmrnO = (int) (38.007-(-55.235)-(-98.102)-(-93.762)-(81.526)-(23.863)-(41.261));
segmentsAcked = (int) (-96.595+(32.884));
