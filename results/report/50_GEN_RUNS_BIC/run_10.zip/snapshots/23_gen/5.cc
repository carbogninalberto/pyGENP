if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-79.77*(10.562)*(-1.947)*(-26.244)*(26.767));
segmentsAcked = (int) (-7.433+(90.77)+(13.969)+(80.226)+(12.965)+(-41.924));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
