tcb->m_cWnd = (int) (87.701+(18.237)+(95.017)+(72.259)+(23.694));
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (tcb->m_cWnd*(65.244)*(10.396));
	cnt = (int) (18.864+(segmentsAcked));
	tcb->m_segmentSize = (int) (55.053*(2.936)*(63.886)*(46.598));

} else {
	tcb->m_segmentSize = (int) (21.298+(52.997)+(60.842)+(96.122)+(35.035));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int KibDTHapLuinatDn = (int) (0.1/9.415);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (59.132+(KibDTHapLuinatDn)+(cnt)+(22.757));
KibDTHapLuinatDn = (int) (30.167*(81.733)*(50.042)*(75.382)*(80.954));
tcb->m_segmentSize = (int) (80.761-(tcb->m_segmentSize)-(28.927)-(7.894)-(51.203));
if (tcb->m_cWnd < KibDTHapLuinatDn) {
	tcb->m_ssThresh = (int) (27.494-(91.514)-(9.388)-(tcb->m_segmentSize)-(2.019)-(tcb->m_ssThresh));

} else {
	tcb->m_ssThresh = (int) (20.522+(KibDTHapLuinatDn)+(57.399));

}
