if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (0.1/32.485);
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (52.218*(19.239)*(tcb->m_segmentSize)*(17.818)*(92.02));
	cnt = (int) (47.944-(45.84)-(84.24)-(14.703)-(80.262)-(15.715)-(43.188)-(tcb->m_ssThresh));

}
segmentsAcked = (int) (23.257-(71.2)-(28.037)-(8.654)-(tcb->m_segmentSize));
if (segmentsAcked >= segmentsAcked) {
	cnt = (int) (40.376/18.296);

} else {
	cnt = (int) (segmentsAcked-(23.32));
	segmentsAcked = (int) (tcb->m_segmentSize*(1.523)*(cnt)*(19.622)*(65.387));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
