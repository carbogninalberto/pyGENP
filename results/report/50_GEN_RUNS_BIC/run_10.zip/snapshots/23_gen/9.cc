tcb->m_segmentSize = (int) (-13.978+(-50.466)+(72.527));
int nROjOiBFFuqOdUOw = (int) (58.459-(64.497)-(6.945)-(29.214));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(37.191)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (-25.339-(-84.592)-(61.382)-(-42.058)-(-64.696)-(-42.432)-(-17.456)-(-85.594));
nROjOiBFFuqOdUOw = (int) (97.947-(18.414)-(89.387)-(-8.539)-(92.005)-(2.709)-(72.658)-(-32.318));
tcb->m_segmentSize = (int) (54.246+(2.146)+(71.871)+(72.13)+(11.921)+(99.993));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (10.6+(-31.263)+(-16.439)+(-59.822)+(-64.982)+(24.156));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
