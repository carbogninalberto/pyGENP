if (cnt >= tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (44.32-(6.67)-(27.602)-(72.309));
	tcb->m_segmentSize = (int) (73.041+(77.84)+(cnt)+(57.424)+(95.975)+(segmentsAcked));

} else {
	tcb->m_ssThresh = (int) (55.682+(89.815)+(52.736)+(70.917)+(25.71)+(29.307));
	segmentsAcked = (int) (tcb->m_ssThresh-(46.129)-(32.633)-(75.818)-(segmentsAcked)-(78.925)-(42.559));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (53.415+(69.147)+(2.698));
tcb->m_segmentSize = (int) (97.511+(cnt)+(cnt)+(50.935)+(11.916)+(67.108)+(32.056));
