tcb->m_segmentSize = (int) (14.596+(-44.115)+(-99.087));
int nROjOiBFFuqOdUOw = (int) (-36.66-(76.578)-(80.967)-(-45.205));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
nROjOiBFFuqOdUOw = (int) (-67.919-(-78.544)-(42.454)-(27.927)-(68.229)-(24.921)-(0.51)-(89.953));
tcb->m_segmentSize = (int) (-72.618+(-20.943)+(-80.229)+(-81.048)+(-78.631)+(29.75));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
