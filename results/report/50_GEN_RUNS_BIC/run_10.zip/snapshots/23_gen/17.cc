ReduceCwnd (tcb);
if (tcb->m_ssThresh > tcb->m_cWnd) {
	cnt = (int) (tcb->m_segmentSize-(84.652));

} else {
	cnt = (int) (37.925-(0.788)-(39.238)-(tcb->m_segmentSize)-(92.71)-(63.606)-(14.074));

}
ReduceCwnd (tcb);
float QbRLqBFSNXpiQWbc = (float) (86.908*(37.027)*(15.549)*(55.33)*(tcb->m_cWnd)*(32.551)*(99.664)*(78.058));
float gZatBjmwFNKcWJjG = (float) (23.658/0.1);
tcb->m_cWnd = (int) (0.1/0.1);
ReduceCwnd (tcb);
