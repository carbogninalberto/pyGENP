int nROjOiBFFuqOdUOw = (int) (-8.971-(-19.285)-(-53.212)-(-87.74));
tcb->m_segmentSize = (int) (1.552+(-51.435)+(34.542));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(37.191)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (49.768-(-5.209)-(-20.976)-(20.21)-(-16.319)-(60.881)-(79.432)-(44.908));
nROjOiBFFuqOdUOw = (int) (-37.641-(-82.945)-(-97.743)-(-53.668)-(8.489)-(37.883)-(-46.354)-(-76.286));
tcb->m_segmentSize = (int) (50.869+(13.351)+(-68.822)+(-89.335)+(-71.378)+(68.105));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (-69.609+(49.299)+(-11.968)+(-56.27)+(91.095)+(50.526));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
