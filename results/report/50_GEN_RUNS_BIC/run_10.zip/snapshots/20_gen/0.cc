int nROjOiBFFuqOdUOw = (int) (91.452-(61.932)-(56.436)-(-80.694));
tcb->m_segmentSize = (int) (-89.31+(-6.701)+(-77.887));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (18.866-(-16.715)-(79.098)-(88.435)-(46.217)-(-4.463)-(-87.948)-(65.212));
tcb->m_segmentSize = (int) (51.858+(-33.885)+(54.903)+(21.164)+(-33.77)+(41.181));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
