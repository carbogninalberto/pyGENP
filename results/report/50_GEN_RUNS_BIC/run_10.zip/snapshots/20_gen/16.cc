ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (53.733-(69.132)-(53.791)-(86.379)-(45.952)-(11.298)-(6.766));
tcb->m_ssThresh = (int) (39.311+(94.746)+(4.816)+(88.84)+(42.617)+(26.006)+(50.198)+(44.525));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
