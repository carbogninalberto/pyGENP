ReduceCwnd (tcb);
int kPWdduRWXyoGuREH = (int) (87.482*(-10.898)*(74.234)*(-3.273)*(-45.956)*(-26.252));
tcb->m_segmentSize = (int) (-80.046*(-44.757)*(19.232)*(82.534)*(-6.787)*(53.749)*(13.45)*(53.007));
segmentsAcked = (int) (-17.041/0.428);
ReduceCwnd (tcb);
