if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (96.61+(5.602)+(98.536)+(50.991));
tcb->m_cWnd = (int) (87.292-(9.931)-(56.304));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd < segmentsAcked) {
	cnt = (int) (32.599-(89.575)-(78.078)-(45.591)-(tcb->m_ssThresh)-(3.636)-(15.622));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (((0.1)+((92.955-(89.239)-(31.467)-(19.121)-(segmentsAcked)-(20.951)))+(0.1)+(0.1))/((13.803)+(44.167)+(31.483)+(40.591)));

} else {
	cnt = (int) (((0.1)+(72.552)+(0.1)+(39.744)+(99.425)+(0.1)+(0.1)+(0.1))/((0.1)));

}
if (tcb->m_cWnd != cnt) {
	tcb->m_segmentSize = (int) (92.433-(50.595)-(71.548)-(tcb->m_segmentSize)-(39.032)-(tcb->m_ssThresh)-(83.245)-(5.349)-(78.475));

} else {
	tcb->m_segmentSize = (int) (51.09-(53.792)-(75.049));

}
