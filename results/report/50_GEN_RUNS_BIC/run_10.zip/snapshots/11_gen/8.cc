float TetOVCQXVqRXHCyv = (float) (2.944+(-70.924)+(-83.273)+(-48.25)+(-50.656)+(-83.741)+(-70.314));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_segmentSize = (int) (-52.265-(-75.31)-(-40.017)-(32.962)-(82.758)-(-89.792)-(-86.198)-(-38.012)-(1.573));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
