if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(0.87)*(9.53));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) ((((tcb->m_segmentSize-(45.293)-(1.053)-(98.597)-(84.823)))+((4.046*(32.634)*(87.887)*(79.057)*(1.723)))+(0.1)+(51.451)+(0.1)+(2.882)+(33.678))/((0.1)+(83.536)));

} else {
	tcb->m_segmentSize = (int) (18.416*(segmentsAcked)*(93.906)*(23.432)*(segmentsAcked)*(tcb->m_segmentSize)*(28.553)*(tcb->m_cWnd));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (-70.227*(52.748)*(-90.268)*(-45.16)*(6.799)*(67.089)*(-80.564)*(-40.348));
