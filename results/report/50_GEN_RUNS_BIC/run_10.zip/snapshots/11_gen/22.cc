ReduceCwnd (tcb);
tcb->m_cWnd = (int) (66.016+(82.031));
if (cnt != segmentsAcked) {
	tcb->m_segmentSize = (int) (85.457*(74.887)*(31.498)*(27.02)*(60.954)*(66.68)*(56.316));

} else {
	tcb->m_segmentSize = (int) (39.903*(tcb->m_ssThresh)*(86.512)*(45.676)*(17.324)*(15.254)*(15.568)*(42.758));

}
cnt = (int) (36.579+(32.126)+(95.399)+(3.833)+(99.381)+(tcb->m_segmentSize));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
