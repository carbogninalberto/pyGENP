ReduceCwnd (tcb);
if (tcb->m_ssThresh < cnt) {
	cnt = (int) ((((48.621+(35.988)+(tcb->m_ssThresh)+(68.799)))+(0.1)+(0.1)+(0.1))/((43.736)+(15.94)));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (84.858+(64.337)+(35.344)+(80.854)+(18.922)+(80.089)+(85.004)+(tcb->m_ssThresh));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
if (tcb->m_cWnd > cnt) {
	tcb->m_cWnd = (int) (80.736-(65.597)-(7.663)-(2.992)-(47.188)-(57.241)-(56.041));

} else {
	tcb->m_cWnd = (int) (24.814+(6.535)+(18.344)+(99.741)+(82.753));

}
int UkhfRoeuGQvYDXXV = (int) (cnt-(75.442)-(58.688)-(40.747)-(tcb->m_cWnd)-(5.842)-(97.905)-(42.515));
UkhfRoeuGQvYDXXV = (int) (23.895+(1.809)+(77.799)+(UkhfRoeuGQvYDXXV)+(53.267)+(26.894));
if (tcb->m_ssThresh != cnt) {
	tcb->m_cWnd = (int) (segmentsAcked-(48.473)-(37.244)-(95.197));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (43.435*(77.685)*(9.481)*(84.16)*(12.955)*(20.007)*(12.922)*(73.613));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (23.917*(55.565));

}
int CerhPjsCTQPwRjSl = (int) (55.881-(tcb->m_ssThresh)-(40.36)-(8.28)-(54.332)-(64.111)-(39.145)-(67.35)-(15.061));
