if (cnt >= segmentsAcked) {
	tcb->m_ssThresh = (int) (6.311+(41.296)+(10.393)+(47.316)+(56.804)+(tcb->m_segmentSize)+(tcb->m_segmentSize));
	tcb->m_segmentSize = (int) (43.869*(97.48)*(segmentsAcked)*(71.218)*(69.547)*(16.818));

} else {
	tcb->m_ssThresh = (int) (52.436-(46.768)-(59.774)-(7.779)-(78.493)-(65.94)-(35.408));

}
if (cnt > tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (30.16/0.1);
	cnt = (int) (((60.858)+(0.1)+(1.385)+(0.1)+(0.1))/((67.15)));

} else {
	tcb->m_ssThresh = (int) (85.179-(8.579));
	tcb->m_ssThresh = (int) ((37.57*(40.677)*(59.733))/0.1);
	tcb->m_segmentSize = (int) (97.99-(38.31)-(13.912)-(28.859)-(21.631)-(38.581)-(32.715)-(85.482)-(45.586));

}
if (segmentsAcked != segmentsAcked) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(44.554)*(33.149));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(66.57)+(0.1)+(0.1))/((45.784)));
	segmentsAcked = (int) (27.361-(97.886)-(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((17.809-(46.463)-(63.561)-(93.916)-(84.344)-(67.573)-(tcb->m_ssThresh)-(91.885))/(7.571-(92.106)-(13.416)-(11.415)-(73.338)-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(93.146)-(39.366)));
	tcb->m_segmentSize = (int) (77.362+(32.807)+(15.823));
	tcb->m_cWnd = (int) (cnt*(36.431)*(93.033)*(tcb->m_cWnd)*(60.137)*(7.502)*(71.7));

} else {
	tcb->m_ssThresh = (int) (64.934-(12.068)-(86.274)-(70.079)-(tcb->m_segmentSize)-(37.04)-(3.804)-(tcb->m_cWnd)-(84.788));
	tcb->m_cWnd = (int) (17.932*(79.666)*(tcb->m_cWnd));
	segmentsAcked = (int) (78.004/80.035);

}
ReduceCwnd (tcb);
