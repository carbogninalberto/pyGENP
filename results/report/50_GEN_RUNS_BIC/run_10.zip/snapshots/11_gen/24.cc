if (tcb->m_segmentSize > cnt) {
	cnt = (int) ((4.548-(44.955)-(26.866)-(0.601)-(82.371)-(73.498))/0.1);

} else {
	cnt = (int) (35.94-(96.413)-(39.48)-(65.802)-(27.353)-(45.51)-(60.092)-(23.409));
	segmentsAcked = (int) (((34.037)+(68.355)+(0.1)+(46.283)+(65.044)+((65.715-(58.135)-(18.289)-(82.655)))+(8.046))/((0.1)));

}
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (36.588+(90.32)+(2.394)+(55.985));

} else {
	tcb->m_ssThresh = (int) (79.148+(69.743)+(89.213)+(2.783)+(93.247)+(1.467)+(42.683));

}
tcb->m_cWnd = (int) (72.383-(78.739)-(segmentsAcked)-(99.014)-(20.798)-(79.981)-(86.686)-(58.395));
if (cnt >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) ((((52.704-(55.884)-(31.088)))+(0.1)+(0.1)+(13.589)+((tcb->m_cWnd-(86.247)-(14.724)-(tcb->m_segmentSize)-(10.472)))+(83.255))/((0.1)+(93.175)+(32.358)));
	segmentsAcked = (int) (63.226*(43.391)*(85.127)*(80.051)*(37.07)*(84.53));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	tcb->m_ssThresh = (int) (73.433*(tcb->m_cWnd)*(tcb->m_segmentSize)*(63.748)*(segmentsAcked)*(24.205)*(4.408)*(78.852));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (cnt != tcb->m_cWnd) {
	tcb->m_segmentSize = (int) ((tcb->m_cWnd*(tcb->m_ssThresh)*(29.947)*(70.267)*(27.322)*(tcb->m_cWnd)*(24.443)*(53.068)*(cnt))/19.883);

} else {
	tcb->m_segmentSize = (int) (73.785+(79.475)+(80.03)+(52.707)+(22.023)+(4.715)+(40.327)+(59.34)+(9.814));
	tcb->m_cWnd = (int) (40.972-(3.027));

}
float XNCQPmgwZBUlvrFa = (float) (94.58*(2.679)*(90.121)*(cnt));
if (XNCQPmgwZBUlvrFa < tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (45.887+(46.914)+(66.776)+(72.173)+(96.538)+(78.327));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (54.805+(56.519));

}
