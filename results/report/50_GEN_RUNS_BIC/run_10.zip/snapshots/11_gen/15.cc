ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (((0.1)+(70.017)+((73.461+(14.036)+(2.797)+(tcb->m_ssThresh)+(7.704)))+(39.037))/((0.1)+(28.354)));
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (0.1/96.999);
if (cnt >= segmentsAcked) {
	segmentsAcked = (int) (86.369*(43.316)*(76.284)*(51.173)*(64.557)*(segmentsAcked)*(71.762));
	tcb->m_segmentSize = (int) (17.188+(tcb->m_segmentSize)+(29.451)+(40.476)+(13.539)+(25.819)+(73.14)+(60.916));

} else {
	segmentsAcked = (int) (61.133*(28.642)*(94.834)*(97.116)*(tcb->m_ssThresh)*(segmentsAcked)*(64.57)*(69.365));

}
int JfdSXYHlRiWzyizI = (int) (30.429*(cnt));
if (tcb->m_ssThresh > cnt) {
	cnt = (int) (7.795*(53.081)*(94.288)*(89.154)*(38.063)*(93.661)*(65.065)*(47.342));
	tcb->m_segmentSize = (int) (87.157*(98.074)*(76.781)*(tcb->m_cWnd));
	cnt = (int) (55.979*(75.953)*(15.725)*(tcb->m_ssThresh)*(99.581)*(17.418)*(3.209)*(44.775)*(cnt));

} else {
	cnt = (int) (56.14+(37.651)+(84.574)+(segmentsAcked));
	tcb->m_ssThresh = (int) (7.406+(cnt));

}
float WHfVLklhSinhMzoJ = (float) (91.793*(JfdSXYHlRiWzyizI)*(12.813)*(9.148)*(11.908));
if (WHfVLklhSinhMzoJ == WHfVLklhSinhMzoJ) {
	cnt = (int) (WHfVLklhSinhMzoJ*(15.223)*(58.158)*(8.608)*(13.028)*(99.926)*(WHfVLklhSinhMzoJ));

} else {
	cnt = (int) (JfdSXYHlRiWzyizI*(65.918)*(5.538)*(12.145)*(25.009)*(46.544)*(48.814)*(78.643));
	tcb->m_cWnd = (int) (39.509-(38.33)-(67.32)-(51.62)-(54.152)-(5.852)-(87.819));
	cnt = (int) (cnt*(WHfVLklhSinhMzoJ)*(11.215)*(83.031)*(49.718)*(28.18)*(74.261));

}
