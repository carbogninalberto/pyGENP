float TetOVCQXVqRXHCyv = (float) (-98.717+(50.366)+(24.429)+(-83.681)+(24.292)+(63.099)+(-94.817));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int dhYNcUJRSAryylMP = (int) (-40.583-(90.62)-(9.347));
tcb->m_segmentSize = (int) (-70.647-(77.286)-(-9.653)-(-49.435)-(-23.92)-(-0.822)-(5.948)-(-35.1)-(16.07));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
