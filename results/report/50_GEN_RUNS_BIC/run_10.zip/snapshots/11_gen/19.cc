if (tcb->m_ssThresh != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (42.18-(2.897));

} else {
	tcb->m_ssThresh = (int) (60.841-(28.986)-(14.925)-(tcb->m_ssThresh)-(16.924)-(82.112)-(13.898)-(7.494)-(79.958));
	tcb->m_ssThresh = (int) (38.912-(48.207));
	tcb->m_segmentSize = (int) (7.491-(74.604)-(10.504)-(segmentsAcked)-(92.017)-(6.901)-(7.793)-(85.079)-(47.779));

}
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (83.673-(31.222)-(71.348)-(cnt)-(tcb->m_ssThresh));

} else {
	tcb->m_cWnd = (int) (19.4*(60.127)*(93.03)*(19.926)*(6.794)*(43.441)*(79.22));
	tcb->m_ssThresh = (int) (77.55+(37.479)+(9.8)+(31.528));
	cnt = (int) (tcb->m_cWnd-(68.103)-(78.308));

}
if (tcb->m_cWnd > segmentsAcked) {
	cnt = (int) (38.569+(62.94));
	cnt = (int) (((60.003)+(0.1)+(0.1)+(53.102))/((11.112)));

} else {
	cnt = (int) (tcb->m_segmentSize+(15.042)+(3.904)+(60.605)+(8.211)+(87.359)+(51.828));

}
if (tcb->m_ssThresh < segmentsAcked) {
	tcb->m_segmentSize = (int) (50.566-(11.591)-(29.424)-(22.114)-(55.734)-(54.731)-(19.342)-(tcb->m_cWnd)-(34.005));
	tcb->m_segmentSize = (int) (29.021+(9.017));
	tcb->m_cWnd = (int) ((tcb->m_segmentSize+(76.474)+(22.665)+(54.633)+(72.982))/0.1);

} else {
	tcb->m_segmentSize = (int) (tcb->m_cWnd-(12.719)-(54.031)-(46.9));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd <= segmentsAcked) {
	tcb->m_cWnd = (int) ((11.328-(95.899)-(9.697)-(tcb->m_segmentSize)-(cnt)-(22.676)-(cnt)-(20.81)-(68.6))/72.163);
	tcb->m_cWnd = (int) (25.973-(63.277)-(83.34)-(63.054)-(96.177)-(75.741)-(66.095));

} else {
	tcb->m_cWnd = (int) (87.91+(97.272)+(23.153)+(tcb->m_ssThresh)+(84.171)+(cnt));

}
