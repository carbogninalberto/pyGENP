tcb->m_cWnd = (int) (-34.345-(-57.166)-(-91.161)-(-55.411)-(-50.131)-(37.464));
int AHSRpvEsKZRwGcgk = (int) (-75.233/-79.009);
segmentsAcked = (int) (-89.706+(-26.102)+(-29.911));
float NJOgCfVkYYXcOoiG = (float) (44.63-(-8.413)-(89.704)-(15.983)-(-94.064)-(-76.097)-(-28.433));
ReduceCwnd (tcb);
