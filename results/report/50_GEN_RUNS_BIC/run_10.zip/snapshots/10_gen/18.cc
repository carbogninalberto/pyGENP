ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (segmentsAcked+(12.293)+(cnt)+(38.247)+(segmentsAcked)+(67.841)+(86.206)+(43.507)+(87.354));

} else {
	tcb->m_ssThresh = (int) (18.3-(39.074)-(65.53)-(93.374)-(segmentsAcked)-(cnt)-(39.084));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (0.1/0.1);
ReduceCwnd (tcb);
int BVjpWRApBbqQRJMi = (int) (26.118-(38.599)-(26.198)-(9.033)-(63.463));
if (BVjpWRApBbqQRJMi == tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (0.1/24.737);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (5.467-(tcb->m_cWnd)-(57.08)-(tcb->m_ssThresh)-(57.627)-(38.476)-(tcb->m_cWnd));
	cnt = (int) (57.115+(22.664));

}
tcb->m_ssThresh = (int) (85.106*(76.063)*(11.884)*(54.008)*(10.839));
segmentsAcked = (int) (31.896/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
