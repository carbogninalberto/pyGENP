int fNJSMMUIpDflgAHK = (int) (68.442/10.464);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float TetOVCQXVqRXHCyv = (float) (2.812+(93.446)+(48.799)+(1.467)+(38.636)+(20.124)+(-89.763));
tcb->m_segmentSize = (int) (-21.257-(-89.297)-(26.44)-(11.475)-(-98.108)-(-57.719)-(2.94)-(-39.928)-(-4.572));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
