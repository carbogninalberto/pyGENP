if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh >= cnt) {
	segmentsAcked = (int) (segmentsAcked-(58.292)-(tcb->m_ssThresh)-(68.042)-(70.298)-(cnt)-(tcb->m_cWnd)-(tcb->m_ssThresh)-(51.626));

} else {
	segmentsAcked = (int) (86.29-(tcb->m_ssThresh)-(8.985)-(tcb->m_cWnd)-(17.744));
	tcb->m_ssThresh = (int) (8.108-(cnt)-(tcb->m_ssThresh)-(28.721));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize < segmentsAcked) {
	cnt = (int) (40.958+(69.786)+(42.445)+(77.067)+(38.447)+(77.723)+(69.569)+(10.595));

} else {
	cnt = (int) (49.955*(33.597)*(41.735)*(84.432)*(60.046));
	tcb->m_ssThresh = (int) (45.751+(cnt));
	tcb->m_cWnd = (int) (23.855-(tcb->m_cWnd)-(61.751));

}
tcb->m_cWnd = (int) (13.418-(98.321)-(96.305)-(99.422)-(54.699));
float MNoREdPokocNPlru = (float) (8.386*(60.93)*(59.738));
