float uTGcLSEyAzxKfhDI = (float) 59.85;
