segmentsAcked = (int) (13.606-(99.299)-(16.35));
ReduceCwnd (tcb);
if (tcb->m_ssThresh <= tcb->m_segmentSize) {
	cnt = (int) (tcb->m_cWnd+(71.248)+(50.529)+(71.894)+(93.349));
	tcb->m_cWnd = (int) (25.51+(48.101)+(tcb->m_ssThresh)+(cnt)+(9.684));

} else {
	cnt = (int) (49.078-(30.451)-(41.739)-(94.021)-(tcb->m_segmentSize)-(9.631));

}
tcb->m_segmentSize = (int) (22.001*(18.978)*(7.364)*(30.128)*(92.762)*(tcb->m_cWnd)*(40.105)*(11.113));
segmentsAcked = (int) (0.1/71.151);
if (tcb->m_cWnd < tcb->m_cWnd) {
	cnt = (int) (10.848-(18.785)-(20.886)-(cnt)-(76.754)-(29.968)-(21.543)-(61.843)-(68.317));
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	cnt = (int) (99.936+(tcb->m_segmentSize)+(41.558)+(segmentsAcked)+(10.342));
	ReduceCwnd (tcb);

}
ReduceCwnd (tcb);
