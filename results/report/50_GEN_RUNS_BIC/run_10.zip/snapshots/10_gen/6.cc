int cYPYcTLhyukgZWOy = (int) (-68.084-(51.833)-(-58.089));
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (80.817/0.1);

} else {
	tcb->m_segmentSize = (int) (20.796-(2.819)-(24.852)-(85.091)-(88.298)-(41.944)-(30.729)-(73.437)-(38.066));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cYPYcTLhyukgZWOy = (int) (-78.893-(75.542)-(98.613)-(78.609));
ReduceCwnd (tcb);
