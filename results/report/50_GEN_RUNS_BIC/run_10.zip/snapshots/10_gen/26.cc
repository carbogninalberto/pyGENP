if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (23.291+(0.105));

} else {
	tcb->m_segmentSize = (int) (59.038*(3.714)*(segmentsAcked)*(49.057));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (22.724*(tcb->m_ssThresh)*(50.206)*(41.158)*(81.095)*(4.44));

}
if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(0.87)*(9.53));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) ((((tcb->m_segmentSize-(45.293)-(1.053)-(98.597)-(84.823)))+((4.046*(32.634)*(87.887)*(79.057)*(1.723)))+(0.1)+(51.451)+(0.1)+(2.882)+(33.678))/((0.1)+(83.536)));

} else {
	tcb->m_segmentSize = (int) (18.416*(segmentsAcked)*(93.906)*(23.432)*(segmentsAcked)*(tcb->m_segmentSize)*(28.553)*(tcb->m_cWnd));
	ReduceCwnd (tcb);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
tcb->m_segmentSize = (int) (26.824*(29.834)*(75.6)*(47.679)*(79.84)*(tcb->m_segmentSize)*(16.166)*(tcb->m_segmentSize));
if (tcb->m_segmentSize < cnt) {
	tcb->m_segmentSize = (int) (50.264-(17.445));

} else {
	tcb->m_segmentSize = (int) (44.631+(58.748)+(34.75)+(55.437)+(87.575));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (83.204-(36.537));
