tcb->m_cWnd = (int) (tcb->m_segmentSize-(cnt)-(52.803)-(77.138)-(49.893));
ReduceCwnd (tcb);
if (cnt >= tcb->m_segmentSize) {
	cnt = (int) (59.816-(7.927)-(54.227)-(2.393));
	cnt = (int) (0.514+(41.186)+(67.938)+(91.853)+(96.274)+(cnt));

} else {
	cnt = (int) (78.126*(77.54));
	tcb->m_segmentSize = (int) (0.526+(22.245)+(tcb->m_ssThresh)+(cnt)+(73.606)+(53.537)+(20.021)+(98.838));
	cnt = (int) ((65.648*(6.62))/0.1);

}
if (tcb->m_segmentSize < tcb->m_cWnd) {
	cnt = (int) (33.061*(63.821)*(26.317)*(76.754)*(46.227)*(86.646)*(12.052));
	segmentsAcked = (int) (73.676-(33.888)-(56.242)-(tcb->m_cWnd)-(26.145)-(51.385));

} else {
	cnt = (int) (38.08*(89.15));
	ReduceCwnd (tcb);

}
if (cnt >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (24.77-(85.206)-(41.146)-(segmentsAcked));

} else {
	tcb->m_cWnd = (int) (79.674-(41.435)-(85.88)-(13.791)-(23.535)-(segmentsAcked)-(55.906)-(32.488)-(26.899));
	tcb->m_ssThresh = (int) (73.543+(77.579)+(53.423)+(92.826)+(85.093)+(tcb->m_cWnd));

}
