if (segmentsAcked >= cnt) {
	cnt = (int) (10.129/46.703);
	segmentsAcked = (int) (tcb->m_ssThresh*(31.941)*(tcb->m_segmentSize)*(12.599)*(23.086)*(84.592)*(83.494)*(26.366));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (0.1/71.655);

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(20.452)+(cnt));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_ssThresh = (int) (85.359-(13.306));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt == tcb->m_cWnd) {
	cnt = (int) (67.194-(11.737));

} else {
	cnt = (int) (0.1/0.1);

}
ReduceCwnd (tcb);
