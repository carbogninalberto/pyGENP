float mGOtklmGvOuLyLye = (float) (97.678/-63.167);
ReduceCwnd (tcb);
if (segmentsAcked < tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (mGOtklmGvOuLyLye-(85.225));
	tcb->m_cWnd = (int) (tcb->m_segmentSize*(66.8)*(96.866)*(42.84)*(-66.404)*(56.235));

} else {
	tcb->m_segmentSize = (int) (82.559-(91.546)-(31.774)-(27.245)-(8.535)-(tcb->m_segmentSize)-(28.301)-(50.809)-(35.615));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
