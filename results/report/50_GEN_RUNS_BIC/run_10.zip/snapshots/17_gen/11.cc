float gMSBbdQsXZbHNPjj = (float) 84.484;
tcb->m_segmentSize = (int) (((-61.451)+((tcb->m_ssThresh-(24.6)-(-36.384)-(66.095)-(95.735)-(21.199)-(13.015)-(61.764)))+(22.175)+(15.727)+(17.03))/((-30.329)+(-57.664)));
ReduceCwnd (tcb);
