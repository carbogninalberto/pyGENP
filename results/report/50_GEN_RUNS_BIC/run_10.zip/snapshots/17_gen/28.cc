int xwRhyZBLcwNIHfFT = (int) (36.934*(-40.857)*(-17.564)*(-40.365)*(41.216)*(2.36)*(65.948));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (5.942/13.31);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-43.717*(-12.608)*(-17.795)*(-46.907));
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (99.439+(54.05)+(-51.965)+(23.385));
