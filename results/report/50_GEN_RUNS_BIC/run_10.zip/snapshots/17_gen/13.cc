tcb->m_cWnd = (int) (75.403+(80.418)+(-49.487)+(70.097));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (14.177-(-59.321));
