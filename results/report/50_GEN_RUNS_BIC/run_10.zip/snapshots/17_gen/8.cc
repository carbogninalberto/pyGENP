float tzFUMnGIGPcLDiSV = (float) (-8.968*(75.223)*(-7.947)*(77.632)*(-3.673)*(35.438));
tcb->m_cWnd = (int) (5.141-(-25.72)-(27.957)-(12.18));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
