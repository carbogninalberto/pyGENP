if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (42.216-(47.051));
int zBKDejwVlQTzNLnc = (int) (69.895+(90.0)+(-12.942)+(-75.153)+(-28.681)+(93.494)+(84.588));
segmentsAcked = (int) (51.353-(-49.055));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
