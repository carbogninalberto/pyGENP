float JBWIkUCJPnYMqFol = (float) 95.457;
