int nROjOiBFFuqOdUOw = (int) (89.772-(38.014)-(55.283)-(-25.448));
tcb->m_segmentSize = (int) (-32.471+(42.721)+(27.92));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-84.882)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (-37.739-(48.711)-(3.107)-(64.842)-(48.808)-(-93.011)-(96.588)-(56.605));
nROjOiBFFuqOdUOw = (int) (-49.567-(-42.442)-(89.574)-(-48.674)-(93.246)-(6.447)-(-7.295)-(73.878));
tcb->m_segmentSize = (int) (86.134+(-57.694)+(1.049)+(-57.442)+(-67.254)+(66.353));
tcb->m_segmentSize = (int) (80.984+(-27.63)+(-16.954)+(-44.691)+(86.202)+(-75.246));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
