int nROjOiBFFuqOdUOw = (int) (51.22-(96.994)-(-53.86)-(81.0));
tcb->m_segmentSize = (int) (-53.31+(62.8)+(35.852));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(71.614)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (22.345-(-44.168)-(40.842)-(72.225)-(26.443)-(-26.581)-(66.402)-(11.914));
tcb->m_segmentSize = (int) (33.072+(-57.413)+(-21.516)+(-1.405)+(-80.483)+(-77.526));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
