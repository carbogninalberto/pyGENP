segmentsAcked = (int) (-0.626/-78.548);
int xwRhyZBLcwNIHfFT = (int) (-80.665*(63.351)*(86.343)*(-53.546)*(77.591)*(45.96)*(4.285));
int SIWhiEGWZThnMYJq = (int) (69.498-(-15.277)-(-75.4)-(82.376)-(-6.563));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (-72.222*(55.735)*(-90.582)*(41.95));
tcb->m_cWnd = (int) (43.597+(-48.011)+(59.079)+(66.613));
