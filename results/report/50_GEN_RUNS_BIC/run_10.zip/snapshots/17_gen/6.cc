float lkdEbckGnHwwVynB = (float) (93.026+(-43.881)+(-88.303)+(38.449)+(32.217)+(-65.382)+(9.008)+(-22.883));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
lkdEbckGnHwwVynB = (float) (-80.213+(-51.253)+(54.885)+(-27.176)+(73.347));
