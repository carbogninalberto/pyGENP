if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (79.897+(84.244)+(7.116));
if (tcb->m_segmentSize < cnt) {
	tcb->m_cWnd = (int) (48.952+(8.282)+(16.676)+(53.163));
	tcb->m_segmentSize = (int) (80.439+(tcb->m_segmentSize)+(52.609)+(90.095)+(80.142)+(38.002)+(91.555));

} else {
	tcb->m_cWnd = (int) (segmentsAcked+(55.5)+(tcb->m_ssThresh)+(tcb->m_cWnd)+(84.781)+(48.753)+(45.527)+(98.087)+(87.776));

}
segmentsAcked = (int) (0.1/79.94);
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (42.106-(41.345)-(tcb->m_segmentSize)-(60.403));
	tcb->m_ssThresh = (int) (10.159*(segmentsAcked)*(35.276)*(74.834));

} else {
	tcb->m_ssThresh = (int) (24.304/39.723);

}
float OzEVpMwrXVEvZKZx = (float) (42.399-(tcb->m_segmentSize)-(67.892)-(cnt)-(39.504)-(33.263)-(92.806)-(44.344)-(20.899));
ReduceCwnd (tcb);
segmentsAcked = (int) (69.001*(25.288)*(37.746)*(tcb->m_cWnd));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
