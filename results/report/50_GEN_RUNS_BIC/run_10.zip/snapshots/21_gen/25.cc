if (segmentsAcked <= tcb->m_cWnd) {
	cnt = (int) (34.932/0.1);
	tcb->m_cWnd = (int) (72.925+(5.571)+(35.882));

} else {
	cnt = (int) (((0.1)+(5.239)+(0.1)+(0.1)+(11.175)+(44.596))/((0.1)));
	cnt = (int) (8.754+(segmentsAcked));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float PUHrWnrqVtsKFGoH = (float) (80.28+(cnt)+(tcb->m_cWnd)+(tcb->m_ssThresh)+(12.744)+(segmentsAcked)+(30.357)+(92.468)+(51.65));
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize != segmentsAcked) {
	tcb->m_cWnd = (int) (64.808+(PUHrWnrqVtsKFGoH)+(PUHrWnrqVtsKFGoH));

} else {
	tcb->m_cWnd = (int) (30.609-(36.046)-(58.871)-(20.459)-(50.022)-(81.864));
	ReduceCwnd (tcb);

}
tcb->m_ssThresh = (int) (36.325+(85.69)+(87.901));
ReduceCwnd (tcb);
