float vjgvGaEEQnuUBqEe = (float) (69.255+(23.375)+(22.526)+(-29.181));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-15.335+(78.769)+(21.536)+(74.879)+(-53.331)+(-95.715)+(10.048)+(-39.89));
ReduceCwnd (tcb);
