int bUrKUDrGKZhvQGrb = (int) 7.193;
