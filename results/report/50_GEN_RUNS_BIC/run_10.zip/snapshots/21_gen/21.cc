tcb->m_cWnd = (int) (7.549-(tcb->m_segmentSize)-(65.633)-(60.248)-(92.105)-(24.392)-(9.315));
if (cnt != tcb->m_cWnd) {
	tcb->m_cWnd = (int) (5.184-(tcb->m_ssThresh)-(26.013)-(29.032)-(segmentsAcked)-(4.317)-(62.247));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_cWnd = (int) (90.236+(62.401)+(cnt)+(17.681)+(6.384)+(8.7)+(93.795));

}
segmentsAcked = (int) (tcb->m_segmentSize*(31.963)*(tcb->m_ssThresh)*(59.725)*(17.954)*(cnt)*(11.106));
segmentsAcked = (int) ((70.037-(tcb->m_segmentSize)-(87.448)-(87.371)-(40.649)-(50.648)-(segmentsAcked))/0.1);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
