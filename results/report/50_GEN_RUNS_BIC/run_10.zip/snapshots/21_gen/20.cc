if (tcb->m_ssThresh < tcb->m_segmentSize) {
	segmentsAcked = (int) (41.809-(tcb->m_cWnd)-(15.337)-(22.528)-(62.949)-(89.2));

} else {
	segmentsAcked = (int) (((65.58)+((62.328+(58.739)+(11.037)+(tcb->m_cWnd)))+(0.1)+(0.1)+(0.1)+(0.1)+(91.046))/((0.1)+(0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize < tcb->m_cWnd) {
	segmentsAcked = (int) (78.206+(31.103)+(cnt)+(33.92)+(47.009)+(33.843)+(tcb->m_cWnd)+(25.051));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (tcb->m_cWnd-(42.669)-(68.635)-(87.48)-(tcb->m_ssThresh)-(tcb->m_cWnd));

}
tcb->m_segmentSize = (int) (((0.1)+(87.037)+(0.1)+(5.789)+(22.775))/((0.1)+(81.018)+(38.466)+(0.1)));
if (cnt <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (segmentsAcked+(24.449)+(37.177)+(12.993)+(67.561));
	cnt = (int) (28.187*(48.896)*(cnt)*(27.293)*(63.052));
	segmentsAcked = (int) (38.739-(87.793)-(8.964)-(tcb->m_cWnd)-(96.388)-(58.227)-(2.133)-(tcb->m_ssThresh)-(11.571));

} else {
	tcb->m_cWnd = (int) (((0.1)+(66.002)+(42.719)+(0.1)+(0.1))/((12.464)));
	cnt = (int) (94.529-(48.609)-(84.251)-(23.799)-(23.897));

}
if (cnt != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(0.1)+(78.086))/((77.333)+(0.1)));
	tcb->m_ssThresh = (int) (3.148*(76.887)*(87.69));

} else {
	tcb->m_cWnd = (int) (67.995+(25.527)+(70.597));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (((56.041)+(0.1)+(0.1)+((72.785-(tcb->m_ssThresh)-(38.61)-(4.451)-(97.517)-(39.898)-(74.859)))+(1.116)+(0.1)+(33.626))/((46.976)));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (43.7+(cnt)+(63.693)+(57.385)+(95.171));
	segmentsAcked = (int) ((tcb->m_cWnd-(4.95))/68.931);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
