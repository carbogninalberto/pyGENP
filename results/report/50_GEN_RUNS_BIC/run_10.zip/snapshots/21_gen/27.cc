tcb->m_segmentSize = (int) (43.836*(50.862)*(11.455)*(98.529)*(58.206)*(53.633)*(cnt));
if (segmentsAcked >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (80.685/0.1);

} else {
	tcb->m_segmentSize = (int) (0.1/0.1);
	cnt = (int) (21.505-(16.129)-(32.017)-(segmentsAcked)-(78.496)-(72.477)-(34.059)-(55.28));
	tcb->m_ssThresh = (int) (19.621-(tcb->m_segmentSize)-(64.774)-(43.642)-(82.973)-(segmentsAcked)-(1.386)-(73.438)-(14.868));

}
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (cnt*(tcb->m_segmentSize)*(86.866)*(86.854)*(40.216)*(90.792));
	segmentsAcked = (int) (73.363*(73.078)*(33.121)*(cnt));

} else {
	segmentsAcked = (int) (38.161*(79.736)*(57.992)*(4.15)*(96.333)*(80.322)*(segmentsAcked)*(97.698)*(9.753));
	tcb->m_ssThresh = (int) (30.16-(tcb->m_cWnd)-(73.483)-(63.946));

}
if (segmentsAcked > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (((70.63)+(82.001)+((cnt+(35.512)+(32.91)+(85.606)))+(82.319))/((0.1)));
	segmentsAcked = (int) (61.949*(16.616)*(cnt)*(19.531)*(84.091)*(3.294)*(57.029)*(66.103)*(68.968));
	tcb->m_ssThresh = (int) (tcb->m_segmentSize+(68.559)+(38.154)+(26.149)+(cnt)+(79.119)+(74.881)+(tcb->m_cWnd)+(51.275));

} else {
	tcb->m_cWnd = (int) ((((35.083-(94.568)-(65.256)))+(0.1)+(0.1)+(49.595))/((55.375)+(0.1)));
	cnt = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (tcb->m_segmentSize*(tcb->m_ssThresh)*(39.211)*(41.524)*(1.982)*(77.53));
