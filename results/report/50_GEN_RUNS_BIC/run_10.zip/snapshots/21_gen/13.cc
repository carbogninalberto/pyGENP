tcb->m_segmentSize = (int) (2.474+(80.057)+(20.635));
int nROjOiBFFuqOdUOw = (int) (-75.011-(99.676)-(-84.792)-(-51.806));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
nROjOiBFFuqOdUOw = (int) (-73.4-(-96.477)-(59.007)-(-88.638)-(-64.109)-(-84.465)-(48.916)-(-80.185));
tcb->m_segmentSize = (int) (61.567+(-18.377)+(-91.099)+(-49.674)+(79.06)+(-80.308));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
