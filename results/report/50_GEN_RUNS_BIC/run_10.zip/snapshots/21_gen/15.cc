tcb->m_segmentSize = (int) (41.018+(-92.852)+(-96.587));
int nROjOiBFFuqOdUOw = (int) (88.803-(-22.437)-(40.613)-(44.309));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(37.191)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (-67.513-(12.656)-(33.98)-(43.16)-(66.67)-(81.796)-(-26.84)-(-10.268));
nROjOiBFFuqOdUOw = (int) (4.676-(23.804)-(-76.568)-(-69.642)-(-35.013)-(-22.144)-(-99.242)-(29.173));
tcb->m_segmentSize = (int) (-69.645+(59.066)+(-9.829)+(-48.221)+(-69.627)+(-77.327));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (39.289+(-97.516)+(50.477)+(84.39)+(-9.349)+(42.911));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
