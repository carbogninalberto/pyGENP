if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh < cnt) {
	tcb->m_ssThresh = (int) (43.696*(33.347)*(48.128)*(7.067)*(39.162)*(39.622)*(73.032)*(81.412));

} else {
	tcb->m_ssThresh = (int) (18.828+(28.679)+(2.19)+(22.683)+(71.119));
	tcb->m_segmentSize = (int) (34.32+(7.961));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (0.488-(24.186)-(32.608)-(12.273)-(69.862));
if (cnt >= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (64.309*(58.551));

} else {
	tcb->m_cWnd = (int) (70.105+(0.407));
	segmentsAcked = (int) (85.849-(99.046)-(33.211)-(26.574)-(tcb->m_ssThresh)-(40.143)-(tcb->m_cWnd)-(36.844));
	tcb->m_cWnd = (int) (0.1/0.1);

}
if (cnt > segmentsAcked) {
	tcb->m_cWnd = (int) (7.176+(tcb->m_ssThresh)+(71.95)+(79.68)+(18.261)+(36.148));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (32.386*(56.045)*(8.738)*(39.191));

} else {
	tcb->m_cWnd = (int) (0.1/0.1);

}
