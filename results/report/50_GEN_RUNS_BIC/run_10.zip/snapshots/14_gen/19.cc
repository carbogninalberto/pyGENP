if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (62.054+(8.24)+(55.832)+(14.659)+(98.767)+(tcb->m_cWnd)+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (18.756*(segmentsAcked)*(26.466)*(54.124)*(71.587)*(60.681)*(segmentsAcked)*(tcb->m_segmentSize));
	cnt = (int) (cnt+(segmentsAcked)+(57.312)+(74.6)+(59.966)+(92.848)+(cnt)+(79.912)+(74.814));

}
segmentsAcked = (int) (15.195+(66.041)+(28.62));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
