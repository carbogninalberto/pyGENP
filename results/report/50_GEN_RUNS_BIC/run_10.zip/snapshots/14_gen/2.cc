float BIhFpUPgMiGokpIj = (float) (82.08-(47.822)-(-32.705));
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (-79.766/94.673);
ReduceCwnd (tcb);
