int jnstKNosbpwMsWPi = (int) (cnt*(39.145)*(19.287)*(91.403)*(10.02)*(26.734)*(segmentsAcked)*(75.353)*(segmentsAcked));
if (tcb->m_cWnd > segmentsAcked) {
	tcb->m_segmentSize = (int) (2.821-(43.73)-(17.546)-(35.59)-(segmentsAcked)-(91.538));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (45.875+(tcb->m_cWnd)+(42.57));

}
tcb->m_ssThresh = (int) (31.744*(18.189)*(16.752)*(46.539)*(97.306)*(91.181));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_cWnd) {
	cnt = (int) (segmentsAcked*(46.932)*(tcb->m_cWnd)*(62.787)*(79.036)*(44.494)*(13.317));
	cnt = (int) ((65.422-(10.131)-(14.776)-(89.063)-(tcb->m_cWnd)-(86.215))/0.1);

} else {
	cnt = (int) (jnstKNosbpwMsWPi-(29.83)-(jnstKNosbpwMsWPi)-(19.243)-(81.671)-(tcb->m_ssThresh)-(jnstKNosbpwMsWPi)-(tcb->m_ssThresh)-(15.804));

}
