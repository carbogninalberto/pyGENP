float bWmGrwAqTcybmWQo = (float) (91.055+(81.189)+(cnt)+(tcb->m_segmentSize)+(tcb->m_segmentSize));
int vNlshrIfCuBVbKDk = (int) (((95.922)+(0.1)+(76.395)+(26.721)+(0.1))/((77.724)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
