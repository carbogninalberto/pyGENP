cnt = (int) (42.376+(tcb->m_cWnd)+(29.65)+(tcb->m_cWnd)+(tcb->m_cWnd)+(15.747)+(cnt)+(72.343)+(tcb->m_cWnd));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int CMaoXNnSXWuCjCYs = (int) (76.8-(24.093)-(50.904));
if (CMaoXNnSXWuCjCYs > CMaoXNnSXWuCjCYs) {
	segmentsAcked = (int) (cnt-(6.238)-(63.465));

} else {
	segmentsAcked = (int) (CMaoXNnSXWuCjCYs+(73.276)+(segmentsAcked)+(74.97));
	tcb->m_ssThresh = (int) (41.123+(34.575)+(63.881)+(32.445)+(94.593)+(73.954)+(82.527));
	tcb->m_segmentSize = (int) (80.677*(51.079)*(79.346)*(59.541)*(5.496));

}
ReduceCwnd (tcb);
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (47.392+(tcb->m_cWnd)+(54.308));

} else {
	tcb->m_ssThresh = (int) (6.756*(46.985)*(10.952)*(7.553));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_cWnd = (int) (84.555*(55.336));

}
CMaoXNnSXWuCjCYs = (int) (98.018-(96.392)-(cnt)-(63.417)-(74.846)-(28.367)-(CMaoXNnSXWuCjCYs)-(75.453)-(35.993));
