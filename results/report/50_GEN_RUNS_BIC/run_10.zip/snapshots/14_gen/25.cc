segmentsAcked = (int) (35.566+(36.093)+(34.636)+(37.798)+(tcb->m_segmentSize)+(tcb->m_segmentSize));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (42.145+(63.575)+(17.996)+(79.33));
	segmentsAcked = (int) (segmentsAcked+(30.274)+(tcb->m_cWnd)+(87.939)+(segmentsAcked));
	segmentsAcked = (int) (33.658-(77.628)-(7.509)-(tcb->m_ssThresh)-(tcb->m_cWnd)-(36.56)-(48.654)-(24.57));

} else {
	tcb->m_segmentSize = (int) (37.854*(63.829)*(25.338));

}
tcb->m_ssThresh = (int) (25.51+(21.754)+(tcb->m_ssThresh)+(4.923)+(4.612)+(25.44));
if (segmentsAcked == tcb->m_ssThresh) {
	cnt = (int) (10.989*(tcb->m_segmentSize)*(21.147)*(75.286)*(33.896)*(tcb->m_ssThresh));

} else {
	cnt = (int) (91.93*(74.728)*(93.953)*(55.981)*(31.315)*(tcb->m_ssThresh)*(25.497));
	ReduceCwnd (tcb);

}
if (tcb->m_cWnd > tcb->m_cWnd) {
	cnt = (int) (53.964-(19.834)-(44.365)-(57.693));

} else {
	cnt = (int) (20.4-(tcb->m_cWnd)-(cnt)-(75.362)-(cnt));
	ReduceCwnd (tcb);
	tcb->m_segmentSize = (int) (9.471/47.612);

}
if (tcb->m_ssThresh >= cnt) {
	segmentsAcked = (int) (98.143+(84.653)+(53.84)+(90.73));

} else {
	segmentsAcked = (int) (22.225-(64.269));

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
