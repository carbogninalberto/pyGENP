if (tcb->m_segmentSize >= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (8.258*(54.942)*(7.646));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (57.653-(54.949));
	tcb->m_segmentSize = (int) (20.071/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
