if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (66.957+(7.575)+(-71.529)+(1.47)+(26.52)+(-19.405));
