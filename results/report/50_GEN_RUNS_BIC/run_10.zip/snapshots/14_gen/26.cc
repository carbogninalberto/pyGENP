if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd >= segmentsAcked) {
	segmentsAcked = (int) (36.694*(tcb->m_cWnd)*(57.786)*(63.941)*(49.631)*(39.276)*(cnt)*(58.624));
	ReduceCwnd (tcb);

} else {
	segmentsAcked = (int) (88.856-(tcb->m_ssThresh));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
segmentsAcked = (int) (53.766-(6.478)-(segmentsAcked));
int XDlXjFMRyvCechhr = (int) (segmentsAcked+(5.049)+(52.399)+(27.346));
if (XDlXjFMRyvCechhr > XDlXjFMRyvCechhr) {
	XDlXjFMRyvCechhr = (int) (87.559+(cnt)+(tcb->m_ssThresh)+(26.922)+(61.501)+(44.123)+(94.375)+(15.454));
	ReduceCwnd (tcb);

} else {
	XDlXjFMRyvCechhr = (int) (26.628*(XDlXjFMRyvCechhr)*(74.079)*(tcb->m_segmentSize)*(4.836));

}
segmentsAcked = (int) (29.807-(14.341)-(93.402)-(XDlXjFMRyvCechhr)-(34.869)-(tcb->m_ssThresh)-(12.864)-(51.34));
