if (tcb->m_ssThresh == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(9.946)+(37.242)+(71.576)+(50.136)+(11.834)+(60.464)+(71.996)+(21.574));
	tcb->m_ssThresh = (int) (2.058+(26.659)+(43.802));

} else {
	tcb->m_segmentSize = (int) (0.1/54.845);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (62.168+(tcb->m_segmentSize)+(cnt)+(segmentsAcked)+(39.995)+(36.832)+(49.206)+(37.973));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float SpbNbkckIVRPKYza = (float) (80.575/34.066);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_cWnd = (int) (segmentsAcked+(85.364)+(23.35)+(12.262)+(tcb->m_cWnd)+(tcb->m_ssThresh));
