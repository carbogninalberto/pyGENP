ReduceCwnd (tcb);
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (((7.479)+(0.1)+(34.583)+(0.1))/((79.647)+(0.1)+(38.07)));
tcb->m_cWnd = (int) (44.715-(tcb->m_segmentSize)-(segmentsAcked));
if (tcb->m_segmentSize == cnt) {
	segmentsAcked = (int) (82.107*(19.48)*(63.682)*(18.982));

} else {
	segmentsAcked = (int) (41.019-(cnt)-(46.043)-(2.265)-(95.813));
	ReduceCwnd (tcb);

}
