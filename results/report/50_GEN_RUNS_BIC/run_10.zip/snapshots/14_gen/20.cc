if (cnt == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((99.796)+((79.204-(72.563)-(26.495)-(33.304)))+((segmentsAcked+(14.833)+(segmentsAcked)+(19.114)+(34.136)+(tcb->m_segmentSize)+(segmentsAcked)+(segmentsAcked)))+((47.599*(59.387)*(79.392)*(21.903)*(21.132)*(89.812)))+(0.1))/((0.1)+(0.1)+(0.1)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (73.731+(segmentsAcked)+(79.364));

}
segmentsAcked = (int) (91.635+(60.166));
tcb->m_ssThresh = (int) (tcb->m_cWnd+(76.029)+(85.068)+(tcb->m_cWnd)+(52.48));
tcb->m_cWnd = (int) (75.007*(13.995)*(54.998)*(7.615)*(cnt));
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_segmentSize = (int) (46.188-(16.398)-(14.068)-(tcb->m_ssThresh));
