ReduceCwnd (tcb);
segmentsAcked = (int) (cnt+(94.365));
tcb->m_ssThresh = (int) (35.789/60.784);
segmentsAcked = (int) (43.289*(15.646)*(61.578)*(50.087)*(88.162)*(68.159)*(93.307));
if (tcb->m_cWnd == tcb->m_segmentSize) {
	cnt = (int) (cnt+(78.05)+(37.464)+(39.758)+(63.479)+(23.47));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	cnt = (int) (48.326-(cnt)-(segmentsAcked));
	tcb->m_ssThresh = (int) (0.1/53.961);
	tcb->m_ssThresh = (int) (17.061+(0.966)+(21.572)+(38.58)+(segmentsAcked)+(cnt)+(48.122)+(62.804)+(98.902));

}
if (cnt > tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (22.081-(tcb->m_cWnd)-(2.575)-(67.592)-(tcb->m_segmentSize)-(90.117));
	tcb->m_cWnd = (int) (segmentsAcked+(segmentsAcked)+(41.315)+(54.597)+(25.994)+(65.85)+(26.521));
	tcb->m_cWnd = (int) (62.426/19.978);

} else {
	tcb->m_ssThresh = (int) (68.552-(17.617)-(tcb->m_cWnd));
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(76.464)+(0.1))/((15.757)));
	tcb->m_cWnd = (int) (47.355-(23.357)-(59.349)-(segmentsAcked)-(tcb->m_segmentSize)-(66.816)-(68.744));

}
tcb->m_ssThresh = (int) (tcb->m_ssThresh+(99.598)+(27.839)+(81.655)+(tcb->m_cWnd)+(89.221)+(18.075)+(28.966)+(tcb->m_segmentSize));
segmentsAcked = (int) (22.912*(70.961)*(tcb->m_segmentSize)*(69.168)*(tcb->m_segmentSize)*(tcb->m_cWnd)*(5.419)*(3.065)*(8.935));
