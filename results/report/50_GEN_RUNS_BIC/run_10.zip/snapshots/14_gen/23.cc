if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (31.39*(52.109)*(7.99)*(cnt)*(36.636)*(12.534)*(tcb->m_segmentSize)*(39.011));

}
if (tcb->m_cWnd > tcb->m_segmentSize) {
	cnt = (int) (0.1/0.1);
	ReduceCwnd (tcb);

} else {
	cnt = (int) (tcb->m_ssThresh-(57.705)-(86.054)-(92.867)-(14.614)-(tcb->m_segmentSize)-(tcb->m_ssThresh)-(33.922));
	tcb->m_cWnd = (int) (41.172-(46.52));
	tcb->m_ssThresh = (int) (55.145*(15.093)*(31.467)*(43.943)*(42.79)*(29.471)*(3.28));

}
tcb->m_cWnd = (int) (74.248+(95.37)+(82.559)+(cnt)+(83.436)+(69.342)+(14.546)+(57.256)+(35.637));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
