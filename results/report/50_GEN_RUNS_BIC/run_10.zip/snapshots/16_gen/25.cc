tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(0.1)+(62.472)+(27.434))/((59.008)+(59.644)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int LrxhzIowFKAtmyEp = (int) (58.292+(89.322)+(70.712)+(10.204)+(tcb->m_ssThresh)+(22.742));
tcb->m_segmentSize = (int) (6.976*(25.256)*(21.445)*(67.345)*(64.128)*(40.025)*(31.193));
LrxhzIowFKAtmyEp = (int) (92.602/0.1);
