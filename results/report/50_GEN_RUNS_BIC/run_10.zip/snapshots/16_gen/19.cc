if (segmentsAcked != segmentsAcked) {
	cnt = (int) ((54.425+(55.24)+(49.244)+(51.776)+(segmentsAcked)+(tcb->m_ssThresh)+(cnt))/0.1);
	tcb->m_cWnd = (int) (((46.58)+(75.529)+((35.698*(56.502)*(tcb->m_segmentSize)*(segmentsAcked)*(88.386)*(77.185)*(63.131)))+(10.426))/((59.173)+(0.1)));

} else {
	cnt = (int) (67.528*(49.851)*(17.241)*(65.701)*(20.165)*(tcb->m_cWnd)*(25.886));

}
if (tcb->m_segmentSize <= cnt) {
	tcb->m_cWnd = (int) (17.047*(88.545)*(tcb->m_cWnd)*(50.594)*(62.561)*(91.396)*(65.838)*(67.502));
	tcb->m_segmentSize = (int) (46.319+(72.836)+(42.773)+(tcb->m_cWnd)+(34.834));

} else {
	tcb->m_cWnd = (int) (61.323-(76.733)-(48.55)-(44.303)-(41.937)-(95.599)-(6.14));

}
tcb->m_cWnd = (int) (65.737-(99.88)-(83.347)-(17.011));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
ReduceCwnd (tcb);
ReduceCwnd (tcb);
