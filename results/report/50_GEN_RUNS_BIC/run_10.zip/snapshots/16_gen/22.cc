if (tcb->m_cWnd >= tcb->m_ssThresh) {
	cnt = (int) (5.217-(segmentsAcked)-(56.268)-(66.027)-(13.192)-(tcb->m_segmentSize)-(40.098)-(91.26));

} else {
	cnt = (int) (0.1/0.1);
	tcb->m_segmentSize = (int) (83.421*(33.662)*(46.409)*(7.111)*(78.372)*(segmentsAcked)*(11.778));
	tcb->m_ssThresh = (int) (((78.277)+((33.37+(63.367)+(3.422)+(79.534)))+(0.1)+(0.1))/((32.386)));

}
tcb->m_ssThresh = (int) (63.354-(80.462)-(34.295)-(33.062));
if (tcb->m_ssThresh <= cnt) {
	segmentsAcked = (int) (89.703*(68.033)*(98.577));
	tcb->m_cWnd = (int) (56.75-(93.921)-(82.832)-(4.104)-(17.608));
	tcb->m_segmentSize = (int) (74.797*(18.253)*(27.357)*(tcb->m_segmentSize)*(93.787)*(segmentsAcked));

} else {
	segmentsAcked = (int) ((79.849*(21.992)*(70.419)*(56.497)*(14.414)*(28.388)*(8.979))/32.877);
	ReduceCwnd (tcb);

}
tcb->m_cWnd = (int) (cnt*(97.944)*(13.172)*(tcb->m_ssThresh)*(tcb->m_segmentSize)*(tcb->m_segmentSize));
tcb->m_ssThresh = (int) (84.099/62.821);
