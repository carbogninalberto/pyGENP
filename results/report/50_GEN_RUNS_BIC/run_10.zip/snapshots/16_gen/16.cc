if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (77.096*(47.061)*(78.662)*(26.339)*(46.055)*(34.956)*(43.462)*(77.985));

} else {
	tcb->m_segmentSize = (int) (44.434-(17.311)-(36.163)-(97.921)-(39.455)-(62.808)-(30.952));
	tcb->m_cWnd = (int) (52.96+(3.84)+(16.212)+(24.139));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_cWnd > cnt) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(16.381));
	tcb->m_segmentSize = (int) (94.483*(57.995)*(tcb->m_ssThresh)*(tcb->m_ssThresh)*(10.839));
	segmentsAcked = (int) (((0.1)+(4.118)+(0.1)+(0.1)+(59.745))/((0.1)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(26.857)+(0.1)+(43.559)+(91.187)+(64.482)+(0.1))/((71.717)+(0.1)));
	segmentsAcked = (int) (97.89+(32.748)+(74.698)+(segmentsAcked));

}
