tcb->m_ssThresh = (int) (29.861+(62.616)+(tcb->m_ssThresh)+(65.293));
tcb->m_ssThresh = (int) (7.773/0.1);
ReduceCwnd (tcb);
if (cnt >= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (61.128-(tcb->m_cWnd)-(81.755));
	cnt = (int) (tcb->m_segmentSize-(4.257)-(52.251)-(18.727));
	tcb->m_ssThresh = (int) (((0.1)+((74.919-(tcb->m_ssThresh)-(53.072)))+(63.769)+(0.1))/((0.1)+(99.274)+(87.863)+(0.1)));

} else {
	tcb->m_segmentSize = (int) (((0.1)+(0.1)+(0.1)+(48.56)+(73.721)+(0.1)+(66.941))/((3.388)+(0.1)));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_segmentSize != segmentsAcked) {
	cnt = (int) (84.975+(36.199)+(37.833));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (71.834-(tcb->m_ssThresh));

}
cnt = (int) (11.911/71.487);
if (tcb->m_cWnd == tcb->m_ssThresh) {
	segmentsAcked = (int) (78.87*(4.05)*(51.52)*(53.459)*(80.441)*(91.934)*(1.649)*(79.052)*(38.207));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	segmentsAcked = (int) (tcb->m_segmentSize+(73.445)+(cnt)+(14.576)+(21.068));
	tcb->m_cWnd = (int) (0.1/47.809);
	segmentsAcked = (int) (67.035*(56.998)*(segmentsAcked)*(cnt));

}
