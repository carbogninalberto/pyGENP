int RqnvxxzpEIILplIX = (int) (8.4*(segmentsAcked)*(56.859));
float xdtmQQVRNrHrTjEA = (float) (47.155-(84.884)-(28.193)-(66.622)-(17.431)-(22.952));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
tcb->m_ssThresh = (int) (46.625*(37.796));
if (tcb->m_cWnd >= xdtmQQVRNrHrTjEA) {
	tcb->m_segmentSize = (int) (22.476*(RqnvxxzpEIILplIX)*(51.374)*(82.044)*(51.117)*(20.497)*(93.1)*(65.164));
	RqnvxxzpEIILplIX = (int) (32.5*(xdtmQQVRNrHrTjEA)*(24.85)*(tcb->m_ssThresh)*(segmentsAcked)*(tcb->m_segmentSize)*(28.688)*(RqnvxxzpEIILplIX)*(69.932));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (33.949+(20.556)+(9.175)+(13.457)+(46.826));
	RqnvxxzpEIILplIX = (int) (RqnvxxzpEIILplIX+(97.205)+(0.263)+(41.707));
	cnt = (int) (tcb->m_ssThresh-(14.456)-(1.745)-(23.721)-(tcb->m_segmentSize)-(47.73)-(94.438)-(tcb->m_segmentSize));

}
if (tcb->m_segmentSize == cnt) {
	segmentsAcked = (int) ((69.467-(xdtmQQVRNrHrTjEA))/0.1);
	tcb->m_cWnd = (int) (0.1/81.907);

} else {
	segmentsAcked = (int) (54.418*(45.904)*(36.749));
	tcb->m_segmentSize = (int) (13.635/61.155);
	tcb->m_segmentSize = (int) (8.651+(81.137)+(67.175)+(13.563)+(12.731)+(RqnvxxzpEIILplIX)+(10.229));

}
if (tcb->m_cWnd != tcb->m_ssThresh) {
	RqnvxxzpEIILplIX = (int) (47.947-(59.047)-(85.41)-(44.647)-(78.069)-(64.444)-(34.223)-(63.315));

} else {
	RqnvxxzpEIILplIX = (int) (0.1/0.1);
	RqnvxxzpEIILplIX = (int) (0.1/0.1);
	segmentsAcked = (int) (7.039-(45.624)-(87.188)-(RqnvxxzpEIILplIX)-(18.504)-(83.99));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
