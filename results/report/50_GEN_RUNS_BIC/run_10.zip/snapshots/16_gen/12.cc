if (tcb->m_cWnd == tcb->m_segmentSize) {
	cnt = (int) (6.268+(73.761)+(77.543)+(74.446));
	cnt = (int) (cnt*(79.516)*(2.286)*(62.089)*(9.08)*(28.474));
	tcb->m_ssThresh = (int) (tcb->m_cWnd*(72.799)*(62.897)*(39.214)*(30.839)*(52.803));

} else {
	cnt = (int) (11.149-(tcb->m_ssThresh)-(65.042)-(51.267));
	tcb->m_segmentSize = (int) (88.018-(42.527)-(76.908)-(20.666)-(22.702)-(49.355)-(66.929)-(segmentsAcked));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
segmentsAcked = (int) (7.252-(25.834));
tcb->m_ssThresh = (int) (25.098-(segmentsAcked)-(tcb->m_segmentSize)-(12.996)-(25.142));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
