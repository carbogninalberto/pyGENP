ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (cnt < tcb->m_segmentSize) {
	segmentsAcked = (int) (((95.275)+(32.71)+(46.202)+(0.1)+(84.794)+(0.1)+(58.497))/((0.1)+(0.1)));
	tcb->m_ssThresh = (int) (73.393-(62.723)-(51.219)-(14.205)-(85.823)-(88.99));
	tcb->m_cWnd = (int) (0.1/0.1);

} else {
	segmentsAcked = (int) (41.525/9.952);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_segmentSize = (int) (((0.1)+(8.859)+((48.814-(54.661)-(cnt)-(segmentsAcked)-(81.87)-(86.001)-(19.921)-(tcb->m_cWnd)))+((tcb->m_cWnd*(tcb->m_segmentSize)*(24.662)*(tcb->m_segmentSize)*(72.25)*(86.683)*(49.334)*(92.589)))+(0.1))/((57.184)));

}
ReduceCwnd (tcb);
segmentsAcked = (int) (9.782-(0.147));
if (tcb->m_ssThresh < cnt) {
	cnt = (int) (12.307/0.1);
	segmentsAcked = (int) (76.475-(41.059)-(79.798)-(16.116)-(32.251)-(70.11)-(77.798)-(92.728));
	cnt = (int) (tcb->m_ssThresh*(89.012)*(80.645)*(59.643));

} else {
	cnt = (int) (cnt-(78.942)-(93.654)-(tcb->m_ssThresh)-(40.215)-(57.681)-(92.929)-(30.55)-(88.903));
	ReduceCwnd (tcb);
	tcb->m_ssThresh = (int) (14.56/3.143);

}
ReduceCwnd (tcb);
int IgBEzyorCwKTzRVF = (int) (70.958*(tcb->m_ssThresh));
cnt = (int) (59.76*(24.419)*(IgBEzyorCwKTzRVF)*(74.854)*(75.517));
