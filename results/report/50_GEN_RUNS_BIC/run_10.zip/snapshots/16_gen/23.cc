if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (tcb->m_ssThresh > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (((0.1)+(0.1)+(52.76)+(52.667)+(62.695))/((5.116)+(0.1)+(0.1)));

} else {
	tcb->m_cWnd = (int) (segmentsAcked+(60.876)+(79.363)+(tcb->m_ssThresh));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (((62.577)+((22.389-(77.45)-(segmentsAcked)-(1.289)-(segmentsAcked)-(3.139)-(61.366)))+((73.782-(68.456)-(46.732)-(55.459)-(5.372)-(segmentsAcked)))+(23.733)+(93.423))/((90.304)+(0.1)+(13.981)));

}
if (cnt <= tcb->m_ssThresh) {
	cnt = (int) (0.1/0.1);
	ReduceCwnd (tcb);

} else {
	cnt = (int) (59.092+(16.184)+(tcb->m_cWnd)+(56.868)+(65.154)+(cnt)+(34.825)+(44.106)+(tcb->m_cWnd));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
ReduceCwnd (tcb);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
