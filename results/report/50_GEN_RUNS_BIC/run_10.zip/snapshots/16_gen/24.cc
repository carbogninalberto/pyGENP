ReduceCwnd (tcb);
int xwRhyZBLcwNIHfFT = (int) (29.193*(42.6)*(segmentsAcked)*(tcb->m_ssThresh)*(89.704)*(segmentsAcked)*(84.951));
segmentsAcked = (int) (24.723/0.1);
if (tcb->m_cWnd < tcb->m_ssThresh) {
	cnt = (int) (tcb->m_ssThresh+(58.259)+(52.453)+(25.994)+(9.476)+(39.963)+(88.554)+(82.466));

} else {
	cnt = (int) (28.417-(86.573)-(96.145)-(1.715)-(92.085)-(33.098)-(segmentsAcked)-(71.567));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
tcb->m_cWnd = (int) (60.582*(segmentsAcked)*(62.106)*(79.95));
tcb->m_cWnd = (int) (tcb->m_ssThresh+(88.545)+(35.861)+(50.319));
