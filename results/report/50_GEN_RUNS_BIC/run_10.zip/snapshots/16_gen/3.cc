if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (-61.199+(98.923)+(29.991)+(20.458));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (56.545*(27.93)*(15.36)*(42.355)*(-5.566)*(80.73)*(tcb->m_segmentSize));

}
