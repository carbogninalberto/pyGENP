if (tcb->m_segmentSize != tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (7.702+(46.338));
	ReduceCwnd (tcb);
	cnt = (int) (72.984-(20.595)-(69.273));

} else {
	tcb->m_cWnd = (int) (29.853-(cnt));

}
tcb->m_segmentSize = (int) (4.017+(43.264)+(56.174));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(cnt)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
int nROjOiBFFuqOdUOw = (int) (61.936-(31.25)-(55.733)-(82.184));
if (tcb->m_segmentSize <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (tcb->m_ssThresh+(tcb->m_ssThresh)+(88.406)+(14.773)+(98.749)+(60.17)+(segmentsAcked)+(2.722));

} else {
	tcb->m_ssThresh = (int) (2.468+(60.089)+(80.896)+(tcb->m_cWnd)+(cnt)+(70.14)+(66.096)+(69.566)+(43.733));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
nROjOiBFFuqOdUOw = (int) (0.676-(13.981)-(90.84)-(19.732)-(74.226)-(52.227)-(94.877)-(94.137));
if (cnt <= segmentsAcked) {
	cnt = (int) (67.115+(84.762)+(83.04)+(69.321)+(44.156));
	ReduceCwnd (tcb);

} else {
	cnt = (int) (tcb->m_ssThresh+(tcb->m_cWnd)+(tcb->m_ssThresh)+(24.991));
	cnt = (int) (tcb->m_cWnd+(53.496)+(tcb->m_segmentSize)+(51.55)+(38.966));
	tcb->m_cWnd = (int) (69.178-(tcb->m_cWnd)-(58.482)-(cnt)-(56.973)-(47.644)-(98.95)-(21.32)-(45.099));

}
tcb->m_segmentSize = (int) (12.736+(44.682)+(51.057)+(tcb->m_ssThresh)+(66.877)+(37.57));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
