int nROjOiBFFuqOdUOw = (int) (24.921-(-70.302)-(-97.975)-(-20.335));
tcb->m_segmentSize = (int) (44.631+(29.657)+(-73.804));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(11.853)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (6.451-(-47.286)-(11.295)-(41.716)-(82.857)-(82.81)-(-86.122)-(53.676));
tcb->m_segmentSize = (int) (-56.407+(67.068)+(70.972)+(-48.771)+(-11.941)+(2.597));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
