tcb->m_ssThresh = (int) (tcb->m_segmentSize-(24.371)-(5.572));
ReduceCwnd (tcb);
if (cnt <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (8.505+(65.962)+(22.161)+(27.736)+(97.381)+(29.477));

} else {
	tcb->m_segmentSize = (int) (86.989-(36.885));

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
int XwBNTPGRmWEqSaoM = (int) (2.206-(7.15));
if (tcb->m_ssThresh < tcb->m_cWnd) {
	tcb->m_cWnd = (int) (87.114-(5.455)-(93.237));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (0.1/0.1);
	segmentsAcked = (int) (36.149*(tcb->m_cWnd)*(33.471)*(91.058)*(58.088)*(37.681)*(65.575)*(90.946));

}
if (XwBNTPGRmWEqSaoM == tcb->m_cWnd) {
	segmentsAcked = (int) (97.854*(73.243)*(13.539)*(99.458));

} else {
	segmentsAcked = (int) (81.188*(segmentsAcked)*(tcb->m_ssThresh));

}
