cnt = (int) (segmentsAcked-(59.728));
if (tcb->m_cWnd < cnt) {
	tcb->m_cWnd = (int) (44.192*(90.046));

} else {
	tcb->m_cWnd = (int) (0.1/90.739);
	tcb->m_ssThresh = (int) (98.397/79.735);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
segmentsAcked = (int) (19.735/50.284);
