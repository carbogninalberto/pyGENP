if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (((3.323)+((92.324+(97.503)+(segmentsAcked)))+(66.098)+(0.1)+(46.142))/((13.602)+(0.1)+(20.088)));

} else {
	tcb->m_ssThresh = (int) (12.814+(93.563)+(27.924)+(0.41));
	cnt = (int) (cnt+(16.726)+(11.603));
	tcb->m_segmentSize = (int) (0.1/0.1);

}
if (tcb->m_cWnd > tcb->m_cWnd) {
	tcb->m_cWnd = (int) (83.756+(tcb->m_segmentSize));
	ReduceCwnd (tcb);

} else {
	tcb->m_cWnd = (int) (0.1/0.1);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (segmentsAcked == tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (((38.092)+(0.1)+(67.864)+(0.1)+(54.062))/((11.477)+(0.1)+(17.669)+(3.233)));
	tcb->m_cWnd = (int) (6.655/39.195);
	cnt = (int) (((0.1)+(0.1)+(73.886)+(79.255))/((0.1)+(0.1)+(63.359)+(97.518)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (segmentsAcked-(69.447)-(83.9)-(61.315)-(segmentsAcked)-(83.532));
	ReduceCwnd (tcb);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (tcb->m_cWnd+(tcb->m_cWnd)+(79.52)+(54.329)+(97.029)+(segmentsAcked)+(76.79)+(tcb->m_ssThresh));
