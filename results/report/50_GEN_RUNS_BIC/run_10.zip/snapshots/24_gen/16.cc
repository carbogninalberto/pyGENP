if (tcb->m_ssThresh == cnt) {
	tcb->m_segmentSize = (int) (0.1/1.676);
	ReduceCwnd (tcb);

} else {
	tcb->m_segmentSize = (int) (93.141+(cnt)+(53.285));
	tcb->m_ssThresh = (int) (88.355/30.226);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
cnt = (int) (segmentsAcked+(segmentsAcked)+(4.715));
tcb->m_cWnd = (int) ((((tcb->m_cWnd*(tcb->m_cWnd)*(tcb->m_segmentSize)*(20.678)*(92.334)*(cnt)))+(95.328)+(95.653)+(0.1))/((0.1)+(97.896)+(0.1)));
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
tcb->m_ssThresh = (int) (47.227+(40.648)+(79.429)+(74.877)+(tcb->m_segmentSize)+(70.529));
if (segmentsAcked > segmentsAcked) {
	cnt = (int) (segmentsAcked*(25.194)*(13.463)*(99.616));
	ReduceCwnd (tcb);
	cnt = (int) (tcb->m_ssThresh-(66.105)-(67.822)-(tcb->m_cWnd)-(78.043)-(8.163));

} else {
	cnt = (int) (77.974*(32.147));

}
ReduceCwnd (tcb);
ReduceCwnd (tcb);
