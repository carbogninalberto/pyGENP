if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
float pLtZnPQJOlZidaYD = (float) (38.236/19.421);
segmentsAcked = (int) (88.996-(12.031)-(45.365)-(53.828)-(6.743)-(0.631)-(28.563));
if (tcb->m_cWnd >= pLtZnPQJOlZidaYD) {
	tcb->m_ssThresh = (int) (6.851*(tcb->m_segmentSize));

} else {
	tcb->m_ssThresh = (int) (72.132*(segmentsAcked)*(tcb->m_cWnd)*(50.031));
	segmentsAcked = (int) (tcb->m_segmentSize+(segmentsAcked)+(50.589)+(tcb->m_ssThresh)+(20.667)+(83.814)+(38.84)+(59.931)+(17.455));
	pLtZnPQJOlZidaYD = (float) (24.35-(70.552)-(21.059));

}
