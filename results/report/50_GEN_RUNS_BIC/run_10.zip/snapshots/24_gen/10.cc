int nROjOiBFFuqOdUOw = (int) (-14.858-(14.156)-(-40.448)-(58.131));
tcb->m_segmentSize = (int) (-88.952+(57.118)+(-4.302));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (-56.176+(-37.886)+(-46.099));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
nROjOiBFFuqOdUOw = (int) (94.37-(-17.428)-(68.657)-(50.202)-(-79.137)-(71.364)-(-94.555)-(-64.451));
tcb->m_segmentSize = (int) (20.526+(93.708)+(-17.809)+(40.331)+(-8.451)+(6.139));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
nROjOiBFFuqOdUOw = (int) (78.91-(-45.137)-(74.837)-(-83.296)-(-49.385)-(12.561)-(-48.297)-(53.801));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
nROjOiBFFuqOdUOw = (int) (72.501-(-63.891)-(47.323)-(80.913)-(25.474)-(94.776)-(79.198)-(25.815));
tcb->m_segmentSize = (int) (-26.013+(18.517)+(-44.157)+(-58.946)+(40.16)+(92.977));
tcb->m_segmentSize = (int) (-38.245+(89.993)+(43.985)+(-69.107)+(-11.609)+(9.558));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
tcb->m_segmentSize = (int) (40.756+(12.711)+(-58.112)+(61.709)+(-87.788)+(71.348));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
nROjOiBFFuqOdUOw = (int) (-8.136-(-63.09)-(-40.671)-(-95.277)-(97.985)-(28.883)-(15.943)-(37.62));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (-89.088+(-30.163)+(99.792)+(64.707)+(-43.062)+(2.575));
nROjOiBFFuqOdUOw = (int) (-44.393-(-68.37)-(-2.518)-(21.68)-(82.521)-(37.934)-(-82.856)-(-55.489));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (-98.049+(-75.462)+(-43.507)+(-18.291)+(-82.754)+(-93.988));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
