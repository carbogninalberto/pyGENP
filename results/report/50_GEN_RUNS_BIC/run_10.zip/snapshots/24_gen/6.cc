ReduceCwnd (tcb);
int vLOirIypnLtwmrnO = (int) 63.504;
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
vLOirIypnLtwmrnO = (int) (-98.787-(40.504)-(-44.811)-(91.496)-(17.574)-(7.151)-(68.579));
segmentsAcked = (int) (91.678+(-89.356));
