int nROjOiBFFuqOdUOw = (int) (8.406-(-96.281)-(78.026)-(-95.073));
tcb->m_segmentSize = (int) (63.256+(90.464)+(-13.018));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
nROjOiBFFuqOdUOw = (int) (84.93-(91.96)-(-77.065)-(2.107)-(97.643)-(75.259)-(-17.655)-(-0.02));
tcb->m_segmentSize = (int) (-96.861+(-53.362)+(-98.188)+(-65.713)+(-9.017)+(80.267));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
