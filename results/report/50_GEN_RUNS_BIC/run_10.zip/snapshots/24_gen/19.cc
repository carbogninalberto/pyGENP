cnt = (int) ((((22.535+(22.717)+(12.565)+(tcb->m_cWnd)+(21.403)+(tcb->m_segmentSize)+(32.086)+(39.67)))+(0.1)+(12.553)+(0.1)+(0.1)+(58.466)+(0.1)+(75.258))/((0.1)));
float rJuJIURtkQlgaBPS = (float) (73.758+(20.27)+(51.263));
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	segmentsAcked = (int) (43.189*(tcb->m_ssThresh)*(88.892)*(cnt));

} else {
	segmentsAcked = (int) (53.49-(tcb->m_segmentSize)-(64.326));
	segmentsAcked = (int) (70.134*(90.733)*(90.187));

}
if (rJuJIURtkQlgaBPS == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (95.527+(63.629)+(85.58)+(69.591)+(46.891)+(80.728)+(tcb->m_segmentSize)+(tcb->m_cWnd));
	tcb->m_ssThresh = (int) (95.485/6.074);

} else {
	tcb->m_cWnd = (int) (16.802+(10.097)+(23.257)+(tcb->m_ssThresh)+(50.455)+(8.985)+(96.889)+(52.002));

}
tcb->m_segmentSize = (int) (85.034+(79.3)+(90.389)+(tcb->m_segmentSize)+(segmentsAcked)+(tcb->m_ssThresh)+(80.431)+(segmentsAcked));
float zYFexACXJJqSFuZG = (float) (66.073+(76.267));
int YaOLkleXVZyFAgne = (int) (0.1/85.36);
if (cnt > cnt) {
	tcb->m_segmentSize = (int) (95.839-(55.905)-(46.134)-(99.971)-(rJuJIURtkQlgaBPS)-(3.424)-(65.569));
	YaOLkleXVZyFAgne = (int) (tcb->m_ssThresh-(75.094)-(21.54)-(1.517)-(cnt)-(4.418)-(99.9));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_segmentSize = (int) (53.37+(6.533)+(77.398)+(9.061)+(12.263)+(6.435)+(80.31)+(39.143)+(24.075));

}
