int MKeTXKCvPCIZgsUI = (int) (90.298+(25.548)+(7.121)+(77.173)+(92.197));
if (segmentsAcked == segmentsAcked) {
	cnt = (int) (58.166*(36.497)*(64.103));

} else {
	cnt = (int) (39.303*(tcb->m_cWnd)*(50.402)*(74.115));
	segmentsAcked = (int) ((76.93-(MKeTXKCvPCIZgsUI)-(2.152)-(90.081)-(31.476)-(65.532)-(cnt)-(91.691))/0.1);

}
int ncbKUIeNAMnTxwCK = (int) (86.417-(99.594)-(MKeTXKCvPCIZgsUI)-(10.115)-(15.534));
int JSkLUgYhaoUkiInz = (int) ((29.559-(tcb->m_segmentSize)-(95.099)-(40.398)-(9.24)-(69.046)-(48.877))/0.1);
MKeTXKCvPCIZgsUI = (int) (JSkLUgYhaoUkiInz-(87.612)-(56.722)-(25.112)-(28.439)-(48.927)-(62.592));
if (ncbKUIeNAMnTxwCK <= JSkLUgYhaoUkiInz) {
	MKeTXKCvPCIZgsUI = (int) (34.386*(ncbKUIeNAMnTxwCK)*(92.792));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
	tcb->m_ssThresh = (int) (tcb->m_cWnd+(80.82)+(84.891));

} else {
	MKeTXKCvPCIZgsUI = (int) (27.688/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_cWnd < cnt) {
	tcb->m_ssThresh = (int) (((36.589)+(95.739)+(0.1)+(9.149))/((0.1)+(0.1)));
	JSkLUgYhaoUkiInz = (int) (((0.1)+(0.1)+(42.856)+(32.301)+(0.1)+(37.876))/((0.1)+(0.1)));

} else {
	tcb->m_ssThresh = (int) (73.254-(89.426)-(64.762)-(64.411)-(17.948)-(38.542));

}
