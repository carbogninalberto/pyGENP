tcb->m_segmentSize = (int) (cnt*(92.523)*(44.892)*(91.652)*(90.945));
ReduceCwnd (tcb);
cnt = (int) (0.1/62.261);
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
ReduceCwnd (tcb);
