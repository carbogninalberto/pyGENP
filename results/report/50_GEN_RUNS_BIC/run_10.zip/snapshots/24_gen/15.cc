tcb->m_cWnd = (int) (81.572-(94.618)-(35.501));
tcb->m_segmentSize = (int) (tcb->m_cWnd*(4.371)*(63.783)*(50.603)*(99.846)*(93.498)*(tcb->m_segmentSize)*(29.701));
if (tcb->m_ssThresh > segmentsAcked) {
	tcb->m_ssThresh = (int) (64.639-(98.249)-(45.035)-(29.615)-(86.287)-(55.441)-(tcb->m_ssThresh));
	tcb->m_cWnd = (int) (22.43*(93.598)*(6.441)*(tcb->m_cWnd)*(57.648)*(tcb->m_cWnd)*(78.171));
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

} else {
	tcb->m_ssThresh = (int) (0.1/0.1);
	if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }

}
if (tcb->m_segmentSize < segmentsAcked) {
	cnt = (int) (cnt*(90.201)*(tcb->m_segmentSize)*(8.804)*(36.162)*(24.672));

} else {
	cnt = (int) ((65.097*(72.519)*(tcb->m_segmentSize)*(48.551)*(16.506)*(6.424))/91.671);

}
if (m_cWndCnt > cnt) {   tcb->m_cWnd += tcb->m_segmentSize;   m_cWndCnt = 0; }
