float WgBfekymahsVxaLS = (float) 86.016;
segmentsAcked = (int) (-42.178*(46.198)*(65.07));
