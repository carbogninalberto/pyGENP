int nROjOiBFFuqOdUOw = (int) (-54.947-(-47.227)-(-24.243)-(18.577));
tcb->m_segmentSize = (int) (-32.754+(-28.072)+(70.824));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (-58.165+(74.915)+(-21.967));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
nROjOiBFFuqOdUOw = (int) (43.068-(-43.945)-(93.771)-(20.279)-(35.797)-(-57.171)-(47.089)-(-16.625));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
nROjOiBFFuqOdUOw = (int) (-70.179-(35.022)-(-34.535)-(36.557)-(-88.354)-(98.971)-(38.521)-(3.453));
tcb->m_segmentSize = (int) (-52.923+(58.533)+(2.362)+(-61.376)+(-66.625)+(79.475));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
tcb->m_segmentSize = (int) (57.273+(92.112)+(-18.038)+(-68.356)+(-65.707)+(-27.932));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
nROjOiBFFuqOdUOw = (int) (89.563-(-86.409)-(26.093)-(10.089)-(8.961)-(77.268)-(-98.888)-(44.368));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (47.457+(-54.809)+(0.672)+(46.577)+(58.913)+(-71.457));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
nROjOiBFFuqOdUOw = (int) (-12.146-(-18.036)-(82.984)-(-99.687)-(58.445)-(57.195)-(53.824)-(-48.097));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
nROjOiBFFuqOdUOw = (int) (-92.738-(44.734)-(73.871)-(95.939)-(-14.363)-(86.481)-(-11.381)-(-4.64));
tcb->m_segmentSize = (int) (-65.452+(58.885)+(-83.089)+(97.375)+(35.891)+(23.889));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
nROjOiBFFuqOdUOw = (int) (33.63-(-81.968)-(85.446)-(67.578)-(-98.591)-(70.884)-(1.884)-(61.245));
tcb->m_segmentSize = (int) (68.287+(-12.656)+(-45.252)+(-31.022)+(-13.601)+(-19.485));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
tcb->m_segmentSize = (int) (80.241+(-21.736)+(0.817)+(35.879)+(-58.227)+(63.929));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(-90.716)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

} else {
	tcb->m_cWnd = (int) (61.011-(86.646));

}
nROjOiBFFuqOdUOw = (int) (96.379-(-28.832)-(82.811)-(3.661)-(-8.361)-(97.56)-(-63.878)-(-11.874));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (87.972+(83.985)+(85.308)+(-45.749)+(76.552)+(41.135));
nROjOiBFFuqOdUOw = (int) (-99.357-(23.967)-(-23.84)-(-22.048)-(-16.376)-(25.927)-(29.969)-(-45.519));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (-16.179+(57.273)+(36.093)+(-12.141)+(-18.44)+(95.939));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
