int nROjOiBFFuqOdUOw = (int) (5.505-(-67.453)-(-64.285)-(-54.038));
tcb->m_segmentSize = (int) (81.908+(-1.474)+(18.971));
if (tcb->m_segmentSize == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (61.011-(86.646));

} else {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(35.355)+(tcb->m_cWnd)+(23.035));
	ReduceCwnd (tcb);
	tcb->m_cWnd = (int) (36.859-(44.509)-(37.191)-(76.008)-(76.519)-(3.25)-(13.142)-(75.862));

}
nROjOiBFFuqOdUOw = (int) (-21.106-(28.814)-(56.358)-(-65.849)-(-10.108)-(-85.166)-(8.946)-(-63.023));
nROjOiBFFuqOdUOw = (int) (-75.324-(-63.815)-(-89.647)-(21.659)-(48.414)-(38.608)-(-41.087)-(31.987));
tcb->m_segmentSize = (int) (34.59+(-90.0)+(-39.492)+(43.451)+(-58.217)+(42.819));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
tcb->m_segmentSize = (int) (-1.817+(18.72)+(-79.553)+(85.288)+(-84.266)+(25.223));
if (tcb->m_segmentSize <= segmentsAcked) {
	tcb->m_cWnd = (int) (tcb->m_segmentSize+(97.013)+(77.918)+(44.989)+(81.876)+(23.891)+(84.87));

} else {
	tcb->m_cWnd = (int) (((90.173)+(83.131)+((34.36*(38.908)))+(48.173))/((0.1)));
	ReduceCwnd (tcb);

}
