segmentsAcked = (int) (-6-(7));
tcb->m_cWnd = (int) (-14+(12)+(-12));
tcb->m_cWnd = (int) (-10*(9)*(-6));
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (16.44-(13.17)-(19.91));

} else {
	segmentsAcked = (int) (14.53-(segmentsAcked)-(19.28)-(6.69));

}
segmentsAcked = (int) (13-(-13)-(-8)-(tcb->m_segmentSize));
segmentsAcked = (int) (-9-(-10)-(15));
segmentsAcked = (int) (14*(-5)*(-4)*(7));
tcb->m_cWnd = (int) (-20+(-17)+(3));
tcb->m_cWnd = (int) (13*(7)*(-20));
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (16.44-(13.17)-(19.91));

} else {
	segmentsAcked = (int) (14.53-(segmentsAcked)-(19.28)-(6.69));

}
segmentsAcked = (int) (-17-(-4)-(-11)-(tcb->m_segmentSize));
segmentsAcked = (int) (9*(-10)*(7)*(17));
