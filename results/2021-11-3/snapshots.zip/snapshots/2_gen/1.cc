segmentsAcked = (int) (-8+(3)+(1)+(-6));
tcb->m_cWnd = (int) (-14+(10)+(2));
tcb->m_cWnd = (int) (-9*(18)*(-12));
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (16.44-(13.17)-(19.91));

} else {
	segmentsAcked = (int) (14.53-(segmentsAcked)-(19.28)-(6.69));

}
segmentsAcked = (int) (5-(15)-(-1)-(tcb->m_segmentSize));
segmentsAcked = (int) (-4*(-2)*(8)*(-18));
