float oQoPAodzgRdiuYTu = (float) (-18-(-5)-(-6));
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (5.33-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (9.03+(9.15));

}
tcb->m_cWnd = (int) (2+(-16));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-5)+(3));
segmentsAcked = (int) (tcb->m_cWnd+(19)+(9));
