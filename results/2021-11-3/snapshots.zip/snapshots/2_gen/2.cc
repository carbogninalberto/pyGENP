float oQoPAodzgRdiuYTu = (float) (15-(5)-(-20));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.55*(7.37)*(1.05));

} else {
	tcb->m_cWnd = (int) (10.57-(12.63));

}
tcb->m_cWnd = (int) (-2+(18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(0)+(-6));
