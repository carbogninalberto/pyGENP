segmentsAcked = (int) (6-(15)-(-3));
segmentsAcked = (int) (-20-(12)-(-15)-(tcb->m_segmentSize));
tcb->m_cWnd = (int) (-16+(-17)+(-16));
segmentsAcked = (int) (19*(-4)*(-8)*(-4));
tcb->m_cWnd = (int) (12*(4)*(3));
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (16.44-(13.17)-(19.91));

} else {
	segmentsAcked = (int) (14.53-(segmentsAcked)-(19.28)-(6.69));

}
segmentsAcked = (int) (15-(-11)-(19)-(tcb->m_segmentSize));
segmentsAcked = (int) (-13*(-10)*(-14)*(5));
