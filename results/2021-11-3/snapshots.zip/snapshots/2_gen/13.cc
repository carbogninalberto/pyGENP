float oQoPAodzgRdiuYTu = (float) (-1-(13)-(-6));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (16.73+(tcb->m_cWnd)+(10.29)+(13.85));

} else {
	tcb->m_cWnd = (int) (18.99+(5.48)+(0.98));

}
tcb->m_cWnd = (int) (-16+(3));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(4)+(19));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(14)+(-7));
