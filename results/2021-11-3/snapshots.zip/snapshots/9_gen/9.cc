if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.11-(6.81)-(7.86));

} else {
	tcb->m_cWnd = (int) (11.0*(tcb->m_segmentSize)*(11.97)*(9.84));

}
float oQoPAodzgRdiuYTu = (float) (14-(-8)-(-16)-(3));
tcb->m_cWnd = (int) (9+(-14));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (7+(14));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(12)+(-5));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-10)+(12));
