if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (16+(13.99)+(-18));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize-(12.74));

}
float oQoPAodzgRdiuYTu = (float) (-9+(-6));
tcb->m_cWnd = (int) (11+(-18));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-6)+(-1));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(1)+(7));
segmentsAcked = (int) (tcb->m_cWnd+(16)+(4));
segmentsAcked = (int) (tcb->m_cWnd+(-3)+(-6));
