float oQoPAodzgRdiuYTu = (float) (3+(-11)+(11));
tcb->m_cWnd = (int) (-3*(4)*(15));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-15+(-14));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-13)+(-9));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-4)+(10));
