CongestionAvoidance (tcb, segmentsAcked);
float oQoPAodzgRdiuYTu = (float) (-10-(-3)-(-11)-(10));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.61*(16));

} else {
	tcb->m_cWnd = (int) (15.21+(12.79)+(11.28)+(18.51));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-1)+(-8));
tcb->m_cWnd = (int) (-15+(3));
segmentsAcked = (int) (tcb->m_cWnd+(-1)+(1));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-9)+(6));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-8)+(-14));
segmentsAcked = (int) (tcb->m_cWnd+(6)+(17));
segmentsAcked = (int) (tcb->m_cWnd+(-10)+(-1));
