float oQoPAodzgRdiuYTu = (float) (0+(-12));
tcb->m_cWnd = (int) (-13+(-7));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-11)+(7));
segmentsAcked = (int) (tcb->m_cWnd+(-3)+(-19));
