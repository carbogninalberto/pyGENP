CongestionAvoidance (tcb, segmentsAcked);
float oQoPAodzgRdiuYTu = (float) (-5-(-2));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.61*(16));

} else {
	tcb->m_cWnd = (int) (15.21+(12.79)+(11.28)+(18.51));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-16)+(15));
segmentsAcked = (int) (tcb->m_cWnd+(-9)+(-13));
tcb->m_cWnd = (int) (-10+(-13));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-17)+(3));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(13)+(11));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-9)+(18));
segmentsAcked = (int) (tcb->m_cWnd+(3)+(10));
segmentsAcked = (int) (tcb->m_cWnd+(19)+(1));
