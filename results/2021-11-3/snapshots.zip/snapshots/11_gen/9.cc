float oQoPAodzgRdiuYTu = (float) (1-(9)-(14)-(-13));
tcb->m_cWnd = (int) (14+(9));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (1+(6));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-8)+(-3));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-20)+(13));
