if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.84-(tcb->m_cWnd)-(14.32));

} else {
	tcb->m_cWnd = (int) (1.67*(17.2)*(8.39)*(8.79));

}
float oQoPAodzgRdiuYTu = (float) (7-(-8));
tcb->m_cWnd = (int) (4+(12));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(4)+(-14));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-2)+(-7));
segmentsAcked = (int) (tcb->m_cWnd+(1)+(1));
segmentsAcked = (int) (tcb->m_cWnd+(1)+(-15));
