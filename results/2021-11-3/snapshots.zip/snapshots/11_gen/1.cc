CongestionAvoidance (tcb, segmentsAcked);
float oQoPAodzgRdiuYTu = (float) (12+(-18));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.61*(16));

} else {
	tcb->m_cWnd = (int) (15.21+(12.79)+(11.28)+(18.51));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-20)+(-3));
tcb->m_cWnd = (int) (5+(0));
segmentsAcked = (int) (tcb->m_cWnd+(1)+(-15));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(16)+(13));
segmentsAcked = (int) (tcb->m_cWnd+(14)+(-18));
