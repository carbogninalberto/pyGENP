if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (11.42-(13.83));

} else {
	tcb->m_cWnd = (int) (segmentsAcked-(16.42));

}
float oQoPAodzgRdiuYTu = (float) (14-(18)-(18));
tcb->m_cWnd = (int) (-13+(-12));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(15)+(2));
segmentsAcked = (int) (tcb->m_cWnd+(6)+(2));
