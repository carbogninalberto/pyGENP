tcb->m_cWnd = (int) (10+(5)+(2));
float oQoPAodzgRdiuYTu = (float) (-3+(17)+(-17));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-17+(13));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-8)+(-14));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(14)+(-13));
