tcb->m_cWnd = (int) (18+(16));
float oQoPAodzgRdiuYTu = (float) (-10+(9)+(-12)+(-16));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-6)+(-3));
segmentsAcked = (int) (tcb->m_cWnd+(-8)+(-16));
