tcb->m_cWnd = (int) (14*(1)*(8));
float oQoPAodzgRdiuYTu = (float) (18+(-16)+(17));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (10+(6));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(13)+(-7));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(8)+(-6));
