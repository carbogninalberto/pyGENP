float oQoPAodzgRdiuYTu = (float) (-4-(-4)-(-2)-(-8));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.61*(16));

} else {
	tcb->m_cWnd = (int) (15.21+(12.79)+(11.28)+(18.51));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(5)+(-5));
tcb->m_cWnd = (int) (-2+(-5));
segmentsAcked = (int) (tcb->m_cWnd+(7)+(11));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(4)+(-13));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(10)+(4));
segmentsAcked = (int) (tcb->m_cWnd+(13)+(-16));
segmentsAcked = (int) (tcb->m_cWnd+(11)+(-10));
