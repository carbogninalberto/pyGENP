tcb->m_cWnd = (int) (-18+(3));
float oQoPAodzgRdiuYTu = (float) (-6+(-10));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-19)+(-7));
segmentsAcked = (int) (tcb->m_cWnd+(4)+(8));
