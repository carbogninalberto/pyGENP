float oQoPAodzgRdiuYTu = (float) (-18+(-4));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.84-(tcb->m_cWnd)-(14.32));

} else {
	tcb->m_cWnd = (int) (1.67*(17.2)*(8.39)*(8.79));

}
tcb->m_cWnd = (int) (-4+(13));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-6)+(-6));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(14)+(-10));
segmentsAcked = (int) (tcb->m_cWnd+(-5)+(-4));
segmentsAcked = (int) (tcb->m_cWnd+(-20)+(14));
