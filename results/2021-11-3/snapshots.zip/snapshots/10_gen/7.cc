float oQoPAodzgRdiuYTu = (float) (-5-(-5)-(7)-(12));
if (tcb->m_cWnd == tcb->m_cWnd) {
	oQoPAodzgRdiuYTu = (float) (oQoPAodzgRdiuYTu+(oQoPAodzgRdiuYTu));

} else {
	oQoPAodzgRdiuYTu = (float) (15.14+(oQoPAodzgRdiuYTu)+(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (2+(7));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-1+(17));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-16)+(-12));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(2)+(12));
