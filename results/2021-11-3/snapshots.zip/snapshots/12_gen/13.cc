tcb->m_cWnd = (int) (15+(-9));
float oQoPAodzgRdiuYTu = (float) (-8+(-13)+(-3)+(5));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (11+(-1));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-14)+(15));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-4)+(-19));
