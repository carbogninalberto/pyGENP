float oQoPAodzgRdiuYTu = (float) (16-(-6)-(-7));
if (tcb->m_cWnd == tcb->m_cWnd) {
	oQoPAodzgRdiuYTu = (float) (9.51-(3.18)-(0.46));

} else {
	oQoPAodzgRdiuYTu = (float) (6.68+(18.26));

}
tcb->m_cWnd = (int) (17+(-6));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(19)+(-4));
segmentsAcked = (int) (tcb->m_cWnd+(18)+(6));
