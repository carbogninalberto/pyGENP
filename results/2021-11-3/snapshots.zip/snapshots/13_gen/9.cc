float oQoPAodzgRdiuYTu = (float) (-15+(14)+(18)+(1));
tcb->m_cWnd = (int) (-17+(1));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (9+(19));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(7)+(-17));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(1)+(5));
