float oQoPAodzgRdiuYTu = (float) (12-(8)-(-6));
tcb->m_cWnd = (int) (12+(15));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-16)+(12));
segmentsAcked = (int) (tcb->m_cWnd+(-18)+(13));
