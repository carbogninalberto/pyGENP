CongestionAvoidance (tcb, segmentsAcked);
float oQoPAodzgRdiuYTu = (float) (7-(12)-(-10)-(16));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.61*(16));

} else {
	tcb->m_cWnd = (int) (15.21+(12.79)+(11.28)+(18.51));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-4)+(-8));
tcb->m_cWnd = (int) (-20+(18));
segmentsAcked = (int) (tcb->m_cWnd+(-12)+(-11));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-20)+(-14));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-3)+(17));
segmentsAcked = (int) (tcb->m_cWnd+(14)+(-12));
segmentsAcked = (int) (tcb->m_cWnd+(4)+(-15));
