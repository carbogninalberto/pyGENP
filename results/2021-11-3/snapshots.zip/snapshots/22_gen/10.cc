float oQoPAodzgRdiuYTu = (float) (-7-(14)-(-13)-(-10));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.61*(16));

} else {
	tcb->m_cWnd = (int) (15.21+(12.79)+(11.28)+(18.51));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(9)+(-14));
tcb->m_cWnd = (int) (-1+(16));
segmentsAcked = (int) (tcb->m_cWnd+(11)+(-4));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-9)+(-10));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(9)+(0));
segmentsAcked = (int) (tcb->m_cWnd+(3)+(-13));
segmentsAcked = (int) (tcb->m_cWnd+(-15)+(0));
