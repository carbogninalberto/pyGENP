float oQoPAodzgRdiuYTu = (float) (-4-(3)-(-13));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.61*(16));

} else {
	tcb->m_cWnd = (int) (15.21+(12.79)+(11.28)+(18.51));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(9)+(19));
tcb->m_cWnd = (int) (-1+(14));
segmentsAcked = (int) (tcb->m_cWnd+(2)+(-4));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-19)+(-5));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-5)+(-17));
segmentsAcked = (int) (tcb->m_cWnd+(-13)+(-16));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-4)+(11));
segmentsAcked = (int) (tcb->m_cWnd+(0)+(-12));
segmentsAcked = (int) (tcb->m_cWnd+(-9)+(2));
segmentsAcked = (int) (tcb->m_cWnd+(-15)+(8));
segmentsAcked = (int) (tcb->m_cWnd+(-14)+(-18));
