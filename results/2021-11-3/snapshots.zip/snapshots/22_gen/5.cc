tcb->m_cWnd = (int) (13*(-10)*(3));
float oQoPAodzgRdiuYTu = (float) (4+(6)+(-5)+(13));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-10)+(0));
segmentsAcked = (int) (tcb->m_cWnd+(4)+(-4));
