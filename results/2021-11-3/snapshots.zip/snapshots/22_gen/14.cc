tcb->m_cWnd = (int) (17+(3)+(19));
float oQoPAodzgRdiuYTu = (float) (-5+(14)+(-7)+(-6));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (6+(4));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(7)+(-12));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-19)+(-11));
