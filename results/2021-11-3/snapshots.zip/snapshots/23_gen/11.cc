float oQoPAodzgRdiuYTu = (float) (15+(8)+(11)+(-18));
tcb->m_cWnd = (int) (-1*(9)*(-6));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-18)+(-8));
segmentsAcked = (int) (tcb->m_cWnd+(-8)+(-13));
