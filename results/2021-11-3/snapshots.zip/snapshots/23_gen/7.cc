float oQoPAodzgRdiuYTu = (float) (-10+(9)+(14)+(6));
tcb->m_cWnd = (int) (7+(9)+(-14));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (5+(-5));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(5)+(-1));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-1)+(12));
