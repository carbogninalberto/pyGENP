float oQoPAodzgRdiuYTu = (float) (-2-(13)-(3)-(10));
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (10.22-(15.2)-(14.28)-(12.33));

} else {
	segmentsAcked = (int) (oQoPAodzgRdiuYTu+(tcb->m_cWnd)+(12.46)+(segmentsAcked));

}
tcb->m_cWnd = (int) (18+(0));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-8)+(-11));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(15)+(-8));
segmentsAcked = (int) (tcb->m_cWnd+(-1)+(7));
segmentsAcked = (int) (tcb->m_cWnd+(-18)+(10));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.84-(tcb->m_cWnd)-(14.32));

} else {
	tcb->m_cWnd = (int) (1.67*(17.2)*(8.39)*(8.79));

}
tcb->m_cWnd = (int) (-14+(6));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(14)+(-17));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(10)+(-5));
segmentsAcked = (int) (tcb->m_cWnd+(-13)+(13));
segmentsAcked = (int) (tcb->m_cWnd+(-18)+(-6));
