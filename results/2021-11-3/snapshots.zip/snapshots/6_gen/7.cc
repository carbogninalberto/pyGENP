float oQoPAodzgRdiuYTu = (float) (-8+(-2));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.61*(16));

} else {
	tcb->m_cWnd = (int) (15.21+(12.79)+(11.28)+(18.51));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(4)+(-3));
tcb->m_cWnd = (int) (15+(-14));
segmentsAcked = (int) (tcb->m_cWnd+(15)+(-8));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(9)+(6));
segmentsAcked = (int) (tcb->m_cWnd+(10)+(-14));
