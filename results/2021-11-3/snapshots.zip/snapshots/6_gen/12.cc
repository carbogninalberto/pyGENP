float oQoPAodzgRdiuYTu = (float) (5-(12)-(9));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(14.33));

} else {
	tcb->m_cWnd = (int) (3.02+(10.66));

}
tcb->m_cWnd = (int) (-10+(14));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-18)+(0));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-17)+(-6));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (16.73+(tcb->m_cWnd)+(10.29)+(13.85));

} else {
	tcb->m_cWnd = (int) (18.99+(5.48)+(0.98));

}
tcb->m_cWnd = (int) (1+(18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(19)+(-13));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(4)+(-13));
