float oQoPAodzgRdiuYTu = (float) (4-(0)-(6));
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (oQoPAodzgRdiuYTu+(13.99)+(oQoPAodzgRdiuYTu));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize-(12.74));

}
tcb->m_cWnd = (int) (-19+(2));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(15)+(-8));
segmentsAcked = (int) (tcb->m_cWnd+(-2)+(4));
