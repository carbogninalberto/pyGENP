float oQoPAodzgRdiuYTu = (float) (15-(-17));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (16.73+(tcb->m_cWnd)+(10.29)+(13.85));

} else {
	tcb->m_cWnd = (int) (18.99+(5.48)+(0.98));

}
tcb->m_cWnd = (int) (15+(-15));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(3)+(-19));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-10)+(14));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(13)+(3));
segmentsAcked = (int) (tcb->m_cWnd+(-2)+(9));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(13)+(3));
segmentsAcked = (int) (tcb->m_cWnd+(1)+(13));
segmentsAcked = (int) (tcb->m_cWnd+(-9)+(14));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(15)+(-4));
