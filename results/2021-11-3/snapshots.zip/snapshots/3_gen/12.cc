if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.55*(7.37)*(1.05));

} else {
	tcb->m_cWnd = (int) (10.57-(12.63));

}
float oQoPAodzgRdiuYTu = (float) (4-(-1)-(1));
tcb->m_cWnd = (int) (16+(-16));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.55*(7.37)*(1.05));

} else {
	tcb->m_cWnd = (int) (10.57-(12.63));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (11+(-14));
segmentsAcked = (int) (tcb->m_cWnd+(-11)+(0));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-6)+(2));
