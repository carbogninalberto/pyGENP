if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (5.33-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (9.03+(9.15));

}
float oQoPAodzgRdiuYTu = (float) (-19*(-10));
tcb->m_cWnd = (int) (-11+(18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-5)+(8));
segmentsAcked = (int) (tcb->m_cWnd+(16)+(-17));
