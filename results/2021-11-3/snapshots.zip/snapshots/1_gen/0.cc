segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
if (tcb->m_segmentSize <= tcb->m_cWnd) {
	tcb->m_cWnd = (int) (19.69*(5.35));

} else {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(2.91)-(17.58));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
int RBSKiAvsSsNxPHHR = (int) (6.46+(5.05)+(7.39)+(tcb->m_segmentSize));
