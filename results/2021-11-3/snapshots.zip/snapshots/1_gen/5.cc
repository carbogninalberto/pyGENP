tcb->m_segmentSize = (int) (tcb->m_segmentSize*(segmentsAcked)*(tcb->m_segmentSize)*(1.12));
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(5.57)+(segmentsAcked));
if (segmentsAcked != tcb->m_cWnd) {
	segmentsAcked = (int) (2.94-(14.24)-(12.54));

} else {
	segmentsAcked = (int) (13.36*(6.94)*(tcb->m_cWnd)*(tcb->m_cWnd));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
segmentsAcked = SlowStart (tcb, segmentsAcked);
