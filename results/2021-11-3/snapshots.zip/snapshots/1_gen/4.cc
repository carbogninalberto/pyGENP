tcb->m_segmentSize = (int) (10.99*(4.03)*(tcb->m_cWnd)*(17.04));
int nmMoZMJgFOXzDXnz = (int) (tcb->m_cWnd-(8.0)-(7.13));
tcb->m_cWnd = (int) (0.56+(19.09)+(segmentsAcked));
tcb->m_cWnd = (int) (10.08*(0.28));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
