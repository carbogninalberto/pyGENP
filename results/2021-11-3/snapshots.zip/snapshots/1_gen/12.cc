TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (4.25-(18.55));

} else {
	tcb->m_segmentSize = (int) (segmentsAcked-(segmentsAcked));

}
if (tcb->m_cWnd <= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (1.08-(11.73)-(6.11));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(5.22)-(16.6));

}
segmentsAcked = (int) (16.42-(8.84)-(11.44)-(16.62));
segmentsAcked = (int) (7.75-(segmentsAcked)-(3.88));
