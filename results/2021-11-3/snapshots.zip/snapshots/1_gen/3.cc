segmentsAcked = (int) (14.94-(14.69)-(17.8));
tcb->m_cWnd = (int) (tcb->m_cWnd+(17.4)+(18.0));
tcb->m_cWnd = (int) (19.85*(11.89)*(16.52));
if (tcb->m_segmentSize >= tcb->m_segmentSize) {
	segmentsAcked = (int) (16.44-(13.17)-(19.91));

} else {
	segmentsAcked = (int) (14.53-(segmentsAcked)-(19.28)-(6.69));

}
segmentsAcked = (int) (4.7-(11.62)-(7.75)-(tcb->m_segmentSize));
segmentsAcked = (int) (2.0*(2.96)*(segmentsAcked)*(13.12));
