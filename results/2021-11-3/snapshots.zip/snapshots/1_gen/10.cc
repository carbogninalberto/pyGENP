tcb->m_cWnd = (int) (7.3-(10.5)-(11.79)-(4.2));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (7.15+(0.24));
if (tcb->m_cWnd >= segmentsAcked) {
	tcb->m_segmentSize = (int) (6.15+(10.92));

} else {
	tcb->m_segmentSize = (int) (10.14-(8.24));

}
segmentsAcked = SlowStart (tcb, segmentsAcked);
tcb->m_segmentSize = (int) (18.16*(13.67));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd <= tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (16.52-(tcb->m_cWnd)-(9.71));

} else {
	tcb->m_cWnd = (int) (18.27+(8.03)+(18.29));

}
