float oQoPAodzgRdiuYTu = (float) (-16+(14)+(-17));
tcb->m_cWnd = (int) (16*(-19)*(13));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (11+(10));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(6)+(17));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(0)+(-2));
