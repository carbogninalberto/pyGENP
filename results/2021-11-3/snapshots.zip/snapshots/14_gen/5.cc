tcb->m_cWnd = (int) (17+(-1));
float oQoPAodzgRdiuYTu = (float) (13+(-7)+(15)+(2));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (0+(1));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(12)+(13));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-4)+(16));
