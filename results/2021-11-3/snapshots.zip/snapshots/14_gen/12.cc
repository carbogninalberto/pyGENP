tcb->m_cWnd = (int) (-20+(6));
float oQoPAodzgRdiuYTu = (float) (15+(6)+(19)+(11));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(0)+(13));
segmentsAcked = (int) (tcb->m_cWnd+(-8)+(-14));
