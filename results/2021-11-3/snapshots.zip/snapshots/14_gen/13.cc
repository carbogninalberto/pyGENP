float oQoPAodzgRdiuYTu = (float) (-2-(-14));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.61*(16));

} else {
	tcb->m_cWnd = (int) (15.21+(12.79)+(11.28)+(18.51));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-16)+(11));
segmentsAcked = (int) (tcb->m_cWnd+(-10)+(-12));
tcb->m_cWnd = (int) (16+(-18));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-17)+(-5));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(13)+(-9));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(11)+(4));
segmentsAcked = (int) (tcb->m_cWnd+(19)+(-12));
segmentsAcked = (int) (tcb->m_cWnd+(1)+(-17));
