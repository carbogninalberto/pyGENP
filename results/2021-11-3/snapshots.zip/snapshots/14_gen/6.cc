float oQoPAodzgRdiuYTu = (float) (-11+(-2));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.61*(16));

} else {
	tcb->m_cWnd = (int) (15.21+(12.79)+(11.28)+(18.51));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-19)+(6));
tcb->m_cWnd = (int) (10+(11));
segmentsAcked = (int) (tcb->m_cWnd+(-8)+(-19));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-18)+(-2));
segmentsAcked = (int) (tcb->m_cWnd+(-14)+(13));
