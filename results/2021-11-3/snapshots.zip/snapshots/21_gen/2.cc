float oQoPAodzgRdiuYTu = (float) (-14+(-7)+(-1));
tcb->m_cWnd = (int) (2+(5)+(oQoPAodzgRdiuYTu));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-6+(-7));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-13)+(7));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-4)+(-16));
