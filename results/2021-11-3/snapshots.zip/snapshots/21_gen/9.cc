float WpTKkfthoUgtreIz = (float) (-20*(-9)*(18));
TcpLinuxCongestionAvoidance (tcb, segmentsAcked);
float rIwNSdMikbUsRumE = (float) (-15+(-7)+(7)+(-15));
CongestionAvoidance (tcb, segmentsAcked);
float zSONGnzIbZqsGJSY = (float) (-10*(0));
CongestionAvoidance (tcb, segmentsAcked);
if (rIwNSdMikbUsRumE >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (2.47+(13.4)+(3.47)+(2.58));

} else {
	tcb->m_segmentSize = (int) (0.42+(tcb->m_segmentSize)+(16.82));

}
if (rIwNSdMikbUsRumE >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (2.47+(13.4)+(3.47)+(2.58));

} else {
	tcb->m_segmentSize = (int) (0.42+(tcb->m_segmentSize)+(16.82));

}
if (rIwNSdMikbUsRumE >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (2.47+(13.4)+(3.47)+(2.58));

} else {
	tcb->m_segmentSize = (int) (0.42+(tcb->m_segmentSize)+(16.82));

}
if (rIwNSdMikbUsRumE >= tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (2.47+(13.4)+(3.47)+(2.58));

} else {
	tcb->m_segmentSize = (int) (0.42+(tcb->m_segmentSize)+(16.82));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) (16.51+(7.96)+(5.28)+(3.92));

} else {
	segmentsAcked = (int) (10.71+(segmentsAcked)+(3.75)+(2.52));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) (16.51+(7.96)+(5.28)+(3.92));

} else {
	segmentsAcked = (int) (10.71+(segmentsAcked)+(3.75)+(2.52));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) (16.51+(7.96)+(5.28)+(3.92));

} else {
	segmentsAcked = (int) (10.71+(segmentsAcked)+(3.75)+(2.52));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) (16.51+(7.96)+(5.28)+(3.92));

} else {
	segmentsAcked = (int) (10.71+(segmentsAcked)+(3.75)+(2.52));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) (16.51+(7.96)+(5.28)+(3.92));

} else {
	segmentsAcked = (int) (10.71+(segmentsAcked)+(3.75)+(2.52));

}
if (tcb->m_cWnd != tcb->m_segmentSize) {
	segmentsAcked = (int) (16.51+(7.96)+(5.28)+(3.92));

} else {
	segmentsAcked = (int) (10.71+(segmentsAcked)+(3.75)+(2.52));

}
