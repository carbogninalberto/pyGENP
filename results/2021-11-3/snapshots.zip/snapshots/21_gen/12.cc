float oQoPAodzgRdiuYTu = (float) (-13+(6));
tcb->m_cWnd = (int) (-18*(oQoPAodzgRdiuYTu)*(oQoPAodzgRdiuYTu));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(7)+(4));
segmentsAcked = (int) (tcb->m_cWnd+(16)+(12));
