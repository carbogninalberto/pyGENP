float oQoPAodzgRdiuYTu = (float) (15+(-3)+(18)+(-13));
tcb->m_cWnd = (int) (9+(-10)+(-17));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (15+(-13));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(15)+(8));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(15)+(-16));
