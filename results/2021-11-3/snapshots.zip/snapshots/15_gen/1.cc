float oQoPAodzgRdiuYTu = (float) (-9+(7));
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (-3-(17.66)-(10.73));

} else {
	segmentsAcked = (int) (2.26-(0.82)-(segmentsAcked)-(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (3+(-9));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-11)+(3));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(12)+(-1));
segmentsAcked = (int) (tcb->m_cWnd+(-19)+(9));
segmentsAcked = (int) (tcb->m_cWnd+(0)+(-11));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.84-(tcb->m_cWnd)-(14.32));

} else {
	tcb->m_cWnd = (int) (1.67*(17.2)*(8.39)*(8.79));

}
tcb->m_cWnd = (int) (-2+(-16));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(2)+(-20));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(4)+(-5));
segmentsAcked = (int) (tcb->m_cWnd+(-4)+(3));
segmentsAcked = (int) (tcb->m_cWnd+(0)+(12));
