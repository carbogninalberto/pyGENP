float oQoPAodzgRdiuYTu = (float) (5-(16)-(6)-(-20));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.61*(16));

} else {
	tcb->m_cWnd = (int) (15.21+(12.79)+(11.28)+(18.51));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(2)+(6));
tcb->m_cWnd = (int) (11+(-18));
segmentsAcked = (int) (tcb->m_cWnd+(-18)+(13));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(2)+(-20));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-14)+(0));
segmentsAcked = (int) (tcb->m_cWnd+(-13)+(1));
segmentsAcked = (int) (tcb->m_cWnd+(9)+(-18));
