tcb->m_cWnd = (int) (14+(16));
float oQoPAodzgRdiuYTu = (float) (2+(3));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-14)+(17));
segmentsAcked = (int) (tcb->m_cWnd+(-9)+(-2));
