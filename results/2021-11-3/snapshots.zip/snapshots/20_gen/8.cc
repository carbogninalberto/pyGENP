tcb->m_cWnd = (int) (5*(-4)*(4));
float oQoPAodzgRdiuYTu = (float) (9+(-2)+(2));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-16+(9));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-18)+(-15));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-7)+(7));
