float oQoPAodzgRdiuYTu = (float) (-14-(-13)-(6));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.61*(16));

} else {
	tcb->m_cWnd = (int) (15.21+(12.79)+(11.28)+(18.51));

}
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(7)+(-5));
tcb->m_cWnd = (int) (16+(-18));
segmentsAcked = (int) (tcb->m_cWnd+(12)+(18));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(13)+(-8));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-5)+(5));
segmentsAcked = (int) (tcb->m_cWnd+(-5)+(19));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-19)+(-19));
segmentsAcked = (int) (tcb->m_cWnd+(-17)+(-8));
segmentsAcked = (int) (tcb->m_cWnd+(-7)+(-13));
segmentsAcked = (int) (tcb->m_cWnd+(-14)+(-10));
segmentsAcked = (int) (tcb->m_cWnd+(-17)+(-15));
