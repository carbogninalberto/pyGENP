tcb->m_cWnd = (int) (0*(-7)*(9));
float oQoPAodzgRdiuYTu = (float) (18+(-10)+(-2)+(19));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(4)+(-16));
segmentsAcked = (int) (tcb->m_cWnd+(1)+(-3));
