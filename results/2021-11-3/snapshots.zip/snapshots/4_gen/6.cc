float oQoPAodzgRdiuYTu = (float) (18-(13)-(-9));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.55*(7.37)*(1.05));

} else {
	tcb->m_cWnd = (int) (10.57-(12.63));

}
tcb->m_cWnd = (int) (13+(18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(7)+(1));
