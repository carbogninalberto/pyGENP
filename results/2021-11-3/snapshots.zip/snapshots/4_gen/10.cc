float oQoPAodzgRdiuYTu = (float) (12-(13)-(8));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_segmentSize = (int) (8.72-(tcb->m_segmentSize)-(8.86));

} else {
	tcb->m_segmentSize = (int) (6.06*(0.68));

}
tcb->m_cWnd = (int) (-18+(-6));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.55*(7.37)*(1.05));

} else {
	tcb->m_cWnd = (int) (10.57-(12.63));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-12+(13));
segmentsAcked = (int) (tcb->m_cWnd+(-11)+(-7));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(8)+(-20));
