float oQoPAodzgRdiuYTu = (float) (-8-(5)-(-3));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.61*(18));

} else {
	tcb->m_cWnd = (int) (15.21+(12.79)+(11.28)+(18.51));

}
tcb->m_cWnd = (int) (14+(6));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(3)+(-14));
segmentsAcked = (int) (tcb->m_cWnd+(-8)+(-12));
