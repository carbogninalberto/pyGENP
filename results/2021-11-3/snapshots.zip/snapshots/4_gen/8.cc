float oQoPAodzgRdiuYTu = (float) (-19-(8)-(-8));
if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (oQoPAodzgRdiuYTu-(0.87)-(tcb->m_cWnd));

} else {
	segmentsAcked = (int) (6.98+(tcb->m_cWnd));

}
tcb->m_cWnd = (int) (-15+(8));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(19)+(-20));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(10)+(-11));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (16.73+(tcb->m_cWnd)+(10.29)+(13.85));

} else {
	tcb->m_cWnd = (int) (18.99+(5.48)+(0.98));

}
tcb->m_cWnd = (int) (-8+(-3));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(3)+(0));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-3)+(-12));
