float oQoPAodzgRdiuYTu = (float) (-18+(6));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (0.11-(6.81)-(7.86));

} else {
	tcb->m_cWnd = (int) (11.0*(tcb->m_segmentSize)*(11.97)*(9.84));

}
tcb->m_cWnd = (int) (12+(-20));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-2+(14));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-15)+(-9));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(9)+(6));
