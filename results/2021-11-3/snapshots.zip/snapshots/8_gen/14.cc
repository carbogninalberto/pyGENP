float oQoPAodzgRdiuYTu = (float) (-11*(-17)*(-2));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (13.81-(1.94)-(9.11));

} else {
	tcb->m_cWnd = (int) (12.33+(tcb->m_segmentSize)+(oQoPAodzgRdiuYTu));

}
tcb->m_cWnd = (int) (-9+(5));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(15)+(6));
segmentsAcked = (int) (tcb->m_cWnd+(-3)+(10));
segmentsAcked = (int) (tcb->m_cWnd+(0)+(-14));
segmentsAcked = (int) (tcb->m_cWnd+(-6)+(10));
