if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.55*(7.37)*(1.05));

} else {
	tcb->m_cWnd = (int) (10.57-(12.63));

}
float oQoPAodzgRdiuYTu = (float) (8*(-4));
tcb->m_cWnd = (int) (-5+(3));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (4+(-1));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.55*(7.37)*(1.05));

} else {
	tcb->m_cWnd = (int) (10.57-(12.63));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-14+(2));
segmentsAcked = (int) (tcb->m_cWnd+(-17)+(-15));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-14+(10));
segmentsAcked = (int) (tcb->m_cWnd+(-19)+(-5));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(19)+(16));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(9)+(1));
