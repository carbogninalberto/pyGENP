float oQoPAodzgRdiuYTu = (float) (-10+(11));
if (tcb->m_cWnd == tcb->m_cWnd) {
	oQoPAodzgRdiuYTu = (float) (10.26+(12.78)+(tcb->m_cWnd)+(10.1));

} else {
	oQoPAodzgRdiuYTu = (float) (oQoPAodzgRdiuYTu-(12.83));

}
tcb->m_cWnd = (int) (-19+(-11));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-14+(8));
segmentsAcked = (int) (tcb->m_cWnd+(19)+(-10));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-17)+(7));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-14)+(13));
