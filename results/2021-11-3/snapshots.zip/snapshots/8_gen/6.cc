float oQoPAodzgRdiuYTu = (float) (2-(8)-(2));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (tcb->m_cWnd-(14.33));

} else {
	tcb->m_cWnd = (int) (3.02+(10.66));

}
tcb->m_cWnd = (int) (-14+(-7));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-10)+(17));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(1)+(16));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (16.73+(tcb->m_cWnd)+(10.29)+(13.85));

} else {
	tcb->m_cWnd = (int) (18.99+(5.48)+(0.98));

}
tcb->m_cWnd = (int) (5+(-3));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-2)+(3));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-2)+(15));
