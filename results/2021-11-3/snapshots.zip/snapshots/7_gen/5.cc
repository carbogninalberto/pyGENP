if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.55*(7.37)*(1.05));

} else {
	tcb->m_cWnd = (int) (10.57-(12.63));

}
float oQoPAodzgRdiuYTu = (float) (18+(6));
tcb->m_cWnd = (int) (3+(15));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-4+(8));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-3)+(5));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(5)+(19));
