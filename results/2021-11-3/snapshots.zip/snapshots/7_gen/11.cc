float oQoPAodzgRdiuYTu = (float) (-17-(9)-(-15));
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.55*(7.37)*(1.05));

} else {
	tcb->m_cWnd = (int) (10.57-(12.63));

}
tcb->m_cWnd = (int) (-17+(0));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-14+(-14));
CongestionAvoidance (tcb, segmentsAcked);
if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (18.55*(7.37)*(1.05));

} else {
	tcb->m_cWnd = (int) (10.57-(12.63));

}
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-12+(5));
segmentsAcked = (int) (tcb->m_cWnd+(-10)+(7));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-17+(-20));
segmentsAcked = (int) (tcb->m_cWnd+(-11)+(19));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(4)+(15));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-20)+(6));
