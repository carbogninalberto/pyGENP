if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (16+(13.99)+(-18));

} else {
	segmentsAcked = (int) (tcb->m_segmentSize-(12.74));

}
float oQoPAodzgRdiuYTu = (float) (-5*(-17)*(-16));
tcb->m_cWnd = (int) (-16+(-18));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(18)+(3));
segmentsAcked = (int) (tcb->m_cWnd+(-8)+(0));
