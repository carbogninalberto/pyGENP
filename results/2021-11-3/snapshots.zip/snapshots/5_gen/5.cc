if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (16.73+(tcb->m_cWnd)+(10.29)+(13.85));

} else {
	tcb->m_cWnd = (int) (18.99+(5.48)+(0.98));

}
float oQoPAodzgRdiuYTu = (float) (0-(-16)-(-14));
tcb->m_cWnd = (int) (-10+(-4));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(11)+(8));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(2)+(-12));
segmentsAcked = (int) (tcb->m_cWnd+(-3)+(8));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(18)+(-15));
