if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (6.61*(18));

} else {
	tcb->m_cWnd = (int) (15.21+(12.79)+(11.28)+(18.51));

}
float oQoPAodzgRdiuYTu = (float) (18-(6)-(6));
tcb->m_cWnd = (int) (2+(3));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-3)+(-6));
segmentsAcked = (int) (tcb->m_cWnd+(16)+(-8));
