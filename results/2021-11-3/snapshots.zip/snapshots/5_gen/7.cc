if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (17.17-(11.19)-(12.33)-(1.34));

} else {
	tcb->m_cWnd = (int) (10.94+(tcb->m_segmentSize));

}
float oQoPAodzgRdiuYTu = (float) (-18-(-17)-(5));
tcb->m_cWnd = (int) (-11+(4));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(12)+(17));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(12)+(10));
