if (tcb->m_cWnd == tcb->m_cWnd) {
	segmentsAcked = (int) (5.33-(tcb->m_segmentSize));

} else {
	segmentsAcked = (int) (9.03+(9.15));

}
float oQoPAodzgRdiuYTu = (float) (-17*(-11));
tcb->m_cWnd = (int) (-2+(14));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-12)+(-9));
segmentsAcked = (int) (tcb->m_cWnd+(-16)+(-12));
