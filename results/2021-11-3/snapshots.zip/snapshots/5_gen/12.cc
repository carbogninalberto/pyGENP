if (tcb->m_cWnd == tcb->m_cWnd) {
	tcb->m_cWnd = (int) (16.73+(tcb->m_cWnd)+(10.29)+(13.85));

} else {
	tcb->m_cWnd = (int) (18.99+(5.48)+(0.98));

}
float oQoPAodzgRdiuYTu = (float) (-8-(5)-(15));
CongestionAvoidance (tcb, segmentsAcked);
tcb->m_cWnd = (int) (-10+(10));
CongestionAvoidance (tcb, segmentsAcked);
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(3)+(9));
CongestionAvoidance (tcb, segmentsAcked);
segmentsAcked = (int) (tcb->m_cWnd+(-8)+(4));
