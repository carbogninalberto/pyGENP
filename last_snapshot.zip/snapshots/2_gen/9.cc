tcb->m_segmentSize = (int) (-10.07)/(18.35);
float cpmok = (float) (2.31+(1.54));
float sorqj = (float) (1.28)/(-5.15);
