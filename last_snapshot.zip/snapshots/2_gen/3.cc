tcb->m_segmentSize = (int) (18.84*(tcb->m_segmentSize));
