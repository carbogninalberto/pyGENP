tcb->m_segmentSize = (int) (-10.07)/(18.35);
if (false) {
	tcb->m_segmentSize = (int) (3.18+(-19.28));

} else {
	tcb->m_segmentSize = (int) (19.81-(12.16)-(14.31));

}
if (false) {
	tcb->m_segmentSize = (int) (-19.87*(15.4));

} else {
	tcb->m_segmentSize = (int) (14.22*(-5.63));

}
