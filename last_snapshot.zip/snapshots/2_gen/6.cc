float cpmok = (float) (-13.3*(sorqj));
tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(8.96);
