tcb->m_segmentSize = (int) (tcb->m_segmentSize-(3.16));
float cpmok = (float) (14.9)/(cpmok);
tcb->m_segmentSize = (int) (1.75-(-5.36)-(8.39)-(19.28));
