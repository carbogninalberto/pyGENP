tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-2.25)-(-16.62));
float cpmok = (float) (2.31+(1.54));
float sorqj = (float) (1.28)/(-5.15);
