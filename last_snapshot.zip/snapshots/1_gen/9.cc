tcb->m_segmentSize = (int) (-16.69-(tcb->m_segmentSize));
