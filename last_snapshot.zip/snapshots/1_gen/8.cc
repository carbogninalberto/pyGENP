tcb->m_segmentSize = (int) (-4.22)/(-19.77);
