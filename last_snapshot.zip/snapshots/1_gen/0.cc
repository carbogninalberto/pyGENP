float wrjoo = (float) (-17.33)/(tcb->m_segmentSize);
wrjoo = (float) (-12.29+(1.87)+(tcb->m_segmentSize));
if (false) {
	wrjoo = (float) (-6.2*(-0.24));

} else {
	wrjoo = (float) (-2.64*(wrjoo));

}
