if (false) {
	tcb->m_segmentSize = (int) (3.48*(-16.85)*(tcb->m_segmentSize)*(-2.11));

} else {
	tcb->m_segmentSize = (int) (13.74)/(1.1);

}
if (false) {
	tcb->m_segmentSize = (int) (0.21-(1.1));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(-19.47)*(16.32)*(19.29));

}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-14.8)-(3.89)-(-17.95));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-10.2);

}
