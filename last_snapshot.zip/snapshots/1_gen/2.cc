float issvo = (float) (0.27-(tcb->m_segmentSize));
if (true) {
	tcb->m_segmentSize = (int) (16.22*(1.49)*(-0.34)*(-18.64));

} else {
	tcb->m_segmentSize = (int) (-17.64+(issvo)+(-17.09)+(-13.52));

}
if (true) {
	tcb->m_segmentSize = (int) (-2.78)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (-19.01+(11.01)+(11.06)+(issvo));

}
