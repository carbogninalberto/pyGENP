if (false) {
	tcb->m_segmentSize = (int) (15.59)/(14.94);

} else {
	tcb->m_segmentSize = (int) (-9.0)/(tcb->m_segmentSize);

}
