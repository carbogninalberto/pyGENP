tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(8.96);
