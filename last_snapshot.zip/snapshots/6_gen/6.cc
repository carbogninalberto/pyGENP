tcb->m_segmentSize = (int) (17.65*(11.72)*(1.73)*(-3.09));
tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-15.14);
tcb->m_segmentSize = (int) (-10.07)/(18.35);
tcb->m_segmentSize = (int) (1.75-(-5.36)-(8.39)-(19.28));
float cpmok = (float) (2.31+(1.54));
float sorqj = (float) (1.28)/(-5.15);
