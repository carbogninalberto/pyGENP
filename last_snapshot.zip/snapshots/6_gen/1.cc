tcb->m_segmentSize = (int) (8.96)/(tcb->m_segmentSize);
tcb->m_segmentSize = (int) (1.75-(-5.36)-(8.39)-(19.28));
float cpmok = (float) (2.31+(1.54));
float sorqj = (float) (1.28)/(-5.15);
