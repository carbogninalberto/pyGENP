tcb->m_segmentSize = (int) (5.24+(6.75));
float cpmok = (float) (14.9)/(cpmok);
tcb->m_segmentSize = (int) (1.75-(-5.36)-(8.39)-(19.28));
