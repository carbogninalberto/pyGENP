BASE_URL = 'https://apps.nsnam.org'
SEARCH_API = '/backend/api/search/'
INSTALL_API = '/backend/api/install/'