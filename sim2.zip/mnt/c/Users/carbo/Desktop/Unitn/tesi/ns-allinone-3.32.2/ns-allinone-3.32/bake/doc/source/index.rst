.. Bake Quick Start Documentation documentation master file, created by
   sphinx-quickstart on Thu Jun 30 10:55:38 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. |br| raw:: html

   <br />

BAKE Documentation
====

Content:

.. toctree::
   :maxdepth: 3

   bake-over
   bake-tutorial

.. how-it-works
   dce-readme
 
    

