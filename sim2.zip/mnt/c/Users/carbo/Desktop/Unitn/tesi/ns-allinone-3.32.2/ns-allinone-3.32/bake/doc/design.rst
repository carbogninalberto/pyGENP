Bake, a software construction tool
==================================

Bake is not a make, autoconf, or automake replacement. 
Bake is not a replacement for the package management
tool that can be found on your home system. Rather,
Bake is an integration tool which is used by software 
developers to automate the reproducible build of a number 
of projects which depend on each other and which might be 
developed, and hosted by unrelated parties.
