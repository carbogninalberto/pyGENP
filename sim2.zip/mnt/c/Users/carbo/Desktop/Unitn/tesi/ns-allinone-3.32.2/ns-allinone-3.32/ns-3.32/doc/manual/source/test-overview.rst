.. include:: replace.txt

Overview
--------

This chapter is concerned with the testing and validation of |ns3| software.

This chapter provides

* background about terminology and software testing 
* a description of the ns-3 testing framework 
* a guide to model developers or new model contributors for how to write tests 

