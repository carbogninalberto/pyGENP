if (false) {
	tcb->m_segmentSize = (int) (12.17)/(5.51);

} else {
	tcb->m_segmentSize = (int) (-5.89-(-6.36)-(tcb->m_segmentSize));

}
if (true) {
	tcb->m_segmentSize = (int) (-15.39)/(-18.5);

} else {
	tcb->m_segmentSize = (int) (-4.3)/(-17.73);

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(tcb->m_segmentSize);
tcb->m_segmentSize = (int) (-16.33*(-19.04)*(-8.66));
