if (true) {
	tcb->m_segmentSize = (int) (-4.33*(-5.54)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-10.23)/(11.51);

}
if (false) {
	tcb->m_segmentSize = (int) (19.99+(tcb->m_segmentSize)+(6.35));

} else {
	tcb->m_segmentSize = (int) (-14.19-(-12.34));

}
tcb->m_segmentSize = (int) (-0.72)/(16.12);
