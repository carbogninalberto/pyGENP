if (false) {
	tcb->m_segmentSize = (int) (6.09-(1.93));

} else {
	tcb->m_segmentSize = (int) (8.84)/(tcb->m_segmentSize);

}
