if (false) {
	tcb->m_segmentSize = (int) (18.95+(-16.09));

} else {
	tcb->m_segmentSize = (int) (-7.88)/(-3.81);

}
tcb->m_segmentSize = (int) (-18.88+(18.23)+(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (6.94)/(-8.6);
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(-14.41)*(7.95));

} else {
	tcb->m_segmentSize = (int) (13.89*(18.13));

}
