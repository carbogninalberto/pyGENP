if (true) {
	tcb->m_segmentSize = (int) (-11.02+(18.0));

} else {
	tcb->m_segmentSize = (int) (13.13-(tcb->m_segmentSize)-(11.54));

}
if (false) {
	tcb->m_segmentSize = (int) (-14.34*(-11.54));

} else {
	tcb->m_segmentSize = (int) (13.72+(-10.33)+(10.85)+(-8.89));

}
