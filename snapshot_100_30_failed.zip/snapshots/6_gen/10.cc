if (false) {
	tcb->m_segmentSize = (int) (-19.65-(17.89));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(18.1)-(11.44));

}
if (false) {
	tcb->m_segmentSize = (int) (-9.03-(-18.4)-(-6.39)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (4.17-(-0.1));

}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(tcb->m_segmentSize)-(-6.67)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-13.88-(14.81)-(19.34)-(-0.21));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(6.34));
