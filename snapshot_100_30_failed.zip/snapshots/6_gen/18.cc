tcb->m_segmentSize = (int) (-11.89+(-3.97)+(11.36)+(-10.36));
tcb->m_segmentSize = (int) (5.8)/(-19.42);
if (false) {
	tcb->m_segmentSize = (int) (11.36)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(18.36));

}
