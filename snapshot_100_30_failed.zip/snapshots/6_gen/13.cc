tcb->m_segmentSize = (int) (tcb->m_segmentSize-(9.26));
tcb->m_segmentSize = (int) (-14.29*(-11.18));
if (true) {
	tcb->m_segmentSize = (int) (-17.69-(9.31));

} else {
	tcb->m_segmentSize = (int) (-14.27*(14.37)*(3.02)*(-9.96));

}
