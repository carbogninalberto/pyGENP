tcb->m_segmentSize = (int) (4.47+(tcb->m_segmentSize)+(19.19));
