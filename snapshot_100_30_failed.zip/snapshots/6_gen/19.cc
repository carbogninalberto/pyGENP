if (true) {
	tcb->m_segmentSize = (int) (14.95+(8.9)+(tcb->m_segmentSize)+(6.74));

} else {
	tcb->m_segmentSize = (int) (12.02*(-2.33)*(12.1)*(-7.34));

}
if (false) {
	tcb->m_segmentSize = (int) (12.89*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.06)/(14.34);

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-17.64);
