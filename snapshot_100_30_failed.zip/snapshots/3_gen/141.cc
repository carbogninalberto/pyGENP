if (false) {
	(0.08*(0.72)*(14.82)*(-10.94))
} else {
	(18.25*(14.16)*(-14.22)*(13.22))
}
if (false) {
	(-1.82)/(tcb->m_segmentSize)
} else {
	(4.85)/(-13.22)
}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-3.98)+(5.06));

} else {
	tcb->m_segmentSize = (int) (4.62*(-7.1));

}
tcb->m_segmentSize = (int) (11.75-(tcb->m_segmentSize)-(-15.0));
