tcb->m_segmentSize = (int) (-12.3-(-16.46)-(tcb->m_segmentSize)-(15.63));
tcb->m_segmentSize = (int) (-6.37*(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (7.65)/(0.67);
