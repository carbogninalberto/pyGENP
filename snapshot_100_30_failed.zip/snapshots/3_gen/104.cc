tcb->m_segmentSize = (int) (10.37*(-19.64)*(8.42));
if (true) {
	tcb->m_segmentSize = (int) (1.67-(0.94)-(-19.49)-(0.25));

} else {
	tcb->m_segmentSize = (int) (2.24-(-0.95)-(17.86));

}
if (false) {
	tcb->m_segmentSize = (int) (-7.64-(2.68));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(3.15)+(-8.7));

}
if (true) {
	tcb->m_segmentSize = (int) (-8.02*(-14.24)*(19.62));

} else {
	tcb->m_segmentSize = (int) (-18.12)/(17.13);

}
