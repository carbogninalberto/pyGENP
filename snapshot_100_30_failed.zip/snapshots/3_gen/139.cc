tcb->m_segmentSize = (int) (-6.37*(tcb->m_segmentSize));
if (true) {
	tcb->m_segmentSize = (int) (6.17+(-0.76)+(13.28)+(-5.78));

} else {
	tcb->m_segmentSize = (int) (3.28)/(-14.95);

}
if (true) {
	tcb->m_segmentSize = (int) (0.13)/(-1.67);

} else {
	tcb->m_segmentSize = (int) (-13.07-(0.38));

}
