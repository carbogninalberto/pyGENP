tcb->m_segmentSize = (int) (tcb->m_segmentSize*(-11.76)*(-14.81)*(5.82));
tcb->m_segmentSize = (int) (-6.37*(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (7.65)/(0.67);
