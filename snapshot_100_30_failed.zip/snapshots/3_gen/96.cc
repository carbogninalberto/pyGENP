if (true) {
	(-9.56+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(17.37))
} else {
	(14.51)/(11.41)
}
tcb->m_segmentSize = (int) (14.42-(-17.52)-(10.33));
tcb->m_segmentSize = (int) (-9.49)/(6.09);
tcb->m_segmentSize = (int) (7.65)/(0.67);
