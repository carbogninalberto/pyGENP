if (false) {
	(-4.21+(-1.05)+(-16.49))
} else {
	(-13.09*(tcb->m_segmentSize)*(-17.69)*(-16.12))
}
tcb->m_segmentSize = (int) (14.42-(-17.52)-(10.33));
tcb->m_segmentSize = (int) (-9.49)/(6.09);
tcb->m_segmentSize = (int) (7.65)/(0.67);
