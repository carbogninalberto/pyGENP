tcb->m_segmentSize = (int) (-19.63*(14.94)*(19.71));
tcb->m_segmentSize = (int) (10.37*(-19.64)*(8.42));
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-12.22);

} else {
	tcb->m_segmentSize = (int) (-17.32-(-7.4)-(14.24));

}
tcb->m_segmentSize = (int) (-6.47+(-19.11)+(-2.37)+(-13.31));
tcb->m_segmentSize = (int) (16.91)/(14.71);
tcb->m_segmentSize = (int) (-17.75+(-6.93)+(-8.24));
