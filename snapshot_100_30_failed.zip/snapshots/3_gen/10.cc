if (true) {
	(17.83-(-10.36)-(tcb->m_segmentSize)-(5.41))
} else {
	(tcb->m_segmentSize-(tcb->m_segmentSize)-(-6.54))
}
tcb->m_segmentSize = (int) (-9.49)/(6.09);
tcb->m_segmentSize = (int) (7.65)/(0.67);
