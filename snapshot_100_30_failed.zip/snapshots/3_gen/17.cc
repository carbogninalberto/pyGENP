if (true) {
	(19.57+(-2.56))
} else {
	(-8.28-(tcb->m_segmentSize))
}
if (false) {
	(2.09*(tcb->m_segmentSize)*(7.89)*(14.77))
} else {
	(tcb->m_segmentSize*(-12.56)*(tcb->m_segmentSize)*(-3.75))
}
if (true) {
	tcb->m_segmentSize = (int) (0.13)/(-1.67);

} else {
	tcb->m_segmentSize = (int) (-13.07-(0.38));

}
