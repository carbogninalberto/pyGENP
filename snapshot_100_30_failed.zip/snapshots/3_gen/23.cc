if (true) {
	(-5.98*(-19.57)*(5.96))
} else {
	(tcb->m_segmentSize+(0.9)+(tcb->m_segmentSize)+(-12.3))
}
tcb->m_segmentSize = (int) (-6.37*(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (7.65)/(0.67);
