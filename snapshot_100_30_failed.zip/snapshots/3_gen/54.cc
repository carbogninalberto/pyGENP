if (false) {
	(0.45+(-13.95)+(tcb->m_segmentSize)+(-3.42))
} else {
	(-12.5*(-1.73)*(tcb->m_segmentSize))
}
if (true) {
	(19.57+(-2.56))
} else {
	(-8.28-(tcb->m_segmentSize))
}
if (true) {
	tcb->m_segmentSize = (int) (1.67-(0.94)-(-19.49)-(0.25));

} else {
	tcb->m_segmentSize = (int) (2.24-(-0.95)-(17.86));

}
tcb->m_segmentSize = (int) (-4.43*(tcb->m_segmentSize)*(18.24)*(-11.53));
