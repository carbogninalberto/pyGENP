if (true) {
	(-1.81*(15.86))
} else {
	(-15.91+(-7.44)+(3.44)+(9.46))
}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-3.98)+(5.06));

} else {
	tcb->m_segmentSize = (int) (4.62*(-7.1));

}
tcb->m_segmentSize = (int) (-9.49)/(6.09);
tcb->m_segmentSize = (int) (7.65)/(0.67);
