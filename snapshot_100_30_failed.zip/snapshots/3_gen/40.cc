if (true) {
	tcb->m_segmentSize = (int) (6.17+(-0.76)+(13.28)+(-5.78));

} else {
	tcb->m_segmentSize = (int) (3.28)/(-14.95);

}
tcb->m_segmentSize = (int) (-6.37*(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (7.65)/(0.67);
