tcb->m_segmentSize = (int) (14.42-(-17.52)-(10.33));
if (true) {
	(tcb->m_segmentSize+(tcb->m_segmentSize))
} else {
	(14.36-(tcb->m_segmentSize))
}
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-1.89)+(19.8)+(-10.19));

} else {
	tcb->m_segmentSize = (int) (-19.57)/(-14.77);

}
tcb->m_segmentSize = (int) (15.92*(8.11)*(10.3));
