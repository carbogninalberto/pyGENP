if (true) {
	(0.05)/(18.5)
} else {
	(tcb->m_segmentSize-(15.48)-(12.88)-(-15.41))
}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (-15.87*(-10.22));

}
