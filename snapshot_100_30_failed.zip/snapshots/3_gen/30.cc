if (false) {
	(17.68)/(-11.45)
} else {
	(8.98+(19.76))
}
if (true) {
	tcb->m_segmentSize = (int) (12.42+(tcb->m_segmentSize)+(14.83)+(19.28));

} else {
	tcb->m_segmentSize = (int) (-19.35-(14.45)-(17.99)-(-7.29));

}
tcb->m_segmentSize = (int) (14.42-(-17.52)-(10.33));
tcb->m_segmentSize = (int) (19.07+(8.35)+(-18.77)+(10.82));
