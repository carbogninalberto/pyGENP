if (true) {
	(6.12+(8.62)+(2.1))
} else {
	(3.45)/(tcb->m_segmentSize)
}
tcb->m_segmentSize = (int) (-6.37*(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (7.65)/(0.67);
