tcb->m_segmentSize = (int) (14.42-(-17.52)-(10.33));
if (true) {
	tcb->m_segmentSize = (int) (12.42+(tcb->m_segmentSize)+(14.83)+(19.28));

} else {
	tcb->m_segmentSize = (int) (-19.35-(14.45)-(17.99)-(-7.29));

}
if (false) {
	tcb->m_segmentSize = (int) (-7.64-(2.68));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(3.15)+(-8.7));

}
if (true) {
	tcb->m_segmentSize = (int) (-8.02*(-14.24)*(19.62));

} else {
	tcb->m_segmentSize = (int) (-18.12)/(17.13);

}
