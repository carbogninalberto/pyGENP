if (false) {
	(13.52)/(tcb->m_segmentSize)
} else {
	(tcb->m_segmentSize+(-6.0)+(5.2)+(tcb->m_segmentSize))
}
if (true) {
	tcb->m_segmentSize = (int) (0.13)/(-1.67);

} else {
	tcb->m_segmentSize = (int) (-13.07-(0.38));

}
