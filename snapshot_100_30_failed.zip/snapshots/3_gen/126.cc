if (false) {
	(-3.37+(4.61)+(19.75))
} else {
	(16.79*(4.37))
}
tcb->m_segmentSize = (int) (10.37*(-19.64)*(8.42));
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-12.22);

} else {
	tcb->m_segmentSize = (int) (-17.32-(-7.4)-(14.24));

}
tcb->m_segmentSize = (int) (-6.47+(-19.11)+(-2.37)+(-13.31));
tcb->m_segmentSize = (int) (16.91)/(14.71);
tcb->m_segmentSize = (int) (-17.75+(-6.93)+(-8.24));
