if (true) {
	tcb->m_segmentSize = (int) (1.67-(0.94)-(-19.49)-(0.25));

} else {
	tcb->m_segmentSize = (int) (2.24-(-0.95)-(17.86));

}
tcb->m_segmentSize = (int) (14.42-(-17.52)-(10.33));
tcb->m_segmentSize = (int) (-9.49)/(6.09);
tcb->m_segmentSize = (int) (7.65)/(0.67);
