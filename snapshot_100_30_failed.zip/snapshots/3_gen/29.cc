if (false) {
	(-18.33-(4.81)-(-9.11))
} else {
	(12.59-(10.17))
}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-3.98)+(5.06));

} else {
	tcb->m_segmentSize = (int) (4.62*(-7.1));

}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (-15.87*(-10.22));

}
