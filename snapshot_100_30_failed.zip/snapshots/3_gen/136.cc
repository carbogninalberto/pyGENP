if (true) {
	(-10.68*(-12.88))
} else {
	(5.33*(17.41)*(1.17)*(-5.82))
}
tcb->m_segmentSize = (int) (-9.49)/(6.09);
tcb->m_segmentSize = (int) (14.42-(-17.52)-(10.33));
tcb->m_segmentSize = (int) (19.07+(8.35)+(-18.77)+(10.82));
