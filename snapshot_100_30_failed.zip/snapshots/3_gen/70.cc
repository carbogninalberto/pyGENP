if (true) {
	(tcb->m_segmentSize*(-13.77)*(8.43))
} else {
	(17.85-(tcb->m_segmentSize))
}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-3.98)+(5.06));

} else {
	tcb->m_segmentSize = (int) (4.62*(-7.1));

}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (-15.87*(-10.22));

}
