tcb->m_segmentSize = (int) (-17.11)/(11.53);
tcb->m_segmentSize = (int) (-9.49)/(6.09);
tcb->m_segmentSize = (int) (14.42-(-17.52)-(10.33));
tcb->m_segmentSize = (int) (19.07+(8.35)+(-18.77)+(10.82));
