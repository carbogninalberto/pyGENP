tcb->m_segmentSize = (int) (-5.21+(16.46)+(-13.12));
tcb->m_segmentSize = (int) (-9.49)/(6.09);
tcb->m_segmentSize = (int) (7.65)/(0.67);
