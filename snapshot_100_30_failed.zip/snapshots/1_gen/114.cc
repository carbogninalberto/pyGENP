tcb->m_segmentSize = (int) (tcb->m_segmentSize*(-3.36)*(tcb->m_segmentSize)*(10.72));
tcb->m_segmentSize = (int) (5.85-(tcb->m_segmentSize));
