if (false) {
	tcb->m_segmentSize = (int) (-2.39*(tcb->m_segmentSize)*(16.37));

} else {
	tcb->m_segmentSize = (int) (17.51-(10.01));

}
if (true) {
	tcb->m_segmentSize = (int) (3.38)/(-11.48);

} else {
	tcb->m_segmentSize = (int) (-18.96-(-8.5)-(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (6.81-(9.8)-(-19.95));
tcb->m_segmentSize = (int) (-11.06+(tcb->m_segmentSize)+(-3.68)+(-9.74));
