if (true) {
	tcb->m_segmentSize = (int) (-8.92)/(18.11);

} else {
	tcb->m_segmentSize = (int) (14.42*(13.49));

}
if (true) {
	tcb->m_segmentSize = (int) (-14.48)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (15.36+(-6.95)+(-10.45)+(16.18));

}
