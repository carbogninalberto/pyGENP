if (false) {
	tcb->m_segmentSize = (int) (-10.85*(-13.59)*(-9.11)*(-15.39));

} else {
	tcb->m_segmentSize = (int) (-4.58+(8.23)+(-4.65)+(14.5));

}
if (false) {
	tcb->m_segmentSize = (int) (-16.8)/(4.76);

} else {
	tcb->m_segmentSize = (int) (-11.99*(-17.89)*(tcb->m_segmentSize)*(-8.47));

}
