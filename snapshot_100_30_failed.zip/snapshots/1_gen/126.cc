if (false) {
	tcb->m_segmentSize = (int) (-8.94*(tcb->m_segmentSize)*(19.81)*(17.3));

} else {
	tcb->m_segmentSize = (int) (10.5+(tcb->m_segmentSize)+(3.86));

}
tcb->m_segmentSize = (int) (14.14-(15.17)-(-10.24));
