if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(16.48));

} else {
	tcb->m_segmentSize = (int) (9.41+(1.16)+(17.72));

}
