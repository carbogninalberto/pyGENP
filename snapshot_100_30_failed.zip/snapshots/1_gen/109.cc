tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(tcb->m_segmentSize));
if (false) {
	tcb->m_segmentSize = (int) (12.46+(9.2));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(tcb->m_segmentSize)+(-12.54)+(-13.73));

}
tcb->m_segmentSize = (int) (-13.72+(tcb->m_segmentSize));
if (false) {
	tcb->m_segmentSize = (int) (-3.11-(-15.96)-(-10.72));

} else {
	tcb->m_segmentSize = (int) (-6.14+(-13.28)+(-15.31));

}
