tcb->m_segmentSize = (int) (5.66-(10.81));
