tcb->m_segmentSize = (int) (-11.44)/(14.03);
tcb->m_segmentSize = (int) (-0.37)/(14.01);
tcb->m_segmentSize = (int) (-9.97*(-13.97));
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(7.44);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(-4.73)*(tcb->m_segmentSize)*(-3.33));

}
