if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(2.56)-(tcb->m_segmentSize)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (6.15*(-2.26)*(-3.84));

}
