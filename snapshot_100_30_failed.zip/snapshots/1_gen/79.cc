tcb->m_segmentSize = (int) (10.35+(-8.89)+(4.62));
