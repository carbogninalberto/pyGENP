tcb->m_segmentSize = (int) (-8.93-(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (0.41)/(-5.57);
