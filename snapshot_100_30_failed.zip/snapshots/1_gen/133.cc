if (false) {
	tcb->m_segmentSize = (int) (-0.96-(5.89));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(3.43);

}
if (false) {
	tcb->m_segmentSize = (int) (8.58)/(-16.39);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-1.83);

}
if (true) {
	tcb->m_segmentSize = (int) (7.09+(8.22)+(-7.87)+(-11.53));

} else {
	tcb->m_segmentSize = (int) (-15.69)/(-18.93);

}
