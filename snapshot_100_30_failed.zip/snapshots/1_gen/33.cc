tcb->m_segmentSize = (int) (-4.07-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(tcb->m_segmentSize));
