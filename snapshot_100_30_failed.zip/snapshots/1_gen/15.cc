tcb->m_segmentSize = (int) (7.18-(-5.61));
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(2.39));

} else {
	tcb->m_segmentSize = (int) (12.61-(-6.24)-(16.14)-(10.55));

}
