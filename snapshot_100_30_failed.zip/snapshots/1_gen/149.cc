if (true) {
	tcb->m_segmentSize = (int) (11.89)/(-11.55);

} else {
	tcb->m_segmentSize = (int) (-0.01*(tcb->m_segmentSize)*(-10.5));

}
tcb->m_segmentSize = (int) (17.23+(-0.85)+(-16.11));
