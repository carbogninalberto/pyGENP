tcb->m_segmentSize = (int) (13.86+(tcb->m_segmentSize));
