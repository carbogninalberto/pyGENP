if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-17.52)-(-12.51)-(14.04));

} else {
	tcb->m_segmentSize = (int) (-13.67-(-9.39)-(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(9.68);
tcb->m_segmentSize = (int) (7.14+(tcb->m_segmentSize)+(2.92)+(-19.05));
if (false) {
	tcb->m_segmentSize = (int) (-3.45-(-18.77)-(12.55)-(-9.29));

} else {
	tcb->m_segmentSize = (int) (9.25)/(-16.23);

}
