tcb->m_segmentSize = (int) (6.84*(17.75));
if (true) {
	tcb->m_segmentSize = (int) (16.97)/(-3.41);

} else {
	tcb->m_segmentSize = (int) (12.34-(tcb->m_segmentSize));

}
if (false) {
	tcb->m_segmentSize = (int) (8.23-(-14.87)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-2.47-(14.84));

}
