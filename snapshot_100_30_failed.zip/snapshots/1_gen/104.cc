tcb->m_segmentSize = (int) (tcb->m_segmentSize*(15.85)*(tcb->m_segmentSize));
if (false) {
	tcb->m_segmentSize = (int) (-2.36*(-2.7)*(-7.88));

} else {
	tcb->m_segmentSize = (int) (18.77+(-1.34));

}
