tcb->m_segmentSize = (int) (8.21*(6.49)*(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (17.11*(-4.48)*(6.99));
tcb->m_segmentSize = (int) (-10.48+(19.44)+(1.17)+(0.52));
