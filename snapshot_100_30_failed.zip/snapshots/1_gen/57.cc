if (true) {
	tcb->m_segmentSize = (int) (3.61+(-1.07)+(17.42)+(-3.74));

} else {
	tcb->m_segmentSize = (int) (8.95-(5.44)-(-12.57));

}
if (false) {
	tcb->m_segmentSize = (int) (14.84)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (0.35-(tcb->m_segmentSize));

}
