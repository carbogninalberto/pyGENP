if (false) {
	tcb->m_segmentSize = (int) (15.01+(-9.04)+(18.93));

} else {
	tcb->m_segmentSize = (int) (17.42*(2.69)*(4.21));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(5.99));
tcb->m_segmentSize = (int) (16.76*(-5.78)*(-7.2));
tcb->m_segmentSize = (int) (-5.69+(-17.84)+(6.26)+(12.42));
