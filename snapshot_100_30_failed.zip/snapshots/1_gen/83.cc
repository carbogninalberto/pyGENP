if (true) {
	tcb->m_segmentSize = (int) (17.51-(-7.1));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(12.4);

}
if (false) {
	tcb->m_segmentSize = (int) (3.5-(-3.56)-(19.12)-(16.68));

} else {
	tcb->m_segmentSize = (int) (-8.25+(15.49)+(9.94)+(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (-9.4*(15.91)*(-16.8));
