tcb->m_segmentSize = (int) (-9.5*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(8.98));
