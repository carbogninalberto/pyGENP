tcb->m_segmentSize = (int) (14.07*(-3.55)*(tcb->m_segmentSize)*(1.39));
