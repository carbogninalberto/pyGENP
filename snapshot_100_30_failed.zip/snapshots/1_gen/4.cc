if (false) {
	tcb->m_segmentSize = (int) (-12.53+(-15.6)+(8.04));

} else {
	tcb->m_segmentSize = (int) (-8.05+(tcb->m_segmentSize));

}
if (false) {
	tcb->m_segmentSize = (int) (-8.29-(tcb->m_segmentSize)-(-16.74)-(-8.72));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(18.82);

}
tcb->m_segmentSize = (int) (7.43*(2.72));
tcb->m_segmentSize = (int) (16.44)/(tcb->m_segmentSize);
