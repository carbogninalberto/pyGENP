if (false) {
	tcb->m_segmentSize = (int) (10.4-(-2.73)-(17.37)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (6.93)/(tcb->m_segmentSize);

}
if (false) {
	tcb->m_segmentSize = (int) (5.78)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (16.82-(tcb->m_segmentSize)-(19.78));

}
if (true) {
	tcb->m_segmentSize = (int) (-1.65*(-3.0)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-1.55+(15.37));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(tcb->m_segmentSize));
