tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(11.04);
tcb->m_segmentSize = (int) (-0.76-(6.76)-(-19.21)-(9.69));
tcb->m_segmentSize = (int) (-13.84*(tcb->m_segmentSize)*(-15.69)*(-10.47));
