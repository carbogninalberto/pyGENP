tcb->m_segmentSize = (int) (-13.57-(-12.81)-(-13.95)-(-6.62));
tcb->m_segmentSize = (int) (-18.59)/(0.37);
tcb->m_segmentSize = (int) (-15.17+(12.15));
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-8.88));
