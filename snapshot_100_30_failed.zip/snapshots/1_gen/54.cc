if (true) {
	tcb->m_segmentSize = (int) (9.74-(2.64)-(-7.44)-(18.41));

} else {
	tcb->m_segmentSize = (int) (8.23)/(-18.84);

}
if (true) {
	tcb->m_segmentSize = (int) (2.28+(10.56)+(11.82));

} else {
	tcb->m_segmentSize = (int) (-9.51+(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (-3.78-(-4.0)-(2.62)-(0.15));
if (false) {
	tcb->m_segmentSize = (int) (5.96+(6.98));

} else {
	tcb->m_segmentSize = (int) (-10.5+(8.92)+(-12.89)+(-10.72));

}
