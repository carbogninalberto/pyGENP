tcb->m_segmentSize = (int) (5.3)/(-2.9);
tcb->m_segmentSize = (int) (11.55)/(-2.47);
if (false) {
	tcb->m_segmentSize = (int) (7.05*(-0.45)*(10.09)*(17.37));

} else {
	tcb->m_segmentSize = (int) (-9.52)/(1.28);

}
tcb->m_segmentSize = (int) (-5.71-(tcb->m_segmentSize)-(-13.0));
