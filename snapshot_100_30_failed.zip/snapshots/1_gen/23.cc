tcb->m_segmentSize = (int) (20.0-(8.23)-(12.43));
if (false) {
	tcb->m_segmentSize = (int) (17.34+(10.69)+(-16.92));

} else {
	tcb->m_segmentSize = (int) (18.44*(-11.65)*(10.2)*(13.77));

}
if (false) {
	tcb->m_segmentSize = (int) (9.8*(-9.07)*(16.01)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (4.94+(-1.78)+(18.06)+(-19.46));

}
