if (false) {
	tcb->m_segmentSize = (int) (-0.62+(-1.4)+(tcb->m_segmentSize)+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-1.22-(2.58)-(10.26)-(13.38));

}
tcb->m_segmentSize = (int) (5.95*(-10.56));
