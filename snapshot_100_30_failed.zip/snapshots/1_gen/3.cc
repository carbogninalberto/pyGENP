if (true) {
	tcb->m_segmentSize = (int) (-18.63)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (-15.81*(-0.9)*(tcb->m_segmentSize));

}
