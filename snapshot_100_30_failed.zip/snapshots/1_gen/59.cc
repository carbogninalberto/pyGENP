tcb->m_segmentSize = (int) (17.28)/(-16.48);
if (true) {
	tcb->m_segmentSize = (int) (-10.04+(-8.43));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-4.81));

}
if (true) {
	tcb->m_segmentSize = (int) (6.04*(13.88)*(-13.77)*(18.69));

} else {
	tcb->m_segmentSize = (int) (11.24)/(-12.15);

}
