tcb->m_segmentSize = (int) (-7.17)/(-14.17);
tcb->m_segmentSize = (int) (12.81-(tcb->m_segmentSize)-(10.26)-(-18.77));
if (true) {
	tcb->m_segmentSize = (int) (-15.45+(-7.63)+(-2.52));

} else {
	tcb->m_segmentSize = (int) (17.9-(-9.9)-(-18.22));

}
if (true) {
	tcb->m_segmentSize = (int) (-9.31-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(11.22);

}
