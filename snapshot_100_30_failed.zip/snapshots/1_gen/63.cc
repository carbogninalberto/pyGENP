if (false) {
	tcb->m_segmentSize = (int) (13.82)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (-11.83*(-0.4));

}
