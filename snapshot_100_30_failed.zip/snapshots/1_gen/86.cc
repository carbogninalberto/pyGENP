tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-5.69)+(13.22)+(-15.69));
tcb->m_segmentSize = (int) (-7.38+(-17.4));
tcb->m_segmentSize = (int) (16.95-(8.26)-(-12.18)-(-8.3));
