if (true) {
	tcb->m_segmentSize = (int) (-16.7-(15.32));

} else {
	tcb->m_segmentSize = (int) (-10.68-(-1.85));

}
