if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-8.25)-(6.15)-(-18.19));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(tcb->m_segmentSize));

}
if (false) {
	tcb->m_segmentSize = (int) (-17.53)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (19.11*(16.7)*(2.65)*(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (-12.61*(tcb->m_segmentSize)*(0.41)*(-18.43));
