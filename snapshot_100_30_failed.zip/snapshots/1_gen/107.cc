if (true) {
	tcb->m_segmentSize = (int) (-0.5)/(3.39);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(16.05));

}
if (false) {
	tcb->m_segmentSize = (int) (-15.83+(-12.33));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-7.34)+(0.16)+(-16.53));

}
if (false) {
	tcb->m_segmentSize = (int) (19.9)/(19.86);

} else {
	tcb->m_segmentSize = (int) (9.53*(-5.64));

}
