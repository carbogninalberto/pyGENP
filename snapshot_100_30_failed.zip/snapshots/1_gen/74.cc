if (true) {
	tcb->m_segmentSize = (int) (-18.76-(-18.73)-(-17.71)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-15.15)/(-17.9);

}
