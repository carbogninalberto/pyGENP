tcb->m_segmentSize = (int) (-3.25+(-8.36)+(tcb->m_segmentSize));
if (false) {
	tcb->m_segmentSize = (int) (7.76-(19.11)-(tcb->m_segmentSize)-(3.84));

} else {
	tcb->m_segmentSize = (int) (-0.89+(tcb->m_segmentSize)+(-1.62));

}
tcb->m_segmentSize = (int) (-17.49-(3.1)-(-13.05));
tcb->m_segmentSize = (int) (13.22+(tcb->m_segmentSize));
