tcb->m_segmentSize = (int) (-18.45)/(7.16);
if (true) {
	tcb->m_segmentSize = (int) (9.66)/(5.97);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(-1.21)*(-18.02)*(-8.89));

}
tcb->m_segmentSize = (int) (-3.93*(10.37)*(tcb->m_segmentSize)*(-16.26));
if (true) {
	tcb->m_segmentSize = (int) (5.83-(8.44)-(4.5)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (12.66-(9.96)-(-14.24)-(-8.4));

}
