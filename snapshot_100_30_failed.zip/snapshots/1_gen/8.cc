if (true) {
	tcb->m_segmentSize = (int) (-3.94)/(-15.23);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-6.59)+(1.35));

}
if (true) {
	tcb->m_segmentSize = (int) (-15.93-(-18.88)-(-1.71));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(12.26)*(tcb->m_segmentSize)*(tcb->m_segmentSize));

}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-1.97)-(tcb->m_segmentSize)-(-11.11));

} else {
	tcb->m_segmentSize = (int) (-2.07*(8.76)*(-19.53));

}
tcb->m_segmentSize = (int) (-15.43)/(9.92);
