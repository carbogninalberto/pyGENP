tcb->m_segmentSize = (int) (-5.34-(16.96)-(17.72)-(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (-13.95-(-2.78)-(tcb->m_segmentSize)-(-2.75));
if (false) {
	tcb->m_segmentSize = (int) (6.38+(4.81)+(13.82)+(2.48));

} else {
	tcb->m_segmentSize = (int) (-3.92+(-7.49)+(-2.34));

}
