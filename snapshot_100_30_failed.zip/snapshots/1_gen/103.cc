if (false) {
	tcb->m_segmentSize = (int) (-16.64-(14.18)-(16.53)-(6.28));

} else {
	tcb->m_segmentSize = (int) (-0.93)/(tcb->m_segmentSize);

}
tcb->m_segmentSize = (int) (-14.58+(6.43)+(tcb->m_segmentSize));
if (true) {
	tcb->m_segmentSize = (int) (-14.73)/(1.81);

} else {
	tcb->m_segmentSize = (int) (5.64-(8.67));

}
tcb->m_segmentSize = (int) (-10.15)/(-10.36);
