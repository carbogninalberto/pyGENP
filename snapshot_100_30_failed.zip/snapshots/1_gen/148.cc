if (false) {
	tcb->m_segmentSize = (int) (5.01*(-19.27)*(-3.38));

} else {
	tcb->m_segmentSize = (int) (-13.75+(tcb->m_segmentSize));

}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-8.04);

} else {
	tcb->m_segmentSize = (int) (-3.64)/(tcb->m_segmentSize);

}
tcb->m_segmentSize = (int) (8.0-(6.95)-(-4.5));
tcb->m_segmentSize = (int) (2.54)/(18.55);
