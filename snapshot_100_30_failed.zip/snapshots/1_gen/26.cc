tcb->m_segmentSize = (int) (-16.0)/(-2.81);
tcb->m_segmentSize = (int) (12.39+(16.3)+(-3.0));
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(4.77)-(10.7));
