tcb->m_segmentSize = (int) (11.72+(0.77));
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(14.49));

} else {
	tcb->m_segmentSize = (int) (-3.31+(4.78)+(-12.97));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(15.59)+(3.49)+(11.31));
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(tcb->m_segmentSize)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (19.95-(-8.81));

}
