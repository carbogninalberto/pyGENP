if (false) {
	tcb->m_segmentSize = (int) (-18.92+(10.99)+(1.51));

} else {
	tcb->m_segmentSize = (int) (9.51+(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (-6.93+(0.69)+(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(tcb->m_segmentSize);
