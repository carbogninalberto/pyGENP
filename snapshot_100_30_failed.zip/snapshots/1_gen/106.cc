if (false) {
	tcb->m_segmentSize = (int) (-7.1*(-3.89)*(-13.6));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(19.07)-(2.04));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(10.44));
if (false) {
	tcb->m_segmentSize = (int) (-13.35+(-7.76));

} else {
	tcb->m_segmentSize = (int) (0.32)/(-6.84);

}
if (false) {
	tcb->m_segmentSize = (int) (0.13+(-9.42)+(5.55));

} else {
	tcb->m_segmentSize = (int) (-13.61+(0.47)+(-6.21));

}
