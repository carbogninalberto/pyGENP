tcb->m_segmentSize = (int) (14.46+(-3.57));
