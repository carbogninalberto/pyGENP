tcb->m_segmentSize = (int) (-3.82*(8.17)*(17.9));
if (false) {
	tcb->m_segmentSize = (int) (-18.83-(-4.55)-(18.62));

} else {
	tcb->m_segmentSize = (int) (-3.7)/(7.76);

}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-2.02)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-15.62+(16.21)+(-6.27)+(19.31));

}
