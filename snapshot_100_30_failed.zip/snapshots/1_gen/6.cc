if (true) {
	tcb->m_segmentSize = (int) (-12.91+(4.8)+(-1.69));

} else {
	tcb->m_segmentSize = (int) (-16.13+(-1.71)+(12.24)+(-1.34));

}
if (true) {
	tcb->m_segmentSize = (int) (6.82-(-18.34));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(tcb->m_segmentSize);

}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(14.62)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(1.2);

}
