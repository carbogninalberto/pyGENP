tcb->m_segmentSize = (int) (-13.5)/(-2.69);
