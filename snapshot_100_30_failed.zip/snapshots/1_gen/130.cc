if (false) {
	tcb->m_segmentSize = (int) (-12.19)/(-17.44);

} else {
	tcb->m_segmentSize = (int) (18.98)/(17.97);

}
