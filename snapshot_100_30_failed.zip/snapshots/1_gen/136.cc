tcb->m_segmentSize = (int) (-15.09+(tcb->m_segmentSize)+(-1.16));
if (false) {
	tcb->m_segmentSize = (int) (8.86+(18.21)+(tcb->m_segmentSize)+(8.09));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(3.66));

}
tcb->m_segmentSize = (int) (-8.21*(-6.63));
