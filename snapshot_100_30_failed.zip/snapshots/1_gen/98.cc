if (false) {
	tcb->m_segmentSize = (int) (8.86*(-13.73)*(8.35));

} else {
	tcb->m_segmentSize = (int) (-13.62+(-15.27));

}
