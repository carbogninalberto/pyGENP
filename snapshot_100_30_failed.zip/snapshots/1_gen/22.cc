if (false) {
	tcb->m_segmentSize = (int) (-3.66+(10.17)+(16.69));

} else {
	tcb->m_segmentSize = (int) (-13.34)/(19.01);

}
