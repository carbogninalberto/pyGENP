if (false) {
	tcb->m_segmentSize = (int) (-19.91*(-9.61)*(9.11)*(-1.53));

} else {
	tcb->m_segmentSize = (int) (-16.95-(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (15.12-(tcb->m_segmentSize)-(12.65));
