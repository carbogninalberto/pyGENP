if (true) {
	tcb->m_segmentSize = (int) (4.53)/(8.52);

} else {
	tcb->m_segmentSize = (int) (0.87+(8.56)+(10.64));

}
