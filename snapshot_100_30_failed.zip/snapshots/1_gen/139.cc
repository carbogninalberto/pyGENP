tcb->m_segmentSize = (int) (-2.62-(tcb->m_segmentSize)-(19.2)-(8.86));
tcb->m_segmentSize = (int) (3.42-(tcb->m_segmentSize)-(tcb->m_segmentSize)-(-16.53));
if (false) {
	tcb->m_segmentSize = (int) (-18.44)/(-18.03);

} else {
	tcb->m_segmentSize = (int) (6.83*(18.49)*(-8.39));

}
