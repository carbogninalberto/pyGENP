if (true) {
	tcb->m_segmentSize = (int) (5.09*(-9.9));

} else {
	tcb->m_segmentSize = (int) (3.97-(tcb->m_segmentSize));

}
if (true) {
	tcb->m_segmentSize = (int) (-7.05*(19.72)*(4.23)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-8.0-(tcb->m_segmentSize)-(-11.14));

}
if (true) {
	tcb->m_segmentSize = (int) (-1.32+(12.81));

} else {
	tcb->m_segmentSize = (int) (-1.12-(5.39)-(2.78));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-1.23);
