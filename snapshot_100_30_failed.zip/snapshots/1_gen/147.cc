tcb->m_segmentSize = (int) (-11.28-(10.43));
if (true) {
	tcb->m_segmentSize = (int) (-14.13-(-18.97)-(tcb->m_segmentSize)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-13.51);

}
