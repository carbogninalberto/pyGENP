tcb->m_segmentSize = (int) (tcb->m_segmentSize+(tcb->m_segmentSize)+(-6.65));
