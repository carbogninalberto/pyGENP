tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_segmentSize));
if (false) {
	tcb->m_segmentSize = (int) (10.86-(2.78));

} else {
	tcb->m_segmentSize = (int) (6.16-(14.72)-(-9.78)-(-5.48));

}
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(2.92)*(5.43));

} else {
	tcb->m_segmentSize = (int) (-12.46+(15.51)+(-14.31));

}
