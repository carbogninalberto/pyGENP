if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-7.79);

} else {
	tcb->m_segmentSize = (int) (4.86*(2.45)*(-8.2)*(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (9.41-(-7.24));
tcb->m_segmentSize = (int) (18.49)/(tcb->m_segmentSize);
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-2.79);

} else {
	tcb->m_segmentSize = (int) (-17.91*(-5.92)*(tcb->m_segmentSize));

}
