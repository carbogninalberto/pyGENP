if (false) {
	tcb->m_segmentSize = (int) (-4.28*(13.09)*(2.99)*(-14.42));

} else {
	tcb->m_segmentSize = (int) (-3.47+(15.52)+(19.15));

}
if (false) {
	tcb->m_segmentSize = (int) (-9.13-(tcb->m_segmentSize)-(-8.76)-(0.14));

} else {
	tcb->m_segmentSize = (int) (-0.9)/(12.63);

}
tcb->m_segmentSize = (int) (9.53*(tcb->m_segmentSize));
