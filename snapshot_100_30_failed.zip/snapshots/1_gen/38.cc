tcb->m_segmentSize = (int) (19.34-(tcb->m_segmentSize));
