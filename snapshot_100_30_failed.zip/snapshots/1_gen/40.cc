tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-2.95));
