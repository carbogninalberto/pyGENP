tcb->m_segmentSize = (int) (-17.35-(6.91)-(-3.15));
if (true) {
	tcb->m_segmentSize = (int) (1.42+(1.71));

} else {
	tcb->m_segmentSize = (int) (-2.75)/(tcb->m_segmentSize);

}
