tcb->m_segmentSize = (int) (tcb->m_segmentSize*(-4.69)*(-15.67));
if (true) {
	tcb->m_segmentSize = (int) (18.26+(13.38)+(18.63));

} else {
	tcb->m_segmentSize = (int) (-7.1+(-5.0)+(tcb->m_segmentSize));

}
