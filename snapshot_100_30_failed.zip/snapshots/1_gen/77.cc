if (false) {
	tcb->m_segmentSize = (int) (4.35)/(-7.97);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(11.72)+(-0.29));

}
tcb->m_segmentSize = (int) (8.61)/(19.62);
tcb->m_segmentSize = (int) (-10.71*(tcb->m_segmentSize));
if (true) {
	tcb->m_segmentSize = (int) (-1.48*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-12.07-(10.89)-(-1.29)-(-1.46));

}
