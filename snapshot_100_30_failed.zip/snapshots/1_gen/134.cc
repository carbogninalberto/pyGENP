tcb->m_segmentSize = (int) (5.05+(-13.6)+(-8.26)+(19.43));
tcb->m_segmentSize = (int) (19.77*(19.55)*(tcb->m_segmentSize)*(-11.12));
