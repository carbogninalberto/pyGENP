if (true) {
	tcb->m_segmentSize = (int) (-8.69)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (9.01-(-13.2)-(9.76)-(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(18.05);
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-11.3)-(9.44));
