tcb->m_segmentSize = (int) (2.06)/(tcb->m_segmentSize);
tcb->m_segmentSize = (int) (8.19*(-10.95)*(-4.1));
tcb->m_segmentSize = (int) (-11.69+(7.0)+(-19.63));
if (true) {
	tcb->m_segmentSize = (int) (8.11)/(-11.63);

} else {
	tcb->m_segmentSize = (int) (-8.56+(10.71)+(19.24)+(2.82));

}
