if (false) {
	tcb->m_segmentSize = (int) (1.41+(tcb->m_segmentSize)+(19.82));

} else {
	tcb->m_segmentSize = (int) (-6.56*(-4.71)*(-19.16));

}
if (true) {
	tcb->m_segmentSize = (int) (4.15*(-2.38));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(-13.86));

}
