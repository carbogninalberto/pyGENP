tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-11.76));
if (false) {
	tcb->m_segmentSize = (int) (19.09*(1.59));

} else {
	tcb->m_segmentSize = (int) (3.62*(19.24));

}
tcb->m_segmentSize = (int) (8.2+(-1.32)+(7.74)+(-13.38));
