if (false) {
	tcb->m_segmentSize = (int) (13.01+(2.55)+(-15.72)+(-0.06));

} else {
	tcb->m_segmentSize = (int) (17.73*(11.77));

}
tcb->m_segmentSize = (int) (-15.3+(tcb->m_segmentSize)+(tcb->m_segmentSize)+(-6.85));
if (false) {
	tcb->m_segmentSize = (int) (-4.75-(2.68)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (3.27*(17.83)*(-18.49));

}
