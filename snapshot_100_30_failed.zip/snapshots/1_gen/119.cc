if (true) {
	tcb->m_segmentSize = (int) (-9.35+(-8.4));

} else {
	tcb->m_segmentSize = (int) (-4.77)/(-12.62);

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(tcb->m_segmentSize));
