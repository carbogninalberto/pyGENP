tcb->m_segmentSize = (int) (tcb->m_segmentSize-(tcb->m_segmentSize)-(14.47)-(-4.2));
tcb->m_segmentSize = (int) (-0.37-(12.92));
