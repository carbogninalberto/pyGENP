if (true) {
	tcb->m_segmentSize = (int) (10.44)/(-16.34);

} else {
	tcb->m_segmentSize = (int) (10.94-(tcb->m_segmentSize)-(0.15));

}
if (true) {
	tcb->m_segmentSize = (int) (18.46-(5.47)-(16.24));

} else {
	tcb->m_segmentSize = (int) (11.68*(19.81));

}
tcb->m_segmentSize = (int) (17.14-(13.9)-(tcb->m_segmentSize));
if (true) {
	tcb->m_segmentSize = (int) (13.18*(-8.86));

} else {
	tcb->m_segmentSize = (int) (-16.21-(tcb->m_segmentSize)-(tcb->m_segmentSize));

}
