if (true) {
	tcb->m_segmentSize = (int) (-13.32*(9.12));

} else {
	tcb->m_segmentSize = (int) (-17.77)/(17.95);

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(13.95));
tcb->m_segmentSize = (int) (-17.33-(-5.08)-(11.11));
tcb->m_segmentSize = (int) (14.84-(-2.31));
