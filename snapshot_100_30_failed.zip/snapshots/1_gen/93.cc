tcb->m_segmentSize = (int) (10.65)/(tcb->m_segmentSize);
