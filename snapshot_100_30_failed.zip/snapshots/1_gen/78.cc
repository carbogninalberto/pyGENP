tcb->m_segmentSize = (int) (12.56+(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (4.71-(-8.54)-(14.36));
