tcb->m_segmentSize = (int) (-2.58+(tcb->m_segmentSize)+(-16.78));
