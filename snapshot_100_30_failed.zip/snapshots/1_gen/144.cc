tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-12.77)+(5.79));
tcb->m_segmentSize = (int) (-9.63*(-3.27));
