if (true) {
	tcb->m_segmentSize = (int) (7.41*(-14.02));

} else {
	tcb->m_segmentSize = (int) (-15.42)/(-4.05);

}
if (false) {
	tcb->m_segmentSize = (int) (-4.99)/(-10.33);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-13.98));

}
if (true) {
	tcb->m_segmentSize = (int) (-4.11-(18.11));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(9.53);

}
if (false) {
	tcb->m_segmentSize = (int) (-1.75*(17.04)*(tcb->m_segmentSize)*(-6.24));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(4.87);

}
