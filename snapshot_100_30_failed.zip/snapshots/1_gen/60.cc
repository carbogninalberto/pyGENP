tcb->m_segmentSize = (int) (tcb->m_segmentSize+(7.18)+(13.81));
