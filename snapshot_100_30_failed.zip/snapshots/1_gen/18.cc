tcb->m_segmentSize = (int) (tcb->m_segmentSize*(-4.64));
