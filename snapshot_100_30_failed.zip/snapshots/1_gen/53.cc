if (false) {
	tcb->m_segmentSize = (int) (-12.01+(12.1)+(-6.09)+(1.16));

} else {
	tcb->m_segmentSize = (int) (3.84-(-13.07)-(-4.64)-(3.03));

}
tcb->m_segmentSize = (int) (-5.38-(-18.21));
