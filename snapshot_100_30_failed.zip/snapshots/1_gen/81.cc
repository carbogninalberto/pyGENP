tcb->m_segmentSize = (int) (11.17*(-8.35));
if (false) {
	tcb->m_segmentSize = (int) (7.73-(1.53));

} else {
	tcb->m_segmentSize = (int) (6.97*(-10.81));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(tcb->m_segmentSize)+(18.55)+(-1.28));
tcb->m_segmentSize = (int) (-18.62-(-11.27)-(2.58));
