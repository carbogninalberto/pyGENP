if (true) {
	tcb->m_segmentSize = (int) (-10.67-(-4.97)-(-9.95)-(-16.83));

} else {
	tcb->m_segmentSize = (int) (3.32+(-12.03)+(-5.17)+(4.87));

}
