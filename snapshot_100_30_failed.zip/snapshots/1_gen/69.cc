if (false) {
	tcb->m_segmentSize = (int) (6.33*(tcb->m_segmentSize)*(-12.67)*(-6.35));

} else {
	tcb->m_segmentSize = (int) (14.51-(12.55));

}
tcb->m_segmentSize = (int) (2.52-(tcb->m_segmentSize)-(-0.2));
tcb->m_segmentSize = (int) (-15.68+(11.35));
