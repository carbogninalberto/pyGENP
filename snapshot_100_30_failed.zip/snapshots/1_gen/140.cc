tcb->m_segmentSize = (int) (-14.4+(18.14));
