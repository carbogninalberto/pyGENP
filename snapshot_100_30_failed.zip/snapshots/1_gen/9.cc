if (false) {
	tcb->m_segmentSize = (int) (9.61-(-16.91));

} else {
	tcb->m_segmentSize = (int) (-10.27)/(6.46);

}
if (false) {
	tcb->m_segmentSize = (int) (-6.36+(9.57)+(tcb->m_segmentSize)+(0.38));

} else {
	tcb->m_segmentSize = (int) (-7.41*(tcb->m_segmentSize)*(tcb->m_segmentSize));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(19.68));
if (false) {
	tcb->m_segmentSize = (int) (-3.78*(-6.28)*(16.28)*(-14.29));

} else {
	tcb->m_segmentSize = (int) (-9.17)/(-10.48);

}
