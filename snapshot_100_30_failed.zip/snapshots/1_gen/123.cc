if (false) {
	tcb->m_segmentSize = (int) (-13.96*(5.06)*(-14.09)*(15.76));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(16.72);

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-18.48));
tcb->m_segmentSize = (int) (-7.02-(10.95)-(-1.16));
