tcb->m_segmentSize = (int) (3.65+(8.63)+(-9.7)+(tcb->m_segmentSize));
if (true) {
	tcb->m_segmentSize = (int) (-10.06+(-0.17)+(-18.34)+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(6.83));

}
