if (false) {
	tcb->m_segmentSize = (int) (-18.97)/(14.6);

} else {
	tcb->m_segmentSize = (int) (-12.03-(tcb->m_segmentSize)-(-4.78)-(tcb->m_segmentSize));

}
