tcb->m_segmentSize = (int) (tcb->m_segmentSize-(tcb->m_segmentSize)-(6.19)-(-16.97));
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(10.89));
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-7.03)+(-0.37));
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-7.12)+(16.32)+(2.49));
