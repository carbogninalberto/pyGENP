tcb->m_segmentSize = (int) (-6.44-(-9.55)-(9.38)-(-17.13));
