tcb->m_segmentSize = (int) (1.89-(tcb->m_segmentSize)-(0.92)-(-16.57));
if (false) {
	tcb->m_segmentSize = (int) (-12.44+(-7.92)+(3.96)+(18.09));

} else {
	tcb->m_segmentSize = (int) (7.06*(8.87));

}
if (true) {
	tcb->m_segmentSize = (int) (-3.94*(-5.0)*(-0.48));

} else {
	tcb->m_segmentSize = (int) (-4.43+(0.43));

}
