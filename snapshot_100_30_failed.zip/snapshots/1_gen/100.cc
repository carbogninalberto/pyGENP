if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(8.92));

} else {
	tcb->m_segmentSize = (int) (5.99+(-17.92)+(tcb->m_segmentSize)+(0.78));

}
