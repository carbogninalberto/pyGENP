if (false) {
	tcb->m_segmentSize = (int) (-1.1)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (-5.49+(12.18));

}
