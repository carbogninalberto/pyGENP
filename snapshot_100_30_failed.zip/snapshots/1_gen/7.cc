if (true) {
	tcb->m_segmentSize = (int) (-14.38)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (8.59*(-16.11)*(tcb->m_segmentSize)*(tcb->m_segmentSize));

}
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(14.52);

} else {
	tcb->m_segmentSize = (int) (-0.14-(-2.54)-(tcb->m_segmentSize)-(13.41));

}
