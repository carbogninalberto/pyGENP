if (true) {
	tcb->m_segmentSize = (int) (-2.08*(16.82));

} else {
	tcb->m_segmentSize = (int) (4.64+(16.14));

}
if (true) {
	tcb->m_segmentSize = (int) (13.94-(14.8));

} else {
	tcb->m_segmentSize = (int) (5.73+(1.43)+(7.56));

}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(2.81);

} else {
	tcb->m_segmentSize = (int) (-19.7)/(-0.29);

}
