if (true) {
	tcb->m_segmentSize = (int) (19.67*(17.78));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(17.9);

}
