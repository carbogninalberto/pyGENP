if (true) {
	tcb->m_segmentSize = (int) (19.51+(-3.66)+(4.67)+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-11.35)/(-0.45);

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(4.91)+(7.45));
