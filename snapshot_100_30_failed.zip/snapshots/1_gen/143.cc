tcb->m_segmentSize = (int) (11.44*(12.19)*(15.17));
if (true) {
	tcb->m_segmentSize = (int) (-17.22-(8.89)-(tcb->m_segmentSize)-(-6.61));

} else {
	tcb->m_segmentSize = (int) (4.73*(5.89));

}
if (false) {
	tcb->m_segmentSize = (int) (11.52*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-2.65+(-5.37)+(-18.77));

}
tcb->m_segmentSize = (int) (10.64)/(1.65);
