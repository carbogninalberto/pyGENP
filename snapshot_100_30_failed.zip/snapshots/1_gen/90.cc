tcb->m_segmentSize = (int) (-9.68)/(15.51);
if (true) {
	tcb->m_segmentSize = (int) (-17.62-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-5.28);

}
if (true) {
	tcb->m_segmentSize = (int) (12.5+(17.87));

} else {
	tcb->m_segmentSize = (int) (18.22+(-7.33)+(4.03)+(17.73));

}
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-12.42)+(-11.88));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(tcb->m_segmentSize)*(tcb->m_segmentSize)*(19.33));

}
