if (true) {
	tcb->m_segmentSize = (int) (-9.48-(-8.78)-(2.85));

} else {
	tcb->m_segmentSize = (int) (9.21+(-16.5));

}
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-3.68)-(tcb->m_segmentSize)-(-9.22));

} else {
	tcb->m_segmentSize = (int) (-7.08)/(0.96);

}
tcb->m_segmentSize = (int) (-12.36+(3.63)+(4.86));
