tcb->m_segmentSize = (int) (8.8+(tcb->m_segmentSize)+(-13.05)+(-3.33));
