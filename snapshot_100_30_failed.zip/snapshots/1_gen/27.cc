if (true) {
	tcb->m_segmentSize = (int) (15.35+(-9.89)+(-5.4)+(9.08));

} else {
	tcb->m_segmentSize = (int) (17.69-(13.68)-(19.89)-(-19.84));

}
if (false) {
	tcb->m_segmentSize = (int) (14.91*(-17.92));

} else {
	tcb->m_segmentSize = (int) (17.07*(tcb->m_segmentSize));

}
