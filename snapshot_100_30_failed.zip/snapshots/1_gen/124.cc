tcb->m_segmentSize = (int) (7.83*(tcb->m_segmentSize));
