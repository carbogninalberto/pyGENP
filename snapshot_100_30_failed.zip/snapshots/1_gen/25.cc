tcb->m_segmentSize = (int) (-19.66*(19.25));
if (true) {
	tcb->m_segmentSize = (int) (15.91-(-7.42)-(-19.6)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-15.32)/(-1.88);

}
