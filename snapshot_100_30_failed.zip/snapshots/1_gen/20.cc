tcb->m_segmentSize = (int) (2.06*(-11.47));
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-6.35));

} else {
	tcb->m_segmentSize = (int) (-3.7)/(-4.02);

}
