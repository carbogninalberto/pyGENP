if (true) {
	tcb->m_segmentSize = (int) (10.2-(-18.28)-(-19.14));

} else {
	tcb->m_segmentSize = (int) (-1.1-(13.94)-(11.82));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-18.23));
if (true) {
	tcb->m_segmentSize = (int) (-8.61-(1.89));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(13.04);

}
tcb->m_segmentSize = (int) (-1.28)/(-9.78);
