if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(11.32));

} else {
	tcb->m_segmentSize = (int) (11.3)/(-18.87);

}
tcb->m_segmentSize = (int) (-12.09*(9.41)*(-18.72));
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(2.29)-(18.29));

} else {
	tcb->m_segmentSize = (int) (-19.82+(4.81)+(15.54)+(-4.28));

}
tcb->m_segmentSize = (int) (-9.1*(-2.46)*(tcb->m_segmentSize)*(12.71));
