if (true) {
	tcb->m_segmentSize = (int) (9.26*(-14.98)*(8.11));

} else {
	tcb->m_segmentSize = (int) (-5.73*(-15.88)*(17.79));

}
tcb->m_segmentSize = (int) (-12.02+(-2.74)+(16.83)+(-1.48));
