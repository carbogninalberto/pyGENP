if (true) {
	tcb->m_segmentSize = (int) (-7.35)/(-11.53);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(12.69)-(9.02)-(19.44));

}
if (true) {
	tcb->m_segmentSize = (int) (-15.51)/(-18.84);

} else {
	tcb->m_segmentSize = (int) (17.93)/(-6.38);

}
if (true) {
	tcb->m_segmentSize = (int) (-12.26+(-3.91)+(-5.05)+(10.58));

} else {
	tcb->m_segmentSize = (int) (-11.71+(4.88));

}
