tcb->m_segmentSize = (int) (tcb->m_segmentSize-(tcb->m_segmentSize)-(1.53));
tcb->m_segmentSize = (int) (9.96+(11.34));
