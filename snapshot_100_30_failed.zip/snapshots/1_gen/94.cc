if (false) {
	tcb->m_segmentSize = (int) (7.55*(9.14)*(-14.13)*(3.86));

} else {
	tcb->m_segmentSize = (int) (8.14+(4.42)+(-11.46));

}
