if (true) {
	tcb->m_segmentSize = (int) (1.4)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (11.76*(-4.82)*(-3.38));

}
tcb->m_segmentSize = (int) (14.23+(13.78)+(3.35));
