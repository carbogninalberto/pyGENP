if (false) {
	tcb->m_segmentSize = (int) (-16.92+(-3.75)+(-7.84)+(17.23));

} else {
	tcb->m_segmentSize = (int) (-17.06*(tcb->m_segmentSize)*(-14.65));

}
