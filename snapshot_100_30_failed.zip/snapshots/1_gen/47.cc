if (true) {
	tcb->m_segmentSize = (int) (12.11+(0.23)+(12.73));

} else {
	tcb->m_segmentSize = (int) (-4.7+(tcb->m_segmentSize));

}
