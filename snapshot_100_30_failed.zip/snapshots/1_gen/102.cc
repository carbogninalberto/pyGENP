tcb->m_segmentSize = (int) (6.06*(tcb->m_segmentSize)*(-15.59)*(16.91));
