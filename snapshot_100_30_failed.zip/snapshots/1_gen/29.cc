if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.65*(12.25));

}
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(19.03)+(-6.6));
