tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-18.85)+(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (-19.87*(5.64)*(2.93));
