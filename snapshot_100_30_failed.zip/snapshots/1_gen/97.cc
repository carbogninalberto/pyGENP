if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(16.94)+(14.07));

} else {
	tcb->m_segmentSize = (int) (8.38+(-13.11));

}
if (true) {
	tcb->m_segmentSize = (int) (8.59+(-1.89)+(14.33)+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-14.56*(2.31));

}
if (true) {
	tcb->m_segmentSize = (int) (-10.04*(17.88)*(17.86)*(-11.17));

} else {
	tcb->m_segmentSize = (int) (14.3)/(12.82);

}
tcb->m_segmentSize = (int) (0.86*(tcb->m_segmentSize)*(tcb->m_segmentSize));
