if (false) {
	tcb->m_segmentSize = (int) (10.12-(-15.48));

} else {
	tcb->m_segmentSize = (int) (3.41+(-0.8)+(11.46));

}
if (true) {
	tcb->m_segmentSize = (int) (18.37)/(-7.26);

} else {
	tcb->m_segmentSize = (int) (-17.53+(3.84));

}
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-18.69);

} else {
	tcb->m_segmentSize = (int) (10.45)/(-2.66);

}
if (false) {
	tcb->m_segmentSize = (int) (5.4)/(-18.09);

} else {
	tcb->m_segmentSize = (int) (-7.78+(-8.34));

}
