if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(19.08)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-3.4)/(8.06);

}
if (true) {
	tcb->m_segmentSize = (int) (0.42*(-5.29)*(tcb->m_segmentSize)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-3.71+(-9.24)+(12.69));

}
tcb->m_segmentSize = (int) (-13.94-(-9.52)-(-1.65)-(9.45));
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (6.68+(18.0));

}
