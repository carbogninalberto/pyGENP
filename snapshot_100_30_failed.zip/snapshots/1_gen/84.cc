if (true) {
	tcb->m_segmentSize = (int) (-10.98-(tcb->m_segmentSize)-(6.11)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (1.62)/(13.49);

}
tcb->m_segmentSize = (int) (-11.27*(16.43)*(tcb->m_segmentSize)*(-12.38));
if (true) {
	tcb->m_segmentSize = (int) (0.25)/(-13.62);

} else {
	tcb->m_segmentSize = (int) (2.31)/(-2.67);

}
