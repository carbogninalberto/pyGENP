tcb->m_segmentSize = (int) (tcb->m_segmentSize-(9.38)-(5.99)-(-1.27));
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-6.32)+(16.38));
