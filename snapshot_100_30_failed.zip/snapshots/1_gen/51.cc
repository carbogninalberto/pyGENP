if (false) {
	tcb->m_segmentSize = (int) (-3.29*(-0.51)*(4.52));

} else {
	tcb->m_segmentSize = (int) (5.36*(5.15)*(tcb->m_segmentSize)*(-12.16));

}
if (true) {
	tcb->m_segmentSize = (int) (9.89+(2.24)+(-6.31));

} else {
	tcb->m_segmentSize = (int) (15.92+(tcb->m_segmentSize)+(8.71));

}
