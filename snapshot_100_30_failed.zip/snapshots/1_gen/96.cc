tcb->m_segmentSize = (int) (7.92+(-7.58)+(tcb->m_segmentSize)+(16.26));
if (true) {
	tcb->m_segmentSize = (int) (-14.22-(-16.46)-(1.45)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-19.6);

}
