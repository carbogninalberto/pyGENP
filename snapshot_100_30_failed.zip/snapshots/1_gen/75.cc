tcb->m_segmentSize = (int) (tcb->m_segmentSize-(14.87)-(tcb->m_segmentSize));
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(tcb->m_segmentSize)+(0.55)+(-9.84));

} else {
	tcb->m_segmentSize = (int) (-13.91)/(-1.43);

}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(-12.47)*(-15.58)*(-4.44));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(2.33));

}
if (true) {
	tcb->m_segmentSize = (int) (-13.15+(16.05)+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-10.96-(-16.19)-(-2.29));

}
