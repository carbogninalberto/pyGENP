tcb->m_segmentSize = (int) (tcb->m_segmentSize-(15.21));
