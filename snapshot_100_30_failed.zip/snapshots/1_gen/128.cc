if (false) {
	tcb->m_segmentSize = (int) (9.86-(tcb->m_segmentSize)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (11.45)/(4.25);

}
