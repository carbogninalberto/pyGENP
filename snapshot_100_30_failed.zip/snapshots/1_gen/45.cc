if (true) {
	tcb->m_segmentSize = (int) (-7.43+(10.7));

} else {
	tcb->m_segmentSize = (int) (-9.37*(12.63)*(19.07)*(5.89));

}
if (true) {
	tcb->m_segmentSize = (int) (16.9)/(-6.81);

} else {
	tcb->m_segmentSize = (int) (7.72+(tcb->m_segmentSize)+(6.57));

}
tcb->m_segmentSize = (int) (-0.59*(tcb->m_segmentSize));
