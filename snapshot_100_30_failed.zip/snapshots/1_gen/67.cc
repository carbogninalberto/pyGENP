if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-12.45)+(-7.66)+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(11.07)*(2.6)*(tcb->m_segmentSize));

}
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-1.85)-(-14.61));

} else {
	tcb->m_segmentSize = (int) (2.27-(tcb->m_segmentSize));

}
