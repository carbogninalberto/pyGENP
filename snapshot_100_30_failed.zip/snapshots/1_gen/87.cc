if (true) {
	tcb->m_segmentSize = (int) (-8.44*(tcb->m_segmentSize)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (14.1*(-19.56)*(-14.96));

}
tcb->m_segmentSize = (int) (9.86+(-16.64));
tcb->m_segmentSize = (int) (-11.18-(-1.06)-(8.27)-(18.95));
tcb->m_segmentSize = (int) (-4.59+(-9.23)+(0.8)+(7.84));
