tcb->m_segmentSize = (int) (10.37*(-19.64)*(8.42));
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-3.98)+(5.06));

} else {
	tcb->m_segmentSize = (int) (4.62*(-7.1));

}
tcb->m_segmentSize = (int) (11.75-(tcb->m_segmentSize)-(-15.0));
