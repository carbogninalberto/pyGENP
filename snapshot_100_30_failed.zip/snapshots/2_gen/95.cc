if (true) {
	tcb->m_segmentSize = (int) (12.42+(tcb->m_segmentSize)+(14.83)+(19.28));

} else {
	tcb->m_segmentSize = (int) (-19.35-(14.45)-(17.99)-(-7.29));

}
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (-15.87*(-10.22));

}
