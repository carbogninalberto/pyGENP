tcb->m_segmentSize = (int) (-9.49)/(6.09);
tcb->m_segmentSize = (int) (-10.07-(-12.58)-(5.39)-(18.43));
