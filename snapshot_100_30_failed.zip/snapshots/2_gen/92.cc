if (true) {
	(4.77*(tcb->m_segmentSize)*(10.08)*(-0.9))
} else {
	(15.32*(tcb->m_segmentSize)*(-2.61))
}
if (true) {
	tcb->m_segmentSize = (int) (12.42+(tcb->m_segmentSize)+(14.83)+(19.28));

} else {
	tcb->m_segmentSize = (int) (-19.35-(14.45)-(17.99)-(-7.29));

}
if (true) {
	tcb->m_segmentSize = (int) (-6.96*(-7.9)*(10.96)*(-7.22));

} else {
	tcb->m_segmentSize = (int) (-14.43-(-10.19)-(-6.97)-(-14.61));

}
