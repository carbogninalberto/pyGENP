if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-12.22);

} else {
	tcb->m_segmentSize = (int) (-17.32-(-7.4)-(14.24));

}
tcb->m_segmentSize = (int) (-10.07-(-12.58)-(5.39)-(18.43));
