if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-3.98)+(5.06));

} else {
	tcb->m_segmentSize = (int) (4.62*(-7.1));

}
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-12.22);

} else {
	tcb->m_segmentSize = (int) (-17.32-(-7.4)-(14.24));

}
tcb->m_segmentSize = (int) (-6.47+(-19.11)+(-2.37)+(-13.31));
tcb->m_segmentSize = (int) (16.91)/(14.71);
tcb->m_segmentSize = (int) (-17.75+(-6.93)+(-8.24));
