if (false) {
	(tcb->m_segmentSize-(15.2))
} else {
	(tcb->m_segmentSize+(-18.23))
}
tcb->m_segmentSize = (int) (-6.47+(-19.11)+(-2.37)+(-13.31));
tcb->m_segmentSize = (int) (16.91)/(14.71);
tcb->m_segmentSize = (int) (-17.75+(-6.93)+(-8.24));
