tcb->m_segmentSize = (int) (14.42-(-17.52)-(10.33));
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-3.98)+(5.06));

} else {
	tcb->m_segmentSize = (int) (4.62*(-7.1));

}
tcb->m_segmentSize = (int) (11.75-(tcb->m_segmentSize)-(-15.0));
