if (false) {
	(-0.83-(-11.69)-(16.34))
} else {
	(-19.88-(-2.23))
}
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-12.22);

} else {
	tcb->m_segmentSize = (int) (-17.32-(-7.4)-(14.24));

}
tcb->m_segmentSize = (int) (-6.47+(-19.11)+(-2.37)+(-13.31));
tcb->m_segmentSize = (int) (16.91)/(14.71);
tcb->m_segmentSize = (int) (-17.75+(-6.93)+(-8.24));
