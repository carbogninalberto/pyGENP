tcb->m_segmentSize = (int) (-10.07-(-12.58)-(5.39)-(18.43));
tcb->m_segmentSize = (int) (14.42-(-17.52)-(10.33));
tcb->m_segmentSize = (int) (19.07+(8.35)+(-18.77)+(10.82));
