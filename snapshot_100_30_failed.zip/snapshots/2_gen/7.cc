tcb->m_segmentSize = (int) (10.37*(-19.64)*(8.42));
