if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-12.22);

} else {
	tcb->m_segmentSize = (int) (-17.32-(-7.4)-(14.24));

}
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(-1.89)+(19.8)+(-10.19));

} else {
	tcb->m_segmentSize = (int) (-19.57)/(-14.77);

}
tcb->m_segmentSize = (int) (15.92*(8.11)*(10.3));
