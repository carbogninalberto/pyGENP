tcb->m_segmentSize = (int) (-9.49)/(6.09);
if (true) {
	tcb->m_segmentSize = (int) (0.13)/(-1.67);

} else {
	tcb->m_segmentSize = (int) (-13.07-(0.38));

}
