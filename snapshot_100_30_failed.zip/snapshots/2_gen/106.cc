if (false) {
	tcb->m_segmentSize = (int) (-1.21*(tcb->m_segmentSize)*(-5.09));

} else {
	tcb->m_segmentSize = (int) (-17.63+(4.5)+(tcb->m_segmentSize)+(17.95));

}
tcb->m_segmentSize = (int) (14.42-(-17.52)-(10.33));
tcb->m_segmentSize = (int) (19.07+(8.35)+(-18.77)+(10.82));
