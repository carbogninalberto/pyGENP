if (true) {
	tcb->m_segmentSize = (int) (6.17+(-0.76)+(13.28)+(-5.78));

} else {
	tcb->m_segmentSize = (int) (3.28)/(-14.95);

}
if (true) {
	tcb->m_segmentSize = (int) (-11.15+(-2.75)+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-5.74-(10.75));

}
