if (false) {
	tcb->m_segmentSize = (int) (-7.64-(2.68));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize+(3.15)+(-8.7));

}
if (true) {
	tcb->m_segmentSize = (int) (-8.02*(-14.24)*(19.62));

} else {
	tcb->m_segmentSize = (int) (-18.12)/(17.13);

}
