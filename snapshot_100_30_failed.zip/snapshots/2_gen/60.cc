tcb->m_segmentSize = (int) (-0.23+(-18.77)+(tcb->m_segmentSize)+(-18.75));
tcb->m_segmentSize = (int) (10.37*(-19.64)*(8.42));
