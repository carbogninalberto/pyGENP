if (true) {
	(9.36*(-13.88))
} else {
	(18.47*(18.27))
}
tcb->m_segmentSize = (int) (-9.49)/(6.09);
tcb->m_segmentSize = (int) (7.65)/(0.67);
