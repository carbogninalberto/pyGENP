if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (-15.87*(-10.22));

}
if (true) {
	tcb->m_segmentSize = (int) (0.13)/(-1.67);

} else {
	tcb->m_segmentSize = (int) (-13.07-(0.38));

}
