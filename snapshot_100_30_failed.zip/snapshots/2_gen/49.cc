if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (-15.87*(-10.22));

}
tcb->m_segmentSize = (int) (-9.49)/(6.09);
tcb->m_segmentSize = (int) (7.65)/(0.67);
