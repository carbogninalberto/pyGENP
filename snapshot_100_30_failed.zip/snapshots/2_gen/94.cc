if (true) {
	(3.21-(-3.43)-(tcb->m_segmentSize))
} else {
	(-13.3*(-9.77)*(8.1))
}
tcb->m_segmentSize = (int) (-10.07-(-12.58)-(5.39)-(18.43));
