if (false) {
	(-4.67)/(4.72)
} else {
	(-12.24-(4.48)-(tcb->m_segmentSize))
}
if (true) {
	tcb->m_segmentSize = (int) (0.13)/(-1.67);

} else {
	tcb->m_segmentSize = (int) (-13.07-(0.38));

}
