if (false) {
	tcb->m_segmentSize = (int) (-1.21*(tcb->m_segmentSize)*(-5.09));

} else {
	tcb->m_segmentSize = (int) (-17.63+(4.5)+(tcb->m_segmentSize)+(17.95));

}
if (true) {
	tcb->m_segmentSize = (int) (6.17+(-0.76)+(13.28)+(-5.78));

} else {
	tcb->m_segmentSize = (int) (3.28)/(-14.95);

}
if (false) {
	tcb->m_segmentSize = (int) (-9.39*(8.93));

} else {
	tcb->m_segmentSize = (int) (11.43)/(-8.25);

}
if (false) {
	tcb->m_segmentSize = (int) (-13.79+(-14.28));

} else {
	tcb->m_segmentSize = (int) (-19.36-(tcb->m_segmentSize)-(-15.28));

}
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(12.32)-(-1.55)-(8.41));

} else {
	tcb->m_segmentSize = (int) (5.25)/(14.89);

}
