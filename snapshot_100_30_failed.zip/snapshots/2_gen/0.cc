if (true) {
	(13.0-(-14.64)-(-2.26)-(tcb->m_segmentSize))
} else {
	(tcb->m_segmentSize+(tcb->m_segmentSize))
}
