tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(8.62);
tcb->m_segmentSize = (int) (19.07+(8.35)+(-18.77)+(10.82));
