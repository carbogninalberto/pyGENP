if (false) {
	(-8.08)/(17.61)
} else {
	(4.88)/(-12.41)
}
tcb->m_segmentSize = (int) (-9.49)/(6.09);
tcb->m_segmentSize = (int) (7.65)/(0.67);
