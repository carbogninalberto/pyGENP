tcb->m_segmentSize = (int) (-10.07-(-12.58)-(5.39)-(18.43));
