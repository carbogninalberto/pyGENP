tcb->m_segmentSize = (int) (10.37*(-19.64)*(8.42));
if (true) {
	tcb->m_segmentSize = (int) (-11.15+(-2.75)+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-5.74-(10.75));

}
