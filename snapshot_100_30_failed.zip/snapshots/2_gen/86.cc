if (true) {
	tcb->m_segmentSize = (int) (1.67-(0.94)-(-19.49)-(0.25));

} else {
	tcb->m_segmentSize = (int) (2.24-(-0.95)-(17.86));

}
if (true) {
	tcb->m_segmentSize = (int) (0.13)/(-1.67);

} else {
	tcb->m_segmentSize = (int) (-13.07-(0.38));

}
