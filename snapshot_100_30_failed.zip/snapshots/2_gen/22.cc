if (false) {
	(-8.27)/(5.06)
} else {
	(18.37+(-8.96)+(tcb->m_segmentSize))
}
tcb->m_segmentSize = (int) (14.42-(-17.52)-(10.33));
tcb->m_segmentSize = (int) (19.07+(8.35)+(-18.77)+(10.82));
