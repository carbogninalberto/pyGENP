tcb->m_segmentSize = (int) (-3.6*(2.12)*(8.11)*(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (-9.35-(-5.53)-(-19.97));
tcb->m_segmentSize = (int) (-16.61+(12.6)+(-0.51));
tcb->m_segmentSize = (int) (2.33)/(-17.54);
