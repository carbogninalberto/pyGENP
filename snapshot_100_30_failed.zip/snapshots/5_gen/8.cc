tcb->m_segmentSize = (int) (-9.35-(-5.53)-(-19.97));
tcb->m_segmentSize = (int) (8.36*(5.18)*(3.64)*(-17.66));
tcb->m_segmentSize = (int) (-16.61+(12.6)+(-0.51));
tcb->m_segmentSize = (int) (2.33)/(-17.54);
