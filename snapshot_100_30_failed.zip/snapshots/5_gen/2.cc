tcb->m_segmentSize = (int) (-14.33)/(-13.87);
tcb->m_segmentSize = (int) (2.33)/(-17.54);
tcb->m_segmentSize = (int) (tcb->m_segmentSize+(15.0));
if (true) {
	tcb->m_segmentSize = (int) (-13.73-(6.21)-(-8.82)-(-1.13));

} else {
	tcb->m_segmentSize = (int) (2.71-(2.44)-(1.15)-(-5.67));

}
