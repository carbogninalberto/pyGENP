float bSWdUTXGjxmBnXSr = (float) (13.2*(3.37));
