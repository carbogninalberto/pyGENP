float bSWdUTXGjxmBnXSr = (float) (18.05*(5.28));
