float bSWdUTXGjxmBnXSr = (float) (18.0+(17.57));
