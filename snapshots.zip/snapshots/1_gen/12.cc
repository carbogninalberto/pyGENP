int evngogpqEpOYVdVy = (int) (5.51*(1.73)*(14.41)*(13.07));
int FWLRgWgaksdcLgPM = (int) (10.7*(11.26)*(8.29));
if (tcb->m_ssThresh > evngogpqEpOYVdVy) {
	tcb->m_ssThresh = (int) (17.03+(19.57)+(3.61));

} else {
	tcb->m_ssThresh = (int) (12.02+(8.36)+(15.55));

}
evngogpqEpOYVdVy = (int) (17.18*(13.52)*(16.42)*(13.81));
