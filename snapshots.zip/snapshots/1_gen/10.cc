int ikvRglrTpfelmkdk = (int) (16.97+(7.51)+(10.42));
tcb->m_ssThresh = (int) (8.78+(16.65)+(8.67));
tcb->m_cWnd = (int) (3.14+(11.77)+(13.56));
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (19.19*(0.24)*(19.63)*(7.59));

} else {
	tcb->m_ssThresh = (int) (16.95+(1.3));

}
tcb->m_segmentSize = (int) (15.37+(6.87)+(15.98));
float TAxRCyXmeBXdaybs = (float) (14.21+(6.3));
if (tcb->m_segmentSize == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (13.15*(13.57));

} else {
	tcb->m_ssThresh = (int) (3.0+(4.27)+(10.47));

}
tcb->m_cWnd = (int) (9.59+(12.04)+(9.33));
int rbNVCXjHHAARDANs = (int) (2.7+(12.72)+(9.42)+(12.8));
if (ikvRglrTpfelmkdk == rbNVCXjHHAARDANs) {
	TAxRCyXmeBXdaybs = (float) (0.51+(6.02)+(5.66));

} else {
	TAxRCyXmeBXdaybs = (float) (11.21*(7.89));

}
if (tcb->m_ssThresh != ikvRglrTpfelmkdk) {
	tcb->m_segmentSize = (int) (8.23*(7.14)*(0.32)*(1.57));

} else {
	tcb->m_segmentSize = (int) (8.2+(5.34)+(15.05)+(5.57));

}
int oXwsjbZOOjDzzlcn = (int) (8.48*(11.19)*(6.63)*(13.11));
