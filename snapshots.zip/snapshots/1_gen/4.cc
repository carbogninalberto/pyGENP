if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (10.81*(9.49));

} else {
	tcb->m_segmentSize = (int) (8.11+(1.28));

}
tcb->m_cWnd = (int) (15.93+(16.84)+(2.31));
tcb->m_segmentSize = (int) (16.93*(15.49)*(17.45)*(8.44));
