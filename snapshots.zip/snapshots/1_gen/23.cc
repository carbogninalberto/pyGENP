int pxeIEUvwHYKlwXmX = (int) (8.98*(5.57));
tcb->m_ssThresh = (int) (2.08*(2.5)*(1.13)*(0.63));
tcb->m_segmentSize = (int) (7.05+(6.49)+(14.86));
int sVWmyeYuFTNUBgsY = (int) (15.83+(2.32)+(19.52));
pxeIEUvwHYKlwXmX = (int) (12.71*(4.17));
float imLyRRKYMzbZuyuN = (float) (14.37+(2.56)+(7.24)+(13.89));
if (tcb->m_cWnd != sVWmyeYuFTNUBgsY) {
	tcb->m_segmentSize = (int) (3.6*(5.73)*(8.76));

} else {
	tcb->m_segmentSize = (int) (1.79+(10.8)+(12.85));

}
float UGJpxOAuxEiyAvEJ = (float) (3.94+(5.32)+(4.46)+(12.83));
imLyRRKYMzbZuyuN = (float) (10.81*(14.88));
float GuEdGGrqIdZKDBom = (float) (10.9*(3.03)*(5.3)*(3.75));
tcb->m_segmentSize = (int) (15.0*(10.47)*(2.13));
sVWmyeYuFTNUBgsY = (int) (4.47*(12.67));
if (UGJpxOAuxEiyAvEJ < tcb->m_cWnd) {
	sVWmyeYuFTNUBgsY = (int) (16.34*(5.38)*(18.33));

} else {
	sVWmyeYuFTNUBgsY = (int) (7.23+(3.67));

}
float XJYPWrHrnmWOepAZ = (float) (17.96*(17.67)*(11.66)*(16.03));
int ttIDfHKbtLuCFklZ = (int) (9.98+(19.76));
if (ttIDfHKbtLuCFklZ != UGJpxOAuxEiyAvEJ) {
	tcb->m_cWnd = (int) (10.24*(17.84)*(3.81));

} else {
	tcb->m_cWnd = (int) (14.72*(2.63)*(6.59));

}
if (tcb->m_segmentSize > XJYPWrHrnmWOepAZ) {
	GuEdGGrqIdZKDBom = (float) (0.61+(7.41)+(17.21));

} else {
	GuEdGGrqIdZKDBom = (float) (4.09*(11.32)*(11.8));

}
tcb->m_segmentSize = (int) (6.92*(6.22)*(2.86));
pxeIEUvwHYKlwXmX = (int) (5.69+(6.85)+(19.52));
