if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (9.0*(6.04)*(13.48)*(3.5));

} else {
	tcb->m_cWnd = (int) (3.83+(1.62));

}
