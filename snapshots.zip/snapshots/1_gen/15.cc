float tZJMytHxCylimqMn = (float) (7.45*(15.55)*(18.18));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (2.99+(16.27)+(16.22)+(11.78));

} else {
	tcb->m_ssThresh = (int) (4.09+(5.27)+(17.23)+(3.62));

}
int GhnxpAvYKmqmpzKI = (int) (7.3+(5.83));
if (tcb->m_segmentSize < GhnxpAvYKmqmpzKI) {
	tcb->m_segmentSize = (int) (17.69*(0.33)*(5.3)*(13.32));

} else {
	tcb->m_segmentSize = (int) (4.07*(1.22)*(6.92)*(3.3));

}
int ZkIoVUOSKgmHaNEP = (int) (2.24*(18.49)*(10.74)*(1.79));
