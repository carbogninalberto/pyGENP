float jFKJdcpWRblsjkzP = (float) (16.06+(5.94)+(13.8)+(2.84));
tcb->m_ssThresh = (int) (10.0+(14.23)+(9.23)+(10.2));
if (tcb->m_cWnd == jFKJdcpWRblsjkzP) {
	jFKJdcpWRblsjkzP = (float) (1.51*(3.29)*(12.4));

} else {
	jFKJdcpWRblsjkzP = (float) (13.01*(16.62)*(3.56)*(8.52));

}
float LYiTNJlqeoSsVzUX = (float) (15.61+(12.03)+(1.67)+(19.84));
if (tcb->m_ssThresh != tcb->m_segmentSize) {
	jFKJdcpWRblsjkzP = (float) (8.08+(15.67));

} else {
	jFKJdcpWRblsjkzP = (float) (18.66*(11.61)*(19.82));

}
tcb->m_cWnd = (int) (19.91+(4.16)+(6.17));
tcb->m_cWnd = (int) (0.59+(2.56)+(10.27)+(17.57));
tcb->m_cWnd = (int) (5.27*(7.15)*(18.35)*(1.81));
tcb->m_ssThresh = (int) (4.09+(8.7));
if (tcb->m_cWnd >= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (16.41+(6.14)+(9.76));

} else {
	tcb->m_ssThresh = (int) (2.02+(0.21));

}
