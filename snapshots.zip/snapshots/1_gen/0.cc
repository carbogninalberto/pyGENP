tcb->m_cWnd = (int) (12.33+(4.48)+(11.47));
float URvFApfsCSshmrrr = (float) (11.05*(19.64));
if (tcb->m_ssThresh <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (13.56*(4.59));

} else {
	tcb->m_cWnd = (int) (6.01+(13.4)+(4.7));

}
tcb->m_cWnd = (int) (6.57+(6.35));
tcb->m_segmentSize = (int) (18.4+(19.6)+(7.58));
tcb->m_cWnd = (int) (15.28+(19.73)+(15.79)+(0.99));
if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (16.01+(11.5)+(17.99)+(6.3));

} else {
	tcb->m_cWnd = (int) (6.71+(13.69)+(17.91));

}
if (tcb->m_ssThresh == tcb->m_cWnd) {
	URvFApfsCSshmrrr = (float) (5.87*(18.03)*(13.0));

} else {
	URvFApfsCSshmrrr = (float) (4.04*(13.06));

}
int tZKiuhePUqVTLeFo = (int) (19.47+(13.95));
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	URvFApfsCSshmrrr = (float) (5.49*(15.02));

} else {
	URvFApfsCSshmrrr = (float) (4.16+(11.81)+(15.9)+(7.57));

}
int vsBukaNvcnKAmSeZ = (int) (8.96+(1.77)+(16.9));
if (URvFApfsCSshmrrr >= URvFApfsCSshmrrr) {
	tcb->m_cWnd = (int) (11.41+(4.04)+(7.99));

} else {
	tcb->m_cWnd = (int) (8.0*(6.15));

}
tcb->m_cWnd = (int) (3.36*(17.85)*(12.28)*(11.91));
tZKiuhePUqVTLeFo = (int) (9.85+(2.83)+(4.8)+(11.28));
tcb->m_cWnd = (int) (14.92*(10.49));
int vGessUrIXoxkVUUN = (int) (10.27*(7.56)*(17.72)*(12.81));
