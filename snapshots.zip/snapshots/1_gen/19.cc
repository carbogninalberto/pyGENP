if (tcb->m_cWnd <= tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (18.76*(2.26)*(9.82)*(2.47));

} else {
	tcb->m_ssThresh = (int) (13.78*(3.27)*(10.14));

}
tcb->m_ssThresh = (int) (11.97+(19.3)+(13.63)+(7.44));
tcb->m_ssThresh = (int) (18.23*(9.91)*(15.15));
if (tcb->m_ssThresh < tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (0.37*(11.24));

} else {
	tcb->m_ssThresh = (int) (13.69+(3.09)+(19.56)+(10.88));

}
int IjfCOIywjFsAyrah = (int) (12.12*(15.73)*(14.85)*(5.22));
if (tcb->m_segmentSize < tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (15.45*(19.9)*(12.87)*(5.17));

} else {
	tcb->m_ssThresh = (int) (17.08*(19.95)*(9.64)*(13.2));

}
tcb->m_ssThresh = (int) (5.93+(1.36)+(6.98));
if (tcb->m_cWnd > tcb->m_segmentSize) {
	tcb->m_cWnd = (int) (6.81*(15.68));

} else {
	tcb->m_cWnd = (int) (13.11+(7.03)+(10.05)+(17.06));

}
float ydKXvCAmhUcyiwAd = (float) (8.11+(17.48)+(14.71)+(3.27));
int FEGAUzidEKenyasy = (int) (2.13+(8.51)+(12.4)+(18.93));
float DuGSvSqUkVJsKAcJ = (float) (16.2+(15.39)+(12.72)+(16.85));
tcb->m_cWnd = (int) (9.55+(8.26)+(4.77));
IjfCOIywjFsAyrah = (int) (3.66+(7.3)+(17.46)+(9.36));
if (DuGSvSqUkVJsKAcJ > tcb->m_ssThresh) {
	DuGSvSqUkVJsKAcJ = (float) (10.15*(12.68));

} else {
	DuGSvSqUkVJsKAcJ = (float) (14.74+(2.9)+(0.88)+(16.17));

}
if (tcb->m_cWnd < tcb->m_segmentSize) {
	IjfCOIywjFsAyrah = (int) (11.04+(10.43)+(16.57)+(9.62));

} else {
	IjfCOIywjFsAyrah = (int) (9.69*(6.23)*(2.13)*(1.73));

}
DuGSvSqUkVJsKAcJ = (float) (7.38*(0.49));
