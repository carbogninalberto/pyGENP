float yaFNFpVtvRJGfCHE = (float) (5.89*(1.82));
tcb->m_segmentSize = (int) (12.65+(3.31)+(2.04)+(19.9));
if (yaFNFpVtvRJGfCHE > tcb->m_segmentSize) {
	tcb->m_ssThresh = (int) (3.75*(3.19)*(12.67)*(4.43));

} else {
	tcb->m_ssThresh = (int) (17.88+(15.01));

}
if (tcb->m_segmentSize > tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (12.62+(16.66)+(17.19));

} else {
	tcb->m_segmentSize = (int) (10.33*(4.98)*(18.05)*(10.55));

}
int NlVExHrzHSCMIVFC = (int) (8.11+(11.14)+(2.96)+(17.38));
int XECBbYlPqyZtNYnD = (int) (15.02*(8.56));
tcb->m_segmentSize = (int) (7.92+(10.62)+(6.55)+(0.3));
tcb->m_ssThresh = (int) (17.54*(10.33)*(14.29)*(0.49));
NlVExHrzHSCMIVFC = (int) (9.41+(5.9)+(6.82));
float YRWlwpJzjMXqeWEU = (float) (14.75*(1.27)*(17.11)*(5.0));
if (yaFNFpVtvRJGfCHE >= tcb->m_segmentSize) {
	yaFNFpVtvRJGfCHE = (float) (3.17+(5.3)+(2.94)+(15.88));

} else {
	yaFNFpVtvRJGfCHE = (float) (14.45+(5.61)+(15.49));

}
