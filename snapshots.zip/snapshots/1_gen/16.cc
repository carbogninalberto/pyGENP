tcb->m_segmentSize = (int) (19.53*(1.96)*(13.64)*(1.7));
tcb->m_ssThresh = (int) (18.33+(16.98)+(13.01)+(16.98));
tcb->m_ssThresh = (int) (12.06*(11.37)*(19.09)*(9.82));
tcb->m_ssThresh = (int) (3.92+(3.51));
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_cWnd = (int) (19.11+(9.86)+(16.83));

} else {
	tcb->m_cWnd = (int) (7.4+(11.29)+(10.76));

}
if (tcb->m_segmentSize > tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (17.11+(2.78)+(18.12));

} else {
	tcb->m_segmentSize = (int) (10.08+(4.66));

}
tcb->m_cWnd = (int) (5.15*(15.18)*(5.22));
tcb->m_cWnd = (int) (13.0+(11.51)+(15.29));
float gsCjEBgtTlaQJFYg = (float) (10.64*(6.53)*(5.44)*(12.12));
if (tcb->m_cWnd <= tcb->m_cWnd) {
	gsCjEBgtTlaQJFYg = (float) (17.59+(9.45)+(1.39));

} else {
	gsCjEBgtTlaQJFYg = (float) (7.41*(17.47)*(11.47));

}
if (gsCjEBgtTlaQJFYg == tcb->m_ssThresh) {
	tcb->m_ssThresh = (int) (6.33*(13.44));

} else {
	tcb->m_ssThresh = (int) (13.66*(13.71)*(16.5));

}
int xlBkCooidgCJdRmu = (int) (6.41+(19.14)+(15.94));
tcb->m_ssThresh = (int) (6.02*(9.55)*(18.67)*(9.72));
tcb->m_ssThresh = (int) (10.64*(9.98));
if (tcb->m_cWnd < tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (6.09*(19.78)*(6.93));

} else {
	tcb->m_segmentSize = (int) (17.4+(14.63)+(11.46)+(10.17));

}
