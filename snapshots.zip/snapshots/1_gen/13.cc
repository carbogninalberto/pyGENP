tcb->m_ssThresh = (int) (18.52*(15.11));
tcb->m_segmentSize = (int) (5.01+(14.42)+(3.83));
float hzBNFIbpKVqKTzLt = (float) (10.41+(7.56)+(1.37));
float zcKcWDmjwdZqgQYz = (float) (15.38*(19.91)*(0.83)*(7.79));
float IhOdCXifcsGhepOW = (float) (20.0*(8.77)*(7.61)*(13.18));
int PLCtLbIAQoteAbRY = (int) (9.65+(12.48)+(8.64));
if (hzBNFIbpKVqKTzLt <= tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (9.96+(6.67));

} else {
	tcb->m_segmentSize = (int) (14.0+(13.94)+(14.08)+(17.07));

}
float YdcLxrsVKTyRdSTQ = (float) (4.97*(8.81)*(11.92));
hzBNFIbpKVqKTzLt = (float) (12.81*(16.59)*(1.67));
int vjrkzdAfqqCPvBaQ = (int) (1.53*(3.2));
vjrkzdAfqqCPvBaQ = (int) (2.97*(0.96)*(12.79)*(19.7));
float qptwSxUlfJFPUUoe = (float) (1.87+(12.51)+(15.77)+(4.78));
vjrkzdAfqqCPvBaQ = (int) (5.58+(10.16)+(2.29)+(0.57));
int BWSQdZMJXJgRSBQj = (int) (12.93*(7.65)*(9.98)*(4.91));
zcKcWDmjwdZqgQYz = (float) (10.77+(4.16)+(5.35));
if (YdcLxrsVKTyRdSTQ == tcb->m_ssThresh) {
	vjrkzdAfqqCPvBaQ = (int) (7.19+(17.25)+(8.48)+(12.21));

} else {
	vjrkzdAfqqCPvBaQ = (int) (13.04*(0.98)*(15.96));

}
