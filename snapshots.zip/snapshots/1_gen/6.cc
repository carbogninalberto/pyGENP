float bSWdUTXGjxmBnXSr = (float) (8.51*(2.75));
