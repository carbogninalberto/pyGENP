float bSWdUTXGjxmBnXSr = (float) (16.31*(18.05));
