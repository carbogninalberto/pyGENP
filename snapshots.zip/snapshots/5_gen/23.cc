float bSWdUTXGjxmBnXSr = (float) (7.58*(5.11)*(11.26)*(10.83));
