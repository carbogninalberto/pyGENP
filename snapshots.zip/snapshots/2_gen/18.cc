if (tcb->m_cWnd != tcb->m_segmentSize) {
	tcb->m_segmentSize = (int) (7.03+(8.45)+(18.1));

} else {
	tcb->m_segmentSize = (int) (6.02*(16.3));

}
tcb->m_cWnd = (int) (15.93+(16.84)+(2.31));
tcb->m_segmentSize = (int) (16.93*(15.49)*(17.45)*(8.44));
