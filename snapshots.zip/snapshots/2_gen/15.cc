if (tcb->m_segmentSize != tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (16.75+(11.54)+(3.04));

} else {
	tcb->m_segmentSize = (int) (18.81+(14.99));

}
