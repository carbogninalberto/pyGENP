tcb->m_cWnd = (int) (19.26+(14.07)+(1.97));
if (tcb->m_segmentSize != tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (14.44+(0.22)+(1.04));

} else {
	tcb->m_ssThresh = (int) (14.48+(1.58)+(19.17));

}
tcb->m_ssThresh = (int) (18.54+(4.61));
int XGxkczqaKqffkBFB = (int) (13.87*(17.29));
