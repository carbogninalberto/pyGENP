tcb->m_segmentSize = (int) (16.23+(18.31)+(2.85));
if (tcb->m_segmentSize < tcb->m_cWnd) {
	tcb->m_ssThresh = (int) (9.98+(18.73)+(8.61));

} else {
	tcb->m_ssThresh = (int) (14.77*(18.64)*(4.31));

}
int bZKyqSUQtdHvCUKh = (int) (18.47+(18.23)+(1.35)+(13.35));
tcb->m_ssThresh = (int) (10.46+(0.97)+(8.72)+(15.72));
if (tcb->m_ssThresh == tcb->m_ssThresh) {
	tcb->m_segmentSize = (int) (13.04*(12.63)*(9.85)*(2.17));

} else {
	tcb->m_segmentSize = (int) (1.25+(18.95)+(3.05)+(16.5));

}
float AkHXlfkGnYiIONFO = (float) (13.48+(8.14));
int lGntEkJoduWHAsOP = (int) (6.56*(18.76)*(10.89)*(17.14));
if (tcb->m_cWnd >= tcb->m_segmentSize) {
	bZKyqSUQtdHvCUKh = (int) (6.69+(0.44)+(9.37)+(6.05));

} else {
	bZKyqSUQtdHvCUKh = (int) (1.54*(12.65)*(5.47));

}
