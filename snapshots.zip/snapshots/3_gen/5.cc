float bSWdUTXGjxmBnXSr = (float) (14.64+(11.2)+(1.98)+(18.88));
