float bSWdUTXGjxmBnXSr = (float) (0.84*(7.57)*(5.62)*(3.91));
