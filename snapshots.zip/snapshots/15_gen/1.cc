float bSWdUTXGjxmBnXSr = (float) (18.84*(18.79)*(14.03));
