float bSWdUTXGjxmBnXSr = (float) (5.39+(0.92)+(19.21));
