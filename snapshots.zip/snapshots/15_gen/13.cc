float bSWdUTXGjxmBnXSr = (float) (19.1+(13.24));
