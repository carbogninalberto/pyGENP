float bSWdUTXGjxmBnXSr = (float) (11.02+(8.84));
