float bSWdUTXGjxmBnXSr = (float) (17.26+(2.73)+(12.49));
