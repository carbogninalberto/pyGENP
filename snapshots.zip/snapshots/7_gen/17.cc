float bSWdUTXGjxmBnXSr = (float) (0.31+(8.19)+(9.66)+(11.3));
