float bSWdUTXGjxmBnXSr = (float) (18.93+(14.17));
