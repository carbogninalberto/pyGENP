float bSWdUTXGjxmBnXSr = (float) (5.46*(1.46)*(8.16));
