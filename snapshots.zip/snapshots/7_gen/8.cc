float bSWdUTXGjxmBnXSr = (float) (17.38*(18.35)*(15.59));
