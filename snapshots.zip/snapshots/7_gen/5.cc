float bSWdUTXGjxmBnXSr = (float) (14.39+(16.73)+(19.22));
