float bSWdUTXGjxmBnXSr = (float) (16.96*(19.38));
