float bSWdUTXGjxmBnXSr = (float) (12.99+(14.74));
