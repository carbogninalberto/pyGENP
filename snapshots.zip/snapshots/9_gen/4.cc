float bSWdUTXGjxmBnXSr = (float) (7.24+(9.87)+(7.49)+(13.58));
