float bSWdUTXGjxmBnXSr = (float) (7.8+(4.08)+(1.7)+(11.27));
