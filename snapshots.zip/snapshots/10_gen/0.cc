float bSWdUTXGjxmBnXSr = (float) (0.27+(11.63)+(19.8)+(3.05));
