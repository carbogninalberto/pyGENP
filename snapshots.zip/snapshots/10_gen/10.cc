float bSWdUTXGjxmBnXSr = (float) (11.94*(16.19));
