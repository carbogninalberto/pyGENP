float bSWdUTXGjxmBnXSr = (float) (3.2+(7.83)+(4.59)+(10.07));
