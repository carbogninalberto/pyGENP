float bSWdUTXGjxmBnXSr = (float) (17.6*(9.99));
