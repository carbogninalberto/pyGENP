float bSWdUTXGjxmBnXSr = (float) (3.13+(17.1)+(3.57)+(15.97));
