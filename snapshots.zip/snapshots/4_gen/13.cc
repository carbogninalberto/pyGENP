float bSWdUTXGjxmBnXSr = (float) (14.46*(6.38)*(5.77));
