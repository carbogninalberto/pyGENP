float bSWdUTXGjxmBnXSr = (float) (6.91+(4.31)+(14.34)+(1.14));
