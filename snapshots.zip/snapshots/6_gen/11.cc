float bSWdUTXGjxmBnXSr = (float) (4.95*(13.2)*(17.27)*(0.93));
