float bSWdUTXGjxmBnXSr = (float) (17.96*(5.05)*(3.76));
