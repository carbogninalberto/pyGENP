float bSWdUTXGjxmBnXSr = (float) (12.07+(6.53)+(8.33));
