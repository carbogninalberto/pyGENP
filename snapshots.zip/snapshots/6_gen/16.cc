float bSWdUTXGjxmBnXSr = (float) (19.18*(19.01));
