float bSWdUTXGjxmBnXSr = (float) (9.09+(15.84)+(3.32));
