float bSWdUTXGjxmBnXSr = (float) (17.89*(8.63)*(19.14));
