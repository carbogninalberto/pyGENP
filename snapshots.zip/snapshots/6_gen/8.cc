float bSWdUTXGjxmBnXSr = (float) (16.78+(0.3)+(5.43)+(10.76));
