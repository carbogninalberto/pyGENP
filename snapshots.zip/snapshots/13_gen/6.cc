float bSWdUTXGjxmBnXSr = (float) (9.46*(14.05));
