float bSWdUTXGjxmBnXSr = (float) (13.61*(8.67)*(7.03)*(7.08));
