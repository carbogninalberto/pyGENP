float bSWdUTXGjxmBnXSr = (float) (18.57*(7.01)*(9.02)*(8.78));
