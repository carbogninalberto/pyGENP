float bSWdUTXGjxmBnXSr = (float) (3.08+(8.18)+(1.64));
