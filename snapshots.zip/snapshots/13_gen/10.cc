float bSWdUTXGjxmBnXSr = (float) (2.7+(13.88)+(6.23));
