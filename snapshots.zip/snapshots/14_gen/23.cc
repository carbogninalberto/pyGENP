float bSWdUTXGjxmBnXSr = (float) (4.42+(1.12)+(2.43));
