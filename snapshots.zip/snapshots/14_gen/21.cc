float bSWdUTXGjxmBnXSr = (float) (7.11+(3.7));
