float bSWdUTXGjxmBnXSr = (float) (14.72+(3.21));
