float bSWdUTXGjxmBnXSr = (float) (9.47*(12.48));
