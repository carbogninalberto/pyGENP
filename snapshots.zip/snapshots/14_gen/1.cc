float bSWdUTXGjxmBnXSr = (float) (5.91+(3.29)+(16.6)+(6.34));
