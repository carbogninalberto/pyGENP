float ylcjzzHIjUQpJYdE = (float) (16.79+(13.72)+(2.74));
float aLVvHYRZntQmiBki = (float) (7.6*(6.23)*(9.51)*(6.89));
float SJNmoIDLZmNkztvc = (float) (0.85+(17.47)+(4.49)+(8.54));
if (tcb->m_ssThresh < tcb->m_cWnd) {
	SJNmoIDLZmNkztvc = (float) (11.92+(8.55));

} else {
	SJNmoIDLZmNkztvc = (float) (6.68*(5.77)*(18.45)*(14.25));

}
int ijqGMeQDDbXkgdiQ = (int) (6.96*(19.7));
float ICSIVvrWfmqmFWeV = (float) (10.13*(1.07)*(16.97));
SJNmoIDLZmNkztvc = (float) (9.39*(2.82)*(1.4));
tcb->m_ssThresh = (int) (15.82*(14.07)*(16.95));
ICSIVvrWfmqmFWeV = (float) (0.61*(4.01)*(7.15)*(9.15));
aLVvHYRZntQmiBki = (float) (14.5+(3.24)+(7.49)+(11.42));
float iUytMinaMFbUXPjx = (float) (1.81+(13.72));
if (aLVvHYRZntQmiBki > SJNmoIDLZmNkztvc) {
	SJNmoIDLZmNkztvc = (float) (9.78+(16.28)+(14.54)+(10.73));

} else {
	SJNmoIDLZmNkztvc = (float) (15.28+(9.12)+(4.06));

}
if (iUytMinaMFbUXPjx > tcb->m_segmentSize) {
	ijqGMeQDDbXkgdiQ = (int) (17.54+(3.62)+(9.5));

} else {
	ijqGMeQDDbXkgdiQ = (int) (2.72*(3.72)*(8.36));

}
int ApHfxTHdSMNblvcK = (int) (15.67*(8.4));
int nkZWbyuSFYmqPplw = (int) (7.16*(9.78)*(10.36));
if (SJNmoIDLZmNkztvc <= nkZWbyuSFYmqPplw) {
	ApHfxTHdSMNblvcK = (int) (6.94*(19.58)*(11.86)*(5.7));

} else {
	ApHfxTHdSMNblvcK = (int) (11.5+(16.79)+(13.15)+(5.23));

}
