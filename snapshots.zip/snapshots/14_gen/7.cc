float bSWdUTXGjxmBnXSr = (float) (10.81+(14.63)+(10.09)+(0.52));
