float bSWdUTXGjxmBnXSr = (float) (18.04+(5.37)+(12.79));
