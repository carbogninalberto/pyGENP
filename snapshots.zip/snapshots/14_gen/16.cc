float bSWdUTXGjxmBnXSr = (float) (8.86*(9.43)*(19.01)*(1.99));
