float bSWdUTXGjxmBnXSr = (float) (18.07+(4.55));
