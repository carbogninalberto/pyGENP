float bSWdUTXGjxmBnXSr = (float) (9.6*(3.36));
