float bSWdUTXGjxmBnXSr = (float) (1.52*(6.76)*(6.33)*(16.57));
