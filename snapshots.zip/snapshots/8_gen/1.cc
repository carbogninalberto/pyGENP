float bSWdUTXGjxmBnXSr = (float) (11.58+(4.58));
