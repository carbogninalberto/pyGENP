float bSWdUTXGjxmBnXSr = (float) (12.73*(14.04)*(13.04)*(10.65));
