float bSWdUTXGjxmBnXSr = (float) (18.86*(8.52)*(17.31));
