float bSWdUTXGjxmBnXSr = (float) (0.66*(11.63));
