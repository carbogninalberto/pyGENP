tcb->m_ssThresh = (int) (2.78*(17.79)*(15.55)*(12.51));
tcb->m_ssThresh = (int) (17.66*(6.92));
tcb->m_segmentSize = (int) (16.44+(5.67)+(5.42));
int yfANzXuLHjyeckLA = (int) (9.64*(12.05)*(2.6));
yfANzXuLHjyeckLA = (int) (9.65*(16.58)*(5.3));
if (tcb->m_cWnd < yfANzXuLHjyeckLA) {
	tcb->m_segmentSize = (int) (6.74+(14.02)+(2.93)+(9.45));

} else {
	tcb->m_segmentSize = (int) (15.03+(5.76)+(13.11));

}
int LTfomBefDPnaaspp = (int) (15.17+(3.65)+(15.33));
