float bSWdUTXGjxmBnXSr = (float) (1.69*(6.79));
