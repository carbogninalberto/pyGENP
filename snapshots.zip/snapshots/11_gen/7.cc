float bSWdUTXGjxmBnXSr = (float) (14.11*(17.0));
