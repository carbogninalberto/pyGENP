float bSWdUTXGjxmBnXSr = (float) (14.01+(14.29)+(14.42)+(8.7));
