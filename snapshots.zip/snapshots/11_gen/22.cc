float bSWdUTXGjxmBnXSr = (float) (13.62*(2.71)*(8.65));
