if (true) {
	tcb->m_segmentSize = (int) (2.53+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.91-(-1.54));

}
if (true) {
	tcb->m_segmentSize = (int) (2.53+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.91-(-1.54));

}
if (true) {
	tcb->m_segmentSize = (int) (2.53+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.91-(-1.54));

}
if (true) {
	tcb->m_segmentSize = (int) (2.53+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.91-(-1.54));

}
if (true) {
	tcb->m_segmentSize = (int) (2.53+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.91-(-1.54));

}
if (true) {
	tcb->m_segmentSize = (int) (2.53+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.91-(-1.54));

}
if (true) {
	tcb->m_segmentSize = (int) (2.53+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.91-(-1.54));

}
if (true) {
	tcb->m_segmentSize = (int) (2.53+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.91-(-1.54));

}
if (true) {
	tcb->m_segmentSize = (int) (2.53+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.91-(-1.54));

}
if (true) {
	tcb->m_segmentSize = (int) (2.53+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.91-(-1.54));

}
if (true) {
	tcb->m_segmentSize = (int) (2.53+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.91-(-1.54));

}
if (true) {
	tcb->m_segmentSize = (int) (2.53+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.91-(-1.54));

}
if (true) {
	tcb->m_segmentSize = (int) (2.53+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.91-(-1.54));

}
tcb->m_segmentSize = (int) (1.38-(-1.73)-(tcb->m_segmentSize));
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(tcb->m_segmentSize);

} else {
	tcb->m_segmentSize = (int) (-6.06-(tcb->m_segmentSize));

}
