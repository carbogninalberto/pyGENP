if (true) {
	tcb->m_segmentSize = (int) (-0.06*(-17.13)*(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (-9.56*(tcb->m_segmentSize)*(-14.03)*(16.91));

}
if (false) {
	tcb->m_segmentSize = (int) (-6.93)/(13.73);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(tcb->m_segmentSize);

}
