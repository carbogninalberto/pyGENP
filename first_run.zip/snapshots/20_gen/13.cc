tcb->m_segmentSize = (int) (13.04*(-18.84)*(-3.56));
tcb->m_segmentSize = (int) (12.51)/(-4.56);
tcb->m_segmentSize = (int) (9.72-(-7.11));
