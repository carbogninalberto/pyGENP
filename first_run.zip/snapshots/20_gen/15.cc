tcb->m_segmentSize = (int) (19.22+(-19.74));
tcb->m_segmentSize = (int) (0.89)/(-13.89);
tcb->m_segmentSize = (int) (-3.24+(-6.72)+(-11.5));
