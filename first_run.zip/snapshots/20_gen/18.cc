if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-0.31);

} else {
	tcb->m_segmentSize = (int) (7.34-(11.13));

}
