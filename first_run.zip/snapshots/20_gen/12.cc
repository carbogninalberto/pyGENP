tcb->m_segmentSize = (int) (9.24*(1.26));
tcb->m_segmentSize = (int) (2.49+(13.01));
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize)/(-4.53);

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-1.36));

}
