if (false) {
	tcb->m_segmentSize = (int) (-1.4+(-12.42)+(tcb->m_segmentSize)+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (13.46+(0.45));

}
if (false) {
	tcb->m_segmentSize = (int) (15.46*(-14.96)*(9.78));

} else {
	tcb->m_segmentSize = (int) (16.75)/(8.41);

}
if (true) {
	tcb->m_segmentSize = (int) (-17.83)/(-16.23);

} else {
	tcb->m_segmentSize = (int) (12.64+(8.53)+(12.91)+(-3.66));

}
