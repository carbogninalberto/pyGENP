if (false) {
	tcb->m_segmentSize = (int) (19.78-(-9.09)-(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(-11.08)*(-18.13)*(3.2));

}
tcb->m_segmentSize = (int) (-7.55)/(1.25);
tcb->m_segmentSize = (int) (-10.89+(9.72));
