if (true) {
	tcb->m_segmentSize = (int) (-15.13+(-4.99)+(4.11)+(11.41));

} else {
	tcb->m_segmentSize = (int) (-6.85)/(18.81);

}
