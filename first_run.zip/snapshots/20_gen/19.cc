if (false) {
	tcb->m_segmentSize = (int) (-6.91-(13.46)-(-18.41));

} else {
	tcb->m_segmentSize = (int) (11.97-(11.12)-(3.06)-(-19.03));

}
tcb->m_segmentSize = (int) (8.14)/(-14.19);
