tcb->m_segmentSize = (int) (-10.14*(tcb->m_segmentSize));
tcb->m_segmentSize = (int) (-17.96-(2.08)-(-18.76));
tcb->m_segmentSize = (int) (-9.06-(2.71)-(-16.13)-(-1.22));
tcb->m_segmentSize = (int) (5.64*(tcb->m_segmentSize));
