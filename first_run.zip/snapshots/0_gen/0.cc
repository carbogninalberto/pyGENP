if (true) {
	tcb->m_segmentSize = (int) (16.15*(-16.11));

} else {
	tcb->m_segmentSize = (int) (12.09+(2.17));

}
tcb->m_segmentSize = (int) (11.76-(-18.1));
if (false) {
	tcb->m_segmentSize = (int) (-0.51*(-0.83)*(14.74));

} else {
	tcb->m_segmentSize = (int) (-7.89)/(-14.66);

}
tcb->m_segmentSize = (int) (-0.51+(-0.01)+(-19.96));
