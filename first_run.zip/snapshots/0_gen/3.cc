tcb->m_segmentSize = (int) (-10.9-(-6.77));
