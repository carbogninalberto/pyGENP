tcb->m_segmentSize = (int) (11.67-(-1.02));
tcb->m_segmentSize = (int) (-8.04-(tcb->m_segmentSize)-(-13.18)-(-9.75));
if (true) {
	tcb->m_segmentSize = (int) (8.97)/(14.93);

} else {
	tcb->m_segmentSize = (int) (-16.96+(-9.62)+(-8.73));

}
