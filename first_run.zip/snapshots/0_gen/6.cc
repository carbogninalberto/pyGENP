tcb->m_segmentSize = (int) (15.42)/(13.05);
tcb->m_segmentSize = (int) (tcb->m_segmentSize*(-4.34)*(tcb->m_segmentSize)*(-8.12));
