if (false) {
	tcb->m_segmentSize = (int) (18.13+(-11.63)+(-7.65)+(-18.77));

} else {
	tcb->m_segmentSize = (int) (8.55)/(-14.41);

}
tcb->m_segmentSize = (int) (-16.37+(10.31)+(-14.82));
tcb->m_segmentSize = (int) (-7.21-(tcb->m_segmentSize));
if (false) {
	tcb->m_segmentSize = (int) (-10.86*(5.08)*(19.76)*(-9.95));

} else {
	tcb->m_segmentSize = (int) (0.77+(-15.11));

}
