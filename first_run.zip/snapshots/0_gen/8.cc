if (true) {
	tcb->m_segmentSize = (int) (-12.34)/(10.01);

} else {
	tcb->m_segmentSize = (int) (13.13)/(-11.15);

}
if (false) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize*(-15.14)*(1.7));

} else {
	tcb->m_segmentSize = (int) (9.26)/(-0.69);

}
if (false) {
	tcb->m_segmentSize = (int) (-2.19*(-17.08));

} else {
	tcb->m_segmentSize = (int) (-12.85-(-2.51)-(-8.95)-(-18.59));

}
