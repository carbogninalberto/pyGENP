if (true) {
	tcb->m_segmentSize = (int) (2.53+(tcb->m_segmentSize));

} else {
	tcb->m_segmentSize = (int) (5.91-(-1.54));

}
tcb->m_segmentSize = (int) (19.97)/(9.51);
