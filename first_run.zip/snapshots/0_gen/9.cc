if (false) {
	tcb->m_segmentSize = (int) (10.37)/(3.78);

} else {
	tcb->m_segmentSize = (int) (-15.14-(-2.25)-(-1.83));

}
tcb->m_segmentSize = (int) (-8.92*(14.05)*(tcb->m_segmentSize)*(0.3));
if (true) {
	tcb->m_segmentSize = (int) (tcb->m_segmentSize-(-19.56));

} else {
	tcb->m_segmentSize = (int) (12.87)/(18.6);

}
tcb->m_segmentSize = (int) (9.88-(tcb->m_segmentSize));
