if (false) {
	tcb->m_segmentSize = (int) (-11.64-(1.25));

} else {
	tcb->m_segmentSize = (int) (11.18-(6.41));

}
if (false) {
	tcb->m_segmentSize = (int) (7.56-(17.09)-(0.59)-(15.84));

} else {
	tcb->m_segmentSize = (int) (-12.36)/(tcb->m_segmentSize);

}
